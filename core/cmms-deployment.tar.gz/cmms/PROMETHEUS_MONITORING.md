# Prometheus Monitoring for ChatterFix CMMS

## Overview

The ChatterFix CMMS application now includes Prometheus monitoring via `prometheus-fastapi-instrumentator`. This provides comprehensive request tracking, latency histograms, and performance metrics for production monitoring and alerting.

## Metrics Available

### HTTP Request Metrics
- `http_request_duration_seconds` - Request latency histogram with handler-specific labels
- `http_requests_total` - Total HTTP requests counter  
- `http_requests_inprogress` - Currently active HTTP requests gauge

### System Metrics
- Standard Python/process metrics (memory, CPU, GC stats)
- Custom application metrics available via `/metrics` endpoint

## Configuration Details

### Histogram Buckets
The application uses **modest histogram buckets** to minimize overhead:
```
Buckets: [0.1, 0.5, 1.0, +Inf] seconds
```

These buckets provide sufficient granularity for:
- **p50 (median)**: Requests under 100ms vs 100ms-500ms  
- **p95**: Requests under 500ms vs 500ms-1s vs >1s
- **p99**: Captured in the +Inf bucket

### Performance Overhead

⚠️ **Monitoring Overhead Considerations:**

1. **Memory Impact**: ~1KB per unique handler/method/status combination
2. **CPU Impact**: ~0.1ms additional latency per request for metric collection
3. **Cardinality**: Limited by default handler grouping (excludes untemplated routes)
4. **Storage**: ~50 bytes per metric sample in Prometheus

**Recommended limits:**
- Max 1000 handlers to keep cardinality manageable
- Scrape interval: **15 seconds** (balances freshness vs overhead)
- Retention: 7-30 days depending on storage capacity

## Deployment Configuration

### Application Setup
```python
from prometheus_fastapi_instrumentator import Instrumentator

# Minimal setup with sensible defaults
Instrumentator().instrument(app).expose(app)
```

### Prometheus Scrape Job
```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'chatterfix-cmms'
    static_configs:
      - targets: ['localhost:8888']
    scrape_interval: 15s
    scrape_timeout: 10s
    metrics_path: '/metrics'
    honor_labels: true
```

### Docker Compose (Optional)
```yaml
version: '3.8'
services:
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=7d'
```

## Grafana Dashboard

See `grafana-dashboard.json` for a pre-configured dashboard showing:
- Request rate (RPS) by handler
- Response time percentiles (p50, p95, p99) 
- Error rate percentage
- Active requests gauge
- System resource utilization

### Key Queries

**Request Rate (RPS):**
```promql
rate(http_request_duration_seconds_count[5m])
```

**p95 Latency:**
```promql
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))
```

**Error Rate:**
```promql
rate(http_requests_total{status=~"4..|5.."}[5m]) / 
rate(http_requests_total[5m]) * 100
```

## Production Readiness Checklist

- [x] Metrics endpoint exposed at `/metrics`
- [x] Modest histogram buckets configured  
- [ ] Prometheus server configured with 15s scrape interval
- [ ] Grafana dashboard imported
- [ ] Alerting rules configured for SLA violations
- [ ] Log aggregation correlation with trace IDs

## Troubleshooting

### Metrics Not Available
1. Check `/metrics` endpoint returns Prometheus format
2. Verify instrumentator is called during app initialization
3. Confirm no middleware conflicts with metrics collection

### High Cardinality Issues
1. Monitor series count: `prometheus_tsdb_symbol_table_size_bytes`
2. Review handler grouping configuration
3. Consider excluding high-volume untemplated routes

### Performance Impact
1. Monitor request latency distribution changes
2. Track memory growth in metrics storage
3. Adjust scrape intervals if overhead is significant

## Next Steps

1. Deploy to production environment
2. Configure Prometheus alerts for SLA monitoring
3. Set up dashboard links for incident response
4. Implement log correlation with request IDs