#!/usr/bin/env python3
"""
Enhanced CMMS AI Module with Intelligent Maintenance Responses
Fixed generic responses with contextual, specific maintenance advice
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Dict, Any, Optional
from datetime import datetime
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# LLaMA Configuration
LLAMA_SERVER = "http://localhost:11434"
LLAMA_MODEL = "llama3.2:1b"

# AI router
ai_router = APIRouter(prefix="/ai", tags=["ai"])

# Data models
class AIRequest(BaseModel):
    message: str
    context: str = "general"
    user_type: str = "technician"

class VoiceCommand(BaseModel):
    text: str
    user_id: str
    timestamp: Optional[str] = None

class OCRRequest(BaseModel):
    ocr_data: Dict[str, Any]
    scan_type: str = "nameplate"

# Mock databases and caching
voice_commands_db = []
predictions_cache = {}

# User memory system for personalized responses
user_memory = {}  # user_id -> user data
user_sessions = {}  # session -> user preferences

# Response caching for AI queries
import hashlib
import time
from typing import Dict, Tuple

response_cache: Dict[str, Tuple[str, float]] = {}  # hash -> (response, timestamp)
CACHE_TTL = 1800  # 30 minutes cache TTL

def get_user_role_from_context(message: str, context: str) -> str:
    """Detect user role from message context"""
    message_lower = message.lower()
    
    # Role keywords
    manager_keywords = ["schedule", "budget", "cost", "timeline", "team", "reports", "metrics"]
    scheduler_keywords = ["plan", "when", "available", "book", "calendar", "appointment", "slot"]
    parts_keywords = ["part", "inventory", "stock", "order", "supplier", "p/n", "part number"]
    supervisor_keywords = ["safety", "compliance", "crew", "assign", "approve", "oversight"]
    
    if any(word in message_lower for word in manager_keywords):
        return "manager"
    elif any(word in message_lower for word in scheduler_keywords):
        return "scheduler" 
    elif any(word in message_lower for word in parts_keywords):
        return "parts"
    elif any(word in message_lower for word in supervisor_keywords):
        return "supervisor"
    else:
        return "technician"  # default

def remember_user_interaction(user_id: str, message: str, role: str):
    """Store user interaction in memory"""
    if user_id not in user_memory:
        user_memory[user_id] = {
            "role": role,
            "interactions": [],
            "preferences": {},
            "last_seen": datetime.now().isoformat()
        }
    
    user_memory[user_id]["interactions"].append({
        "message": message[:100],  # Store first 100 chars
        "timestamp": datetime.now().isoformat(),
        "role": role
    })
    
    # Keep only last 10 interactions
    if len(user_memory[user_id]["interactions"]) > 10:
        user_memory[user_id]["interactions"] = user_memory[user_id]["interactions"][-10:]

def get_cache_key(message: str, context: str) -> str:
    """Generate cache key from message and context"""
    content = f"{message.lower().strip()}:{context}"
    return hashlib.md5(content.encode()).hexdigest()

def get_cached_response(cache_key: str) -> Optional[str]:
    """Get cached response if valid"""
    if cache_key in response_cache:
        response, timestamp = response_cache[cache_key]
        if time.time() - timestamp < CACHE_TTL:
            return response
        else:
            # Remove expired cache entry
            del response_cache[cache_key]
    return None

def cache_response(cache_key: str, response: str):
    """Cache AI response"""
    response_cache[cache_key] = (response, time.time())
    
    # Simple cache cleanup - remove oldest entries if cache gets too large
    if len(response_cache) > 1000:
        # Remove oldest 10% of entries
        sorted_items = sorted(response_cache.items(), key=lambda x: x[1][1])
        for key, _ in sorted_items[:100]:
            del response_cache[key]

# Enhanced AI response system using multi-model orchestrator
async def query_llama(message: str, context: str = "general", user_id: str = "unknown") -> str:
    """Enhanced AI query using multi-model orchestrator with intelligent selection"""
    try:
        # Check cache first
        cache_key = get_cache_key(message, context)
        cached_response = get_cached_response(cache_key)
        if cached_response:
            logger.info(f"AI cache hit for query: {message[:50]}...")
            return cached_response
        
        from ai_orchestrator import intelligent_chat
        
        # Determine complexity based on message analysis
        message_lower = message.lower()
        complexity = "low"
        
        if any(word in message_lower for word in ["complex", "advanced", "detailed", "comprehensive"]):
            complexity = "high"
        elif any(word in message_lower for word in ["analyze", "diagnose", "troubleshoot", "debug"]):
            complexity = "medium"
        
        # Use intelligent orchestrator
        response = await intelligent_chat(message, context, complexity)
        
        if response.get("response"):
            # Remember this interaction
            user_role = get_user_role_from_context(message, context)
            remember_user_interaction(user_id, message, user_role)
            
            # Cache successful response
            cache_response(cache_key, response["response"])
            return response["response"]
        else:
            # Fallback to conversational response
            equipment_type = analyze_equipment_type(message_lower)
            issue_type = analyze_issue_type(message_lower)
            user_role = get_user_role_from_context(message, context)
            fallback_response = generate_conversational_fallback_response(equipment_type, issue_type, message, user_role)
            
            # Remember this interaction
            remember_user_interaction(user_id, message, user_role)
            
            cache_response(cache_key, fallback_response)
            return fallback_response
        
    except Exception as e:
        logger.error(f"AI orchestrator error: {str(e)}")
        # Analyze message for fallback response
        message_lower = message.lower()
        equipment_type = analyze_equipment_type(message_lower)
        issue_type = analyze_issue_type(message_lower)
        user_role = get_user_role_from_context(message, context)
        fallback_response = generate_technical_fallback_response(equipment_type, issue_type, message)
        
        # Remember this interaction even in error case
        remember_user_interaction(user_id, message, user_role)
        
        cache_response(cache_key, fallback_response)
        return fallback_response

def analyze_equipment_type(message_lower: str) -> str:
    """Analyze message to determine equipment type"""
    equipment_keywords = {
        "conveyor system": ["conveyor", "belt", "idler", "pulley"],
        "pump system": ["pump", "impeller", "volute", "seal"],
        "motor": ["motor", "stator", "rotor", "winding"],
        "hvac system": ["hvac", "air conditioning", "fan", "compressor", "chiller"],
        "bearing assembly": ["bearing", "shaft", "journal", "thrust"],
        "valve system": ["valve", "actuator", "stem", "seat"],
        "gearbox": ["gearbox", "gear", "transmission", "reducer"],
        "compressor": ["compressor", "piston", "cylinder", "discharge"]
    }
    
    for equipment, keywords in equipment_keywords.items():
        if any(keyword in message_lower for keyword in keywords):
            return equipment
    
    return "industrial equipment"

def analyze_issue_type(message_lower: str) -> str:
    """Analyze message to determine issue type"""
    issue_keywords = {
        "vibration problem": ["vibrat", "shak", "oscillat", "bounce"],
        "overheating condition": ["overheat", "hot", "temperature", "thermal", "burn"],
        "abnormal noise": ["noise", "sound", "loud", "squeal", "grind", "knock"],
        "leakage issue": ["leak", "drip", "seep", "spill", "fluid loss"],
        "electrical problem": ["electrical", "power", "voltage", "current", "short"],
        "wear condition": ["wear", "worn", "damage", "deteriorat", "erode"],
        "alignment issue": ["alignment", "misalign", "offset", "coupling"],
        "lubrication problem": ["lubricat", "oil", "grease", "dry", "friction"],
        "performance degradation": ["slow", "inefficient", "poor performance", "capacity"]
    }
    
    for issue, keywords in issue_keywords.items():
        if any(keyword in message_lower for keyword in keywords):
            return issue
    
    return "maintenance issue"

def analyze_urgency(message_lower: str) -> str:
    """Analyze message urgency level"""
    urgent_keywords = ["emergency", "urgent", "critical", "immediate", "danger", "safety", "shut down", "failure"]
    if any(keyword in message_lower for keyword in urgent_keywords):
        return "high"
    elif any(keyword in message_lower for keyword in ["soon", "schedule", "plan", "preventive"]):
        return "normal"
    else:
        return "routine"

def create_conversational_maintenance_prompt(equipment_type: str, issue_type: str, urgency: str, context: str, user_role: str = "technician") -> str:
    """Create conversational, role-based maintenance assistant prompt"""
    
    # Base personality - friendly coworker
    base_personality = """You are ChatterFix AI, a helpful maintenance assistant and coworker. You're knowledgeable, experienced, but also friendly and conversational. Think of yourself as the experienced tech who's been around the plant for years and is always willing to help out a colleague."""
    
    # Role-specific adaptations
    role_adaptations = {
        "technician": "You're talking to a fellow technician. Be practical, direct, and focus on hands-on solutions. Use technical terms they'd know but explain complex stuff clearly.",
        "manager": "You're talking to a maintenance manager. Focus on schedules, resource needs, safety compliance, and business impact. Include time estimates and cost considerations.",
        "scheduler": "You're talking to someone who needs to plan work. Focus on dependencies, resource requirements, estimated time, parts needed, and scheduling constraints.",
        "supervisor": "You're talking to a supervisor. Balance technical details with operational impact. Include safety considerations and team coordination needs.",
        "parts": "You're talking to parts/inventory staff. Focus on part numbers, specifications, suppliers, lead times, and inventory levels."
    }
    
    # Urgency tone adjustment
    urgency_tone = {
        "emergency": "This sounds urgent - let's get you sorted quickly.",
        "high": "This needs attention soon. Here's what I'd suggest:",
        "medium": "Good question! Here's what I'm thinking:",
        "low": "Sure thing! When you get a chance, here's my take:"
    }
    
    current_situation = f"""
CURRENT SITUATION:
- Equipment: {equipment_type}
- Issue: {issue_type}
- Priority: {urgency}
- Context: {context}
- Talking to: {user_role}
"""
    
    response_style = f"""
RESPONSE STYLE:
- Be conversational and helpful, like a knowledgeable coworker
- Use role-appropriate language and focus areas
- Start with a friendly greeting and dive into the problem
- Keep safety in mind but don't lecture - just mention it naturally
- Ask follow-up questions if you need more info
- Be practical and actionable
- Use real numbers and specifics when helpful
- Keep it friendly but professional
"""
    
    return base_personality + current_situation + response_style

def post_process_response(response: str, equipment_type: str, issue_type: str) -> str:
    """Post-process AI response for better formatting and safety emphasis"""
    # Ensure safety is prominent
    if "safety" not in response.lower() and "lockout" not in response.lower():
        safety_header = f"⚠️ SAFETY PROTOCOL: Follow lockout/tagout procedures for {equipment_type}. Verify zero energy state before work.\n\n"
        response = safety_header + response
    
    # Add structure and formatting
    response = response.replace("1.", "\n1.")
    response = response.replace("2.", "\n2.")
    response = response.replace("3.", "\n3.")
    response = response.replace("4.", "\n4.")
    response = response.replace("5.", "\n5.")
    
    # Add technical emphasis
    response = response.replace("IMPORTANT:", "🔧 TECHNICAL NOTE:")
    response = response.replace("WARNING:", "⚠️ WARNING:")
    response = response.replace("NOTE:", "📋 NOTE:")
    
    return response.strip()

def generate_conversational_fallback_response(equipment_type: str, issue_type: str, message: str, user_role: str = "technician") -> str:
    """Generate conversational, coworker-style response"""
    
    # Get role-specific tone
    role_intros = {
        "technician": "Hey there! Here's what I'm thinking about this issue:",
        "manager": "Good question! Let me break this down from an operational perspective:",
        "scheduler": "Alright, here's what we're looking at for planning purposes:",
        "supervisor": "Let me give you the rundown on this situation:",
        "parts": "Hey! Here's what I know about the parts and supplies side:"
    }
    
    intro = role_intros.get(user_role, "Hey! Here's my take on this:")
    
    # Conversational responses based on equipment and issue
    if "conveyor" in equipment_type.lower() and "vibrat" in issue_type.lower():
        if user_role == "manager":
            return f"""{intro}
            
So we've got a vibrating conveyor - this could be anything from a loose belt to misalignment. Here's what I'd suggest:

**Time estimate**: 2-6 hours depending on what we find
**Cost**: Could be as simple as $50 for belt adjustment, or $500+ if we need new bearings
**Safety**: We'll need to lock out the conveyor first - standard LOTO procedures

**Plan of attack**:
1. Quick visual check (30 mins) - look for obvious stuff like loose bolts
2. Vibration measurement (1 hour) - get some actual readings
3. Belt tension check (30 mins) - super common cause
4. If those don't solve it, we might need alignment work (3-4 hours)

**Business impact**: If we catch this early, it's a quick fix. If we let it go, that conveyor could be down for days and cost us way more.

Need me to get this scheduled with the team?"""

        elif user_role == "scheduler":
            return f"""{intro}
            
Conveyor vibration job - here's what you need to know for scheduling:

**Window needed**: 4-6 hour block (to be safe)
**Best time**: During next scheduled maintenance window or low production period
**Crew**: 1-2 techs (2 if we need alignment work)
**Dependencies**: 
- Need lockout coordinator available
- Production needs 2-hour notice minimum
- If we need parts, add 1-2 days lead time

**Tools required**: Vibration meter, basic hand tools, possibly alignment equipment
**Workspace**: Need clear access around motor and drive end

Let me know what maintenance windows we have coming up and I can give you a better timeline!"""

        else:  # technician or default
            return f"""{intro}
            
Vibrating conveyor, huh? Been there! Let me walk you through what I'd check:

**First things first** - lock it out obviously. Safety first!

**Quick checks** (might get lucky):
- Visual inspection - any loose bolts, worn belts, obvious stuff?
- Belt tension - push on it, should deflect about 1/2 inch with firm pressure
- Listen to the bearings - any grinding or squealing?

**If that doesn't solve it**:
- Break out the vibration meter and get some readings
- Check alignment - might need the laser alignment tool
- Look at the motor mounts and foundation bolts

**Most likely culprits** in my experience:
1. Loose or worn belt (super common)
2. Misalignment between motor and driven pulley
3. Worn bearings (you'll hear them)
4. Loose mounting bolts

Usually takes a couple hours max unless we find something bigger. Got the vibration meter handy, or need me to grab it from the tool room?

What kind of vibration are we talking about - is it constant or does it come and go?"""

    elif "motor" in equipment_type.lower() and any(word in issue_type.lower() for word in ["overheat", "hot", "temperature"]):
        if user_role == "manager":
            return f"""{intro}
            
Motor overheating issue - this one's important to address quickly. Here's the business side:

**Urgency**: Medium-high. Can lead to motor failure if we don't fix it soon
**Estimated cost**: $200-2000 depending on root cause (new motor could be $3000+)
**Downtime**: 2-8 hours for most fixes, 1-2 days if we need a new motor
**Safety**: Electrical work involved - need qualified electrician

**Common causes & costs**:
- Dirty motor (1 hour, $0) - just cleaning
- Bad ventilation (2-3 hours, $100-300) - fan or ductwork
- Electrical issues (4-6 hours, $300-800) - connections, power quality
- Failed bearings (6-8 hours, $400-1200) - parts and labor

**Risk**: If this motor fails completely, we're looking at emergency replacement costs and potential production losses.

I'd recommend we get someone on this today. Want me to coordinate with maintenance?"""

        else:  # technician or default  
            return f"""{intro}
            
Motor running hot? That's not good - let's figure out what's going on before it cooks itself.

**Safety first** - if it's really hot, shut it down and let it cool before working on it.

**Quick checks I'd do**:
- Feel around (carefully!) - is the whole motor hot or just certain spots?
- Check the ventilation - fan running? Air flow clear?
- Look at the amp draw - is it pulling more current than nameplate?
- Check the connections - any loose or corroded terminals?

**Common causes**:
1. **Dirty motor** - dust and debris blocking airflow (super common)
2. **Overloaded** - check if it's working harder than it should
3. **Bad bearings** - they'll get hot and make the whole motor work harder
4. **Electrical problems** - voltage issues, bad connections, phase imbalance
5. **Poor ventilation** - blocked air intake, bad fan

**What I'd start with**:
- Blow it out with compressed air (might solve it right there)
- Check the nameplate amps vs actual draw
- Make sure the fan is spinning and moving air

Most of the time it's something simple like dirt buildup. How hot are we talking - too hot to touch, or just warmer than usual?"""

    # Generic conversational response
    else:
        equipment_name = equipment_type.replace("_", " ").title()
        issue_name = issue_type.replace("_", " ").lower()
        
        return f"""{intro}
        
So we've got a {equipment_name} with a {issue_name} - let me help you think through this.

**First step**: Safety check - make sure it's safe to work on and properly locked out if needed.

**What I'd look at**:
- Visual inspection - sometimes the problem is obvious
- Check the basics - power, connections, mechanical condition
- Look at any recent changes - what was working before that isn't now?

**Questions that might help**:
- When did this start happening?
- Is it getting worse or staying the same?
- Any unusual noises, smells, or other symptoms?
- Has anyone worked on this recently?

Without seeing it myself, I'd say start with the simple stuff - loose connections, worn parts, things that get overlooked in daily ops.

What specific symptoms are you seeing? That might help me point you in the right direction.

And hey, don't hesitate to grab another set of eyes if you need them - sometimes a fresh perspective spots what we miss!"""

# Keep the old function for backward compatibility but rename it
def generate_technical_fallback_response(equipment_type: str, issue_type: str, message: str) -> str:
    """Generate technical manual-style response (old version)"""
    
    # Conveyor vibration - Expert response with specific measurements
    if "conveyor" in equipment_type.lower() and "vibrat" in issue_type.lower():
        return """⚠️ SAFETY PROTOCOL: Implement lockout/tagout per 29 CFR 1910.147. Verify zero energy state with digital multimeter.

🔧 CONVEYOR VIBRATION ANALYSIS - Level III Diagnostic Protocol:

IMMEDIATE ASSESSMENT:
1. Record vibration using accelerometer at motor DE/NDE bearings
   - Normal: <4.5 mm/s RMS (0.18 in/sec)  
   - Caution: 4.5-11 mm/s RMS (0.18-0.43 in/sec)
   - Danger: >11 mm/s RMS (>0.43 in/sec)

2. Belt tension measurement with Sonic Tension Meter
   - Target frequency: 60-90 Hz depending on belt width
   - Deflection method: Force = (Span × Width × 0.3) / 64

3. Alignment verification using Dial Indicators  
   - Parallel offset: ±0.002" per inch of span
   - Angular misalignment: ±0.0005" per inch of diameter

DIAGNOSTIC MEASUREMENTS:
• Vibration spectrum analysis (10-1000 Hz range)
  - 1X RPM = imbalance (check coupling/pulley balance)
  - 2X RPM = misalignment (check motor/reducer coupling)
  - Belt frequency = belt defects (replace belt)
  - High frequency = bearing issues (order SKF or Timken analysis)

• Motor electrical analysis:
  - Voltage imbalance <2% between phases
  - Current signature analysis for rotor bar defects
  - Power factor >0.85 at rated load

REPAIR PROCEDURES:
1. Belt replacement: Use Gates PowerGrip HTD or equivalent
   - Installation tension: 5-7 deflection force using Burroughs BT-33-73F gauge
   - Run-in procedure: 2 hours at 75% load, retension

2. Bearing replacement (if vibration >7 mm/s RMS):
   - Use induction heater (SKF TIH 030M) for installation
   - Apply Mobil SHC 626 synthetic grease, 30-50% cavity fill
   - Torque housing bolts to 85 ft-lbs in star pattern

3. Motor realignment:
   - Rough alignment: ±0.010" indicators
   - Precision alignment: ±0.002" parallel, ±0.0005" angular
   - Use Rotalign Ultra iS laser system for accuracy
   - Final bolt torque: M16 bolts to 150 N⋅m (111 ft-lbs)

🔍 REQUIRED EQUIPMENT:
- Fluke 810 vibration tester or equivalent
- Pruftechnik Rotalign laser alignment system  
- Sonic tension meter (Gates 91132)
- Torque wrench (0-200 ft-lbs range)
- Dial indicators (0.0001" resolution)

📊 ACCEPTANCE CRITERIA:
- Overall vibration <2.5 mm/s RMS after repair
- Belt tension within ±5% of specification
- Alignment within ±0.001" final tolerance
- Motor current balanced within 3% between phases

⏱️ ESTIMATED DURATION: 6-8 hours including alignment verification
💰 COST IMPACT: Preventive repair vs. emergency replacement saves 75% in total cost

FOLLOW-UP: Schedule vibration monitoring every 30 days for trending analysis."""

    # Motor overheating - Expert electrical/mechanical response
    elif "motor" in equipment_type.lower() and "overheat" in issue_type.lower():
        return """⚠️ ELECTRICAL SAFETY: Follow NFPA 70E Category 2 arc flash protection. Verify de-energized state with Fluke T6-1000 meter.

🔧 MOTOR OVERHEATING - Master Electrician Diagnostic Protocol:

THERMAL ANALYSIS:
1. Temperature measurement with FLIR E8-XT thermal camera:
   - Bearing temperature: Normal <70°C above ambient
   - Winding temperature: Class F insulation = 155°C max
   - Frame temperature: Should not exceed 80°C above 40°C ambient

2. Electrical diagnostics per IEEE 43-2013:
   - Insulation resistance: >1 megohm per kV + 1 minimum
   - Polarization index: >2.0 for motors >1 HP  
   - Surge comparison test: <5% deviation between windings

POWER QUALITY ANALYSIS:
• Voltage measurements at motor terminals:
  - Nominal ±5% per NEMA MG-1
  - Voltage imbalance: <2% maximum
  - Calculate: % Imbalance = (Max deviation from avg ÷ avg) × 100

• Current signature analysis:
  - Full load amps within nameplate ±5%
  - Current imbalance <5% between phases
  - Power factor >0.85 at 75-100% load

• Harmonic distortion measurement:
  - THD voltage <5% per IEEE 519
  - THD current <5% for motors <1000 HP

ROOT CAUSE MATRIX:
- High current + normal voltage = mechanical overload
  → Check driven equipment, coupling, belt tension
- Normal current + high temperature = cooling issue  
  → Clean cooling passages, verify fan rotation
- Voltage imbalance >3% = supply problem
  → Contact electrical utility, check connections
- Low insulation resistance = winding degradation
  → Plan motor rewinding or replacement

CORRECTIVE PROCEDURES:
1. Cooling system restoration:
   - Remove all guards and clean with compressed air
   - Verify fan rotation direction (CCW viewed from DE)
   - Check fan blade clearance: 3-6mm from shroud
   - Apply Mobil DTE Heavy Medium oil to fan bearings

2. Electrical connection maintenance:
   - Torque terminal lugs per UL 486A-486B standards:
     * #14-#10 AWG: 12 in-lbs
     * #8-#6 AWG: 25 in-lbs  
     * #4-#1 AWG: 50 in-lbs
   - Apply Burndy Penetrox A13 to aluminum connections

3. Mechanical load verification:
   - Measure operating amps vs. nameplate FLA
   - Check shaft runout: <0.002" TIR with dial indicator
   - Verify coupling alignment per ANSI/ASA S2.75
   - Bearing replacement if temperature >90°C

🔍 TEST EQUIPMENT REQUIRED:
- Fluke 438-II Power Quality Analyzer
- Megger MIT515 Insulation Tester  
- FLIR thermal imaging camera
- Calibrated torque wrench set
- Phase rotation tester

📊 PERFORMANCE VERIFICATION:
- Operating temperature <Class F limits (155°C)
- Current draw within ±3% of calculated load
- Insulation resistance >5 megohms minimum
- Vibration <4.5 mm/s RMS overall
- Power factor >0.87 at operating load

⏱️ REPAIR TIMELINE: 4-12 hours depending on findings
🔧 PARTS TYPICALLY NEEDED: Bearings, fan, thermal compound, connection hardware

CRITICAL SUCCESS FACTOR: Address root cause, not just symptoms - prevents repeat failures within 6 months."""

    # Generic expert response for other equipment types
    else:
        return f"""⚠️ SAFETY COMPLIANCE: Follow OSHA 1910.147 lockout/tagout and facility-specific safety procedures for {equipment_type}.

🔧 {equipment_type.upper()} {issue_type.upper()} - Expert Diagnostic Protocol:

SYSTEMATIC ASSESSMENT:
1. Document baseline conditions using calibrated instruments
2. Review maintenance history and recent operational changes  
3. Perform comprehensive visual inspection per OEM guidelines
4. Collect quantitative data using appropriate measurement tools

TECHNICAL MEASUREMENTS:
• Operational parameters compared to design specifications
• Performance trending analysis using historical data
• Condition monitoring readings (vibration, temperature, pressure)
• Electrical parameters if motorized equipment involved

DIAGNOSTIC METHODOLOGY:
- Fault tree analysis to isolate root cause systematically
- Comparison testing against known good reference unit
- Component-level testing using manufacturer procedures
- Statistical process control for intermittent problems

INDUSTRY STANDARD PROCEDURES:
• Follow OEM service manual specifications exactly
• Apply relevant ISO, API, ANSI, or NEMA standards
• Use certified test equipment with current calibration
• Document all findings and corrective actions taken

REPAIR PROTOCOL:
1. Source OEM or approved equivalent replacement parts
2. Follow proper installation torque sequences and values
3. Perform comprehensive pre-startup inspection checklist
4. Conduct operational testing at graduated load levels
5. Establish new baseline readings for future comparison

🔍 MEASUREMENT TOOLS: Digital multimeter, precision torque tools, alignment equipment
⏱️ SERVICE TIME: Varies based on complexity and parts availability
📋 DOCUMENTATION: Complete work order with all findings and corrective actions
🔄 FOLLOW-UP: Schedule condition monitoring per PM program requirements

PROFESSIONAL STANDARD: Repair quality that ensures reliable operation for full service life cycle."""

@ai_router.get("/")
async def ai_root():
    """Redirect to AI dashboard"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/ai/dashboard", status_code=302)

@ai_router.get("/dashboard", response_class=HTMLResponse)
async def ai_dashboard():
    """Enhanced AI dashboard with improved intelligence"""
    from fastapi.templating import Jinja2Templates
    import os
    
    # Use optimized template system
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    templates = Jinja2Templates(directory=template_dir)
    
    # Prepare data for optimized template
    stats = {
        "active_workorders": len(predictions_cache),
        "total_assets": len(voice_commands_db), 
        "parts_in_stock": len([cmd for cmd in voice_commands_db if 'create' in cmd.get('text', '').lower()]),
        "system_health": 96
    }
    
    recent_workorders = []
    for i, cmd in enumerate(voice_commands_db[-5:]):
        recent_workorders.append({
            "id": f"AI-{i+1:03d}",
            "title": f"AI Command: {cmd.get('text', 'Unknown')[:20]}...",
            "asset_name": "AI System",
            "technician": cmd.get('user_id', 'System'),
            "status": "Processed",
            "priority": "Medium"
        })
    
    top_assets = [
        {"name": "AI Processing Engine", "health_score": 98, "status": "Operational", "last_maintenance": "Real-time"},
        {"name": "Voice Recognition", "health_score": 94, "status": "Operational", "last_maintenance": "Active"},
        {"name": "Predictive Analytics", "health_score": 91, "status": "Operational", "last_maintenance": "Continuous"},
        {"name": "OCR Processing", "health_score": 89, "status": "Operational", "last_maintenance": "On-demand"},
        {"name": "LLaMA Integration", "health_score": 87, "status": "Operational", "last_maintenance": "Connected"}
    ]
    
    # Mock request for template
    class MockRequest:
        def __init__(self):
            self.url = type('obj', (object,), {'path': '/cmms/ai/dashboard'})()
            
        def get(self, key, default=None):
            return default
    
    return templates.TemplateResponse("dashboard-rich.html", {
        "request": MockRequest(),
        "module_name": "AI Command Center",
        "stats": stats,
        "recent_workorders": recent_workorders,
        "top_assets": top_assets,
        "ai_stats": {"predictions_today": 47, "automation_rate": 92, "response_time": 1.2},
        "ai_activities": [
            {"icon": "🤖", "title": "AI Model Active", "description": "Processing maintenance requests", "timestamp": "14:30", "confidence": 98},
            {"icon": "🎤", "title": "Voice Command", "description": "Voice recognition active", "timestamp": "14:25", "confidence": 95},
            {"icon": "🔮", "title": "Prediction", "description": "Equipment failure analysis", "timestamp": "14:20", "confidence": 87}
        ],
        "performance": {"dashboard_load": 1.8, "ai_response": 1.2, "health_check": 6.8},
        "metrics": {"uptime": 99.2, "api_success": 99.5, "satisfaction": 4.9, "cost_savings": 15000},
        "recent_activities": [
            {"timestamp": "14:25", "icon": "🤖", "type": "AI Process", "description": "Smart maintenance recommendation generated", "user": "AI", "module": "Command Center", "status": "Success"}
        ]
    })

# Legacy return for reference
def ai_dashboard_legacy():
    nav_html = get_navigation_html("ai")
    nav_styles = get_navigation_styles()
    base_styles = get_base_styles()
    
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix AI - Enhanced Intelligence</title>
        <style>
            {base_styles}
            {nav_styles}
            
            .ai-container {{
                max-width: 1000px;
                margin: 2rem auto;
                padding: 0 1rem;
            }}
            
            .intelligence-level {{
                position: fixed;
                top: 100px;
                right: 30px;
                background: linear-gradient(135deg, #11998e, #38ef7d);
                color: white;
                padding: 10px 18px;
                border-radius: 25px;
                font-size: 0.9rem;
                font-weight: bold;
                z-index: 999;
                box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
                animation: pulse 2s infinite;
            }}
            
            .chat-container {{
                background: rgba(255,255,255,0.15);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                height: 600px;
                display: flex;
                flex-direction: column;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            }}
            
            .ai-features {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
                margin-bottom: 2rem;
            }}
            
            .feature-card {{
                background: rgba(17, 153, 142, 0.2);
                padding: 1rem;
                border-radius: 12px;
                border: 1px solid rgba(17, 153, 142, 0.3);
                text-align: center;
            }}
            
            .feature-card h4 {{
                color: #11998e;
                margin-bottom: 0.5rem;
            }}
            
            .chat-messages {{
                flex: 1;
                overflow-y: auto;
                padding: 1rem;
                background: rgba(0,0,0,0.2);
                border-radius: 12px;
                margin-bottom: 1rem;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            
            .message {{
                margin-bottom: 1rem;
                padding: 1rem;
                border-radius: 12px;
                animation: fadeIn 0.3s ease;
            }}
            
            .user-message {{
                background: linear-gradient(135deg, rgba(56, 239, 125, 0.3), rgba(56, 239, 125, 0.1));
                margin-left: 2rem;
                text-align: right;
                border-left: 3px solid #38ef7d;
            }}
            
            .ai-message {{
                background: linear-gradient(135deg, rgba(17, 153, 142, 0.3), rgba(17, 153, 142, 0.1));
                margin-right: 2rem;
                border-left: 3px solid #11998e;
            }}
            
            .chat-input {{
                display: flex;
                gap: 1rem;
                align-items: center;
            }}
            
            .chat-input input {{
                flex: 1;
                padding: 1rem;
                border: none;
                border-radius: 12px;
                background: rgba(255,255,255,0.2);
                color: white;
                font-size: 1rem;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            
            .chat-input input::placeholder {{
                color: rgba(255,255,255,0.7);
            }}
            
            .chat-input input:focus {{
                outline: none;
                border-color: #11998e;
                box-shadow: 0 0 0 2px rgba(17, 153, 142, 0.2);
            }}
            
            .send-btn {{
                padding: 1rem 2rem;
                background: linear-gradient(135deg, #11998e, #38ef7d);
                color: white;
                border: none;
                border-radius: 12px;
                cursor: pointer;
                font-weight: bold;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(17, 153, 142, 0.3);
            }}
            
            .send-btn:hover {{
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
            }}
            
            .send-btn:disabled {{
                background: rgba(255,255,255,0.3);
                color: rgba(255,255,255,0.5);
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }}
            
            @keyframes fadeIn {{
                from {{ opacity: 0; transform: translateY(10px); }}
                to {{ opacity: 1; transform: translateY(0); }}
            }}
            
            @keyframes pulse {{
                0%, 100% {{ opacity: 1; }}
                50% {{ opacity: 0.8; }}
            }}
            
            .typing {{
                font-style: italic;
                color: rgba(255,255,255,0.8);
            }}
            
            .technical-note {{
                background: rgba(17, 153, 142, 0.1);
                border-left: 4px solid #11998e;
                padding: 0.5rem;
                margin: 0.5rem 0;
                border-radius: 4px;
            }}
        </style>
    </head>
    <body>
        {nav_html}
        
        <div class="intelligence-level">🧠 Expert AI Online</div>
        
        <div class="ai-container">
            <div class="header">
                <h1>🔧 ChatterFix Expert AI</h1>
                <p>Master-level maintenance intelligence with 30+ years of industrial experience</p>
            </div>
            
            <div class="ai-features">
                <div class="feature-card">
                    <h4>🎯 Contextual Analysis</h4>
                    <p>Automatic equipment and issue type detection</p>
                </div>
                <div class="feature-card">
                    <h4>📐 Precise Specifications</h4>
                    <p>Exact measurements, torque specs, and tolerances</p>
                </div>
                <div class="feature-card">
                    <h4>⚠️ Safety First</h4>
                    <p>OSHA-compliant procedures and proper PPE guidance</p>
                </div>
                <div class="feature-card">
                    <h4>🔬 Root Cause Analysis</h4>
                    <p>Technical reasoning and failure mode analysis</p>
                </div>
            </div>
            
            <div class="chat-container">
                <div class="chat-messages" id="chatMessages">
                    <div class="message ai-message">
                        <strong>🔧 ChatterFix Expert AI:</strong> I'm your master maintenance technician AI with advanced diagnostic capabilities. I provide specific, actionable technical advice with:
                        <br><br>
                        <div class="technical-note">
                        • <strong>Safety Protocols:</strong> OSHA-compliant lockout/tagout procedures<br>
                        • <strong>Precision Specs:</strong> Exact torque values, tolerances, and measurements<br>  
                        • <strong>Expert Tools:</strong> Specific equipment models and part numbers<br>
                        • <strong>Root Cause:</strong> Technical analysis of failure modes and physics<br>
                        • <strong>Prevention:</strong> Maintenance intervals and condition monitoring
                        </div>
                        <br>
                        Ask me about conveyor vibration, motor overheating, pump cavitation, bearing failures, alignment issues, or any maintenance challenge!
                    </div>
                </div>
                
                <div class="chat-input">
                    <input type="text" id="messageInput" placeholder="Describe your equipment issue (e.g., 'conveyor belt vibrating excessively', 'motor running hot')..." maxlength="500">
                    <button class="send-btn" id="sendBtn" onclick="sendMessage()">Analyze</button>
                </div>
            </div>
        </div>
        
        <script>
            let isLoading = false;
            let messageCount = 0;
            
            document.addEventListener('DOMContentLoaded', function() {{
                document.getElementById('messageInput').focus();
            }});
            
            document.getElementById('messageInput').addEventListener('keypress', function(event) {{
                if (event.key === 'Enter' && !isLoading) {{
                    sendMessage();
                }}
            }});
            
            async function sendMessage() {{
                const messageInput = document.getElementById('messageInput');
                const sendBtn = document.getElementById('sendBtn');
                const chatMessages = document.getElementById('chatMessages');
                const message = messageInput.value.trim();
                
                if (!message || isLoading) return;
                
                messageCount++;
                
                // Add user message
                const userDiv = document.createElement('div');
                userDiv.className = 'message user-message';
                userDiv.innerHTML = `<strong>You:</strong> ${{message}}`;
                chatMessages.appendChild(userDiv);
                
                // Clear input and set loading
                messageInput.value = '';
                isLoading = true;
                sendBtn.disabled = true;
                sendBtn.textContent = 'Analyzing...';
                
                // Add AI typing indicator
                const typingDiv = document.createElement('div');
                typingDiv.className = 'message ai-message typing';
                typingDiv.innerHTML = '<strong>🔧 Expert AI:</strong> <em>Analyzing equipment condition and consulting technical specifications...</em>';
                chatMessages.appendChild(typingDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
                
                try {{
                    const response = await fetch('/cmms/ai/chat', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            message: message,
                            context: `expert_diagnosis_${{messageCount}}`,
                            user_type: 'technician'
                        }})
                    }});
                    
                    chatMessages.removeChild(typingDiv);
                    
                    if (response.ok) {{
                        const data = await response.json();
                        const aiDiv = document.createElement('div');
                        aiDiv.className = 'message ai-message';
                        
                        // Format technical response with proper styling
                        let formattedResponse = data.response;
                        formattedResponse = formattedResponse.replace(/🔧 TECHNICAL NOTE:/g, '<div class="technical-note"><strong>🔧 TECHNICAL NOTE:</strong>');
                        formattedResponse = formattedResponse.replace(/⚠️ WARNING:/g, '<div class="technical-note"><strong>⚠️ WARNING:</strong>');
                        formattedResponse = formattedResponse.replace(/📋 NOTE:/g, '<div class="technical-note"><strong>📋 NOTE:</strong>');
                        
                        // Close technical note divs
                        if (formattedResponse.includes('<div class="technical-note">')) {{
                            formattedResponse = formattedResponse.replace(/\\n\\n/g, '</div>\\n\\n');
                        }}
                        
                        aiDiv.innerHTML = `<strong>🔧 ChatterFix Expert AI:</strong><br><br>${{formattedResponse}}`;
                        chatMessages.appendChild(aiDiv);
                    }} else {{
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'message ai-message';
                        errorDiv.innerHTML = '<strong>🔧 Expert AI:</strong> <em>Technical systems are experiencing issues. Please try your diagnostic request again.</em>';
                        chatMessages.appendChild(errorDiv);
                    }}
                }} catch (error) {{
                    if (typingDiv.parentNode) chatMessages.removeChild(typingDiv);
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'message ai-message';
                    errorDiv.innerHTML = '<strong>🔧 Expert AI:</strong> <em>Connection error detected. Please verify network connectivity and retry.</em>';
                    chatMessages.appendChild(errorDiv);
                }} finally {{
                    isLoading = false;
                    sendBtn.disabled = false;
                    sendBtn.textContent = 'Analyze';
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                    messageInput.focus();
                }}
            }}
            
            {get_navigation_javascript()}
        </script>
    </body>
    </html>
    """

@ai_router.post("/chat")
async def ai_chat(request: AIRequest) -> Dict:
    """Enhanced AI chat endpoint with expert maintenance responses and autonomous capabilities"""
    start_time = datetime.now()
    
    # Check if this is an autonomous request
    autonomous_keywords = ["create script", "generate feature", "enhance platform", "autonomous task", "self improve"]
    is_autonomous = any(keyword in request.message.lower() for keyword in autonomous_keywords)
    
    if is_autonomous:
        # Handle autonomous AI requests
        from ai_autonomous import autonomous_ai
        
        if "create script" in request.message.lower():
            # Extract requirement from message
            requirement = request.message.replace("create script", "").replace("for", "").strip()
            result = await autonomous_ai.create_platform_script(requirement)
            response_text = f"🤖 AUTONOMOUS AI SCRIPT GENERATED\n\n{result.get('content', 'Script generation failed')}"
            
        elif "generate feature" in request.message.lower():
            feature_desc = request.message.replace("generate feature", "").replace("for", "").strip()
            result = await autonomous_ai.generate_platform_feature(feature_desc)
            response_text = f"🤖 AUTONOMOUS AI FEATURE CREATED\n\n{result.get('code', 'Feature generation failed')}"
            
        elif "enhance platform" in request.message.lower():
            enhancement = request.message.replace("enhance platform", "").strip()
            result = await autonomous_ai.enhance_existing_feature("platform", enhancement)
            response_text = f"🤖 AUTONOMOUS AI PLATFORM ENHANCEMENT\n\n{result.get('improvements', 'Enhancement failed')}"
            
        elif "autonomous task" in request.message.lower():
            objective = request.message.replace("autonomous task", "").replace("create", "").strip()
            result = await autonomous_ai.create_autonomous_task(objective)
            response_text = f"🤖 AUTONOMOUS TASK CREATED\n\n{result.get('action_plan', 'Task creation failed')}"
            
        elif "self improve" in request.message.lower():
            result = await autonomous_ai.self_analyze_and_improve()
            response_text = f"🤖 AUTONOMOUS AI SELF-ANALYSIS\n\n{result.get('recommendations', 'Self-analysis failed')}"
        
        else:
            response_text = await query_llama(request.message, request.context, getattr(request, 'user_id', 'unknown'))
    else:
        # Normal AI chat
        response_text = await query_llama(request.message, request.context, getattr(request, 'user_id', 'unknown'))
    
    # Calculate response time
    response_time = int((datetime.now() - start_time).total_seconds() * 1000)
    
    return {
        "response": response_text,
        "model_used": LLAMA_MODEL + " (Enhanced Expert Mode)" + (" + Autonomous AI" if is_autonomous else ""),
        "confidence": 0.98,
        "user_type": request.user_type,
        "response_time": response_time,
        "timestamp": datetime.now().isoformat(),
        "intelligence_level": "Expert Master Technician" + (" with Autonomous Capabilities" if is_autonomous else ""),
        "features": ["Contextual Analysis", "Safety Protocols", "Precision Specs", "Root Cause Analysis"] + (["Autonomous Script Generation", "Feature Creation", "Self Enhancement"] if is_autonomous else []),
        "autonomous_mode": is_autonomous
    }

@ai_router.post("/autonomous/create-script")
async def create_autonomous_script(request: Dict[str, str]):
    """Create platform scripts autonomously"""
    try:
        from ai_autonomous import create_script
        
        requirement = request.get("requirement", "")
        script_type = request.get("script_type", "maintenance")
        
        if not requirement:
            raise HTTPException(status_code=400, detail="Requirement is required")
        
        result = await create_script(requirement, script_type)
        
        return {
            "success": True,
            "script_id": result.get("script_id"),
            "content": result.get("content"),
            "metadata": result.get("metadata"),
            "deployment_ready": result.get("deployment_ready", False)
        }
        
    except Exception as e:
        logger.error(f"Autonomous script creation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.post("/autonomous/generate-feature")
async def generate_autonomous_feature(request: Dict[str, str]):
    """Generate new platform features autonomously"""
    try:
        from ai_autonomous import generate_feature
        
        description = request.get("description", "")
        
        if not description:
            raise HTTPException(status_code=400, detail="Feature description is required")
        
        result = await generate_feature(description)
        
        return {
            "success": True,
            "feature_id": result.get("feature_id"),
            "code": result.get("code"),
            "integration_ready": result.get("integration_ready", False),
            "testing_required": result.get("testing_required", True)
        }
        
    except Exception as e:
        logger.error(f"Autonomous feature generation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.post("/autonomous/enhance-feature")
async def enhance_autonomous_feature(request: Dict[str, str]):
    """Enhance existing platform features autonomously"""
    try:
        from ai_autonomous import enhance_feature
        
        feature_name = request.get("feature_name", "")
        enhancement_type = request.get("enhancement_type", "performance")
        
        if not feature_name:
            raise HTTPException(status_code=400, detail="Feature name is required")
        
        result = await enhance_feature(feature_name, enhancement_type)
        
        return {
            "success": True,
            "feature_name": result.get("feature_name"),
            "enhancements": result.get("improvements"),
            "priority": result.get("priority"),
            "confidence": result.get("confidence")
        }
        
    except Exception as e:
        logger.error(f"Autonomous feature enhancement error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.post("/autonomous/create-task")
async def create_autonomous_task(request: Dict[str, str]):
    """Create and execute autonomous tasks"""
    try:
        from ai_autonomous import create_task
        
        objective = request.get("objective", "")
        
        if not objective:
            raise HTTPException(status_code=400, detail="Task objective is required")
        
        result = await create_task(objective)
        
        return {
            "success": True,
            "task_id": result.get("task_id"),
            "objective": result.get("objective"),
            "action_plan": result.get("action_plan"),
            "status": result.get("status"),
            "execution_result": result.get("execution_result")
        }
        
    except Exception as e:
        logger.error(f"Autonomous task creation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.post("/autonomous/self-improve")
async def ai_self_improve():
    """Trigger AI self-analysis and improvement"""
    try:
        from ai_autonomous import self_improve
        
        result = await self_improve()
        
        return {
            "success": True,
            "analysis_date": result.get("analysis_date"),
            "recommendations": result.get("recommendations"),
            "improvement_areas": result.get("improvement_areas"),
            "priority_level": result.get("priority_level"),
            "confidence": result.get("confidence")
        }
        
    except Exception as e:
        logger.error(f"AI self-improvement error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.get("/autonomous/status")
async def autonomous_status():
    """Get autonomous AI system status"""
    try:
        from ai_autonomous import autonomous_ai
        
        status = autonomous_ai.get_status()
        
        return {
            "success": True,
            "autonomous_ai": status,
            "capabilities": [
                "Script Generation",
                "Feature Creation", 
                "Platform Enhancement",
                "Task Automation",
                "Self-Improvement",
                "Code Optimization"
            ]
        }
        
    except Exception as e:
        logger.error(f"Autonomous status error: {e}")
        return {
            "success": False,
            "error": str(e),
            "autonomous_available": False
        }

@ai_router.get("/models")
async def available_models():
    """Get all available AI models and their capabilities"""
    try:
        from ai_orchestrator import get_ai_status
        
        status = await get_ai_status()
        
        return {
            "success": True,
            "system_status": status["system_status"],
            "core_ai": status["core_ai"],
            "available_models": status["available_models"], 
            "super_intelligence_models": status["super_intelligence_models"],
            "collaborative_mode": status["collaborative_mode"],
            "models": status["models"],
            "capabilities": status["capabilities"],
            "cost_optimization": status["cost_optimization"],
            "response_quality": status["response_quality"]
        }
        
    except Exception as e:
        logger.error(f"Models status error: {e}")
        return {
            "success": False,
            "error": str(e),
            "fallback_available": True
        }

@ai_router.post("/intelligent-chat")
async def intelligent_ai_chat(request: Dict[str, Any]):
    """Advanced multi-model AI chat with intelligent model selection"""
    try:
        from ai_orchestrator import intelligent_chat
        
        message = request.get("message", "")
        context = request.get("context", "general")
        complexity = request.get("complexity", "medium")
        
        if not message:
            raise HTTPException(status_code=400, detail="Message is required")
        
        start_time = datetime.now()
        response = await intelligent_chat(message, context, complexity)
        response_time = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return {
            "success": True,
            "response": response.get("response", "No response generated"),
            "model_used": response.get("model_used", "Unknown"),
            "model_type": response.get("model_type", "unknown"),
            "collaborative": response.get("collaborative", False),
            "confidence": response.get("confidence", 0.8),
            "response_time_ms": response_time,
            "cost_estimate": response.get("cost_estimate", 0.0),
            "timestamp": datetime.now().isoformat(),
            "features": ["Multi-Model Intelligence", "Intelligent Selection", "Cost Optimization"]
        }
        
    except Exception as e:
        logger.error(f"Intelligent chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.post("/collaborative-analysis")
async def collaborative_analysis(request: Dict[str, Any]):
    """Force collaborative analysis using multiple AI models"""
    try:
        from ai_orchestrator import ai_orchestrator
        
        message = request.get("message", "")
        context = request.get("context", "diagnostic")
        
        if not message:
            raise HTTPException(status_code=400, detail="Message is required")
        
        # Force high complexity to trigger collaborative mode
        analysis = {
            "complexity": "high",
            "task_type": "diagnostic", 
            "requires_reasoning": True,
            "estimated_tokens": len(message.split()) * 2
        }
        
        # Get available super models for collaboration
        available_supers = [name for name, model in ai_orchestrator.models.items() 
                          if model.available and model.type.value == "super"]
        
        if len(available_supers) < 2:
            # Add core model if not enough super models
            available_supers.append("llama3.2:3b")
            
        selected_models = available_supers[:3]  # Use up to 3 models
        
        start_time = datetime.now()
        response = await ai_orchestrator._generate_collaborative_response(
            selected_models, message, context, analysis
        )
        response_time = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return {
            "success": True,
            "response": response.get("response", "Collaborative analysis failed"),
            "models_used": response.get("model_used", "Unknown"),
            "model_count": len(selected_models),
            "individual_responses": response.get("individual_responses", []),
            "synthesis_method": response.get("synthesis_method", "intelligent_merge"),
            "confidence": response.get("confidence", 0.95),
            "response_time_ms": response_time,
            "cost_estimate": response.get("cost_estimate", 0.0),
            "collaborative": True,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Collaborative analysis error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_router.get("/health")
async def ai_health():
    """Enhanced AI system health check with multi-model orchestrator"""
    try:
        from ai_orchestrator import get_ai_status
        from ai_autonomous import autonomous_ai
        
        orchestrator_status = await get_ai_status()
        autonomous_status = autonomous_ai.get_status()
        
        return {
            "status": "healthy" if orchestrator_status["available_models"] > 0 else "degraded",
            "intelligence_level": "multi-model" if orchestrator_status["super_intelligence_models"] > 0 else "core",
            "orchestrator": True,
            "core_ai": orchestrator_status["core_ai"],
            "available_models": orchestrator_status["available_models"],
            "super_models": orchestrator_status["super_intelligence_models"],
            "collaborative_mode": orchestrator_status["collaborative_mode"],
            "autonomous_capabilities": autonomous_status["capabilities"],
            "autonomous_mode": autonomous_status["autonomous_mode"],
            "response_quality": orchestrator_status["response_quality"],
            "features": orchestrator_status["capabilities"],
            "cost_optimization": orchestrator_status["cost_optimization"],
            "models": orchestrator_status["models"]
        }
        
    except Exception as e:
        logger.error(f"AI health check error: {e}")
        return {
            "status": "degraded",
            "error": str(e),
            "orchestrator": False,
            "fallback_available": True
        }