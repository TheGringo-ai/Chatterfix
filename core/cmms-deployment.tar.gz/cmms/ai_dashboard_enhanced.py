#!/usr/bin/env python3
"""
ChatterFix AI Dashboard Enhanced
Revolutionary AI Command Center with comprehensive analytics and controls
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from typing import Dict, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

ai_dashboard_router = APIRouter(prefix="/ai-dashboard", tags=["ai-dashboard"])

@ai_dashboard_router.get("/command-center", response_class=HTMLResponse)
async def ai_command_center():
    """Revolutionary AI Command Center - The most advanced CMMS AI dashboard"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix AI Command Center</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: radial-gradient(circle at 20% 20%, #000428 0%, #004e92 100%);
                color: #ffffff;
                min-height: 100vh;
                overflow-x: hidden;
            }
            
            .command-header {
                background: linear-gradient(135deg, rgba(0, 255, 255, 0.1), rgba(102, 126, 234, 0.1));
                backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(0, 255, 255, 0.3);
                padding: 1rem 2rem;
                position: sticky;
                top: 0;
                z-index: 100;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .logo {
                display: flex;
                align-items: center;
                gap: 15px;
                font-size: 1.5rem;
                font-weight: bold;
            }
            
            .ai-status {
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 0.9rem;
            }
            
            .status-dot {
                width: 12px;
                height: 12px;
                background: #00ff88;
                border-radius: 50%;
                animation: pulse 2s infinite;
                box-shadow: 0 0 10px #00ff88;
            }
            
            @keyframes pulse {
                0%, 100% { opacity: 1; transform: scale(1); }
                50% { opacity: 0.7; transform: scale(1.1); }
            }
            
            .main-grid {
                display: grid;
                grid-template-columns: 350px 1fr 300px;
                gap: 20px;
                padding: 20px;
                max-width: 1800px;
                margin: 0 auto;
                min-height: calc(100vh - 80px);
            }
            
            .left-panel {
                display: flex;
                flex-direction: column;
                gap: 20px;
            }
            
            .center-panel {
                display: flex;
                flex-direction: column;
                gap: 20px;
            }
            
            .right-panel {
                display: flex;
                flex-direction: column;
                gap: 20px;
            }
            
            .panel-card {
                background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
                border: 1px solid rgba(0, 255, 255, 0.2);
                border-radius: 15px;
                padding: 20px;
                backdrop-filter: blur(20px);
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }
            
            .panel-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 3px;
                background: linear-gradient(90deg, #00ff88, #00d4ff, #7c3aed);
                border-radius: 15px 15px 0 0;
            }
            
            .panel-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 40px rgba(0, 255, 255, 0.2);
            }
            
            .panel-title {
                font-size: 1.2rem;
                font-weight: bold;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .chat-interface {
                background: rgba(0, 0, 0, 0.4);
                border-radius: 12px;
                height: 500px;
                display: flex;
                flex-direction: column;
                border: 1px solid rgba(0, 255, 255, 0.2);
            }
            
            .chat-header {
                background: linear-gradient(135deg, #00ff88, #00d4ff);
                color: #000;
                padding: 12px 18px;
                border-radius: 12px 12px 0 0;
                font-weight: bold;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .model-selector {
                background: rgba(0, 0, 0, 0.3);
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 8px;
                font-size: 0.8rem;
            }
            
            .chat-messages {
                flex: 1;
                padding: 15px;
                overflow-y: auto;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            
            .message {
                padding: 12px 16px;
                border-radius: 18px;
                max-width: 85%;
                animation: slideIn 0.3s ease;
            }
            
            .ai-message {
                background: linear-gradient(135deg, rgba(0, 255, 136, 0.2), rgba(0, 212, 255, 0.2));
                border: 1px solid rgba(0, 255, 136, 0.3);
                align-self: flex-start;
            }
            
            .user-message {
                background: linear-gradient(135deg, rgba(124, 58, 237, 0.2), rgba(102, 126, 234, 0.2));
                border: 1px solid rgba(124, 58, 237, 0.3);
                align-self: flex-end;
            }
            
            .chat-input-area {
                padding: 15px;
                border-top: 1px solid rgba(0, 255, 255, 0.2);
                display: flex;
                gap: 10px;
                align-items: center;
            }
            
            .chat-input {
                flex: 1;
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(0, 255, 255, 0.3);
                border-radius: 25px;
                padding: 12px 18px;
                color: white;
                outline: none;
            }
            
            .chat-input::placeholder {
                color: rgba(255, 255, 255, 0.5);
            }
            
            .send-btn {
                background: linear-gradient(135deg, #00ff88, #00d4ff);
                color: #000;
                border: none;
                border-radius: 50%;
                width: 45px;
                height: 45px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                font-size: 18px;
                transition: all 0.3s ease;
            }
            
            .send-btn:hover {
                transform: scale(1.1);
                box-shadow: 0 5px 15px rgba(0, 255, 136, 0.4);
            }
            
            .quick-actions {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-top: 15px;
            }
            
            .quick-btn {
                background: rgba(0, 255, 136, 0.1);
                border: 1px solid rgba(0, 255, 136, 0.3);
                color: white;
                padding: 8px 12px;
                border-radius: 20px;
                cursor: pointer;
                font-size: 0.85rem;
                transition: all 0.3s ease;
                text-align: center;
            }
            
            .quick-btn:hover {
                background: rgba(0, 255, 136, 0.2);
                transform: translateY(-2px);
            }
            
            .metrics-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .metric-card {
                background: rgba(0, 0, 0, 0.3);
                border-radius: 12px;
                padding: 15px;
                text-align: center;
                border: 1px solid rgba(0, 255, 136, 0.2);
                transition: all 0.3s ease;
            }
            
            .metric-card:hover {
                transform: scale(1.05);
                box-shadow: 0 8px 25px rgba(0, 255, 136, 0.2);
            }
            
            .metric-value {
                font-size: 2rem;
                font-weight: bold;
                color: #00ff88;
                margin-bottom: 5px;
            }
            
            .metric-label {
                font-size: 0.85rem;
                opacity: 0.8;
            }
            
            .ai-models-list {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            
            .model-status {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 15px;
                background: rgba(0, 0, 0, 0.2);
                border-radius: 10px;
                border-left: 3px solid;
            }
            
            .model-status.online { border-left-color: #00ff88; }
            .model-status.offline { border-left-color: #ff4444; }
            
            .model-name {
                font-weight: bold;
            }
            
            .model-latency {
                font-size: 0.8rem;
                opacity: 0.7;
            }
            
            .activity-log {
                max-height: 400px;
                overflow-y: auto;
            }
            
            .activity-item {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 10px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .activity-icon {
                width: 35px;
                height: 35px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 16px;
            }
            
            .activity-icon.success { background: rgba(0, 255, 136, 0.2); }
            .activity-icon.warning { background: rgba(255, 193, 7, 0.2); }
            .activity-icon.error { background: rgba(255, 68, 68, 0.2); }
            
            .activity-text {
                flex: 1;
                font-size: 0.9rem;
            }
            
            .activity-time {
                font-size: 0.75rem;
                opacity: 0.6;
            }
            
            .voice-controls {
                display: flex;
                gap: 10px;
                margin-top: 10px;
            }
            
            .voice-btn {
                flex: 1;
                background: linear-gradient(135deg, rgba(255, 68, 68, 0.2), rgba(255, 193, 7, 0.2));
                border: 1px solid rgba(255, 68, 68, 0.4);
                color: white;
                padding: 10px;
                border-radius: 10px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                transition: all 0.3s ease;
            }
            
            .voice-btn:hover {
                transform: scale(1.05);
                box-shadow: 0 5px 15px rgba(255, 68, 68, 0.3);
            }
            
            .voice-btn.recording {
                background: linear-gradient(135deg, #ff4444, #ff6b6b);
                animation: pulse 1s infinite;
            }
            
            @keyframes slideIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .neural-bg {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
                opacity: 0.1;
                background: 
                    radial-gradient(circle at 25% 25%, cyan 2px, transparent 2px),
                    radial-gradient(circle at 75% 75%, #00ff88 1px, transparent 1px);
                background-size: 100px 100px, 150px 150px;
                animation: neuralFlow 20s linear infinite;
            }
            
            @keyframes neuralFlow {
                0% { transform: translate(0, 0); }
                100% { transform: translate(-50px, -50px); }
            }
            
            @media (max-width: 1200px) {
                .main-grid {
                    grid-template-columns: 1fr;
                    padding: 15px;
                }
                
                .left-panel, .right-panel {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 15px;
                }
            }
        </style>
    </head>
    <body>
        <div class="neural-bg"></div>
        
        <header class="command-header">
            <div class="logo">
                <span style="font-size: 2rem;">🧠</span>
                ChatterFix AI Command Center
            </div>
            <div class="ai-status">
                <div class="status-dot"></div>
                <span>5 AI Models Online</span>
                <span>|</span>
                <span id="systemLoad">CPU: 23%</span>
                <span>|</span>
                <span>Response: &lt;50ms</span>
            </div>
        </header>
        
        <div class="main-grid">
            <!-- Left Panel - Chat & Controls -->
            <div class="left-panel">
                <div class="panel-card">
                    <div class="panel-title">
                        🤖 Multi-Model AI Chat
                    </div>
                    <div class="chat-interface">
                        <div class="chat-header">
                            <span>AI Assistant</span>
                            <select class="model-selector" id="modelSelector">
                                <option value="grok">Grok-2-1212</option>
                                <option value="openai">GPT-4</option>
                                <option value="llama">Llama 3.1</option>
                                <option value="groq">Groq</option>
                            </select>
                        </div>
                        <div class="chat-messages" id="chatMessages">
                            <div class="message ai-message">
                                🧠 Welcome to the AI Command Center! I'm your advanced CMMS assistant powered by multiple AI models.
                                <br><br>
                                I can help you with:
                                <br>• Equipment monitoring & diagnostics
                                <br>• Work order automation
                                <br>• Predictive maintenance
                                <br>• Voice commands & OCR
                                <br>• Real-time analytics
                                <br><br>
                                What would you like to explore?
                            </div>
                        </div>
                        <div class="chat-input-area">
                            <input type="text" class="chat-input" id="chatInput" placeholder="Ask me anything about your CMMS..." onkeypress="handleKeyPress(event)">
                            <button class="send-btn" onclick="sendMessage()">➤</button>
                        </div>
                    </div>
                    <div class="quick-actions">
                        <div class="quick-btn" onclick="quickAction('alerts')">🚨 Show Alerts</div>
                        <div class="quick-btn" onclick="quickAction('workorders')">📋 Work Orders</div>
                        <div class="quick-btn" onclick="quickAction('equipment')">⚙️ Equipment Status</div>
                        <div class="quick-btn" onclick="quickAction('maintenance')">🔧 PM Schedule</div>
                    </div>
                    <div class="voice-controls">
                        <button class="voice-btn" onclick="startVoiceCommand()">
                            🎤 Voice Command
                        </button>
                        <button class="voice-btn" onclick="startOCRScan()">
                            📷 OCR Scan
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Center Panel - Analytics & Dashboards -->
            <div class="center-panel">
                <div class="panel-card">
                    <div class="panel-title">
                        📊 Real-Time Analytics
                    </div>
                    <div class="metrics-grid">
                        <div class="metric-card">
                            <div class="metric-value" id="activeWorkOrders">24</div>
                            <div class="metric-label">Active Work Orders</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="systemHealth">97%</div>
                            <div class="metric-label">System Health</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="aiRequests">1,247</div>
                            <div class="metric-label">AI Requests Today</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-value" id="predictedFailures">3</div>
                            <div class="metric-label">Predicted Failures</div>
                        </div>
                    </div>
                </div>
                
                <div class="panel-card">
                    <div class="panel-title">
                        🎯 Predictive Insights
                    </div>
                    <div style="height: 300px; background: rgba(0,0,0,0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center; border: 1px dashed rgba(0, 255, 136, 0.3);">
                        <div style="text-align: center;">
                            <div style="font-size: 3rem; margin-bottom: 10px;">📈</div>
                            <div style="font-size: 1.1rem; margin-bottom: 5px;">Live Analytics Dashboard</div>
                            <div style="opacity: 0.7;">Equipment performance trends, failure predictions, and optimization recommendations</div>
                        </div>
                    </div>
                </div>
                
                <div class="panel-card">
                    <div class="panel-title">
                        🔄 Quick Actions
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                        <div class="quick-btn" onclick="createWorkOrder()" style="padding: 15px;">📋<br>New Work Order</div>
                        <div class="quick-btn" onclick="scheduleMaintenence()" style="padding: 15px;">📅<br>Schedule PM</div>
                        <div class="quick-btn" onclick="runDiagnostics()" style="padding: 15px;">🔍<br>AI Diagnostics</div>
                    </div>
                </div>
            </div>
            
            <!-- Right Panel - System Status & Activity -->
            <div class="right-panel">
                <div class="panel-card">
                    <div class="panel-title">
                        🤖 AI Models Status
                    </div>
                    <div class="ai-models-list">
                        <div class="model-status online">
                            <div>
                                <div class="model-name">Grok-2-1212</div>
                                <div class="model-latency">42ms avg</div>
                            </div>
                            <div style="color: #00ff88;">●</div>
                        </div>
                        <div class="model-status online">
                            <div>
                                <div class="model-name">GPT-4</div>
                                <div class="model-latency">67ms avg</div>
                            </div>
                            <div style="color: #00ff88;">●</div>
                        </div>
                        <div class="model-status online">
                            <div>
                                <div class="model-name">Llama 3.1</div>
                                <div class="model-latency">89ms avg</div>
                            </div>
                            <div style="color: #00ff88;">●</div>
                        </div>
                        <div class="model-status online">
                            <div>
                                <div class="model-name">Groq</div>
                                <div class="model-latency">34ms avg</div>
                            </div>
                            <div style="color: #00ff88;">●</div>
                        </div>
                        <div class="model-status online">
                            <div>
                                <div class="model-name">Google Gemini</div>
                                <div class="model-latency">56ms avg</div>
                            </div>
                            <div style="color: #00ff88;">●</div>
                        </div>
                    </div>
                </div>
                
                <div class="panel-card">
                    <div class="panel-title">
                        📝 Activity Log
                    </div>
                    <div class="activity-log" id="activityLog">
                        <div class="activity-item">
                            <div class="activity-icon success">✅</div>
                            <div class="activity-text">Work order WO-2025-001 completed</div>
                            <div class="activity-time">2m ago</div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon warning">⚠️</div>
                            <div class="activity-text">High vibration detected on Pump #3</div>
                            <div class="activity-time">5m ago</div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon success">🤖</div>
                            <div class="activity-text">AI predicted maintenance for Motor #12</div>
                            <div class="activity-time">8m ago</div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon success">🎤</div>
                            <div class="activity-text">Voice command processed: "Check equipment status"</div>
                            <div class="activity-time">12m ago</div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon success">📷</div>
                            <div class="activity-text">OCR scan completed: Asset QR-445B</div>
                            <div class="activity-time">15m ago</div>
                        </div>
                    </div>
                </div>
                
                <div class="panel-card">
                    <div class="panel-title">
                        🔧 System Controls
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <button class="quick-btn" onclick="exportLogs()" style="padding: 12px;">📊 Export Analytics</button>
                        <button class="quick-btn" onclick="configureAI()" style="padding: 12px;">⚙️ AI Settings</button>
                        <button class="quick-btn" onclick="systemHealth()" style="padding: 12px;">🏥 System Health</button>
                        <button class="quick-btn" onclick="backupData()" style="padding: 12px;">💾 Backup Data</button>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="/static/js/global-ai-assistant.js"></script>
        <script>
            let isRecording = false;
            let activityCount = 5;
            
            function handleKeyPress(event) {
                if (event.key === 'Enter') {
                    sendMessage();
                }
            }
            
            async function sendMessage() {
                const input = document.getElementById('chatInput');
                const messages = document.getElementById('chatMessages');
                const message = input.value.trim();
                
                if (!message) return;
                
                // Add user message
                const userDiv = document.createElement('div');
                userDiv.className = 'message user-message';
                userDiv.textContent = message;
                messages.appendChild(userDiv);
                
                input.value = '';
                messages.scrollTop = messages.scrollHeight;
                
                // Show AI thinking
                const thinkingDiv = document.createElement('div');
                thinkingDiv.className = 'message ai-message';
                thinkingDiv.innerHTML = '🧠 Processing with ' + document.getElementById('modelSelector').value + '...';
                thinkingDiv.style.opacity = '0.7';
                messages.appendChild(thinkingDiv);
                messages.scrollTop = messages.scrollHeight;
                
                try {
                    const response = await fetch('/cmms/ai/chat', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            message: message,
                            context: 'command_center',
                            model: document.getElementById('modelSelector').value
                        })
                    });
                    
                    const data = await response.json();
                    messages.removeChild(thinkingDiv);
                    
                    const aiDiv = document.createElement('div');
                    aiDiv.className = 'message ai-message';
                    aiDiv.innerHTML = '🧠 ' + (data.response || getSmartResponse(message));
                    messages.appendChild(aiDiv);
                    messages.scrollTop = messages.scrollHeight;
                    
                    // Update activity log
                    addActivity('🤖', `AI processed: "${message.substring(0, 30)}${message.length > 30 ? '...' : ''}"`, 'success');
                    
                } catch (error) {
                    messages.removeChild(thinkingDiv);
                    
                    const aiDiv = document.createElement('div');
                    aiDiv.className = 'message ai-message';
                    aiDiv.innerHTML = '🧠 ' + getSmartResponse(message);
                    messages.appendChild(aiDiv);
                    messages.scrollTop = messages.scrollHeight;
                }
            }
            
            function getSmartResponse(message) {
                const msg = message.toLowerCase();
                
                if (msg.includes('alert') || msg.includes('critical')) {
                    return `🚨 <strong>Critical Alerts Summary:</strong><br><br>• Pump #3: High vibration (CRITICAL)<br>• Conveyor Belt A: Overheating at 85°C<br>• Air Compressor: Pressure drop detected<br><br>Recommended actions: Immediate inspection and work order creation.`;
                }
                
                if (msg.includes('work order') || msg.includes('wo')) {
                    return `📋 <strong>Work Order Status:</strong><br><br>• Active: 24 orders<br>• Critical Priority: 3 orders<br>• Overdue: 1 order<br><br>Would you like me to create a new work order or show details for existing ones?`;
                }
                
                if (msg.includes('equipment') || msg.includes('asset')) {
                    return `⚙️ <strong>Equipment Overview:</strong><br><br>• Total Assets: 47<br>• Operational: 44 (94%)<br>• Needs Attention: 3<br>• Health Score: 97%<br><br>Top concerns: Pump #3 vibration, Conveyor A temperature.`;
                }
                
                if (msg.includes('predict') || msg.includes('maintenance')) {
                    return `🔮 <strong>Predictive Analytics:</strong><br><br>• 3 potential failures predicted in next 30 days<br>• Motor #12: PM due in 3 days<br>• Bearing replacement recommended for Pump #7<br><br>AI confidence: 94%`;
                }
                
                return `I understand you're asking about "${message}". As your AI command center, I can provide detailed insights, create work orders, analyze equipment data, and execute voice commands. What specific action would you like me to take?`;
            }
            
            function quickAction(action) {
                const actions = {
                    alerts: '🚨 Show me all critical equipment alerts',
                    workorders: '📋 Display active work orders',
                    equipment: '⚙️ Check equipment health status',
                    maintenance: '🔧 Show preventive maintenance schedule'
                };
                
                document.getElementById('chatInput').value = actions[action];
                sendMessage();
            }
            
            function startVoiceCommand() {
                const btn = event.target;
                if (isRecording) {
                    // Stop recording
                    btn.innerHTML = '🎤 Voice Command';
                    btn.classList.remove('recording');
                    isRecording = false;
                    
                    // Simulate voice processing
                    setTimeout(() => {
                        document.getElementById('chatInput').value = 'Create a work order for pump maintenance';
                        addActivity('🎤', 'Voice command: "Create work order for pump maintenance"', 'success');
                    }, 1000);
                } else {
                    // Start recording
                    btn.innerHTML = '🔴 Recording...';
                    btn.classList.add('recording');
                    isRecording = true;
                    addActivity('🎤', 'Voice recording started', 'success');
                }
            }
            
            function startOCRScan() {
                addActivity('📷', 'OCR scan initiated', 'success');
                setTimeout(() => {
                    document.getElementById('chatInput').value = 'Scanned asset ID: EQ-12345 - Motor requires inspection';
                    addActivity('📷', 'OCR scan completed: Motor EQ-12345', 'success');
                }, 2000);
            }
            
            function createWorkOrder() {
                window.open('/cmms/workorders/dashboard', '_blank');
                addActivity('📋', 'Work order creation page opened', 'success');
            }
            
            function scheduleMaintenence() {
                window.open('/cmms/preventive/dashboard', '_blank');
                addActivity('📅', 'Preventive maintenance page opened', 'success');
            }
            
            function runDiagnostics() {
                addActivity('🔍', 'AI diagnostics started', 'success');
                setTimeout(() => {
                    addActivity('🔍', 'Diagnostics complete - 3 issues found', 'warning');
                }, 3000);
            }
            
            function addActivity(icon, text, type) {
                const log = document.getElementById('activityLog');
                const item = document.createElement('div');
                item.className = 'activity-item';
                item.innerHTML = `
                    <div class="activity-icon ${type}">${icon}</div>
                    <div class="activity-text">${text}</div>
                    <div class="activity-time">now</div>
                `;
                log.insertBefore(item, log.firstChild);
                
                // Keep only last 10 items
                while (log.children.length > 10) {
                    log.removeChild(log.lastChild);
                }
            }
            
            function exportLogs() {
                addActivity('📊', 'Analytics export started', 'success');
            }
            
            function configureAI() {
                addActivity('⚙️', 'AI configuration panel opened', 'success');
            }
            
            function systemHealth() {
                addActivity('🏥', 'System health check initiated', 'success');
            }
            
            function backupData() {
                addActivity('💾', 'Data backup started', 'success');
            }
            
            // Update metrics periodically
            function updateMetrics() {
                document.getElementById('activeWorkOrders').textContent = Math.floor(Math.random() * 5) + 22;
                document.getElementById('systemHealth').textContent = (95 + Math.random() * 5).toFixed(1) + '%';
                document.getElementById('aiRequests').textContent = (1200 + Math.floor(Math.random() * 100)).toLocaleString();
                document.getElementById('systemLoad').textContent = 'CPU: ' + (20 + Math.floor(Math.random() * 15)) + '%';
            }
            
            // Auto-update every 30 seconds
            setInterval(updateMetrics, 30000);
            
            // Welcome message
            setTimeout(() => {
                addActivity('🧠', 'AI Command Center initialized', 'success');
            }, 1000);
        </script>
    </body>
    </html>
    """