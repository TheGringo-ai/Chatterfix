#!/usr/bin/env python3
"""
CMMS AI Pipeline - Complete RAG, Prediction, and Voice System
Refactored to treat heavy ML/AI libraries as optional so the module imports cleanly
without requiring full scientific stack. Missing libs now degrade features gracefully.
"""

from __future__ import annotations

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union, Tuple, TYPE_CHECKING
import logging
import hashlib
import pickle
import asyncio
import re
import random
import inspect
from pathlib import Path

# ---------------------------------------------------------------------------
# Optional heavy dependencies (lazy / guarded). Provide light fallbacks to
# prevent import resolution errors in constrained environments.
# ---------------------------------------------------------------------------
DEPENDENCIES_AVAILABLE = False  # default; enable only if all heavy deps present at runtime
SentenceTransformer = None  # type: ignore
faiss = None  # type: ignore
IsolationForest = None  # type: ignore
Image = None  # type: ignore
PyPDF2 = None  # type: ignore
docx = None  # type: ignore
pytesseract = None  # type: ignore
openai = None  # type: ignore
fitz = None  # type: ignore

# Lightweight numpy substitute (only what we need) if numpy missing
try:  # pragma: no cover - best effort
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    class _NPStub:
        class random:
            @staticmethod
            def randint(a, b):
                return random.randint(a, b)
            @staticmethod
            def uniform(a, b):
                return random.uniform(a, b)
        @staticmethod
        def array(values):
            return list(values)
        @staticmethod
        def float32():  # placeholder
            return 'float32'
    np = _NPStub()  # type: ignore

def _attempt_heavy_imports():  # lazy detection
    global SentenceTransformer, faiss, IsolationForest, Image, PyPDF2, docx, pytesseract, DEPENDENCIES_AVAILABLE
    try:
        from sentence_transformers import SentenceTransformer as _ST  # type: ignore
        import faiss as _faiss  # type: ignore
        from sklearn.ensemble import IsolationForest as _IF  # type: ignore
        from PIL import Image as _Image  # type: ignore
        import PyPDF2 as _PyPDF2  # type: ignore
        import docx as _docx  # type: ignore
        import pytesseract as _pyt  # type: ignore
        SentenceTransformer = _ST  # type: ignore
        faiss = _faiss  # type: ignore
        IsolationForest = _IF  # type: ignore
        Image = _Image  # type: ignore
        PyPDF2 = _PyPDF2  # type: ignore
        docx = _docx  # type: ignore
        pytesseract = _pyt  # type: ignore
        DEPENDENCIES_AVAILABLE = True
    except Exception:  # pragma: no cover
        DEPENDENCIES_AVAILABLE = False

_attempt_heavy_imports()

# Optional lightweight openai import (not required for basic operations)
try:  # pragma: no cover
    import openai as _openai  # type: ignore
    openai = _openai  # type: ignore
except Exception:
    openai = None  # type: ignore

# FastAPI and core imports
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, BackgroundTasks, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

# Removed direct heavy AI imports block; handled by lazy loader above

# CMMS imports
from auth_rbac import get_current_user, require_permissions, Permission, AuthUser
from audit_trail import audit_create, log_audit_entry, AuditContext

logger = logging.getLogger(__name__)

# =============================================================================
# Configuration and Models
# =============================================================================

class AIConfig:
    """AI Pipeline Configuration"""
    BASE_DIR = Path("/tmp/cmms_ai")
    DOCUMENTS_DIR = BASE_DIR / "documents"
    MODELS_DIR = BASE_DIR / "models" 
    EMBEDDINGS_DIR = BASE_DIR / "embeddings"
    OCR_DIR = BASE_DIR / "ocr_cache"
    
    # Vector DB settings
    EMBEDDING_DIM = 384  # sentence-transformers/all-MiniLM-L6-v2
    MAX_CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200
    
    # Prediction settings
    PREDICTION_LOOKBACK_DAYS = 365
    MIN_FAILURE_SAMPLES = 5
    
    # Voice settings
    VOICE_CONFIDENCE_THRESHOLD = 0.7
    MAX_AUDIO_DURATION = 60  # seconds

# Ensure directories exist
for dir_path in [AIConfig.BASE_DIR, AIConfig.DOCUMENTS_DIR, AIConfig.MODELS_DIR, 
                 AIConfig.EMBEDDINGS_DIR, AIConfig.OCR_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# API Models
class DocumentUpload(BaseModel):
    title: str
    asset_id: Optional[str] = None
    part_id: Optional[str] = None
    document_type: str = Field(..., description="manual, specification, image, other")
    tags: List[str] = Field(default_factory=list)

class RAGQuery(BaseModel):
    query: str = Field(..., min_length=3, max_length=500)
    asset_id: Optional[str] = None
    part_id: Optional[str] = None
    limit: int = Field(5, ge=1, le=20)
    include_context: bool = True

class RAGResponse(BaseModel):
    answer: str
    confidence: float
    sources: List[Dict[str, Any]]
    context_used: List[str]
    query_time_ms: float

class VoiceCommand(BaseModel):
    command: str
    intent: Optional[str] = None
    entities: Dict[str, Any] = Field(default_factory=dict)
    confidence: float = 0.0

class PredictionRequest(BaseModel):
    asset_id: str
    prediction_type: str = Field("failure_risk", description="failure_risk, maintenance_due, cost_estimate")
    horizon_days: int = Field(30, ge=1, le=365)

class PredictionResponse(BaseModel):
    asset_id: str
    prediction_type: str
    risk_score: float
    risk_level: str
    confidence: float
    reasons: List[str]
    recommendations: List[str]
    next_maintenance_suggested: Optional[str] = None
    predicted_failure_date: Optional[str] = None

# =============================================================================
# AI Pipeline Router
# =============================================================================

ai_pipeline_router = APIRouter(prefix="/ai", tags=["ai-pipeline"])

# =============================================================================
# Document Processing and RAG System
# =============================================================================

class DocumentProcessor:
    """Handle document ingestion, processing, and indexing"""
    
    def __init__(self):
        self.embedding_model = None
        self.vector_index = None
        self.document_metadata = {}
        self.load_models()
    
    def load_models(self):
        """Load embedding model and vector index"""
        if not DEPENDENCIES_AVAILABLE:
            logger.info("Vector/RAG heavy deps missing - operating in stub mode")
            return
        try:
            if SentenceTransformer:
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')  # type: ignore
            if faiss:
                index_path = AIConfig.EMBEDDINGS_DIR / "faiss_index.bin"
                metadata_path = AIConfig.EMBEDDINGS_DIR / "metadata.json"
                if index_path.exists() and metadata_path.exists():
                    self.vector_index = faiss.read_index(str(index_path))  # type: ignore
                    with open(metadata_path, 'r') as f:
                        self.document_metadata = json.load(f)
                    logger.info(f"Loaded existing index with {getattr(self.vector_index,'ntotal',0)} documents")
                else:
                    self.vector_index = faiss.IndexFlatIP(AIConfig.EMBEDDING_DIM)  # type: ignore
                    logger.info("Created new FAISS index")
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Model load degraded: {e}")
    
    def extract_text_from_file(self, file_path: Path, file_type: str) -> str:
        """Extract text from various file types"""
        try:
            if file_type.lower() == 'pdf':
                return self._extract_pdf_text(file_path)
            elif file_type.lower() in ['docx', 'doc']:
                return self._extract_docx_text(file_path)
            elif file_type.lower() in ['jpg', 'jpeg', 'png', 'tiff']:
                return self._extract_image_text(file_path)
            elif file_type.lower() in ['txt', 'csv']:
                return file_path.read_text(encoding='utf-8')
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
        except Exception as e:
            logger.error(f"Failed to extract text from {file_path}: {e}")
            return ""
    
    def _extract_pdf_text(self, file_path: Path) -> str:
        """Extract text from PDF using PyMuPDF or fallback to PyPDF2"""
        if not DEPENDENCIES_AVAILABLE:
            return ""
        text = ""
        # Prefer PyMuPDF if available
        if fitz is not None:
            try:
                doc = fitz.open(str(file_path))  # type: ignore
                if hasattr(doc, '__iter__'):
                    for page in doc:  # type: ignore
                        try:
                            text += page.get_text()  # type: ignore[attr-defined]
                        except Exception:
                            continue
                if hasattr(doc, 'close'):
                    try:
                        doc.close()  # type: ignore
                    except Exception:
                        pass
                return text
            except Exception as e:
                logger.warning(f"PyMuPDF extraction failed ({e}); falling back to PyPDF2")
        # Fallback to PyPDF2
        if PyPDF2 is not None:
            try:
                with open(file_path, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    for page in reader.pages:
                        text += page.extract_text() or ""
            except Exception as e:
                logger.error(f"PyPDF2 extraction failed: {e}")
        else:
            logger.error("No PDF library available (install PyPDF2)")
        return text
    
    def _extract_docx_text(self, file_path: Path) -> str:
        """Extract text from DOCX"""
        if not DEPENDENCIES_AVAILABLE or not docx:
            return ""
            
        try:
            doc = docx.Document(str(file_path))
            text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
            return text
        except Exception as e:
            logger.error(f"DOCX extraction failed: {e}")
            return ""
    
    def _extract_image_text(self, file_path: Path) -> str:
        """Extract text from image using OCR"""
        if not DEPENDENCIES_AVAILABLE or not Image or not pytesseract:
            return ""
            
        try:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)
            return text
        except Exception as e:
            logger.error(f"OCR extraction failed: {e}")
            return ""
    
    def chunk_text(self, text: str, chunk_size: int = AIConfig.MAX_CHUNK_SIZE, 
                   overlap: int = AIConfig.CHUNK_OVERLAP) -> List[str]:
        """Split text into overlapping chunks"""
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at sentence boundary
            if end < len(text):
                # Look for sentence endings within the last 200 characters
                search_start = max(end - 200, start)
                sentence_end = -1
                
                for punct in ['. ', '! ', '? ', '\n\n']:
                    pos = text.rfind(punct, search_start, end)
                    if pos > sentence_end:
                        sentence_end = pos + len(punct)
                
                if sentence_end > start:
                    end = sentence_end
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            start = end - overlap
            
        return chunks
    
    def index_document(self, file_path: Path, metadata: Dict[str, Any]) -> str:
        """Index a document for RAG retrieval"""
        if not DEPENDENCIES_AVAILABLE or not self.embedding_model or not faiss or not self.vector_index:
            # Lightweight fallback: store plain text chunks only
            doc_id = hashlib.md5(str(file_path).encode()).hexdigest()
            self.document_metadata[doc_id] = {**metadata, 'chunks': [file_path.read_text(errors='ignore')[:AIConfig.MAX_CHUNK_SIZE]], 'fallback': True}
            return doc_id
        
        try:
            # Auto-detect file type from extension if not provided
            file_type = metadata.get('file_type') or file_path.suffix.lstrip('.')
            
            # Extract text
            text = self.extract_text_from_file(file_path, file_type)
            if not text.strip():
                raise ValueError("No text content extracted from document")
            
            # Chunk text
            chunks = self.chunk_text(text)
            
            # Generate embeddings
            if not self.embedding_model:
                raise RuntimeError("Embedding model missing despite dependency flag")
            embeddings = self.embedding_model.encode(chunks)
            try:
                embeddings = embeddings.astype(np.float32)  # type: ignore[attr-defined]
            except Exception:
                pass
            # Normalize embeddings for cosine similarity
            if faiss:
                try:
                    faiss.normalize_L2(embeddings)  # type: ignore
                except Exception:
                    pass
            
            # Add to index
            doc_id = hashlib.md5(str(file_path).encode()).hexdigest()
            start_idx = self.vector_index.ntotal
            
            self.vector_index.add(embeddings)
            
            # Store metadata
            self.document_metadata[doc_id] = {
                **metadata,
                'file_path': str(file_path),
                'chunk_count': len(chunks),
                'chunks': chunks,
                'embedding_indices': list(range(start_idx, start_idx + len(chunks))),
                'indexed_at': datetime.now().isoformat()
            }
            
            # Save index and metadata
            self._save_index()
            
            logger.info(f"Indexed document {doc_id} with {len(chunks)} chunks")
            return doc_id
            
        except Exception as e:
            logger.error(f"Document indexing failed: {e}")
            raise
    
    def search_documents(self, query: str, limit: int = 5, 
                        asset_id: Optional[str] = None, 
                        part_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search documents using RAG"""
        if not DEPENDENCIES_AVAILABLE or not self.vector_index or getattr(self.vector_index, 'ntotal', 0) == 0:
            return [{
                'document_id': did,
                'title': meta.get('title','Untitled'),
                'content': (meta.get('chunks') or [''])[0][:500],
                'score': 0.1,
                'asset_id': meta.get('asset_id'),
                'chunk_index': 0
            } for did, meta in list(self.document_metadata.items())[:min(1, len(self.document_metadata))]]
        
        try:
            # Generate query embedding
            if not self.embedding_model:
                raise RuntimeError("Embedding model missing for search")
            query_embedding = self.embedding_model.encode([query])
            if faiss:
                try:
                    faiss.normalize_L2(query_embedding)  # type: ignore
                except Exception:
                    pass
            
            # Search vector index
            scores, indices = self.vector_index.search(query_embedding, limit * 3)
            
            results = []
            seen_docs = set()
            
            for score, idx in zip(scores[0], indices[0]):
                if idx == -1:  # Invalid index
                    continue
                    
                # Find which document this chunk belongs to
                doc_id = None
                chunk_idx = None
                
                for did, metadata in self.document_metadata.items():
                    if idx in metadata.get('embedding_indices', []):
                        doc_id = did
                        chunk_idx = metadata['embedding_indices'].index(idx)
                        break
                
                if not doc_id or doc_id in seen_docs:
                    continue
                    
                # Apply filters
                doc_metadata = self.document_metadata[doc_id]
                if asset_id and doc_metadata.get('asset_id') != asset_id:
                    continue
                if part_id and doc_metadata.get('part_id') != part_id:
                    continue
                
                results.append({
                    'document_id': doc_id,
                    'title': doc_metadata.get('title', 'Untitled'),
                    'content': doc_metadata['chunks'][chunk_idx],
                    'score': float(score),
                    'asset_id': doc_metadata.get('asset_id'),
                    'part_id': doc_metadata.get('part_id'),
                    'document_type': doc_metadata.get('document_type'),
                    'chunk_index': chunk_idx,
                    'file_path': doc_metadata.get('file_path')
                })
                
                seen_docs.add(doc_id)
                
                if len(results) >= limit:
                    break
            
            return results
            
        except Exception as e:
            logger.error(f"Document search failed: {e}")
            return []
    
    def _save_index(self):
        """Save FAISS index and metadata to disk"""
        try:
            if not faiss or not self.vector_index:
                return
            faiss.write_index(self.vector_index, str(AIConfig.EMBEDDINGS_DIR / "faiss_index.bin"))
            with open(AIConfig.EMBEDDINGS_DIR / "metadata.json", 'w') as f:
                json.dump(self.document_metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save index: {e}")

# Global document processor instance
doc_processor = DocumentProcessor()

# =============================================================================
# Predictive Maintenance System
# =============================================================================

class PredictiveMaintenanceEngine:
    """Predictive maintenance using historical data and ML models"""
    
    def __init__(self):
        self.models = {}
        self.feature_cache = {}
        
    def extract_features(self, asset_id: str) -> Dict[str, Any]:
        """Extract features for predictive modeling"""
        # In production, this would query actual work order and maintenance history
        # For now, we'll use mock historical data
        
        if asset_id in self.feature_cache:
            return self.feature_cache[asset_id]
        
        # Mock feature extraction - replace with actual database queries
        features = {
            'asset_age_days': np.random.randint(30, 3650),
            'total_work_orders': np.random.randint(5, 100),
            'failure_count': np.random.randint(0, 10),
            'days_since_last_maintenance': np.random.randint(1, 365),
            'avg_repair_time': np.random.uniform(1, 24),
            'total_maintenance_cost': np.random.uniform(500, 50000),
            'operating_hours': np.random.uniform(1000, 50000),
            'maintenance_frequency': np.random.uniform(30, 365),
            'criticality_score': np.random.uniform(1, 5),
            'environmental_factor': np.random.uniform(0.5, 2.0),
            'usage_intensity': np.random.uniform(0.1, 1.0)
        }
        
        # Calculate derived features
        features['work_orders_per_year'] = features['total_work_orders'] / (features['asset_age_days'] / 365)
        features['cost_per_work_order'] = features['total_maintenance_cost'] / max(features['total_work_orders'], 1)
        features['failure_rate'] = features['failure_count'] / max(features['total_work_orders'], 1)
        features['maintenance_efficiency'] = features['operating_hours'] / (features['avg_repair_time'] * features['total_work_orders'])
        
        self.feature_cache[asset_id] = features
        return features
    
    def calculate_failure_risk(self, asset_id: str, horizon_days: int = 30) -> PredictionResponse:
        """Calculate failure risk using ensemble approach"""
        try:
            features = self.extract_features(asset_id)
            
            # Baseline risk calculation (moving average approach)
            baseline_risk = self._calculate_baseline_risk(features, horizon_days)
            
            # Anomaly detection risk
            anomaly_risk = self._calculate_anomaly_risk(features)
            
            # Trend-based risk
            trend_risk = self._calculate_trend_risk(features, horizon_days)
            
            # Combine risks with weights
            combined_risk = (
                0.4 * baseline_risk +
                0.3 * anomaly_risk +
                0.3 * trend_risk
            )
            
            # Determine risk level
            if combined_risk >= 0.8:
                risk_level = "CRITICAL"
            elif combined_risk >= 0.6:
                risk_level = "HIGH"
            elif combined_risk >= 0.4:
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"
            
            # Generate reasons and recommendations
            reasons = self._generate_risk_reasons(features, combined_risk)
            recommendations = self._generate_recommendations(features, risk_level)
            
            # Predict next maintenance and potential failure dates
            next_maintenance = self._predict_next_maintenance(features)
            failure_date = self._predict_failure_date(features, combined_risk, horizon_days)
            
            return PredictionResponse(
                asset_id=asset_id,
                prediction_type="failure_risk",
                risk_score=round(combined_risk, 3),
                risk_level=risk_level,
                confidence=0.75,  # Would be calculated from model uncertainty
                reasons=reasons,
                recommendations=recommendations,
                next_maintenance_suggested=next_maintenance,
                predicted_failure_date=failure_date
            )
            
        except Exception as e:
            logger.error(f"Risk calculation failed for asset {asset_id}: {e}")
            raise HTTPException(status_code=500, detail="Risk calculation failed")
    
    def _calculate_baseline_risk(self, features: Dict[str, Any], horizon_days: int) -> float:
        """Calculate baseline risk using historical patterns"""
        # Simple baseline: risk increases with time since last maintenance
        days_since_maintenance = features['days_since_last_maintenance']
        maintenance_interval = features['maintenance_frequency']
        
        # Risk increases exponentially as we approach maintenance interval
        if days_since_maintenance >= maintenance_interval:
            return min(1.0, 0.7 + (days_since_maintenance - maintenance_interval) / maintenance_interval * 0.3)
        else:
            return (days_since_maintenance / maintenance_interval) * 0.5
    
    def _calculate_anomaly_risk(self, features: Dict[str, Any]) -> float:
        """Calculate risk based on anomaly detection"""
        # Use Isolation Forest for anomaly detection
        # This is a simplified version - in production, train on historical data
        
        feature_values = [
            features['work_orders_per_year'],
            features['cost_per_work_order'],
            features['failure_rate'],
            features['avg_repair_time']
        ]  # simplified structure when numpy absent
        
        # Mock anomaly score (in production, use trained model)
        anomaly_score = np.random.uniform(-0.5, 0.5)
        
        # Convert to risk (higher anomaly score = higher risk)
        risk = max(0, min(1, 0.5 + anomaly_score))
        return risk
    
    def _calculate_trend_risk(self, features: Dict[str, Any], horizon_days: int) -> float:
        """Calculate risk based on trends"""
        # Analyze trends in maintenance frequency, costs, failure rates
        # This is simplified - in production, analyze time series data
        
        failure_rate = features['failure_rate']
        work_order_frequency = features['work_orders_per_year'] / 365
        
        # Higher failure rate and work order frequency = higher risk
        trend_risk = min(1.0, failure_rate * 2 + work_order_frequency * horizon_days * 0.1)
        
        return trend_risk
    
    def _generate_risk_reasons(self, features: Dict[str, Any], risk_score: float) -> List[str]:
        """Generate human-readable reasons for risk assessment"""
        reasons = []
        
        if features['days_since_last_maintenance'] > features['maintenance_frequency']:
            overdue_days = features['days_since_last_maintenance'] - features['maintenance_frequency']
            reasons.append(f"Maintenance overdue by {overdue_days} days")
        
        if features['failure_rate'] > 0.1:
            reasons.append(f"High historical failure rate: {features['failure_rate']:.1%}")
        
        if features['work_orders_per_year'] > 20:
            reasons.append(f"High maintenance frequency: {features['work_orders_per_year']:.1f} work orders/year")
        
        if features['cost_per_work_order'] > 5000:
            reasons.append(f"High average repair cost: ${features['cost_per_work_order']:,.0f}")
        
        if features['asset_age_days'] > 2555:  # ~7 years
            reasons.append(f"Asset aging: {features['asset_age_days']/365:.1f} years old")
        
        if not reasons:
            if risk_score > 0.5:
                reasons.append("Multiple moderate risk factors detected")
            else:
                reasons.append("Asset within normal operating parameters")
        
        return reasons[:5]  # Limit to 5 most important reasons
    
    def _generate_recommendations(self, features: Dict[str, Any], risk_level: str) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        if risk_level in ["CRITICAL", "HIGH"]:
            if features['days_since_last_maintenance'] > features['maintenance_frequency']:
                recommendations.append("Schedule immediate preventive maintenance")
            
            if features['failure_rate'] > 0.15:
                recommendations.append("Consider asset replacement or major overhaul")
            
            recommendations.append("Increase inspection frequency to weekly")
            recommendations.append("Prepare spare parts and replacement components")
        
        elif risk_level == "MEDIUM":
            recommendations.append("Schedule preventive maintenance within 2 weeks")
            recommendations.append("Monitor asset performance indicators closely")
            recommendations.append("Review maintenance procedures and intervals")
        
        else:  # LOW risk
            recommendations.append("Continue standard maintenance schedule")
            recommendations.append("Monitor for any changes in performance")
        
        return recommendations[:4]
    
    def _predict_next_maintenance(self, features: Dict[str, Any]) -> str:
        """Predict optimal next maintenance date"""
        last_maintenance_days_ago = features['days_since_last_maintenance']
        maintenance_interval = features['maintenance_frequency']
        
        # Calculate next maintenance based on interval and current overdue status
        if last_maintenance_days_ago >= maintenance_interval:
            # Overdue - recommend immediate maintenance
            next_date = datetime.now() + timedelta(days=1)
        else:
            # Calculate based on normal interval
            days_until_next = maintenance_interval - last_maintenance_days_ago
            next_date = datetime.now() + timedelta(days=days_until_next)
        
        return next_date.strftime("%Y-%m-%d")
    
    def _predict_failure_date(self, features: Dict[str, Any], risk_score: float, horizon_days: int) -> Optional[str]:
        """Predict potential failure date"""
        if risk_score < 0.6:
            return None  # Low risk, no specific failure predicted
        
        # Estimate failure date based on risk progression
        days_to_failure = max(1, int(horizon_days * (1 - risk_score) * 2))
        failure_date = datetime.now() + timedelta(days=days_to_failure)
        
        return failure_date.strftime("%Y-%m-%d")

# Global predictive maintenance engine
pm_engine = PredictiveMaintenanceEngine()

# =============================================================================
# Natural Language Processing and Voice Interface
# =============================================================================

class NLPProcessor:
    """Process natural language commands and extract intents/entities"""
    
    def __init__(self):
        self.intent_patterns = {
            'create_work_order': [
                r'create (?:a )?work order',
                r'make (?:a )?work order',
                r'new work order',
                r'add work order'
            ],
            'list_parts': [
                r'what parts',
                r'list parts',
                r'show parts',
                r'parts (?:that )?need reordering',
                r'low stock'
            ],
            'check_asset': [
                r'check asset',
                r'asset status',
                r'how is (?:the )?(?:asset|equipment)',
                r'status of'
            ],
            'schedule_maintenance': [
                r'schedule maintenance',
                r'plan maintenance',
                r'maintenance for'
            ],
            'search_manual': [
                r'what is (?:the )?(?:torque|pressure|temperature)',
                r'(?:find|search) in manual',
                r'spec for',
                r'specification'
            ]
        }
        
        self.entity_patterns = {
            'asset_id': r'(?:asset|pump|motor|unit|equipment)[\s\-]?([A-Z]*\-?\d+)',
            'part_id': r'(?:part|component)[\s\-]?([A-Z]*\-?\d+)',
            'priority': r'(low|medium|high|urgent|critical)(?:\s+priority)?',
            'date': r'(today|tomorrow|(?:next )?(?:week|month)|(?:\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?)|(?:\d{1,2}(?:st|nd|rd|th)?))',
            'quantity': r'(\d+)(?:\s+(?:pieces?|units?|items?))?'
        }
    
    def process_command(self, command: str) -> VoiceCommand:
        """Process natural language command and extract intent/entities"""
        command_lower = command.lower().strip()
        
        # Detect intent
        intent = self._detect_intent(command_lower)
        
        # Extract entities
        entities = self._extract_entities(command_lower)
        
        # Calculate confidence based on pattern matches
        confidence = self._calculate_confidence(command_lower, intent, entities)
        
        return VoiceCommand(
            command=command,
            intent=intent,
            entities=entities,
            confidence=confidence
        )
    
    def _detect_intent(self, command: str) -> Optional[str]:
        """Detect user intent from command"""
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, command, re.IGNORECASE):
                    return intent
        return None
    
    def _extract_entities(self, command: str) -> Dict[str, Any]:
        """Extract entities from command"""
        entities = {}
        
        for entity_type, pattern in self.entity_patterns.items():
            matches = re.findall(pattern, command, re.IGNORECASE)
            if matches:
                if entity_type in ['asset_id', 'part_id']:
                    entities[entity_type] = matches[0].upper()
                elif entity_type == 'priority':
                    entities[entity_type] = matches[0].lower()
                elif entity_type == 'date':
                    entities[entity_type] = self._normalize_date(matches[0])
                elif entity_type == 'quantity':
                    entities[entity_type] = int(matches[0])
        
        return entities
    
    def _normalize_date(self, date_str: str) -> str:
        """Normalize date expressions to ISO format"""
        date_str = date_str.lower()
        
        if date_str == 'today':
            return datetime.now().strftime('%Y-%m-%d')
        elif date_str == 'tomorrow':
            return (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
        elif 'next week' in date_str:
            return (datetime.now() + timedelta(weeks=1)).strftime('%Y-%m-%d')
        elif 'next month' in date_str:
            return (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
        else:
            # Try to parse date patterns (simplified)
            return datetime.now().strftime('%Y-%m-%d')  # Fallback to today
    
    def _calculate_confidence(self, command: str, intent: Optional[str], entities: Dict[str, Any]) -> float:
        """Calculate confidence score for the interpretation"""
        score = 0.0
        
        # Base score for having an intent
        if intent:
            score += 0.4
            
            # Bonus for specific intents with required entities
            if intent == 'create_work_order' and 'asset_id' in entities:
                score += 0.3
            elif intent == 'list_parts' and len(command.split()) <= 6:  # Simple query
                score += 0.4
            elif intent == 'check_asset' and 'asset_id' in entities:
                score += 0.3
        
        # Entity extraction bonus
        score += len(entities) * 0.05
        
        # Command clarity bonus
        if len(command.split()) >= 3 and len(command.split()) <= 10:
            score += 0.1
        
        return min(1.0, score)

# Global NLP processor
nlp_processor = NLPProcessor()

# =============================================================================
# AI Pipeline API Endpoints
# =============================================================================

@ai_pipeline_router.post("/upload-document")
@require_permissions(Permission.ADMIN_CONFIG)
async def upload_document(
    file: UploadFile = File(...),
    title: str = Form(...),
    document_type: str = Form(...),
    asset_id: Optional[str] = Form(None),
    part_id: Optional[str] = Form(None),
    tags: str = Form(""),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    current_user: AuthUser = Depends(get_current_user)
):
    """Upload and index document for RAG system"""
    
    # Validate file type
    allowed_extensions = {'.pdf', '.docx', '.doc', '.txt', '.csv', '.jpg', '.jpeg', '.png', '.tiff'}
    if not file.filename:
        raise HTTPException(status_code=400, detail="Uploaded file has no filename")
    file_extension = Path(file.filename).suffix.lower()
    
    if file_extension not in allowed_extensions:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {file_extension}")
    
    # Save uploaded file
    file_path = AIConfig.DOCUMENTS_DIR / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}"
    
    try:
        content = await file.read()
        with open(file_path, 'wb') as f:
            f.write(content)
        
        # Prepare metadata
        metadata = {
            'title': title,
            'document_type': document_type,
            'asset_id': asset_id,
            'part_id': part_id,
            'tags': [tag.strip() for tag in tags.split(',') if tag.strip()],
            'file_type': file_extension[1:],  # Remove the dot
            'original_filename': file.filename,
            'uploaded_by': current_user.username,
            'uploaded_at': datetime.now().isoformat()
        }
        
        # Index document in background
        background_tasks.add_task(doc_processor.index_document, file_path, metadata)
        
        return JSONResponse({
            'success': True,
            'message': f'Document "{title}" uploaded and will be indexed shortly',
            'file_path': str(file_path)
        })
        
    except Exception as e:
        # Clean up file on error
        if file_path.exists():
            file_path.unlink()
        logger.error(f"Document upload failed: {e}")
        raise HTTPException(status_code=500, detail="Document upload failed")

@ai_pipeline_router.post("/search", response_model=List[Dict[str, Any]])
@require_permissions(Permission.PARTS_VIEW)  # Basic permission for document search
async def search_documents(
    query: RAGQuery,
    current_user: AuthUser = Depends(get_current_user)
):
    """Search documents using RAG system"""
    
    try:
        results = doc_processor.search_documents(
            query=query.query,
            limit=query.limit,
            asset_id=query.asset_id,
            part_id=query.part_id
        )
        
        return results
        
    except Exception as e:
        logger.error(f"Document search failed: {e}")
        raise HTTPException(status_code=500, detail="Document search failed")

@ai_pipeline_router.post("/answer", response_model=RAGResponse)
@require_permissions(Permission.PARTS_VIEW)
async def answer_question(
    query: RAGQuery,
    current_user: AuthUser = Depends(get_current_user)
):
    """Answer questions using RAG system"""
    
    start_time = datetime.now()
    
    try:
        # Search for relevant documents
        search_results = doc_processor.search_documents(
            query=query.query,
            limit=query.limit,
            asset_id=query.asset_id,
            part_id=query.part_id
        )
        
        if not search_results:
            return RAGResponse(
                answer="I couldn't find any relevant information in the documentation for your query.",
                confidence=0.0,
                sources=[],
                context_used=[],
                query_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
        
        # Generate answer based on search results
        context_texts = [result['content'] for result in search_results]
        context_combined = '\n\n'.join(context_texts[:3])  # Use top 3 results

        # Simple answer generation (in production, use LLM)
        answer = _generate_answer(query.query, context_combined, search_results)

        # Calculate confidence based on search scores
        avg_score = sum(r['score'] for r in search_results) / len(search_results)
        confidence = min(0.95, avg_score * 0.8)

        query_time = (datetime.now() - start_time).total_seconds() * 1000

        return RAGResponse(
            answer=answer,
            confidence=confidence,
            sources=search_results,
            context_used=context_texts if query.include_context else [],
            query_time_ms=query_time
        )
        
    except Exception as e:
        logger.error(f"Question answering failed: {e}")
        raise HTTPException(status_code=500, detail="Question answering failed")

def _generate_answer(query: str, context: str, sources: List[Dict[str, Any]]) -> str:
    """Generate answer from context (simplified version)"""
    # In production, this would use an LLM like GPT-4 or Claude
    # For now, provide a structured response based on context
    
    query_lower = query.lower()
    
    # Extract key information from context
    lines = context.split('\n')
    relevant_lines = []
    
    # Look for lines that might contain the answer
    for line in lines:
        line_lower = line.lower()
        if any(word in line_lower for word in query_lower.split() if len(word) > 3):
            relevant_lines.append(line.strip())
    
    if relevant_lines:
        answer = "Based on the documentation:\n\n"
        answer += '\n'.join(relevant_lines[:3])  # Top 3 relevant lines
        
        # Add source reference
        if sources:
            answer += f"\n\nSource: {sources[0]['title']}"
        
        return answer
    else:
        return f"I found some relevant documentation, but couldn't extract a specific answer to '{query}'. Please review the source documents for more details."

@ai_pipeline_router.post("/predict/asset/{asset_id}", response_model=PredictionResponse)
@require_permissions(Permission.ASSETS_VIEW)
async def predict_asset_risk(
    asset_id: str,
    request: PredictionRequest = PredictionRequest(asset_id="temp", prediction_type="failure_risk", horizon_days=30),
    current_user: AuthUser = Depends(get_current_user)
):
    """Generate predictive maintenance assessment for asset"""
    
    try:
        # Override asset_id from path parameter
        request.asset_id = asset_id
        
        if request.prediction_type == "failure_risk":
            prediction = pm_engine.calculate_failure_risk(asset_id, request.horizon_days)
            
            # Log the prediction request for audit
            # log_audit_entry may be sync or async; handle both
            audit_ctx = AuditContext(
                user_id=current_user.id,
                user_name=current_user.username,
                action="PREDICT_FAILURE_RISK",
                resource_type="asset",
                resource_id=asset_id,
                payload={
                    "prediction_type": request.prediction_type,
                    "horizon_days": request.horizon_days,
                    "risk_score": prediction.risk_score,
                    "risk_level": prediction.risk_level
                }
            )
            maybe_coro = log_audit_entry(audit_ctx)
            if inspect.isawaitable(maybe_coro):  # type: ignore
                await maybe_coro  # type: ignore
            
            return prediction
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported prediction type: {request.prediction_type}")
            
    except Exception as e:
        logger.error(f"Prediction failed for asset {asset_id}: {e}")
        raise HTTPException(status_code=500, detail="Prediction failed")

@ai_pipeline_router.post("/voice/command", response_model=Dict[str, Any])
@require_permissions(Permission.WORK_ORDERS_VIEW)
async def process_voice_command(
    command: str = Form(...),
    current_user: AuthUser = Depends(get_current_user)
):
    """Process natural language voice command"""
    
    try:
        # Process command using NLP
        voice_command = nlp_processor.process_command(command)
        
        if voice_command.confidence < AIConfig.VOICE_CONFIDENCE_THRESHOLD:
            return {
                'success': False,
                'message': f"I'm not confident about interpreting '{command}'. Could you please rephrase?",
                'confidence': voice_command.confidence,
                'suggestion': "Try commands like 'create work order for pump A tomorrow high priority' or 'what parts need reordering?'"
            }
        
        # Execute command based on intent
        result = await execute_voice_command(voice_command, current_user)
        
        return result
        
    except Exception as e:
        logger.error(f"Voice command processing failed: {e}")
        raise HTTPException(status_code=500, detail="Voice command processing failed")

async def execute_voice_command(command: VoiceCommand, user: AuthUser) -> Dict[str, Any]:
    """Execute the interpreted voice command"""
    
    if command.intent == 'create_work_order':
        return await _execute_create_work_order(command, user)
    elif command.intent == 'list_parts':
        return await _execute_list_parts(command, user)
    elif command.intent == 'check_asset':
        return await _execute_check_asset(command, user)
    elif command.intent == 'search_manual':
        return await _execute_search_manual(command, user)
    else:
        return {
            'success': False,
            'message': f"I understood your intent ({command.intent}) but cannot execute this command yet.",
            'intent': command.intent,
            'entities': command.entities
        }

async def _execute_create_work_order(command: VoiceCommand, user: AuthUser) -> Dict[str, Any]:
    """Execute create work order command"""
    
    # Check permissions
    if Permission.WORK_ORDERS_CREATE.value not in user.permissions:
        return {
            'success': False,
            'message': "You don't have permission to create work orders.",
            'required_permission': 'work_orders:create'
        }
    
    # Extract required information
    asset_id = command.entities.get('asset_id')
    priority = command.entities.get('priority', 'medium')
    due_date = command.entities.get('date')
    
    if not asset_id:
        return {
            'success': False,
            'message': "I need an asset ID to create a work order. For example: 'create work order for pump-123'",
            'missing': 'asset_id'
        }
    
    # Create work order data
    work_order_data = {
        'title': f'Voice-created work order for {asset_id}',
        'description': f'Work order created via voice command: "{command.command}"',
        'asset_id': asset_id,
        'type': 'reactive',
        'priority': priority,
        'created_by': user.username
    }
    
    if due_date:
        work_order_data['due_date'] = due_date
    
    # Mock work order creation (in production, call actual API)
    work_order_id = f"WO-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    
    return {
        'success': True,
        'message': f'Created work order {work_order_id} for {asset_id} with {priority} priority' + 
                  (f' due {due_date}' if due_date else ''),
        'work_order_id': work_order_id,
        'data': work_order_data
    }

async def _execute_list_parts(command: VoiceCommand, user: AuthUser) -> Dict[str, Any]:
    """Execute list parts command"""
    
    # Mock parts that need reordering
    low_stock_parts = [
        {'id': 'PART-001', 'name': 'Bearing Type A', 'current_stock': 2, 'min_stock': 5},
        {'id': 'PART-015', 'name': 'Oil Filter', 'current_stock': 1, 'min_stock': 3},
        {'id': 'PART-027', 'name': 'Drive Belt', 'current_stock': 0, 'min_stock': 2}
    ]
    
    message = f"Found {len(low_stock_parts)} parts that need reordering:\n"
    for part in low_stock_parts:
        message += f"• {part['name']} ({part['id']}): {part['current_stock']} in stock, minimum {part['min_stock']}\n"
    
    return {
        'success': True,
        'message': message.strip(),
        'parts_count': len(low_stock_parts),
        'parts': low_stock_parts
    }

async def _execute_check_asset(command: VoiceCommand, user: AuthUser) -> Dict[str, Any]:
    """Execute check asset command"""
    
    asset_id = command.entities.get('asset_id')
    if not asset_id:
        return {
            'success': False,
            'message': "I need an asset ID to check status. For example: 'check asset pump-123'",
            'missing': 'asset_id'
        }
    
    # Mock asset status check
    return {
        'success': True,
        'message': f'Asset {asset_id} is operational. Last maintenance: 15 days ago. Next maintenance due in 45 days.',
        'asset_id': asset_id,
        'status': 'operational',
        'last_maintenance_days_ago': 15,
        'next_maintenance_due_days': 45
    }

async def _execute_search_manual(command: VoiceCommand, user: AuthUser) -> Dict[str, Any]:
    """Execute manual search command"""
    
    # Use RAG system to search for the answer
    query = RAGQuery(query=command.command, limit=3)
    
    try:
        results = doc_processor.search_documents(
            query=query.query,
            limit=query.limit
        )
        
        if results:
            top_result = results[0]
            return {
                'success': True,
                'message': f"Found information in {top_result['title']}:\n\n{top_result['content'][:300]}...",
                'source': top_result['title'],
                'confidence': top_result['score']
            }
        else:
            return {
                'success': False,
                'message': "I couldn't find that information in the available manuals and documentation.",
                'suggestion': "Try uploading relevant documentation or rephrasing your question."
            }
            
    except Exception as e:
        return {
            'success': False,
            'message': f"Manual search failed: {str(e)}"
        }

@ai_pipeline_router.get("/status")
async def get_ai_status():
    """Get AI pipeline status and capabilities"""
    
    return {
        'ai_pipeline_status': 'operational',
        'dependencies_available': DEPENDENCIES_AVAILABLE,
        'capabilities': {
            'rag_system': {
                'available': True,
                'documents_indexed': len(doc_processor.document_metadata),
                'vector_index_size': doc_processor.vector_index.ntotal if doc_processor.vector_index else 0
            },
            'predictive_maintenance': {
                'available': True,
                'models_loaded': len(pm_engine.models),
                'supported_predictions': ['failure_risk']
            },
            'nlp_processing': {
                'available': True,
                'supported_intents': list(nlp_processor.intent_patterns.keys())
            },
            'voice_interface': {
                'available': True,
                'confidence_threshold': AIConfig.VOICE_CONFIDENCE_THRESHOLD
            }
        },
        'storage_locations': {
            'documents': str(AIConfig.DOCUMENTS_DIR),
            'embeddings': str(AIConfig.EMBEDDINGS_DIR),
            'models': str(AIConfig.MODELS_DIR)
        }
    }

# Initialize AI pipeline on startup
async def initialize_ai_pipeline():
    """Initialize AI pipeline components"""
    logger.info("Initializing AI Pipeline...")
    
    try:
        # Load document processor
        doc_processor.load_models()
        
        # Initialize predictive maintenance engine
        # pm_engine would load trained models here
        
        logger.info("AI Pipeline initialized successfully")
        
    except Exception as e:
        logger.error(f"AI Pipeline initialization failed: {e}")

# Export router
__all__ = ['ai_pipeline_router', 'initialize_ai_pipeline']