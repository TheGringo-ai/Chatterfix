#!/usr/bin/env python3
"""
AI Pipeline Demo Script
Comprehensive demonstration of all AI capabilities in the CMMS system
"""

import asyncio
import sys
import time
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime

from ai_pipeline import (
    DocumentProcessor, 
    PredictiveMaintenanceEngine, 
    NLPProcessor,
    get_ai_status
)

class AIPipelineDemo:
    """Comprehensive AI Pipeline demonstration"""
    
    def __init__(self):
        self.doc_processor = DocumentProcessor()
        self.predictive_engine = PredictiveMaintenanceEngine()
        self.nlp_processor = NLPProcessor()
        
    def print_banner(self, title: str):
        """Print a formatted banner"""
        print("\n" + "=" * 60)
        print(f"🤖 {title}")
        print("=" * 60)
        
    def create_demo_documents(self):
        """Create demo documents for RAG testing"""
        self.print_banner("Creating Demo Documents")
        
        # Create test directory
        demo_dir = Path('/tmp/cmms_ai/demo')
        demo_dir.mkdir(parents=True, exist_ok=True)
        
        # 1. Create equipment manual text
        manual_content = """
        PUMP-001 Operations Manual
        
        Equipment: Centrifugal Water Pump Model XH-2500
        Location: Building A, Mechanical Room
        Installation Date: 2022-03-15
        
        Operating Specifications:
        - Flow Rate: 2500 GPM
        - Head: 150 feet
        - Power: 75 HP motor
        - Operating Temperature: 40-180°F
        
        Maintenance Schedule:
        - Daily: Check for leaks, unusual noise
        - Weekly: Inspect coupling alignment
        - Monthly: Lubricate bearings, check vibration levels
        - Quarterly: Replace seals, inspect impeller
        
        Troubleshooting:
        - High vibration: Check alignment, inspect bearings
        - Low flow: Clean impeller, check suction strainer
        - Overheating: Check cooling system, reduce flow rate
        
        Torque Specifications:
        - Coupling bolts: 45 ft-lbs
        - Flange bolts: 30 ft-lbs
        - Bearing housing: 25 ft-lbs
        """
        
        manual_path = demo_dir / "pump_001_manual.txt"
        manual_path.write_text(manual_content)
        
        # 2. Create maintenance history document
        history_content = """
        MOTOR-045 Maintenance History
        
        Equipment: Electric Motor 50HP
        Asset ID: MOTOR-045
        Location: Production Line 2
        
        Maintenance Records:
        
        2024-01-15: Replaced bearings due to excessive noise
        Cost: $450, Downtime: 4 hours
        Technician: John Smith
        
        2024-03-22: Routine inspection, found insulation degradation  
        Cost: $200, Preventive maintenance
        Technician: Maria Garcia
        
        2024-06-10: Rewound motor windings after failure
        Cost: $1,200, Downtime: 8 hours
        Root cause: Overheating due to blocked ventilation
        
        2024-08-30: Quarterly lubrication and alignment check
        Cost: $75, Preventive maintenance
        Status: Good condition, no issues found
        
        Critical Notes:
        - Motor shows signs of aging, consider replacement in 2025
        - Ventilation system needs regular cleaning
        - Vibration levels trending upward
        """
        
        history_path = demo_dir / "motor_045_history.txt" 
        history_path.write_text(history_content)
        
        # 3. Create equipment image with OCR text
        img = Image.new('RGB', (500, 300), color='white')
        draw = ImageDraw.Draw(img)
        
        # Try to use system font
        try:
            font_title = ImageFont.truetype('/System/Library/Fonts/Arial.ttf', 20)
            font_text = ImageFont.truetype('/System/Library/Fonts/Arial.ttf', 14)
        except:
            font_title = ImageFont.load_default()
            font_text = ImageFont.load_default()
        
        # Draw equipment label
        draw.text((20, 20), 'VALVE-123 Inspection Report', fill='black', font=font_title)
        draw.text((20, 60), 'Type: Ball Valve 6-inch', fill='black', font=font_text)
        draw.text((20, 80), 'Status: REQUIRES MAINTENANCE', fill='red', font=font_text) 
        draw.text((20, 100), 'Last Service: 2024-01-15', fill='black', font=font_text)
        draw.text((20, 120), 'Issue: Actuator sticking', fill='red', font=font_text)
        draw.text((20, 140), 'Priority: HIGH', fill='red', font=font_text)
        draw.text((20, 180), 'Technician Notes:', fill='black', font=font_text)
        draw.text((20, 200), '• Actuator needs lubrication', fill='black', font=font_text)
        draw.text((20, 220), '• Replace seals during next service', fill='black', font=font_text)
        draw.text((20, 240), '• Check pneumatic pressure', fill='black', font=font_text)
        
        image_path = demo_dir / "valve_123_report.png"
        img.save(image_path)
        
        print(f"✅ Created demo documents in {demo_dir}")
        return {
            'manual': manual_path,
            'history': history_path,
            'image': image_path
        }
        
    def demo_rag_system(self, documents):
        """Demonstrate RAG document indexing and search"""
        self.print_banner("RAG System Demonstration")
        
        # Index documents
        print("📄 Indexing documents...")
        
        doc_ids = []
        
        # Index pump manual
        metadata = {
            'title': 'PUMP-001 Operations Manual',
            'asset_id': 'PUMP-001',
            'document_type': 'manual',
            'tags': ['pump', 'operations', 'maintenance', 'troubleshooting']
        }
        doc_id = self.doc_processor.index_document(documents['manual'], metadata)
        doc_ids.append(doc_id)
        print(f"  ✅ Indexed: {metadata['title']} (ID: {doc_id})")
        
        # Index motor history
        metadata = {
            'title': 'MOTOR-045 Maintenance History', 
            'asset_id': 'MOTOR-045',
            'document_type': 'history',
            'tags': ['motor', 'maintenance', 'history', 'repairs']
        }
        doc_id = self.doc_processor.index_document(documents['history'], metadata)
        doc_ids.append(doc_id)
        print(f"  ✅ Indexed: {metadata['title']} (ID: {doc_id})")
        
        # Index valve image
        metadata = {
            'title': 'VALVE-123 Inspection Report',
            'asset_id': 'VALVE-123', 
            'document_type': 'image',
            'tags': ['valve', 'inspection', 'maintenance', 'high-priority']
        }
        doc_id = self.doc_processor.index_document(documents['image'], metadata)
        doc_ids.append(doc_id)
        print(f"  ✅ Indexed: {metadata['title']} (ID: {doc_id})")
        
        print(f"📊 Total documents in index: {self.doc_processor.vector_index.ntotal}")
        
        # Test semantic searches
        search_queries = [
            "pump troubleshooting high vibration",
            "motor maintenance cost history", 
            "valve requires maintenance",
            "torque specifications coupling bolts",
            "bearing replacement procedure"
        ]
        
        print("\n🔍 Testing semantic search...")
        for query in search_queries:
            print(f"\nQuery: \"{query}\"")
            results = self.doc_processor.search_documents(query, limit=2)
            
            for i, result in enumerate(results[:2], 1):
                print(f"  {i}. {result['title']} (score: {result['score']:.3f})")
                print(f"     Asset: {result['asset_id']}")
                print(f"     Content: {result['content'][:100]}...")
                
    def demo_predictive_maintenance(self):
        """Demonstrate predictive maintenance capabilities"""
        self.print_banner("Predictive Maintenance Engine")
        
        # Test different assets with various risk levels
        test_assets = [
            'PUMP-001',
            'MOTOR-045', 
            'VALVE-123',
            'COMPRESSOR-007',
            'GENERATOR-019'
        ]
        
        print("📈 Analyzing failure risk for assets...")
        
        for asset_id in test_assets:
            print(f"\n🔧 Asset: {asset_id}")
            
            # Get failure risk prediction
            prediction = self.predictive_engine.calculate_failure_risk(asset_id, horizon_days=30)
            
            print(f"   Risk Score: {prediction.risk_score:.3f}")
            print(f"   Risk Level: {prediction.risk_level}")
            print(f"   Confidence: {prediction.confidence:.0%}")
            
            if prediction.predicted_failure_date:
                print(f"   Predicted Failure: {prediction.predicted_failure_date}")
            
            if prediction.next_maintenance_suggested:
                print(f"   Next Maintenance: {prediction.next_maintenance_suggested}")
                
            print("   Top Risk Factors:")
            for reason in prediction.reasons[:2]:
                print(f"     • {reason}")
                
            print("   Recommendations:")
            for rec in prediction.recommendations[:2]:
                print(f"     • {rec}")
                
        # Test longer time horizons
        print(f"\n📊 Extended Risk Analysis (90 days)")
        extended_prediction = self.predictive_engine.calculate_failure_risk('PUMP-001', horizon_days=90)
        print(f"   90-day risk score: {extended_prediction.risk_score:.3f}")
        print(f"   Risk level: {extended_prediction.risk_level}")
        
    def demo_nlp_processing(self):
        """Demonstrate natural language processing"""
        self.print_banner("Natural Language Processing")
        
        # Test voice commands
        voice_commands = [
            "Create work order for PUMP-001 tomorrow high priority",
            "What parts need reordering?", 
            "Show me maintenance history for MOTOR-045",
            "Schedule preventive maintenance for all valves next month",
            "Update asset VALVE-123 status to needs repair",
            "Generate report for equipment in building A",
            "Check inventory levels for bearings",
            "What is the torque specification for coupling bolts?"
        ]
        
        print("🗣️  Processing natural language commands...")
        
        for i, command in enumerate(voice_commands, 1):
            print(f"\n{i}. \"{command}\"")
            
            result = self.nlp_processor.process_command(command)
            
            print(f"   Intent: {result.intent or 'Unknown'}")
            print(f"   Confidence: {result.confidence:.0%}")
            
            if result.entities:
                print("   Entities:")
                for key, value in result.entities.items():
                    print(f"     {key}: {value}")
            else:
                print("   Entities: None detected")
                
        # Test different confidence levels
        print("\n📊 Command Analysis Summary:")
        intents_found = {}
        total_confidence = 0
        
        for command in voice_commands:
            result = self.nlp_processor.process_command(command)
            intent = result.intent or 'unknown'
            intents_found[intent] = intents_found.get(intent, 0) + 1
            total_confidence += result.confidence
            
        print(f"   Average confidence: {total_confidence / len(voice_commands):.0%}")
        print("   Intent distribution:")
        for intent, count in intents_found.items():
            print(f"     {intent}: {count} commands")
            
    async def demo_ai_status(self):
        """Demonstrate AI system status monitoring"""
        self.print_banner("AI System Status")
        
        status = await get_ai_status()
        
        print(f"🤖 AI Pipeline Status: {status['ai_pipeline_status'].upper()}")
        print(f"📦 Dependencies Available: {status['dependencies_available']}")
        
        print("\n🎯 System Capabilities:")
        capabilities = status['capabilities']
        
        # RAG System
        rag = capabilities['rag_system']
        print(f"   📚 RAG System: {'✅' if rag['available'] else '❌'}")
        print(f"      Documents indexed: {rag['documents_indexed']}")
        print(f"      Vector index size: {rag['vector_index_size']}")
        
        # Predictive Maintenance
        pred = capabilities['predictive_maintenance']
        print(f"   📈 Predictive Maintenance: {'✅' if pred['available'] else '❌'}")
        print(f"      Models loaded: {pred['models_loaded']}")
        print(f"      Predictions supported: {', '.join(pred['supported_predictions'])}")
        
        # NLP Processing
        nlp = capabilities['nlp_processing']
        print(f"   🗣️  NLP Processing: {'✅' if nlp['available'] else '❌'}")
        print(f"      Supported intents: {len(nlp['supported_intents'])}")
        print(f"      Intents: {', '.join(nlp['supported_intents'])}")
        
        # Voice Interface
        voice = capabilities['voice_interface']
        print(f"   🎤 Voice Interface: {'✅' if voice['available'] else '❌'}")
        print(f"      Confidence threshold: {voice['confidence_threshold']:.0%}")
        
        print("\n💾 Storage Locations:")
        for location, path in status['storage_locations'].items():
            print(f"   {location}: {path}")
            
    async def run_full_demo(self):
        """Run the complete AI pipeline demonstration"""
        self.print_banner("ChatterFix CMMS AI Pipeline Demo")
        
        print("🚀 Starting comprehensive AI demonstration...")
        print(f"⏰ Demo started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # 1. System Status
            await self.demo_ai_status()
            
            # 2. Create demo documents
            documents = self.create_demo_documents()
            
            # 3. RAG System
            self.demo_rag_system(documents)
            
            # 4. Predictive Maintenance  
            self.demo_predictive_maintenance()
            
            # 5. NLP Processing
            self.demo_nlp_processing()
            
            # Final status
            self.print_banner("Demo Complete")
            print("✅ All AI pipeline components successfully demonstrated!")
            print(f"📊 Final system status:")
            print(f"   Documents indexed: {self.doc_processor.vector_index.ntotal}")
            print(f"   Prediction models: Ready")
            print(f"   NLP processor: Operational")
            print(f"   Voice interface: Ready")
            
            print(f"\n🎉 Demo completed successfully at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            
        except Exception as e:
            print(f"❌ Demo failed with error: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    demo = AIPipelineDemo()
    asyncio.run(demo.run_full_demo())