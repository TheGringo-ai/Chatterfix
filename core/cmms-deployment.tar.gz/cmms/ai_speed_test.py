#!/usr/bin/env python3
"""
AI Provider Speed Test - Compare Grok vs Llama vs OpenAI
Tests actual response times for CMMS work order generation
"""

import asyncio
import time
import json
from ai_model_provider import CentralizedAIProvider, AIConfig

async def test_ai_speeds():
    """Test response times across all providers"""
    print("🚀 ChatterFix AI Speed Comparison Test")
    print("=" * 60)
    
    # Test prompt for work order generation
    test_prompt = "Generate a work order for maintenance on Pump-003. The pump is making unusual noise and vibrating. Priority: High. Include asset ID, description, estimated time, and required parts."
    
    # Test each provider
    providers_to_test = [
        {"name": "Grok", "priority": ["grok"], "expected_time": "7.7s"},
        {"name": "Llama", "priority": ["llama"], "expected_time": "25s"},
        {"name": "OpenAI", "priority": ["openai"], "expected_time": "8s"},
    ]
    
    results = []
    
    for provider_test in providers_to_test:
        print(f"\n🔧 Testing {provider_test['name']} (Expected: {provider_test['expected_time']})")
        print("-" * 50)
        
        try:
            # Configure provider
            config = AIConfig()
            config.provider_priority = provider_test["priority"] + ["fallback"]
            
            # Add API keys
            config.grok_api_key = os.getenv("XAI_API_KEY", "")
            config.grok_model = "grok-2-1212"
            
            ai_provider = CentralizedAIProvider(config)
            
            # Time the request
            start_time = time.time()
            response = await ai_provider.generate(
                message=test_prompt,
                context="work_order",
                system_prompt="You are ChatterFix CMMS AI. Generate concise, actionable work orders with specific technical details.",
                max_tokens=500,
                temperature=0.3
            )
            end_time = time.time()
            
            response_time = end_time - start_time
            
            print(f"✅ Provider: {response.provider.value}")
            print(f"✅ Model: {response.model}")
            print(f"✅ Response Time: {response_time:.2f}s ({response.response_time_ms}ms)")
            print(f"✅ Confidence: {response.confidence}")
            print(f"✅ Content Preview: {response.content[:150]}...")
            
            # Check if meets 7.7s goal
            meets_goal = response_time <= 7.7
            status = "🎯 MEETS GOAL" if meets_goal else "❌ TOO SLOW"
            print(f"✅ Status: {status}")
            
            results.append({
                "provider": provider_test["name"],
                "actual_provider": response.provider.value,
                "model": response.model,
                "response_time": response_time,
                "response_time_ms": response.response_time_ms,
                "confidence": response.confidence,
                "meets_goal": meets_goal,
                "expected": provider_test["expected_time"]
            })
            
        except Exception as e:
            print(f"❌ Error testing {provider_test['name']}: {str(e)}")
            results.append({
                "provider": provider_test["name"],
                "error": str(e),
                "meets_goal": False
            })
    
    # Summary Report
    print("\n" + "=" * 60)
    print("🏁 SPEED TEST SUMMARY - 7.7s Goal Analysis")
    print("=" * 60)
    
    successful_tests = [r for r in results if 'error' not in r]
    meeting_goal = [r for r in successful_tests if r['meets_goal']]
    
    print(f"📊 Total Tests: {len(results)}")
    print(f"✅ Successful: {len(successful_tests)}")
    print(f"🎯 Meeting Goal (≤7.7s): {len(meeting_goal)}")
    
    if successful_tests:
        fastest = min(successful_tests, key=lambda x: x['response_time'])
        slowest = max(successful_tests, key=lambda x: x['response_time'])
        
        print(f"\n🏃 Fastest: {fastest['provider']} ({fastest['response_time']:.2f}s)")
        print(f"🐌 Slowest: {slowest['provider']} ({slowest['response_time']:.2f}s)")
        
        avg_time = sum(r['response_time'] for r in successful_tests) / len(successful_tests)
        print(f"📈 Average: {avg_time:.2f}s")
    
    # Recommendations
    print("\n💡 RECOMMENDATIONS:")
    if meeting_goal:
        best_provider = min(meeting_goal, key=lambda x: x['response_time'])
        print(f"   • Use {best_provider['provider']} for real-time dashboard (fastest: {best_provider['response_time']:.2f}s)")
    
    slow_providers = [r for r in successful_tests if not r['meets_goal']]
    if slow_providers:
        print("   • Slow providers:")
        for provider in slow_providers:
            print(f"     - {provider['provider']}: {provider['response_time']:.2f}s (needs optimization)")
    
    print("\n🎯 FOR 7.7S DASHBOARD GOAL:")
    print("   • Dashboard should use fastest provider for real-time updates")
    print("   • Slow providers can be used for background/batch processing")
    print("   • Consider caching frequent requests")
    
    return results

if __name__ == "__main__":
    results = asyncio.run(test_ai_speeds())
    
    # Save results for analysis
    with open("ai_speed_test_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n💾 Results saved to ai_speed_test_results.json")