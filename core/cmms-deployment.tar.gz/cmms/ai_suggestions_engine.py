#!/usr/bin/env python3
"""
ChatterFix AI Suggestions Engine
Intelligent work order suggestions, parts recommendations, and technician optimization
"""

import os
import json
import logging
import asyncio
import re
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, Counter

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# AI suggestions router
ai_suggestions_router = APIRouter(prefix="/ai/suggestions", tags=["ai-suggestions"])

class WorkOrderSuggestion(BaseModel):
    type: str  # parts, tools, procedures, technician, duration, priority
    suggestion: str
    confidence: float
    reasoning: str
    estimated_cost: Optional[float] = None
    estimated_time: Optional[float] = None

class TechnicianRecommendation(BaseModel):
    technician_id: str
    technician_name: str
    skill_match_score: float
    availability_score: float
    overall_score: float
    reasoning: str
    estimated_completion_time: float

class PartsRecommendation(BaseModel):
    part_number: str
    part_name: str
    quantity: int
    confidence: float
    estimated_cost: float
    supplier: str
    lead_time_days: int
    alternative_parts: List[str]

class AISuggestionsEngine:
    def __init__(self):
        self.knowledge_base = {}
        self.technician_profiles = {}
        self.parts_database = {}
        self.historical_patterns = {}
        self.skill_matrix = {}
        
        # Initialize knowledge base
        asyncio.create_task(self.initialize_knowledge_base())
    
    async def initialize_knowledge_base(self):
        """Initialize AI knowledge base with maintenance procedures and patterns"""
        try:
            logger.info("🧠 Initializing AI suggestions knowledge base...")
            
            # Asset-specific maintenance procedures
            self.knowledge_base = {
                "pump": {
                    "common_issues": {
                        "not starting": {
                            "probable_causes": ["Power supply failure", "Motor burnout", "Control circuit issue"],
                            "procedures": ["Check power supply", "Test motor continuity", "Inspect control panel"],
                            "parts": ["motor_starter", "control_relay", "fuses"],
                            "estimated_time": 3.0
                        },
                        "low pressure": {
                            "probable_causes": ["Worn impeller", "Clogged intake", "Seal leakage"],
                            "procedures": ["Inspect impeller", "Clear intake screen", "Replace mechanical seal"],
                            "parts": ["impeller", "mechanical_seal", "intake_screen"],
                            "estimated_time": 4.5
                        },
                        "excessive vibration": {
                            "probable_causes": ["Misalignment", "Worn bearings", "Unbalanced impeller"],
                            "procedures": ["Check alignment", "Replace bearings", "Balance impeller"],
                            "parts": ["bearings", "coupling", "alignment_shims"],
                            "estimated_time": 6.0
                        }
                    },
                    "preventive_maintenance": {
                        "monthly": ["Check alignment", "Lubricate bearings", "Inspect seals"],
                        "quarterly": ["Replace seals", "Check impeller wear", "Test pressure"],
                        "annually": ["Overhaul pump", "Replace bearings", "Pressure test"]
                    },
                    "required_skills": ["mechanical", "hydraulics", "electrical"],
                    "common_tools": ["wrench_set", "alignment_tool", "pressure_gauge"]
                },
                
                "generator": {
                    "common_issues": {
                        "won't start": {
                            "probable_causes": ["Fuel system issue", "Battery failure", "Control system fault"],
                            "procedures": ["Check fuel level", "Test battery", "Inspect control panel"],
                            "parts": ["fuel_filter", "battery", "control_module"],
                            "estimated_time": 2.5
                        },
                        "low power output": {
                            "probable_causes": ["Dirty air filter", "Fuel contamination", "Engine wear"],
                            "procedures": ["Replace air filter", "Drain fuel tank", "Check compression"],
                            "parts": ["air_filter", "fuel_filter", "spark_plugs"],
                            "estimated_time": 3.5
                        }
                    },
                    "preventive_maintenance": {
                        "weekly": ["Check fuel level", "Test auto-start", "Inspect for leaks"],
                        "monthly": ["Change oil", "Replace air filter", "Test load bank"],
                        "annually": ["Service cooling system", "Replace spark plugs", "Overhaul engine"]
                    },
                    "required_skills": ["electrical", "engine_repair", "controls"],
                    "common_tools": ["multimeter", "compression_tester", "load_bank"]
                },
                
                "hvac": {
                    "common_issues": {
                        "not cooling": {
                            "probable_causes": ["Low refrigerant", "Dirty condenser", "Compressor failure"],
                            "procedures": ["Check refrigerant levels", "Clean condenser coils", "Test compressor"],
                            "parts": ["refrigerant", "contactor", "compressor"],
                            "estimated_time": 4.0
                        },
                        "poor airflow": {
                            "probable_causes": ["Clogged filter", "Blower motor issue", "Ductwork obstruction"],
                            "procedures": ["Replace filter", "Service blower motor", "Inspect ductwork"],
                            "parts": ["air_filter", "blower_motor", "fan_belt"],
                            "estimated_time": 2.0
                        }
                    },
                    "preventive_maintenance": {
                        "monthly": ["Replace filters", "Check thermostat", "Inspect ductwork"],
                        "quarterly": ["Clean coils", "Check refrigerant", "Lubricate motors"],
                        "annually": ["Service compressor", "Check electrical connections", "Calibrate controls"]
                    },
                    "required_skills": ["hvac", "electrical", "refrigeration"],
                    "common_tools": ["manifold_gauges", "leak_detector", "recovery_unit"]
                },
                
                "conveyor": {
                    "common_issues": {
                        "belt slipping": {
                            "probable_causes": ["Loose belt tension", "Worn pulley", "Overloaded conveyor"],
                            "procedures": ["Adjust belt tension", "Replace worn pulleys", "Check load capacity"],
                            "parts": ["drive_belt", "pulley", "tension_hardware"],
                            "estimated_time": 2.5
                        },
                        "motor overheating": {
                            "probable_causes": ["Overload", "Poor ventilation", "Motor failure"],
                            "procedures": ["Check load", "Clean ventilation", "Test motor"],
                            "parts": ["motor", "thermal_overload", "ventilation_fan"],
                            "estimated_time": 3.0
                        }
                    },
                    "preventive_maintenance": {
                        "weekly": ["Check belt tension", "Lubricate bearings", "Inspect safety guards"],
                        "monthly": ["Check alignment", "Clean drive components", "Test emergency stops"],
                        "quarterly": ["Replace drive belt", "Service motor", "Check electrical connections"]
                    },
                    "required_skills": ["mechanical", "electrical", "safety_systems"],
                    "common_tools": ["belt_tensioner", "alignment_tool", "torque_wrench"]
                }
            }
            
            # Initialize technician profiles
            self.technician_profiles = {
                "TECH-001": {
                    "name": "Mike Johnson",
                    "skills": {"mechanical": 9, "electrical": 7, "hydraulics": 8, "safety_systems": 8},
                    "certifications": ["pump_specialist", "safety_certified"],
                    "experience_years": 12,
                    "avg_completion_rate": 0.92,
                    "current_workload": 6,  # hours this week
                    "max_workload": 40
                },
                "TECH-002": {
                    "name": "Sarah Davis",
                    "skills": {"electrical": 9, "controls": 8, "hvac": 7, "refrigeration": 9},
                    "certifications": ["electrical_master", "hvac_certified", "epa_certified"],
                    "experience_years": 8,
                    "avg_completion_rate": 0.89,
                    "current_workload": 12,
                    "max_workload": 40
                },
                "TECH-003": {
                    "name": "David Wilson",
                    "skills": {"mechanical": 8, "engine_repair": 9, "electrical": 6, "hydraulics": 7},
                    "certifications": ["engine_specialist", "diesel_certified"],
                    "experience_years": 15,
                    "avg_completion_rate": 0.95,
                    "current_workload": 8,
                    "max_workload": 40
                },
                "TECH-004": {
                    "name": "Lisa Chen",
                    "skills": {"electrical": 8, "controls": 9, "safety_systems": 8, "mechanical": 6},
                    "certifications": ["controls_specialist", "plc_programmer"],
                    "experience_years": 6,
                    "avg_completion_rate": 0.87,
                    "current_workload": 15,
                    "max_workload": 40
                }
            }
            
            # Initialize parts database
            self.parts_database = {
                "motor_starter": {
                    "name": "Motor Starter, 3-Phase, 15HP",
                    "cost": 245.00,
                    "supplier": "ElectricCorp",
                    "lead_time": 3,
                    "alternatives": ["motor_starter_alt1", "motor_starter_alt2"]
                },
                "mechanical_seal": {
                    "name": "Mechanical Seal, Standard Duty",
                    "cost": 89.50,
                    "supplier": "SealTech",
                    "lead_time": 5,
                    "alternatives": ["seal_premium", "seal_economy"]
                },
                "impeller": {
                    "name": "Centrifugal Pump Impeller, 6-inch",
                    "cost": 425.00,
                    "supplier": "PumpParts Inc",
                    "lead_time": 7,
                    "alternatives": ["impeller_stainless", "impeller_bronze"]
                },
                "air_filter": {
                    "name": "HVAC Air Filter, MERV 8, 20x25x1",
                    "cost": 12.50,
                    "supplier": "FilterMax",
                    "lead_time": 1,
                    "alternatives": ["filter_merv11", "filter_merv13"]
                },
                "drive_belt": {
                    "name": "V-Belt, Industrial Grade",
                    "cost": 35.00,
                    "supplier": "BeltCorp",
                    "lead_time": 2,
                    "alternatives": ["timing_belt", "synchronous_belt"]
                }
            }
            
            logger.info("✅ AI suggestions knowledge base initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize knowledge base: {e}")
    
    async def analyze_work_order_for_suggestions(self, work_order_data: Dict) -> List[WorkOrderSuggestion]:
        """Analyze work order and generate AI suggestions"""
        try:
            suggestions = []
            
            title = work_order_data.get("title", "").lower()
            description = work_order_data.get("description", "").lower()
            asset_type = work_order_data.get("asset_type", "unknown").lower()
            
            # Combine text for analysis
            combined_text = f"{title} {description}"
            
            # Get asset-specific knowledge
            asset_knowledge = self.knowledge_base.get(asset_type, {})
            
            # Analyze for issue patterns
            issue_suggestions = self.identify_issue_patterns(combined_text, asset_knowledge)
            suggestions.extend(issue_suggestions)
            
            # Generate parts suggestions
            parts_suggestions = self.suggest_parts(combined_text, asset_knowledge)
            suggestions.extend(parts_suggestions)
            
            # Generate procedure suggestions
            procedure_suggestions = self.suggest_procedures(combined_text, asset_knowledge)
            suggestions.extend(procedure_suggestions)
            
            # Generate duration estimates
            duration_suggestion = self.estimate_duration(combined_text, asset_knowledge)
            if duration_suggestion:
                suggestions.append(duration_suggestion)
            
            # Generate priority recommendations
            priority_suggestion = self.suggest_priority(combined_text)
            if priority_suggestion:
                suggestions.append(priority_suggestion)
            
            # Sort by confidence score
            suggestions.sort(key=lambda x: x.confidence, reverse=True)
            
            return suggestions[:8]  # Return top 8 suggestions
            
        except Exception as e:
            logger.error(f"❌ Work order analysis failed: {e}")
            return []
    
    def identify_issue_patterns(self, text: str, asset_knowledge: Dict) -> List[WorkOrderSuggestion]:
        """Identify common issue patterns and suggest solutions"""
        suggestions = []
        
        try:
            common_issues = asset_knowledge.get("common_issues", {})
            
            for issue_type, issue_data in common_issues.items():
                # Check if text matches issue pattern
                issue_keywords = issue_type.split()
                keyword_matches = sum(1 for keyword in issue_keywords if keyword in text)
                
                if keyword_matches > 0:
                    confidence = min(0.9, keyword_matches / len(issue_keywords) * 0.8 + 0.1)
                    
                    # Add procedure suggestion
                    procedures = issue_data.get("procedures", [])
                    if procedures:
                        suggestion_text = f"Recommended procedures: {', '.join(procedures[:3])}"
                        suggestions.append(WorkOrderSuggestion(
                            type="procedures",
                            suggestion=suggestion_text,
                            confidence=confidence,
                            reasoning=f"Pattern match for '{issue_type}' issue",
                            estimated_time=issue_data.get("estimated_time", 2.0)
                        ))
            
            return suggestions
            
        except Exception as e:
            logger.error(f"❌ Issue pattern identification failed: {e}")
            return []
    
    def suggest_parts(self, text: str, asset_knowledge: Dict) -> List[WorkOrderSuggestion]:
        """Suggest parts based on work order description"""
        suggestions = []
        
        try:
            # Check for part-related keywords
            part_keywords = {
                "seal": ["mechanical_seal", "o_ring", "gasket"],
                "belt": ["drive_belt", "timing_belt", "v_belt"],
                "filter": ["air_filter", "oil_filter", "fuel_filter"],
                "motor": ["motor_starter", "motor", "contactor"],
                "bearing": ["bearings", "bearing_set", "grease"],
                "impeller": ["impeller", "pump_parts"],
                "battery": ["battery", "battery_charger"],
                "fuse": ["fuses", "circuit_breaker"]
            }
            
            for keyword, part_numbers in part_keywords.items():
                if keyword in text:
                    for part_number in part_numbers[:2]:  # Top 2 parts per keyword
                        part_info = self.parts_database.get(part_number, {})
                        if part_info:
                            suggestions.append(WorkOrderSuggestion(
                                type="parts",
                                suggestion=f"Consider ordering: {part_info.get('name', part_number)}",
                                confidence=0.7,
                                reasoning=f"Keyword '{keyword}' detected in description",
                                estimated_cost=part_info.get('cost', 50.0)
                            ))
            
            # Check asset-specific common issues
            common_issues = asset_knowledge.get("common_issues", {})
            for issue_type, issue_data in common_issues.items():
                if any(word in text for word in issue_type.split()):
                    parts = issue_data.get("parts", [])
                    for part_number in parts[:2]:
                        part_info = self.parts_database.get(part_number, {})
                        if part_info:
                            suggestions.append(WorkOrderSuggestion(
                                type="parts",
                                suggestion=f"Likely needed: {part_info.get('name', part_number)}",
                                confidence=0.8,
                                reasoning=f"Common part for '{issue_type}' issues",
                                estimated_cost=part_info.get('cost', 50.0)
                            ))
            
            return suggestions
            
        except Exception as e:
            logger.error(f"❌ Parts suggestion failed: {e}")
            return []
    
    def suggest_procedures(self, text: str, asset_knowledge: Dict) -> List[WorkOrderSuggestion]:
        """Suggest maintenance procedures"""
        suggestions = []
        
        try:
            # Safety-related procedures
            if any(word in text for word in ["emergency", "hazard", "danger", "leak", "fire"]):
                suggestions.append(WorkOrderSuggestion(
                    type="procedures",
                    suggestion="🚨 Follow lockout/tagout procedures before starting work",
                    confidence=0.95,
                    reasoning="Safety keywords detected in description",
                    estimated_time=0.5
                ))
            
            # Electrical work procedures
            if any(word in text for word in ["electrical", "motor", "power", "voltage", "circuit"]):
                suggestions.append(WorkOrderSuggestion(
                    type="procedures", 
                    suggestion="⚡ De-energize equipment and verify zero energy state",
                    confidence=0.9,
                    reasoning="Electrical work procedures required",
                    estimated_time=0.25
                ))
            
            # Preventive maintenance suggestions
            pm_procedures = asset_knowledge.get("preventive_maintenance", {})
            if "maintenance" in text or "service" in text:
                monthly_tasks = pm_procedures.get("monthly", [])
                if monthly_tasks:
                    suggestions.append(WorkOrderSuggestion(
                        type="procedures",
                        suggestion=f"Include monthly PM tasks: {', '.join(monthly_tasks[:3])}",
                        confidence=0.75,
                        reasoning="Preventive maintenance opportunity identified",
                        estimated_time=1.0
                    ))
            
            return suggestions
            
        except Exception as e:
            logger.error(f"❌ Procedure suggestion failed: {e}")
            return []
    
    def estimate_duration(self, text: str, asset_knowledge: Dict) -> Optional[WorkOrderSuggestion]:
        """Estimate work order duration based on description"""
        try:
            base_duration = 2.0  # Default 2 hours
            
            # Check for complexity indicators
            complexity_factors = {
                "replace": 1.5,
                "rebuild": 3.0,
                "overhaul": 4.0,
                "emergency": 1.2,
                "inspect": 0.5,
                "clean": 0.8,
                "adjust": 0.6,
                "repair": 2.0,
                "install": 2.5
            }
            
            duration_multiplier = 1.0
            matched_keywords = []
            
            for keyword, multiplier in complexity_factors.items():
                if keyword in text:
                    duration_multiplier = max(duration_multiplier, multiplier)
                    matched_keywords.append(keyword)
            
            # Check asset-specific duration estimates
            common_issues = asset_knowledge.get("common_issues", {})
            for issue_type, issue_data in common_issues.items():
                if any(word in text for word in issue_type.split()):
                    base_duration = issue_data.get("estimated_time", base_duration)
                    break
            
            estimated_duration = base_duration * duration_multiplier
            
            confidence = 0.7 if matched_keywords else 0.6
            reasoning = f"Based on keywords: {', '.join(matched_keywords)}" if matched_keywords else "Based on average task complexity"
            
            return WorkOrderSuggestion(
                type="duration",
                suggestion=f"Estimated duration: {estimated_duration:.1f} hours",
                confidence=confidence,
                reasoning=reasoning,
                estimated_time=estimated_duration
            )
            
        except Exception as e:
            logger.error(f"❌ Duration estimation failed: {e}")
            return None
    
    def suggest_priority(self, text: str) -> Optional[WorkOrderSuggestion]:
        """Suggest work order priority based on description"""
        try:
            priority_keywords = {
                "critical": ["emergency", "down", "failed", "broken", "leak", "fire", "safety"],
                "high": ["urgent", "asap", "important", "problem", "issue", "malfunction"],
                "medium": ["maintenance", "service", "replace", "repair", "worn"],
                "low": ["clean", "inspect", "routine", "scheduled", "when convenient"]
            }
            
            priority_scores = {}
            
            for priority, keywords in priority_keywords.items():
                score = sum(1 for keyword in keywords if keyword in text)
                if score > 0:
                    priority_scores[priority] = score
            
            if priority_scores:
                # Manual max to satisfy static checker
                suggested_priority = None
                max_score = -1
                for p, sc in priority_scores.items():
                    if sc > max_score:
                        suggested_priority = p
                        max_score = sc
                total = sum(priority_scores.values()) or 1
                confidence = min(0.95, 0.5 + (max_score / total) * 0.4)
                suggestion_text = f"Recommended priority: {suggested_priority.upper()}" if suggested_priority else "Priority inferred"
                return WorkOrderSuggestion(
                    type="priority",
                    suggestion=suggestion_text,
                    confidence=confidence,
                    reasoning=f"Keywords indicate {suggested_priority} priority level (matches: {max_score}/{total})" if suggested_priority else "Heuristic priority inference"
                )
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Priority suggestion failed: {e}")
            return None
    
    async def recommend_technician(self, work_order_data: Dict) -> List[TechnicianRecommendation]:
        """Recommend best technician for work order based on skills and availability"""
        try:
            recommendations = []
            
            # Extract required skills from work order
            asset_type = work_order_data.get("asset_type", "").lower()
            description = work_order_data.get("description", "").lower()
            
            # Get required skills for asset type
            asset_knowledge = self.knowledge_base.get(asset_type, {})
            required_skills = asset_knowledge.get("required_skills", ["mechanical"])
            
            # Add skills based on description keywords
            skill_keywords = {
                "electrical": ["electrical", "motor", "power", "voltage", "wiring"],
                "hydraulics": ["pump", "pressure", "hydraulic", "fluid"],
                "mechanical": ["mechanical", "bearing", "alignment", "coupling"],
                "hvac": ["hvac", "cooling", "heating", "refrigeration"],
                "controls": ["control", "plc", "sensor", "automation"],
                "engine_repair": ["engine", "generator", "diesel", "fuel"],
                "safety_systems": ["safety", "emergency", "alarm", "lockout"]
            }
            
            description_skills = []
            for skill, keywords in skill_keywords.items():
                if any(keyword in description for keyword in keywords):
                    description_skills.append(skill)
            
            # Combine required skills
            all_required_skills = list(set(required_skills + description_skills))
            
            # Evaluate each technician
            for tech_id, tech_data in self.technician_profiles.items():
                # Calculate skill match score
                tech_skills = tech_data["skills"]
                skill_scores = []
                
                for skill in all_required_skills:
                    skill_level = tech_skills.get(skill, 0)
                    skill_scores.append(skill_level)
                
                if skill_scores:
                    skill_match_score = sum(skill_scores) / len(skill_scores) / 10  # Normalize to 0-1
                else:
                    skill_match_score = 0.5  # Default if no matching skills
                
                # Calculate availability score
                current_workload = tech_data["current_workload"]
                max_workload = tech_data["max_workload"]
                availability_score = max(0, (max_workload - current_workload) / max_workload)
                
                # Consider experience and completion rate
                experience_bonus = min(0.2, tech_data["experience_years"] * 0.01)
                completion_rate_bonus = tech_data["avg_completion_rate"] * 0.1
                
                # Calculate overall score
                overall_score = (
                    skill_match_score * 0.5 + 
                    availability_score * 0.3 + 
                    experience_bonus + 
                    completion_rate_bonus
                )
                
                # Estimate completion time
                base_time = work_order_data.get("estimated_hours", 4.0)
                skill_efficiency = skill_match_score * 1.2 + 0.8  # 0.8 to 2.0 multiplier
                estimated_completion_time = base_time / skill_efficiency
                
                # Generate reasoning
                reasoning_parts = []
                if skill_match_score > 0.7:
                    reasoning_parts.append(f"Strong skill match ({skill_match_score:.1%})")
                if availability_score > 0.7:
                    reasoning_parts.append(f"High availability ({availability_score:.1%})")
                if tech_data["experience_years"] > 10:
                    reasoning_parts.append(f"Experienced ({tech_data['experience_years']} years)")
                if tech_data["avg_completion_rate"] > 0.9:
                    reasoning_parts.append("High completion rate")
                
                reasoning = "; ".join(reasoning_parts) or "General technician qualifications"
                
                recommendations.append(TechnicianRecommendation(
                    technician_id=tech_id,
                    technician_name=tech_data["name"],
                    skill_match_score=skill_match_score,
                    availability_score=availability_score,
                    overall_score=overall_score,
                    reasoning=reasoning,
                    estimated_completion_time=estimated_completion_time
                ))
            
            # Sort by overall score
            recommendations.sort(key=lambda x: x.overall_score, reverse=True)
            
            return recommendations
            
        except Exception as e:
            logger.error(f"❌ Technician recommendation failed: {e}")
            return []
    
    async def suggest_parts_for_work_order(self, work_order_data: Dict) -> List[PartsRecommendation]:
        """Generate detailed parts recommendations for work order"""
        try:
            recommendations = []
            
            title = work_order_data.get("title", "").lower()
            description = work_order_data.get("description", "").lower()
            asset_type = work_order_data.get("asset_type", "").lower()
            
            combined_text = f"{title} {description}"
            
            # Get asset-specific knowledge
            asset_knowledge = self.knowledge_base.get(asset_type, {})
            
            # Check common issues for part suggestions
            common_issues = asset_knowledge.get("common_issues", {})
            suggested_parts = set()
            
            for issue_type, issue_data in common_issues.items():
                if any(word in combined_text for word in issue_type.split()):
                    parts = issue_data.get("parts", [])
                    suggested_parts.update(parts)
            
            # Add parts based on keywords
            part_keywords = {
                "seal": ["mechanical_seal", "o_ring"],
                "belt": ["drive_belt", "v_belt"],
                "filter": ["air_filter", "oil_filter"],
                "motor": ["motor_starter", "motor"],
                "bearing": ["bearings"],
                "impeller": ["impeller"],
                "battery": ["battery"]
            }
            
            for keyword, part_list in part_keywords.items():
                if keyword in combined_text:
                    suggested_parts.update(part_list)
            
            # Generate recommendations for suggested parts
            for part_number in list(suggested_parts)[:6]:  # Limit to 6 parts
                part_info = self.parts_database.get(part_number, {})
                
                if part_info:
                    # Calculate confidence based on keyword matches
                    confidence = 0.6
                    if any(keyword in combined_text for keyword in part_number.split('_')):
                        confidence += 0.2
                    
                    recommendations.append(PartsRecommendation(
                        part_number=part_number,
                        part_name=part_info.get("name", part_number.replace('_', ' ').title()),
                        quantity=1,
                        confidence=min(0.9, confidence),
                        estimated_cost=part_info.get("cost", 50.0),
                        supplier=part_info.get("supplier", "Standard Supplier"),
                        lead_time_days=part_info.get("lead_time", 5),
                        alternative_parts=part_info.get("alternatives", [])
                    ))
            
            # Sort by confidence
            recommendations.sort(key=lambda x: x.confidence, reverse=True)
            
            return recommendations
            
        except Exception as e:
            logger.error(f"❌ Parts recommendation failed: {e}")
            return []

# Initialize global suggestions engine
ai_suggestions_engine = AISuggestionsEngine()

# API Endpoints
@ai_suggestions_router.post("/work-order-analysis")
async def analyze_work_order(work_order_data: Dict[str, Any]):
    """Analyze work order and return AI suggestions"""
    try:
        suggestions = await ai_suggestions_engine.analyze_work_order_for_suggestions(work_order_data)
        
        return JSONResponse({
            "success": True,
            "work_order_id": work_order_data.get("id", "unknown"),
            "suggestions": [suggestion.dict() for suggestion in suggestions],
            "total_suggestions": len(suggestions),
            "confidence_score": (sum(s.confidence for s in suggestions) / len(suggestions)) if suggestions else 0.0
        })
        
    except Exception as e:
        logger.error(f"❌ Work order analysis failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_suggestions_router.post("/recommend-technician")
async def recommend_technician_for_work_order(work_order_data: Dict[str, Any]):
    """Recommend best technician for work order"""
    try:
        recommendations = await ai_suggestions_engine.recommend_technician(work_order_data)
        
        return JSONResponse({
            "success": True,
            "work_order_id": work_order_data.get("id", "unknown"),
            "recommendations": [rec.dict() for rec in recommendations],
            "best_match": recommendations[0].dict() if recommendations else None
        })
        
    except Exception as e:
        logger.error(f"❌ Technician recommendation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_suggestions_router.post("/recommend-parts")
async def recommend_parts_for_work_order(work_order_data: Dict[str, Any]):
    """Recommend parts for work order"""
    try:
        recommendations = await ai_suggestions_engine.suggest_parts_for_work_order(work_order_data)
        
        total_cost = sum(rec.estimated_cost for rec in recommendations)
        
        return JSONResponse({
            "success": True,
            "work_order_id": work_order_data.get("id", "unknown"),
            "parts_recommendations": [rec.dict() for rec in recommendations],
            "total_estimated_cost": total_cost,
            "total_parts": len(recommendations)
        })
        
    except Exception as e:
        logger.error(f"❌ Parts recommendation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_suggestions_router.get("/knowledge-base/assets")
async def get_asset_knowledge():
    """Get asset knowledge base for reference"""
    return JSONResponse({
        "asset_types": list(ai_suggestions_engine.knowledge_base.keys()),
        "knowledge_base": ai_suggestions_engine.knowledge_base
    })

@ai_suggestions_router.get("/technicians")
async def get_technician_profiles():
    """Get technician profiles and capabilities"""
    return JSONResponse({
        "technicians": ai_suggestions_engine.technician_profiles,
        "total_technicians": len(ai_suggestions_engine.technician_profiles)
    })

@ai_suggestions_router.get("/parts-database")
async def get_parts_database():
    """Get parts database for reference"""
    return JSONResponse({
        "parts": ai_suggestions_engine.parts_database,
        "total_parts": len(ai_suggestions_engine.parts_database)
    })