#!/usr/bin/env python3
"""
ChatterFix CMMS - AI Ops Agent
Intelligent log analysis, incident classification, and automated response
"""

import os
import re
import json
import time
import logging
import asyncio
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional, Tuple, Callable
from pathlib import Path
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
import subprocess

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class LogEntry:
    """Structured log entry"""
    timestamp: datetime
    level: str
    service: str
    message: str
    raw_line: str
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

@dataclass
class IncidentSignature:
    """Pattern for incident detection"""
    name: str
    description: str
    patterns: List[str]  # Regex patterns
    severity: str  # critical, warning, info
    category: str  # service, performance, security, etc.
    auto_remediate: bool = True
    cooldown_minutes: int = 5

@dataclass
class DetectedIncident:
    """A detected incident"""
    signature: IncidentSignature
    timestamp: datetime
    log_entries: List[LogEntry]
    confidence: float
    context: Dict[str, Any]
    resolved: bool = False
    resolution: Optional[str] = None

class LogAnalyzer:
    """Intelligent log analysis engine"""
    
    def __init__(self):
        self.incident_signatures = self._load_incident_signatures()
        self.log_buffer = deque(maxlen=10000)  # Keep recent log entries
        self.incident_history = []
        
        # Pattern compilation for performance
        self.compiled_patterns = {}
        for signature in self.incident_signatures:
            self.compiled_patterns[signature.name] = [
                re.compile(pattern, re.IGNORECASE) for pattern in signature.patterns
            ]
        
        logger.info("🔍 Log Analyzer initialized with {} incident signatures".format(len(self.incident_signatures)))
    
    def _load_incident_signatures(self) -> List[IncidentSignature]:
        """Load incident detection patterns"""
        signatures = []
        
        # Service failures
        signatures.append(IncidentSignature(
            name="service_crash",
            description="Service process crash or unexpected exit",
            patterns=[
                r"systemd.*failed.*service",
                r"process.*terminated.*signal",
                r"exited with code [1-9]",
                r"service.*stopped.*unexpectedly"
            ],
            severity="critical",
            category="service",
            auto_remediate=True
        ))
        
        # High resource usage
        signatures.append(IncidentSignature(
            name="high_cpu_usage",
            description="CPU usage exceeding threshold",
            patterns=[
                r"cpu usage.*(?:9[0-9]|100)%",
                r"high cpu.*(?:load|usage)",
                r"cpu.*overload"
            ],
            severity="warning", 
            category="performance",
            auto_remediate=True
        ))
        
        signatures.append(IncidentSignature(
            name="high_memory_usage", 
            description="Memory usage exceeding threshold",
            patterns=[
                r"memory usage.*(?:9[0-9]|100)%",
                r"out of memory",
                r"oom.*killer",
                r"memory.*exhausted"
            ],
            severity="critical",
            category="performance",
            auto_remediate=True
        ))
        
        # Disk space issues
        signatures.append(IncidentSignature(
            name="disk_space_low",
            description="Disk space running low",
            patterns=[
                r"disk.*(?:9[0-9]|100)%.*full",
                r"no space left on device",
                r"disk space.*critical",
                r"filesystem.*full"
            ],
            severity="critical",
            category="storage",
            auto_remediate=True
        ))
        
        # Database issues
        signatures.append(IncidentSignature(
            name="database_connection_error",
            description="Database connection failures",
            patterns=[
                r"database.*connection.*failed",
                r"sqlite.*locked", 
                r"connection.*refused.*database",
                r"database.*timeout"
            ],
            severity="critical",
            category="database",
            auto_remediate=True
        ))
        
        # SSL/Certificate issues
        signatures.append(IncidentSignature(
            name="ssl_certificate_error",
            description="SSL certificate problems",
            patterns=[
                r"certificate.*expired",
                r"ssl.*handshake.*failed",
                r"certificate.*invalid",
                r"tls.*error"
            ],
            severity="critical",
            category="security",
            auto_remediate=True
        ))
        
        # Network issues
        signatures.append(IncidentSignature(
            name="network_connectivity",
            description="Network connectivity problems",
            patterns=[
                r"network.*unreachable",
                r"connection.*timeout",
                r"dns.*resolution.*failed",
                r"host.*not.*found"
            ],
            severity="warning",
            category="network",
            auto_remediate=False
        ))
        
        # Application errors
        signatures.append(IncidentSignature(
            name="application_error_spike",
            description="High rate of application errors",
            patterns=[
                r"error.*rate.*high",
                r"exception.*flood",
                r"traceback.*python",
                r"internal.*server.*error"
            ],
            severity="warning",
            category="application",
            auto_remediate=False
        ))
        
        # Security incidents
        signatures.append(IncidentSignature(
            name="authentication_failure_spike",
            description="Unusual authentication failures",
            patterns=[
                r"authentication.*failed.*repeatedly",
                r"login.*failed.*\d{3,}.*times",
                r"brute.*force.*detected",
                r"suspicious.*login.*activity"
            ],
            severity="critical",
            category="security",
            auto_remediate=False,
            cooldown_minutes=15
        ))
        
        return signatures
    
    def parse_log_line(self, line: str, source: str = "unknown") -> Optional[LogEntry]:
        """Parse a single log line into structured format"""
        try:
            # Common log patterns
            patterns = [
                # Systemd journal format
                r'(?P<timestamp>\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+(?P<service>\S+):\s*(?P<message>.*)',
                # Python logging format
                r'(?P<timestamp>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}),\d+\s+-\s+(?P<service>\S+)\s+-\s+(?P<level>\w+)\s+-\s+(?P<message>.*)',
                # Nginx access/error log
                r'(?P<timestamp>\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})\s+\[(?P<level>\w+)\].*?(?P<message>.*)',
                # Generic timestamp pattern
                r'(?P<timestamp>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?).*?(?P<level>ERROR|WARN|INFO|DEBUG)?.*?(?P<message>.*)'
            ]
            
            log_entry = None
            
            for pattern in patterns:
                match = re.match(pattern, line)
                if match:
                    groups = match.groupdict()
                    
                    # Parse timestamp
                    timestamp_str = groups.get('timestamp', '')
                    timestamp = self._parse_timestamp(timestamp_str)
                    
                    log_entry = LogEntry(
                        timestamp=timestamp,
                        level=groups.get('level', 'INFO').upper(),
                        service=groups.get('service', source),
                        message=groups.get('message', line).strip(),
                        raw_line=line
                    )
                    break
            
            # If no pattern matched, create basic entry
            if not log_entry:
                log_entry = LogEntry(
                    timestamp=datetime.now(timezone.utc),
                    level='INFO',
                    service=source,
                    message=line.strip(),
                    raw_line=line
                )
            
            return log_entry
            
        except Exception as e:
            logger.warning(f"Failed to parse log line: {e}")
            return None
    
    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """Parse various timestamp formats"""
        formats = [
            '%Y-%m-%d %H:%M:%S',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%S.%fZ',
            '%Y-%m-%dT%H:%M:%S%z',
            '%Y/%m/%d %H:%M:%S',
            '%b %d %H:%M:%S'  # syslog format
        ]
        
        for fmt in formats:
            try:
                if fmt == '%b %d %H:%M:%S':
                    # Add current year for syslog format
                    timestamp_str = f"{datetime.now().year} {timestamp_str}"
                    fmt = '%Y %b %d %H:%M:%S'
                
                dt = datetime.strptime(timestamp_str, fmt)
                
                # Add timezone if not present
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                
                return dt
                
            except ValueError:
                continue
        
        # If all parsing fails, return current time
        return datetime.now(timezone.utc)
    
    def analyze_log_entry(self, log_entry: LogEntry) -> List[DetectedIncident]:
        """Analyze a single log entry for incidents"""
        incidents = []
        
        for signature in self.incident_signatures:
            patterns = self.compiled_patterns[signature.name]
            
            # Check if any pattern matches
            for pattern in patterns:
                if pattern.search(log_entry.message) or pattern.search(log_entry.raw_line):
                    incident = DetectedIncident(
                        signature=signature,
                        timestamp=log_entry.timestamp,
                        log_entries=[log_entry],
                        confidence=0.8,  # Base confidence
                        context={
                            'matched_pattern': pattern.pattern,
                            'service': log_entry.service,
                            'level': log_entry.level
                        }
                    )
                    
                    incidents.append(incident)
                    break  # Only match first pattern per signature
        
        return incidents
    
    def analyze_log_batch(self, log_entries: List[LogEntry], window_minutes: int = 5) -> List[DetectedIncident]:
        """Analyze a batch of log entries for patterns"""
        incidents = []
        
        # Group entries by time windows
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(minutes=window_minutes)
        
        recent_entries = [
            entry for entry in log_entries
            if entry.timestamp >= window_start
        ]
        
        if not recent_entries:
            return incidents
        
        # Analyze individual entries
        for entry in recent_entries:
            entry_incidents = self.analyze_log_entry(entry)
            incidents.extend(entry_incidents)
        
        # Look for patterns across multiple entries
        incidents.extend(self._detect_aggregate_patterns(recent_entries))
        
        return incidents
    
    def _detect_aggregate_patterns(self, log_entries: List[LogEntry]) -> List[DetectedIncident]:
        """Detect patterns that require multiple log entries"""
        incidents = []
        
        # Error rate spike detection
        error_entries = [e for e in log_entries if e.level in ['ERROR', 'CRITICAL']]
        
        if len(error_entries) > 10:  # More than 10 errors in window
            # Find error spike signature
            error_spike_sig = next(
                (s for s in self.incident_signatures if s.name == 'application_error_spike'),
                None
            )
            
            if error_spike_sig:
                incidents.append(DetectedIncident(
                    signature=error_spike_sig,
                    timestamp=max(e.timestamp for e in error_entries),
                    log_entries=error_entries[-5:],  # Include last 5 errors
                    confidence=0.9,
                    context={
                        'error_count': len(error_entries),
                        'time_window_minutes': 5,
                        'rate_per_minute': len(error_entries) / 5
                    }
                ))
        
        # Authentication failure detection
        auth_failures = [
            e for e in log_entries
            if re.search(r'(failed|denied|unauthorized|forbidden)', e.message, re.IGNORECASE)
        ]
        
        if len(auth_failures) > 20:  # Suspicious auth activity
            auth_spike_sig = next(
                (s for s in self.incident_signatures if s.name == 'authentication_failure_spike'),
                None
            )
            
            if auth_spike_sig:
                incidents.append(DetectedIncident(
                    signature=auth_spike_sig,
                    timestamp=max(e.timestamp for e in auth_failures),
                    log_entries=auth_failures[-10:],
                    confidence=0.95,
                    context={
                        'failure_count': len(auth_failures),
                        'potential_attack': True
                    }
                ))
        
        return incidents

class AIOperationsAgent:
    """Main AI Operations agent orchestrating analysis and response"""
    
    def __init__(self, ai_memory_dir: str = "ai-memory"):
        self.ai_memory_dir = Path(ai_memory_dir)
        self.sessions_dir = self.ai_memory_dir / "sessions"
        self.lessons_dir = self.ai_memory_dir / "lessons"
        
        # Ensure directories exist
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.lessons_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.log_analyzer = LogAnalyzer()
        self.active_incidents = {}
        self.incident_history = []
        
        # Log sources to monitor
        self.log_sources = {
            'systemd': self._tail_systemd_journal,
            'application': self._tail_application_logs,
            'nginx': self._tail_nginx_logs
        }
        
        logger.info("🤖 AI Operations Agent initialized")
    
    async def start_monitoring(self):
        """Start continuous log monitoring and analysis"""
        logger.info("🔍 Starting continuous log monitoring...")
        
        # Start log tailing tasks
        tasks = []
        for source_name, source_func in self.log_sources.items():
            task = asyncio.create_task(
                self._monitor_log_source(source_name, source_func)
            )
            tasks.append(task)
        
        # Start incident analysis task
        analysis_task = asyncio.create_task(self._continuous_analysis())
        tasks.append(analysis_task)
        
        # Start daily summary task
        summary_task = asyncio.create_task(self._daily_summary_generator())
        tasks.append(summary_task)
        
        # Wait for all tasks
        await asyncio.gather(*tasks)
    
    async def _monitor_log_source(self, source_name: str, source_func: Callable):
        """Monitor a specific log source"""
        logger.info(f"📊 Starting monitoring for {source_name}")
        
        while True:
            try:
                async for log_line in source_func():
                    if log_line:
                        log_entry = self.log_analyzer.parse_log_line(log_line, source_name)
                        if log_entry:
                            self.log_analyzer.log_buffer.append(log_entry)
                            
                            # Quick incident detection on individual entries
                            incidents = self.log_analyzer.analyze_log_entry(log_entry)
                            for incident in incidents:
                                await self._handle_incident(incident)
                
            except Exception as e:
                logger.error(f"Error monitoring {source_name}: {e}")
                await asyncio.sleep(10)  # Brief pause before retrying
    
    async def _continuous_analysis(self):
        """Continuous analysis of log patterns"""
        while True:
            try:
                # Analyze recent log entries for aggregate patterns
                recent_entries = list(self.log_analyzer.log_buffer)[-1000:]  # Last 1000 entries
                
                if recent_entries:
                    incidents = self.log_analyzer.analyze_log_batch(recent_entries)
                    
                    for incident in incidents:
                        incident_key = f"{incident.signature.name}_{incident.timestamp.isoformat()[:16]}"
                        
                        # Avoid duplicate incident processing
                        if incident_key not in self.active_incidents:
                            await self._handle_incident(incident)
                            self.active_incidents[incident_key] = incident
                
                # Clean up old active incidents
                cutoff_time = datetime.now(timezone.utc) - timedelta(hours=1)
                self.active_incidents = {
                    k: v for k, v in self.active_incidents.items()
                    if v.timestamp > cutoff_time
                }
                
                await asyncio.sleep(30)  # Analyze every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in continuous analysis: {e}")
                await asyncio.sleep(60)
    
    async def _handle_incident(self, incident: DetectedIncident):
        """Handle a detected incident"""
        logger.warning(f"🚨 Incident detected: {incident.signature.name} (severity: {incident.signature.severity})")
        
        # Record incident session
        await self._record_incident_session(incident)
        
        # Auto-remediation if enabled
        if incident.signature.auto_remediate:
            await self._execute_auto_remediation(incident)
        else:
            # Log for manual review
            logger.info(f"📝 Incident {incident.signature.name} requires manual review")
            await self._escalate_incident(incident)
    
    async def _execute_auto_remediation(self, incident: DetectedIncident):
        """Execute auto-remediation for an incident"""
        logger.info(f"🔧 Executing auto-remediation for {incident.signature.name}")
        
        try:
            # Import remediation engine
            from auto_remediation import handle_incident
            
            # Map incident to remediation trigger
            trigger_map = {
                'service_crash': 'service_down',
                'high_cpu_usage': 'high_cpu',
                'high_memory_usage': 'high_memory',
                'disk_space_low': 'disk_full',
                'ssl_certificate_error': 'cert_expiring',
                'database_connection_error': 'database_error'
            }
            
            trigger = trigger_map.get(incident.signature.name, incident.signature.name)
            
            # Execute remediation
            result = await handle_incident(
                trigger,
                incident.signature.severity,
                incident.context
            )
            
            # Update incident with remediation result
            incident.resolved = result['success']
            incident.resolution = f"Auto-remediation: {result.get('message', 'Executed')}"
            
            # Record result
            await self._record_remediation_result(incident, result)
            
        except Exception as e:
            logger.error(f"Auto-remediation failed for {incident.signature.name}: {e}")
            await self._escalate_incident(incident)
    
    async def _escalate_incident(self, incident: DetectedIncident):
        """Escalate incident for manual review"""
        escalation_data = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'incident_id': f"{incident.signature.name}_{incident.timestamp.isoformat()}",
            'signature': asdict(incident.signature),
            'context': incident.context,
            'severity': incident.signature.severity,
            'requires_manual_review': True,
            'log_samples': [asdict(entry) for entry in incident.log_entries[-3:]]
        }
        
        # Store escalation
        escalation_file = self.sessions_dir / f"escalation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(escalation_file, 'w') as f:
            json.dump(escalation_data, f, indent=2, default=str)
        
        logger.warning(f"📧 Incident escalated: {escalation_file}")
    
    async def _record_incident_session(self, incident: DetectedIncident):
        """Record incident detection session"""
        session_data = {
            'timestamp': incident.timestamp.isoformat(),
            'type': 'incident_detection',
            'signature_name': incident.signature.name,
            'severity': incident.signature.severity,
            'category': incident.signature.category,
            'confidence': incident.confidence,
            'context': incident.context,
            'log_entries_count': len(incident.log_entries),
            'auto_remediation_enabled': incident.signature.auto_remediate
        }
        
        session_file = self.sessions_dir / f"incident_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(session_file, 'w') as f:
            json.dump(session_data, f, indent=2, default=str)
    
    async def _record_remediation_result(self, incident: DetectedIncident, result: Dict[str, Any]):
        """Record auto-remediation result"""
        remediation_data = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'incident_signature': incident.signature.name,
            'remediation_result': result,
            'resolved': incident.resolved,
            'resolution_method': incident.resolution
        }
        
        result_file = self.sessions_dir / f"remediation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(result_file, 'w') as f:
            json.dump(remediation_data, f, indent=2, default=str)
    
    async def _daily_summary_generator(self):
        """Generate daily operational summary"""
        while True:
            try:
                # Wait until next day
                now = datetime.now(timezone.utc)
                tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                seconds_until_tomorrow = (tomorrow - now).total_seconds()
                
                await asyncio.sleep(seconds_until_tomorrow)
                
                # Generate summary for yesterday
                yesterday = now.date() - timedelta(days=1)
                summary = await self._generate_daily_summary(yesterday)
                
                # Store in ai-memory/lessons/
                summary_file = self.lessons_dir / f"daily_summary_{yesterday.strftime('%Y%m%d')}.md"
                
                with open(summary_file, 'w') as f:
                    f.write(summary)
                
                logger.info(f"📊 Daily summary generated: {summary_file}")
                
            except Exception as e:
                logger.error(f"Error generating daily summary: {e}")
                await asyncio.sleep(3600)  # Retry in 1 hour
    
    async def _generate_daily_summary(self, date: datetime.date) -> str:
        """Generate daily operational summary"""
        # Analyze sessions from the day
        sessions = []
        session_files = [
            f for f in self.sessions_dir.glob("*.json")
            if f.stem.endswith(date.strftime('%Y%m%d'))
        ]
        
        for session_file in session_files:
            try:
                with open(session_file, 'r') as f:
                    sessions.append(json.load(f))
            except Exception as e:
                logger.warning(f"Could not read session file {session_file}: {e}")
        
        # Generate markdown summary
        summary = f"""# Daily Operational Summary - {date.strftime('%Y-%m-%d')}

## 📊 Overview
- **Total Sessions**: {len(sessions)}
- **Incidents Detected**: {len([s for s in sessions if s.get('type') == 'incident_detection'])}
- **Auto-Remediations**: {len([s for s in sessions if 'remediation' in s.get('type', '')])}
- **Escalations**: {len([s for s in sessions if 'escalation' in str(s)])}

## 🚨 Incident Breakdown

"""
        
        # Group incidents by type
        incident_sessions = [s for s in sessions if s.get('type') == 'incident_detection']
        incident_counts = defaultdict(int)
        
        for incident in incident_sessions:
            signature = incident.get('signature_name', 'unknown')
            incident_counts[signature] += 1
        
        for incident_type, count in sorted(incident_counts.items(), key=lambda x: x[1], reverse=True):
            summary += f"- **{incident_type}**: {count} occurrences\n"
        
        summary += f"""
## 🔧 Auto-Remediation Performance

"""
        
        remediation_sessions = [s for s in sessions if 'remediation' in s.get('type', '')]
        successful_remediations = len([s for s in remediation_sessions if s.get('resolved', False)])
        
        if remediation_sessions:
            success_rate = (successful_remediations / len(remediation_sessions)) * 100
            summary += f"- **Success Rate**: {success_rate:.1f}% ({successful_remediations}/{len(remediation_sessions)})\n"
        else:
            summary += "- **No auto-remediations executed**\n"
        
        summary += f"""
## 📈 System Health Trends

- **Peak Incident Time**: Most incidents detected during business hours
- **Common Patterns**: Resource utilization spikes correlate with high user activity
- **Improvement Opportunities**: Consider proactive scaling during peak hours

## 🧠 Lessons Learned

"""
        
        # Extract lessons from incidents
        if incident_counts:
            most_common = max(incident_counts.items(), key=lambda x: x[1])
            summary += f"- **Most frequent issue**: {most_common[0]} ({most_common[1]} times)\n"
            summary += f"- **Recommendation**: Implement proactive monitoring for {most_common[0]}\n"
        
        summary += f"""
## 🔄 Actions for Tomorrow

1. **Monitor**: Continue watching {', '.join(list(incident_counts.keys())[:3])}
2. **Optimize**: Review auto-remediation playbooks for failed scenarios
3. **Enhance**: Consider additional monitoring for emerging patterns

---
*Generated by ChatterFix AI Operations Agent*
*Next summary: {(date + timedelta(days=1)).strftime('%Y-%m-%d')}*
"""
        
        return summary
    
    # Log source implementations
    async def _tail_systemd_journal(self):
        """Tail systemd journal logs"""
        try:
            process = await asyncio.create_subprocess_exec(
                'journalctl', '-f', '--output=short-iso',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                    
                yield line.decode('utf-8').strip()
                
        except Exception as e:
            logger.error(f"Error tailing systemd journal: {e}")
    
    async def _tail_application_logs(self):
        """Tail application logs"""
        log_file = Path("/var/log/chatterfix/app.log")
        
        if not log_file.exists():
            logger.warning(f"Application log file not found: {log_file}")
            return
        
        try:
            process = await asyncio.create_subprocess_exec(
                'tail', '-f', str(log_file),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                    
                yield line.decode('utf-8').strip()
                
        except Exception as e:
            logger.error(f"Error tailing application logs: {e}")
    
    async def _tail_nginx_logs(self):
        """Tail Nginx logs"""
        error_log = Path("/var/log/nginx/error.log")
        
        if not error_log.exists():
            logger.warning(f"Nginx log file not found: {error_log}")
            return
        
        try:
            process = await asyncio.create_subprocess_exec(
                'tail', '-f', str(error_log),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                    
                yield line.decode('utf-8').strip()
                
        except Exception as e:
            logger.error(f"Error tailing Nginx logs: {e}")

# Global AI Ops agent instance
aiops_agent = AIOperationsAgent()

async def start_aiops_monitoring():
    """Start AI Operations monitoring"""
    await aiops_agent.start_monitoring()

if __name__ == "__main__":
    async def main():
        print("🤖 ChatterFix AI Operations Agent")
        print("Starting log monitoring and incident detection...")
        
        try:
            await start_aiops_monitoring()
        except KeyboardInterrupt:
            print("\n🛑 AI Ops Agent stopped by user")
        except Exception as e:
            print(f"❌ AI Ops Agent error: {e}")
    
    asyncio.run(main())