"""seed_initial_data

Revision ID: 3935bcda336c
Revises: e190f14ef925
Create Date: 2025-09-08 19:32:36.693364

"""
from typing import Sequence, Union
from datetime import datetime

from alembic import op
import sqlalchemy as sa
from sqlalchemy import text


# revision identifiers, used by Alembic.
revision: str = '3935bcda336c'
down_revision: Union[str, Sequence[str], None] = 'e190f14ef925'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Seed initial data - idempotent operations."""
    connection = op.get_bind()
    
    # Seed KPI metrics
    kpi_data = [
        {'name': 'mttr_hours', 'value': 3.2},
        {'name': 'mtbf_days', 'value': 47.0},
        {'name': 'pm_compliance_pct', 'value': 92.4},
        {'name': 'overdue_work_orders', 'value': 3.0},
        {'name': 'critical_assets', 'value': 2.0},
        {'name': 'inventory_value_usd', 'value': 2400.0},
    ]
    
    for kpi in kpi_data:
        # Check if KPI already exists (idempotent)
        result = connection.execute(
            text("SELECT COUNT(*) FROM kpi_metrics WHERE name = :name"),
            {'name': kpi['name']}
        ).scalar()
        
        if result == 0:
            connection.execute(
                text("""
                    INSERT INTO kpi_metrics (name, value, updated_at) 
                    VALUES (:name, :value, :updated_at)
                """),
                {
                    'name': kpi['name'],
                    'value': kpi['value'],
                    'updated_at': datetime.utcnow()
                }
            )
    
    # Seed sample assets
    assets_data = [
        {
            'id': 'PUMP-001',
            'name': 'Primary Water Pump',
            'category': 'Pumps',
            'location': 'Mechanical Room A',
            'status': 'operational',
            'condition': 'good',
            'manufacturer': 'Grundfos',
            'model': 'CR120-2',
            'criticality': 'high',
            'health_score': 85.5
        },
        {
            'id': 'MOTOR-001',
            'name': 'Conveyor Motor 1',
            'category': 'Motors',
            'location': 'Production Line 1',
            'status': 'operational',
            'condition': 'fair',
            'manufacturer': 'ABB',
            'model': 'M3BP-180L',
            'criticality': 'medium',
            'health_score': 78.2
        },
        {
            'id': 'HVAC-001',
            'name': 'Main HVAC Unit',
            'category': 'HVAC',
            'location': 'Roof Level 3',
            'status': 'operational',
            'condition': 'excellent',
            'manufacturer': 'Carrier',
            'model': 'AquaEdge-19DV',
            'criticality': 'high',
            'health_score': 92.1
        }
    ]
    
    for asset in assets_data:
        # Check if asset already exists (idempotent)
        result = connection.execute(
            text("SELECT COUNT(*) FROM assets WHERE id = :id"),
            {'id': asset['id']}
        ).scalar()
        
        if result == 0:
            connection.execute(
                text("""
                    INSERT INTO assets (
                        id, name, category, location, status, condition,
                        manufacturer, model, criticality, health_score
                    ) VALUES (
                        :id, :name, :category, :location, :status, :condition,
                        :manufacturer, :model, :criticality, :health_score
                    )
                """),
                asset
            )
    
    # Seed sample parts
    parts_data = [
        {
            'id': 'BEARING-6308',
            'part_number': '6308-2RS',
            'name': 'Deep Groove Ball Bearing',
            'description': 'Single row deep groove ball bearing with rubber seals',
            'category': 'Bearings',
            'manufacturer': 'SKF',
            'unit_cost': 45.50,
            'quantity_on_hand': 12,
            'reorder_point': 5,
            'maximum_stock': 25,
            'unit_of_measure': 'each',
            'location': 'Warehouse A-12'
        },
        {
            'id': 'FILTER-AF25',
            'part_number': 'AF25-1234',
            'name': 'Air Filter Element',
            'description': 'High-efficiency particulate air filter',
            'category': 'Filters',
            'manufacturer': 'Parker',
            'unit_cost': 28.75,
            'quantity_on_hand': 8,
            'reorder_point': 3,
            'maximum_stock': 15,
            'unit_of_measure': 'each',
            'location': 'Warehouse B-05'
        }
    ]
    
    for part in parts_data:
        # Check if part already exists (idempotent)
        result = connection.execute(
            text("SELECT COUNT(*) FROM parts WHERE id = :id"),
            {'id': part['id']}
        ).scalar()
        
        if result == 0:
            connection.execute(
                text("""
                    INSERT INTO parts (
                        id, part_number, name, description, category, manufacturer,
                        unit_cost, quantity_on_hand, reorder_point, maximum_stock,
                        unit_of_measure, location
                    ) VALUES (
                        :id, :part_number, :name, :description, :category, :manufacturer,
                        :unit_cost, :quantity_on_hand, :reorder_point, :maximum_stock,
                        :unit_of_measure, :location
                    )
                """),
                part
            )


def downgrade() -> None:
    """Remove seed data."""
    connection = op.get_bind()
    
    # Remove seed data (use specific IDs to avoid removing user data)
    seed_kpi_names = [
        'mttr_hours', 'mtbf_days', 'pm_compliance_pct', 
        'overdue_work_orders', 'critical_assets', 'inventory_value_usd'
    ]
    
    seed_asset_ids = ['PUMP-001', 'MOTOR-001', 'HVAC-001']
    seed_part_ids = ['BEARING-6308', 'FILTER-AF25']
    
    for kpi_name in seed_kpi_names:
        connection.execute(
            text("DELETE FROM kpi_metrics WHERE name = :name"),
            {'name': kpi_name}
        )
    
    for asset_id in seed_asset_ids:
        connection.execute(
            text("DELETE FROM assets WHERE id = :id"),
            {'id': asset_id}
        )
    
    for part_id in seed_part_ids:
        connection.execute(
            text("DELETE FROM parts WHERE id = :id"),
            {'id': part_id}
        )