#!/usr/bin/env python3
"""
CMMS API Schemas - Pydantic models for request/response validation
"""
from __future__ import annotations
from typing import Optional, List, Literal
from pydantic import BaseModel, Field
from datetime import datetime


# =============================================================================
# Base Response Models
# =============================================================================

class PaginatedResponse(BaseModel):
    """Base paginated response"""
    total: int
    limit: int
    offset: int
    has_next: bool


# =============================================================================
# Parts API Schemas
# =============================================================================

class PartBase(BaseModel):
    """Base part fields"""
    part_number: Optional[str] = None
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    manufacturer: Optional[str] = None
    supplier: Optional[str] = None
    unit_cost: Optional[float] = None
    quantity_on_hand: Optional[int] = None
    reorder_point: Optional[int] = None
    maximum_stock: Optional[int] = None
    unit_of_measure: Optional[str] = None
    location: Optional[str] = None
    compatible_assets: Optional[str] = None


class PartCreate(PartBase):
    """Schema for creating a new part"""
    pass


class PartUpdate(BaseModel):
    """Schema for updating a part (all fields optional)"""
    part_number: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    manufacturer: Optional[str] = None
    supplier: Optional[str] = None
    unit_cost: Optional[float] = None
    quantity_on_hand: Optional[int] = None
    reorder_point: Optional[int] = None
    maximum_stock: Optional[int] = None
    unit_of_measure: Optional[str] = None
    location: Optional[str] = None
    compatible_assets: Optional[str] = None


class PartResponse(PartBase):
    """Schema for part response"""
    id: str
    last_ordered: Optional[str] = None

    class Config:
        from_attributes = True


class PartsListResponse(PaginatedResponse):
    """Schema for paginated parts list"""
    items: List[PartResponse]


# =============================================================================
# Equipment/Assets API Schemas
# =============================================================================

class AssetBase(BaseModel):
    """Base asset fields"""
    name: str
    category: Optional[str] = None
    location: Optional[str] = None
    status: Optional[str] = None
    condition: Optional[str] = None
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    serial_number: Optional[str] = None
    installation_date: Optional[str] = None
    maintenance_frequency: Optional[int] = None
    criticality: Optional[str] = None
    cost_center: Optional[str] = None
    specifications: Optional[str] = None
    parent_asset_id: Optional[str] = None
    health_score: Optional[float] = None


class AssetCreate(AssetBase):
    """Schema for creating a new asset"""
    pass


class AssetUpdate(BaseModel):
    """Schema for updating an asset (all fields optional)"""
    name: Optional[str] = None
    category: Optional[str] = None
    location: Optional[str] = None
    status: Optional[str] = None
    condition: Optional[str] = None
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    serial_number: Optional[str] = None
    installation_date: Optional[str] = None
    last_maintenance: Optional[str] = None
    next_maintenance: Optional[str] = None
    maintenance_frequency: Optional[int] = None
    criticality: Optional[str] = None
    cost_center: Optional[str] = None
    specifications: Optional[str] = None
    parent_asset_id: Optional[str] = None
    health_score: Optional[float] = None


class AssetResponse(AssetBase):
    """Schema for asset response"""
    id: str
    last_maintenance: Optional[str] = None
    next_maintenance: Optional[str] = None

    class Config:
        from_attributes = True


class AssetsListResponse(PaginatedResponse):
    """Schema for paginated assets list"""
    items: List[AssetResponse]


# =============================================================================
# Work Orders API Schemas
# =============================================================================

class WorkOrderBase(BaseModel):
    """Base work order fields"""
    title: str
    description: str
    asset_id: Optional[str] = None
    type: Optional[str] = None
    priority: Optional[str] = Field(None, pattern="^(low|medium|high|critical)$")
    status: Optional[str] = Field(None, pattern="^(open|in_progress|completed|cancelled|on_hold)$")
    assigned_to: Optional[str] = None
    due_date: Optional[str] = None
    estimated_hours: Optional[float] = None
    cost: Optional[float] = None
    sla_hours: Optional[int] = None


class WorkOrderCreate(WorkOrderBase):
    """Schema for creating a new work order"""
    pass


class WorkOrderUpdate(BaseModel):
    """Schema for updating a work order (all fields optional)"""
    title: Optional[str] = None
    description: Optional[str] = None
    asset_id: Optional[str] = None
    type: Optional[str] = None
    priority: Optional[str] = Field(None, pattern="^(low|medium|high|critical)$")
    status: Optional[str] = Field(None, pattern="^(open|in_progress|completed|cancelled|on_hold)$")
    assigned_to: Optional[str] = None
    due_date: Optional[str] = None
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    cost: Optional[float] = None
    sla_hours: Optional[int] = None
    acknowledged_at: Optional[str] = None
    closed_date: Optional[str] = None
    escalated: Optional[bool] = None


class WorkOrderResponse(WorkOrderBase):
    """Schema for work order response"""
    id: str
    created_at: Optional[str] = None
    created_by: Optional[str] = None
    actual_hours: Optional[float] = None
    acknowledged_at: Optional[str] = None
    closed_date: Optional[str] = None
    escalated: Optional[bool] = None

    class Config:
        from_attributes = True


class WorkOrdersListResponse(PaginatedResponse):
    """Schema for paginated work orders list"""
    items: List[WorkOrderResponse]


# =============================================================================
# Common Query Parameters
# =============================================================================

class CommonQueryParams(BaseModel):
    """Common query parameters for list endpoints"""
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)


class PartQueryParams(CommonQueryParams):
    """Query parameters for parts list"""
    category: Optional[str] = None
    low_stock: Optional[bool] = False
    order_by: Literal["name", "category", "quantity_on_hand", "reorder_point"] = "name"


class AssetQueryParams(CommonQueryParams):
    """Query parameters for assets list"""
    category: Optional[str] = None
    order_by: Literal["name", "category", "location"] = "name"


class WorkOrderQueryParams(CommonQueryParams):
    """Query parameters for work orders list"""
    status: Optional[str] = None
    priority: Optional[str] = None
    assigned_to: Optional[str] = None
    order_by: Literal["created_at", "due_date", "priority", "status"] = "created_at"


# =============================================================================
# Error Responses
# =============================================================================

class ErrorResponse(BaseModel):
    """Standard error response"""
    error: str
    message: str
    request_id: Optional[str] = None


class ValidationErrorResponse(BaseModel):
    """Validation error response"""
    error: str = "validation_error"
    message: str
    details: List[dict]
    request_id: Optional[str] = None