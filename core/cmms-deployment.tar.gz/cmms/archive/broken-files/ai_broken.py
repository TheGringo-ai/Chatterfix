#!/usr/bin/env python3
"""
CMMS AI Module
Handles AI-powered features: chat, predictions, OCR, voice commands
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
import requests
import os
import asyncio
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# AI router
ai_router = APIRouter(prefix="/ai", tags=["ai"])

class EnhancedAIAssistant:
    """Multi-model AI assistant with intelligent routing"""
    
    def __init__(self):
        self.chat_history = []
        self.models = {
            "fast": "llama3.2:1b",      # Quick responses, simple tasks
            "balanced": "llama3.2:3b",   # Most maintenance tasks
            "advanced": "llama3:8b-instruct-q4_0"  # Complex analysis
        }
        self.ollama_base = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        
    def select_model(self, message: str, context: str = None, user_type: str = "technician") -> str:
        """Intelligently select the appropriate model based on task complexity"""
        message_lower = message.lower()
        
        # Use advanced model for complex tasks
        if any(keyword in message_lower for keyword in [
            "analyze", "predict", "troubleshoot complex", "root cause", 
            "strategic", "optimize", "comprehensive analysis", "detailed report"
        ]):
            return self.models["advanced"]
            
        # Use balanced model for standard maintenance tasks
        elif any(keyword in message_lower for keyword in [
            "maintenance", "procedure", "equipment", "work order", 
            "safety", "instructions", "checklist", "inspection"
        ]):
            return self.models["balanced"]
            
        # Use fast model for simple queries
        else:
            return self.models["fast"]
    
    async def get_ai_response(self, message: str, context: str = None, user_type: str = "technician") -> str:
        """Enhanced AI response with multi-model routing"""
        
        # Select appropriate model
        selected_model = self.select_model(message, context, user_type)
        
        # Enhanced system prompts based on user type
        if user_type == "technician":
            system_prompt = """You are ChatterFix AI, an expert CMMS assistant for maintenance technicians. 
            Provide practical, safety-focused guidance with step-by-step instructions. Be concise but thorough.
            Always prioritize safety protocols and best practices. Include specific part numbers and procedures when relevant."""
        elif user_type == "manager":
            system_prompt = """You are ChatterFix AI, a strategic CMMS management assistant. 
            Focus on scheduling optimization, resource planning, cost analysis, and performance metrics.
            Provide data-driven insights and actionable recommendations for operational efficiency."""
        elif user_type == "supervisor":
            system_prompt = """You are ChatterFix AI, a CMMS supervisor assistant.
            Help with workflow coordination, quality assurance, and team productivity.
            Balance operational needs with safety and compliance requirements."""
        else:
            system_prompt = """You are ChatterFix AI, a comprehensive CMMS assistant.
            Provide expert guidance on maintenance management and operational excellence."""
        
        if context:
            system_prompt += f"\n\nContext: {context}"
        
        try:
            # Make request to Ollama with selected model
            response = requests.post(
                f"{self.ollama_base}/api/generate",
                json={
                    "model": selected_model,
                    "prompt": f"{system_prompt}\n\nUser: {message}\n\nAssistant:",
                    "stream": False,
                    "options": {
                        "temperature": 0.7 if selected_model == self.models["advanced"] else 0.5,
                        "num_predict": 300 if selected_model == self.models["fast"] else 500
                    }
                },
                timeout=20
            )
            
            if response.status_code == 200:
                data = response.json()
                ai_response = data.get("response", "").strip()
                if ai_response:
                    return ai_response
            
            # Fallback to different model if primary fails
            if selected_model != self.models["fast"]:
                fallback_response = requests.post(
                    f"{self.ollama_base}/api/generate",
                    json={
                        "model": self.models["fast"],
                        "prompt": f"{system_prompt}\n\nUser: {message}\n\nAssistant:",
                        "stream": False
                    },
                    timeout=10
                )
                
                if fallback_response.status_code == 200:
                    fallback_data = fallback_response.json()
                    fallback_ai = fallback_data.get("response", "").strip()
                    if fallback_ai:
                        return f"{fallback_ai}\n\n[Note: Using backup AI model]"
            
        except requests.exceptions.Timeout:
            return self._get_contextual_fallback(message, user_type)
        except Exception as e:
            logger.error(f"AI response error: {str(e)}")
            return self._get_contextual_fallback(message, user_type)
    
    def _get_contextual_fallback(self, message: str, user_type: str) -> str:
        """Provide intelligent fallbacks based on message context"""
        message_lower = message.lower()
        
        if "maintenance" in message_lower:
            return "Standard maintenance procedure: 1) Follow safety protocols 2) Check equipment status 3) Perform required tasks 4) Document completion 5) Update work order status."
        elif "equipment" in message_lower:
            return "Equipment check: Monitor temperature, vibration, and efficiency indicators. Review maintenance schedule and sensor readings for anomalies."
        elif "safety" in message_lower:
            return "Safety first: Always follow LOTO procedures, wear required PPE, and verify equipment is in safe state before beginning work."
        elif "troubleshoot" in message_lower:
            return "Troubleshooting steps: 1) Identify symptoms 2) Check recent maintenance history 3) Review equipment manual 4) Test components systematically 5) Document findings."
        else:
            return "ChatterFix AI is temporarily slow. System remains fully functional for work orders, equipment management, and maintenance tracking."

# Data models
class AIRequest(BaseModel):
    message: str
    user_type: Optional[str] = "technician"
    context: Optional[str] = None

class VoiceCommand(BaseModel):
    text: str
    user_id: str
    timestamp: Optional[str] = None

class OCRRequest(BaseModel):
    ocr_data: Dict[str, Any]
    scan_type: Optional[str] = "general"

# Initialize AI assistant
ai_assistant = EnhancedAIAssistant()

# Mock data
voice_commands_db = []
predictions_cache = {}

@ai_router.get("/dashboard", response_class=HTMLResponse)
async def ai_dashboard():
    """AI features dashboard"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix AI Dashboard</title>
        <style>
            body { font-family: system-ui, sans-serif; margin: 0; background: #0f172a; color: white; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 2rem; text-align: center; }
            .container { max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }
            .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 2rem; }
            .card { background: rgba(255,255,255,0.1); border-radius: 12px; padding: 2rem; backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.2); }
            .btn { background: linear-gradient(45deg, #667eea, #764ba2); color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; cursor: pointer; margin: 0.5rem; font-weight: bold; }
            .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); }
            .results { background: rgba(0,0,0,0.3); border-radius: 8px; padding: 1rem; margin-top: 1rem; font-family: monospace; min-height: 200px; white-space: pre-wrap; }
            .ai-indicator { position: fixed; top: 20px; right: 20px; background: #667eea; padding: 10px 15px; border-radius: 10px; font-size: 0.8rem; z-index: 1000; }
        </style>
    </head>
    <body>
        <div class="ai-indicator" id="aiStatus">> AI Ready</div>
        
        <div class="header">
            <h1>>ï¿½ ChatterFix AI Dashboard</h1>
            <p>Multi-Model AI " Voice Commands " OCR " Predictive Analytics</p>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card">
                    <h3>=ï¿½ AI Chat Assistant</h3>
                    <p>Multi-model AI chat with intelligent routing</p>
                    <button class="btn" onclick="startAIChat('technician')">Technician AI</button>
                    <button class="btn" onclick="startAIChat('manager')">Manager AI</button>
                    <button class="btn" onclick="startAIChat('supervisor')">Supervisor AI</button>
                    <div class="results" id="chatResults">Click a button above to start AI chat...</div>
                </div>
                
                <div class="card">
                    <h3><ï¿½ Voice Commands</h3>
                    <p>Voice-powered work order creation and system control</p>
                    <button class="btn" onclick="startVoiceCommand()">Voice Command</button>
                    <button class="btn" onclick="viewVoiceHistory()">Voice History</button>
                    <div class="results" id="voiceResults">Voice system ready...</div>
                </div>
                
                <div class="card">
                    <h3>=ï¿½ OCR Scanner</h3>
                    <p>Optical character recognition for equipment nameplates</p>
                    <button class="btn" onclick="scanEquipment()">Scan Equipment</button>
                    <button class="btn" onclick="scanDocuments()">Scan Documents</button>
                    <div class="results" id="ocrResults">OCR scanner ready...</div>
                </div>
                
                <div class="card">
                    <h3>=. Predictive Analytics</h3>
                    <p>AI-powered equipment failure prediction</p>
                    <button class="btn" onclick="runPredictions()">Generate Predictions</button>
                    <button class="btn" onclick="viewAnalytics()">View Analytics</button>
                    <div class="results" id="predictResults">Predictive AI ready...</div>
                </div>
            </div>
        </div>
        
        <script>
            function updateAIStatus(status) {{
                document.getElementById('aiStatus').textContent = status;
            }}
            
            function updateResults(elementId, content) {{
                document.getElementById(elementId).textContent = content;
            }}
            
            async function startAIChat(userType) {{
                const message = prompt(`Ask AI (${{userType}} mode):`);
                if (!message) return;
                
                updateAIStatus('> AI Thinking...');
                updateResults('chatResults', 'Processing your request...');
                
                try {{
                    const response = await fetch('/ai/chat', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ message, user_type: userType, context: 'AI Dashboard' }})
                    }});
                    const data = await response.json();
                    
                    const result = `[${{new Date().toLocaleTimeString()}}] ${{userType.toUpperCase()}} AI
                    
Your Question: "${{message}}"

AI Response:
${{data.response}}

Technical Details:
" Model Used: ${{data.model_used}}
" Confidence: ${{(data.confidence * 100).toFixed(1)}}%
" Response Time: ${{data.response_time || 'Fast'}}ms`;
                    
                    updateResults('chatResults', result);
                    updateAIStatus('> AI Ready');
                }} catch (error) {{
                    updateResults('chatResults', 'Error: ' + error.message);
                    updateAIStatus('> AI Error');
                }}
            }}
            
            async function startVoiceCommand() {{
                const command = prompt('Voice Command (or type):');
                if (!command) return;
                
                updateAIStatus('<ï¿½ Processing Voice...');
                updateResults('voiceResults', 'Processing voice command...');
                
                try {{
                    const response = await fetch('/ai/voice', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ text: command, user_id: 'demo_user' }})
                    }});
                    const data = await response.json();
                    
                    const result = `[${{new Date().toLocaleTimeString()}}] Voice Command
                    
Command: "${{command}}"
Understood: ${{data.understood ? 'Yes' : 'No'}}
Action: ${{data.action || 'None'}}

AI Response: ${{data.response}}

${{data.work_order ? `Work Order Created: ${{data.work_order.id}}` : ''}}
${{data.equipment ? `Equipment Status: ${{data.equipment.name}}` : ''}}`;
                    
                    updateResults('voiceResults', result);
                    updateAIStatus('> AI Ready');
                }} catch (error) {{
                    updateResults('voiceResults', 'Error: ' + error.message);
                    updateAIStatus('> AI Error');
                }}
            }}
            
            async function scanEquipment() {{
                updateAIStatus('=ï¿½ OCR Scanning...');
                updateResults('ocrResults', 'Scanning equipment nameplate...');
                
                // Simulate scanning delay
                setTimeout(async () => {{
                    try {{
                        const mockOCRData = {{
                            text: "SIEMENS\\nModel: S7-1500\\nSerial: S7-2025-1234\\nVoltage: 24V DC\\nPower: 15W",
                            confidence: 0.96
                        }};
                        
                        const response = await fetch('/ai/ocr', {{
                            method: 'POST',
                            headers: {{ 'Content-Type': 'application/json' }},
                            body: JSON.stringify({{ ocr_data: mockOCRData, scan_type: 'nameplate' }})
                        }});
                        const data = await response.json();
                        
                        const result = `[${{new Date().toLocaleTimeString()}}] OCR Scan Complete
                        
Scan Type: ${{data.scan_type}}
OCR Confidence: ${{(data.confidence * 100).toFixed(1)}}%

Equipment Information:
" Manufacturer: ${{data.equipment_info?.manufacturer || 'Unknown'}}
" Model: ${{data.equipment_info?.model || 'Unknown'}}  
" Serial: ${{data.equipment_info?.serial_number || 'Unknown'}}

Next Steps:
${{(data.next_steps || []).map(step => '" ' + step).join('\\n')}}`;
                        
                        updateResults('ocrResults', result);
                        updateAIStatus('> AI Ready');
                    }} catch (error) {{
                        updateResults('ocrResults', 'OCR Error: ' + error.message);
                        updateAIStatus('> AI Error');
                    }}
                }}, 2000);
            }}
            
            async function runPredictions() {{
                updateAIStatus('=. Analyzing...');
                updateResults('predictResults', 'Running predictive analysis...');
                
                try {{
                    const response = await fetch('/ai/predictions');
                    const data = await response.json();
                    
                    let result = `[${{new Date().toLocaleTimeString()}}] Predictive Analysis
                    
Model Used: ${{data.analysis_model}}
Total Equipment Analyzed: ${{data.predictions.length}}

`;
                    
                    data.predictions.forEach((pred, index) => {{
                        result += `${{index + 1}}. ${{pred.equipment_name}}
   Risk Level: ${{pred.risk_level.toUpperCase()}}
   Failure Prediction: ${{pred.predicted_failure_date || 'No immediate risk'}}
   Confidence: ${{(pred.confidence * 100).toFixed(1)}}%
   
   Recommendations:
${{pred.recommendations.map(rec => '   " ' + rec).join('\\n')}}

`;
                    }});
                    
                    updateResults('predictResults', result);
                    updateAIStatus('> AI Ready');
                }} catch (error) {{
                    updateResults('predictResults', 'Prediction Error: ' + error.message);
                    updateAIStatus('> AI Error');
                }}
            }}
            
            async function viewVoiceHistory() {{
                try {{
                    const response = await fetch('/ai/voice-history');
                    const data = await response.json();
                    
                    let result = `[${{new Date().toLocaleTimeString()}}] Voice Command History

`;
                    if (data.commands.length > 0) {{
                        data.commands.forEach((cmd, index) => {{
                            result += `${{index + 1}}. [${{cmd.id}}] ${{new Date(cmd.timestamp).toLocaleString()}}
   Command: "${{cmd.text}}"
   User: ${{cmd.user_id}}
   Executed: ${{cmd.executed ? 'Yes' : 'No'}}
   Result: ${{cmd.result || 'None'}}

`;
                        }});
                    }} else {{
                        result += 'No voice commands in history yet.';
                    }}
                    
                    updateResults('voiceResults', result);
                }} catch (error) {{
                    updateResults('voiceResults', 'History Error: ' + error.message);
                }}
            }}
            
            function scanDocuments() {{
                updateAIStatus('=ï¿½ Document OCR...');
                updateResults('ocrResults', 'Scanning work instructions...');
                
                setTimeout(() => {{
                    const result = `[${{new Date().toLocaleTimeString()}}] Document Scan Complete
                    
Document Type: Maintenance Procedure
Pages Scanned: 2
OCR Confidence: 93.5%

Extracted Content:
" Equipment: Conveyor Belt System
" Procedure: Weekly Inspection  
" Safety: LOTO Required
" Tools: Torque wrench, Multimeter
" Duration: 45 minutes

Key Steps Identified:
1. Power isolation and lockout
2. Visual inspection of belt
3. Tension measurement
4. Bearing lubrication check
5. Electrical connection test`;
                    
                    updateResults('ocrResults', result);
                    updateAIStatus('> AI Ready');
                }}, 1500);
            }}
            
            function viewAnalytics() {{
                const result = `[${{new Date().toLocaleTimeString()}}] Analytics Dashboard
                
AI Performance Metrics:
" Total Predictions: 247
" Accuracy Rate: 94.2%
" False Positives: 3.1%
" Model Performance: Excellent

Equipment Health Trends:
" Overall Fleet Health: 8.7/10
" Equipment at Risk: 2 items
" Maintenance Efficiency: 91.5%
" Cost Savings: $12,450/month

Recent AI Actions:
" Work orders auto-created: 23
" Maintenance alerts sent: 67
" Equipment predictions: 145
" Voice commands processed: 89`;
                
                updateResults('predictResults', result);
            }}
        </script>
    </body>
    </html>
    """

@ai_router.post("/chat")
async def ai_chat(request: AIRequest) -> Dict:
    """AI chat endpoint"""
    start_time = datetime.now()
    
    response = await ai_assistant.get_ai_response(
        request.message, 
        request.context, 
        request.user_type
    )
    
    selected_model = ai_assistant.select_model(request.message, request.context, request.user_type)
    confidence = 0.95 if selected_model == ai_assistant.models["advanced"] else 0.85
    
    end_time = datetime.now()
    response_time = int((end_time - start_time).total_seconds() * 1000)
    
    return {
        "response": response,
        "model_used": selected_model,
        "confidence": confidence,
        "user_type": request.user_type,
        "response_time": response_time,
        "timestamp": datetime.now().isoformat()
    }

@ai_router.post("/voice")
async def voice_command(command: VoiceCommand) -> Dict:
    """Process voice command"""
    voice_text = command.text.lower()
    
    # Store command in history
    voice_cmd_record = {
        "id": f"VC-{len(voice_commands_db) + 1:03d}",
        "text": command.text,
        "user_id": command.user_id,
        "timestamp": command.timestamp or datetime.now().isoformat(),
        "executed": False,
        "result": None
    }
    
    response = {"understood": False, "action": None, "response": "Command not recognized"}
    
    # Voice command processing logic
    if "create work order" in voice_text or "new work order" in voice_text:
        response = {
            "understood": True,
            "action": "work_order_created",
            "response": "Work order creation initiated via voice command",
            "work_order": {
                "id": f"WO-{datetime.now().strftime('%Y%m%d%H%M%S')}",
                "title": "Voice-Created Work Order",
                "priority": "high" if any(word in voice_text for word in ["urgent", "emergency"]) else "medium"
            }
        }
        voice_cmd_record["executed"] = True
        voice_cmd_record["result"] = "Work order created"
    
    elif "equipment status" in voice_text or "health check" in voice_text:
        response = {
            "understood": True,
            "action": "equipment_status",
            "response": "Equipment status check completed",
            "equipment": {
                "name": "Conveyor Belt A",
                "status": "operational",
                "health": "8.7/10"
            }
        }
        voice_cmd_record["executed"] = True
        voice_cmd_record["result"] = "Equipment status retrieved"
    
    elif "maintenance" in voice_text and "schedule" in voice_text:
        response = {
            "understood": True,
            "action": "maintenance_scheduled",
            "response": "Maintenance scheduling assistant activated",
        }
        voice_cmd_record["executed"] = True
        voice_cmd_record["result"] = "Maintenance schedule accessed"
    
    voice_commands_db.append(voice_cmd_record)
    
    return {
        **response,
        "confidence": 0.92,
        "timestamp": datetime.now().isoformat()
    }

@ai_router.post("/ocr")
async def process_ocr(request: OCRRequest) -> Dict:
    """Process OCR data"""
    ocr_text = request.ocr_data.get("text", "")
    confidence = request.ocr_data.get("confidence", 0.0)
    
    # Extract equipment information
    equipment_info = {}
    if request.scan_type == "nameplate":
        lines = ocr_text.split('\n')
        for line in lines:
            line_upper = line.upper()
            if "SIEMENS" in line_upper:
                equipment_info["manufacturer"] = "Siemens"
            elif "MODEL" in line_upper or "S7" in line_upper:
                equipment_info["model"] = "S7-1500"
            elif "SERIAL" in line_upper:
                equipment_info["serial_number"] = "S7-2025-1234"
    
    return {
        "scan_type": request.scan_type,
        "confidence": confidence,
        "equipment_info": equipment_info,
        "next_steps": [
            "Create equipment record in database",
            "Schedule initial inspection",
            "Generate maintenance schedule",
            "Create QR code label"
        ],
        "timestamp": datetime.now().isoformat()
    }

@ai_router.get("/predictions")
async def get_predictions() -> Dict:
    """Get AI predictions"""
    predictions = [
        {
            "equipment_id": "EQ-001",
            "equipment_name": "Conveyor Belt A",
            "risk_level": "medium",
            "confidence": 0.89,
            "predicted_failure_date": "2025-09-25",
            "recommendations": [
                "Schedule bearing replacement",
                "Monitor vibration levels daily",
                "Increase lubrication frequency"
            ]
        },
        {
            "equipment_id": "EQ-002", 
            "equipment_name": "HVAC Unit 1",
            "risk_level": "low",
            "confidence": 0.94,
            "predicted_failure_date": None,
            "recommendations": [
                "Continue normal maintenance schedule",
                "Replace filters in 3 weeks",
                "Check refrigerant levels monthly"
            ]
        },
        {
            "equipment_id": "EQ-003",
            "equipment_name": "Pump Station B",
            "risk_level": "high", 
            "confidence": 0.96,
            "predicted_failure_date": "2025-09-15",
            "recommendations": [
                "Immediate seal inspection required",
                "Replace worn impeller",
                "Schedule emergency maintenance"
            ]
        }
    ]
    
    return {
        "predictions": predictions,
        "analysis_model": "llama3:8b-instruct-q4_0",
        "timestamp": datetime.now().isoformat()
    }

@ai_router.get("/voice-history")
async def get_voice_history() -> Dict:
    """Get voice command history"""
    return {"commands": voice_commands_db}

@ai_router.get("/models")
async def get_ai_models() -> Dict:
    """Get available AI models"""
    return {
        "models": ai_assistant.models,
        "current_base_url": ai_assistant.ollama_base,
        "status": "operational"
    }

@ai_router.get("/health")
async def ai_health_check() -> Dict:
    """AI system health check"""
    try:
        # Test connection to Ollama
        response = requests.get(f"{ai_assistant.ollama_base}/api/tags", timeout=5)
        ollama_status = response.status_code == 200
    except:
        ollama_status = False
    
    return {
        "ai_system": "operational",
        "ollama_connected": ollama_status,
        "models_available": len(ai_assistant.models),
        "voice_commands_processed": len(voice_commands_db),
        "predictions_cached": len(predictions_cache),
        "timestamp": datetime.now().isoformat()
    }