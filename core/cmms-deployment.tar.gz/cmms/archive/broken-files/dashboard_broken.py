#!/usr/bin/env python3
"""
CMMS Dashboard Module
Provides main dashboard functionality and overview statistics
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse
from datetime import datetime
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Dashboard router
dashboard_router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@dashboard_router.get("/main", response_class=HTMLResponse)
async def main_dashboard():
    """Main system dashboard with comprehensive overview"""
    nav_html = get_navigation_html("dashboard")
    nav_styles = get_navigation_styles()
    nav_js = get_navigation_javascript()
    base_styles = get_base_styles()
    
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - Main Dashboard</title>
        <style>
            {base_styles}
            {nav_styles}
            
            /* Dashboard Content */
            .header { 
                padding: 3rem 2rem 2rem;
                text-align: center;
            }
            .header h1 { 
                font-size: 3rem; 
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            .container { 
                max-width: 1400px; 
                margin: 0 auto; 
                padding: 0 2rem 2rem; 
            }
            .stats-grid { 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                gap: 2rem; 
                margin-bottom: 3rem;
            }
            .stat-card { 
                background: rgba(255,255,255,0.15); 
                border-radius: 15px; 
                padding: 2rem; 
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                text-align: center;
                transition: transform 0.3s ease;
            }
            .stat-card:hover {
                transform: translateY(-5px);
            }
            .stat-value {
                font-size: 3rem;
                font-weight: bold;
                color: #38ef7d;
                display: block;
                margin-bottom: 0.5rem;
            }
            .stat-label {
                color: rgba(255,255,255,0.8);
                font-size: 1.1rem;
            }
            
            .charts-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 2rem;
                margin-top: 2rem;
            }
            .chart-card {
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }
            .chart-title {
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            }
        </style>
    </head>
    <body>
        {nav_html}
        
        <!-- Header -->
        <div class="header">
            <h1>📊 System Dashboard</h1>
            <p>Comprehensive CMMS Overview & Key Performance Indicators</p>
        </div>
        
        <!-- Main Content -->
        <div class="container">
            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value">24</span>
                    <span class="stat-label">Active Work Orders</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">47</span>
                    <span class="stat-label">Assets Monitored</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">3</span>
                    <span class="stat-label">Critical Alerts</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">95%</span>
                    <span class="stat-label">System Health</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">12</span>
                    <span class="stat-label">Technicians Online</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">$2.4K</span>
                    <span class="stat-label">Parts Inventory</span>
                </div>
            </div>
            
            <!-- Charts Section -->
            <div class="charts-grid">
                <div class="chart-card">
                    <h3 class="chart-title">Work Order Status</h3>
                    <canvas id="workOrderChart" width="400" height="300"></canvas>
                </div>
                <div class="chart-card">
                    <h3 class="chart-title">Asset Health Overview</h3>
                    <canvas id="assetHealthChart" width="400" height="300"></canvas>
                </div>
            </div>
        </div>
        
        <script>
            {nav_js}
                window.chatterFixAIInjected = true;
                
                // Create AI button
                const aiBtn = document.createElement('div');
                aiBtn.id = 'cfAIBtn';
                aiBtn.innerHTML = '🤖';
                aiBtn.style.cssText = `
                    position: fixed; bottom: 30px; right: 30px;
                    width: 65px; height: 65px; border-radius: 50%;
                    background: linear-gradient(135deg, #38ef7d, #11998e);
                    display: flex; align-items: center; justify-content: center;
                    cursor: pointer; z-index: 10000; font-size: 32px;
                    box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                    border: 3px solid rgba(255,255,255,0.3);
                    transition: all 0.3s ease;
                    animation: pulse-glow 3s infinite;
                `;
                
                // Add pulsing animation
                const style = document.createElement('style');
                style.textContent = `
                    @keyframes pulse-glow {{
                        0%, 100% {{ 
                            transform: scale(1); 
                            box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                        }}
                        50% {{ 
                            transform: scale(1.05); 
                            box-shadow: 0 8px 30px rgba(56,239,125,0.8);
                        }}
                    }}
                    #cfAIBtn:hover {{
                        transform: scale(1.1) !important;
                        box-shadow: 0 8px 35px rgba(56,239,125,0.9) !important;
                    }}
                `;
                document.head.appendChild(style);
                
                // Create AI panel
                const aiPanel = document.createElement('iframe');
                aiPanel.id = 'cfAIPanel';
                aiPanel.src = '/cmms/ai-enhanced/dashboard/universal';
                aiPanel.style.cssText = `
                    position: fixed; bottom: 100px; right: 30px;
                    width: 400px; height: 600px; max-width: 90vw; max-height: 70vh;
                    border: none; border-radius: 20px; display: none; z-index: 9999;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
                `;
                
                document.body.appendChild(aiBtn);
                document.body.appendChild(aiPanel);
                
                // Toggle panel
                aiBtn.onclick = () => {{
                    const visible = aiPanel.style.display === 'block';
                    aiPanel.style.display = visible ? 'none' : 'block';
                    aiBtn.style.transform = visible ? 'scale(1)' : 'scale(0.9)';
                }};
                
                aiBtn.onmouseover = () => aiBtn.style.transform = 'scale(1.1)';
                aiBtn.onmouseout = () => {{
                    if (aiPanel.style.display !== 'block') {{
                        aiBtn.style.transform = 'scale(1)';
                    }}
                }};
                
                console.log('✅ ChatterFix AI Assistant loaded');
            }}
            
            // Auto-update stats
            setInterval(function() {{
                // Simulate real-time updates
                const stats = document.querySelectorAll('.stat-value');
                stats.forEach((stat, index) => {{
                    if (index === 0) {{ // Work Orders
                        const current = parseInt(stat.textContent);
                        stat.textContent = current + Math.floor(Math.random() * 2);
                    }}
                }});
            }}, 30000);
        </script>
    </body>
    </html>
    """