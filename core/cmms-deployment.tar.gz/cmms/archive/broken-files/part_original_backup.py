#!/usr/bin/env python3
"""
CMMS Parts Module
Parts inventory management, ordering, and tracking
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Parts router
parts_router = APIRouter(prefix="/parts", tags=["parts"])

# Data models
class Part(BaseModel):
    id: str
    part_number: str
    name: str
    description: str
    category: str
    manufacturer: str
    supplier: str
    unit_cost: float
    quantity_on_hand: int
    reorder_point: int
    maximum_stock: int
    unit_of_measure: str
    location: str
    last_ordered: Optional[str] = None
    compatible_assets: List[str]

class PurchaseOrder(BaseModel):
    id: str
    supplier: str
    order_date: str
    expected_delivery: str
    status: str
    total_cost: float
    parts: List[Dict[str, Any]]

class InventoryTransaction(BaseModel):
    id: str
    part_id: str
    transaction_type: str  # issued, received, adjusted
    quantity: int
    work_order_id: Optional[str] = None
    date: str
    notes: str

# Mock database
parts_db = [
    {
        "id": "PRT-001",
        "part_number": "BRG-6205-2RS",
        "name": "Deep Groove Ball Bearing",
        "description": "25x52x15mm sealed bearing",
        "category": "Bearings",
        "manufacturer": "SKF",
        "supplier": "Industrial Supply Co",
        "unit_cost": 24.50,
        "quantity_on_hand": 12,
        "reorder_point": 5,
        "maximum_stock": 25,
        "unit_of_measure": "each",
        "location": "A-1-15",
        "last_ordered": "2025-07-15",
        "compatible_assets": ["AST-001", "AST-002", "AST-005"]
    },
    {
        "id": "PRT-002",
        "part_number": "FLT-AIR-AC37",
        "name": "Air Filter Element",
        "description": "High efficiency air filter for AC37 compressor",
        "category": "Filters",
        "manufacturer": "Atlas Copco",
        "supplier": "Atlas Copco Parts",
        "unit_cost": 89.99,
        "quantity_on_hand": 3,
        "reorder_point": 2,
        "maximum_stock": 8,
        "unit_of_measure": "each",
        "location": "B-2-08",
        "last_ordered": "2025-08-01",
        "compatible_assets": ["AST-001"]
    },
    {
        "id": "PRT-003",
        "part_number": "OIL-SYN-5W30",
        "name": "Synthetic Compressor Oil",
        "description": "5W-30 synthetic oil for air compressors",
        "category": "Lubricants",
        "manufacturer": "Mobil",
        "supplier": "Lubricant Solutions",
        "unit_cost": 45.25,
        "quantity_on_hand": 8,
        "reorder_point": 3,
        "maximum_stock": 15,
        "unit_of_measure": "liter",
        "location": "C-1-03",
        "last_ordered": "2025-07-20",
        "compatible_assets": ["AST-001", "AST-004"]
    },
    {
        "id": "PRT-004",
        "part_number": "BLT-CONV-50M",
        "name": "Conveyor Belt",
        "description": "50m polyurethane conveyor belt, 300mm width",
        "category": "Belts",
        "manufacturer": "Habasit",
        "supplier": "Conveyor Systems Inc",
        "unit_cost": 1250.00,
        "quantity_on_hand": 1,
        "reorder_point": 1,
        "maximum_stock": 2,
        "unit_of_measure": "each",
        "location": "D-1-01",
        "last_ordered": "2025-06-10",
        "compatible_assets": ["AST-002"]
    },
    {
        "id": "PRT-005",
        "part_number": "VLV-SOL-24V",
        "name": "Solenoid Valve",
        "description": "24V DC 2-way solenoid valve, 1/2 inch",
        "category": "Valves",
        "manufacturer": "ASCO",
        "supplier": "Automation Parts Ltd",
        "unit_cost": 165.75,
        "quantity_on_hand": 0,
        "reorder_point": 2,
        "maximum_stock": 6,
        "unit_of_measure": "each",
        "location": "A-3-22",
        "last_ordered": "2025-05-15",
        "compatible_assets": ["AST-001", "AST-003", "AST-004"]
    },
    {
        "id": "PRT-006",
        "part_number": "SLG-PACK-300",
        "name": "Packaging Film",
        "description": "Heat sealable packaging film roll",
        "category": "Consumables",
        "manufacturer": "Sealed Air",
        "supplier": "Packaging Supplies Co",
        "unit_cost": 125.00,
        "quantity_on_hand": 24,
        "reorder_point": 10,
        "maximum_stock": 50,
        "unit_of_measure": "roll",
        "location": "E-2-15",
        "last_ordered": "2025-08-20",
        "compatible_assets": ["AST-005"]
    }
]

purchase_orders_db = [
    {
        "id": "PO-001",
        "supplier": "Industrial Supply Co",
        "order_date": "2025-08-25",
        "expected_delivery": "2025-09-02",
        "status": "pending",
        "total_cost": 490.00,
        "parts": [
            {"part_id": "PRT-001", "part_number": "BRG-6205-2RS", "quantity": 20, "unit_cost": 24.50}
        ]
    },
    {
        "id": "PO-002", 
        "supplier": "Automation Parts Ltd",
        "order_date": "2025-08-28",
        "expected_delivery": "2025-09-05",
        "status": "shipped",
        "total_cost": 663.00,
        "parts": [
            {"part_id": "PRT-005", "part_number": "VLV-SOL-24V", "quantity": 4, "unit_cost": 165.75}
        ]
    }
]

inventory_transactions_db = [
    {
        "id": "TXN-001",
        "part_id": "PRT-001",
        "transaction_type": "issued",
        "quantity": -2,
        "work_order_id": "WO-001",
        "date": "2025-08-20",
        "notes": "Issued for conveyor maintenance"
    },
    {
        "id": "TXN-002",
        "part_id": "PRT-003",
        "transaction_type": "issued",
        "quantity": -4,
        "work_order_id": "WO-002",
        "date": "2025-08-15",
        "notes": "Oil change for compressor"
    },
    {
        "id": "TXN-003",
        "part_id": "PRT-006",
        "transaction_type": "received",
        "quantity": 25,
        "work_order_id": None,
        "date": "2025-08-22",
        "notes": "Received shipment from supplier"
    }
]

# Parts manuals database
manuals_db = [
    {
        "id": "MAN-P001",
        "part_id": "PRT-001",
        "title": "SKF 6205-2RS Bearing Installation Guide",
        "type": "installation_guide",
        "file_url": "/manuals/skf_6205_2rs_installation.pdf",
        "file_size": "1.8 MB",
        "upload_date": "2025-08-01",
        "description": "Step-by-step installation procedures for deep groove ball bearings"
    },
    {
        "id": "MAN-P002",
        "part_id": "PRT-002",
        "title": "Atlas Copco Air Filter Maintenance Manual",
        "type": "maintenance_manual",
        "file_url": "/manuals/atlas_copco_air_filter_maintenance.pdf",
        "file_size": "3.2 MB",
        "upload_date": "2025-08-05",
        "description": "Complete maintenance procedures for air filter elements including replacement schedules"
    },
    {
        "id": "MAN-P003",
        "part_id": "PRT-003",
        "title": "Mobil Synthetic Oil Specifications",
        "type": "specification_sheet",
        "file_url": "/manuals/mobil_synthetic_oil_specs.pdf",
        "file_size": "0.8 MB",
        "upload_date": "2025-07-20",
        "description": "Technical specifications and application guidelines for 5W-30 synthetic compressor oil"
    },
    {
        "id": "MAN-P004",
        "part_id": "PRT-004",
        "title": "Habasit Conveyor Belt Installation Manual",
        "type": "installation_guide",
        "file_url": "/manuals/habasit_conveyor_belt_installation.pdf",
        "file_size": "5.4 MB",
        "upload_date": "2025-06-15",
        "description": "Comprehensive guide for conveyor belt installation, tensioning, and alignment procedures"
    },
    {
        "id": "MAN-P005",
        "part_id": "PRT-005",
        "title": "ASCO Solenoid Valve Technical Data",
        "type": "technical_manual",
        "file_url": "/manuals/asco_solenoid_valve_technical.pdf",
        "file_size": "2.1 MB",
        "upload_date": "2025-05-25",
        "description": "Technical data sheet with wiring diagrams, pressure ratings, and troubleshooting guide"
    },
    {
        "id": "MAN-P006",
        "part_id": "PRT-006",
        "title": "Sealed Air Packaging Film Specifications",
        "type": "specification_sheet",
        "file_url": "/manuals/sealed_air_packaging_film_specs.pdf",
        "file_size": "1.2 MB",
        "upload_date": "2025-08-22",
        "description": "Product specifications, temperature ranges, and sealing parameters for packaging film"
    }
]

@parts_router.get("/dashboard", response_class=HTMLResponse)
async def parts_dashboard():
    """Parts inventory dashboard with comprehensive overview and management"""
    total_parts = len(parts_db)
    low_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] <= p['reorder_point']])
    out_of_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] == 0])
    pending_orders = len([po for po in purchase_orders_db if po['status'] == 'pending'])
    total_inventory_value = sum(p['quantity_on_hand'] * p['unit_cost'] for p in parts_db)
    in_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] > p['reorder_point']])
    
    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix Parts Inventory</title>
        <style>""" + get_base_styles() + get_navigation_styles() + """
            .header { padding: 2rem; text-align: center; background: rgba(0,0,0,0.2); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 2rem; }
            .container {{ max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 1rem 0; }}
            .stat-value {{ font-size: 2rem; font-weight: bold; }}
            .status-good {{ color: #38a169; }}
            .status-warning {{ color: #d69e2e; }}
            .status-critical {{ color: #e53e3e; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-success {{ background: #38a169; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
            .table th, .table td {{ padding: 0.75rem; text-align: left; border-bottom: 1px solid #e2e8f0; }}
            .table th {{ background: #edf2f7; font-weight: 600; }}
            .filter-bar {{ background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; align-items: center; }}
            .filter-bar select, .filter-bar input {{ padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .stock-indicator {{ width: 12px; height: 12px; border-radius: 50%; display: inline-block; margin-right: 0.5rem; }}
            .stock-indicator.good {{ background: #38a169; }}
            .stock-indicator.warning {{ background: #d69e2e; }}
            .stock-indicator.critical {{ background: #e53e3e; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>=� ChatterFix Parts Inventory</h1>
            <p>Parts Management, Ordering & Stock Control</p>
        </div>
        
        <div class="container">
            <!-- Stats Overview -->
            <div class="grid">
                <div class="card">
                    <h3>=� Inventory Overview</h3>
                    <div class="stat">
                        <span>Total Parts</span>
                        <span class="stat-value">{total_parts}</span>
                    </div>
                    <div class="stat">
                        <span>Low Stock Items</span>
                        <span class="stat-value status-warning">{low_stock_parts}</span>
                    </div>
                    <div class="stat">
                        <span>Out of Stock</span>
                        <span class="stat-value status-critical">{out_of_stock_parts}</span>
                    </div>
                    <div class="stat">
                        <span>Total Value</span>
                        <span class="stat-value">${total_inventory_value:,.2f}</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>=� Quick Actions</h3>
                    <button class="btn" onclick="addPart()">Add New Part</button>
                    <button class="btn btn-warning" onclick="createPurchaseOrder()">Create Purchase Order</button>
                    <button class="btn btn-success" onclick="receiveShipment()">Receive Shipment</button>
                    <button class="btn" onclick="adjustInventory()">Adjust Inventory</button>
                    <button class="btn" onclick="window.location.href='/cmms/parts/manuals'">📚 Parts Manuals</button>
                    <button class="btn" onclick="generateReport()">Generate Report</button>
                </div>
                
                <div class="card">
                    <h3>=� Purchase Orders</h3>
                    <div class="stat">
                        <span>Pending Orders</span>
                        <span class="stat-value status-warning">{pending_orders}</span>
                    </div>
                    <div class="stat">
                        <span>Expected This Week</span>
                        <span class="stat-value">2</span>
                    </div>
                    <button class="btn" onclick="viewPurchaseOrders()">View All Orders</button>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <label>Filter by:</label>
                <select id="categoryFilter" onchange="filterParts()">
                    <option value="">All Categories</option>
                    <option value="Bearings">Bearings</option>
                    <option value="Filters">Filters</option>
                    <option value="Lubricants">Lubricants</option>
                    <option value="Belts">Belts</option>
                    <option value="Valves">Valves</option>
                    <option value="Consumables">Consumables</option>
                </select>
                <select id="stockFilter" onchange="filterParts()">
                    <option value="">All Stock Levels</option>
                    <option value="low">Low Stock</option>
                    <option value="out">Out of Stock</option>
                    <option value="good">Good Stock</option>
                </select>
                <select id="supplierFilter" onchange="filterParts()">
                    <option value="">All Suppliers</option>
                    <option value="Industrial Supply Co">Industrial Supply Co</option>
                    <option value="Atlas Copco Parts">Atlas Copco Parts</option>
                    <option value="Lubricant Solutions">Lubricant Solutions</option>
                    <option value="Automation Parts Ltd">Automation Parts Ltd</option>
                </select>
                <input type="text" id="searchFilter" placeholder="Search parts..." onkeyup="filterParts()">
            </div>
            
            <!-- Parts Table -->
            <div class="card">
                <h3>=� Parts Inventory</h3>
                <table class="table" id="partsTable">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Part Number</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>On Hand</th>
                            <th>Reorder Point</th>
                            <th>Unit Cost</th>
                            <th>Location</th>
                            <th>Last Ordered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {chr(10).join([f'''
                        <tr data-category="{part['category']}" data-supplier="{part['supplier']}" data-name="{part['name'].lower()}" data-stock="{'out' if part['quantity_on_hand'] == 0 else 'low' if part['quantity_on_hand'] <= part['reorder_point'] else 'good'}">
                            <td>
                                <span class="stock-indicator {'critical' if part['quantity_on_hand'] == 0 else 'warning' if part['quantity_on_hand'] <= part['reorder_point'] else 'good'}"></span>
                                {'Out of Stock' if part['quantity_on_hand'] == 0 else 'Low Stock' if part['quantity_on_hand'] <= part['reorder_point'] else 'In Stock'}
                            </td>
                            <td><strong>{part['part_number']}</strong></td>
                            <td>{part['name']}</td>
                            <td>{part['category']}</td>
                            <td><strong>{part['quantity_on_hand']}</strong></td>
                            <td>{part['reorder_point']}</td>
                            <td>${part['unit_cost']:,.2f}</td>
                            <td>{part['location']}</td>
                            <td>{part.get('last_ordered', 'Never')}</td>
                            <td>
                                <button class="btn btn-sm" onclick="viewPartDetails('{part['id']}')">Details</button>
                                <button class="btn btn-sm btn-warning" onclick="orderPart('{part['id']}')">Order</button>
                                <button class="btn btn-sm" onclick="adjustStock('{part['id']}')">Adjust</button>
                            </td>
                        </tr>''' for part in parts_db])}
                    </tbody>
                </table>
            </div>
            
            <!-- Recent Transactions -->
            <div class="card" style="margin-top: 2rem;">
                <h3>=� Recent Transactions</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Part</th>
                            <th>Type</th>
                            <th>Quantity</th>
                            <th>Work Order</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        {chr(10).join([f'''
                        <tr>
                            <td>{txn['date']}</td>
                            <td>{next((p['part_number'] for p in parts_db if p['id'] == txn['part_id']), 'Unknown')}</td>
                            <td><span class="btn btn-sm {'btn-danger' if txn['transaction_type'] == 'issued' else 'btn-success'}">{txn['transaction_type'].title()}</span></td>
                            <td>{abs(txn['quantity'])}</td>
                            <td>{txn.get('work_order_id', '-')}</td>
                            <td>{txn['notes'][:30]}{'...' if len(txn['notes']) > 30 else ''}</td>
                        </tr>''' for txn in inventory_transactions_db[-10:]])}
                    </tbody>
                </table>
            </div>
        </div>
        
        <script>
            function filterParts() {{
                const categoryFilter = document.getElementById('categoryFilter').value;
                const stockFilter = document.getElementById('stockFilter').value;
                const supplierFilter = document.getElementById('supplierFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const rows = document.querySelectorAll('#partsTable tbody tr');
                rows.forEach(row => {{
                    const category = row.dataset.category;
                    const stock = row.dataset.stock;
                    const supplier = row.dataset.supplier;
                    const name = row.dataset.name;
                    
                    const categoryMatch = !categoryFilter || category === categoryFilter;
                    const stockMatch = !stockFilter || stock === stockFilter;
                    const supplierMatch = !supplierFilter || supplier === supplierFilter;
                    const searchMatch = !searchFilter || name.includes(searchFilter);
                    
                    row.style.display = (categoryMatch && stockMatch && supplierMatch && searchMatch) ? '' : 'none';
                }});
            }}
            
            function addPart() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; max-height: 90%; overflow-y: auto;" onclick="event.stopPropagation()">
                            <h3>Add New Part</h3>
                            <form id="addPartForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Part Number:</label><br>
                                    <input type="text" name="part_number" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Part Name:</label><br>
                                    <input type="text" name="name" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Description:</label><br>
                                    <textarea name="description" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 60px;"></textarea>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Category:</label><br>
                                    <select name="category" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="">Select Category</option>
                                        <option value="Bearings">Bearings</option>
                                        <option value="Filters">Filters</option>
                                        <option value="Lubricants">Lubricants</option>
                                        <option value="Belts">Belts</option>
                                        <option value="Valves">Valves</option>
                                        <option value="Consumables">Consumables</option>
                                    </select>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Manufacturer:</label><br>
                                    <input type="text" name="manufacturer" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Supplier:</label><br>
                                    <input type="text" name="supplier" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Unit Cost:</label><br>
                                        <input type="number" step="0.01" name="unit_cost" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                    <div>
                                        <label>Reorder Point:</label><br>
                                        <input type="number" name="reorder_point" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Stock Location:</label><br>
                                    <input type="text" name="location" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" class="btn">Add Part</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('addPartForm').addEventListener('submit', function(e) {{
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const partData = Object.fromEntries(formData);
                    
                    fetch('/parts', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(partData)
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Part added:', data);
                        location.reload();
                    }});
                }});
            }}
            
            function closeModal(event) {{
                if (event.target === event.currentTarget) {{
                    document.body.removeChild(event.currentTarget);
                }}
            }}
            
            function viewPartDetails(partId) {{
                window.open(`/parts/${{partId}}`, '_blank');
            }}
            
            function orderPart(partId) {{
                window.location.href = `/parts/${{partId}}/order`;
            }}
            
            function adjustStock(partId) {{
                const newQuantity = prompt('Enter new quantity:');
                if (newQuantity !== null && !isNaN(newQuantity)) {{
                    fetch(`/parts/${{partId}}/adjust`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ 
                            quantity: parseInt(newQuantity),
                            notes: 'Manual adjustment'
                        }})
                    }})
                    .then(() => location.reload());
                }}
            }}
            
            function createPurchaseOrder() {{
                window.location.href = '/parts/purchase-orders/create';
            }}
            
            function receiveShipment() {{
                window.location.href = '/parts/receive';
            }}
            
            function adjustInventory() {{
                window.location.href = '/parts/adjust';
            }}
            
            function generateReport() {{
                window.open('/parts/reports', '_blank');
            }}
            
            function viewPurchaseOrders() {{
                window.location.href = '/parts/purchase-orders';
            }}
        </script>
    </body>
    </html>
    """

@parts_router.get("/manuals", response_class=HTMLResponse)
async def parts_manuals():
    """Parts manuals and documentation dashboard"""
    breadcrumbs = [
        {"name": "Parts", "url": "/cmms/parts/dashboard"},
        {"name": "Manuals"}
    ]
    
    navigation_html = get_navigation_html('parts', breadcrumbs)
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix Parts - Manuals & Documentation</title>
        <style>""" + get_base_styles() + get_navigation_styles() + """
        </style>
    </head>
    <body>
        """ + navigation_html + f"""
        
        <div class="header">
            <h1>📚 Parts Manuals & Documentation</h1>
            <p>Installation guides, specifications, and technical documentation</p>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card">
                    <h3>📊 Documentation Statistics</h3>
                    <div class="stat-value">{len(manuals_db)}</div>
                    <div>Total Manuals</div>
                    <br>
                    <div class="stat-value">{len(set(m['type'] for m in manuals_db))}</div>
                    <div>Document Types</div>
                    <br>
                    <div class="stat-value">{len(set(m['part_id'] for m in manuals_db))}</div>
                    <div>Parts Covered</div>
                </div>
                
                <div class="card">
                    <h3>🔍 Search & Filter</h3>
                    <input type="text" id="searchManuals" placeholder="Search manuals..." style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                    <br><br>
                    <select id="typeFilter" onchange="filterManuals()" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        <option value="">All Document Types</option>
                        <option value="installation_guide">Installation Guides</option>
                        <option value="maintenance_manual">Maintenance Manuals</option>
                        <option value="specification_sheet">Specification Sheets</option>
                        <option value="technical_manual">Technical Manuals</option>
                    </select>
                </div>
                
                <div class="card">
                    <h3>⚡ Quick Actions</h3>
                    <button class="btn" onclick="uploadManual()">📤 Upload Manual</button>
                    <button class="btn" onclick="createManual()">➕ Create Manual</button>
                    <button class="btn" onclick="bulkUpload()">📁 Bulk Upload</button>
                    <button class="btn" onclick="exportManuals()">📥 Export List</button>
                </div>
            </div>
            
            <div class="card">
                <h3>📖 Parts Documentation Library</h3>
                <div id="manualsGrid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 1rem; margin-top: 1rem;">
    """
    
    # Add each manual card
    for manual in manuals_db:
        # Find the corresponding part
        part = next((p for p in parts_db if p['id'] == manual['part_id']), None)
        part_name = part['name'] if part else 'Unknown Part'
        part_number = part['part_number'] if part else 'N/A'
        
        type_icons = {
            'installation_guide': '🔧',
            'maintenance_manual': '⚙️',
            'specification_sheet': '📋',
            'technical_manual': '🔬',
            'safety_manual': '⚠️',
            'operation_manual': '▶️'
        }
        
        icon = type_icons.get(manual['type'], '📄')
        
        html_content += f"""
                    <div class="card" data-type="{manual['type']}" data-part="{part_name.lower()}" data-title="{manual['title'].lower()}" style="margin: 0; padding: 1.5rem;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                            <div style="flex: 1;">
                                <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                                    <span style="font-size: 1.5rem; margin-right: 0.5rem;">{icon}</span>
                                    <h4 style="margin: 0; color: white;">{manual['title']}</h4>
                                </div>
                                <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.7); font-size: 0.9rem;">
                                    Part: <strong>{part_number} - {part_name}</strong>
                                </p>
                                <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.6); font-size: 0.85rem;">
                                    {manual['description']}
                                </p>
                            </div>
                        </div>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding: 0.75rem; background: rgba(255,255,255,0.1); border-radius: 8px;">
                            <div style="font-size: 0.85rem;">
                                <div><strong>Type:</strong> {manual['type'].replace('_', ' ').title()}</div>
                                <div><strong>Size:</strong> {manual['file_size']}</div>
                                <div><strong>Uploaded:</strong> {manual['upload_date']}</div>
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                            <button class="btn" onclick="viewManual('{manual['id']}', '{manual['file_url']}')" style="font-size: 0.85rem;">📖 View</button>
                            <button class="btn" onclick="downloadManual('{manual['id']}', '{manual['file_url']}')" style="font-size: 0.85rem;">⬇️ Download</button>
                            <button class="btn" onclick="shareManual('{manual['id']}')" style="font-size: 0.85rem;">🔗 Share</button>
                            <button class="btn" onclick="editManual('{manual['id']}')" style="font-size: 0.85rem;">✏️ Edit</button>
                        </div>
                    </div>
        """
    
    html_content += f"""
                </div>
            </div>
        </div>
        
        <script>
            {get_navigation_javascript()}
            
            function filterManuals() {{
                const searchTerm = document.getElementById('searchManuals').value.toLowerCase();
                const typeFilter = document.getElementById('typeFilter').value;
                const cards = document.querySelectorAll('#manualsGrid .card');
                
                cards.forEach(card => {{
                    const title = card.dataset.title || '';
                    const part = card.dataset.part || '';
                    const type = card.dataset.type || '';
                    
                    const matchesSearch = !searchTerm || title.includes(searchTerm) || part.includes(searchTerm);
                    const matchesType = !typeFilter || type === typeFilter;
                    
                    card.style.display = (matchesSearch && matchesType) ? 'block' : 'none';
                }});
            }}
            
            document.getElementById('searchManuals').addEventListener('input', filterManuals);
            
            function viewManual(manualId, fileUrl) {{
                window.open(fileUrl, '_blank');
                console.log('Viewing manual:', manualId);
            }}
            
            function downloadManual(manualId, fileUrl) {{
                const link = document.createElement('a');
                link.href = fileUrl;
                link.download = true;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                console.log('Downloading manual:', manualId);
            }}
            
            function shareManual(manualId) {{
                const shareUrl = window.location.origin + `/cmms/parts/manuals/${{manualId}}`;
                if (navigator.share) {{
                    navigator.share({{
                        title: 'Parts Manual',
                        url: shareUrl
                    }});
                }} else {{
                    navigator.clipboard.writeText(shareUrl);
                    alert('Manual link copied to clipboard!');
                }}
            }}
            
            function editManual(manualId) {{
                alert(`Edit manual functionality would open for manual ID: ${{manualId}}`);
            }}
            
            function uploadManual() {{
                alert('Upload manual dialog would open here');
            }}
            
            function createManual() {{
                alert('Create new manual form would open here');
            }}
            
            function bulkUpload() {{
                alert('Bulk upload interface would open here');
            }}
            
            function exportManuals() {{
                alert('Export manuals list functionality');
            }}
        </script>
    </body>
    </html>
    """
    
    return html_content

@parts_router.get("/")
async def get_parts(
    category: Optional[str] = Query(None),
    supplier: Optional[str] = Query(None),
    low_stock: Optional[bool] = Query(None)
) -> List[Dict]:
    """Get all parts with optional filtering"""
    filtered_parts = parts_db
    
    if category:
        filtered_parts = [p for p in filtered_parts if p['category'] == category]
    if supplier:
        filtered_parts = [p for p in filtered_parts if p['supplier'] == supplier]
    if low_stock:
        filtered_parts = [p for p in filtered_parts if p['quantity_on_hand'] <= p['reorder_point']]
    
    return filtered_parts

@parts_router.get("/{part_id}")
async def get_part(part_id: str) -> Dict:
    """Get specific part details"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    # Get transaction history for this part
    transactions = [t for t in inventory_transactions_db if t['part_id'] == part_id]
    
    return {
        "part": part,
        "transactions": transactions,
        "usage_stats": {
            "total_issued_ytd": sum(abs(t['quantity']) for t in transactions if t['transaction_type'] == 'issued'),
            "total_received_ytd": sum(t['quantity'] for t in transactions if t['transaction_type'] == 'received'),
            "average_monthly_usage": 5.2,  # Would calculate from actual data
            "stock_days_remaining": part['quantity_on_hand'] / (5.2 / 30) if part['quantity_on_hand'] > 0 else 0
        }
    }

@parts_router.post("/")
async def create_part(part_data: Dict[str, Any]) -> Dict:
    """Create new part"""
    part_id = f"PRT-{len(parts_db) + 1:03d}"
    
    new_part = {
        "id": part_id,
        "part_number": part_data["part_number"],
        "name": part_data["name"],
        "description": part_data["description"],
        "category": part_data["category"],
        "manufacturer": part_data["manufacturer"],
        "supplier": part_data["supplier"],
        "unit_cost": float(part_data["unit_cost"]),
        "quantity_on_hand": 0,
        "reorder_point": int(part_data["reorder_point"]),
        "maximum_stock": int(part_data.get("maximum_stock", part_data["reorder_point"] * 3)),
        "unit_of_measure": part_data.get("unit_of_measure", "each"),
        "location": part_data["location"],
        "last_ordered": None,
        "compatible_assets": part_data.get("compatible_assets", [])
    }
    
    parts_db.append(new_part)
    logger.info(f"Part created: {part_id}")
    return new_part

@parts_router.post("/{part_id}/adjust")
async def adjust_inventory(part_id: str, adjustment_data: Dict[str, Any]) -> Dict:
    """Adjust part inventory"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    old_quantity = part['quantity_on_hand']
    new_quantity = adjustment_data['quantity']
    
    # Create transaction record
    transaction_id = f"TXN-{len(inventory_transactions_db) + 1:03d}"
    transaction = {
        "id": transaction_id,
        "part_id": part_id,
        "transaction_type": "adjusted",
        "quantity": new_quantity - old_quantity,
        "work_order_id": None,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "notes": adjustment_data.get("notes", "Inventory adjustment")
    }
    
    inventory_transactions_db.append(transaction)
    part['quantity_on_hand'] = new_quantity
    
    logger.info(f"Inventory adjusted for part {part_id}: {old_quantity} -> {new_quantity}")
    return {"transaction": transaction, "part": part}

@parts_router.post("/{part_id}/issue")
async def issue_part(part_id: str, issue_data: Dict[str, Any]) -> Dict:
    """Issue part to work order"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    quantity = issue_data['quantity']
    if quantity > part['quantity_on_hand']:
        raise HTTPException(status_code=400, detail="Insufficient stock")
    
    # Create transaction record
    transaction_id = f"TXN-{len(inventory_transactions_db) + 1:03d}"
    transaction = {
        "id": transaction_id,
        "part_id": part_id,
        "transaction_type": "issued",
        "quantity": -quantity,
        "work_order_id": issue_data.get("work_order_id"),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "notes": issue_data.get("notes", f"Issued to work order {issue_data.get('work_order_id')}")
    }
    
    inventory_transactions_db.append(transaction)
    part['quantity_on_hand'] -= quantity
    
    logger.info(f"Part issued: {part_id} quantity {quantity}")
    return {"transaction": transaction, "part": part}

@parts_router.post("/{part_id}/receive")
async def receive_part(part_id: str, receive_data: Dict[str, Any]) -> Dict:
    """Receive part shipment"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    quantity = receive_data['quantity']
    
    # Create transaction record
    transaction_id = f"TXN-{len(inventory_transactions_db) + 1:03d}"
    transaction = {
        "id": transaction_id,
        "part_id": part_id,
        "transaction_type": "received",
        "quantity": quantity,
        "work_order_id": None,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "notes": receive_data.get("notes", f"Received shipment - PO: {receive_data.get('purchase_order_id')}")
    }
    
    inventory_transactions_db.append(transaction)
    part['quantity_on_hand'] += quantity
    part['last_ordered'] = datetime.now().strftime("%Y-%m-%d")
    
    logger.info(f"Part received: {part_id} quantity {quantity}")
    return {"transaction": transaction, "part": part}

@parts_router.get("/purchase-orders")
async def get_purchase_orders() -> List[Dict]:
    """Get all purchase orders"""
    return purchase_orders_db

@parts_router.post("/purchase-orders")
async def create_purchase_order(po_data: Dict[str, Any]) -> Dict:
    """Create new purchase order"""
    po_id = f"PO-{len(purchase_orders_db) + 1:03d}"
    
    # Calculate total cost
    total_cost = sum(item['quantity'] * item['unit_cost'] for item in po_data['parts'])
    
    new_po = {
        "id": po_id,
        "supplier": po_data["supplier"],
        "order_date": datetime.now().strftime("%Y-%m-%d"),
        "expected_delivery": po_data.get("expected_delivery"),
        "status": "pending",
        "total_cost": total_cost,
        "parts": po_data["parts"]
    }
    
    purchase_orders_db.append(new_po)
    logger.info(f"Purchase order created: {po_id}")
    return new_po

@parts_router.get("/reports/low-stock")
async def get_low_stock_report() -> Dict:
    """Get low stock report"""
    low_stock_parts = [p for p in parts_db if p['quantity_on_hand'] <= p['reorder_point']]
    out_of_stock_parts = [p for p in parts_db if p['quantity_on_hand'] == 0]
    
    return {
        "low_stock_parts": low_stock_parts,
        "out_of_stock_parts": out_of_stock_parts,
        "total_low_stock": len(low_stock_parts),
        "total_out_of_stock": len(out_of_stock_parts),
        "recommended_orders": [
            {
                "part_id": p['id'],
                "part_number": p['part_number'],
                "current_stock": p['quantity_on_hand'],
                "reorder_point": p['reorder_point'],
                "recommended_quantity": p['maximum_stock'] - p['quantity_on_hand'],
                "estimated_cost": (p['maximum_stock'] - p['quantity_on_hand']) * p['unit_cost']
            }
            for p in low_stock_parts
        ],
        "generated_at": datetime.now().isoformat()
    }

@parts_router.get("/reports/inventory-value")
async def get_inventory_value_report() -> Dict:
    """Get inventory value report"""
    parts_by_category = {}
    for part in parts_db:
        category = part['category']
        if category not in parts_by_category:
            parts_by_category[category] = {
                "count": 0,
                "total_value": 0,
                "parts": []
            }
        
        part_value = part['quantity_on_hand'] * part['unit_cost']
        parts_by_category[category]['count'] += 1
        parts_by_category[category]['total_value'] += part_value
        parts_by_category[category]['parts'].append({
            "id": part['id'],
            "part_number": part['part_number'],
            "name": part['name'],
            "quantity": part['quantity_on_hand'],
            "unit_cost": part['unit_cost'],
            "total_value": part_value
        })
    
    total_inventory_value = sum(cat['total_value'] for cat in parts_by_category.values())
    
    return {
        "total_inventory_value": total_inventory_value,
        "by_category": parts_by_category,
        "total_parts": len(parts_db),
        "generated_at": datetime.now().isoformat()
    }