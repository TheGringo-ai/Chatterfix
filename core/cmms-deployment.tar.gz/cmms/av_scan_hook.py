#!/usr/bin/env python3
"""
ChatterFix CMMS - Antivirus Scan Hook Integration
Extensible antivirus scanning with multiple engine support
"""

import os
import subprocess
import asyncio
import tempfile
import json
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Union
from pathlib import Path
from pydantic import BaseModel
from abc import ABC, abstractmethod

# =============================================================================
# Configuration
# =============================================================================

AV_SCAN_TIMEOUT = int(os.getenv("AV_SCAN_TIMEOUT", "60"))  # seconds
AV_QUARANTINE_ON_THREAT = os.getenv("AV_QUARANTINE_ON_THREAT", "true").lower() == "true"
AV_LOG_SCANS = os.getenv("AV_LOG_SCANS", "true").lower() == "true"

# =============================================================================
# Data Models
# =============================================================================

class ScanResult(BaseModel):
    engine: str
    clean: bool
    threats: List[str]
    scan_time_ms: int
    engine_version: Optional[str]
    signature_date: Optional[str]
    error: Optional[str]

class CompositeScanResult(BaseModel):
    file_path: str
    file_hash: str
    overall_clean: bool
    scan_results: List[ScanResult]
    consensus_threats: List[str]
    total_scan_time_ms: int
    timestamp: datetime
    engines_used: List[str]

# =============================================================================
# Abstract Base Engine
# =============================================================================

class AntivirusEngine(ABC):
    """Abstract base class for antivirus engines"""
    
    @property
    @abstractmethod
    def engine_name(self) -> str:
        pass
    
    @abstractmethod
    async def is_available(self) -> bool:
        pass
    
    @abstractmethod
    async def get_version(self) -> Optional[str]:
        pass
    
    @abstractmethod
    async def scan_file(self, file_path: str) -> ScanResult:
        pass
    
    @abstractmethod 
    async def update_signatures(self) -> bool:
        pass

# =============================================================================
# ClamAV Engine Implementation
# =============================================================================

class ClamAVEngine(AntivirusEngine):
    """ClamAV antivirus engine integration"""
    
    @property
    def engine_name(self) -> str:
        return "ClamAV"
    
    async def is_available(self) -> bool:
        """Check if ClamAV is available"""
        try:
            process = await asyncio.create_subprocess_exec(
                "clamscan", "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await asyncio.wait_for(process.communicate(), timeout=5)
            return process.returncode == 0
        except (asyncio.TimeoutError, FileNotFoundError):
            return False
    
    async def get_version(self) -> Optional[str]:
        """Get ClamAV version information"""
        try:
            process = await asyncio.create_subprocess_exec(
                "clamscan", "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout=5)
            
            if process.returncode == 0:
                version_line = stdout.decode().strip().split('\n')[0]
                return version_line
            return None
        except (asyncio.TimeoutError, FileNotFoundError):
            return None
    
    async def scan_file(self, file_path: str) -> ScanResult:
        """Scan a file with ClamAV"""
        start_time = datetime.now()
        
        try:
            # Run ClamAV scan
            process = await asyncio.create_subprocess_exec(
                "clamscan", 
                "--no-summary",
                "--infected", 
                file_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), 
                timeout=AV_SCAN_TIMEOUT
            )
            
            scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            # Parse results
            output = stdout.decode()
            threats = []
            
            if process.returncode == 1:  # Threat found
                # Extract threat names from output
                for line in output.split('\n'):
                    if ' FOUND' in line:
                        threat_name = line.split(':')[-1].replace(' FOUND', '').strip()
                        if threat_name:
                            threats.append(threat_name)
            
            clean = (process.returncode == 0)
            version = await self.get_version()
            
            return ScanResult(
                engine=self.engine_name,
                clean=clean,
                threats=threats,
                scan_time_ms=scan_time,
                engine_version=version,
                signature_date=None,  # ClamAV doesn't easily provide this
                error=stderr.decode() if stderr else None
            )
            
        except asyncio.TimeoutError:
            scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
            return ScanResult(
                engine=self.engine_name,
                clean=False,
                threats=[],
                scan_time_ms=scan_time,
                engine_version=None,
                signature_date=None,
                error="Scan timeout"
            )
        except Exception as e:
            scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
            return ScanResult(
                engine=self.engine_name,
                clean=False,
                threats=[],
                scan_time_ms=scan_time,
                engine_version=None,
                signature_date=None,
                error=str(e)
            )
    
    async def update_signatures(self) -> bool:
        """Update ClamAV virus signatures"""
        try:
            process = await asyncio.create_subprocess_exec(
                "freshclam",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await asyncio.wait_for(process.communicate(), timeout=300)  # 5 minutes
            return process.returncode == 0
        except (asyncio.TimeoutError, FileNotFoundError, PermissionError):
            return False

# =============================================================================
# YARA Engine Implementation (for custom rules)
# =============================================================================

class YARAEngine(AntivirusEngine):
    """YARA rules engine for custom threat detection"""
    
    def __init__(self, rules_directory: str = "./yara_rules"):
        self.rules_directory = Path(rules_directory)
        self.rules_directory.mkdir(exist_ok=True)
        self._create_default_rules()
    
    @property
    def engine_name(self) -> str:
        return "YARA"
    
    def _create_default_rules(self):
        """Create default YARA rules for common threats"""
        default_rules = '''
rule SuspiciousJavaScript {
    meta:
        description = "Detects potentially malicious JavaScript"
        severity = "medium"
    strings:
        $js1 = "eval(" nocase
        $js2 = "document.write(" nocase
        $js3 = "window.location" nocase
        $js4 = "<script" nocase
    condition:
        any of them
}

rule EmbeddedExecutable {
    meta:
        description = "Detects embedded executable content"
        severity = "high"
    strings:
        $exe1 = { 4D 5A }  // MZ header
        $exe2 = "This program cannot be run in DOS mode"
    condition:
        $exe1 at 0 or $exe2
}

rule SuspiciousURLs {
    meta:
        description = "Detects suspicious URLs"
        severity = "medium"
    strings:
        $url1 = /https?:\/\/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/ nocase
        $url2 = "bit.ly/" nocase
        $url3 = "tinyurl.com/" nocase
    condition:
        any of them
}
'''
        
        rules_file = self.rules_directory / "default.yar"
        if not rules_file.exists():
            with open(rules_file, 'w') as f:
                f.write(default_rules)
    
    async def is_available(self) -> bool:
        """Check if YARA is available"""
        try:
            process = await asyncio.create_subprocess_exec(
                "yara", "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await asyncio.wait_for(process.communicate(), timeout=5)
            return process.returncode == 0
        except (asyncio.TimeoutError, FileNotFoundError):
            return False
    
    async def get_version(self) -> Optional[str]:
        """Get YARA version information"""
        try:
            process = await asyncio.create_subprocess_exec(
                "yara", "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout=5)
            
            if process.returncode == 0:
                return stdout.decode().strip()
            return None
        except (asyncio.TimeoutError, FileNotFoundError):
            return None
    
    async def scan_file(self, file_path: str) -> ScanResult:
        """Scan a file with YARA rules"""
        start_time = datetime.now()
        
        try:
            # Find all YARA rules
            rule_files = list(self.rules_directory.glob("*.yar"))
            
            if not rule_files:
                return ScanResult(
                    engine=self.engine_name,
                    clean=True,
                    threats=[],
                    scan_time_ms=0,
                    engine_version=await self.get_version(),
                    signature_date=None,
                    error="No YARA rules found"
                )
            
            threats = []
            
            # Run YARA scan for each rule file
            for rule_file in rule_files:
                process = await asyncio.create_subprocess_exec(
                    "yara",
                    str(rule_file),
                    file_path,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=AV_SCAN_TIMEOUT
                )
                
                # Parse YARA output
                if stdout:
                    for line in stdout.decode().split('\n'):
                        line = line.strip()
                        if line:
                            # YARA output format: "rule_name file_path"
                            rule_name = line.split()[0] if line.split() else line
                            threats.append(f"YARA:{rule_name}")
            
            scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            return ScanResult(
                engine=self.engine_name,
                clean=(len(threats) == 0),
                threats=threats,
                scan_time_ms=scan_time,
                engine_version=await self.get_version(),
                signature_date=None,
                error=None
            )
            
        except asyncio.TimeoutError:
            scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
            return ScanResult(
                engine=self.engine_name,
                clean=False,
                threats=[],
                scan_time_ms=scan_time,
                engine_version=None,
                signature_date=None,
                error="Scan timeout"
            )
        except Exception as e:
            scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
            return ScanResult(
                engine=self.engine_name,
                clean=False,
                threats=[],
                scan_time_ms=scan_time,
                engine_version=None,
                signature_date=None,
                error=str(e)
            )
    
    async def update_signatures(self) -> bool:
        """Update YARA rules (placeholder for custom implementation)"""
        # In a production environment, this might download updated rules
        # from a threat intelligence feed
        return True

# =============================================================================
# Multi-Engine Scanner
# =============================================================================

class MultiEngineScanner:
    """Multi-engine antivirus scanner with consensus detection"""
    
    def __init__(self):
        self.engines: List[AntivirusEngine] = [
            ClamAVEngine(),
            YARAEngine()
        ]
    
    async def get_available_engines(self) -> List[AntivirusEngine]:
        """Get list of available antivirus engines"""
        available = []
        for engine in self.engines:
            if await engine.is_available():
                available.append(engine)
        return available
    
    async def scan_file_comprehensive(self, file_path: str, file_hash: str = "") -> CompositeScanResult:
        """
        Comprehensive multi-engine file scan
        """
        start_time = datetime.now()
        available_engines = await self.get_available_engines()
        
        if not available_engines:
            return CompositeScanResult(
                file_path=file_path,
                file_hash=file_hash,
                overall_clean=False,
                scan_results=[],
                consensus_threats=["No antivirus engines available"],
                total_scan_time_ms=0,
                timestamp=start_time,
                engines_used=[]
            )
        
        # Run scans concurrently
        scan_tasks = [engine.scan_file(file_path) for engine in available_engines]
        scan_results = await asyncio.gather(*scan_tasks, return_exceptions=True)
        
        # Process results
        valid_results = []
        for i, result in enumerate(scan_results):
            if isinstance(result, ScanResult):
                valid_results.append(result)
            else:
                # Handle exceptions
                error_result = ScanResult(
                    engine=available_engines[i].engine_name,
                    clean=False,
                    threats=[],
                    scan_time_ms=0,
                    engine_version=None,
                    signature_date=None,
                    error=str(result)
                )
                valid_results.append(error_result)
        
        # Determine consensus
        threat_votes = {}
        clean_votes = 0
        
        for result in valid_results:
            if result.clean and not result.error:
                clean_votes += 1
            for threat in result.threats:
                if threat not in threat_votes:
                    threat_votes[threat] = 0
                threat_votes[threat] += 1
        
        # Consensus logic: threat must be detected by at least one reliable engine
        consensus_threats = []
        for threat, votes in threat_votes.items():
            if votes >= 1:  # At least one engine detected it
                consensus_threats.append(threat)
        
        # Overall clean if majority say clean and no consensus threats
        overall_clean = (clean_votes > len(valid_results) // 2) and len(consensus_threats) == 0
        
        total_scan_time = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return CompositeScanResult(
            file_path=file_path,
            file_hash=file_hash,
            overall_clean=overall_clean,
            scan_results=valid_results,
            consensus_threats=consensus_threats,
            total_scan_time_ms=total_scan_time,
            timestamp=start_time,
            engines_used=[engine.engine_name for engine in available_engines]
        )
    
    async def update_all_engines(self) -> Dict[str, bool]:
        """Update signatures for all available engines"""
        available_engines = await self.get_available_engines()
        results = {}
        
        for engine in available_engines:
            try:
                success = await engine.update_signatures()
                results[engine.engine_name] = success
            except Exception as e:
                results[engine.engine_name] = False
        
        return results

# =============================================================================
# Scan Hook Functions
# =============================================================================

# Global scanner instance
_scanner = MultiEngineScanner()

async def scan_file_with_av(file_path: str, file_hash: str = "") -> CompositeScanResult:
    """
    Main function to scan a file with all available AV engines
    """
    result = await _scanner.scan_file_comprehensive(file_path, file_hash)
    
    # Log scan result if logging is enabled
    if AV_LOG_SCANS:
        log_entry = {
            "timestamp": result.timestamp.isoformat(),
            "file_path": result.file_path,
            "file_hash": result.file_hash,
            "overall_clean": result.overall_clean,
            "threats": result.consensus_threats,
            "engines_used": result.engines_used,
            "total_scan_time_ms": result.total_scan_time_ms
        }
        
        # In production, this would go to a proper logging system
        print(f"AV_SCAN_LOG: {json.dumps(log_entry)}")
    
    return result

async def get_av_engine_status() -> Dict:
    """Get status of all antivirus engines"""
    engines = await _scanner.get_available_engines()
    
    engine_status = {}
    for engine in engines:
        version = await engine.get_version()
        engine_status[engine.engine_name] = {
            "available": True,
            "version": version
        }
    
    return {
        "engines": engine_status,
        "total_engines": len(engines),
        "scan_timeout": AV_SCAN_TIMEOUT,
        "quarantine_on_threat": AV_QUARANTINE_ON_THREAT
    }

async def update_av_signatures() -> Dict[str, bool]:
    """Update antivirus signatures for all engines"""
    return await _scanner.update_all_engines()