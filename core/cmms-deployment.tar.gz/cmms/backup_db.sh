#!/bin/bash

# ChatterFix CMMS Database Backup Script
# Backs up SQLite database with timestamp and uploads to cloud storage

set -e

# Configuration
DB_PATH="./cmms.db"
BACKUP_DIR="./backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="cmms_backup_$DATE.db"
BACKUP_PATH="$BACKUP_DIR/$BACKUP_NAME"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}🗄️  ChatterFix CMMS Database Backup Starting...${NC}"
echo "📅 Timestamp: $(date)"
echo "💾 Database: $DB_PATH"
echo "📁 Backup Location: $BACKUP_PATH"

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Check if database exists
if [[ ! -f "$DB_PATH" ]]; then
    echo -e "${RED}❌ Database file not found: $DB_PATH${NC}"
    exit 1
fi

# Create backup using SQLite backup command (safer than cp for active databases)
echo -e "${YELLOW}📋 Creating database backup...${NC}"
sqlite3 "$DB_PATH" ".backup '$BACKUP_PATH'"

# Verify backup integrity
if sqlite3 "$BACKUP_PATH" "PRAGMA integrity_check;" | grep -q "ok"; then
    echo -e "${GREEN}✅ Backup integrity verified${NC}"
else
    echo -e "${RED}❌ Backup integrity check failed${NC}"
    exit 1
fi

# Get backup size and record count
BACKUP_SIZE=$(du -h "$BACKUP_PATH" | cut -f1)
RECORD_COUNT=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';")
WO_COUNT=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM work_orders;" 2>/dev/null || echo "N/A")
ASSET_COUNT=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM assets;" 2>/dev/null || echo "N/A")

echo -e "${GREEN}📊 Backup Statistics:${NC}"
echo "   📁 Size: $BACKUP_SIZE"
echo "   🗃️  Tables: $RECORD_COUNT"
echo "   📋 Work Orders: $WO_COUNT"
echo "   ⚙️  Assets: $ASSET_COUNT"

# Upload to Google Cloud Storage (if available)
if command -v gsutil &> /dev/null; then
    echo -e "${YELLOW}☁️  Uploading to Google Cloud Storage...${NC}"
    GCS_BUCKET="gs://chatterfix-backups"
    
    if gsutil cp "$BACKUP_PATH" "$GCS_BUCKET/database/" 2>/dev/null; then
        echo -e "${GREEN}✅ Backup uploaded to $GCS_BUCKET/database/$BACKUP_NAME${NC}"
    else
        echo -e "${YELLOW}⚠️  Cloud upload failed (bucket may not exist or no permissions)${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  gsutil not available - skipping cloud upload${NC}"
fi

# Cleanup old backups (keep last 7)
echo -e "${YELLOW}🧹 Cleaning up old backups (keeping 7 most recent)...${NC}"
OLD_BACKUPS=$(ls -t "$BACKUP_DIR"/cmms_backup_*.db | tail -n +8)
if [[ -n "$OLD_BACKUPS" ]]; then
    echo "$OLD_BACKUPS" | xargs rm -f
    echo -e "${GREEN}✅ Cleaned up $(echo "$OLD_BACKUPS" | wc -l) old backups${NC}"
else
    echo "   ℹ️  No old backups to clean up"
fi

# Create restore instructions
cat > "$BACKUP_DIR/README_RESTORE.md" << EOF
# ChatterFix CMMS Database Restore Instructions

## Latest Backup
- File: $BACKUP_NAME
- Created: $(date)
- Size: $BACKUP_SIZE
- Work Orders: $WO_COUNT
- Assets: $ASSET_COUNT

## To Restore Database

### Option 1: Direct copy (when app is stopped)
\`\`\`bash
cp "$BACKUP_PATH" ./cmms.db
\`\`\`

### Option 2: SQLite restore (safer)
\`\`\`bash
sqlite3 cmms_restored.db ".restore '$BACKUP_PATH'"
mv cmms_restored.db cmms.db
\`\`\`

### Option 3: Cloud restore
\`\`\`bash
gsutil cp $GCS_BUCKET/database/$BACKUP_NAME ./cmms.db
\`\`\`

## Verify Restored Database
\`\`\`bash
sqlite3 cmms.db "PRAGMA integrity_check;"
sqlite3 cmms.db "SELECT COUNT(*) FROM assets;"
sqlite3 cmms.db "SELECT COUNT(*) FROM work_orders;"
\`\`\`

Generated: $(date)
EOF

echo -e "${GREEN}🎉 Database backup completed successfully!${NC}"
echo "📁 Local backup: $BACKUP_PATH"
echo "📖 Restore instructions: $BACKUP_DIR/README_RESTORE.md"
echo ""
echo "💡 To schedule automatic backups:"
echo "   crontab -e"
echo "   Add: 0 2 * * * $(pwd)/backup_db.sh"
echo ""