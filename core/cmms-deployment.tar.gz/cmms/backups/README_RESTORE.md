# ChatterFix CMMS Database Restore Instructions

## Latest Backup
- File: cmms_backup_20250913_125801.db
- Created: Sat Sep 13 12:58:04 CDT 2025
- Size: 200K
- Work Orders: 5
- Assets: 8

## To Restore Database

### Option 1: Direct copy (when app is stopped)
```bash
cp "./backups/cmms_backup_20250913_125801.db" ./cmms.db
```

### Option 2: SQLite restore (safer)
```bash
sqlite3 cmms_restored.db ".restore './backups/cmms_backup_20250913_125801.db'"
mv cmms_restored.db cmms.db
```

### Option 3: Cloud restore
```bash
gsutil cp gs://chatterfix-backups/database/cmms_backup_20250913_125801.db ./cmms.db
```

## Verify Restored Database
```bash
sqlite3 cmms.db "PRAGMA integrity_check;"
sqlite3 cmms.db "SELECT COUNT(*) FROM assets;"
sqlite3 cmms.db "SELECT COUNT(*) FROM work_orders;"
```

Generated: Sat Sep 13 12:58:04 CDT 2025
