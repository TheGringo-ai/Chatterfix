#!/usr/bin/env python3
"""
Main CMMS Router - All Modules
"""

from fastapi import APIRouter
import logging

logger = logging.getLogger(__name__)

# Import core working modules first
try:
    from admin import admin_router
    logger.info("✅ Admin module loaded")
except ImportError as e:
    logger.warning(f"⚠️  Admin module not available: {e}")
    admin_router = None

try:
    from ai import ai_router
    logger.info("✅ AI module loaded")
except ImportError as e:
    logger.warning(f"⚠️  AI module not available: {e}")
    ai_router = None

try:
    from assets import assets_router
    logger.info("✅ Assets module loaded")
except ImportError as e:
    logger.warning(f"⚠️  Assets module not available: {e}")
    assets_router = None

try:
    from dashboard import dashboard_router
    logger.info("✅ Dashboard module loaded")
except ImportError as e:
    logger.warning(f"⚠️  Dashboard module not available: {e}")
    dashboard_router = None

try:
    from part import parts_router
    logger.info("✅ Parts module loaded")
except ImportError as e:
    logger.warning(f"⚠️  Parts module not available: {e}")
    parts_router = None

try:
    from file_manager import file_router
    logger.info("✅ File Manager module loaded")
except ImportError as e:
    logger.warning(f"⚠️  File Manager module not available: {e}")
    file_router = None

# Try to import additional modules
try:
    from ai_enhanced import ai_enhanced_router
    AI_ENHANCED_AVAILABLE = True
except ImportError as e:
    logger.warning(f"AI Enhanced module not available: {e}")
    AI_ENHANCED_AVAILABLE = False

try:
    from ai_meta_system import meta_router
    META_SYSTEM_AVAILABLE = True
    logger.info("✅ Meta-System module available for CMMS router")
except ImportError as e:
    logger.warning(f"Meta-System module not available: {e}")
    META_SYSTEM_AVAILABLE = False

try:
    from prevenative import preventive_router  # Note: file is named "prevenative"
    PREVENTIVE_AVAILABLE = True
    logger.info("✅ Preventive Maintenance module loaded")
except ImportError as e:
    logger.warning(f"Preventive module not available: {e}")
    PREVENTIVE_AVAILABLE = False

try:
    from technician import technician_router
    TECHNICIAN_AVAILABLE = True
    logger.info("✅ Technician Portal module loaded")
except ImportError as e:
    logger.warning(f"Technician module not available: {e}")
    TECHNICIAN_AVAILABLE = False

try:
    from workorders import workorders_router
    WORKORDERS_AVAILABLE = True
    logger.info("✅ Work Orders module loaded")
except ImportError as e:
    logger.warning(f"Work Orders module not available: {e}")
    WORKORDERS_AVAILABLE = False

# Create main router
cmms_router = APIRouter(prefix="/cmms")

# Include core working modules
if admin_router:
    cmms_router.include_router(admin_router)
if ai_router:
    cmms_router.include_router(ai_router)
if assets_router:
    cmms_router.include_router(assets_router)
if dashboard_router:
    cmms_router.include_router(dashboard_router)
if parts_router:
    cmms_router.include_router(parts_router)
if file_router:
    cmms_router.include_router(file_router)

# Include additional modules if available
if AI_ENHANCED_AVAILABLE:
    cmms_router.include_router(ai_enhanced_router)
    logger.info("✅ AI Enhanced module loaded")

if PREVENTIVE_AVAILABLE:
    cmms_router.include_router(preventive_router)
    
if TECHNICIAN_AVAILABLE:
    cmms_router.include_router(technician_router)
    
if WORKORDERS_AVAILABLE:
    cmms_router.include_router(workorders_router)
    
if META_SYSTEM_AVAILABLE:
    cmms_router.include_router(meta_router)
    logger.info("✅ Meta-System module loaded in CMMS router")

logger.info(f"🚀 CMMS Router initialized with {sum([admin_router is not None, ai_router is not None, assets_router is not None, dashboard_router is not None, parts_router is not None, AI_ENHANCED_AVAILABLE, PREVENTIVE_AVAILABLE, TECHNICIAN_AVAILABLE, WORKORDERS_AVAILABLE, META_SYSTEM_AVAILABLE])} modules")
