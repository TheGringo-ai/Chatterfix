"""Lightweight SQLAlchemy database setup for CMMS persistence.
Creates SQLite (default) or uses DATABASE_URL env.
"""
from __future__ import annotations
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("CMMS_DATABASE_URL") or os.getenv("DATABASE_URL") or "sqlite:///./cmms.db"

# echo can be enabled via env for debugging
_engine = create_engine(DATABASE_URL, echo=bool(os.getenv("CMMS_DB_ECHO")), future=True)
engine = _engine  # alias for compatibility
SessionLocal = sessionmaker(bind=_engine, autoflush=False, autocommit=False, expire_on_commit=False, future=True)
Base = declarative_base()

def get_engine():
    return _engine

def get_session():
    return SessionLocal()
