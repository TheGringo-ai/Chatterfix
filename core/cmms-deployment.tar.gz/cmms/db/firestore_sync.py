"""Firestore sync scaffolding.
Currently queues changes; a background worker would push to Firestore when configured.
"""
from __future__ import annotations
from typing import List, Dict, Any, Optional
import os

try:
    import firebase_admin  # type: ignore
    from firebase_admin import credentials, firestore  # type: ignore
    _FIREBASE_AVAILABLE = True
except Exception:  # pragma: no cover
    _FIREBASE_AVAILABLE = False

_app = None
_db = None

SYNC_BUFFER: List[Dict[str, Any]] = []

FIREBASE_CRED_PATH = os.getenv("FIREBASE_CREDENTIALS_JSON")

def init_firestore():
    global _app, _db
    if not _FIREBASE_AVAILABLE or _db:
        return _db
    if FIREBASE_CRED_PATH and os.path.exists(FIREBASE_CRED_PATH):
        cred = credentials.Certificate(FIREBASE_CRED_PATH)
        _app = firebase_admin.initialize_app(cred)
        _db = firestore.client()
    return _db

def queue_change(collection: str, doc_id: str, data: Dict[str, Any]):
    SYNC_BUFFER.append({"collection": collection, "doc_id": doc_id, "data": data})

def flush(max_items: int = 20):
    if not _FIREBASE_AVAILABLE:
        return 0
    db = init_firestore()
    if not db:
        return 0
    flushed = 0
    while SYNC_BUFFER and flushed < max_items:
        change = SYNC_BUFFER.pop(0)
        db.collection(change['collection']).document(change['doc_id']).set(change['data'], merge=True)  # type: ignore
        flushed += 1
    return flushed
