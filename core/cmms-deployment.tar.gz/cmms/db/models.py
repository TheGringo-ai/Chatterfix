"""SQLAlchemy models for CMMS core entities (minimal subset).
Designed to mirror existing in-memory structures for Work Orders & KPIs.
"""
from __future__ import annotations
from sqlalchemy import Column, String, Integer, Float, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class WorkOrderORM(Base):
    __tablename__ = "work_orders"
    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    asset_id = Column(String, index=True)
    type = Column(String, index=True)
    priority = Column(String, index=True)
    status = Column(String, index=True)
    created_date = Column(String, index=True)
    created_by = Column(String)
    assigned_to = Column(String, index=True, nullable=True)
    due_date = Column(String, nullable=True)
    estimated_hours = Column(Float, nullable=True)
    actual_hours = Column(Float, nullable=True)
    cost = Column(Float, nullable=True)
    sla_hours = Column(Integer, nullable=True)
    acknowledged_at = Column(String, nullable=True)
    closed_date = Column(String, nullable=True)
    escalated = Column(Boolean, default=False)

class KPIORM(Base):
    __tablename__ = "kpi_metrics"
    name = Column(String, primary_key=True)
    value = Column(Float, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# Extended persistence models
class AssetORM(Base):
    __tablename__ = "assets"
    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    category = Column(String, index=True)
    location = Column(String, index=True)
    status = Column(String, index=True)
    condition = Column(String)
    manufacturer = Column(String)
    model = Column(String)
    serial_number = Column(String)
    installation_date = Column(String)
    last_maintenance = Column(String, nullable=True)
    next_maintenance = Column(String, nullable=True)
    maintenance_frequency = Column(Integer)
    criticality = Column(String, index=True)
    cost_center = Column(String)
    specifications = Column(Text)
    parent_asset_id = Column(String, nullable=True, index=True)
    health_score = Column(Float, nullable=True)  # Added

class PartORM(Base):
    __tablename__ = "parts"
    id = Column(String, primary_key=True, index=True)
    part_number = Column(String, index=True)
    name = Column(String, nullable=False)
    description = Column(Text)
    category = Column(String, index=True)
    manufacturer = Column(String)
    supplier = Column(String)
    unit_cost = Column(Float)
    quantity_on_hand = Column(Integer)
    reorder_point = Column(Integer)
    maximum_stock = Column(Integer)
    unit_of_measure = Column(String)
    location = Column(String, index=True)
    last_ordered = Column(String, nullable=True)
    compatible_assets = Column(Text)

class WorkOrderCommentORM(Base):
    __tablename__ = "work_order_comments"
    id = Column(String, primary_key=True)
    work_order_id = Column(String, index=True)
    author = Column(String)
    timestamp = Column(String)
    comment = Column(Text)
    attachments = Column(Text)

class WorkOrderStatusORM(Base):
    __tablename__ = "work_order_status_history"
    id = Column(String, primary_key=True)
    work_order_id = Column(String, index=True)
    status = Column(String, index=True)
    timestamp = Column(String)
    updated_by = Column(String)
    notes = Column(Text)

# Vendor and Procurement Models for Parts & Purchasing Dashboard
class VendorORM(Base):
    __tablename__ = "vendors" 
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    contact_email = Column(String)
    contact_phone = Column(String)
    contact_person = Column(String)
    address = Column(Text)
    terms = Column(String, default="NET30")  # Payment terms
    default_lead_days = Column(Integer, default=7)
    rating = Column(Float, default=0.0)  # 0-5 scale
    active = Column(Boolean, default=True)
    created_at = Column(String)
    updated_at = Column(String)
    notes = Column(Text)

class PurchaseRequestORM(Base):
    __tablename__ = "purchase_requests"
    id = Column(String, primary_key=True) 
    requested_by = Column(String, nullable=False)
    status = Column(String, default="draft")  # draft, submitted, approved, ordered
    priority = Column(String, default="normal")  # normal, urgent, critical
    need_by_date = Column(String)
    created_at = Column(String, nullable=False)
    approved_by = Column(String)
    approved_at = Column(String)
    total_estimated = Column(Float, default=0.0)
    justification = Column(Text)
    work_order_id = Column(String, nullable=True)

class PRLineORM(Base):
    __tablename__ = "pr_lines"
    id = Column(String, primary_key=True)
    pr_id = Column(String, ForeignKey("purchase_requests.id"))
    part_id = Column(String, ForeignKey("parts.id"), nullable=True)
    description = Column(String, nullable=False)  # For non-catalog items
    quantity = Column(Integer, nullable=False)
    estimated_cost = Column(Float, default=0.0)
    asset_id = Column(String, nullable=True)  # If for specific asset
    notes = Column(Text)

class RFQORM(Base):
    __tablename__ = "rfqs"
    id = Column(String, primary_key=True)
    pr_id = Column(String, ForeignKey("purchase_requests.id"))
    status = Column(String, default="sent")  # sent, responses_received, closed
    sent_date = Column(String)
    response_due_date = Column(String) 
    created_by = Column(String)
    vendor_ids = Column(Text)  # JSON list of vendor IDs
    notes = Column(Text)

class QuoteORM(Base):
    __tablename__ = "quotes" 
    id = Column(String, primary_key=True)
    rfq_id = Column(String, ForeignKey("rfqs.id"))
    vendor_id = Column(String, ForeignKey("vendors.id"))
    quote_number = Column(String)  # Vendor's quote reference
    total_amount = Column(Float)
    currency = Column(String, default="USD")
    validity_date = Column(String)
    lead_time_days = Column(Integer)
    terms = Column(String)
    received_date = Column(String)
    status = Column(String, default="received")  # received, selected, expired, rejected
    notes = Column(Text)
    attachment_path = Column(String, nullable=True)

class PurchaseOrderORM(Base):
    __tablename__ = "purchase_orders"  
    id = Column(String, primary_key=True)
    vendor_id = Column(String, ForeignKey("vendors.id"))
    po_number = Column(String, unique=True)
    status = Column(String, default="draft")  # draft, sent, acknowledged, received, closed
    order_date = Column(String)
    expected_delivery = Column(String)
    actual_delivery = Column(String, nullable=True)
    total_amount = Column(Float)
    created_by = Column(String)
    approved_by = Column(String)
    approved_at = Column(String)
    terms = Column(String)
    notes = Column(Text)

class POLineORM(Base):
    __tablename__ = "po_lines"
    id = Column(String, primary_key=True)
    po_id = Column(String, ForeignKey("purchase_orders.id"))
    part_id = Column(String, ForeignKey("parts.id"), nullable=True)
    description = Column(String, nullable=False)
    quantity_ordered = Column(Integer, nullable=False)
    quantity_received = Column(Integer, default=0)
    unit_price = Column(Float)
    total_price = Column(Float)
    notes = Column(Text)

class ReceivingORM(Base):
    __tablename__ = "receiving"
    id = Column(String, primary_key=True)
    po_id = Column(String, ForeignKey("purchase_orders.id"))
    received_by = Column(String, nullable=False)
    received_date = Column(String, nullable=False)
    packing_slip = Column(String)
    notes = Column(Text)
    partial_shipment = Column(Boolean, default=False)

class ReceivingLineORM(Base):
    __tablename__ = "receiving_lines"
    id = Column(String, primary_key=True)
    receiving_id = Column(String, ForeignKey("receiving.id"))
    po_line_id = Column(String, ForeignKey("po_lines.id"))
    part_id = Column(String, ForeignKey("parts.id"), nullable=True)
    quantity_received = Column(Integer, nullable=False)
    condition = Column(String, default="good")  # good, damaged, wrong_item
    bin_location = Column(String, nullable=True)
    notes = Column(Text)
