-- Canonical CMMS relational schema (Postgres dialect)
CREATE TABLE IF NOT EXISTS assets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT,
    location TEXT,
    status TEXT,
    condition TEXT,
    manufacturer TEXT,
    model TEXT,
    serial_number TEXT,
    installation_date TEXT,
    last_maintenance TEXT,
    next_maintenance TEXT,
    maintenance_frequency INTEGER,
    criticality TEXT,
    cost_center TEXT,
    specifications JSONB,
    parent_asset_id TEXT
);

CREATE TABLE IF NOT EXISTS parts (
    id TEXT PRIMARY KEY,
    part_number TEXT,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    manufacturer TEXT,
    supplier TEXT,
    unit_cost NUMERIC,
    quantity_on_hand INTEGER,
    reorder_point INTEGER,
    maximum_stock INTEGER,
    unit_of_measure TEXT,
    location TEXT,
    last_ordered TEXT,
    compatible_assets JSONB
);

CREATE TABLE IF NOT EXISTS work_orders (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    asset_id TEXT,
    type TEXT,
    priority TEXT,
    status TEXT,
    created_date TEXT,
    created_by TEXT,
    assigned_to TEXT,
    due_date TEXT,
    estimated_hours NUMERIC,
    actual_hours NUMERIC,
    cost NUMERIC,
    sla_hours INTEGER,
    acknowledged_at TEXT,
    closed_date TEXT,
    escalated BOOLEAN
);

CREATE TABLE IF NOT EXISTS work_order_comments (
    id TEXT PRIMARY KEY,
    work_order_id TEXT,
    author TEXT,
    timestamp TEXT,
    comment TEXT,
    attachments JSONB
);

CREATE TABLE IF NOT EXISTS work_order_status_history (
    id TEXT PRIMARY KEY,
    work_order_id TEXT,
    status TEXT,
    timestamp TEXT,
    updated_by TEXT,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS kpi_metrics (
    name TEXT PRIMARY KEY,
    value NUMERIC,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_work_orders_asset ON work_orders(asset_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_priority ON work_orders(priority);
CREATE INDEX IF NOT EXISTS idx_parts_category ON parts(category);
CREATE INDEX IF NOT EXISTS idx_assets_status ON assets(status);
