#!/bin/bash

# ChatterFix CMMS - Rich UI Deployment Script
# Deploy new glass morphism styling and features with zero-downtime blue/green strategy

set -e

echo "🚀 ChatterFix CMMS Rich UI Deployment Starting..."
echo "Timestamp: $(date)"
echo "Project: /Users/fredtaylor/Desktop/Projects/ai-tools/core/cmms"

# Configuration
PROJECT_ID="chatterfix-production"
IMAGE_NAME="chatterfix-cmms"
REGION="us-central1"
SERVICE_NAME="chatterfix-cmms"
VERSION_TAG="rich-ui-v2.0"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Step 1: Build new container image with rich styling
print_status "Building new container image with rich UI..."
docker build -t ${IMAGE_NAME}:${VERSION_TAG} . \
  --build-arg VERSION=${VERSION_TAG} \
  --build-arg BUILD_DATE=$(date -u +'%Y-%m-%dT%H:%M:%SZ')

if [ $? -eq 0 ]; then
    print_success "Container image built successfully"
else
    print_error "Container build failed"
    exit 1
fi

# Step 2: Tag and push to Google Container Registry
print_status "Pushing to Google Container Registry..."
docker tag ${IMAGE_NAME}:${VERSION_TAG} gcr.io/${PROJECT_ID}/${IMAGE_NAME}:${VERSION_TAG}
docker push gcr.io/${PROJECT_ID}/${IMAGE_NAME}:${VERSION_TAG}

if [ $? -eq 0 ]; then
    print_success "Image pushed to GCR successfully"
else
    print_error "Failed to push image to GCR"
    exit 1
fi

# Step 3: Deploy canary version (10% traffic)
print_status "Deploying canary version with rich UI..."
gcloud run deploy ${SERVICE_NAME} \
  --image gcr.io/${PROJECT_ID}/${IMAGE_NAME}:${VERSION_TAG} \
  --region ${REGION} \
  --platform managed \
  --tag canary \
  --no-traffic \
  --memory 2Gi \
  --cpu 2 \
  --port 8080 \
  --timeout 300 \
  --concurrency 100 \
  --max-instances 10 \
  --set-env-vars "VERSION=${VERSION_TAG},ENVIRONMENT=production,UI_VERSION=rich-v2.0" \
  --allow-unauthenticated

if [ $? -eq 0 ]; then
    print_success "Canary deployment successful"
    CANARY_URL=$(gcloud run services describe ${SERVICE_NAME} --region ${REGION} --format 'value(status.traffic[0].url)' --filter="metadata.name=${SERVICE_NAME}")
    print_status "Canary URL: ${CANARY_URL}"
else
    print_error "Canary deployment failed"
    exit 1
fi

# Step 4: Test canary deployment
print_status "Testing canary deployment..."

# Test basic connectivity
if curl -f -s "${CANARY_URL}/health" > /dev/null; then
    print_success "✅ Health check passed"
else
    print_error "❌ Health check failed"
    exit 1
fi

# Test rich UI elements
if curl -s "${CANARY_URL}/cmms/parts/dashboard" | grep -q "chatterfix-ultimate.css"; then
    print_success "✅ Rich UI styling loaded"
else
    print_warning "⚠️ Rich UI styling not detected"
fi

# Test AI features
if curl -s "${CANARY_URL}/cmms/ai/dashboard" | grep -q "ai-chat-container"; then
    print_success "✅ AI features available"
else
    print_warning "⚠️ AI features not detected"
fi

# Step 5: Gradual traffic shift (Blue/Green deployment)
print_status "Starting gradual traffic shift..."

# Shift 10% traffic to canary
print_status "Shifting 10% traffic to canary..."
gcloud run services update-traffic ${SERVICE_NAME} \
  --region ${REGION} \
  --to-tags canary=10,latest=90

sleep 30

# Monitor for 2 minutes
print_status "Monitoring canary for 2 minutes..."
for i in {1..12}; do
    if curl -f -s "${CANARY_URL}/health" > /dev/null; then
        print_status "Health check ${i}/12 passed"
    else
        print_error "Health check failed during monitoring"
        print_status "Rolling back traffic..."
        gcloud run services update-traffic ${SERVICE_NAME} \
          --region ${REGION} \
          --to-tags latest=100
        exit 1
    fi
    sleep 10
done

# Step 6: Full traffic shift
print_status "Canary stable - shifting 50% traffic..."
gcloud run services update-traffic ${SERVICE_NAME} \
  --region ${REGION} \
  --to-tags canary=50,latest=50

sleep 60

# Monitor again
print_status "Monitoring 50/50 split..."
for i in {1..6}; do
    if curl -f -s "${CANARY_URL}/health" > /dev/null; then
        print_status "50/50 health check ${i}/6 passed"
    else
        print_error "Health check failed during 50/50 split"
        print_status "Rolling back to previous version..."
        gcloud run services update-traffic ${SERVICE_NAME} \
          --region ${REGION} \
          --to-tags latest=100
        exit 1
    fi
    sleep 10
done

# Step 7: Complete migration
print_status "Completing migration - 100% traffic to rich UI version..."
gcloud run services update-traffic ${SERVICE_NAME} \
  --region ${REGION} \
  --to-tags canary=100

# Update latest tag
print_status "Updating latest tag..."
gcloud run services update-traffic ${SERVICE_NAME} \
  --region ${REGION} \
  --to-revisions LATEST=100

# Step 8: Cleanup old revisions (keep last 3)
print_status "Cleaning up old revisions..."
OLD_REVISIONS=$(gcloud run revisions list \
  --service ${SERVICE_NAME} \
  --region ${REGION} \
  --format="value(metadata.name)" \
  --sort-by="~metadata.creationTimestamp" \
  --limit=100 \
  | tail -n +4)

if [ -n "$OLD_REVISIONS" ]; then
    for revision in $OLD_REVISIONS; do
        gcloud run revisions delete $revision --region ${REGION} --quiet
        print_status "Deleted old revision: $revision"
    done
fi

# Step 9: Verify final deployment
print_status "Verifying final deployment..."
PRODUCTION_URL=$(gcloud run services describe ${SERVICE_NAME} --region ${REGION} --format 'value(status.url)')

# Test production endpoints
ENDPOINTS=(
    "/health"
    "/cmms/dashboard" 
    "/cmms/parts/dashboard"
    "/cmms/ai/dashboard"
    "/static/css/chatterfix-ultimate.css"
    "/static/js/chatterfix-ultimate.js"
)

print_status "Testing production endpoints..."
for endpoint in "${ENDPOINTS[@]}"; do
    if curl -f -s "${PRODUCTION_URL}${endpoint}" > /dev/null; then
        print_success "✅ ${endpoint}"
    else
        print_warning "⚠️ ${endpoint} - may not be available"
    fi
done

# Final status report
print_success "🎉 Rich UI Deployment Completed Successfully!"
print_status "Production URL: ${PRODUCTION_URL}"
print_status "Version: ${VERSION_TAG}"
print_status "Features deployed:"
print_status "  ✅ Glass morphism styling (chatterfix-ultimate.css)"
print_status "  ✅ Interactive features (chatterfix-ultimate.js)" 
print_status "  ✅ Rich Parts dashboard"
print_status "  ✅ Enhanced AI Command Center"
print_status "  ✅ Unified template system"
print_status "  ✅ Mobile responsive design"
print_status "  ✅ Voice command support"
print_status "  ✅ Real-time updates"

# Performance test
print_status "Running quick performance test..."
RESPONSE_TIME=$(curl -w "%{time_total}" -s -o /dev/null "${PRODUCTION_URL}/cmms/dashboard")
print_status "Dashboard load time: ${RESPONSE_TIME}s"

if (( $(echo "$RESPONSE_TIME < 5.0" | bc -l) )); then
    print_success "✅ Performance target met (<5s)"
else
    print_warning "⚠️ Performance slower than target (${RESPONSE_TIME}s)"
fi

echo ""
print_success "🚀 ChatterFix CMMS Rich UI v2.0 is now LIVE!"
print_status "Ready for beta launch with 20 clients targeting $47K MRR"
print_status "Next steps:"
print_status "  1. Update demo video with new UI"
print_status "  2. Post to Reddit r/manufacturing"
print_status "  3. Contact beta clients about upgrade"
print_status "  4. Monitor system performance and user feedback"

echo ""
print_status "Deployment completed at: $(date)"