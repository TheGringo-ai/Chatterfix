#!/bin/bash

# ChatterFix CMMS - Production Cloud Run Deployment
# Deploy the ERP-killing CMMS to Google Cloud Run

set -e

echo "🚀 Deploying ChatterFix CMMS to Cloud Run..."

# Configuration
PROJECT_ID=${1:-"chatterfix-prod"}
REGION="us-central1"
SERVICE_NAME="chatterfix-cmms"
IMAGE_NAME="chatterfix-cmms"

echo "📊 Configuration:"
echo "  Project: $PROJECT_ID"
echo "  Region: $REGION"
echo "  Service: $SERVICE_NAME"

# Build and push container
echo "🐳 Building container image..."
docker build -t gcr.io/$PROJECT_ID/$IMAGE_NAME .

echo "📤 Pushing to Google Container Registry..."
docker push gcr.io/$PROJECT_ID/$IMAGE_NAME

# Deploy to Cloud Run
echo "🌟 Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
  --image gcr.io/$PROJECT_ID/$IMAGE_NAME \
  --platform managed \
  --region $REGION \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 1 \
  --min-instances 1 \
  --max-instances 10 \
  --timeout 300s \
  --port 8080 \
  --set-env-vars="DATABASE_URL=sqlite:///./cmms.db,GROK_API_KEY=xai-mwvYfIxr7QtNpxANwbgHCGWmkfrjtQEXi0T2r3q8lQ9VYsSgUkSmLphMnpTVfmA8dbdxEtigsqObIkBt" \
  --project $PROJECT_ID

# Get the service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --platform managed --region $REGION --format="value(status.url)" --project $PROJECT_ID)

echo ""
echo "🎉 Deployment complete!"
echo "🌐 Service URL: $SERVICE_URL"
echo "📊 Dashboard: $SERVICE_URL/cmms/assets/dashboard"
echo "🧀 Quality Control: $SERVICE_URL/erp/quality/analyze"
echo "🤖 AI Fast Dashboard: $SERVICE_URL/api/dashboard/fast-assets"
echo ""
echo "🧪 Test commands:"
echo "  curl $SERVICE_URL/health"
echo "  curl $SERVICE_URL/api/dashboard/fast-assets"
echo ""
echo "💰 Ready for beta signup at: $SERVICE_URL"
echo "🚀 ChatterFix CMMS is LIVE and ready to crush SAP!"