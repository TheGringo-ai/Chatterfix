#!/usr/bin/env python3
"""
ChatterFix CMMS - Comprehensive E2E QA Test Suite
Senior QA Engineer validation with full CRUD, uploads, and adversarial testing.
"""

import os
import sys
import json
import time
import requests
import tempfile
import struct
import wave
from datetime import datetime, timezone
from typing import Dict, Any, List, Tuple

class E2EQATester:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.timeout = 20
        self.results = []
        self.curl_commands = []
        self.bugs = []
        self.created_workorder_id = None
        
    def log_result(self, endpoint: str, method: str, expected: str, actual: Any, notes: str = "", status_code: int = 0):
        """Log test result"""
        result = actual if isinstance(actual, str) else str(actual)
        passed = "PASS" if expected.lower() in result.lower() or status_code in [200, 201, 204] else "FAIL"
        
        self.results.append({
            'endpoint': endpoint,
            'method': method, 
            'status': status_code,
            'expectation': expected,
            'result': passed,
            'notes': notes
        })
        
        if passed == "FAIL":
            self.bugs.append({
                'endpoint': endpoint,
                'method': method,
                'expected': expected,
                'actual': result,
                'response_code': status_code,
                'notes': notes
            })

    def log_curl(self, method: str, url: str, data: str = "", files: str = ""):
        """Log cURL command for replay"""
        curl_cmd = f'curl -X {method} "{url}"'
        if data:
            curl_cmd += f' -d \'{data}\''
        if files:
            curl_cmd += f' {files}'
        curl_cmd += ' -H "Content-Type: application/json" -w "\\n%{http_code}\\n"'
        self.curl_commands.append(curl_cmd)

    def test_request(self, method: str, endpoint: str, expected_status: int, expected_content: str, **kwargs):
        """Execute test request with logging"""
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(url, **kwargs)
                self.log_curl('GET', url)
            elif method.upper() == 'POST':
                response = self.session.post(url, **kwargs)
                data_str = json.dumps(kwargs.get('json', {})) if 'json' in kwargs else str(kwargs.get('data', ''))
                files_str = '-F "file=@test.jpg"' if 'files' in kwargs else ''
                self.log_curl('POST', url, data_str, files_str)
            elif method.upper() == 'PUT':
                response = self.session.put(url, **kwargs)
                data_str = json.dumps(kwargs.get('json', {}))
                self.log_curl('PUT', url, data_str)
            elif method.upper() == 'PATCH':
                response = self.session.patch(url, **kwargs)
                data_str = json.dumps(kwargs.get('json', {}))
                self.log_curl('PATCH', url, data_str)
            elif method.upper() == 'DELETE':
                response = self.session.delete(url, **kwargs)
                self.log_curl('DELETE', url)
            else:
                raise ValueError(f"Unsupported method: {method}")
                
            # Parse response
            try:
                response_data = response.json() if response.text else {}
            except:
                response_data = response.text
                
            self.log_result(endpoint, method, expected_content, response_data, 
                          f"Status: {response.status_code}", response.status_code)
            
            return response, response_data
            
        except Exception as e:
            self.log_result(endpoint, method, expected_content, f"ERROR: {e}", 
                          "Request failed", 0)
            return None, None

    def create_test_files(self):
        """Create test files for uploads"""
        # Create test JPEG
        jpeg_data = b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xd9'
        with open('/tmp/test.jpg', 'wb') as f:
            f.write(jpeg_data)
            
        # Create test PDF
        pdf_data = b'%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 0>>endobj\ntrailer<<>>\n%%EOF'
        with open('/tmp/manual.pdf', 'wb') as f:
            f.write(pdf_data)
            
        # Create test WAV
        with wave.open('/tmp/test.wav', 'w') as w:
            w.setparams((1, 2, 8000, 0, "NONE", "not compressed"))
            for _ in range(8000):
                w.writeframes(struct.pack("<h", 0))

    def test_pages_and_ui_smoke(self):
        """Test 1: Pages & UI Smoke Tests"""
        print("🔍 1) Pages & UI Smoke Tests")
        
        # Root page
        self.test_request('GET', '/', 200, 'ChatterFix CMMS')
        
        # Dashboard main
        self.test_request('GET', '/cmms/dashboard/main', 200, 'active_work_orders')
        
        # Core modules
        modules = [
            ('/cmms/workorders', 'workorders'),
            ('/cmms/assets', 'assets'), 
            ('/cmms/parts', 'parts'),
            ('/cmms/preventive', 'preventive'),
            ('/cmms/technicians', 'technicians'),
            ('/cmms/admin', 'admin')
        ]
        
        for endpoint, expected in modules:
            self.test_request('GET', endpoint, 200, expected)
            
        # Health and docs
        self.test_request('GET', '/health', 200, 'healthy')
        self.test_request('GET', '/docs', 200, 'swagger')

    def test_work_order_crud(self):
        """Test 2: Work Orders - Complete CRUD + Scheduling"""
        print("🔧 2) Work Order CRUD + Scheduling")
        
        # CREATE
        create_payload = {
            "title": "Replace fuel pump",
            "asset_id": "A-001", 
            "type": "Corrective",
            "priority": "High",
            "description": "Pump cavitating; replace with PRT-0091",
            "requested_by": "TECH-001"
        }
        
        response, data = self.test_request('POST', '/cmms/workorders', 201, 'id', 
                                         json=create_payload)
        
        if response and response.status_code in [200, 201] and data:
            if isinstance(data, dict) and 'id' in data:
                self.created_workorder_id = data['id']
            else:
                # Try to extract ID from different response formats
                self.created_workorder_id = "WO-123"  # fallback
                
        wo_id = self.created_workorder_id or "WO-123"
        
        # READ
        self.test_request('GET', f'/cmms/workorders/{wo_id}', 200, wo_id)
        
        # UPDATE
        update_payload = {
            "title": "Replace fuel pump (rev A)",
            "priority": "Medium", 
            "description": "Updated per inspection"
        }
        self.test_request('PUT', f'/cmms/workorders/{wo_id}', 200, 'updated',
                         json=update_payload)
        
        # SCHEDULE  
        schedule_payload = {
            "planned_start": "2025-09-15T14:00:00Z",
            "planned_end": "2025-09-15T16:00:00Z",
            "due_date": "2025-09-16"
        }
        self.test_request('PATCH', f'/cmms/workorders/{wo_id}/schedule', 200, 'scheduled',
                         json=schedule_payload)
        
        # ASSIGN
        assign_payload = {"assigned_to": "TECH-001"}
        self.test_request('PATCH', f'/cmms/workorders/{wo_id}/assign', 200, 'assigned',
                         json=assign_payload)
        
        # STATUS CHANGE  
        status_payload = {"status": "Completed"}
        self.test_request('PATCH', f'/cmms/workorders/{wo_id}/status', 200, 'completed',
                         json=status_payload)
        
        # ADD COMMENT
        comment_payload = {"message": "Installed new pump; vibration within spec."}
        self.test_request('POST', f'/cmms/workorders/{wo_id}/comment', 201, 'comment',
                         json=comment_payload)

    def test_work_order_uploads(self):
        """Test 3: Work Order Uploads (Photos + Documents)"""
        print("📸 3) Work Order Uploads")
        
        wo_id = self.created_workorder_id or "WO-123"
        
        # Photo upload
        with open('/tmp/test.jpg', 'rb') as f:
            files = {'photo': f}
            self.test_request('POST', f'/cmms/workorders/{wo_id}/attach-photo', 200, 'uploaded',
                             files=files)
        
        # Document upload
        with open('/tmp/manual.pdf', 'rb') as f:
            files = {'file': f}
            self.test_request('POST', f'/cmms/workorders/{wo_id}/attach-document', 200, 'attached',
                             files=files)
        
        # Negative test - non-image to photo endpoint
        with open('/tmp/manual.pdf', 'rb') as f:
            files = {'photo': f}
            response, _ = self.test_request('POST', f'/cmms/workorders/{wo_id}/attach-photo', 400, 'error',
                                         files=files)

    def test_ai_quality_voice(self):
        """Test 4: AI / Quality / Voice / SOPs"""
        print("🤖 4) AI / Quality / Voice / SOPs")
        
        # Quality analysis
        self.test_request('POST', '/erp/quality/analyze', 200, 'analysis',
                         data={'description': 'nasty cheese'})
        
        # OCR
        with open('/tmp/test.jpg', 'rb') as f:
            files = {'photo': f}
            self.test_request('POST', '/erp/quality/ocr', 200, 'ocr',
                             files=files)
        
        # Voice command
        with open('/tmp/test.wav', 'rb') as f:
            files = {'audio': f}
            self.test_request('POST', '/cmms/ai/voice-command', 200, 'voice',
                             files=files)
        
        # AI chat
        self.test_request('POST', '/cmms/ai/chat', 200, 'response',
                         data={'message': 'Create work order for pump maintenance'})

    def test_listings_and_search(self):
        """Test 5: Listings, Filters, Search"""
        print("🔍 5) Listings, Filters, Search")
        
        # List with filter
        self.test_request('GET', '/cmms/workorders?status=Open', 200, 'workorders')
        
        # Search
        self.test_request('GET', '/cmms/workorders?search=fuel', 200, 'fuel')
        
        # Quick actions from dashboard
        quick_actions = [
            '/cmms/workorders/view',
            '/cmms/assets/manage', 
            '/cmms/parts/inventory',
            '/cmms/export'
        ]
        
        for action in quick_actions:
            self.test_request('GET', action, 200, 'success')

    def cleanup_workorder(self):
        """Clean up created work order"""
        if self.created_workorder_id:
            self.test_request('DELETE', f'/cmms/workorders/{self.created_workorder_id}', 204, 'deleted')

    def run_full_test_suite(self):
        """Execute complete E2E test suite"""
        print("🚀 ChatterFix CMMS - Comprehensive E2E QA Test Suite")
        print("=" * 60)
        
        # Create test files
        self.create_test_files()
        
        # Execute test phases
        self.test_pages_and_ui_smoke()
        self.test_work_order_crud()
        self.test_work_order_uploads()  
        self.test_ai_quality_voice()
        self.test_listings_and_search()
        
        # Cleanup
        self.cleanup_workorder()

    def generate_report(self):
        """Generate comprehensive QA report"""
        passed = len([r for r in self.results if r['result'] == 'PASS'])
        failed = len([r for r in self.results if r['result'] == 'FAIL'])
        
        print("\n" + "=" * 60)
        print("📊 E2E QA TEST REPORT")
        print("=" * 60)
        
        # 1. Summary
        print(f"1) SUMMARY: {passed} passed / {failed} failed")
        
        # 2. Findings Table
        print(f"\n2) FINDINGS TABLE:")
        print("endpoint · method · status · expectation · result · notes")
        print("-" * 80)
        for r in self.results:
            print(f"{r['endpoint']} · {r['method']} · {r['status']} · {r['expectation']} · {r['result']} · {r['notes']}")
        
        # 3. Bugs
        if self.bugs:
            print(f"\n3) BUGS ({len(self.bugs)} found):")
            for i, bug in enumerate(self.bugs, 1):
                print(f"{i}. {bug['method']} {bug['endpoint']}")
                print(f"   Expected: {bug['expected']}")
                print(f"   Actual: {bug['actual'][:200]}...")
                print(f"   Status: {bug['response_code']}")
                print(f"   Notes: {bug['notes']}")
        else:
            print("\n3) BUGS: None found ✅")
            
        # 4. cURL Replay
        print(f"\n4) cURL REPLAY ({len(self.curl_commands)} commands):")
        for cmd in self.curl_commands:
            print(f"  {cmd}")
        
        # 5. Next Actions
        print(f"\n5) NEXT ACTIONS:")
        if self.bugs:
            for i, bug in enumerate(self.bugs, 1):
                severity = self.classify_severity(bug)
                print(f"{i}. [{severity}] Fix {bug['method']} {bug['endpoint']}")
                print(f"   Action: {self.suggest_fix(bug)}")
        else:
            print("No critical issues found. System appears production-ready.")
            
        return passed, failed

    def classify_severity(self, bug: Dict) -> str:
        """Classify bug severity"""
        if bug['response_code'] in [404, 500, 503]:
            return "S1-CRITICAL"
        elif bug['response_code'] in [422, 400]:
            return "S2-MODERATE" 
        else:
            return "S3-MINOR"

    def suggest_fix(self, bug: Dict) -> str:
        """Suggest fix for bug"""
        if bug['response_code'] == 404:
            return f"Add route handler for {bug['endpoint']} in app.py"
        elif bug['response_code'] == 422:
            return f"Add form validation/schema for {bug['method']} {bug['endpoint']}"
        elif 'upload' in bug['endpoint']:
            return "Check multipart file handling and MIME type validation"
        else:
            return "Review endpoint implementation and response format"


def main():
    """Main test execution"""
    base_url = os.getenv('CMMS_BASE_URL', 'http://localhost:8000')
    
    tester = E2EQATester(base_url)
    tester.run_full_test_suite()
    passed, failed = tester.generate_report()
    
    # Save detailed results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f"e2e_qa_results_{timestamp}.json"
    
    with open(results_file, 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'base_url': base_url,
            'summary': {'passed': passed, 'failed': failed},
            'results': tester.results,
            'bugs': tester.bugs,
            'curl_commands': tester.curl_commands
        }, f, indent=2)
    
    print(f"\n📄 Detailed results saved to: {results_file}")
    
    # Exit with appropriate code
    sys.exit(1 if failed > 0 else 0)


if __name__ == '__main__':
    main()