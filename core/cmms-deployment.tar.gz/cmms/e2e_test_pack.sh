#!/bin/bash
# E2E CMMS Testing Pack - Comprehensive API and UI Validation
set -e

echo "🧪 CMMS End-to-End Validation Pack"
echo "=================================="
echo "Timestamp: $(date)"
echo "Test Environment: http://127.0.0.1:8888"
echo

# Create results file
RESULTS_FILE="ai-memory/validation/e2e/test_results_$(date +%Y%m%d_%H%M%S).json"
echo '{"timestamp":"'$(date -Iseconds)'","tests":[' > $RESULTS_FILE

# Function to add test result
add_test_result() {
    local test_name="$1"
    local status="$2"
    local details="$3"
    local http_code="${4:-0}"
    
    # Add comma if not first test
    if [ -s $RESULTS_FILE ] && [ "$(tail -c 2 $RESULTS_FILE)" != "[" ]; then
        echo ',' >> $RESULTS_FILE
    fi
    
    echo "  {" >> $RESULTS_FILE
    echo "    \"test\": \"$test_name\"," >> $RESULTS_FILE
    echo "    \"status\": \"$status\"," >> $RESULTS_FILE
    echo "    \"details\": \"$details\"," >> $RESULTS_FILE
    echo "    \"http_code\": $http_code," >> $RESULTS_FILE
    echo "    \"timestamp\": \"$(date -Iseconds)\"" >> $RESULTS_FILE
    echo "  }" >> $RESULTS_FILE
}

# Test 1: Health Check
echo "🔍 Test 1: Health Check Endpoints"
echo "================================"
health_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/health)
if [ "$health_code" = "200" ]; then
    echo "✅ Health endpoint: PASS ($health_code)"
    add_test_result "health_check" "PASS" "Health endpoint responding correctly" $health_code
else
    echo "❌ Health endpoint: FAIL ($health_code)"
    add_test_result "health_check" "FAIL" "Health endpoint not responding correctly" $health_code
fi

ai_health_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/ai/health)
if [ "$ai_health_code" = "200" ]; then
    echo "✅ AI Health endpoint: PASS ($ai_health_code)"
    add_test_result "ai_health_check" "PASS" "AI health endpoint responding correctly" $ai_health_code
else
    echo "❌ AI Health endpoint: FAIL ($ai_health_code)"
    add_test_result "ai_health_check" "FAIL" "AI health endpoint not responding correctly" $ai_health_code
fi
echo

# Test 2: Dashboard Access
echo "🏠 Test 2: Dashboard Access"
echo "==========================="
dashboard_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/)
if [ "$dashboard_code" = "200" ]; then
    echo "✅ Main dashboard: PASS ($dashboard_code)"
    add_test_result "main_dashboard" "PASS" "Main dashboard accessible" $dashboard_code
else
    echo "❌ Main dashboard: FAIL ($dashboard_code)"
    add_test_result "main_dashboard" "FAIL" "Main dashboard not accessible" $dashboard_code
fi

admin_dashboard_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/admin/dashboard)
if [ "$admin_dashboard_code" = "200" ]; then
    echo "✅ Admin dashboard: PASS ($admin_dashboard_code)"
    add_test_result "admin_dashboard" "PASS" "Admin dashboard accessible" $admin_dashboard_code
else
    echo "❌ Admin dashboard: FAIL ($admin_dashboard_code)"
    add_test_result "admin_dashboard" "FAIL" "Admin dashboard not accessible" $admin_dashboard_code
fi

ai_dashboard_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/ai/dashboard)
if [ "$ai_dashboard_code" = "200" ]; then
    echo "✅ AI dashboard: PASS ($ai_dashboard_code)"
    add_test_result "ai_dashboard" "PASS" "AI dashboard accessible" $ai_dashboard_code
else
    echo "❌ AI dashboard: FAIL ($ai_dashboard_code)"
    add_test_result "ai_dashboard" "FAIL" "AI dashboard not accessible" $ai_dashboard_code
fi
echo

# Test 3: API Authentication 
echo "🔐 Test 3: API Authentication"
echo "============================="
parts_unauth_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/api/parts/)
if [ "$parts_unauth_code" = "401" ]; then
    echo "✅ Parts API auth: PASS ($parts_unauth_code)"
    add_test_result "parts_auth_check" "PASS" "Parts API properly requires authentication" $parts_unauth_code
else
    echo "❌ Parts API auth: FAIL ($parts_unauth_code)"
    add_test_result "parts_auth_check" "FAIL" "Parts API not requiring authentication" $parts_unauth_code
fi

equipment_unauth_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/api/equipment/)
if [ "$equipment_unauth_code" = "401" ]; then
    echo "✅ Equipment API auth: PASS ($equipment_unauth_code)"
    add_test_result "equipment_auth_check" "PASS" "Equipment API properly requires authentication" $equipment_unauth_code
else
    echo "❌ Equipment API auth: FAIL ($equipment_unauth_code)"
    add_test_result "equipment_auth_check" "FAIL" "Equipment API not requiring authentication" $equipment_unauth_code
fi

workorders_unauth_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/api/work-orders/)
if [ "$workorders_unauth_code" = "401" ]; then
    echo "✅ Work Orders API auth: PASS ($workorders_unauth_code)"
    add_test_result "workorders_auth_check" "PASS" "Work Orders API properly requires authentication" $workorders_unauth_code
else
    echo "❌ Work Orders API auth: FAIL ($workorders_unauth_code)"
    add_test_result "workorders_auth_check" "FAIL" "Work Orders API not requiring authentication" $workorders_unauth_code
fi
echo

# Test 4: API Documentation
echo "📚 Test 4: API Documentation"
echo "============================"
docs_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/docs)
if [ "$docs_code" = "200" ]; then
    echo "✅ API Docs: PASS ($docs_code)"
    add_test_result "api_docs" "PASS" "API documentation accessible" $docs_code
else
    echo "❌ API Docs: FAIL ($docs_code)"
    add_test_result "api_docs" "FAIL" "API documentation not accessible" $docs_code
fi

openapi_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/openapi.json)
if [ "$openapi_code" = "200" ]; then
    echo "✅ OpenAPI Schema: PASS ($openapi_code)"
    add_test_result "openapi_schema" "PASS" "OpenAPI schema accessible" $openapi_code
    
    # Count API endpoints
    endpoint_count=$(curl -s http://127.0.0.1:8888/openapi.json | jq '.paths | keys | length')
    echo "   📊 Total API endpoints: $endpoint_count"
else
    echo "❌ OpenAPI Schema: FAIL ($openapi_code)"
    add_test_result "openapi_schema" "FAIL" "OpenAPI schema not accessible" $openapi_code
fi
echo

# Test 5: Admin Functions
echo "⚡ Test 5: Admin Functions"
echo "========================="
stats_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/admin/stats)
if [ "$stats_code" = "200" ]; then
    echo "✅ Admin stats: PASS ($stats_code)"
    add_test_result "admin_stats" "PASS" "Admin statistics accessible" $stats_code
    
    # Get system stats
    stats_response=$(curl -s http://127.0.0.1:8888/admin/stats)
    uptime=$(echo "$stats_response" | jq -r '.system_uptime // "unknown"')
    echo "   📊 System uptime: $uptime"
else
    echo "❌ Admin stats: FAIL ($stats_code)"
    add_test_result "admin_stats" "FAIL" "Admin statistics not accessible" $stats_code
fi

users_code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/admin/users)
if [ "$users_code" = "200" ]; then
    echo "✅ User management: PASS ($users_code)"
    add_test_result "user_management" "PASS" "User management accessible" $users_code
    
    # Get user count
    user_count=$(curl -s http://127.0.0.1:8888/admin/users | jq 'length')
    echo "   👥 Total users: $user_count"
else
    echo "❌ User management: FAIL ($users_code)"
    add_test_result "user_management" "FAIL" "User management not accessible" $users_code
fi
echo

# Test 6: AI Integration
echo "🤖 Test 6: AI Integration"
echo "========================="
ai_chat_response=$(curl -s -X POST http://127.0.0.1:8888/ai/chat \
    -H "Content-Type: application/json" \
    -d '{"message":"test system status","context":"system","user_type":"technician"}' \
    -w "%{http_code}")

ai_chat_code=$(echo "$ai_chat_response" | tail -c 4)
if [ "$ai_chat_code" = "200" ]; then
    echo "✅ AI Chat: PASS ($ai_chat_code)"
    add_test_result "ai_chat" "PASS" "AI chat responding correctly" $ai_chat_code
    
    # Extract response confidence if available
    confidence=$(echo "$ai_chat_response" | head -n -1 | jq -r '.confidence // "unknown"')
    echo "   🎯 AI Confidence: $confidence"
else
    echo "❌ AI Chat: FAIL ($ai_chat_code)"
    add_test_result "ai_chat" "FAIL" "AI chat not responding correctly" $ai_chat_code
fi
echo

# Close JSON array
echo ']}' >> $RESULTS_FILE

echo "💾 Test results saved to: $RESULTS_FILE"
echo
echo "📊 Test Summary:"
echo "==============="

# Count results
total_tests=$(jq '.tests | length' $RESULTS_FILE)
passed_tests=$(jq '.tests | map(select(.status == "PASS")) | length' $RESULTS_FILE)
failed_tests=$(jq '.tests | map(select(.status == "FAIL")) | length' $RESULTS_FILE)

echo "Total tests: $total_tests"
echo "Passed: $passed_tests"  
echo "Failed: $failed_tests"

if [ "$failed_tests" -eq 0 ]; then
    echo "🎉 ALL TESTS PASSED!"
    exit 0
else
    echo "❌ Some tests failed. Check results for details."
    exit 1
fi