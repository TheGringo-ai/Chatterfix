#!/usr/bin/env python3
"""
Enhanced Authentication Security System  
Advanced authentication with 2FA, session management, and threat detection
"""

import asyncio
import hashlib
import hmac
import secrets
import time
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json
import base64
import pyotp
import qrcode
import io
from pathlib import Path

from security_monitor import security_monitor, SecurityEventType, SecurityThreatLevel, log_auth_failure, log_auth_success
from shared_state import shared_state, set_system_status

logger = logging.getLogger(__name__)

class SessionStatus(Enum):
    """User session status"""
    ACTIVE = "active"
    EXPIRED = "expired" 
    REVOKED = "revoked"
    SUSPICIOUS = "suspicious"

class AuthMethod(Enum):
    """Authentication methods"""
    PASSWORD = "password"
    TWO_FACTOR = "two_factor"
    API_KEY = "api_key"
    SSO = "sso"

@dataclass
class UserSession:
    """Enhanced user session with security tracking"""
    session_id: str
    user_id: str
    username: str
    ip_address: str
    user_agent: str
    created_at: datetime
    last_activity: datetime
    auth_method: AuthMethod
    status: SessionStatus = SessionStatus.ACTIVE
    permissions: List[str] = field(default_factory=list)
    two_factor_verified: bool = False
    suspicious_activity_count: int = 0
    location_info: Optional[Dict[str, str]] = None

@dataclass  
class User:
    """Enhanced user model with security features"""
    user_id: str
    username: str
    email: str
    password_hash: str
    salt: str
    two_factor_secret: Optional[str] = None
    two_factor_enabled: bool = False
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_login: Optional[datetime] = None
    failed_login_attempts: int = 0
    account_locked: bool = False
    locked_until: Optional[datetime] = None
    permissions: List[str] = field(default_factory=list)
    password_changed_at: Optional[datetime] = None
    must_change_password: bool = False

class EnhancedAuthManager:
    """Advanced authentication manager with 2FA and threat protection"""
    
    def __init__(self, data_dir: str = "/tmp/chatterfix-auth"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # In-memory storage (in production, use a proper database)
        self.users: Dict[str, User] = {}
        self.sessions: Dict[str, UserSession] = {}
        self.api_keys: Dict[str, Dict[str, Any]] = {}
        
        # Security configuration
        self.config = {
            "session_timeout": 3600,  # 1 hour
            "max_failed_attempts": 5,
            "lockout_duration": 1800,  # 30 minutes
            "password_min_length": 12,
            "require_2fa_for_admin": True,
            "session_rotation_interval": 1800,  # 30 minutes
            "suspicious_activity_threshold": 3,
        }
        
        # Rate limiting for auth attempts
        self.auth_attempts: Dict[str, List[datetime]] = {}
        
        # Initialize default admin user if none exists
        asyncio.create_task(self._initialize_default_admin())
        
        logger.info("🔐 Enhanced Authentication Manager initialized")
    
    async def _initialize_default_admin(self):
        """Initialize default admin user if none exists"""
        if not self.users:
            # Create default admin user
            admin_user = await self.create_user(
                username="admin",
                email="admin@chatterfix.com", 
                password="ChatterFix2025!Admin",  # Should be changed on first login
                permissions=["admin", "cmms_full", "ai_access"],
                must_change_password=True
            )
            logger.info("🔧 Created default admin user (must change password on first login)")
    
    def _generate_salt(self) -> str:
        """Generate cryptographic salt"""
        return secrets.token_hex(32)
    
    def _hash_password(self, password: str, salt: str) -> str:
        """Hash password with salt using PBKDF2"""
        return hashlib.pbkdf2_hex(
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000,  # iterations
            64       # key length
        )
    
    def _generate_session_id(self) -> str:
        """Generate secure session ID"""
        return secrets.token_urlsafe(32)
    
    def _generate_2fa_secret(self) -> str:
        """Generate 2FA secret key"""
        return pyotp.random_base32()
    
    async def create_user(self, 
                         username: str,
                         email: str, 
                         password: str,
                         permissions: List[str] = None,
                         must_change_password: bool = False) -> User:
        """Create new user with enhanced security"""
        
        # Validate password strength
        if not self._validate_password_strength(password):
            raise ValueError("Password does not meet security requirements")
        
        # Check if user already exists
        if any(user.username == username or user.email == email for user in self.users.values()):
            raise ValueError("User already exists")
        
        # Generate user ID and security parameters
        user_id = secrets.token_hex(16)
        salt = self._generate_salt()
        password_hash = self._hash_password(password, salt)
        
        # Create user
        user = User(
            user_id=user_id,
            username=username,
            email=email,
            password_hash=password_hash,
            salt=salt,
            permissions=permissions or [],
            must_change_password=must_change_password,
            password_changed_at=datetime.now(timezone.utc)
        )
        
        self.users[user_id] = user
        
        # Log user creation
        await set_system_status("enhanced_auth", "user_created", {
            "user_id": user_id,
            "username": username,
            "permissions": permissions or []
        })
        
        logger.info(f"👤 Created user: {username} with permissions: {permissions}")
        return user
    
    def _validate_password_strength(self, password: str) -> bool:
        """Validate password meets security requirements"""
        if len(password) < self.config["password_min_length"]:
            return False
        
        # Check for required character types
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
        
        return all([has_upper, has_lower, has_digit, has_special])
    
    async def authenticate_user(self, 
                              username: str,
                              password: str,
                              ip_address: str,
                              user_agent: str,
                              totp_code: str = None) -> Tuple[Optional[UserSession], str]:
        """Authenticate user with enhanced security checks"""
        
        # Rate limiting check
        if not await self._check_auth_rate_limit(ip_address):
            await log_auth_failure(ip_address, details={"reason": "rate_limit_exceeded"})
            return None, "Too many authentication attempts. Try again later."
        
        # Find user
        user = None
        for u in self.users.values():
            if u.username == username:
                user = u
                break
        
        if not user:
            await log_auth_failure(ip_address, details={"username": username, "reason": "user_not_found"})
            return None, "Invalid credentials"
        
        # Check if account is locked
        if user.account_locked:
            if user.locked_until and datetime.now(timezone.utc) > user.locked_until:
                # Unlock account
                user.account_locked = False
                user.locked_until = None
                user.failed_login_attempts = 0
            else:
                await log_auth_failure(ip_address, user.user_id, {"reason": "account_locked"})
                return None, "Account is temporarily locked"
        
        # Verify password
        password_hash = self._hash_password(password, user.salt)
        if not hmac.compare_digest(password_hash, user.password_hash):
            # Increment failed attempts
            user.failed_login_attempts += 1
            
            # Lock account if too many failures
            if user.failed_login_attempts >= self.config["max_failed_attempts"]:
                user.account_locked = True
                user.locked_until = datetime.now(timezone.utc) + timedelta(seconds=self.config["lockout_duration"])
            
            await log_auth_failure(ip_address, user.user_id, {
                "reason": "invalid_password",
                "failed_attempts": user.failed_login_attempts
            })
            return None, "Invalid credentials"
        
        # Check 2FA if enabled
        if user.two_factor_enabled:
            if not totp_code:
                return None, "Two-factor authentication code required"
            
            if not self._verify_totp(user.two_factor_secret, totp_code):
                await log_auth_failure(ip_address, user.user_id, {"reason": "invalid_2fa"})
                return None, "Invalid two-factor authentication code"
        
        # Check if admin requires 2FA
        if "admin" in user.permissions and self.config["require_2fa_for_admin"] and not user.two_factor_enabled:
            return None, "Two-factor authentication is required for admin users"
        
        # Authentication successful
        user.failed_login_attempts = 0
        user.last_login = datetime.now(timezone.utc)
        
        # Create session
        session = await self._create_session(user, ip_address, user_agent)
        
        await log_auth_success(ip_address, user.user_id, {
            "username": username,
            "auth_method": AuthMethod.TWO_FACTOR.value if user.two_factor_enabled else AuthMethod.PASSWORD.value,
            "session_id": session.session_id
        })
        
        return session, "Authentication successful"
    
    async def _check_auth_rate_limit(self, ip_address: str) -> bool:
        """Check authentication rate limiting"""
        now = datetime.now(timezone.utc)
        
        if ip_address not in self.auth_attempts:
            self.auth_attempts[ip_address] = []
        
        # Clean old attempts
        cutoff = now - timedelta(minutes=15)
        self.auth_attempts[ip_address] = [
            attempt for attempt in self.auth_attempts[ip_address]
            if attempt > cutoff
        ]
        
        # Check if too many attempts
        if len(self.auth_attempts[ip_address]) >= 10:  # 10 attempts per 15 minutes
            return False
        
        # Add current attempt
        self.auth_attempts[ip_address].append(now)
        return True
    
    async def _create_session(self, user: User, ip_address: str, user_agent: str) -> UserSession:
        """Create new user session"""
        session_id = self._generate_session_id()
        now = datetime.now(timezone.utc)
        
        session = UserSession(
            session_id=session_id,
            user_id=user.user_id,
            username=user.username,
            ip_address=ip_address,
            user_agent=user_agent,
            created_at=now,
            last_activity=now,
            auth_method=AuthMethod.TWO_FACTOR if user.two_factor_enabled else AuthMethod.PASSWORD,
            permissions=user.permissions,
            two_factor_verified=user.two_factor_enabled
        )
        
        self.sessions[session_id] = session
        
        # Clean up old sessions
        await self._cleanup_expired_sessions()
        
        return session
    
    def _verify_totp(self, secret: str, code: str) -> bool:
        """Verify TOTP code"""
        totp = pyotp.TOTP(secret)
        return totp.verify(code, valid_window=1)  # Allow 30-second window
    
    async def enable_2fa(self, user_id: str) -> Tuple[str, str]:
        """Enable 2FA for user and return secret + QR code"""
        user = self.users.get(user_id)
        if not user:
            raise ValueError("User not found")
        
        # Generate 2FA secret
        secret = self._generate_2fa_secret()
        user.two_factor_secret = secret
        user.two_factor_enabled = True
        
        # Generate QR code
        totp = pyotp.TOTP(secret)
        provisioning_uri = totp.provisioning_uri(
            user.username,
            issuer_name="ChatterFix CMMS"
        )
        
        # Create QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        img_buffer = io.BytesIO()
        img.save(img_buffer, format='PNG')
        img_buffer.seek(0)
        
        qr_code_b64 = base64.b64encode(img_buffer.getvalue()).decode()
        
        logger.info(f"🔒 2FA enabled for user: {user.username}")
        return secret, qr_code_b64
    
    async def validate_session(self, session_id: str, ip_address: str) -> Optional[UserSession]:
        """Validate and refresh session"""
        session = self.sessions.get(session_id)
        if not session:
            return None
        
        now = datetime.now(timezone.utc)
        
        # Check if session expired
        if session.status != SessionStatus.ACTIVE:
            return None
        
        # Check session timeout
        if now - session.last_activity > timedelta(seconds=self.config["session_timeout"]):
            session.status = SessionStatus.EXPIRED
            return None
        
        # Check for suspicious activity (IP change)
        if session.ip_address != ip_address:
            session.suspicious_activity_count += 1
            if session.suspicious_activity_count >= self.config["suspicious_activity_threshold"]:
                session.status = SessionStatus.SUSPICIOUS
                await security_monitor.log_security_event(
                    SecurityEventType.SUSPICIOUS_REQUEST,
                    SecurityThreatLevel.HIGH,
                    ip_address,
                    {
                        "session_id": session_id,
                        "original_ip": session.ip_address,
                        "new_ip": ip_address,
                        "user_id": session.user_id
                    }
                )
                return None
        
        # Update last activity
        session.last_activity = now
        
        # Rotate session ID periodically
        if now - session.created_at > timedelta(seconds=self.config["session_rotation_interval"]):
            await self._rotate_session_id(session)
        
        return session
    
    async def _rotate_session_id(self, session: UserSession) -> None:
        """Rotate session ID for security"""
        old_id = session.session_id
        new_id = self._generate_session_id()
        
        # Update session
        session.session_id = new_id
        session.created_at = datetime.now(timezone.utc)
        
        # Move to new key
        del self.sessions[old_id]
        self.sessions[new_id] = session
        
        logger.debug(f"🔄 Rotated session ID for user: {session.username}")
    
    async def revoke_session(self, session_id: str) -> bool:
        """Revoke a user session"""
        session = self.sessions.get(session_id)
        if session:
            session.status = SessionStatus.REVOKED
            del self.sessions[session_id]
            logger.info(f"🚫 Revoked session for user: {session.username}")
            return True
        return False
    
    async def _cleanup_expired_sessions(self) -> None:
        """Clean up expired sessions"""
        now = datetime.now(timezone.utc)
        expired_sessions = [
            sid for sid, session in self.sessions.items()
            if (now - session.last_activity > timedelta(seconds=self.config["session_timeout"]) or
                session.status != SessionStatus.ACTIVE)
        ]
        
        for sid in expired_sessions:
            del self.sessions[sid]
        
        if expired_sessions:
            logger.debug(f"🧹 Cleaned up {len(expired_sessions)} expired sessions")
    
    async def get_auth_status(self) -> Dict[str, Any]:
        """Get authentication system status"""
        active_sessions = len([s for s in self.sessions.values() if s.status == SessionStatus.ACTIVE])
        suspicious_sessions = len([s for s in self.sessions.values() if s.status == SessionStatus.SUSPICIOUS])
        
        return {
            "total_users": len(self.users),
            "active_sessions": active_sessions,
            "suspicious_sessions": suspicious_sessions,
            "locked_accounts": len([u for u in self.users.values() if u.account_locked]),
            "2fa_enabled_users": len([u for u in self.users.values() if u.two_factor_enabled]),
            "config": self.config,
            "security_level": "high" if self.config["require_2fa_for_admin"] else "medium"
        }

# Global enhanced auth manager
enhanced_auth = EnhancedAuthManager()

# Middleware function for request authentication
async def authenticate_request(session_id: str, ip_address: str) -> Optional[UserSession]:
    """Authenticate request using session"""
    if not session_id:
        return None
    
    return await enhanced_auth.validate_session(session_id, ip_address)

if __name__ == "__main__":
    # Test the enhanced auth system
    async def test_auth():
        # Create test user
        user = await enhanced_auth.create_user(
            "testuser",
            "test@example.com",
            "TestPassword123!",
            ["cmms_read", "ai_access"]
        )
        
        # Test authentication
        session, message = await enhanced_auth.authenticate_user(
            "testuser",
            "TestPassword123!",
            "192.168.1.100",
            "Test-Agent/1.0"
        )
        
        print(f"Authentication result: {message}")
        if session:
            print(f"Session created: {session.session_id}")
        
        status = await enhanced_auth.get_auth_status()
        print("Auth status:", json.dumps(status, indent=2, default=str))
    
    asyncio.run(test_auth())