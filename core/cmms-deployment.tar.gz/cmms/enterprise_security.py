#!/usr/bin/env python3
"""
ChatterFix Enterprise Security & Compliance Framework
SOC 2, ISO 27001, GDPR compliance with advanced security features
"""

import os
import json
import logging
import asyncio
import hashlib
import secrets
import time
from typing import Dict, List, Optional, Any, Set
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass
import ipaddress

from fastapi import APIRouter, HTTPException, Depends, Request, Response
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import bcrypt
import jwt
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

# Enterprise security router
security_router = APIRouter(prefix="/enterprise/security", tags=["enterprise-security"])

class SecurityLevel(str, Enum):
    BASIC = "basic"
    ENHANCED = "enhanced"
    MAXIMUM = "maximum"

class AuditEventType(str, Enum):
    LOGIN = "login"
    LOGOUT = "logout"
    DATA_ACCESS = "data_access"
    DATA_EXPORT = "data_export"
    CONFIGURATION_CHANGE = "configuration_change"
    USER_MANAGEMENT = "user_management"
    SECURITY_INCIDENT = "security_incident"
    COMPLIANCE_CHECK = "compliance_check"

class ComplianceStandard(str, Enum):
    SOC2 = "soc2"
    ISO27001 = "iso27001"
    GDPR = "gdpr"
    HIPAA = "hipaa"
    PCI_DSS = "pci_dss"

@dataclass
class SecurityPolicy:
    password_min_length: int
    password_require_uppercase: bool
    password_require_lowercase: bool
    password_require_numbers: bool
    password_require_symbols: bool
    password_expiry_days: int
    max_login_attempts: int
    lockout_duration_minutes: int
    session_timeout_minutes: int
    require_2fa: bool
    allowed_ip_ranges: List[str]
    data_retention_days: int
    encryption_required: bool

class AuditEvent(BaseModel):
    event_id: str
    tenant_id: str
    user_id: Optional[str]
    event_type: AuditEventType
    resource: str
    action: str
    result: str  # success, failure, blocked
    ip_address: str
    user_agent: str
    timestamp: str
    details: Dict[str, Any]
    risk_score: float

class SecurityIncident(BaseModel):
    incident_id: str
    tenant_id: str
    severity: str  # low, medium, high, critical
    incident_type: str
    description: str
    affected_resources: List[str]
    status: str  # open, investigating, resolved, closed
    created_at: str
    resolved_at: Optional[str]
    resolution_notes: Optional[str]

class ComplianceReport(BaseModel):
    report_id: str
    tenant_id: str
    standard: ComplianceStandard
    compliance_score: float
    requirements_met: int
    total_requirements: int
    findings: List[Dict[str, Any]]
    generated_at: str
    valid_until: str

class EnterpriseSecurityManager:
    def __init__(self):
        self.security_policies: Dict[str, SecurityPolicy] = {}
        self.audit_logs: List[AuditEvent] = []
        self.security_incidents: List[SecurityIncident] = []
        self.compliance_reports: Dict[str, ComplianceReport] = {}
        self.failed_login_attempts: Dict[str, Dict[str, int]] = {}
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
        self.encryption_keys: Dict[str, bytes] = {}
        self.ip_whitelist: Dict[str, Set[str]] = {}
        
        # Initialize security framework
        asyncio.create_task(self.initialize_security_framework())
    
    async def initialize_security_framework(self):
        """Initialize enterprise security framework"""
        try:
            logger.info("🔒 Initializing enterprise security framework...")
            
            # Create default security policies for different tiers
            self.security_policies = {
                "starter": SecurityPolicy(
                    password_min_length=8,
                    password_require_uppercase=True,
                    password_require_lowercase=True,
                    password_require_numbers=True,
                    password_require_symbols=False,
                    password_expiry_days=90,
                    max_login_attempts=5,
                    lockout_duration_minutes=15,
                    session_timeout_minutes=480,  # 8 hours
                    require_2fa=False,
                    allowed_ip_ranges=["0.0.0.0/0"],  # Allow all IPs
                    data_retention_days=365,
                    encryption_required=True
                ),
                "professional": SecurityPolicy(
                    password_min_length=10,
                    password_require_uppercase=True,
                    password_require_lowercase=True,
                    password_require_numbers=True,
                    password_require_symbols=True,
                    password_expiry_days=60,
                    max_login_attempts=3,
                    lockout_duration_minutes=30,
                    session_timeout_minutes=240,  # 4 hours
                    require_2fa=True,
                    allowed_ip_ranges=["0.0.0.0/0"],
                    data_retention_days=2555,  # 7 years
                    encryption_required=True
                ),
                "enterprise": SecurityPolicy(
                    password_min_length=12,
                    password_require_uppercase=True,
                    password_require_lowercase=True,
                    password_require_numbers=True,
                    password_require_symbols=True,
                    password_expiry_days=45,
                    max_login_attempts=3,
                    lockout_duration_minutes=60,
                    session_timeout_minutes=120,  # 2 hours
                    require_2fa=True,
                    allowed_ip_ranges=[],  # Must be configured per tenant
                    data_retention_days=2555,
                    encryption_required=True
                )
            }
            
            # Generate encryption keys for demo tenants
            demo_tenants = ["tenant_acme_corp", "tenant_global_mfg", "tenant_startup_demo"]
            for tenant_id in demo_tenants:
                self.encryption_keys[tenant_id] = Fernet.generate_key()
            
            # Initialize compliance standards
            await self.initialize_compliance_standards()
            
            # Start security monitoring
            asyncio.create_task(self.start_security_monitoring())
            
            logger.info("✅ Enterprise security framework initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize security framework: {e}")
    
    async def initialize_compliance_standards(self):
        """Initialize compliance standards and requirements"""
        try:
            # SOC 2 Type II requirements
            soc2_requirements = {
                "CC1.1": "Control Environment - Management establishes structures, reporting lines, and appropriate authorities and responsibilities",
                "CC1.2": "Control Environment - Management establishes oversight responsibilities",
                "CC2.1": "Communication and Information - Internal communication objectives",
                "CC3.1": "Risk Assessment - Risk identification process",
                "CC4.1": "Monitoring Activities - Control deficiency evaluation",
                "CC5.1": "Control Activities - Design and implementation of controls",
                "CC6.1": "Logical and Physical Access - Access control policies",
                "CC6.2": "Logical and Physical Access - Multi-factor authentication",
                "CC7.1": "System Operations - System monitoring",
                "CC8.1": "Change Management - Change authorization processes"
            }
            
            # ISO 27001 requirements
            iso27001_requirements = {
                "A.5.1.1": "Information security policies",
                "A.6.1.1": "Information security roles and responsibilities",
                "A.7.1.1": "Screening of personnel",
                "A.8.1.1": "Inventory of assets",
                "A.9.1.1": "Access control policy",
                "A.10.1.1": "Cryptographic controls",
                "A.11.1.1": "Physical security perimeters",
                "A.12.1.1": "Operational procedures and responsibilities",
                "A.13.1.1": "Network security management",
                "A.14.1.1": "Information security requirements analysis"
            }
            
            # GDPR requirements
            gdpr_requirements = {
                "Art.25": "Data protection by design and by default",
                "Art.30": "Records of processing activities",
                "Art.32": "Security of processing",
                "Art.33": "Notification of data breach to supervisory authority",
                "Art.34": "Communication of data breach to data subject",
                "Art.35": "Data protection impact assessment"
            }
            
            logger.info("📋 Compliance standards initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize compliance standards: {e}")
    
    async def validate_password_policy(self, tenant_id: str, password: str) -> Tuple[bool, List[str]]:
        """Validate password against tenant security policy"""
        try:
            policy = self.security_policies.get(tenant_id, self.security_policies["starter"])
            errors = []
            
            # Length check
            if len(password) < policy.password_min_length:
                errors.append(f"Password must be at least {policy.password_min_length} characters long")
            
            # Character requirements
            if policy.password_require_uppercase and not any(c.isupper() for c in password):
                errors.append("Password must contain at least one uppercase letter")
            
            if policy.password_require_lowercase and not any(c.islower() for c in password):
                errors.append("Password must contain at least one lowercase letter")
            
            if policy.password_require_numbers and not any(c.isdigit() for c in password):
                errors.append("Password must contain at least one number")
            
            if policy.password_require_symbols and not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
                errors.append("Password must contain at least one special character")
            
            # Check against common passwords
            common_passwords = [
                "password", "123456", "password123", "admin", "letmein",
                "welcome", "monkey", "1234567890", "qwerty", "abc123"
            ]
            if password.lower() in common_passwords:
                errors.append("Password is too common and easily guessed")
            
            return len(errors) == 0, errors
            
        except Exception as e:
            logger.error(f"❌ Password validation failed: {e}")
            return False, ["Password validation error"]
    
    async def check_ip_whitelist(self, tenant_id: str, ip_address: str) -> bool:
        """Check if IP address is allowed for tenant"""
        try:
            # Get tenant IP whitelist
            allowed_ranges = self.ip_whitelist.get(tenant_id, set())
            
            if not allowed_ranges:
                # If no whitelist configured, allow all (less secure)
                return True
            
            client_ip = ipaddress.ip_address(ip_address)
            
            for ip_range in allowed_ranges:
                try:
                    if client_ip in ipaddress.ip_network(ip_range, strict=False):
                        return True
                except ValueError:
                    # Invalid IP range format
                    continue
            
            return False
            
        except Exception as e:
            logger.error(f"❌ IP whitelist check failed: {e}")
            return True  # Default to allow on error
    
    async def log_audit_event(self, event_data: Dict[str, Any]) -> str:
        """Log security audit event"""
        try:
            event_id = f"evt_{int(time.time() * 1000)}_{secrets.token_hex(4)}"
            
            # Calculate risk score
            risk_score = await self.calculate_event_risk_score(event_data)
            
            audit_event = AuditEvent(
                event_id=event_id,
                tenant_id=event_data.get("tenant_id", "system"),
                user_id=event_data.get("user_id"),
                event_type=AuditEventType(event_data["event_type"]),
                resource=event_data.get("resource", "unknown"),
                action=event_data["action"],
                result=event_data["result"],
                ip_address=event_data.get("ip_address", "unknown"),
                user_agent=event_data.get("user_agent", "unknown"),
                timestamp=datetime.now().isoformat(),
                details=event_data.get("details", {}),
                risk_score=risk_score
            )
            
            self.audit_logs.append(audit_event)
            
            # Check for security incidents
            if risk_score > 0.7 or event_data["result"] == "blocked":
                await self.create_security_incident(audit_event)
            
            # Retain only last 10000 audit events for demo
            if len(self.audit_logs) > 10000:
                self.audit_logs = self.audit_logs[-10000:]
            
            return event_id
            
        except Exception as e:
            logger.error(f"❌ Failed to log audit event: {e}")
            return "error"
    
    async def calculate_event_risk_score(self, event_data: Dict[str, Any]) -> float:
        """Calculate risk score for security event"""
        try:
            risk_score = 0.0
            
            # Base risk by event type
            event_type_risks = {
                "login": 0.1,
                "logout": 0.0,
                "data_access": 0.2,
                "data_export": 0.5,
                "configuration_change": 0.6,
                "user_management": 0.4,
                "security_incident": 0.9
            }
            
            risk_score += event_type_risks.get(event_data.get("event_type", ""), 0.3)
            
            # Increase risk for failures
            if event_data.get("result") == "failure":
                risk_score += 0.3
            elif event_data.get("result") == "blocked":
                risk_score += 0.5
            
            # Increase risk for sensitive resources
            resource = event_data.get("resource", "").lower()
            if any(keyword in resource for keyword in ["password", "key", "token", "admin", "config"]):
                risk_score += 0.2
            
            # Increase risk for unusual times (outside business hours)
            current_hour = datetime.now().hour
            if current_hour < 6 or current_hour > 22:
                risk_score += 0.1
            
            # Check for repeated failed attempts
            user_id = event_data.get("user_id")
            if user_id and event_data.get("result") == "failure":
                tenant_id = event_data.get("tenant_id", "")
                if tenant_id not in self.failed_login_attempts:
                    self.failed_login_attempts[tenant_id] = {}
                
                if user_id not in self.failed_login_attempts[tenant_id]:
                    self.failed_login_attempts[tenant_id][user_id] = 0
                
                self.failed_login_attempts[tenant_id][user_id] += 1
                
                # Increase risk with repeated failures
                failures = self.failed_login_attempts[tenant_id][user_id]
                if failures > 3:
                    risk_score += 0.4
                elif failures > 5:
                    risk_score += 0.6
            
            return min(1.0, risk_score)
            
        except Exception as e:
            logger.error(f"❌ Risk score calculation failed: {e}")
            return 0.5  # Default medium risk
    
    async def create_security_incident(self, audit_event: AuditEvent) -> str:
        """Create security incident from high-risk audit event"""
        try:
            incident_id = f"inc_{int(time.time() * 1000)}_{secrets.token_hex(4)}"
            
            # Determine severity
            if audit_event.risk_score >= 0.9:
                severity = "critical"
            elif audit_event.risk_score >= 0.7:
                severity = "high"
            elif audit_event.risk_score >= 0.5:
                severity = "medium"
            else:
                severity = "low"
            
            incident = SecurityIncident(
                incident_id=incident_id,
                tenant_id=audit_event.tenant_id,
                severity=severity,
                incident_type=f"Suspicious {audit_event.event_type.value}",
                description=f"High-risk {audit_event.event_type.value} detected for {audit_event.resource}",
                affected_resources=[audit_event.resource],
                status="open",
                created_at=datetime.now().isoformat(),
                resolved_at=None,
                resolution_notes=None
            )
            
            self.security_incidents.append(incident)
            
            logger.warning(f"🚨 Security incident created: {incident_id} ({severity})")
            
            return incident_id
            
        except Exception as e:
            logger.error(f"❌ Failed to create security incident: {e}")
            return "error"
    
    async def encrypt_sensitive_data(self, tenant_id: str, data: str) -> str:
        """Encrypt sensitive data using tenant-specific key"""
        try:
            if tenant_id not in self.encryption_keys:
                self.encryption_keys[tenant_id] = Fernet.generate_key()
            
            fernet = Fernet(self.encryption_keys[tenant_id])
            encrypted_data = fernet.encrypt(data.encode())
            
            return encrypted_data.decode()
            
        except Exception as e:
            logger.error(f"❌ Data encryption failed: {e}")
            return data  # Return original data on encryption failure
    
    async def decrypt_sensitive_data(self, tenant_id: str, encrypted_data: str) -> str:
        """Decrypt sensitive data using tenant-specific key"""
        try:
            if tenant_id not in self.encryption_keys:
                return encrypted_data  # Return as-is if no key
            
            fernet = Fernet(self.encryption_keys[tenant_id])
            decrypted_data = fernet.decrypt(encrypted_data.encode())
            
            return decrypted_data.decode()
            
        except Exception as e:
            logger.error(f"❌ Data decryption failed: {e}")
            return encrypted_data  # Return encrypted data on decryption failure
    
    async def generate_compliance_report(self, tenant_id: str, standard: ComplianceStandard) -> ComplianceReport:
        """Generate compliance report for tenant"""
        try:
            report_id = f"rpt_{tenant_id}_{standard.value}_{int(time.time())}"
            
            # Mock compliance assessment
            requirements_met = 0
            total_requirements = 0
            findings = []
            
            if standard == ComplianceStandard.SOC2:
                total_requirements = 10
                # Mock assessment results
                soc2_checks = [
                    ("Access Controls", True, "Multi-factor authentication implemented"),
                    ("System Monitoring", True, "Comprehensive audit logging in place"),
                    ("Data Encryption", True, "Data encrypted at rest and in transit"),
                    ("Change Management", True, "Documented change control processes"),
                    ("Incident Response", True, "Security incident response procedures"),
                    ("Physical Security", False, "Data center security documentation needed"),
                    ("Business Continuity", True, "Backup and recovery procedures documented"),
                    ("Risk Assessment", True, "Regular security risk assessments performed"),
                    ("Vendor Management", False, "Third-party security assessments incomplete"),
                    ("Data Retention", True, "Data retention policies implemented")
                ]
                
                for control, compliant, description in soc2_checks:
                    if compliant:
                        requirements_met += 1
                    else:
                        findings.append({
                            "control": control,
                            "status": "non_compliant",
                            "description": description,
                            "recommendation": f"Implement {control.lower()} controls",
                            "severity": "medium"
                        })
            
            elif standard == ComplianceStandard.GDPR:
                total_requirements = 6
                gdpr_checks = [
                    ("Data Protection by Design", True, "Privacy controls implemented"),
                    ("Processing Records", True, "Data processing activities documented"),
                    ("Security of Processing", True, "Technical security measures in place"),
                    ("Breach Notification", True, "Breach notification procedures defined"),
                    ("Data Subject Rights", False, "Data subject request handling needs improvement"),
                    ("Impact Assessment", True, "DPIA processes established")
                ]
                
                for control, compliant, description in gdpr_checks:
                    if compliant:
                        requirements_met += 1
                    else:
                        findings.append({
                            "control": control,
                            "status": "non_compliant",
                            "description": description,
                            "recommendation": f"Enhance {control.lower()} procedures",
                            "severity": "high"
                        })
            
            elif standard == ComplianceStandard.ISO27001:
                total_requirements = 10
                # Mock ISO 27001 assessment
                requirements_met = 8  # 80% compliance
                findings = [
                    {
                        "control": "A.11.1.1 Physical security perimeters",
                        "status": "partial_compliance",
                        "description": "Physical security controls partially implemented",
                        "recommendation": "Complete physical security assessment",
                        "severity": "medium"
                    },
                    {
                        "control": "A.7.1.1 Screening of personnel",
                        "status": "non_compliant",
                        "description": "Background check procedures need enhancement",
                        "recommendation": "Implement comprehensive background screening",
                        "severity": "low"
                    }
                ]
            
            compliance_score = requirements_met / total_requirements if total_requirements > 0 else 0
            
            report = ComplianceReport(
                report_id=report_id,
                tenant_id=tenant_id,
                standard=standard,
                compliance_score=compliance_score,
                requirements_met=requirements_met,
                total_requirements=total_requirements,
                findings=findings,
                generated_at=datetime.now().isoformat(),
                valid_until=(datetime.now() + timedelta(days=90)).isoformat()
            )
            
            self.compliance_reports[report_id] = report
            
            return report
            
        except Exception as e:
            logger.error(f"❌ Compliance report generation failed: {e}")
            raise HTTPException(status_code=500, detail="Compliance report generation failed")
    
    async def start_security_monitoring(self):
        """Start continuous security monitoring"""
        while True:
            try:
                await asyncio.sleep(300)  # Check every 5 minutes
                
                # Monitor for suspicious patterns
                await self.detect_suspicious_patterns()
                
                # Clean up old logs
                await self.cleanup_old_logs()
                
                # Update compliance status
                await self.update_compliance_status()
                
            except Exception as e:
                logger.error(f"❌ Security monitoring error: {e}")
                await asyncio.sleep(300)
    
    async def detect_suspicious_patterns(self):
        """Detect suspicious patterns in audit logs"""
        try:
            # Analyze recent events (last hour)
            recent_time = datetime.now() - timedelta(hours=1)
            recent_events = [
                event for event in self.audit_logs
                if datetime.fromisoformat(event.timestamp) > recent_time
            ]
            
            # Detect patterns
            if len(recent_events) > 100:  # High activity
                await self.log_audit_event({
                    "event_type": "security_incident",
                    "action": "high_activity_detected",
                    "result": "detected",
                    "details": {"event_count": len(recent_events)}
                })
            
            # Detect multiple failures from same IP
            ip_failures = {}
            for event in recent_events:
                if event.result == "failure":
                    ip = event.ip_address
                    ip_failures[ip] = ip_failures.get(ip, 0) + 1
            
            for ip, failures in ip_failures.items():
                if failures >= 10:  # 10+ failures from same IP
                    await self.log_audit_event({
                        "event_type": "security_incident",
                        "action": "brute_force_detected",
                        "result": "blocked",
                        "ip_address": ip,
                        "details": {"failure_count": failures}
                    })
            
        except Exception as e:
            logger.error(f"❌ Suspicious pattern detection failed: {e}")
    
    async def cleanup_old_logs(self):
        """Clean up old audit logs based on retention policies"""
        try:
            # Keep logs for 1 year (demo retention)
            cutoff_date = datetime.now() - timedelta(days=365)
            
            original_count = len(self.audit_logs)
            self.audit_logs = [
                log for log in self.audit_logs
                if datetime.fromisoformat(log.timestamp) > cutoff_date
            ]
            
            cleaned_count = original_count - len(self.audit_logs)
            if cleaned_count > 0:
                logger.info(f"🧹 Cleaned up {cleaned_count} old audit logs")
            
        except Exception as e:
            logger.error(f"❌ Log cleanup failed: {e}")
    
    async def update_compliance_status(self):
        """Update compliance status for all tenants"""
        try:
            # This would typically run compliance checks
            # For demo, we'll just log the activity
            logger.debug("📋 Compliance status check completed")
            
        except Exception as e:
            logger.error(f"❌ Compliance status update failed: {e}")

# Initialize global security manager
security_manager = EnterpriseSecurityManager()

# Security middleware
async def security_audit_middleware(request: Request, call_next):
    """Middleware for security auditing"""
    start_time = time.time()
    
    # Log request
    await security_manager.log_audit_event({
        "event_type": "data_access",
        "action": f"{request.method} {request.url.path}",
        "result": "started",
        "ip_address": request.client.host,
        "user_agent": request.headers.get("user-agent", "unknown"),
        "details": {"method": request.method, "path": str(request.url.path)}
    })
    
    response = await call_next(request)
    
    # Log response
    duration = time.time() - start_time
    result = "success" if response.status_code < 400 else "failure"
    
    await security_manager.log_audit_event({
        "event_type": "data_access",
        "action": f"{request.method} {request.url.path}",
        "result": result,
        "ip_address": request.client.host,
        "user_agent": request.headers.get("user-agent", "unknown"),
        "details": {
            "method": request.method,
            "path": str(request.url.path),
            "status_code": response.status_code,
            "duration_ms": round(duration * 1000, 2)
        }
    })
    
    return response

# API Endpoints
@security_router.get("/audit-logs")
async def get_audit_logs(
    tenant_id: Optional[str] = None,
    event_type: Optional[str] = None,
    limit: int = 100
):
    """Get security audit logs"""
    try:
        logs = security_manager.audit_logs
        
        # Filter by tenant
        if tenant_id:
            logs = [log for log in logs if log.tenant_id == tenant_id]
        
        # Filter by event type
        if event_type:
            logs = [log for log in logs if log.event_type.value == event_type]
        
        # Sort by timestamp (newest first)
        logs = sorted(logs, key=lambda x: x.timestamp, reverse=True)
        
        # Limit results
        logs = logs[:limit]
        
        return JSONResponse({
            "audit_logs": [log.dict() for log in logs],
            "total_count": len(logs),
            "filtered": bool(tenant_id or event_type)
        })
        
    except Exception as e:
        logger.error(f"❌ Failed to get audit logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve audit logs")

@security_router.get("/incidents")
async def get_security_incidents(tenant_id: Optional[str] = None):
    """Get security incidents"""
    incidents = security_manager.security_incidents
    
    if tenant_id:
        incidents = [inc for inc in incidents if inc.tenant_id == tenant_id]
    
    # Sort by created date (newest first)
    incidents = sorted(incidents, key=lambda x: x.created_at, reverse=True)
    
    return JSONResponse({
        "security_incidents": [incident.dict() for incident in incidents],
        "summary": {
            "total": len(incidents),
            "critical": len([i for i in incidents if i.severity == "critical"]),
            "high": len([i for i in incidents if i.severity == "high"]),
            "medium": len([i for i in incidents if i.severity == "medium"]),
            "low": len([i for i in incidents if i.severity == "low"]),
            "open": len([i for i in incidents if i.status == "open"])
        }
    })

@security_router.post("/compliance-report")
async def generate_compliance_report_endpoint(data: Dict[str, Any]):
    """Generate compliance report for tenant"""
    tenant_id = data.get("tenant_id")
    standard = data.get("standard")
    
    if not tenant_id or not standard:
        raise HTTPException(status_code=400, detail="tenant_id and standard are required")
    
    try:
        compliance_standard = ComplianceStandard(standard)
        report = await security_manager.generate_compliance_report(tenant_id, compliance_standard)
        
        return report.dict()
        
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid compliance standard")
    except Exception as e:
        logger.error(f"❌ Compliance report generation failed: {e}")
        raise HTTPException(status_code=500, detail="Report generation failed")

@security_router.get("/compliance-reports")
async def get_compliance_reports(tenant_id: Optional[str] = None):
    """Get compliance reports"""
    reports = list(security_manager.compliance_reports.values())
    
    if tenant_id:
        reports = [report for report in reports if report.tenant_id == tenant_id]
    
    return JSONResponse({
        "compliance_reports": [report.dict() for report in reports],
        "total_count": len(reports)
    })

@security_router.get("/security-policies")
async def get_security_policies():
    """Get available security policies by tier"""
    policies = {}
    
    for tier, policy in security_manager.security_policies.items():
        policies[tier] = policy.__dict__
    
    return JSONResponse({"security_policies": policies})

@security_router.post("/validate-password")
async def validate_password_endpoint(data: Dict[str, Any]):
    """Validate password against security policy"""
    tenant_id = data.get("tenant_id", "starter")
    password = data.get("password", "")
    
    if not password:
        raise HTTPException(status_code=400, detail="Password is required")
    
    is_valid, errors = await security_manager.validate_password_policy(tenant_id, password)
    
    return JSONResponse({
        "valid": is_valid,
        "errors": errors,
        "strength_score": 1.0 if is_valid else 0.5  # Simple strength scoring
    })

@security_router.get("/security-dashboard")
async def get_security_dashboard(tenant_id: Optional[str] = None):
    """Get security dashboard data"""
    try:
        # Filter logs by tenant if specified
        logs = security_manager.audit_logs
        incidents = security_manager.security_incidents
        
        if tenant_id:
            logs = [log for log in logs if log.tenant_id == tenant_id]
            incidents = [inc for inc in incidents if inc.tenant_id == tenant_id]
        
        # Recent activity (last 24 hours)
        recent_time = datetime.now() - timedelta(hours=24)
        recent_logs = [
            log for log in logs
            if datetime.fromisoformat(log.timestamp) > recent_time
        ]
        
        # Calculate metrics
        total_events = len(recent_logs)
        failed_events = len([log for log in recent_logs if log.result == "failure"])
        high_risk_events = len([log for log in recent_logs if log.risk_score > 0.7])
        
        # Top event types
        event_types = {}
        for log in recent_logs:
            event_type = log.event_type.value
            event_types[event_type] = event_types.get(event_type, 0) + 1
        
        dashboard = {
            "overview": {
                "total_events_24h": total_events,
                "failed_events_24h": failed_events,
                "high_risk_events_24h": high_risk_events,
                "success_rate": round((total_events - failed_events) / total_events * 100, 1) if total_events > 0 else 100,
                "active_incidents": len([inc for inc in incidents if inc.status == "open"])
            },
            "event_distribution": event_types,
            "recent_incidents": [inc.dict() for inc in incidents[:5]],
            "compliance_status": {
                "soc2_compliance": 0.85,
                "gdpr_compliance": 0.92,
                "iso27001_compliance": 0.78
            },
            "risk_trends": {
                "current_risk_level": "medium",
                "trend": "stable",
                "recommendations": [
                    "Review failed login attempts",
                    "Update security policies",
                    "Conduct security training"
                ]
            }
        }
        
        return JSONResponse(dashboard)
        
    except Exception as e:
        logger.error(f"❌ Security dashboard generation failed: {e}")
        raise HTTPException(status_code=500, detail="Dashboard generation failed")

@security_router.get("/encryption-status")
async def get_encryption_status():
    """Get encryption key status for tenants"""
    return JSONResponse({
        "encryption_enabled": True,
        "tenants_with_keys": len(security_manager.encryption_keys),
        "key_rotation_schedule": "Every 90 days",
        "encryption_algorithm": "Fernet (AES 128)",
        "key_management": "Tenant-isolated keys"
    })