#!/usr/bin/env python3
"""
ChatterFix CMMS - Enterprise White-Label & Customization Platform
Complete white-label branding and tenant customization system
"""

import os
import json
import base64
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from fastapi import APIRouter, HTTPException, Depends, File, UploadFile
from fastapi.responses import JSONResponse, HTMLResponse
from PIL import Image
import io

# Enterprise White-Label Router
enterprise_white_label_router = APIRouter(prefix="/cmms/enterprise/white-label", tags=["Enterprise White-Label"])

@dataclass
class BrandingConfig:
    """White-label branding configuration"""
    tenant_id: str
    brand_name: str
    primary_color: str
    secondary_color: str
    accent_color: str
    logo_url: Optional[str] = None
    favicon_url: Optional[str] = None
    custom_css: Optional[str] = None
    font_family: str = "Inter, sans-serif"
    theme_mode: str = "light"  # light, dark, auto
    created_at: datetime = None
    updated_at: datetime = None

@dataclass
class CustomWorkflow:
    """Custom workflow definition"""
    workflow_id: str
    tenant_id: str
    name: str
    description: str
    trigger_type: str  # manual, scheduled, condition, webhook
    trigger_config: Dict
    steps: List[Dict]
    is_active: bool = True
    created_at: datetime = None
    updated_at: datetime = None

@dataclass
class UICustomization:
    """UI customization settings"""
    tenant_id: str
    dashboard_layout: Dict
    module_visibility: Dict[str, bool]
    custom_fields: Dict[str, List[Dict]]
    navigation_config: Dict
    widget_configs: Dict
    form_layouts: Dict
    created_at: datetime = None
    updated_at: datetime = None

class EnterpriseWhiteLabelManager:
    """Enterprise white-label and customization manager"""
    
    def __init__(self):
        self.branding_configs: Dict[str, BrandingConfig] = {}
        self.custom_workflows: Dict[str, List[CustomWorkflow]] = {}
        self.ui_customizations: Dict[str, UICustomization] = {}
        self.supported_languages = [
            "en", "es", "fr", "de", "it", "pt", "ja", "ko", "zh", "ru"
        ]
        self.supported_currencies = [
            "USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "KRW", "BRL"
        ]
        
        # Initialize demo configurations
        self._init_demo_configurations()
    
    def _init_demo_configurations(self):
        """Initialize demo white-label configurations"""
        
        # Demo Manufacturing Company
        demo_manufacturing = BrandingConfig(
            tenant_id="demo_manufacturing",
            brand_name="AcmeCorp Maintenance",
            primary_color="#1e40af",
            secondary_color="#3b82f6",
            accent_color="#f59e0b",
            font_family="Roboto, sans-serif",
            theme_mode="light"
        )
        self.branding_configs["demo_manufacturing"] = demo_manufacturing
        
        # Demo Healthcare System
        demo_healthcare = BrandingConfig(
            tenant_id="demo_healthcare",
            brand_name="MedTech Solutions",
            primary_color="#059669",
            secondary_color="#10b981",
            accent_color="#ef4444",
            font_family="Source Sans Pro, sans-serif",
            theme_mode="light"
        )
        self.branding_configs["demo_healthcare"] = demo_healthcare
        
        # Demo Logistics Company
        demo_logistics = BrandingConfig(
            tenant_id="demo_logistics",
            brand_name="SwiftLogistics Pro",
            primary_color="#7c3aed",
            secondary_color="#a855f7",
            accent_color="#f97316",
            font_family="Open Sans, sans-serif",
            theme_mode="dark"
        )
        self.branding_configs["demo_logistics"] = demo_logistics
        
        # Initialize demo workflows
        self._init_demo_workflows()
        
        # Initialize demo UI customizations
        self._init_demo_ui_customizations()
    
    def _init_demo_workflows(self):
        """Initialize demo custom workflows"""
        
        # Critical Equipment Failure Workflow
        critical_failure_workflow = CustomWorkflow(
            workflow_id="critical_failure_response",
            tenant_id="demo_manufacturing",
            name="Critical Equipment Failure Response",
            description="Automated workflow for critical equipment failures",
            trigger_type="condition",
            trigger_config={
                "condition": "asset_status == 'critical_failure'",
                "asset_types": ["production_line", "hvac_system"]
            },
            steps=[
                {
                    "step_id": "create_urgent_wo",
                    "type": "create_work_order",
                    "config": {
                        "priority": "critical",
                        "auto_assign": True,
                        "notification_channels": ["sms", "email", "slack"]
                    }
                },
                {
                    "step_id": "notify_management",
                    "type": "send_notification",
                    "config": {
                        "recipients": ["maintenance_manager", "operations_director"],
                        "template": "critical_failure_alert"
                    }
                },
                {
                    "step_id": "update_dashboard",
                    "type": "dashboard_alert",
                    "config": {
                        "alert_level": "critical",
                        "display_duration": 3600
                    }
                }
            ]
        )
        
        self.custom_workflows["demo_manufacturing"] = [critical_failure_workflow]
        
        # Preventive Maintenance Workflow for Healthcare
        pm_healthcare_workflow = CustomWorkflow(
            workflow_id="healthcare_pm_compliance",
            tenant_id="demo_healthcare",
            name="Healthcare PM Compliance Check",
            description="Ensures all medical equipment meets compliance requirements",
            trigger_type="scheduled",
            trigger_config={
                "schedule": "0 6 * * 1",  # Every Monday at 6 AM
                "timezone": "UTC"
            },
            steps=[
                {
                    "step_id": "compliance_check",
                    "type": "run_compliance_audit",
                    "config": {
                        "standards": ["FDA", "ISO_13485", "IEC_62304"],
                        "equipment_categories": ["diagnostic", "life_support", "surgical"]
                    }
                },
                {
                    "step_id": "generate_report",
                    "type": "generate_compliance_report",
                    "config": {
                        "format": "pdf",
                        "include_charts": True,
                        "auto_submit": True
                    }
                }
            ]
        )
        
        self.custom_workflows["demo_healthcare"] = [pm_healthcare_workflow]
    
    def _init_demo_ui_customizations(self):
        """Initialize demo UI customizations"""
        
        # Manufacturing UI Customization
        manufacturing_ui = UICustomization(
            tenant_id="demo_manufacturing",
            dashboard_layout={
                "widgets": [
                    {"id": "production_kpis", "position": {"x": 0, "y": 0}, "size": {"w": 6, "h": 4}},
                    {"id": "equipment_health", "position": {"x": 6, "y": 0}, "size": {"w": 6, "h": 4}},
                    {"id": "work_order_queue", "position": {"x": 0, "y": 4}, "size": {"w": 12, "h": 6}}
                ]
            },
            module_visibility={
                "work_orders": True,
                "assets": True,
                "preventive": True,
                "inventory": True,
                "reports": True,
                "mobile": True,
                "ai_assistant": True,
                "quality_control": True,
                "production_planning": False
            },
            custom_fields={
                "work_orders": [
                    {"name": "production_line_impact", "type": "select", "options": ["none", "minor", "major", "critical"]},
                    {"name": "safety_requirements", "type": "textarea", "required": True},
                    {"name": "environmental_impact", "type": "checkbox", "label": "Environmental considerations required"}
                ],
                "assets": [
                    {"name": "oee_target", "type": "number", "min": 0, "max": 100, "unit": "%"},
                    {"name": "production_capacity", "type": "number", "unit": "units/hour"},
                    {"name": "quality_grade", "type": "select", "options": ["A", "B", "C", "D"]}
                ]
            },
            navigation_config={
                "primary_menu": ["dashboard", "work_orders", "assets", "preventive", "inventory"],
                "quick_actions": ["create_wo", "emergency_stop", "production_report"]
            },
            widget_configs={
                "production_kpis": {
                    "metrics": ["oee", "availability", "performance", "quality"],
                    "chart_type": "gauge",
                    "refresh_interval": 30
                }
            },
            form_layouts={
                "work_order_create": {
                    "sections": [
                        {"title": "Basic Information", "fields": ["title", "description", "priority"]},
                        {"title": "Production Impact", "fields": ["production_line_impact", "estimated_downtime"]},
                        {"title": "Safety & Compliance", "fields": ["safety_requirements", "environmental_impact"]}
                    ]
                }
            }
        )
        
        self.ui_customizations["demo_manufacturing"] = manufacturing_ui
        
        # Healthcare UI Customization
        healthcare_ui = UICustomization(
            tenant_id="demo_healthcare",
            dashboard_layout={
                "widgets": [
                    {"id": "patient_safety_alerts", "position": {"x": 0, "y": 0}, "size": {"w": 12, "h": 3}},
                    {"id": "medical_equipment_status", "position": {"x": 0, "y": 3}, "size": {"w": 8, "h": 5}},
                    {"id": "compliance_dashboard", "position": {"x": 8, "y": 3}, "size": {"w": 4, "h": 5}}
                ]
            },
            module_visibility={
                "work_orders": True,
                "assets": True,
                "preventive": True,
                "inventory": True,
                "reports": True,
                "mobile": True,
                "ai_assistant": True,
                "compliance_management": True,
                "patient_safety": True,
                "biomedical_engineering": True
            },
            custom_fields={
                "work_orders": [
                    {"name": "patient_impact", "type": "select", "options": ["none", "low", "medium", "high", "critical"]},
                    {"name": "infection_control", "type": "checkbox", "label": "Infection control protocols required"},
                    {"name": "fda_reporting", "type": "checkbox", "label": "FDA incident reporting required"}
                ],
                "assets": [
                    {"name": "fda_class", "type": "select", "options": ["Class I", "Class II", "Class III"]},
                    {"name": "biomedical_id", "type": "text", "required": True},
                    {"name": "last_calibration", "type": "date"},
                    {"name": "next_calibration", "type": "date", "required": True}
                ]
            },
            navigation_config={
                "primary_menu": ["dashboard", "work_orders", "medical_equipment", "preventive", "compliance"],
                "quick_actions": ["emergency_repair", "patient_safety_alert", "compliance_check"]
            },
            widget_configs={
                "patient_safety_alerts": {
                    "alert_types": ["critical_equipment", "expired_certifications", "overdue_maintenance"],
                    "auto_refresh": True,
                    "sound_alerts": True
                }
            }
        )
        
        self.ui_customizations["demo_healthcare"] = healthcare_ui

# White-Label API Endpoints

@enterprise_white_label_router.get("/branding/{tenant_id}")
async def get_branding_config(tenant_id: str):
    """Get white-label branding configuration for tenant"""
    manager = EnterpriseWhiteLabelManager()
    
    if tenant_id not in manager.branding_configs:
        raise HTTPException(status_code=404, detail="Tenant branding configuration not found")
    
    config = manager.branding_configs[tenant_id]
    return JSONResponse({
        "success": True,
        "branding": asdict(config)
    })

@enterprise_white_label_router.put("/branding/{tenant_id}")
async def update_branding_config(tenant_id: str, branding_data: dict):
    """Update white-label branding configuration"""
    manager = EnterpriseWhiteLabelManager()
    
    try:
        # Validate branding data
        required_fields = ["brand_name", "primary_color", "secondary_color", "accent_color"]
        for field in required_fields:
            if field not in branding_data:
                raise HTTPException(status_code=400, detail=f"Missing required field: {field}")
        
        # Update or create branding config
        config = BrandingConfig(
            tenant_id=tenant_id,
            brand_name=branding_data["brand_name"],
            primary_color=branding_data["primary_color"],
            secondary_color=branding_data["secondary_color"],
            accent_color=branding_data["accent_color"],
            logo_url=branding_data.get("logo_url"),
            favicon_url=branding_data.get("favicon_url"),
            custom_css=branding_data.get("custom_css"),
            font_family=branding_data.get("font_family", "Inter, sans-serif"),
            theme_mode=branding_data.get("theme_mode", "light"),
            updated_at=datetime.utcnow()
        )
        
        manager.branding_configs[tenant_id] = config
        
        return JSONResponse({
            "success": True,
            "message": "Branding configuration updated successfully",
            "branding": asdict(config)
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update branding: {str(e)}")

@enterprise_white_label_router.post("/branding/{tenant_id}/logo")
async def upload_logo(tenant_id: str, file: UploadFile = File(...)):
    """Upload custom logo for tenant"""
    try:
        # Validate file type
        if not file.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail="File must be an image")
        
        # Process image
        image_data = await file.read()
        image = Image.open(io.BytesIO(image_data))
        
        # Resize if needed (max 500x200)
        if image.width > 500 or image.height > 200:
            image.thumbnail((500, 200), Image.Resampling.LANCZOS)
        
        # Save as base64 (in production, save to cloud storage)
        buffer = io.BytesIO()
        image.save(buffer, format='PNG')
        base64_image = base64.b64encode(buffer.getvalue()).decode()
        logo_url = f"data:image/png;base64,{base64_image}"
        
        return JSONResponse({
            "success": True,
            "logo_url": logo_url,
            "message": "Logo uploaded successfully"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload logo: {str(e)}")

@enterprise_white_label_router.get("/customization/{tenant_id}")
async def get_ui_customization(tenant_id: str):
    """Get UI customization configuration for tenant"""
    manager = EnterpriseWhiteLabelManager()
    
    if tenant_id not in manager.ui_customizations:
        # Return default customization
        return JSONResponse({
            "success": True,
            "customization": {
                "tenant_id": tenant_id,
                "dashboard_layout": {"widgets": []},
                "module_visibility": {},
                "custom_fields": {},
                "navigation_config": {},
                "widget_configs": {},
                "form_layouts": {}
            }
        })
    
    config = manager.ui_customizations[tenant_id]
    return JSONResponse({
        "success": True,
        "customization": asdict(config)
    })

@enterprise_white_label_router.put("/customization/{tenant_id}")
async def update_ui_customization(tenant_id: str, customization_data: dict):
    """Update UI customization configuration"""
    manager = EnterpriseWhiteLabelManager()
    
    try:
        config = UICustomization(
            tenant_id=tenant_id,
            dashboard_layout=customization_data.get("dashboard_layout", {}),
            module_visibility=customization_data.get("module_visibility", {}),
            custom_fields=customization_data.get("custom_fields", {}),
            navigation_config=customization_data.get("navigation_config", {}),
            widget_configs=customization_data.get("widget_configs", {}),
            form_layouts=customization_data.get("form_layouts", {}),
            updated_at=datetime.utcnow()
        )
        
        manager.ui_customizations[tenant_id] = config
        
        return JSONResponse({
            "success": True,
            "message": "UI customization updated successfully",
            "customization": asdict(config)
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update UI customization: {str(e)}")

@enterprise_white_label_router.get("/workflows/{tenant_id}")
async def get_custom_workflows(tenant_id: str):
    """Get custom workflows for tenant"""
    manager = EnterpriseWhiteLabelManager()
    
    workflows = manager.custom_workflows.get(tenant_id, [])
    return JSONResponse({
        "success": True,
        "workflows": [asdict(workflow) for workflow in workflows]
    })

@enterprise_white_label_router.post("/workflows/{tenant_id}")
async def create_custom_workflow(tenant_id: str, workflow_data: dict):
    """Create new custom workflow for tenant"""
    manager = EnterpriseWhiteLabelManager()
    
    try:
        workflow = CustomWorkflow(
            workflow_id=workflow_data["workflow_id"],
            tenant_id=tenant_id,
            name=workflow_data["name"],
            description=workflow_data["description"],
            trigger_type=workflow_data["trigger_type"],
            trigger_config=workflow_data["trigger_config"],
            steps=workflow_data["steps"],
            is_active=workflow_data.get("is_active", True),
            created_at=datetime.utcnow()
        )
        
        if tenant_id not in manager.custom_workflows:
            manager.custom_workflows[tenant_id] = []
        
        manager.custom_workflows[tenant_id].append(workflow)
        
        return JSONResponse({
            "success": True,
            "message": "Custom workflow created successfully",
            "workflow": asdict(workflow)
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create workflow: {str(e)}")

@enterprise_white_label_router.get("/demo-configurations")
async def get_demo_configurations():
    """Get all demo white-label configurations"""
    manager = EnterpriseWhiteLabelManager()
    
    demo_configs = {
        tenant_id: {
            "branding": asdict(branding),
            "ui_customization": asdict(manager.ui_customizations.get(tenant_id, UICustomization(tenant_id=tenant_id, dashboard_layout={}, module_visibility={}, custom_fields={}, navigation_config={}, widget_configs={}, form_layouts={}))),
            "workflows": [asdict(workflow) for workflow in manager.custom_workflows.get(tenant_id, [])]
        }
        for tenant_id, branding in manager.branding_configs.items()
    }
    
    return JSONResponse({
        "success": True,
        "demo_configurations": demo_configs,
        "supported_languages": manager.supported_languages,
        "supported_currencies": manager.supported_currencies
    })

@enterprise_white_label_router.get("/branding/{tenant_id}/css")
async def get_custom_css(tenant_id: str):
    """Generate custom CSS for tenant branding"""
    manager = EnterpriseWhiteLabelManager()
    
    if tenant_id not in manager.branding_configs:
        raise HTTPException(status_code=404, detail="Tenant branding configuration not found")
    
    config = manager.branding_configs[tenant_id]
    
    # Generate dynamic CSS
    custom_css = f"""
    /* ChatterFix CMMS - Custom Branding for {config.brand_name} */
    
    :root {{
        --brand-primary: {config.primary_color};
        --brand-secondary: {config.secondary_color};
        --brand-accent: {config.accent_color};
        --brand-font: {config.font_family};
    }}
    
    .brand-header {{
        background: linear-gradient(135deg, {config.primary_color}, {config.secondary_color});
        font-family: var(--brand-font);
    }}
    
    .btn-primary {{
        background-color: var(--brand-primary);
        border-color: var(--brand-primary);
        font-family: var(--brand-font);
    }}
    
    .btn-primary:hover {{
        background-color: {config.secondary_color};
        border-color: {config.secondary_color};
    }}
    
    .navbar-brand {{
        color: var(--brand-primary) !important;
        font-family: var(--brand-font);
        font-weight: bold;
    }}
    
    .sidebar-nav .nav-link.active {{
        background-color: var(--brand-primary);
        color: white;
    }}
    
    .dashboard-widget .widget-header {{
        background: linear-gradient(45deg, var(--brand-primary), var(--brand-secondary));
        color: white;
    }}
    
    .status-indicator.online {{
        background-color: var(--brand-accent);
    }}
    
    /* Theme-specific styles */
    body.theme-{config.theme_mode} {{
        font-family: var(--brand-font);
    }}
    
    {config.custom_css or "/* No additional custom CSS */"}
    """
    
    return HTMLResponse(content=custom_css, media_type="text/css")

@enterprise_white_label_router.get("/localization/languages")
async def get_supported_languages():
    """Get list of supported languages for localization"""
    manager = EnterpriseWhiteLabelManager()
    
    language_details = {
        "en": {"name": "English", "native": "English", "flag": "🇺🇸"},
        "es": {"name": "Spanish", "native": "Español", "flag": "🇪🇸"},
        "fr": {"name": "French", "native": "Français", "flag": "🇫🇷"},
        "de": {"name": "German", "native": "Deutsch", "flag": "🇩🇪"},
        "it": {"name": "Italian", "native": "Italiano", "flag": "🇮🇹"},
        "pt": {"name": "Portuguese", "native": "Português", "flag": "🇵🇹"},
        "ja": {"name": "Japanese", "native": "日本語", "flag": "🇯🇵"},
        "ko": {"name": "Korean", "native": "한국어", "flag": "🇰🇷"},
        "zh": {"name": "Chinese", "native": "中文", "flag": "🇨🇳"},
        "ru": {"name": "Russian", "native": "Русский", "flag": "🇷🇺"}
    }
    
    return JSONResponse({
        "success": True,
        "supported_languages": manager.supported_languages,
        "language_details": language_details
    })

@enterprise_white_label_router.get("/currencies")
async def get_supported_currencies():
    """Get list of supported currencies for multi-currency support"""
    manager = EnterpriseWhiteLabelManager()
    
    currency_details = {
        "USD": {"name": "US Dollar", "symbol": "$", "code": "USD"},
        "EUR": {"name": "Euro", "symbol": "€", "code": "EUR"},
        "GBP": {"name": "British Pound", "symbol": "£", "code": "GBP"},
        "JPY": {"name": "Japanese Yen", "symbol": "¥", "code": "JPY"},
        "AUD": {"name": "Australian Dollar", "symbol": "A$", "code": "AUD"},
        "CAD": {"name": "Canadian Dollar", "symbol": "C$", "code": "CAD"},
        "CHF": {"name": "Swiss Franc", "symbol": "CHF", "code": "CHF"},
        "CNY": {"name": "Chinese Yuan", "symbol": "¥", "code": "CNY"},
        "KRW": {"name": "South Korean Won", "symbol": "₩", "code": "KRW"},
        "BRL": {"name": "Brazilian Real", "symbol": "R$", "code": "BRL"}
    }
    
    return JSONResponse({
        "success": True,
        "supported_currencies": manager.supported_currencies,
        "currency_details": currency_details
    })

if __name__ == "__main__":
    # Demo the white-label system
    manager = EnterpriseWhiteLabelManager()
    
    print("\n🎨 ChatterFix Enterprise White-Label & Customization Platform")
    print("=" * 65)
    
    print(f"\n📊 Demo Configurations: {len(manager.branding_configs)}")
    for tenant_id, config in manager.branding_configs.items():
        print(f"   • {config.brand_name} ({tenant_id})")
        print(f"     Colors: {config.primary_color} / {config.secondary_color}")
        print(f"     Theme: {config.theme_mode}, Font: {config.font_family}")
    
    print(f"\n🔧 Custom Workflows: {sum(len(workflows) for workflows in manager.custom_workflows.values())}")
    for tenant_id, workflows in manager.custom_workflows.items():
        for workflow in workflows:
            print(f"   • {workflow.name} ({tenant_id})")
            print(f"     Trigger: {workflow.trigger_type}, Steps: {len(workflow.steps)}")
    
    print(f"\n🎛️ UI Customizations: {len(manager.ui_customizations)}")
    for tenant_id, ui in manager.ui_customizations.items():
        print(f"   • {tenant_id}")
        print(f"     Widgets: {len(ui.dashboard_layout.get('widgets', []))}")
        print(f"     Custom Fields: {sum(len(fields) for fields in ui.custom_fields.values())}")
    
    print(f"\n🌍 Supported Languages: {', '.join(manager.supported_languages)}")
    print(f"💰 Supported Currencies: {', '.join(manager.supported_currencies)}")
    
    print("\n✅ White-Label Platform Ready!")