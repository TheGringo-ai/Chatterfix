#!/usr/bin/env python3
"""
CMMS File Management System
Handles file uploads, storage, and retrieval for work orders, parts, assets, and manuals
"""

import os
import uuid
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, UploadFile, File, HTTPException, Form, Query
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import logging
import mimetypes
import json

logger = logging.getLogger(__name__)

# File manager router
file_router = APIRouter(prefix="/files", tags=["files"])

# File upload configuration
UPLOAD_DIRECTORY = "uploads"
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
ALLOWED_EXTENSIONS = {
    'images': {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg'},
    'documents': {'.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt'},
    'spreadsheets': {'.xls', '.xlsx', '.csv', '.ods'},
    'videos': {'.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'},
    'audio': {'.mp3', '.wav', '.ogg', '.m4a', '.aac'},
    'archives': {'.zip', '.rar', '.7z', '.tar', '.gz'},
    'cad': {'.dwg', '.dxf', '.step', '.iges', '.stl'},
    'other': {'.xml', '.json', '.log', '.cfg', '.ini'}
}

# Create upload directories
def ensure_upload_directories():
    """Create upload directory structure"""
    base_path = Path(UPLOAD_DIRECTORY)
    subdirs = [
        'work_orders',
        'parts',
        'assets', 
        'manuals',
        'technician_photos',
        'safety_documents',
        'maintenance_records',
        'temp'
    ]
    
    for subdir in subdirs:
        (base_path / subdir).mkdir(parents=True, exist_ok=True)

# File metadata model
class FileMetadata(BaseModel):
    id: str
    filename: str
    original_filename: str
    file_size: int
    mime_type: str
    category: str
    subcategory: str
    uploaded_by: str
    upload_date: str
    description: Optional[str] = None
    tags: List[str] = []
    related_entity_type: str  # work_order, part, asset, manual
    related_entity_id: str
    file_path: str
    thumbnail_path: Optional[str] = None
    is_public: bool = False

# File database (in production, use a real database)
files_db = []

def get_file_category(filename: str) -> str:
    """Determine file category based on extension"""
    ext = Path(filename).suffix.lower()
    for category, extensions in ALLOWED_EXTENSIONS.items():
        if ext in extensions:
            return category
    return 'other'

def is_allowed_file(filename: str) -> bool:
    """Check if file extension is allowed"""
    ext = Path(filename).suffix.lower()
    all_extensions = set()
    for extensions in ALLOWED_EXTENSIONS.values():
        all_extensions.update(extensions)
    return ext in all_extensions

def generate_safe_filename(original_filename: str) -> str:
    """Generate a safe, unique filename"""
    ext = Path(original_filename).suffix.lower()
    unique_id = str(uuid.uuid4())
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{timestamp}_{unique_id}{ext}"

@file_router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    entity_type: str = Form(...),
    entity_id: str = Form(...),
    description: Optional[str] = Form(None),
    tags: Optional[str] = Form(None),
    uploaded_by: str = Form("system")
):
    """
    Upload a file and associate it with a work order, part, asset, or manual
    """
    ensure_upload_directories()
    
    # Validate file
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")
    
    if not is_allowed_file(file.filename):
        raise HTTPException(status_code=400, detail="File type not allowed")
    
    # Check file size
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail="File too large")
    
    # Generate safe filename and path
    safe_filename = generate_safe_filename(file.filename)
    category = get_file_category(file.filename)
    
    # Determine subdirectory based on entity type
    subdir_map = {
        'work_order': 'work_orders',
        'part': 'parts',
        'asset': 'assets',
        'manual': 'manuals',
        'technician': 'technician_photos',
        'safety': 'safety_documents',
        'maintenance': 'maintenance_records'
    }
    
    subdir = subdir_map.get(entity_type, 'temp')
    file_path = Path(UPLOAD_DIRECTORY) / subdir / safe_filename
    
    # Save file
    try:
        with open(file_path, "wb") as buffer:
            buffer.write(content)
    except Exception as e:
        logger.error(f"Error saving file: {e}")
        raise HTTPException(status_code=500, detail="Error saving file")
    
    # Create metadata
    file_id = str(uuid.uuid4())
    metadata = FileMetadata(
        id=file_id,
        filename=safe_filename,
        original_filename=file.filename,
        file_size=len(content),
        mime_type=mimetypes.guess_type(file.filename)[0] or 'application/octet-stream',
        category=category,
        subcategory=subdir,
        uploaded_by=uploaded_by,
        upload_date=datetime.now().isoformat(),
        description=description,
        tags=tags.split(',') if tags else [],
        related_entity_type=entity_type,
        related_entity_id=entity_id,
        file_path=str(file_path),
        is_public=entity_type in ['manual', 'safety']
    )
    
    # Save metadata
    files_db.append(metadata.dict())
    
    logger.info(f"File uploaded: {file.filename} -> {safe_filename} for {entity_type} {entity_id}")
    
    return {
        "status": "success",
        "file_id": file_id,
        "filename": safe_filename,
        "original_filename": file.filename,
        "file_size": len(content),
        "category": category,
        "message": "File uploaded successfully"
    }

@file_router.get("/download/{file_id}")
async def download_file(file_id: str):
    """Download a file by ID"""
    file_metadata = next((f for f in files_db if f['id'] == file_id), None)
    if not file_metadata:
        raise HTTPException(status_code=404, detail="File not found")
    
    file_path = Path(file_metadata['file_path'])
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found on disk")
    
    return FileResponse(
        path=file_path,
        filename=file_metadata['original_filename'],
        media_type=file_metadata['mime_type']
    )

@file_router.get("/view/{file_id}")
async def view_file(file_id: str):
    """View a file (for images, PDFs, etc.)"""
    file_metadata = next((f for f in files_db if f['id'] == file_id), None)
    if not file_metadata:
        raise HTTPException(status_code=404, detail="File not found")
    
    file_path = Path(file_metadata['file_path'])
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found on disk")
    
    return FileResponse(
        path=file_path,
        media_type=file_metadata['mime_type']
    )

@file_router.get("/list")
async def list_files(
    entity_type: Optional[str] = Query(None),
    entity_id: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    limit: int = Query(50, le=100)
):
    """List files with optional filtering"""
    filtered_files = files_db
    
    if entity_type:
        filtered_files = [f for f in filtered_files if f['related_entity_type'] == entity_type]
    
    if entity_id:
        filtered_files = [f for f in filtered_files if f['related_entity_id'] == entity_id]
    
    if category:
        filtered_files = [f for f in filtered_files if f['category'] == category]
    
    # Sort by upload date (newest first)
    filtered_files.sort(key=lambda x: x['upload_date'], reverse=True)
    
    return {
        "files": filtered_files[:limit],
        "total": len(filtered_files),
        "entity_type": entity_type,
        "entity_id": entity_id,
        "category": category
    }

@file_router.delete("/{file_id}")
async def delete_file(file_id: str):
    """Delete a file"""
    file_metadata = next((f for f in files_db if f['id'] == file_id), None)
    if not file_metadata:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Delete file from disk
    file_path = Path(file_metadata['file_path'])
    try:
        if file_path.exists():
            file_path.unlink()
    except Exception as e:
        logger.error(f"Error deleting file from disk: {e}")
    
    # Remove from database
    files_db[:] = [f for f in files_db if f['id'] != file_id]
    
    return {"status": "success", "message": "File deleted successfully"}

@file_router.get("/gallery", response_class=HTMLResponse)
async def file_gallery():
    """File gallery and management interface"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>File Gallery - ChatterFix CMMS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
            }
            
            .header {
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                padding: 1.5rem 2rem;
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
                color: white;
                text-align: center;
            }
            
            .header h1 {
                font-size: 2rem;
                font-weight: 600;
                margin-bottom: 0.5rem;
            }
            
            .container {
                max-width: 1400px;
                margin: 0 auto;
                padding: 2rem;
            }
            
            .upload-section {
                background: rgba(255, 255, 255, 0.95);
                border-radius: 16px;
                padding: 2rem;
                margin-bottom: 2rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            }
            
            .upload-zone {
                border: 2px dashed #cbd5e0;
                border-radius: 12px;
                padding: 3rem;
                text-align: center;
                transition: all 0.3s ease;
                cursor: pointer;
            }
            
            .upload-zone:hover {
                border-color: #4299e1;
                background: #f7fafc;
            }
            
            .upload-zone.dragover {
                border-color: #3182ce;
                background: #ebf8ff;
            }
            
            .upload-icon {
                font-size: 4rem;
                color: #a0aec0;
                margin-bottom: 1rem;
            }
            
            .upload-text {
                font-size: 1.2rem;
                color: #4a5568;
                margin-bottom: 0.5rem;
            }
            
            .upload-subtext {
                font-size: 0.9rem;
                color: #718096;
            }
            
            .form-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
                margin-top: 1.5rem;
            }
            
            .form-group {
                display: flex;
                flex-direction: column;
            }
            
            .form-group label {
                font-weight: 600;
                margin-bottom: 0.5rem;
                color: #374151;
            }
            
            .form-group input,
            .form-group select,
            .form-group textarea {
                padding: 0.75rem;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 0.9rem;
            }
            
            .btn {
                padding: 0.75rem 1.5rem;
                border: none;
                border-radius: 6px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s ease;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 0.5rem;
                justify-content: center;
            }
            
            .btn-primary {
                background: #3b82f6;
                color: white;
            }
            
            .btn-primary:hover {
                background: #2563eb;
            }
            
            .btn-success {
                background: #10b981;
                color: white;
            }
            
            .btn-danger {
                background: #ef4444;
                color: white;
            }
            
            .files-section {
                background: rgba(255, 255, 255, 0.95);
                border-radius: 16px;
                padding: 2rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            }
            
            .filter-bar {
                display: flex;
                gap: 1rem;
                margin-bottom: 2rem;
                flex-wrap: wrap;
                align-items: center;
            }
            
            .files-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                gap: 1.5rem;
            }
            
            .file-card {
                background: white;
                border-radius: 12px;
                padding: 1.5rem;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
            }
            
            .file-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
            }
            
            .file-preview {
                width: 100%;
                height: 150px;
                background: #f8fafc;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 1rem;
                overflow: hidden;
            }
            
            .file-preview img {
                max-width: 100%;
                max-height: 100%;
                object-fit: cover;
                border-radius: 8px;
            }
            
            .file-icon {
                font-size: 3rem;
                color: #a0aec0;
            }
            
            .file-info {
                margin-bottom: 1rem;
            }
            
            .file-name {
                font-weight: 600;
                color: #1f2937;
                margin-bottom: 0.25rem;
                word-break: break-word;
            }
            
            .file-meta {
                font-size: 0.8rem;
                color: #6b7280;
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }
            
            .file-tag {
                background: #e0e7ff;
                color: #3730a3;
                padding: 0.2rem 0.5rem;
                border-radius: 4px;
                font-size: 0.7rem;
                font-weight: 500;
            }
            
            .file-actions {
                display: flex;
                gap: 0.5rem;
                flex-wrap: wrap;
            }
            
            .progress-bar {
                width: 100%;
                height: 4px;
                background: #e5e7eb;
                border-radius: 2px;
                overflow: hidden;
                margin-top: 1rem;
                display: none;
            }
            
            .progress-fill {
                height: 100%;
                background: #3b82f6;
                width: 0%;
                transition: width 0.3s ease;
            }
            
            @media (max-width: 768px) {
                .container {
                    padding: 1rem;
                }
                
                .form-grid {
                    grid-template-columns: 1fr;
                }
                
                .filter-bar {
                    flex-direction: column;
                    align-items: stretch;
                }
                
                .files-grid {
                    grid-template-columns: 1fr;
                }
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📁 File Gallery & Management</h1>
            <p>Upload and manage files for work orders, parts, assets, and manuals</p>
        </div>
        
        <div class="container">
            <!-- Upload Section -->
            <div class="upload-section">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">📤 Upload Files</h2>
                
                <div class="upload-zone" onclick="document.getElementById('fileInput').click()">
                    <div class="upload-icon">📄</div>
                    <div class="upload-text">Click to upload or drag and drop</div>
                    <div class="upload-subtext">Support for images, documents, videos, and more (max 50MB)</div>
                </div>
                
                <input type="file" id="fileInput" style="display: none;" multiple accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip,.rar">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Entity Type</label>
                        <select id="entityType" required>
                            <option value="">Select Type</option>
                            <option value="work_order">Work Order</option>
                            <option value="part">Part</option>
                            <option value="asset">Asset</option>
                            <option value="manual">Manual/Documentation</option>
                            <option value="safety">Safety Document</option>
                            <option value="maintenance">Maintenance Record</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Entity ID</label>
                        <input type="text" id="entityId" placeholder="e.g., WO-001, AST-001, PRT-001" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <input type="text" id="description" placeholder="Brief description of the file">
                    </div>
                    <div class="form-group">
                        <label>Tags (comma-separated)</label>
                        <input type="text" id="tags" placeholder="repair, manual, inspection">
                    </div>
                </div>
                
                <div style="margin-top: 1.5rem; text-align: right;">
                    <button class="btn btn-primary" onclick="uploadFiles()">
                        📤 Upload Files
                    </button>
                </div>
                
                <div class="progress-bar" id="progressBar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
            </div>
            
            <!-- Files Section -->
            <div class="files-section">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">📋 File Library</h2>
                
                <!-- Filter Bar -->
                <div class="filter-bar">
                    <div class="form-group" style="min-width: 150px;">
                        <label>Filter by Type</label>
                        <select id="filterType" onchange="loadFiles()">
                            <option value="">All Types</option>
                            <option value="work_order">Work Orders</option>
                            <option value="part">Parts</option>
                            <option value="asset">Assets</option>
                            <option value="manual">Manuals</option>
                            <option value="safety">Safety</option>
                            <option value="maintenance">Maintenance</option>
                        </select>
                    </div>
                    <div class="form-group" style="min-width: 150px;">
                        <label>Category</label>
                        <select id="filterCategory" onchange="loadFiles()">
                            <option value="">All Categories</option>
                            <option value="images">Images</option>
                            <option value="documents">Documents</option>
                            <option value="videos">Videos</option>
                            <option value="audio">Audio</option>
                            <option value="archives">Archives</option>
                            <option value="cad">CAD Files</option>
                        </select>
                    </div>
                    <div class="form-group" style="flex: 1;">
                        <label>Entity ID</label>
                        <input type="text" id="filterEntityId" placeholder="Filter by entity ID..." onkeyup="loadFiles()">
                    </div>
                    <div style="display: flex; align-items: end; gap: 0.5rem;">
                        <button class="btn btn-primary" onclick="loadFiles()">
                            🔄 Refresh
                        </button>
                    </div>
                </div>
                
                <!-- Files Grid -->
                <div class="files-grid" id="filesGrid">
                    <div style="text-align: center; color: #6b7280; padding: 2rem;">
                        Loading files...
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            let selectedFiles = [];
            
            // File input handling
            document.getElementById('fileInput').addEventListener('change', function(e) {
                selectedFiles = Array.from(e.target.files);
                updateUploadZone();
            });
            
            // Drag and drop
            const uploadZone = document.querySelector('.upload-zone');
            
            uploadZone.addEventListener('dragover', function(e) {
                e.preventDefault();
                uploadZone.classList.add('dragover');
            });
            
            uploadZone.addEventListener('dragleave', function(e) {
                e.preventDefault();
                uploadZone.classList.remove('dragover');
            });
            
            uploadZone.addEventListener('drop', function(e) {
                e.preventDefault();
                uploadZone.classList.remove('dragover');
                selectedFiles = Array.from(e.dataTransfer.files);
                updateUploadZone();
            });
            
            function updateUploadZone() {
                const uploadZone = document.querySelector('.upload-zone');
                if (selectedFiles.length > 0) {
                    uploadZone.innerHTML = `
                        <div class="upload-icon">📁</div>
                        <div class="upload-text">${selectedFiles.length} file(s) selected</div>
                        <div class="upload-subtext">${selectedFiles.map(f => f.name).join(', ')}</div>
                    `;
                }
            }
            
            async function uploadFiles() {
                if (selectedFiles.length === 0) {
                    alert('Please select files to upload');
                    return;
                }
                
                const entityType = document.getElementById('entityType').value;
                const entityId = document.getElementById('entityId').value;
                
                if (!entityType || !entityId) {
                    alert('Please select entity type and provide entity ID');
                    return;
                }
                
                const description = document.getElementById('description').value;
                const tags = document.getElementById('tags').value;
                
                const progressBar = document.getElementById('progressBar');
                const progressFill = document.getElementById('progressFill');
                
                progressBar.style.display = 'block';
                
                let uploadedCount = 0;
                const totalFiles = selectedFiles.length;
                
                for (const file of selectedFiles) {
                    const formData = new FormData();
                    formData.append('file', file);
                    formData.append('entity_type', entityType);
                    formData.append('entity_id', entityId);
                    formData.append('description', description);
                    formData.append('tags', tags);
                    formData.append('uploaded_by', 'user');
                    
                    try {
                        const response = await fetch('/cmms/files/upload', {
                            method: 'POST',
                            body: formData
                        });
                        
                        const result = await response.json();
                        
                        if (response.ok) {
                            uploadedCount++;
                            const progress = (uploadedCount / totalFiles) * 100;
                            progressFill.style.width = progress + '%';
                        } else {
                            console.error('Upload failed:', result);
                        }
                    } catch (error) {
                        console.error('Upload error:', error);
                    }
                }
                
                // Reset form
                selectedFiles = [];
                document.getElementById('fileInput').value = '';
                document.getElementById('description').value = '';
                document.getElementById('tags').value = '';
                
                // Reset upload zone
                uploadZone.innerHTML = `
                    <div class="upload-icon">📄</div>
                    <div class="upload-text">Click to upload or drag and drop</div>
                    <div class="upload-subtext">Support for images, documents, videos, and more (max 50MB)</div>
                `;
                
                setTimeout(() => {
                    progressBar.style.display = 'none';
                    progressFill.style.width = '0%';
                }, 2000);
                
                showNotification(`Successfully uploaded ${uploadedCount} files`, 'success');
                loadFiles();
            }
            
            async function loadFiles() {
                const filterType = document.getElementById('filterType').value;
                const filterCategory = document.getElementById('filterCategory').value;
                const filterEntityId = document.getElementById('filterEntityId').value;
                
                const params = new URLSearchParams();
                if (filterType) params.append('entity_type', filterType);
                if (filterCategory) params.append('category', filterCategory);
                if (filterEntityId) params.append('entity_id', filterEntityId);
                params.append('limit', '50');
                
                try {
                    const response = await fetch(`/cmms/files/list?${params}`);
                    const data = await response.json();
                    
                    renderFiles(data.files);
                } catch (error) {
                    console.error('Error loading files:', error);
                    document.getElementById('filesGrid').innerHTML = 
                        '<div style="text-align: center; color: #ef4444; padding: 2rem;">Error loading files</div>';
                }
            }
            
            function renderFiles(files) {
                const grid = document.getElementById('filesGrid');
                
                if (files.length === 0) {
                    grid.innerHTML = '<div style="text-align: center; color: #6b7280; padding: 2rem;">No files found</div>';
                    return;
                }
                
                grid.innerHTML = files.map(file => {
                    const fileIcon = getFileIcon(file.category);
                    const fileSize = formatFileSize(file.file_size);
                    const uploadDate = new Date(file.upload_date).toLocaleDateString();
                    
                    return `
                        <div class="file-card">
                            <div class="file-preview">
                                ${file.category === 'images' ? 
                                    `<img src="/cmms/files/view/${file.id}" alt="${file.original_filename}" onerror="this.style.display='none'">` :
                                    `<div class="file-icon">${fileIcon}</div>`
                                }
                            </div>
                            <div class="file-info">
                                <div class="file-name">${file.original_filename}</div>
                                <div class="file-meta">
                                    <span>${file.related_entity_type}: ${file.related_entity_id}</span>
                                    <span>${fileSize}</span>
                                    <span>${uploadDate}</span>
                                </div>
                                ${file.description ? `<div style="margin-top: 0.5rem; font-size: 0.8rem; color: #4b5563;">${file.description}</div>` : ''}
                                ${file.tags.length > 0 ? `
                                    <div style="margin-top: 0.5rem;">
                                        ${file.tags.map(tag => `<span class="file-tag">${tag}</span>`).join(' ')}
                                    </div>
                                ` : ''}
                            </div>
                            <div class="file-actions">
                                <button class="btn btn-primary" onclick="viewFile('${file.id}')">
                                    👁️ View
                                </button>
                                <button class="btn btn-success" onclick="downloadFile('${file.id}')">
                                    ⬇️ Download
                                </button>
                                <button class="btn btn-danger" onclick="deleteFile('${file.id}')">
                                    🗑️ Delete
                                </button>
                            </div>
                        </div>
                    `;
                }).join('');
            }
            
            function getFileIcon(category) {
                const icons = {
                    'images': '🖼️',
                    'documents': '📄',
                    'spreadsheets': '📊',
                    'videos': '🎥',
                    'audio': '🎵',
                    'archives': '📦',
                    'cad': '📐',
                    'other': '📁'
                };
                return icons[category] || '📁';
            }
            
            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            }
            
            function viewFile(fileId) {
                window.open(`/cmms/files/view/${fileId}`, '_blank');
            }
            
            function downloadFile(fileId) {
                window.open(`/cmms/files/download/${fileId}`, '_blank');
            }
            
            async function deleteFile(fileId) {
                if (!confirm('Are you sure you want to delete this file?')) {
                    return;
                }
                
                try {
                    const response = await fetch(`/cmms/files/${fileId}`, {
                        method: 'DELETE'
                    });
                    
                    if (response.ok) {
                        showNotification('File deleted successfully', 'success');
                        loadFiles();
                    } else {
                        showNotification('Error deleting file', 'error');
                    }
                } catch (error) {
                    console.error('Delete error:', error);
                    showNotification('Error deleting file', 'error');
                }
            }
            
            function showNotification(message, type = 'info') {
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 2rem;
                    right: 2rem;
                    background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
                    color: white;
                    padding: 1rem 1.5rem;
                    border-radius: 8px;
                    z-index: 3000;
                    font-weight: 500;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                `;
                notification.textContent = message;
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 3000);
            }
            
            // Initialize
            document.addEventListener('DOMContentLoaded', function() {
                loadFiles();
            });
        </script>
    </body>
    </html>
    """

# Initialize upload directories on module load
ensure_upload_directories()