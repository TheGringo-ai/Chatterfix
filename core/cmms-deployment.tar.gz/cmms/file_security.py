#!/usr/bin/env python3
"""
ChatterFix CMMS - File Upload Security Module
Comprehensive file validation, MIME type checking, and upload sanitization
"""

import os
import hashlib
import magic
import tempfile
import secrets
from typing import Dict, List, Optional, Set, Tuple, BinaryIO
from pathlib import Path
from datetime import datetime, timezone
import subprocess
from fastapi import UploadFile, HTTPException, status
from pydantic import BaseModel

# =============================================================================
# Configuration
# =============================================================================

# Allowed file types by category
ALLOWED_MIME_TYPES: Dict[str, Set[str]] = {
    "images": {
        "image/jpeg",
        "image/png", 
        "image/gif",
        "image/webp",
        "image/svg+xml"
    },
    "documents": {
        "application/pdf",
        "text/plain",
        "text/csv",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    },
    "technical": {
        "application/json",
        "application/xml",
        "text/xml",
        "application/zip"
    }
}

# File size limits (in bytes)
MAX_FILE_SIZE = {
    "images": 10 * 1024 * 1024,      # 10MB
    "documents": 25 * 1024 * 1024,   # 25MB
    "technical": 50 * 1024 * 1024    # 50MB
}

# Dangerous file extensions (always blocked)
DANGEROUS_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".com", ".scr", ".pif", 
    ".vbs", ".vbe", ".js", ".jse", ".ws", ".wsf", 
    ".wsc", ".wsh", ".ps1", ".ps1xml", ".ps2", 
    ".ps2xml", ".psc1", ".psc2", ".msh", ".msh1", 
    ".msh2", ".mshxml", ".msh1xml", ".msh2xml",
    ".scf", ".lnk", ".inf", ".reg"
}

# Upload directory configuration
UPLOAD_BASE_DIR = os.getenv("UPLOAD_DIR", "./uploads")
QUARANTINE_DIR = os.getenv("QUARANTINE_DIR", "./quarantine")

# =============================================================================
# Data Models
# =============================================================================

class FileValidationResult(BaseModel):
    is_valid: bool
    file_id: str
    original_filename: str
    sanitized_filename: str
    mime_type: str
    file_size: int
    category: Optional[str]
    sha256_hash: str
    validation_errors: List[str]
    security_warnings: List[str]
    quarantined: bool = False

class FileUploadConfig(BaseModel):
    allowed_categories: List[str] = ["images", "documents", "technical"]
    max_files_per_request: int = 10
    enable_virus_scan: bool = False
    quarantine_suspicious: bool = True
    require_hash_verification: bool = True

class UploadSession(BaseModel):
    session_id: str
    user_id: str
    timestamp: datetime
    files: List[FileValidationResult]
    total_size: int
    status: str  # "pending", "completed", "failed"

# =============================================================================
# File Validation Functions
# =============================================================================

def initialize_upload_directories():
    """Initialize required upload directories"""
    for directory in [UPLOAD_BASE_DIR, QUARANTINE_DIR]:
        Path(directory).mkdir(parents=True, exist_ok=True)
        
        # Set secure permissions (owner read/write only)
        os.chmod(directory, 0o700)

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename to prevent directory traversal and other attacks
    """
    # Remove any path components
    filename = os.path.basename(filename)
    
    # Remove or replace dangerous characters
    dangerous_chars = ['<', '>', ':', '"', '|', '?', '*', '\\', '/', '\0']
    for char in dangerous_chars:
        filename = filename.replace(char, '_')
    
    # Remove leading/trailing dots and spaces
    filename = filename.strip(' .')
    
    # Ensure filename isn't empty
    if not filename:
        filename = "unnamed_file"
    
    # Limit filename length
    if len(filename) > 255:
        name, ext = os.path.splitext(filename)
        filename = name[:250] + ext
    
    # Add timestamp prefix to avoid collisions
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{timestamp}_{filename}"
    
    return filename

def detect_mime_type(file_content: bytes, filename: str) -> Tuple[str, List[str]]:
    """
    Detect MIME type using multiple methods for accuracy
    """
    warnings = []
    
    try:
        # Use python-magic for content-based detection
        detected_mime = magic.from_buffer(file_content, mime=True)
        
        # Compare with extension-based expectation
        extension = Path(filename).suffix.lower()
        expected_mimes = {
            '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
            '.png': 'image/png', '.gif': 'image/gif',
            '.pdf': 'application/pdf', '.txt': 'text/plain',
            '.csv': 'text/csv', '.json': 'application/json',
            '.xml': 'application/xml', '.zip': 'application/zip'
        }
        
        expected_mime = expected_mimes.get(extension)
        
        # Check for MIME type mismatch (potential file type spoofing)
        if expected_mime and expected_mime != detected_mime:
            warnings.append(f"MIME type mismatch: extension suggests {expected_mime}, content is {detected_mime}")
        
        return detected_mime, warnings
        
    except Exception as e:
        warnings.append(f"MIME type detection failed: {str(e)}")
        return "application/octet-stream", warnings

def calculate_file_hash(file_content: bytes) -> str:
    """Calculate SHA-256 hash of file content"""
    return hashlib.sha256(file_content).hexdigest()

def check_file_signature(file_content: bytes, expected_mime: str) -> List[str]:
    """
    Check file signature (magic bytes) against expected MIME type
    """
    warnings = []
    
    # Common file signatures
    signatures = {
        'image/jpeg': [b'\xff\xd8\xff'],
        'image/png': [b'\x89\x50\x4e\x47'],
        'image/gif': [b'\x47\x49\x46\x38'],
        'application/pdf': [b'\x25\x50\x44\x46'],
        'application/zip': [b'\x50\x4b\x03\x04', b'\x50\x4b\x05\x06']
    }
    
    expected_sigs = signatures.get(expected_mime, [])
    
    if expected_sigs:
        file_start = file_content[:10]  # Check first 10 bytes
        signature_match = any(file_start.startswith(sig) for sig in expected_sigs)
        
        if not signature_match:
            warnings.append(f"File signature doesn't match expected MIME type {expected_mime}")
    
    return warnings

def scan_for_embedded_threats(file_content: bytes, mime_type: str) -> List[str]:
    """
    Basic scan for embedded threats in files
    """
    threats = []
    
    # Check for suspicious patterns
    suspicious_patterns = [
        b'<script',
        b'javascript:',
        b'vbscript:',
        b'onload=',
        b'onerror=',
        b'eval(',
        b'exec(',
        b'system(',
        b'shell_exec'
    ]
    
    content_lower = file_content.lower()
    
    for pattern in suspicious_patterns:
        if pattern in content_lower:
            threats.append(f"Suspicious pattern found: {pattern.decode('utf-8', errors='ignore')}")
    
    # Additional checks for specific MIME types
    if mime_type == 'image/svg+xml':
        # SVG files can contain JavaScript
        if b'<script' in content_lower or b'javascript:' in content_lower:
            threats.append("SVG contains potentially malicious JavaScript")
    
    if mime_type in ['application/xml', 'text/xml']:
        # Check for XML external entity (XXE) attacks
        if b'<!entity' in content_lower and b'system' in content_lower:
            threats.append("XML contains potential XXE attack vector")
    
    return threats

def get_file_category(mime_type: str) -> Optional[str]:
    """Determine file category based on MIME type"""
    for category, mime_types in ALLOWED_MIME_TYPES.items():
        if mime_type in mime_types:
            return category
    return None

def run_antivirus_scan(file_path: str) -> Tuple[bool, List[str]]:
    """
    Run antivirus scan if available (ClamAV integration)
    """
    try:
        # Check if ClamAV is available
        result = subprocess.run(
            ["clamscan", "--version"], 
            capture_output=True, 
            text=True, 
            timeout=5
        )
        
        if result.returncode != 0:
            return True, ["Antivirus not available - skipping scan"]
        
        # Run actual scan
        scan_result = subprocess.run(
            ["clamscan", "--no-summary", file_path],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if scan_result.returncode == 0:
            return True, ["File clean - no threats detected"]
        else:
            threats = [line.strip() for line in scan_result.stdout.split('\n') if 'FOUND' in line]
            return False, threats or ["Antivirus scan failed"]
            
    except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
        return True, ["Antivirus scan unavailable or timed out"]

# =============================================================================
# Main Validation Functions
# =============================================================================

async def validate_upload_file(
    file: UploadFile, 
    config: FileUploadConfig,
    user_id: str
) -> FileValidationResult:
    """
    Comprehensive file upload validation
    """
    validation_errors = []
    security_warnings = []
    quarantined = False
    
    try:
        # Read file content
        file_content = await file.read()
        file_size = len(file_content)
        
        # Generate file ID and sanitize filename
        file_id = secrets.token_urlsafe(16)
        sanitized_filename = sanitize_filename(file.filename or "unknown")
        
        # Calculate hash
        file_hash = calculate_file_hash(file_content)
        
        # Detect MIME type
        detected_mime, mime_warnings = detect_mime_type(file_content, file.filename or "")
        security_warnings.extend(mime_warnings)
        
        # Get file category
        file_category = get_file_category(detected_mime)
        
        # Validation checks
        
        # 1. Check if file category is allowed
        if not file_category:
            validation_errors.append(f"File type not allowed: {detected_mime}")
        elif file_category not in config.allowed_categories:
            validation_errors.append(f"File category not allowed: {file_category}")
        
        # 2. Check file size
        max_size = MAX_FILE_SIZE.get(file_category, 1024*1024)  # 1MB default
        if file_size > max_size:
            validation_errors.append(f"File too large: {file_size} bytes (max: {max_size})")
        
        # 3. Check for dangerous extensions
        file_ext = Path(sanitized_filename).suffix.lower()
        if file_ext in DANGEROUS_EXTENSIONS:
            validation_errors.append(f"Dangerous file extension: {file_ext}")
            quarantined = True
        
        # 4. Check file signature
        signature_warnings = check_file_signature(file_content, detected_mime)
        security_warnings.extend(signature_warnings)
        
        # 5. Scan for embedded threats
        threat_warnings = scan_for_embedded_threats(file_content, detected_mime)
        security_warnings.extend(threat_warnings)
        
        # 6. Additional security checks
        if file_size == 0:
            validation_errors.append("Empty file not allowed")
        
        if len(file_content) != file_size:
            validation_errors.append("File size mismatch during upload")
        
        # Determine if file should be quarantined
        if (security_warnings and config.quarantine_suspicious) or quarantined:
            quarantined = True
            save_directory = QUARANTINE_DIR
        else:
            save_directory = UPLOAD_BASE_DIR
        
        # Save file if validation passes or quarantining
        file_path = None
        if not validation_errors or quarantined:
            safe_subdir = f"{file_category or 'unknown'}/{user_id}"
            full_save_dir = Path(save_directory) / safe_subdir
            full_save_dir.mkdir(parents=True, exist_ok=True)
            
            file_path = full_save_dir / sanitized_filename
            
            with open(file_path, 'wb') as f:
                f.write(file_content)
            
            # Set secure file permissions
            os.chmod(file_path, 0o600)
            
            # Run antivirus scan if enabled and file is not quarantined
            if config.enable_virus_scan and not quarantined:
                av_clean, av_results = run_antivirus_scan(str(file_path))
                if not av_clean:
                    security_warnings.extend(av_results)
                    quarantined = True
                    
                    # Move to quarantine
                    quarantine_path = Path(QUARANTINE_DIR) / safe_subdir / sanitized_filename
                    quarantine_path.parent.mkdir(parents=True, exist_ok=True)
                    file_path.rename(quarantine_path)
                    file_path = quarantine_path
        
        # Create validation result
        result = FileValidationResult(
            is_valid=(len(validation_errors) == 0),
            file_id=file_id,
            original_filename=file.filename or "unknown",
            sanitized_filename=sanitized_filename,
            mime_type=detected_mime,
            file_size=file_size,
            category=file_category,
            sha256_hash=file_hash,
            validation_errors=validation_errors,
            security_warnings=security_warnings,
            quarantined=quarantined
        )
        
        return result
        
    except Exception as e:
        return FileValidationResult(
            is_valid=False,
            file_id=secrets.token_urlsafe(8),
            original_filename=file.filename or "unknown",
            sanitized_filename="validation_failed",
            mime_type="unknown/error",
            file_size=0,
            category=None,
            sha256_hash="",
            validation_errors=[f"Validation failed: {str(e)}"],
            security_warnings=[],
            quarantined=True
        )

def create_upload_session(user_id: str) -> str:
    """Create a new upload session"""
    session_id = secrets.token_urlsafe(16)
    # In production, this would be stored in database
    return session_id

def get_upload_stats() -> Dict:
    """Get upload system statistics"""
    try:
        upload_dir = Path(UPLOAD_BASE_DIR)
        quarantine_dir = Path(QUARANTINE_DIR)
        
        upload_files = list(upload_dir.rglob("*")) if upload_dir.exists() else []
        quarantine_files = list(quarantine_dir.rglob("*")) if quarantine_dir.exists() else []
        
        upload_size = sum(f.stat().st_size for f in upload_files if f.is_file())
        quarantine_size = sum(f.stat().st_size for f in quarantine_files if f.is_file())
        
        return {
            "total_files": len([f for f in upload_files if f.is_file()]),
            "quarantined_files": len([f for f in quarantine_files if f.is_file()]),
            "total_storage_mb": round(upload_size / (1024*1024), 2),
            "quarantine_storage_mb": round(quarantine_size / (1024*1024), 2),
            "upload_directories": str(upload_dir),
            "quarantine_directory": str(quarantine_dir)
        }
    except Exception:
        return {"error": "Unable to retrieve upload statistics"}

# Initialize directories on import
initialize_upload_directories()