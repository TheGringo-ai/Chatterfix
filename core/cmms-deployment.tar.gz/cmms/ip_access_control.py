#!/usr/bin/env python3
"""
ChatterFix CMMS - IP Access Control Module
Advanced IP allowlisting, geolocation blocking, and access controls
"""

import os
import ipaddress
import json
import time
from typing import Dict, List, Optional, Set, Tuple, Union
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, asdict
from pathlib import Path
import asyncio
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
import secrets

# =============================================================================
# Configuration
# =============================================================================

# IP Access Control Configuration
ENABLE_IP_ALLOWLIST = os.getenv("ENABLE_IP_ALLOWLIST", "false").lower() == "true"
ENABLE_GEO_BLOCKING = os.getenv("ENABLE_GEO_BLOCKING", "false").lower() == "true"
ALLOWLIST_FILE = os.getenv("IP_ALLOWLIST_FILE", "./config/ip_allowlist.json")
BLOCKLIST_FILE = os.getenv("IP_BLOCKLIST_FILE", "./config/ip_blocklist.json")

# Default allowed IP ranges (private networks and localhost)
DEFAULT_ALLOWED_IPS = [
    "127.0.0.0/8",      # Loopback
    "10.0.0.0/8",       # Private Class A
    "172.16.0.0/12",    # Private Class B
    "192.168.0.0/16",   # Private Class C
    "::1/128",          # IPv6 loopback
    "fc00::/7"          # IPv6 private
]

# Countries to block (ISO 3166-1 alpha-2 codes)
BLOCKED_COUNTRIES = os.getenv("BLOCKED_COUNTRIES", "").split(",") if os.getenv("BLOCKED_COUNTRIES") else []

# Rate limiting for blocked IPs
BLOCKED_IP_CACHE_DURATION = 3600  # 1 hour

# =============================================================================
# Data Models
# =============================================================================

@dataclass
class IPAccessRule:
    """IP access rule definition"""
    ip_range: str               # IP address or CIDR range
    rule_type: str             # "allow", "block", "monitor"
    description: str           # Human readable description
    created_by: str            # User who created the rule
    created_at: datetime       # When rule was created
    expires_at: Optional[datetime] = None  # Optional expiration
    priority: int = 0          # Rule priority (higher = more important)
    tags: List[str] = None     # Tags for organization

@dataclass
class AccessAttempt:
    """Record of access attempt"""
    ip_address: str
    user_agent: str
    endpoint: str
    method: str
    timestamp: datetime
    allowed: bool
    rule_matched: Optional[str]
    geolocation: Optional[Dict] = None
    user_id: Optional[str] = None
    request_id: str = ""

@dataclass
class GeolocationInfo:
    """Geolocation information for IP"""
    country_code: str
    country_name: str
    city: Optional[str] = None
    region: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    organization: Optional[str] = None

# =============================================================================
# IP Access Control Core
# =============================================================================

class IPAccessController:
    """Advanced IP access control system"""
    
    def __init__(self):
        self.allowlist_rules: List[IPAccessRule] = []
        self.blocklist_rules: List[IPAccessRule] = []
        self.access_attempts: List[AccessAttempt] = []
        self.blocked_ip_cache: Dict[str, float] = {}  # IP -> timestamp
        self.geoip_cache: Dict[str, GeolocationInfo] = {}  # IP -> geo info
        
        # Ensure config directory exists
        config_dir = Path("./config")
        config_dir.mkdir(exist_ok=True)
        
        # Load existing rules
        self._load_rules()
        
        # Add default rules if none exist
        if not self.allowlist_rules:
            self._create_default_rules()
    
    def _load_rules(self):
        """Load IP access rules from files"""
        try:
            # Load allowlist
            allowlist_path = Path(ALLOWLIST_FILE)
            if allowlist_path.exists():
                with open(allowlist_path, 'r') as f:
                    data = json.load(f)
                    for rule_data in data.get('rules', []):
                        rule = IPAccessRule(
                            ip_range=rule_data['ip_range'],
                            rule_type=rule_data['rule_type'],
                            description=rule_data['description'],
                            created_by=rule_data['created_by'],
                            created_at=datetime.fromisoformat(rule_data['created_at']),
                            expires_at=datetime.fromisoformat(rule_data['expires_at']) if rule_data.get('expires_at') else None,
                            priority=rule_data.get('priority', 0),
                            tags=rule_data.get('tags', [])
                        )
                        self.allowlist_rules.append(rule)
            
            # Load blocklist
            blocklist_path = Path(BLOCKLIST_FILE)
            if blocklist_path.exists():
                with open(blocklist_path, 'r') as f:
                    data = json.load(f)
                    for rule_data in data.get('rules', []):
                        rule = IPAccessRule(
                            ip_range=rule_data['ip_range'],
                            rule_type=rule_data['rule_type'],
                            description=rule_data['description'],
                            created_by=rule_data['created_by'],
                            created_at=datetime.fromisoformat(rule_data['created_at']),
                            expires_at=datetime.fromisoformat(rule_data['expires_at']) if rule_data.get('expires_at') else None,
                            priority=rule_data.get('priority', 0),
                            tags=rule_data.get('tags', [])
                        )
                        self.blocklist_rules.append(rule)
                        
        except Exception as e:
            print(f"Error loading IP access rules: {e}")
    
    def _save_rules(self):
        """Save IP access rules to files"""
        try:
            # Save allowlist
            allowlist_data = {
                "rules": [
                    {
                        "ip_range": rule.ip_range,
                        "rule_type": rule.rule_type,
                        "description": rule.description,
                        "created_by": rule.created_by,
                        "created_at": rule.created_at.isoformat(),
                        "expires_at": rule.expires_at.isoformat() if rule.expires_at else None,
                        "priority": rule.priority,
                        "tags": rule.tags or []
                    }
                    for rule in self.allowlist_rules
                ],
                "last_updated": datetime.now(timezone.utc).isoformat()
            }
            
            with open(ALLOWLIST_FILE, 'w') as f:
                json.dump(allowlist_data, f, indent=2)
            
            # Save blocklist
            blocklist_data = {
                "rules": [
                    {
                        "ip_range": rule.ip_range,
                        "rule_type": rule.rule_type,
                        "description": rule.description,
                        "created_by": rule.created_by,
                        "created_at": rule.created_at.isoformat(),
                        "expires_at": rule.expires_at.isoformat() if rule.expires_at else None,
                        "priority": rule.priority,
                        "tags": rule.tags or []
                    }
                    for rule in self.blocklist_rules
                ],
                "last_updated": datetime.now(timezone.utc).isoformat()
            }
            
            with open(BLOCKLIST_FILE, 'w') as f:
                json.dump(blocklist_data, f, indent=2)
                
        except Exception as e:
            print(f"Error saving IP access rules: {e}")
    
    def _create_default_rules(self):
        """Create default IP access rules"""
        now = datetime.now(timezone.utc)
        
        # Add default allowed IP ranges
        for ip_range in DEFAULT_ALLOWED_IPS:
            rule = IPAccessRule(
                ip_range=ip_range,
                rule_type="allow",
                description=f"Default allowed range: {ip_range}",
                created_by="system",
                created_at=now,
                priority=1,
                tags=["default", "private"]
            )
            self.allowlist_rules.append(rule)
        
        # Save the rules
        self._save_rules()
    
    def _get_client_ip(self, request: Request) -> str:
        """Extract real client IP from request"""
        # Check X-Forwarded-For header (from load balancers)
        forwarded_for = request.headers.get("x-forwarded-for")
        if forwarded_for:
            # Take the first IP (original client)
            return forwarded_for.split(",")[0].strip()
        
        # Check X-Real-IP header (from reverse proxies)
        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            return real_ip.strip()
        
        # Fallback to direct connection IP
        return request.client.host if request.client else "unknown"
    
    def _ip_matches_rule(self, ip_address: str, rule: IPAccessRule) -> bool:
        """Check if IP address matches a rule"""
        try:
            # Handle IP ranges/CIDR notation
            if "/" in rule.ip_range:
                network = ipaddress.ip_network(rule.ip_range, strict=False)
                ip_addr = ipaddress.ip_address(ip_address)
                return ip_addr in network
            else:
                # Direct IP match
                return ip_address == rule.ip_range
        except (ipaddress.AddressValueError, ValueError):
            return False
    
    def _is_rule_expired(self, rule: IPAccessRule) -> bool:
        """Check if rule has expired"""
        if not rule.expires_at:
            return False
        return datetime.now(timezone.utc) > rule.expires_at
    
    async def _get_geolocation(self, ip_address: str) -> Optional[GeolocationInfo]:
        """Get geolocation information for IP address"""
        # Check cache first
        if ip_address in self.geoip_cache:
            return self.geoip_cache[ip_address]
        
        # Skip geolocation for private IPs
        try:
            ip_addr = ipaddress.ip_address(ip_address)
            if ip_addr.is_private or ip_addr.is_loopback:
                return None
        except ipaddress.AddressValueError:
            return None
        
        # In production, this would use a real geolocation service
        # For now, return mock data for demonstration
        geo_info = GeolocationInfo(
            country_code="US",
            country_name="United States",
            city="Unknown",
            region="Unknown"
        )
        
        self.geoip_cache[ip_address] = geo_info
        return geo_info
    
    async def check_ip_access(self, request: Request) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Check if IP address is allowed access
        Returns: (allowed, rule_matched, reason)
        """
        ip_address = self._get_client_ip(request)
        
        # Check if IP is in blocked cache
        if ip_address in self.blocked_ip_cache:
            cache_time = self.blocked_ip_cache[ip_address]
            if time.time() - cache_time < BLOCKED_IP_CACHE_DURATION:
                return False, "cached_block", "IP temporarily blocked"
        
        # Get geolocation if enabled
        geo_info = None
        if ENABLE_GEO_BLOCKING:
            geo_info = await self._get_geolocation(ip_address)
            
            # Check country blocking
            if geo_info and geo_info.country_code in BLOCKED_COUNTRIES:
                return False, "geo_block", f"Country {geo_info.country_code} is blocked"
        
        # Check blocklist rules first (higher priority)
        for rule in sorted(self.blocklist_rules, key=lambda r: r.priority, reverse=True):
            if self._is_rule_expired(rule):
                continue
                
            if self._ip_matches_rule(ip_address, rule):
                # Cache the block
                self.blocked_ip_cache[ip_address] = time.time()
                return False, rule.ip_range, rule.description
        
        # If allowlist is enabled, check it
        if ENABLE_IP_ALLOWLIST:
            for rule in sorted(self.allowlist_rules, key=lambda r: r.priority, reverse=True):
                if self._is_rule_expired(rule):
                    continue
                    
                if self._ip_matches_rule(ip_address, rule):
                    return True, rule.ip_range, rule.description
            
            # If allowlist is enabled and no rule matched, deny
            return False, "allowlist", "IP not in allowlist"
        
        # If no allowlist, allow by default (but log)
        return True, None, "Default allow"
    
    async def record_access_attempt(
        self,
        request: Request,
        allowed: bool,
        rule_matched: Optional[str] = None,
        user_id: Optional[str] = None
    ):
        """Record an access attempt for auditing"""
        ip_address = self._get_client_ip(request)
        geo_info = await self._get_geolocation(ip_address)
        
        attempt = AccessAttempt(
            ip_address=ip_address,
            user_agent=request.headers.get("user-agent", "unknown"),
            endpoint=str(request.url.path),
            method=request.method,
            timestamp=datetime.now(timezone.utc),
            allowed=allowed,
            rule_matched=rule_matched,
            geolocation=asdict(geo_info) if geo_info else None,
            user_id=user_id,
            request_id=getattr(request.state, "request_id", secrets.token_urlsafe(8))
        )
        
        self.access_attempts.append(attempt)
        
        # Keep only last 1000 attempts to avoid memory bloat
        if len(self.access_attempts) > 1000:
            self.access_attempts = self.access_attempts[-1000:]
    
    def add_ip_rule(
        self,
        ip_range: str,
        rule_type: str,
        description: str,
        created_by: str,
        expires_at: Optional[datetime] = None,
        priority: int = 0,
        tags: List[str] = None
    ) -> bool:
        """Add new IP access rule"""
        try:
            # Validate IP range
            if "/" in ip_range:
                ipaddress.ip_network(ip_range, strict=False)
            else:
                ipaddress.ip_address(ip_range)
            
            rule = IPAccessRule(
                ip_range=ip_range,
                rule_type=rule_type,
                description=description,
                created_by=created_by,
                created_at=datetime.now(timezone.utc),
                expires_at=expires_at,
                priority=priority,
                tags=tags or []
            )
            
            if rule_type == "allow":
                self.allowlist_rules.append(rule)
            else:
                self.blocklist_rules.append(rule)
            
            self._save_rules()
            return True
            
        except (ipaddress.AddressValueError, ValueError):
            return False
    
    def remove_ip_rule(self, ip_range: str, rule_type: str) -> bool:
        """Remove IP access rule"""
        if rule_type == "allow":
            rule_list = self.allowlist_rules
        else:
            rule_list = self.blocklist_rules
        
        for i, rule in enumerate(rule_list):
            if rule.ip_range == ip_range:
                rule_list.pop(i)
                self._save_rules()
                return True
        
        return False
    
    def get_access_stats(self) -> Dict:
        """Get access control statistics"""
        now = datetime.now(timezone.utc)
        last_hour = now - timedelta(hours=1)
        last_day = now - timedelta(days=1)
        
        # Filter attempts
        recent_attempts = [a for a in self.access_attempts if a.timestamp > last_hour]
        daily_attempts = [a for a in self.access_attempts if a.timestamp > last_day]
        
        # Count by result
        recent_allowed = len([a for a in recent_attempts if a.allowed])
        recent_blocked = len([a for a in recent_attempts if not a.allowed])
        daily_allowed = len([a for a in daily_attempts if a.allowed])
        daily_blocked = len([a for a in daily_attempts if not a.allowed])
        
        # Top blocked IPs
        blocked_ips = {}
        for attempt in daily_attempts:
            if not attempt.allowed:
                blocked_ips[attempt.ip_address] = blocked_ips.get(attempt.ip_address, 0) + 1
        
        top_blocked = sorted(blocked_ips.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "allowlist_rules": len(self.allowlist_rules),
            "blocklist_rules": len(self.blocklist_rules),
            "last_hour": {
                "allowed": recent_allowed,
                "blocked": recent_blocked,
                "total": len(recent_attempts)
            },
            "last_day": {
                "allowed": daily_allowed,
                "blocked": daily_blocked,
                "total": len(daily_attempts)
            },
            "top_blocked_ips": top_blocked,
            "blocked_countries": BLOCKED_COUNTRIES,
            "allowlist_enabled": ENABLE_IP_ALLOWLIST,
            "geo_blocking_enabled": ENABLE_GEO_BLOCKING
        }
    
    def get_recent_attempts(self, limit: int = 100) -> List[Dict]:
        """Get recent access attempts"""
        recent = self.access_attempts[-limit:]
        return [asdict(attempt) for attempt in reversed(recent)]

# =============================================================================
# IP Access Control Middleware
# =============================================================================

class IPAccessControlMiddleware:
    """Middleware for IP access control"""
    
    def __init__(self, app):
        self.app = app
        self.access_controller = IPAccessController()
    
    async def __call__(self, scope, receive, send):
        """ASGI middleware call"""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        from fastapi import Request
        request = Request(scope, receive)
        
        # Check IP access
        allowed, rule_matched, reason = await self.access_controller.check_ip_access(request)
        
        # Get user ID if available
        user_id = None
        try:
            auth_header = request.headers.get("authorization")
            if auth_header and auth_header.startswith("Bearer "):
                from auth_rbac import decode_token
                token = auth_header[7:]
                token_data = decode_token(token)
                if token_data:
                    user_id = token_data.user_id
        except Exception:
            pass
        
        # Record the attempt
        await self.access_controller.record_access_attempt(
            request=request,
            allowed=allowed,
            rule_matched=rule_matched,
            user_id=user_id
        )
        
        if not allowed:
            # Access denied
            ip_address = self.access_controller._get_client_ip(request)
            
            response_body = json.dumps({
                "error": "Access denied",
                "reason": reason,
                "ip_address": ip_address,
                "rule_matched": rule_matched,
                "request_id": getattr(request.state, "request_id", secrets.token_urlsafe(8))
            }).encode()
            
            response = {
                "type": "http.response.start",
                "status": 403,
                "headers": [
                    [b"content-type", b"application/json"],
                    [b"x-access-denied", b"true"],
                    [b"x-blocked-ip", ip_address.encode()],
                    [b"x-request-id", getattr(request.state, "request_id", "unknown").encode()]
                ]
            }
            
            await send(response)
            await send({
                "type": "http.response.body",
                "body": response_body
            })
            return
        
        # Allow the request to proceed
        await self.app(scope, receive, send)

# Global IP access controller
ip_access_controller = IPAccessController()