#!/usr/bin/env python3
"""
LLaMA Platform Tester - Comprehensive End-User Testing System
Uses LLaMA to test ChatterFix CMMS as an actual end user would
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime
from typing import Dict, List, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test configuration
LLAMA_SERVER = "http://localhost:11434"
LLAMA_MODEL = "llama3.2:1b"
CHATTERFIX_BASE_URL = "http://localhost:8080"

class LLaMAEndUserTester:
    """LLaMA-powered comprehensive platform tester"""
    
    def __init__(self):
        self.test_results = {
            "frontend_tests": {},
            "backend_tests": {},
            "integration_tests": {},
            "ai_functionality_tests": {},
            "cms_functionality_tests": {},
            "user_experience_tests": {},
            "performance_tests": {},
            "overall_assessment": {}
        }
        self.session = None
        
    async def query_llama_tester(self, prompt: str, context: str = "platform_testing") -> str:
        """Query LLaMA as an end user tester"""
        try:
            system_prompt = f"""You are an experienced end user testing the ChatterFix CMMS platform. You are a maintenance manager with 15 years of experience who needs to evaluate if this system meets real-world industrial maintenance needs.

TESTING PERSPECTIVE:
- You are evaluating the platform as if you're considering it for your facility
- Test everything from a practical maintenance manager's viewpoint  
- Look for usability, functionality, integration, and real-world applicability
- Identify any issues that would prevent adoption in a production environment
- Assess if the AI provides genuinely helpful maintenance guidance
- Evaluate if all features work together as a unified system

TESTING CONTEXT: {context}

Be thorough, critical, and provide specific feedback on what works, what doesn't, and what could be improved. Focus on real maintenance workflows and user experience."""

            payload = {
                "model": LLAMA_MODEL,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "max_tokens": 800
                }
            }

            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(f"{LLAMA_SERVER}/api/chat", json=payload) as response:
                    if response.status == 200:
                        result = await response.json()
                        if "message" in result and "content" in result["message"]:
                            return result["message"]["content"]
                    return f"Tester AI unavailable (HTTP {response.status})"
        except Exception as e:
            logger.error(f"LLaMA tester error: {e}")
            return f"Testing system error: {e}"

    async def test_main_dashboard(self) -> Dict[str, Any]:
        """Test main dashboard functionality"""
        logger.info("🏠 Testing main dashboard...")
        
        try:
            async with aiohttp.ClientSession() as session:
                # Test main dashboard
                async with session.get(f"{CHATTERFIX_BASE_URL}/") as response:
                    if response.status == 200:
                        content = await response.text()
                        
                        # Have LLaMA analyze the dashboard as an end user
                        analysis_prompt = f"""I accessed the main ChatterFix CMMS dashboard and received this content (first 1000 chars):
                        
{content[:1000]}

As a maintenance manager evaluating this system, analyze:
1. Does the dashboard look professional and trustworthy?
2. Are all the modules clearly accessible?
3. Does it provide a good overview of the system capabilities?
4. Are there any obvious issues or missing elements?
5. Would this interface work well for daily use by maintenance staff?

Provide specific feedback on usability and professionalism."""

                        analysis = await self.query_llama_tester(analysis_prompt, "dashboard_evaluation")
                        
                        return {
                            "status": "success",
                            "response_code": response.status,
                            "content_length": len(content),
                            "llama_analysis": analysis,
                            "modules_found": content.count("module-card"),
                            "timestamp": datetime.now().isoformat()
                        }
                    else:
                        return {
                            "status": "failed",
                            "response_code": response.status,
                            "error": f"Dashboard returned {response.status}",
                            "timestamp": datetime.now().isoformat()
                        }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    async def test_ai_functionality(self) -> Dict[str, Any]:
        """Test AI functionality comprehensively"""
        logger.info("🤖 Testing AI functionality...")
        
        ai_test_results = {}
        
        # Test queries that should work well
        test_queries = [
            "conveyor belt vibrating excessively",
            "motor running hot and drawing high current",
            "pump cavitating and losing pressure",
            "bearing making grinding noise",
            "HVAC compressor not starting"
        ]
        
        for i, query in enumerate(test_queries):
            try:
                async with aiohttp.ClientSession() as session:
                    payload = {
                        "message": query,
                        "context": "end_user_test",
                        "user_type": "technician"
                    }
                    
                    async with session.post(
                        f"{CHATTERFIX_BASE_URL}/cmms/ai/chat",
                        json=payload,
                        headers={"Content-Type": "application/json"}
                    ) as response:
                        
                        if response.status == 200:
                            data = await response.json()
                            
                            # Have LLaMA evaluate the AI response quality
                            evaluation_prompt = f"""I asked the ChatterFix AI: "{query}"

The AI responded with: "{data.get('response', '')}"

As a maintenance manager, evaluate this response:
1. Is it technically accurate and helpful?
2. Does it provide actionable maintenance guidance?
3. Are safety considerations properly addressed?
4. Is the level of detail appropriate for a technician?
5. Would this response help solve real maintenance problems?
6. Rate the overall quality (1-10) and explain why.

Be critical - this needs to work in real industrial environments."""

                            evaluation = await self.query_llama_tester(evaluation_prompt, f"ai_response_evaluation_{i}")
                            
                            ai_test_results[f"query_{i+1}"] = {
                                "query": query,
                                "status": "success",
                                "response_length": len(data.get('response', '')),
                                "response_time": data.get('response_time', 0),
                                "model_used": data.get('model_used', ''),
                                "llama_evaluation": evaluation,
                                "raw_response": data.get('response', '')[:200] + "..."
                            }
                        else:
                            ai_test_results[f"query_{i+1}"] = {
                                "query": query,
                                "status": "failed",
                                "response_code": response.status,
                                "error": f"AI endpoint returned {response.status}"
                            }
                            
            except Exception as e:
                ai_test_results[f"query_{i+1}"] = {
                    "query": query,
                    "status": "error",
                    "error": str(e)
                }
                
        return ai_test_results

    async def test_module_navigation(self) -> Dict[str, Any]:
        """Test all module links and navigation"""
        logger.info("🧭 Testing module navigation...")
        
        modules_to_test = [
            "/cmms/dashboard/main",
            "/cmms/workorders/dashboard", 
            "/cmms/assets/dashboard",
            "/cmms/parts/dashboard",
            "/cmms/preventive/dashboard",
            "/cmms/technicians/portal",
            "/cmms/ai-enhanced/dashboard/universal",
            "/cmms/meta/dashboard",
            "/cmms/admin/dashboard"
        ]
        
        navigation_results = {}
        
        for module in modules_to_test:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"{CHATTERFIX_BASE_URL}{module}") as response:
                        content = await response.text()
                        
                        # Have LLaMA evaluate each module
                        module_name = module.split('/')[-2] if module.count('/') > 2 else module.split('/')[-1]
                        
                        evaluation_prompt = f"""I accessed the {module_name} module at {module} and got this response (status: {response.status}):

Content preview (first 500 chars): {content[:500]}

As a maintenance manager testing this module:
1. Does it load properly and look professional?
2. Is the functionality clear and usable?
3. Does it integrate well with the overall CMMS design?
4. Are there any obvious bugs or issues?
5. Would maintenance staff find this module useful?

Provide specific feedback on this module's quality and usability."""

                        evaluation = await self.query_llama_tester(evaluation_prompt, f"module_test_{module_name}")
                        
                        navigation_results[module_name] = {
                            "url": module,
                            "status": "success" if response.status == 200 else "failed",
                            "response_code": response.status,
                            "content_length": len(content),
                            "llama_evaluation": evaluation,
                            "has_navigation": "navigation" in content.lower(),
                            "has_functionality": len(content) > 1000
                        }
                        
            except Exception as e:
                navigation_results[module.split('/')[-1]] = {
                    "url": module,
                    "status": "error", 
                    "error": str(e)
                }
                
        return navigation_results

    async def test_api_endpoints(self) -> Dict[str, Any]:
        """Test backend API functionality"""
        logger.info("🔌 Testing API endpoints...")
        
        api_endpoints = [
            ("/health", "GET"),
            ("/api", "GET"),
            ("/cmms/ai/health", "GET"),
            ("/cmms/meta/metrics", "GET")
        ]
        
        api_results = {}
        
        for endpoint, method in api_endpoints:
            try:
                async with aiohttp.ClientSession() as session:
                    if method == "GET":
                        async with session.get(f"{CHATTERFIX_BASE_URL}{endpoint}") as response:
                            data = await response.json() if response.content_type == 'application/json' else await response.text()
                            
                            # Have LLaMA evaluate API response
                            evaluation_prompt = f"""I tested the API endpoint {endpoint} (GET) and received:
Status: {response.status}
Response: {str(data)[:300]}

As a technical evaluator:
1. Is this a proper API response?
2. Does it provide useful system information?
3. Is the response format appropriate?
4. Any issues or improvements needed?"""

                            evaluation = await self.query_llama_tester(evaluation_prompt, f"api_test_{endpoint.replace('/', '_')}")
                            
                            api_results[f"{method}_{endpoint}"] = {
                                "endpoint": endpoint,
                                "method": method,
                                "status": "success" if response.status == 200 else "failed",
                                "response_code": response.status,
                                "response_data": str(data)[:200] + "..." if len(str(data)) > 200 else str(data),
                                "llama_evaluation": evaluation
                            }
                            
            except Exception as e:
                api_results[f"{method}_{endpoint}"] = {
                    "endpoint": endpoint,
                    "method": method,
                    "status": "error",
                    "error": str(e)
                }
                
        return api_results

    async def test_integration_and_workflow(self) -> Dict[str, Any]:
        """Test how all components work together"""
        logger.info("🔗 Testing system integration and workflows...")
        
        # Test a complete workflow: Dashboard -> AI -> Work Orders
        workflow_results = {}
        
        try:
            async with aiohttp.ClientSession() as session:
                # Step 1: Access main dashboard
                async with session.get(f"{CHATTERFIX_BASE_URL}/") as response:
                    dashboard_success = response.status == 200
                
                # Step 2: Test AI functionality
                ai_payload = {
                    "message": "pump vibration analysis needed",
                    "context": "workflow_test",
                    "user_type": "manager"
                }
                
                async with session.post(
                    f"{CHATTERFIX_BASE_URL}/cmms/ai/chat",
                    json=ai_payload,
                    headers={"Content-Type": "application/json"}
                ) as response:
                    ai_success = response.status == 200
                    ai_data = await response.json() if ai_success else {}
                
                # Step 3: Access work orders
                async with session.get(f"{CHATTERFIX_BASE_URL}/cmms/workorders/dashboard") as response:
                    workorders_success = response.status == 200
                
                # Have LLaMA evaluate the complete workflow
                workflow_evaluation_prompt = f"""I tested a complete workflow through ChatterFix CMMS:
1. Main Dashboard: {'✅ Loaded successfully' if dashboard_success else '❌ Failed to load'}
2. AI Consultation: {'✅ AI responded properly' if ai_success else '❌ AI failed'}
   - AI Response Quality: {ai_data.get('response', 'No response')[:100]}...
3. Work Orders Module: {'✅ Accessible' if workorders_success else '❌ Not accessible'}

As a maintenance manager evaluating this complete workflow:
1. Does the system flow logically from task to task?
2. Would this support real maintenance workflows?
3. Are there any integration issues between components?
4. How would you rate the overall user experience?
5. What improvements are needed for production use?

Provide a comprehensive assessment of the integrated system."""

                integration_evaluation = await self.query_llama_tester(workflow_evaluation_prompt, "workflow_integration")
                
                workflow_results = {
                    "dashboard_test": {"status": "success" if dashboard_success else "failed"},
                    "ai_test": {"status": "success" if ai_success else "failed", "response_data": ai_data},
                    "workorders_test": {"status": "success" if workorders_success else "failed"},
                    "llama_integration_assessment": integration_evaluation,
                    "overall_workflow": "functional" if all([dashboard_success, ai_success, workorders_success]) else "issues_detected"
                }
                
        except Exception as e:
            workflow_results = {
                "status": "error",
                "error": str(e),
                "llama_assessment": f"Workflow testing failed due to technical error: {e}"
            }
            
        return workflow_results

    async def generate_final_assessment(self) -> Dict[str, Any]:
        """Generate comprehensive final assessment"""
        logger.info("📋 Generating final assessment...")
        
        # Compile all test results
        summary_prompt = f"""Based on comprehensive testing of the ChatterFix CMMS platform, here are the results:

FRONTEND TESTS: {json.dumps(self.test_results.get('frontend_tests', {}), indent=2)[:500]}...

BACKEND TESTS: {json.dumps(self.test_results.get('backend_tests', {}), indent=2)[:500]}...

AI FUNCTIONALITY: {json.dumps(self.test_results.get('ai_functionality_tests', {}), indent=2)[:500]}...

INTEGRATION TESTS: {json.dumps(self.test_results.get('integration_tests', {}), indent=2)[:500]}...

As an experienced maintenance manager who has now thoroughly tested this entire platform:

1. OVERALL SYSTEM RATING (1-10): Provide a score and detailed justification
2. PRODUCTION READINESS: Is this ready for real industrial use?
3. STRENGTHS: What are the best features and capabilities?
4. WEAKNESSES: What needs improvement or fixing?
5. DEPLOYMENT RECOMMENDATION: Should this be deployed as-is, needs minor fixes, or major work required?
6. COMPETITIVE ASSESSMENT: How does this compare to other CMMS solutions?
7. USER ADOPTION POTENTIAL: Would maintenance teams actually use this?

Provide a comprehensive final assessment that a management team could use to make deployment decisions."""

        final_assessment = await self.query_llama_tester(summary_prompt, "final_comprehensive_assessment")
        
        return {
            "timestamp": datetime.now().isoformat(),
            "testing_duration": "comprehensive",
            "total_tests_performed": len(self.test_results),
            "llama_final_assessment": final_assessment,
            "recommendation": "pending_analysis"
        }

    async def run_comprehensive_tests(self) -> Dict[str, Any]:
        """Run all tests and generate complete report"""
        logger.info("🚀 Starting comprehensive ChatterFix CMMS testing...")
        
        start_time = datetime.now()
        
        # Run all test categories
        self.test_results["frontend_tests"] = await self.test_main_dashboard()
        self.test_results["backend_tests"] = await self.test_api_endpoints()  
        self.test_results["cms_functionality_tests"] = await self.test_module_navigation()
        self.test_results["ai_functionality_tests"] = await self.test_ai_functionality()
        self.test_results["integration_tests"] = await self.test_integration_and_workflow()
        self.test_results["overall_assessment"] = await self.generate_final_assessment()
        
        end_time = datetime.now()
        testing_duration = (end_time - start_time).total_seconds()
        
        # Generate comprehensive report
        report = {
            "test_metadata": {
                "testing_start": start_time.isoformat(),
                "testing_end": end_time.isoformat(), 
                "total_duration_seconds": testing_duration,
                "tester": "LLaMA End-User Comprehensive Tester",
                "platform_tested": "ChatterFix CMMS",
                "test_categories": len(self.test_results)
            },
            "test_results": self.test_results,
            "summary": {
                "tests_passed": sum(1 for category in self.test_results.values() 
                                  if isinstance(category, dict) and category.get('status') == 'success'),
                "tests_failed": sum(1 for category in self.test_results.values()
                                  if isinstance(category, dict) and category.get('status') in ['failed', 'error']),
                "overall_status": "comprehensive_testing_complete"
            }
        }
        
        return report

# Main testing function
async def run_platform_tests():
    """Main testing execution"""
    print("🧪 ChatterFix CMMS - LLaMA Comprehensive Platform Testing")
    print("=" * 60)
    
    tester = LLaMAEndUserTester()
    
    try:
        # Run comprehensive tests
        report = await tester.run_comprehensive_tests()
        
        # Save report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"/Users/fredtaylor/Desktop/Projects/ai-tools/core/cmms/llama_test_report_{timestamp}.json"
        
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n✅ Comprehensive testing complete!")
        print(f"📄 Report saved: {report_file}")
        print(f"⏱️  Testing duration: {report['test_metadata']['total_duration_seconds']:.2f} seconds")
        print("\n🎯 KEY FINDINGS:")
        print("-" * 30)
        
        # Print LLaMA's final assessment
        if 'overall_assessment' in report['test_results']:
            assessment = report['test_results']['overall_assessment'].get('llama_final_assessment', 'Assessment pending...')
            print(assessment[:500] + "..." if len(assessment) > 500 else assessment)
        
        return report
        
    except Exception as e:
        print(f"❌ Testing failed: {e}")
        return {"error": str(e)}

if __name__ == "__main__":
    asyncio.run(run_platform_tests())