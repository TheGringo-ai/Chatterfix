#!/usr/bin/env python3
"""
CMMS Module Manager
Centralized management for AI components and CMMS modules
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from fastapi import APIRouter

logger = logging.getLogger(__name__)

class ModuleStatus(Enum):
    """Module status enumeration"""
    NOT_LOADED = "not_loaded"
    LOADING = "loading"
    LOADED = "loaded"
    FAILED = "failed"
    DISABLED = "disabled"

@dataclass
class ModuleInfo:
    """Information about a registered module"""
    name: str
    description: str
    router: Optional[APIRouter] = None
    status: ModuleStatus = ModuleStatus.NOT_LOADED
    error_message: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)
    priority: int = 100  # Lower number = higher priority
    config: Dict[str, Any] = field(default_factory=dict)

class ModuleManager:
    """Centralized module manager for CMMS system"""
    
    def __init__(self):
        self.modules: Dict[str, ModuleInfo] = {}
        self.loaded_routers: List[APIRouter] = []
        self.event_handlers: Dict[str, List[Callable]] = {}
        self._initialized = False
        
        logger.info("🏗️ Module Manager initialized")
    
    def register_module(self, 
                       name: str, 
                       description: str,
                       import_path: str,
                       router_name: str = "router",
                       dependencies: List[str] = None,
                       priority: int = 100,
                       config: Dict[str, Any] = None) -> None:
        """Register a module for loading"""
        
        self.modules[name] = ModuleInfo(
            name=name,
            description=description,
            dependencies=dependencies or [],
            priority=priority,
            config=config or {}
        )
        
        # Attempt to load the module
        self._load_module(name, import_path, router_name)
        
        logger.info(f"📦 Registered module: {name}")
    
    def _load_module(self, name: str, import_path: str, router_name: str) -> None:
        """Load a specific module"""
        module_info = self.modules[name]
        module_info.status = ModuleStatus.LOADING
        
        try:
            # Dynamic import
            module = __import__(import_path, fromlist=[router_name])
            router = getattr(module, router_name)
            
            module_info.router = router
            module_info.status = ModuleStatus.LOADED
            self.loaded_routers.append(router)
            
            logger.info(f"✅ Module loaded: {name}")
            
            # Emit module loaded event
            self.emit_event("module_loaded", {"module_name": name, "module_info": module_info})
            
        except ImportError as e:
            module_info.status = ModuleStatus.FAILED
            module_info.error_message = f"Import error: {str(e)}"
            logger.warning(f"⚠️ Failed to load module {name}: {e}")
            
        except AttributeError as e:
            module_info.status = ModuleStatus.FAILED
            module_info.error_message = f"Router not found: {str(e)}"
            logger.warning(f"⚠️ Failed to find router for module {name}: {e}")
            
        except Exception as e:
            module_info.status = ModuleStatus.FAILED
            module_info.error_message = f"Unexpected error: {str(e)}"
            logger.error(f"❌ Unexpected error loading module {name}: {e}")
    
    def get_loaded_routers(self) -> List[APIRouter]:
        """Get all successfully loaded routers"""
        return self.loaded_routers.copy()
    
    def get_module_status(self, name: str) -> Optional[ModuleStatus]:
        """Get status of a specific module"""
        module = self.modules.get(name)
        return module.status if module else None
    
    def get_all_modules_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all registered modules"""
        return {
            name: {
                "status": module.status.value,
                "description": module.description,
                "error": module.error_message,
                "dependencies": module.dependencies
            }
            for name, module in self.modules.items()
        }
    
    def is_module_available(self, name: str) -> bool:
        """Check if a module is available and loaded"""
        module = self.modules.get(name)
        return module is not None and module.status == ModuleStatus.LOADED
    
    def on_event(self, event_name: str, handler: Callable) -> None:
        """Register an event handler"""
        if event_name not in self.event_handlers:
            self.event_handlers[event_name] = []
        self.event_handlers[event_name].append(handler)
    
    def emit_event(self, event_name: str, data: Any = None) -> None:
        """Emit an event to all registered handlers"""
        handlers = self.event_handlers.get(event_name, [])
        for handler in handlers:
            try:
                handler(data)
            except Exception as e:
                logger.error(f"Error in event handler for {event_name}: {e}")
    
    async def initialize_modules(self) -> None:
        """Initialize all loaded modules (call their startup routines if available)"""
        if self._initialized:
            return
        
        logger.info("🚀 Initializing loaded modules...")
        
        # Sort modules by priority
        sorted_modules = sorted(
            [(name, info) for name, info in self.modules.items() if info.status == ModuleStatus.LOADED],
            key=lambda x: x[1].priority
        )
        
        for name, module_info in sorted_modules:
            try:
                # Check if module has an initialization function
                if hasattr(module_info.router, 'initialize'):
                    if asyncio.iscoroutinefunction(module_info.router.initialize):
                        await module_info.router.initialize()
                    else:
                        module_info.router.initialize()
                    logger.info(f"🎯 Initialized module: {name}")
                        
            except Exception as e:
                logger.error(f"Failed to initialize module {name}: {e}")
        
        self._initialized = True
        logger.info("✅ Module initialization complete")
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of all modules"""
        total_modules = len(self.modules)
        loaded_modules = len([m for m in self.modules.values() if m.status == ModuleStatus.LOADED])
        failed_modules = len([m for m in self.modules.values() if m.status == ModuleStatus.FAILED])
        
        return {
            "total_modules": total_modules,
            "loaded_modules": loaded_modules,
            "failed_modules": failed_modules,
            "health_percentage": (loaded_modules / total_modules * 100) if total_modules > 0 else 0,
            "modules": self.get_all_modules_status()
        }

# Global module manager instance
module_manager = ModuleManager()

def register_core_modules():
    """Register all core CMMS modules"""
    
    # Core CMMS modules (high priority)
    module_manager.register_module(
        name="cmms_core", 
        description="Core CMMS functionality (assets, workorders, etc.)",
        import_path="cmms",
        router_name="cmms_router",
        priority=10
    )
    
    module_manager.register_module(
        name="ai_pipeline", 
        description="AI processing pipeline and workflows",
        import_path="ai_pipeline",
        router_name="ai_pipeline_router",
        priority=20
    )
    
    module_manager.register_module(
        name="security_auth", 
        description="Authentication and authorization",
        import_path="security_auth",
        router_name="router",
        priority=15
    )
    
    # AI Enhancement modules (medium priority)
    module_manager.register_module(
        name="voice_router", 
        description="Voice command processing",
        import_path="voice_router",
        router_name="voice_router",
        dependencies=["ai_pipeline"],
        priority=30
    )
    
    module_manager.register_module(
        name="rag_system", 
        description="Retrieval-Augmented Generation system",
        import_path="rag_router",
        router_name="router",
        dependencies=["ai_pipeline"],
        priority=25
    )
    
    module_manager.register_module(
        name="natural_language", 
        description="Natural language intent processing",
        import_path="intent_router",
        router_name="router",
        dependencies=["ai_pipeline"],
        priority=40
    )
    
    module_manager.register_module(
        name="predictive_maintenance", 
        description="Predictive maintenance engine",
        import_path="prediction_router",
        router_name="router",
        dependencies=["cmms_core", "ai_pipeline"],
        priority=50
    )
    
    # Advanced AI modules (lower priority)
    module_manager.register_module(
        name="aiops", 
        description="AIOps self-healing system",
        import_path="aiops_router",
        router_name="router",
        dependencies=["cmms_core"],
        priority=60
    )
    
    module_manager.register_module(
        name="meta_system", 
        description="Meta-system AI autonomous capabilities",
        import_path="ai_meta_system",
        router_name="meta_router",
        dependencies=["ai_pipeline"],
        priority=70
    )

if __name__ == "__main__":
    # Test the module manager
    register_core_modules()
    status = module_manager.get_all_modules_status()
    print("Module Status:", status)