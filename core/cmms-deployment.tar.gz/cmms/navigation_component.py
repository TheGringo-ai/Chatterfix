#!/usr/bin/env python3
"""
Navigation Component for ChatterFix CMMS
Provides consistent navigation bar across all modules
"""

def get_navigation_html(current_page: str = "", breadcrumbs: list = None) -> str:
    """
    Generate navigation HTML with current page highlighted
    
    Args:
        current_page: The current page identifier (dashboard, workorders, assets, etc.)
    
    Returns:
        HTML string for the navigation component
    """
    
    nav_items = [
        {"id": "dashboard", "href": "/cmms/dashboard/main", "icon": "📊", "label": "Dashboard"},
        {"id": "workorders", "href": "/cmms/workorders/dashboard", "icon": "📋", "label": "Work Orders"},
        {"id": "assets", "href": "/cmms/assets/dashboard", "icon": "⚙️", "label": "Assets"},
        {"id": "parts", "href": "/cmms/parts/dashboard", "icon": "📦", "label": "Parts"},
        {"id": "preventive", "href": "/cmms/preventive/dashboard", "icon": "🔄", "label": "Preventive"},
        {"id": "technicians", "href": "/cmms/technicians/portal", "icon": "👷", "label": "Technicians"},
        {"id": "ai", "href": "/cmms/ai-enhanced/dashboard/universal", "icon": "🤖", "label": "AI Assistant"},
        {"id": "settings", "href": "/settings/ai-providers", "icon": "🛠️", "label": "AI Settings"},
        {"id": "admin", "href": "/cmms/admin/dashboard", "icon": "⚖️", "label": "Admin"}
    ]
    
    nav_links = ""
    for item in nav_items:
        # Enhanced active state detection
        active_class = ""
        if item["id"] == current_page:
            active_class = "active"
        elif current_page and item["id"] in current_page:
            active_class = "active"
            
        nav_links += f"""
            <li class="nav-item">
                <a href="{item['href']}" class="nav-link {active_class}" data-nav-id="{item['id']}">
                    <span class="nav-icon">{item['icon']}</span>
                    <span class="nav-label">{item['label']}</span>
                </a>
            </li>"""
    
    # Generate breadcrumbs if provided
    breadcrumb_html = ""
    if breadcrumbs:
        breadcrumb_items = []
        for crumb in breadcrumbs:
            if 'url' in crumb:
                breadcrumb_items.append(f'<a href="{crumb["url"]}" class="breadcrumb-link">{crumb["name"]}</a>')
            else:
                breadcrumb_items.append(f'<span class="breadcrumb-current">{crumb["name"]}</span>')
        breadcrumb_html = f"""
        <div class="breadcrumb-container">
            <nav class="breadcrumb">
                <a href="/cmms/" class="breadcrumb-link">🏠 Home</a>
                <span class="breadcrumb-separator">›</span>
                {' <span class="breadcrumb-separator">›</span> '.join(breadcrumb_items)}
            </nav>
        </div>
        """

    return f"""
        <nav class="navbar">
            <a href="/cmms/" class="navbar-brand">⚡ ChatterFix CMMS</a>
            <button class="navbar-toggle" onclick="toggleNav()">☰</button>
            <ul class="navbar-nav" id="navbarNav">
                {nav_links}
            </ul>
        </nav>
        {breadcrumb_html}
        
        <!-- Floating AI Assistant Button -->
        <div class="ai-assistant-float">
            <a href="/cmms/ai-enhanced/dashboard/universal" class="ai-float-btn" title="AI Universal Dashboard - Access from anywhere">
                🤖
                <span class="ai-pulse"></span>
            </a>
        </div>
    """

def get_cmms_css_links() -> str:
    """
    Get CSS links for centralized CMMS stylesheets
    
    Returns:
        HTML link tags for CSS files
    """
    return """
        <link rel="stylesheet" href="/static/css/cmms-professional.css">
        <link rel="stylesheet" href="/static/css/cmms-core.css">
        <link rel="stylesheet" href="/static/css/navigation.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    """

def get_navigation_styles() -> str:
    """
    Get CSS styles for the navigation component
    
    Returns:
        CSS styles as string
    """
    return """
        /* Navigation Styles */
        .navbar {
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
            padding: 1rem;
            display: inline-block;
        }
        .navbar-nav {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            flex-wrap: wrap;
        }
        .nav-item {
            position: relative;
        }
        .nav-link {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
            position: relative;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255,255,255,0.1);
            border-bottom-color: #38ef7d;
            transform: translateY(-1px);
        }
        .nav-link.active {
            color: white;
            background: rgba(56,239,125,0.2);
            border-bottom-color: #38ef7d;
            box-shadow: 0 0 10px rgba(56,239,125,0.3);
        }
        .nav-icon {
            margin-right: 0.5rem;
            font-size: 1.1rem;
        }
        .nav-label {
            font-weight: 500;
        }
        
        /* Mobile Navigation */
        .navbar-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            padding: 1rem;
            cursor: pointer;
        }
        
        /* Breadcrumb Styles */
        .breadcrumb-container {
            background: rgba(0,0,0,0.2);
            backdrop-filter: blur(5px);
            padding: 0.75rem 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .breadcrumb {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            font-size: 0.9rem;
        }
        .breadcrumb-link {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .breadcrumb-link:hover {
            color: #38ef7d;
        }
        .breadcrumb-current {
            color: white;
            font-weight: 500;
        }
        .breadcrumb-separator {
            margin: 0 0.5rem;
            color: rgba(255,255,255,0.4);
        }
        
        @media (max-width: 768px) {
            .navbar-nav {
                display: none;
                width: 100%;
                flex-direction: column;
                background: rgba(0,0,0,0.8);
                backdrop-filter: blur(15px);
                position: absolute;
                top: 100%;
                left: 0;
                border-top: 1px solid rgba(255,255,255,0.1);
            }
            .navbar-nav.show {
                display: flex;
            }
            .navbar-toggle {
                display: block;
            }
            .navbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
                position: relative;
            }
            .nav-link {
                padding: 1rem;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                border-left: none;
                border-right: none;
                border-top: none;
            }
            .nav-link.active {
                background: rgba(56,239,125,0.3);
                border-left: 3px solid #38ef7d;
            }
            .breadcrumb-container {
                padding: 0.5rem;
            }
            .breadcrumb {
                font-size: 0.8rem;
            }
            .breadcrumb-separator {
                margin: 0 0.25rem;
            }
        }
    """

def get_navigation_javascript() -> str:
    """
    Get JavaScript code for navigation functionality with AI assistant
    
    Returns:
        JavaScript code as string with AI injection
    """
    return """
        function toggleNav() {
            const nav = document.getElementById('navbarNav');
            nav.classList.toggle('show');
        }
        
        // Close mobile nav when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('navbarNav');
            const toggle = document.querySelector('.navbar-toggle');
            if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                nav.classList.remove('show');
            }
        });
        
        // Close mobile nav when navigation link is clicked
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                const nav = document.getElementById('navbarNav');
                nav.classList.remove('show');
            });
        });
        
        // Add loading feedback for navigation
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    // Add loading state
                    const icon = this.querySelector('.nav-icon');
                    const originalIcon = icon.textContent;
                    icon.textContent = '⏳';
                    
                    // Restore icon after navigation
                    setTimeout(() => {
                        icon.textContent = originalIcon;
                    }, 1000);
                });
            });
        });
        
        // Inject AI Assistant on page load
        window.addEventListener('DOMContentLoaded', function() {
            injectChatterFixAI();
        });
        
        function injectChatterFixAI() {
            if (window.chatterFixAIInjected) return;
            window.chatterFixAIInjected = true;
            
            // Create AI button
            const aiBtn = document.createElement('div');
            aiBtn.id = 'cfAIBtn';
            aiBtn.innerHTML = '🤖';
            aiBtn.title = 'AI Universal Dashboard\n• Click: Open panel\n• Shift+Click: Navigate to page\n• Ctrl/Cmd+Click: Open in new tab';
            aiBtn.style.cssText = `
                position: fixed; bottom: 30px; right: 30px;
                width: 65px; height: 65px; border-radius: 50%;
                background: linear-gradient(135deg, #38ef7d, #11998e);
                display: flex; align-items: center; justify-content: center;
                cursor: pointer; z-index: 10000; font-size: 32px;
                box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                border: 3px solid rgba(255,255,255,0.3);
                transition: all 0.3s ease;
                animation: pulse-glow 3s infinite;
            `;
            
            // Add pulsing animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes pulse-glow {
                    0%, 100% { 
                        transform: scale(1); 
                        box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                    }
                    50% { 
                        transform: scale(1.05); 
                        box-shadow: 0 8px 30px rgba(56,239,125,0.8);
                    }
                }
                #cfAIBtn:hover {
                    transform: scale(1.1) !important;
                    box-shadow: 0 8px 35px rgba(56,239,125,0.9) !important;
                }
            `;
            document.head.appendChild(style);
            
            // Create AI panel
            const aiPanel = document.createElement('iframe');
            aiPanel.id = 'cfAIPanel';
            aiPanel.src = '/cmms/ai-enhanced/dashboard/universal';
            aiPanel.style.cssText = `
                position: fixed; bottom: 100px; right: 30px;
                width: 420px; height: 650px; max-width: 90vw; max-height: 70vh;
                border: none; border-radius: 20px; display: none; z-index: 9999;
                box-shadow: 0 10px 40px rgba(0,0,0,0.5);
                background: rgba(255,255,255,0.1);
                backdrop-filter: blur(10px);
            `;
            
            document.body.appendChild(aiBtn);
            document.body.appendChild(aiPanel);
            
            // Toggle panel or direct link
            aiBtn.onclick = (e) => {
                if (e.ctrlKey || e.metaKey) {
                    // Ctrl/Cmd + click = open in new tab
                    window.open('/cmms/ai-enhanced/dashboard/universal', '_blank');
                } else if (e.shiftKey) {
                    // Shift + click = navigate to page
                    window.location.href = '/cmms/ai-enhanced/dashboard/universal';
                } else {
                    // Regular click = toggle panel
                    const visible = aiPanel.style.display === 'block';
                    aiPanel.style.display = visible ? 'none' : 'block';
                    aiBtn.style.transform = visible ? 'scale(1)' : 'scale(0.9)';
                }
            };
            
            aiBtn.onmouseover = () => aiBtn.style.transform = 'scale(1.1)';
            aiBtn.onmouseout = () => {
                if (aiPanel.style.display !== 'block') {
                    aiBtn.style.transform = 'scale(1)';
                }
            };
            
            console.log('✅ ChatterFix AI Assistant loaded');
        }
    """

def get_base_styles() -> str:
    """
    Get enterprise-grade CSS styles with professional wow factor
    
    Returns:
        CSS styles as string with enterprise aesthetics
    """
    return """
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Montserrat', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #3498db 0%, #2c3e50 50%, #34495e 100%);
            min-height: 100vh;
            color: white;
            line-height: 1.6;
            overflow-x: hidden;
        }
        
        /* Enterprise Glass Morphism Effects */
        .glass-morphism {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }
        
        .glass-morphism:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        /* Professional Animations */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(52, 152, 219, 0.7); }
            50% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(52, 152, 219, 0); }
        }
        
        .fade-in-up { animation: fadeInUp 0.6s ease-out; }
        .pulse-animation { animation: pulse 2s infinite; }
        
        .container { 
            max-width: 1400px; 
            margin: 0 auto; 
            padding: 3rem 2.5rem; 
        }
        
        .header { 
            padding: 3rem 2rem;
            text-align: center;
            background: linear-gradient(135deg, rgba(52, 152, 219, 0.2) 0%, rgba(44, 62, 80, 0.3) 100%);
            backdrop-filter: blur(20px);
            border-bottom: 2px solid rgba(241, 196, 15, 0.3);
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 0;
        }
        
        .header h1 { 
            font-size: 3rem; 
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            color: #ffffff;
            position: relative;
            z-index: 2;
        }
        
        .card { 
            background: rgba(255, 255, 255, 0.1); 
            border-radius: 20px; 
            padding: 3rem 2.5rem; 
            backdrop-filter: blur(20px);
            border: 2px solid rgba(241, 196, 15, 0.2);
            margin-bottom: 2.5rem;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            border-color: rgba(241, 196, 15, 0.4);
        }
        
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: #3498db;
        }
        
        .grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 2.5rem; 
            margin-bottom: 3rem;
        }
        
        .btn { 
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%); 
            color: white; 
            border: none; 
            padding: 1rem 2rem; 
            border-radius: 12px; 
            cursor: pointer; 
            font-size: 1rem;
            font-weight: 500;
            font-family: 'Montserrat', sans-serif;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(52, 152, 219, 0.3);
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .btn:hover::before {
            left: 100%;
        }
        
        .btn:hover { 
            background: linear-gradient(135deg, #2980b9 0%, #3498db 100%); 
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(52, 152, 219, 0.4);
        }
        
        .btn-success { 
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%); 
            box-shadow: 0 4px 15px rgba(39, 174, 96, 0.3);
        }
        .btn-success:hover { 
            background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%); 
            box-shadow: 0 6px 20px rgba(39, 174, 96, 0.4);
        }
        
        .btn-warning { 
            background: linear-gradient(135deg, #f39c12 0%, #f1c40f 100%); 
            box-shadow: 0 4px 15px rgba(241, 196, 15, 0.3);
            color: #2c3e50;
        }
        .btn-warning:hover { 
            background: linear-gradient(135deg, #f1c40f 0%, #f39c12 100%); 
            box-shadow: 0 6px 20px rgba(241, 196, 15, 0.4);
        }
        
        .btn-danger { 
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); 
            box-shadow: 0 4px 15px rgba(231, 76, 60, 0.3);
        }
        .btn-danger:hover { 
            background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%); 
            box-shadow: 0 6px 20px rgba(231, 76, 60, 0.4);
        }
        
        .table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 1rem; 
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .table th, .table td { 
            padding: 1rem; 
            text-align: left; 
            border-bottom: 1px solid rgba(255,255,255,0.1); 
        }
        .table th { 
            background: rgba(0,0,0,0.3); 
            font-weight: 600; 
        }
        
        .stat-value { 
            font-size: 2rem; 
            font-weight: bold; 
            color: #38ef7d; 
            margin: 1rem 0;
        }
        
        /* Improved content spacing */
        .card h3, .card h2, .card h1 {
            margin-bottom: 1.5rem;
            letter-spacing: 0.02em;
        }
        
        .card p, .card div {
            margin-bottom: 1rem;
        }
        
        .stat {
            margin: 1.5rem 0;
            padding: 0.75rem 0;
        }
        
        .status-operational { color: #38a169; }
        .status-maintenance { color: #d69e2e; }
        .status-down { color: #e53e3e; }
        .status-active { color: #38a169; }
        .status-inactive { color: #e53e3e; }
    """