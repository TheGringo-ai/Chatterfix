"""
Natural Language Router for ChatterFix CMMS
Converts spoken/typed commands into API calls with intent recognition and entity extraction.
"""

import re
import json
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============================================================================
# Intent Schema and Data Models
# =============================================================================

class IntentType(Enum):
    """Supported intent types"""
    CREATE_WORK_ORDER = "create_work_order"
    LIST_WORK_ORDERS = "list_work_orders" 
    UPDATE_WORK_ORDER = "update_work_order"
    LIST_ASSETS = "list_assets"
    LIST_PARTS = "list_parts"
    CREATE_PART = "create_part"
    EXPORT_DATA = "export_data"
    GET_STATUS = "get_status"
    SCHEDULE_PM = "schedule_pm"
    UNKNOWN = "unknown"

class Priority(Enum):
    """Work order priority levels"""
    LOW = "low"
    MEDIUM = "medium" 
    HIGH = "high"
    CRITICAL = "critical"

class EntityType(Enum):
    """Entity types for extraction"""
    EQUIPMENT = "equipment"
    PART = "part"
    DATE = "date"
    PRIORITY = "priority"
    PERSON = "person"
    NUMBER = "number"
    STATUS = "status"
    EXPORT_FORMAT = "export_format"

@dataclass
class Entity:
    """Extracted entity with type and value"""
    type: EntityType
    value: str
    confidence: float
    start_pos: int
    end_pos: int
    normalized_value: Optional[Any] = None

@dataclass
class Intent:
    """Parsed intent with entities and confidence"""
    intent: IntentType
    entities: List[Entity]
    confidence: float
    original_text: str
    
    def get_entity(self, entity_type: EntityType) -> Optional[Entity]:
        """Get first entity of specified type"""
        for entity in self.entities:
            if entity.type == entity_type:
                return entity
        return None
    
    def get_entities(self, entity_type: EntityType) -> List[Entity]:
        """Get all entities of specified type"""
        return [e for e in self.entities if e.type == entity_type]

@dataclass 
class ActionResult:
    """Result of executing an action"""
    success: bool
    action_taken: str
    result_data: Optional[Dict[str, Any]]
    confirmation_message: str
    error_message: Optional[str] = None

# =============================================================================
# Natural Language Processing Engine
# =============================================================================

try:
    import spacy  # type: ignore
    from spacy.matcher import Matcher  # type: ignore
except Exception:  # pragma: no cover
    spacy = None  # type: ignore
    Matcher = None  # type: ignore

class IntentClassifier:
    """Intent classification using pattern matching and NLP"""
    
    def __init__(self):
        if spacy:
            self.nlp = spacy.load("en_core_web_sm")
        else:
            self.nlp = None
            
        self.matcher = Matcher(self.nlp.vocab) if (self.nlp and Matcher) else None
        self._setup_patterns()
    
    def _setup_patterns(self):
        """Setup spaCy patterns for intent recognition"""
        if not self.matcher:
            return
        
        # Work Order Creation Patterns
        create_wo_patterns = [
            [{"LOWER": {"IN": ["create", "make", "generate", "add"]}}, 
             {"LOWER": {"IN": ["work", "wo"]}, "OP": "?"}, 
             {"LOWER": "order"}],
            [{"LOWER": {"IN": ["create", "make", "generate", "add"]}}, 
             {"IS_ALPHA": True, "OP": "*"},
             {"LOWER": {"IN": ["work", "wo"]}}, 
             {"LOWER": "order"}],
            [{"LOWER": {"IN": ["new", "create"]}}, 
             {"LOWER": {"IN": ["ticket", "request", "job"]}}],
            [{"LOWER": "schedule"}, 
             {"LOWER": {"IN": ["maintenance", "repair", "service"]}}]
        ]
        self.matcher.add("CREATE_WORK_ORDER", create_wo_patterns)
        
        # Work Order Listing Patterns
        list_wo_patterns = [
            [{"LOWER": {"IN": ["list", "show", "get", "find"]}}, 
             {"LOWER": {"IN": ["work", "wo"]}, "OP": "?"}, 
             {"LOWER": {"IN": ["orders", "tickets"]}}],
            [{"LOWER": "what"}, 
             {"LOWER": {"IN": ["work", "jobs", "tickets"]}}],
            [{"LOWER": {"IN": ["show", "display"]}}, 
             {"LOWER": {"IN": ["pending", "open", "active"]}}]
        ]
        self.matcher.add("LIST_WORK_ORDERS", list_wo_patterns)
        
        # Parts Listing Patterns  
        list_parts_patterns = [
            [{"LOWER": {"IN": ["list", "show", "get"]}}, 
             {"LOWER": "parts"}],
            [{"LOWER": "what"}, {"LOWER": "parts"}],
            [{"LOWER": "parts"}, 
             {"LOWER": {"IN": ["need", "needed", "requiring"]}}],
            [{"LOWER": {"IN": ["inventory", "stock"]}}]
        ]
        self.matcher.add("LIST_PARTS", list_parts_patterns)
        
        # Export Patterns
        export_patterns = [
            [{"LOWER": {"IN": ["export", "download", "generate"]}}, 
             {"LOWER": {"IN": ["report", "data", "file"]}}],
            [{"LOWER": {"IN": ["create", "make"]}}, 
             {"LOWER": {"IN": ["pdf", "csv", "excel", "report"]}}],
            [{"LOWER": "export"}, {"IS_ALPHA": True, "OP": "*"}, 
             {"LOWER": {"IN": ["pdf", "csv", "excel"]}}]
        ]
        self.matcher.add("EXPORT_DATA", export_patterns)

    def classify_intent(self, text: str) -> Intent:
        """Classify intent from natural language text"""
        doc = self.nlp(text.lower()) if self.nlp else None
        matches = self.matcher(doc) if (doc and self.matcher) else []
        
        # Extract entities first
        entities = self._extract_entities(doc, text)
        
        # Try pattern matching first
        if matches:
            match_id, start, end = matches[0]
            intent_label = self.nlp.vocab.strings[match_id] if self.nlp else "unknown"
            intent_type = IntentType(intent_label.lower())
            confidence = self._calculate_confidence(doc, matches, entities)
            
            return Intent(
                intent=intent_type,
                entities=entities,
                confidence=confidence,
                original_text=text
            )
        
        # Fallback to keyword-based classification
        text_lower = text.lower()
        
        # Create work order patterns
        if any(word in text_lower for word in ['create', 'make', 'generate', 'new']) and \
           any(word in text_lower for word in ['work order', 'wo', 'ticket', 'job']):
            return Intent(
                intent=IntentType.CREATE_WORK_ORDER,
                entities=entities,
                confidence=0.7,
                original_text=text
            )
        
        # List parts patterns
        if any(word in text_lower for word in ['parts', 'inventory']) or \
           ('what' in text_lower and any(word in text_lower for word in ['need', 'reorder', 'stock'])):
            return Intent(
                intent=IntentType.LIST_PARTS,
                entities=entities,
                confidence=0.7,
                original_text=text
            )
        
        # Export patterns
        if any(word in text_lower for word in ['export', 'generate', 'create']) and \
           any(word in text_lower for word in ['pdf', 'csv', 'report', 'file']):
            return Intent(
                intent=IntentType.EXPORT_DATA,
                entities=entities,
                confidence=0.7,
                original_text=text
            )
        
        # Unknown intent
        return Intent(
            intent=IntentType.UNKNOWN,
            entities=entities,
            confidence=0.0,
            original_text=text
        )
    
    def _extract_entities(self, doc, original_text: str) -> List[Entity]:
        """Extract entities from spaCy doc"""
        entities = []
        
        # Extract named entities
        for ent in doc.ents:
            entity_type = self._map_spacy_entity_type(ent.label_)
            if entity_type:
                entities.append(Entity(
                    type=entity_type,
                    value=ent.text,
                    confidence=0.8,  # spaCy confidence
                    start_pos=ent.start_char,
                    end_pos=ent.end_char
                ))
        
        # Extract custom entities
        entities.extend(self._extract_priority(doc, original_text))
        entities.extend(self._extract_equipment(doc, original_text))
        entities.extend(self._extract_dates(doc, original_text))
        entities.extend(self._extract_export_formats(doc, original_text))
        
        return entities
    
    def _extract_priority(self, doc, text: str) -> List[Entity]:
        """Extract priority keywords"""
        priority_patterns = {
            "critical": ["critical", "urgent", "emergency", "asap"],
            "high": ["high", "important", "priority", "rush"],
            "medium": ["medium", "normal", "regular"],
            "low": ["low", "routine", "when possible"]
        }
        
        entities = []
        text_lower = text.lower()
        
        for priority, keywords in priority_patterns.items():
            for keyword in keywords:
                if keyword in text_lower:
                    start_pos = text_lower.find(keyword)
                    entities.append(Entity(
                        type=EntityType.PRIORITY,
                        value=priority,
                        confidence=0.9,
                        start_pos=start_pos,
                        end_pos=start_pos + len(keyword),
                        normalized_value=Priority(priority)
                    ))
                    break  # Only one priority per text
        return entities
    
    def _extract_equipment(self, doc, text: str) -> List[Entity]:
        """Extract equipment names using patterns"""
        equipment_patterns = [
            r'\b(pump|motor|tank|valve|compressor|fan|belt|gear|bearing)-?\d*\b',
            r'\b[A-Z]{2,}-\d+\b',  # Equipment codes like HP-3000, MX-2500
            r'\b(equipment|asset|unit|machine)\s+[\w-]+\b'
        ]
        
        entities = []
        for pattern in equipment_patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                entities.append(Entity(
                    type=EntityType.EQUIPMENT,
                    value=match.group(),
                    confidence=0.85,
                    start_pos=match.start(),
                    end_pos=match.end()
                ))
        return entities
    
    def _extract_dates(self, doc, text: str) -> List[Entity]:
        """Extract date expressions"""
        date_patterns = {
            "tomorrow": datetime.now() + timedelta(days=1),
            "today": datetime.now(),
            "yesterday": datetime.now() - timedelta(days=1),
            "next week": datetime.now() + timedelta(weeks=1),
            "this week": datetime.now(),
            "last week": datetime.now() - timedelta(weeks=1),
            "next month": datetime.now() + timedelta(days=30),
            "this month": datetime.now(),
            "last month": datetime.now() - timedelta(days=30)
        }
        
        entities = []
        text_lower = text.lower()
        
        for date_expr, date_obj in date_patterns.items():
            if date_expr in text_lower:
                start_pos = text_lower.find(date_expr)
                entities.append(Entity(
                    type=EntityType.DATE,
                    value=date_expr,
                    confidence=0.9,
                    start_pos=start_pos,
                    end_pos=start_pos + len(date_expr),
                    normalized_value=date_obj
                ))
        return entities
    
    def _extract_export_formats(self, doc, text: str) -> List[Entity]:
        """Extract export format specifications"""
        formats = ["pdf", "csv", "excel", "xlsx", "json"]
        entities = []
        text_lower = text.lower()
        
        for fmt in formats:
            if fmt in text_lower:
                start_pos = text_lower.find(fmt)
                entities.append(Entity(
                    type=EntityType.EXPORT_FORMAT,
                    value=fmt.upper(),
                    confidence=0.95,
                    start_pos=start_pos,
                    end_pos=start_pos + len(fmt)
                ))
        return entities
    
    def _map_spacy_entity_type(self, spacy_label: str) -> Optional[EntityType]:
        """Map spaCy entity labels to our entity types"""
        mapping = {
            "PERSON": EntityType.PERSON,
            "CARDINAL": EntityType.NUMBER,
            "DATE": EntityType.DATE,
            "TIME": EntityType.DATE
        }
        return mapping.get(spacy_label)
    
    def _calculate_confidence(self, doc, matches, entities) -> float:
        """Calculate overall confidence score"""
        base_confidence = 0.7 if matches else 0.1
        
        # Boost confidence for entities found
        entity_boost = min(0.2, len(entities) * 0.05)
        
        # Boost for specific keywords
        keyword_boost = 0.1 if any(token.lemma_ in ["create", "list", "export", "show"] 
                                 for token in doc) else 0.0
        
        return min(1.0, base_confidence + entity_boost + keyword_boost)

# =============================================================================
# Action Router
# =============================================================================

class ActionRouter:
    """Routes intents to appropriate CMMS API actions"""
    
    def __init__(self, cmms_api=None):
        self.cmms_api = cmms_api  # Will be injected with actual CMMS API
        self.intent_classifier = IntentClassifier()
    
    async def process_command(self, command: str) -> ActionResult:
        """Process natural language command and execute action"""
        try:
            # Parse intent and entities
            intent = self.intent_classifier.classify_intent(command)
            
            logger.info(f"Parsed intent: {intent.intent.value} (confidence: {intent.confidence:.2f})")
            logger.info(f"Entities: {[f'{e.type.value}={e.value}' for e in intent.entities]}")
            
            # Route to appropriate handler
            handler_map = {
                IntentType.CREATE_WORK_ORDER: self._handle_create_work_order,
                IntentType.LIST_WORK_ORDERS: self._handle_list_work_orders,
                IntentType.LIST_PARTS: self._handle_list_parts,
                IntentType.EXPORT_DATA: self._handle_export_data,
                IntentType.LIST_ASSETS: self._handle_list_assets,
                IntentType.CREATE_PART: self._handle_create_part,
                IntentType.SCHEDULE_PM: self._handle_schedule_pm
            }
            
            handler = handler_map.get(intent.intent, self._handle_unknown)
            return await handler(intent)
            
        except Exception as e:
            logger.error(f"Error processing command: {e}")
            return ActionResult(
                success=False,
                action_taken="error",
                result_data=None,
                confirmation_message="Sorry, I encountered an error processing your command.",
                error_message=str(e)
            )
    
    async def _handle_create_work_order(self, intent: Intent) -> ActionResult:
        """Handle work order creation"""
        # Extract entities
        equipment = intent.get_entity(EntityType.EQUIPMENT)
        priority = intent.get_entity(EntityType.PRIORITY)
        date = intent.get_entity(EntityType.DATE)
        
        # Build work order data
        wo_data = {
            "title": f"Maintenance Request - {equipment.value if equipment else 'General'}",
            "description": f"Work order created from voice command: {intent.original_text}",
            "priority": priority.normalized_value.value if (priority and priority.normalized_value) else "medium",
            "equipment_id": equipment.value if equipment else None,
            "scheduled_date": date.normalized_value.isoformat() if (date and hasattr(date.normalized_value, 'isoformat')) else None,
            "status": "open",
            "created_by": "voice_assistant",
            "created_at": datetime.now().isoformat()
        }
        
        # Mock API call (replace with actual API)
        wo_id = f"WO-{datetime.now().strftime('%Y%m%d')}-{hash(intent.original_text) % 1000:03d}"
        
        confirmation = f"Work order #{wo_id} created"
        if equipment:
            confirmation += f" for {equipment.value}"
        if priority:
            confirmation += f" with {priority.value} priority"
        if date:
            confirmation += f" scheduled for {date.value}"
        
        return ActionResult(
            success=True,
            action_taken="create_work_order",
            result_data={"work_order_id": wo_id, "data": wo_data},
            confirmation_message=confirmation
        )
    
    async def _handle_list_work_orders(self, intent: Intent) -> ActionResult:
        """Handle work order listing"""
        # Extract filters from entities
        filters = {}
        
        equipment = intent.get_entity(EntityType.EQUIPMENT)
        if equipment:
            filters["equipment"] = equipment.value
            
        priority = intent.get_entity(EntityType.PRIORITY)
        if priority:
            filters["priority"] = priority.value
        
        # Mock data (replace with actual API call)
        work_orders = [
            {"id": "WO-001", "title": "Pump maintenance", "priority": "high", "status": "open"},
            {"id": "WO-002", "title": "Motor inspection", "priority": "medium", "status": "in_progress"},
            {"id": "WO-003", "title": "Valve replacement", "priority": "low", "status": "scheduled"}
        ]
        
        # Apply filters
        if equipment:
            work_orders = [wo for wo in work_orders if equipment.value.lower() in wo["title"].lower()]
        
        confirmation = f"Found {len(work_orders)} work orders"
        if filters:
            filter_desc = ", ".join([f"{k}={v}" for k, v in filters.items()])
            confirmation += f" matching filters: {filter_desc}"
        
        return ActionResult(
            success=True,
            action_taken="list_work_orders",
            result_data={"work_orders": work_orders, "filters": filters},
            confirmation_message=confirmation
        )
    
    async def _handle_list_parts(self, intent: Intent) -> ActionResult:
        """Handle parts listing with reorder logic"""
        # Check for reorder-specific language
        needs_reorder = any(keyword in intent.original_text.lower() 
                          for keyword in ["reorder", "need", "low", "stock", "inventory"])
        
        # Mock parts data (replace with actual API call)
        all_parts = [
            {"id": "P001", "name": "Hydraulic Seal", "stock": 2, "reorder_level": 5, "status": "low"},
            {"id": "P002", "name": "Motor Bearing", "stock": 15, "reorder_level": 10, "status": "ok"},
            {"id": "P003", "name": "Pump Impeller", "stock": 1, "reorder_level": 3, "status": "critical"}
        ]
        
        if needs_reorder:
            parts = [p for p in all_parts if p["stock"] <= p["reorder_level"]]
            confirmation = f"Found {len(parts)} parts that need reordering this week"
        else:
            parts = all_parts
            confirmation = f"Found {len(parts)} parts in inventory"
        
        return ActionResult(
            success=True,
            action_taken="list_parts",
            result_data={"parts": parts, "filter": "reorder" if needs_reorder else "all"},
            confirmation_message=confirmation
        )
    
    async def _handle_export_data(self, intent: Intent) -> ActionResult:
        """Handle data export requests"""
        # Extract export parameters
        format_entity = intent.get_entity(EntityType.EXPORT_FORMAT)
        date_entity = intent.get_entity(EntityType.DATE)
        
        export_format = format_entity.value if format_entity else "PDF"
        
        # Determine data type from original text
        if "pm" in intent.original_text.lower() or "maintenance" in intent.original_text.lower():
            data_type = "preventive_maintenance"
        elif "work order" in intent.original_text.lower():
            data_type = "work_orders"
        else:
            data_type = "general_report"
        
        # Generate mock file (replace with actual export logic)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{data_type}_{timestamp}.{export_format.lower()}"
        
        confirmation = f"Exported {data_type.replace('_', ' ')} to {export_format}"
        if date_entity:
            confirmation += f" for {date_entity.value}"
        confirmation += f". File: {filename}"
        
        return ActionResult(
            success=True,
            action_taken="export_data",
            result_data={
                "filename": filename,
                "format": export_format,
                "data_type": data_type,
                "date_filter": date_entity.value if date_entity else None
            },
            confirmation_message=confirmation
        )
    
    async def _handle_list_assets(self, intent: Intent) -> ActionResult:
        """Handle asset listing"""
        # Mock asset data
        assets = [
            {"id": "PUMP-12", "name": "Hydraulic Pump 12", "status": "operational", "priority": "high"},
            {"id": "MOTOR-X", "name": "Motor X MX-2500", "status": "maintenance_needed", "priority": "medium"},
            {"id": "VALVE-001", "name": "Control Valve 001", "status": "operational", "priority": "low"}
        ]
        
        return ActionResult(
            success=True,
            action_taken="list_assets",
            result_data={"assets": assets},
            confirmation_message=f"Found {len(assets)} assets in the system"
        )
    
    async def _handle_create_part(self, intent: Intent) -> ActionResult:
        """Handle part creation"""
        return ActionResult(
            success=True,
            action_taken="create_part",
            result_data={"part_id": "PART-001"},
            confirmation_message="New part created successfully"
        )
    
    async def _handle_schedule_pm(self, intent: Intent) -> ActionResult:
        """Handle preventive maintenance scheduling"""
        equipment = intent.get_entity(EntityType.EQUIPMENT)
        date = intent.get_entity(EntityType.DATE)
        
        pm_id = f"PM-{datetime.now().strftime('%Y%m%d')}-001"
        
        confirmation = f"Preventive maintenance {pm_id} scheduled"
        if equipment:
            confirmation += f" for {equipment.value}"
        if date:
            confirmation += f" on {date.value}"
        
        return ActionResult(
            success=True,
            action_taken="schedule_pm",
            result_data={"pm_id": pm_id, "equipment": equipment.value if equipment else None},
            confirmation_message=confirmation
        )

    async def _handle_unknown(self, intent: Intent) -> ActionResult:
        """Handle unknown intents"""
        return ActionResult(
            success=False,
            action_taken="unknown",
            result_data={"original_text": intent.original_text},
            confirmation_message="I didn't understand that command. Try asking me to create work orders, list parts, or export data.",
            error_message="Intent not recognized"
        )

# =============================================================================
# Text-to-Speech Confirmation System
# =============================================================================

class TTSConfirmation:
    """Text-to-speech confirmation system"""
    
    def __init__(self):
        self.enabled = True
    
    def speak_confirmation(self, message: str) -> Dict[str, Any]:
        """Generate TTS confirmation (mock implementation)"""
        if not self.enabled:
            return {"tts_enabled": False}
        
        # In real implementation, this would use Web Speech API or similar
        return {
            "tts_enabled": True,
            "message": message,
            "audio_url": f"/api/tts?text={message}",  # Mock URL
            "duration_ms": len(message) * 80  # Estimate speaking time
        }

# =============================================================================
# Main NL Router Class
# =============================================================================

class NaturalLanguageRouter:
    """Main natural language router coordinating all components"""
    
    def __init__(self, cmms_api=None):
        self.action_router = ActionRouter(cmms_api)
        self.tts = TTSConfirmation()
        logger.info("Natural Language Router initialized")
    
    async def process_voice_command(self, command: str) -> Dict[str, Any]:
        """Process voice command and return full response"""
        start_time = datetime.now()
        
        # Process the command
        result = await self.action_router.process_command(command)
        
        # Generate TTS confirmation
        tts_data = self.tts.speak_confirmation(result.confirmation_message)
        
        # Calculate processing time
        processing_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return {
            "success": result.success,
            "intent_processed": True,
            "action_taken": result.action_taken,
            "confirmation_message": result.confirmation_message,
            "tts_confirmation": tts_data,
            "result_data": result.result_data,
            "error_message": result.error_message,
            "processing_time_ms": processing_time_ms,
            "timestamp": datetime.now().isoformat()
        }
    
    def get_capabilities(self) -> Dict[str, Any]:  # broaden return type
        """Return system capabilities for UI"""
        return {
            "supported_intents": [intent.value for intent in IntentType if intent != IntentType.UNKNOWN],
            "supported_entities": [entity.value for entity in EntityType],
            "spacy_enabled": bool(self.nlp),
            "matcher_enabled": bool(self.matcher),
        }

# Export main class
__all__ = ["NaturalLanguageRouter", "IntentType", "EntityType", "ActionResult"]