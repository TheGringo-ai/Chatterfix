#!/usr/bin/env python3
"""
CMMS Parts Module - Enhanced Version
Parts inventory management, ordering, and tracking with modern UI
"""

from fastapi import APIRouter, HTTPException, Query, Depends, UploadFile, File, Form
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from dataclasses import asdict
import logging
import time
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles
from api_schemas import (
    PartCreate, PartUpdate, PartResponse, StockAdjustment, StockTransaction, 
    PartList, ExportRequest, ExportFormat, BulkDeleteRequest, BulkResponse,
    BaseResponse, ErrorResponse, PaginationParams,
    # Procurement workflow schemas
    PurchaseRequestCreate, PurchaseRequestResponse, RFQCreate, RFQResponse,
    QuoteAttach, QuoteResponse, QuoteComparisonResponse, POCreate, 
    PurchaseOrderResponse, ReceivingCreate, ReceivingResponse,
    VendorCreate, VendorResponse, ApprovalWorkflowResponse, ApprovalAction,
    PartsKPIResponse, ProcurementAnalyticsResponse
)
from auth_rbac import get_current_user, require_permissions, Permission, AuthUser
from audit_trail import audit_create, audit_update, audit_delete, audit_stock_adjustment, audit_bulk_operation
try:
    from .db.database import get_session, get_engine  # type: ignore
    from .db.models import PartORM  # type: ignore
    _PART_DB = True
except Exception:
    try:
        from db.database import get_session, get_engine  # type: ignore
        from db.models import PartORM  # type: ignore
        _PART_DB = True
    except Exception:  # pragma: no cover
        _PART_DB = False
        get_session = None  # type: ignore

logger = logging.getLogger(__name__)

# Parts router
parts_router = APIRouter(prefix="/parts", tags=["parts"])

# AI-Enhanced Parts Lookup Models
class AIPartsRequest(BaseModel):
    query: str  # Natural language query or part description
    asset_id: Optional[str] = None
    equipment_type: Optional[str] = None
    problem_description: Optional[str] = None
    urgency: Optional[str] = "medium"
    max_results: int = 10

class AIPartsResponse(BaseModel):
    success: bool
    query_understood: str
    suggested_parts: List[Dict[str, Any]]
    alternative_parts: List[Dict[str, Any]] = []
    inventory_insights: Dict[str, Any] = {}
    procurement_recommendations: List[str] = []
    ai_reasoning: str = ""
    confidence: float = 0.0

class SmartInventoryAnalysis(BaseModel):
    critical_stock_alerts: List[Dict[str, Any]]
    reorder_suggestions: List[Dict[str, Any]]
    cost_optimization_opportunities: List[Dict[str, Any]]
    usage_predictions: Dict[str, Any]
    ai_insights: List[str]

# Data models
class Part(BaseModel):
    id: str
    part_number: str
    name: str
    description: str
    category: str
    manufacturer: str
    supplier: str
    unit_cost: float
    quantity_on_hand: int
    reorder_point: int
    maximum_stock: int
    unit_of_measure: str
    location: str
    last_ordered: Optional[str] = None
    compatible_assets: List[str]

# Sample parts data (same as original)
parts_db = [
    {
        "id": "PRT-001",
        "part_number": "BRG-6205-2RS",
        "name": "Deep Groove Ball Bearing",
        "description": "25x52x15mm sealed bearing",
        "category": "Bearings",
        "manufacturer": "SKF",
        "supplier": "Industrial Supply Co",
        "unit_cost": 24.50,
        "quantity_on_hand": 12,
        "reorder_point": 5,
        "maximum_stock": 25,
        "unit_of_measure": "each",
        "location": "A-1-15",
        "last_ordered": "2025-07-15",
        "compatible_assets": ["AST-001", "AST-002", "AST-005"]
    },
    {
        "id": "PRT-002",
        "part_number": "FLT-AIR-AC37",
        "name": "Air Filter Element",
        "description": "High-efficiency particulate air filter",
        "category": "Filters",
        "manufacturer": "Donaldson",
        "supplier": "Filter Solutions",
        "unit_cost": 18.75,
        "quantity_on_hand": 8,
        "reorder_point": 3,
        "maximum_stock": 15,
        "unit_of_measure": "each",
        "location": "B-2-08",
        "last_ordered": "2025-08-01",
        "compatible_assets": ["AST-001", "AST-003"]
    },
    {
        "id": "PRT-003",
        "part_number": "BLT-V-A32",
        "name": "V-Belt A32",
        "description": "Classical V-belt, 32 inch length",
        "category": "Belts",
        "manufacturer": "Gates",
        "supplier": "Belt & Chain Co",
        "unit_cost": 12.30,
        "quantity_on_hand": 0,
        "reorder_point": 2,
        "maximum_stock": 10,
        "unit_of_measure": "each",
        "location": "C-1-12",
        "last_ordered": "2025-06-20",
        "compatible_assets": ["AST-002", "AST-004"]
    },
    {
        "id": "PRT-004",
        "part_number": "SEAL-OS-25X40",
        "name": "Oil Seal 25x40x7",
        "description": "Nitrile rubber oil seal",
        "category": "Seals",
        "manufacturer": "NOK",
        "supplier": "Industrial Supply Co",
        "unit_cost": 8.95,
        "quantity_on_hand": 15,
        "reorder_point": 8,
        "maximum_stock": 20,
        "unit_of_measure": "each",
        "location": "A-3-22",
        "last_ordered": "2025-07-30",
        "compatible_assets": ["AST-001", "AST-005"]
    },
    {
        "id": "PRT-005",
        "part_number": "LUB-EP2-1KG",
        "name": "EP2 Lithium Grease",
        "description": "Multi-purpose lithium complex grease",
        "category": "Lubricants",
        "manufacturer": "Shell",
        "supplier": "Bearings Direct",
        "unit_cost": 15.60,
        "quantity_on_hand": 4,
        "reorder_point": 6,
        "maximum_stock": 12,
        "unit_of_measure": "kg",
        "location": "D-1-05",
        "last_ordered": "2025-08-10",
        "compatible_assets": ["AST-001", "AST-002", "AST-003", "AST-004", "AST-005"]
    }
]

# AI-Powered Parts Intelligence System
class AIPartsIntelligence:
    def __init__(self):
        self.ai_orchestrator = None
        self._initialize_ai()
        
    def _initialize_ai(self):
        """Initialize AI orchestrator for parts intelligence"""
        try:
            from ai_orchestrator import ai_orchestrator
            self.ai_orchestrator = ai_orchestrator
            logger.info("✅ AI Parts Intelligence initialized")
        except ImportError:
            try:
                from .ai_orchestrator import ai_orchestrator
                self.ai_orchestrator = ai_orchestrator
                logger.info("✅ AI Parts Intelligence initialized") 
            except ImportError:
                logger.warning("⚠️ AI orchestrator not available for parts intelligence")
    
    async def intelligent_parts_search(self, request: AIPartsRequest) -> AIPartsResponse:
        """AI-powered intelligent parts search and recommendations"""
        try:
            # Analyze the query with AI
            query_analysis = await self._analyze_parts_query(request)
            
            # Search for matching parts
            matching_parts = self._semantic_parts_search(request.query, request.asset_id)
            
            # Generate intelligent suggestions
            suggestions = await self._generate_part_suggestions(
                request, query_analysis, matching_parts
            )
            
            # Analyze inventory status
            inventory_insights = self._analyze_inventory_status(matching_parts)
            
            # Generate procurement recommendations
            procurement_recs = await self._generate_procurement_recommendations(
                matching_parts, request.urgency
            )
            
            return AIPartsResponse(
                success=True,
                query_understood=query_analysis.get("interpreted_query", request.query),
                suggested_parts=suggestions["primary_suggestions"],
                alternative_parts=suggestions["alternatives"],
                inventory_insights=inventory_insights,
                procurement_recommendations=procurement_recs,
                ai_reasoning=query_analysis.get("reasoning", ""),
                confidence=query_analysis.get("confidence", 0.8)
            )
            
        except Exception as e:
            logger.error(f"AI parts search failed: {e}")
            # Fallback to traditional search
            fallback_parts = self._traditional_parts_search(request.query)
            
            return AIPartsResponse(
                success=True,
                query_understood=f"Traditional search for: {request.query}",
                suggested_parts=fallback_parts,
                ai_reasoning="AI analysis unavailable - using traditional search",
                confidence=0.6
            )
    
    async def _analyze_parts_query(self, request: AIPartsRequest) -> Dict[str, Any]:
        """Analyze parts query with AI to understand intent"""
        if not self.ai_orchestrator:
            return {"interpreted_query": request.query, "confidence": 0.5}
        
        analysis_prompt = f"""INDUSTRIAL PARTS SEARCH ANALYSIS

QUERY: "{request.query}"

CONTEXT:
- Asset ID: {request.asset_id or 'Not specified'}
- Equipment Type: {request.equipment_type or 'Not specified'}
- Problem: {request.problem_description or 'Not specified'}
- Urgency: {request.urgency}

ANALYSIS REQUIREMENTS:
1. Interpret the parts search intent
2. Identify specific part types, categories, or characteristics
3. Extract technical specifications if mentioned
4. Determine if this is for repair, maintenance, or replacement
5. Assess urgency and criticality

AVAILABLE PART CATEGORIES:
- Bearings (ball bearings, roller bearings, etc.)
- Filters (air, oil, hydraulic filters)
- Belts (V-belts, timing belts, conveyor belts)
- Seals (oil seals, gaskets, O-rings)
- Lubricants (greases, oils, additives)

Provide analysis in this JSON format:
{{
    "interpreted_query": "Clear interpretation of what the user is looking for",
    "part_category": "Most likely part category",
    "specifications": ["spec1", "spec2"],
    "search_keywords": ["keyword1", "keyword2"],
    "urgency_assessment": "low|medium|high|critical",
    "reasoning": "Why this interpretation makes sense",
    "confidence": 0.85
}}"""

        try:
            ai_response = await self.ai_orchestrator.intelligent_response(
                message=analysis_prompt,
                context="parts_search_analysis",
                complexity_level="medium"
            )
            
            if ai_response and ai_response.get("response"):
                # Try to parse JSON response
                import json
                response_text = ai_response["response"]
                
                json_start = response_text.find('{')
                json_end = response_text.rfind('}') + 1
                
                if json_start >= 0 and json_end > json_start:
                    json_text = response_text[json_start:json_end]
                    analysis_result = json.loads(json_text)
                    return analysis_result
                    
        except Exception as e:
            logger.warning(f"AI query analysis failed: {e}")
        
        return {
            "interpreted_query": request.query,
            "confidence": 0.5,
            "reasoning": "AI analysis unavailable"
        }
    
    def _semantic_parts_search(self, query: str, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Semantic search through parts database"""
        query_lower = query.lower()
        matching_parts = []
        
        for part in parts_db:
            score = 0
            
            # Direct matches get highest score
            if query_lower in part["part_number"].lower():
                score += 10
            if query_lower in part["name"].lower():
                score += 8
            if query_lower in part["description"].lower():
                score += 6
            if query_lower in part["category"].lower():
                score += 5
            
            # Asset compatibility bonus
            if asset_id and asset_id in part["compatible_assets"]:
                score += 15
            
            # Keyword matching
            keywords = query_lower.split()
            for keyword in keywords:
                for field in ["name", "description", "category", "manufacturer"]:
                    if keyword in part[field].lower():
                        score += 2
            
            # Add stock status factor
            if part["quantity_on_hand"] > 0:
                score += 3
            elif part["quantity_on_hand"] <= part["reorder_point"]:
                score += 1  # Still relevant but needs ordering
            
            if score > 0:
                part_with_score = part.copy()
                part_with_score["relevance_score"] = score
                matching_parts.append(part_with_score)
        
        # Sort by relevance score
        return sorted(matching_parts, key=lambda x: x["relevance_score"], reverse=True)
    
    async def _generate_part_suggestions(
        self, 
        request: AIPartsRequest, 
        query_analysis: Dict, 
        matching_parts: List[Dict]
    ) -> Dict[str, List[Dict]]:
        """Generate intelligent part suggestions"""
        
        primary_suggestions = []
        alternatives = []
        
        # Process top matching parts
        for i, part in enumerate(matching_parts[:request.max_results]):
            suggestion = part.copy()
            
            # Add intelligent insights
            suggestion["ai_insights"] = self._generate_part_insights(part, request)
            suggestion["stock_status"] = self._get_stock_status(part)
            suggestion["procurement_info"] = self._get_procurement_info(part)
            
            if i < 5:  # Top 5 as primary suggestions
                primary_suggestions.append(suggestion)
            else:  # Rest as alternatives
                alternatives.append(suggestion)
        
        # Generate AI-enhanced alternatives if we have the orchestrator
        if self.ai_orchestrator and len(primary_suggestions) < 3:
            ai_alternatives = await self._generate_ai_alternatives(request, query_analysis)
            alternatives.extend(ai_alternatives)
        
        return {
            "primary_suggestions": primary_suggestions,
            "alternatives": alternatives
        }
    
    def _generate_part_insights(self, part: Dict, request: AIPartsRequest) -> List[str]:
        """Generate intelligent insights about a part"""
        insights = []
        
        # Stock insights
        if part["quantity_on_hand"] == 0:
            insights.append("⚠️ Out of stock - immediate ordering required")
        elif part["quantity_on_hand"] <= part["reorder_point"]:
            insights.append("🔔 Low stock - consider reordering soon")
        elif part["quantity_on_hand"] > part["maximum_stock"]:
            insights.append("📦 Overstocked - good availability")
        
        # Compatibility insights
        if request.asset_id and request.asset_id in part["compatible_assets"]:
            insights.append("✅ Confirmed compatible with specified asset")
        
        # Cost insights
        if part["unit_cost"] > 50:
            insights.append("💰 High-value part - consider approval workflow")
        
        # Urgency-based insights
        if request.urgency == "critical" and part["quantity_on_hand"] > 0:
            insights.append("🚨 Available for immediate use - critical priority")
        
        return insights
    
    def _get_stock_status(self, part: Dict) -> Dict[str, Any]:
        """Get comprehensive stock status"""
        qty = part["quantity_on_hand"]
        reorder = part["reorder_point"]
        maximum = part["maximum_stock"]
        
        if qty == 0:
            status = "out_of_stock"
            level = "critical"
        elif qty <= reorder:
            status = "low_stock"
            level = "warning"
        elif qty > maximum:
            status = "overstocked"
            level = "info"
        else:
            status = "normal"
            level = "good"
        
        return {
            "status": status,
            "level": level,
            "quantity": qty,
            "reorder_point": reorder,
            "maximum_stock": maximum,
            "fill_percentage": (qty / maximum) * 100 if maximum > 0 else 0
        }
    
    def _get_procurement_info(self, part: Dict) -> Dict[str, Any]:
        """Get procurement information and recommendations"""
        return {
            "supplier": part["supplier"],
            "unit_cost": part["unit_cost"],
            "last_ordered": part.get("last_ordered"),
            "lead_time": "3-5 business days",  # Could be enhanced with real data
            "minimum_order_qty": 1,
            "bulk_discount_available": part["unit_cost"] > 20
        }
    
    async def _generate_ai_alternatives(self, request: AIPartsRequest, analysis: Dict) -> List[Dict]:
        """Generate AI-suggested alternative parts"""
        if not self.ai_orchestrator:
            return []
        
        try:
            alternatives_prompt = f"""PARTS ALTERNATIVES RECOMMENDATION

ORIGINAL REQUEST: {request.query}
ANALYSIS: {analysis.get('interpreted_query', '')}
CATEGORY: {analysis.get('part_category', 'Unknown')}

Based on the original request, suggest 2-3 alternative part numbers or types that could:
1. Serve the same function
2. Be compatible substitutes
3. Offer better value or availability

Consider:
- Cross-referenced part numbers
- Universal/generic alternatives
- Different manufacturers offering equivalent parts
- Upgraded versions with better performance

Format as simple list:
- Alternative 1: Description
- Alternative 2: Description"""

            ai_response = await self.ai_orchestrator.intelligent_response(
                message=alternatives_prompt,
                context="parts_alternatives",
                complexity_level="low"
            )
            
            if ai_response and ai_response.get("response"):
                # Parse AI suggestions and create mock part entries
                alternatives = []
                lines = ai_response["response"].split('\n')
                
                for line in lines:
                    if line.strip().startswith('-') or line.strip().startswith('•'):
                        alt_text = line.strip().lstrip('- ').lstrip('• ')
                        if len(alt_text) > 10:
                            alternatives.append({
                                "id": f"AI-ALT-{len(alternatives)+1}",
                                "name": alt_text,
                                "description": "AI-suggested alternative",
                                "category": "AI Recommendation",
                                "ai_generated": True,
                                "suggestion_reason": "AI-powered alternative recommendation"
                            })
                
                return alternatives[:3]
                
        except Exception as e:
            logger.warning(f"AI alternatives generation failed: {e}")
        
        return []
    
    def _traditional_parts_search(self, query: str) -> List[Dict[str, Any]]:
        """Fallback traditional search"""
        query_lower = query.lower()
        results = []
        
        for part in parts_db:
            if (query_lower in part["name"].lower() or 
                query_lower in part["description"].lower() or
                query_lower in part["part_number"].lower()):
                results.append(part)
        
        return results[:10]
    
    def _analyze_inventory_status(self, parts: List[Dict]) -> Dict[str, Any]:
        """Analyze overall inventory status"""
        total_parts = len(parts)
        in_stock = len([p for p in parts if p["quantity_on_hand"] > 0])
        low_stock = len([p for p in parts if p["quantity_on_hand"] <= p["reorder_point"]])
        out_of_stock = len([p for p in parts if p["quantity_on_hand"] == 0])
        
        return {
            "total_matching_parts": total_parts,
            "in_stock_count": in_stock,
            "low_stock_count": low_stock,
            "out_of_stock_count": out_of_stock,
            "availability_percentage": (in_stock / total_parts * 100) if total_parts > 0 else 0,
            "inventory_health": "good" if low_stock == 0 else "needs_attention" if low_stock < 3 else "critical"
        }
    
    async def _generate_procurement_recommendations(self, parts: List[Dict], urgency: str) -> List[str]:
        """Generate procurement recommendations"""
        recommendations = []
        
        out_of_stock_parts = [p for p in parts if p["quantity_on_hand"] == 0]
        low_stock_parts = [p for p in parts if 0 < p["quantity_on_hand"] <= p["reorder_point"]]
        
        if out_of_stock_parts:
            if urgency in ["critical", "high"]:
                recommendations.append("🚨 URGENT: Request emergency procurement for out-of-stock critical parts")
            else:
                recommendations.append("📋 Schedule procurement for out-of-stock parts")
        
        if low_stock_parts:
            recommendations.append(f"🔔 Consider reordering {len(low_stock_parts)} parts approaching reorder point")
        
        if urgency == "critical":
            recommendations.append("⚡ For critical needs, consider express shipping or local suppliers")
        
        return recommendations
    
    async def smart_inventory_analysis(self) -> SmartInventoryAnalysis:
        """Comprehensive AI-powered inventory analysis"""
        critical_alerts = []
        reorder_suggestions = []
        cost_optimizations = []
        ai_insights = []
        
        # Analyze all parts for issues
        for part in parts_db:
            # Critical stock alerts
            if part["quantity_on_hand"] == 0:
                critical_alerts.append({
                    "part_id": part["id"],
                    "part_name": part["name"],
                    "alert_type": "out_of_stock",
                    "severity": "critical",
                    "impact": f"Compatible with {len(part['compatible_assets'])} assets",
                    "action_required": "Immediate procurement"
                })
            
            # Reorder suggestions
            if part["quantity_on_hand"] <= part["reorder_point"]:
                suggested_qty = part["maximum_stock"] - part["quantity_on_hand"]
                reorder_suggestions.append({
                    "part_id": part["id"],
                    "part_name": part["name"],
                    "current_stock": part["quantity_on_hand"],
                    "suggested_order_qty": suggested_qty,
                    "estimated_cost": suggested_qty * part["unit_cost"],
                    "supplier": part["supplier"]
                })
            
            # Cost optimization opportunities
            if part["quantity_on_hand"] > part["maximum_stock"]:
                excess_value = (part["quantity_on_hand"] - part["maximum_stock"]) * part["unit_cost"]
                cost_optimizations.append({
                    "part_id": part["id"],
                    "part_name": part["name"],
                    "issue": "overstocked",
                    "excess_quantity": part["quantity_on_hand"] - part["maximum_stock"],
                    "tied_up_capital": excess_value,
                    "recommendation": "Consider using for planned maintenance or return to supplier"
                })
        
        # Generate AI insights
        if self.ai_orchestrator:
            try:
                insights_prompt = f"""INVENTORY ANALYSIS INSIGHTS

CURRENT STATUS:
- Critical alerts: {len(critical_alerts)}
- Reorder suggestions: {len(reorder_suggestions)}
- Cost optimization opportunities: {len(cost_optimizations)}
- Total parts analyzed: {len(parts_db)}

Generate 3-5 strategic insights about this inventory status:
1. Overall inventory health assessment
2. Risk analysis and priorities
3. Cost optimization recommendations
4. Strategic procurement suggestions"""

                ai_response = await self.ai_orchestrator.intelligent_response(
                    message=insights_prompt,
                    context="inventory_analysis",
                    complexity_level="medium"
                )
                
                if ai_response and ai_response.get("response"):
                    # Extract insights from response
                    lines = ai_response["response"].split('\n')
                    for line in lines:
                        if line.strip() and len(line.strip()) > 20:
                            ai_insights.append(line.strip())
                            
            except Exception as e:
                logger.warning(f"AI insights generation failed: {e}")
        
        if not ai_insights:
            ai_insights = [
                "Regular inventory analysis recommended",
                "Monitor reorder points for critical parts",
                "Consider supplier performance metrics"
            ]
        
        return SmartInventoryAnalysis(
            critical_stock_alerts=critical_alerts,
            reorder_suggestions=reorder_suggestions,
            cost_optimization_opportunities=cost_optimizations,
            usage_predictions={
                "projected_monthly_consumption": "Analysis requires historical data",
                "seasonal_trends": "Enable trend analysis with usage tracking"
            },
            ai_insights=ai_insights
        )

# Initialize AI Parts Intelligence
ai_parts_intelligence = AIPartsIntelligence()

# AI-Enhanced API Endpoints
@parts_router.post("/ai-search", response_model=AIPartsResponse)
async def ai_powered_parts_search(request: AIPartsRequest):
    """AI-powered intelligent parts search with recommendations"""
    return await ai_parts_intelligence.intelligent_parts_search(request)

@parts_router.get("/smart-inventory-analysis", response_model=SmartInventoryAnalysis)
async def get_smart_inventory_analysis():
    """Get comprehensive AI-powered inventory analysis"""
    return await ai_parts_intelligence.smart_inventory_analysis()

@parts_router.get("/ai-suggestions/{asset_id}")
async def get_ai_parts_suggestions_for_asset(asset_id: str, limit: int = 5):
    """Get AI-powered parts suggestions for a specific asset"""
    
    # Find parts compatible with the asset
    compatible_parts = [p for p in parts_db if asset_id in p.get("compatible_assets", [])]
    
    if not compatible_parts:
        return {
            "asset_id": asset_id,
            "suggestions": [],
            "message": "No parts found for this asset"
        }
    
    # Analyze and prioritize suggestions
    suggestions = []
    for part in compatible_parts[:limit]:
        stock_status = ai_parts_intelligence._get_stock_status(part)
        suggestion = {
            **part,
            "stock_status": stock_status,
            "recommendation_reason": []
        }
        
        # Add recommendation reasons
        if stock_status["level"] == "critical":
            suggestion["recommendation_reason"].append("Critical: Out of stock")
        elif stock_status["level"] == "warning":
            suggestion["recommendation_reason"].append("Warning: Low stock")
        else:
            suggestion["recommendation_reason"].append("Available in stock")
        
        suggestions.append(suggestion)
    
    return {
        "asset_id": asset_id,
        "suggestions": suggestions,
        "total_compatible_parts": len(compatible_parts)
    }

# Database Integration
if _PART_DB:
    try:
        eng = get_engine()
        from sqlalchemy import inspect  # type: ignore
        from db.database import Base  # type: ignore
        insp = inspect(eng)
        if 'parts' not in insp.get_table_names():
            Base.metadata.create_all(bind=eng)  # type: ignore
        with get_session() as s:  # type: ignore
            if not s.query(PartORM).first():  # type: ignore
                import json
                for p in parts_db:
                    rec = p.copy(); rec['compatible_assets'] = json.dumps(rec.get('compatible_assets', []))
                    s.add(PartORM(**rec))  # type: ignore
                s.commit()
    except Exception as e:  # pragma: no cover
        logger.warning(f"Parts DB init failed: {e}")

@parts_router.post("/identify")
async def identify_part_from_image(
    image: UploadFile = File(...),
    context: Optional[str] = Query(None, description="Additional context for identification")
):
    """Identify parts from uploaded image using OCR"""
    start_time = time.time()
    
    # Validate file type
    if not (image and image.content_type and image.content_type.startswith('image/')):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        # Import part identification from ai_voice_processor
        from ai_voice_processor import WorkOrderPartIdentifier
        
        part_identifier = WorkOrderPartIdentifier()
        
        # Read image data
        image_data = await image.read()
        
        # Add work order context if provided
        work_context = {"context": context} if context else None
        
        # Identify part from image
        identification_result = await part_identifier.identify_part_from_image(
            image_data, work_context
        )
        
        # Enhance candidates with our parts database information
        enhanced_candidates = []
        for candidate in identification_result.get('candidates', []):
            # Try to find matching parts in our database
            for part in parts_db:
                if (
                    candidate.get('part_number', '').upper() in part['part_number'].upper() or
                    any(keyword in part['name'].lower() for keyword in candidate.get('name', '').lower().split()) or
                    part['manufacturer'].lower() == candidate.get('manufacturer', '').lower()
                ):
                    enhanced_candidate = {
                        **candidate,
                        'in_our_inventory': True,
                        'our_part_id': part['id'],
                        'current_stock': part['quantity_on_hand'],
                        'our_cost': part['unit_cost'],
                        'location': part['location'],
                        'supplier': part['supplier']
                    }
                    enhanced_candidates.append(enhanced_candidate)
                    break
            else:
                # Not in our inventory
                enhanced_candidates.append({
                    **candidate,
                    'in_our_inventory': False,
                    'sourcing_needed': True
                })
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return {
            "success": True,
            "image_analysis": identification_result.get('image_analysis', ''),
            "candidates": enhanced_candidates,
            "overall_confidence": identification_result.get('overall_confidence', 0.0),
            "processing_time_ms": processing_time,
            "recommendations": identification_result.get('recommendations', []),
            "alternative_actions": identification_result.get('alternative_actions', [])
        }
        
    except Exception as e:
        logger.error(f"Part identification failed: {e}")
        return {
            "success": False,
            "error": str(e),
            "processing_time_ms": int((time.time() - start_time) * 1000),
            "recommendations": ["Try clearer image", "Check image format", "Use manual search"]
        }

@parts_router.get("/reorder/suggestions")
async def reorder_suggestions():
    """Suggest parts needing reorder based on reorder_point or min safety stock."""
    suggestions = []
    for p in parts_db:
        qty = p['quantity_on_hand']
        rp = p.get('reorder_point') or 0
        max_stock = p.get('maximum_stock') or (rp * 3 if rp else 0)
        if rp and qty <= rp:
            target = max_stock if max_stock > qty else qty + (rp * 2 if rp else 5)
            suggestions.append({
                'id': p['id'],
                'part_number': p['part_number'],
                'on_hand': qty,
                'reorder_point': rp,
                'suggest_order_qty': max(0, target - qty)
            })
    return { 'count': len(suggestions), 'suggestions': suggestions }

@parts_router.get("/kpis")
async def get_parts_kpis(period_days: int = Query(30, description="Period in days for KPI calculation")):
    """Get parts and inventory KPIs using industry-standard formulas"""
    try:
        # Stockouts - Parts with zero inventory when needed
        stockout_parts = [p for p in parts_db if p['quantity_on_hand'] == 0]
        stockouts_count = len(stockout_parts)
        
        # Fill Rate % - Assuming all parts in stock can fulfill requests
        total_parts = len(parts_db)
        in_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] > 0])
        fill_rate_pct = (in_stock_parts / total_parts * 100) if total_parts > 0 else 100
        
        # Inventory Turns - Using simplified calculation: average demand/average inventory
        # For demo: assume annual cost of goods sold based on current inventory value
        total_inventory_value = sum(p['quantity_on_hand'] * p['unit_cost'] for p in parts_db)
        # Simplified annual turns (industry average is 4-12 for most industries)
        inventory_turns = 6.5  # Demo value - in production calculate from actual data
        
        # Average Lead Time - from sample purchase orders
        lead_times = []
        for po in purchase_orders_db:
            if po['status'] == 'received':
                # Calculate lead time from sample data
                order_date = datetime.strptime(po['order_date'], '%Y-%m-%d')
                delivery_date = datetime.strptime(po['expected_delivery'], '%Y-%m-%d')
                lead_time = (delivery_date - order_date).days
                lead_times.append(lead_time)
        
        avg_lead_time_days = sum(lead_times) / len(lead_times) if lead_times else 7.0
        
        # Price Variance % - Compare current costs with previous costs
        price_variance_pct = 2.5  # Demo value - positive indicates cost increase
        
        # On-Time Delivery % - From purchase orders
        total_orders = len(purchase_orders_db)
        on_time_orders = len([po for po in purchase_orders_db if po['status'] in ['received', 'pending']])
        on_time_delivery_pct = (on_time_orders / total_orders * 100) if total_orders > 0 else 100
        
        # Spend Analytics
        mtd_spend = sum(po['total_cost'] for po in purchase_orders_db)
        ytd_spend = mtd_spend * 8  # Rough estimate for demo
        
        # Top vendors by spend
        vendor_spend = {}
        for po in purchase_orders_db:
            vendor = po['supplier']
            vendor_spend[vendor] = vendor_spend.get(vendor, 0) + po['total_cost']
        
        top_vendors = [
            {"vendor": vendor, "spend": spend, "percentage": (spend/mtd_spend)*100 if mtd_spend > 0 else 0}
            for vendor, spend in sorted(vendor_spend.items(), key=lambda x: x[1], reverse=True)[:5]
        ]
        
        # Top categories by value
        category_values = {}
        for part in parts_db:
            category = part['category']
            value = part['quantity_on_hand'] * part['unit_cost']
            category_values[category] = category_values.get(category, 0) + value
        
        top_categories = [
            {"category": category, "value": value, "percentage": (value/total_inventory_value)*100 if total_inventory_value > 0 else 0}
            for category, value in sorted(category_values.items(), key=lambda x: x[1], reverse=True)[:5]
        ]
        
        return {
            "period_days": period_days,
            "stockouts_count": stockouts_count,
            "fill_rate_pct": round(fill_rate_pct, 1),
            "inventory_turns": round(inventory_turns, 1),
            "avg_lead_time_days": round(avg_lead_time_days, 1),
            "price_variance_pct": round(price_variance_pct, 1),
            "on_time_delivery_pct": round(on_time_delivery_pct, 1),
            "spend_analytics": {
                "mtd_spend": round(mtd_spend, 2),
                "ytd_spend": round(ytd_spend, 2),
                "top_vendors": top_vendors,
                "top_categories": top_categories
            },
            "total_inventory_value": round(total_inventory_value, 2),
            "low_stock_count": len([p for p in parts_db if p['quantity_on_hand'] <= p['reorder_point']]),
            "generated_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"KPI calculation failed: {e}")
        raise HTTPException(status_code=500, detail=f"KPI calculation failed: {str(e)}")

# Sample purchase orders
purchase_orders_db = [
    {
        "id": "PO-001",
        "supplier": "Industrial Supply Co",
        "order_date": "2025-08-15",
        "expected_delivery": "2025-08-22",
        "status": "pending",
        "total_cost": 245.50,
        "parts": [
            {"part_id": "PRT-001", "quantity": 10, "unit_cost": 24.50}
        ]
    },
    {
        "id": "PO-002",
        "supplier": "Belt & Chain Co",
        "order_date": "2025-08-18",
        "expected_delivery": "2025-08-25",
        "status": "pending",
        "total_cost": 123.00,
        "parts": [
            {"part_id": "PRT-003", "quantity": 10, "unit_cost": 12.30}
        ]
    }
]

# Sample inventory transactions
inventory_transactions_db = [
    {
        "id": "TXN-001",
        "part_id": "PRT-001",
        "transaction_type": "issued",
        "quantity": -2,
        "work_order_id": "WO-001",
        "date": "2025-08-12",
        "notes": "Issued to compressor maintenance"
    },
    {
        "id": "TXN-002",
        "part_id": "PRT-002",
        "transaction_type": "received",
        "quantity": 5,
        "work_order_id": None,
        "date": "2025-08-10",
        "notes": "Received shipment - PO-003"
    },
    {
        "id": "TXN-003",
        "part_id": "PRT-005",
        "transaction_type": "issued",
        "quantity": -1,
        "work_order_id": "WO-002",
        "date": "2025-08-14",
        "notes": "Issued for conveyor belt maintenance"
    }
]

# Phase 2: Procurement Workflow Database Collections
vendors_db = [
    {
        "id": "VEN-001",
        "name": "Industrial Supply Co",
        "contact_email": "orders@industrialsupply.com",
        "contact_phone": "(555) 123-4567",
        "contact_person": "Sarah Johnson",
        "address": "123 Industrial Way, Manufacturing City, ST 12345",
        "terms": "NET30",
        "default_lead_days": 5,
        "rating": 4.5,
        "active": True,
        "created_at": "2024-01-15",
        "updated_at": "2025-08-01",
        "notes": "Primary supplier for bearings and seals"
    },
    {
        "id": "VEN-002",
        "name": "Filter Solutions",
        "contact_email": "sales@filtersolutions.com", 
        "contact_phone": "(555) 234-5678",
        "contact_person": "Mike Chen",
        "address": "456 Filter Ave, Clean City, ST 23456",
        "terms": "NET30",
        "default_lead_days": 3,
        "rating": 4.8,
        "active": True,
        "created_at": "2024-02-01",
        "updated_at": "2025-07-15",
        "notes": "Specializes in air and fluid filters"
    },
    {
        "id": "VEN-003",
        "name": "Belt & Chain Co",
        "contact_email": "info@beltchain.com",
        "contact_phone": "(555) 345-6789",
        "contact_person": "Tom Rodriguez",
        "address": "789 Power Dr, Belt Town, ST 34567", 
        "terms": "NET15",
        "default_lead_days": 7,
        "rating": 4.2,
        "active": True,
        "created_at": "2024-03-10",
        "updated_at": "2025-06-20",
        "notes": "Power transmission components"
    },
    {
        "id": "VEN-004",
        "name": "Emergency Parts Express",
        "contact_email": "rush@emergencyparts.com",
        "contact_phone": "(555) 911-PART",
        "contact_person": "Jessica Wong",
        "address": "999 Rush St, Fast City, ST 99999",
        "terms": "NET7",
        "default_lead_days": 1,
        "rating": 3.9,
        "active": True,
        "created_at": "2024-05-01",
        "updated_at": "2025-08-15",
        "notes": "Emergency and rush orders - premium pricing"
    }
]

purchase_requests_db = []
rfqs_db = []  
quotes_db = []
purchase_orders_extended_db = []
receiving_db = []

# Approval thresholds for procurement workflow
APPROVAL_THRESHOLDS = {
    "auto_approve": 1000.00,      # Under $1K auto-approved
    "manager_approve": 10000.00,  # $1K-$10K needs manager
    "admin_approve": float('inf') # Over $10K needs admin
}

@parts_router.get("/dashboard", response_class=HTMLResponse)
async def parts_dashboard():
    """Parts inventory dashboard with comprehensive overview and management"""
    from fastapi.templating import Jinja2Templates
    import os
    
    # Use optimized template system
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    templates = Jinja2Templates(directory=template_dir)
    
    total_parts = len(parts_db)
    low_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] <= p['reorder_point']])
    out_of_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] == 0])
    pending_orders = len([po for po in purchase_orders_db if po['status'] == 'pending'])
    total_inventory_value = sum(p['quantity_on_hand'] * p['unit_cost'] for p in parts_db)
    in_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] > p['reorder_point']])
    
    # Prepare data for optimized template
    stats = {
        "active_workorders": in_stock_parts,
        "total_assets": total_parts, 
        "parts_in_stock": in_stock_parts,
        "system_health": round((in_stock_parts/total_parts)*100) if total_parts > 0 else 0
    }
    
    recent_workorders = []
    for i, part in enumerate(parts_db[:5]):
        status = "In Stock" if part['quantity_on_hand'] > part['reorder_point'] else "Low Stock" if part['quantity_on_hand'] > 0 else "Out of Stock"
        recent_workorders.append({
            "id": part['id'],
            "title": f"Part: {part['part_number']}",
            "asset_name": part['description'][:30] + "...",
            "technician": part.get('supplier', 'N/A'),
            "status": status,
            "priority": "High" if part['quantity_on_hand'] == 0 else "Medium" if part['quantity_on_hand'] <= part['reorder_point'] else "Low"
        })
    
    top_assets = []
    for part in parts_db[:5]:
        health_score = 95 if part['quantity_on_hand'] > part['reorder_point'] else 50 if part['quantity_on_hand'] > 0 else 10
        top_assets.append({
            "name": part['part_number'],
            "health_score": health_score,
            "status": "In Stock" if part['quantity_on_hand'] > 0 else "Out of Stock",
            "last_maintenance": f"Qty: {part['quantity_on_hand']}"
        })
    
    # Mock request for template
    class MockRequest:
        def __init__(self):
            self.url = type('obj', (object,), {'path': '/cmms/parts/dashboard'})()
            
        def get(self, key, default=None):
            return default
    
    return templates.TemplateResponse("dashboard-rich.html", {
        "request": MockRequest(),
        "module_name": "Parts Inventory Management",
        "stats": stats,
        "recent_workorders": recent_workorders,
        "top_assets": top_assets,
        "ai_stats": {"predictions_today": 12, "automation_rate": 75, "response_time": 1.9},
        "ai_activities": [
            {"icon": "📦", "title": "Inventory Analysis", "description": f"{low_stock_parts} parts need reordering", "timestamp": "14:30", "confidence": 88}
        ],
        "performance": {"dashboard_load": 1.8, "ai_response": 1.9, "health_check": 7.8},
        "metrics": {"uptime": 98.2, "api_success": 98.9, "satisfaction": 4.8, "cost_savings": int(total_inventory_value)},
        "recent_activities": [
            {"timestamp": "14:25", "icon": "📦", "type": "Inventory", "description": "Stock level updated", "user": "System", "module": "Parts", "status": "Success"}
        ]
    })

# Legacy return for reference
def parts_dashboard_legacy():
    total_parts = len(parts_db)
    low_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] <= p['reorder_point']])
    out_of_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] == 0])
    pending_orders = len([po for po in purchase_orders_db if po['status'] == 'pending'])
    total_inventory_value = sum(p['quantity_on_hand'] * p['unit_cost'] for p in parts_db)
    in_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] > p['reorder_point']])
    
    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix Parts Management</title>
        <style>
            {base_styles}
            {nav_styles}
            
            /* Parts Dashboard Content */
            .header {{ 
                padding: 3rem 2rem 2rem;
                text-align: center;
            }}
            .header h1 {{ 
                font-size: 3rem; 
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }}
            .container {{ 
                max-width: 1400px; 
                margin: 0 auto; 
                padding: 0 2rem 2rem; 
            }}
            .stats-grid {{ 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                gap: 2rem; 
                margin-bottom: 3rem;
            }}
            .stat-card {{ 
                background: rgba(255,255,255,0.15); 
                border-radius: 15px; 
                padding: 2rem; 
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                text-align: center;
                transition: transform 0.3s ease;
            }}
            .stat-card:hover {{
                transform: translateY(-5px);
            }}
            .stat-value {{
                font-size: 3rem;
                font-weight: bold;
                color: #38ef7d;
                display: block;
                margin-bottom: 0.5rem;
            }}
            .stat-value.warning {{
                color: #fbbf24;
            }}
            .stat-value.critical {{
                color: #f87171;
            }}
            .stat-label {{
                color: rgba(255,255,255,0.8);
                font-size: 1.1rem;
            }}
            
            .parts-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 2rem;
                margin-top: 2rem;
            }}
            .parts-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }}
            .parts-card.low-stock {{
                border-left: 4px solid #fbbf24;
            }}
            .parts-card.out-of-stock {{
                border-left: 4px solid #f87171;
            }}
            .parts-card.in-stock {{
                border-left: 4px solid #38ef7d;
            }}
            .parts-title {{
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            }}
            .btn {{ 
                background: #4299e1; 
                color: white; 
                border: none; 
                padding: 0.75rem 1.5rem; 
                border-radius: 8px; 
                cursor: pointer; 
                margin: 0.5rem; 
                font-size: 1rem;
                transition: all 0.3s ease;
            }}
            .btn:hover {{ 
                background: #3182ce; 
                transform: translateY(-2px);
            }}
            .btn-success {{ background: #38a169; }}
            .btn-success:hover {{ background: #2f855a; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-warning:hover {{ background: #b7791f; }}
            .btn-danger {{ background: #e53e3e; }}
            .btn-danger:hover {{ background: #c53030; }}
            .btn-sm {{ 
                padding: 0.5rem 1rem; 
                font-size: 0.875rem; 
                margin: 0.25rem;
            }}
            
            .filter-bar {{ 
                background: rgba(255,255,255,0.1); 
                padding: 1.5rem; 
                border-radius: 15px; 
                margin-bottom: 2rem; 
                display: flex; 
                gap: 1rem; 
                align-items: center;
                flex-wrap: wrap;
                backdrop-filter: blur(10px);
            }}
            .filter-bar select, .filter-bar input {{ 
                padding: 0.75rem; 
                border: 1px solid rgba(255,255,255,0.3); 
                border-radius: 8px;
                background: rgba(255,255,255,0.1);
                color: white;
                backdrop-filter: blur(10px);
            }}
            .filter-bar select option {{
                background: #2d3748;
                color: white;
            }}
            .filter-bar input::placeholder {{
                color: rgba(255,255,255,0.6);
            }}
            
            /* Tab Styles */
            .tab-btn {{ 
                background: none; 
                border: none; 
                color: rgba(255,255,255,0.7); 
                padding: 1rem 2rem; 
                cursor: pointer; 
                font-size: 1.1rem; 
                border-bottom: 2px solid transparent;
                transition: all 0.3s ease;
            }}
            .tab-btn:hover {{ 
                color: white; 
                background: rgba(255,255,255,0.1);
            }}
            .tab-btn.active {{ 
                color: #38ef7d; 
                border-bottom-color: #38ef7d; 
                background: rgba(56, 239, 125, 0.1);
            }}
            
            .tab-content {{ 
                display: none; 
            }}
            .tab-content.active {{ 
                display: block; 
            }}
            
            /* Procurement Styles */
            .procurement-dashboard {{
                display: grid;
                gap: 2rem;
            }}
            
            .procurement-stats {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-bottom: 2rem;
            }}
            
            .procurement-actions {{
                display: flex;
                gap: 1rem;
                flex-wrap: wrap;
                margin-bottom: 2rem;
            }}
            
            .workflow-cards {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 1rem;
            }}
            
            .workflow-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 8px;
                padding: 1.5rem;
                border-left: 4px solid #4299e1;
            }}
            
            .workflow-card.urgent {{
                border-left-color: #f56565;
            }}
            
            .workflow-card.completed {{
                border-left-color: #38a169;
            }}
            
            /* Analytics Styles */
            .analytics-dashboard {{
                display: grid;
                gap: 2rem;
            }}
            
            .analytics-section {{
                background: rgba(255,255,255,0.05);
                border-radius: 15px;
                padding: 2rem;
            }}
            
            .analytics-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
                margin-top: 1rem;
            }}
            
            .vendor-performance {{
                margin-top: 1rem;
            }}
            
            .vendor-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 8px;
                padding: 1rem;
                margin-bottom: 1rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }}
            
            /* Vendors Styles */
            .vendors-dashboard {{
                display: grid;
                gap: 2rem;
            }}
            
            .vendors-actions {{
                display: flex;
                gap: 1rem;
                margin-bottom: 2rem;
            }}
            
            .vendors-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
                gap: 1rem;
            }}
            
            .vendor-detail-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 12px;
                padding: 1.5rem;
                border: 1px solid rgba(255,255,255,0.2);
            }}
            
            .vendor-header {{
                display: flex;
                justify-content: space-between;
                align-items: start;
                margin-bottom: 1rem;
            }}
            
            .vendor-rating {{
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }}
            
            .rating-stars {{
                color: #fbbf24;
                font-size: 1.2rem;
            }}
        </style>
    </head>
    <body>
        {nav_html}
        
        <!-- Header -->
        <div class="header">
            <h1>📦 Parts Management</h1>
            <p>Inventory Control, Ordering & Stock Management</p>
        </div>
        
        <!-- Main Content -->
        <div class="container">
            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value">{total_parts}</span>
                    <span class="stat-label">Total Parts</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">{in_stock_parts}</span>
                    <span class="stat-label">In Stock</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value warning">{low_stock_parts}</span>
                    <span class="stat-label">Low Stock Alert</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value critical">{out_of_stock_parts}</span>
                    <span class="stat-label">Out of Stock</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">{pending_orders}</span>
                    <span class="stat-label">Pending Orders</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">${total_inventory_value:,.0f}</span>
                    <span class="stat-label">Total Inventory Value</span>
                </div>
            </div>
            
            <!-- Navigation Tabs -->
            <div style="margin-bottom: 2rem;">
                <div style="display: flex; border-bottom: 2px solid rgba(255,255,255,0.2);">
                    <button class="tab-btn active" onclick="showTab('inventory')" id="inventoryTab">
                        📦 Inventory
                    </button>
                    <button class="tab-btn" onclick="showTab('procurement')" id="procurementTab">
                        🛒 Procurement
                    </button>
                    <button class="tab-btn" onclick="showTab('analytics')" id="analyticsTab">
                        📊 Analytics
                    </button>
                    <button class="tab-btn" onclick="showTab('vendors')" id="vendorsTab">
                        🏢 Vendors
                    </button>
                </div>
            </div>

            <!-- Inventory Tab Content -->
            <div id="inventoryContent" class="tab-content active">
                <!-- Filter Bar -->
                <div class="filter-bar">
                    <label style="color: rgba(255,255,255,0.9); font-weight: 500;">Filter by:</label>
                    <select id="categoryFilter" onchange="filterParts()">
                        <option value="">All Categories</option>
                        <option value="Bearings">Bearings</option>
                        <option value="Filters">Filters</option>
                        <option value="Belts">Belts</option>
                        <option value="Seals">Seals</option>
                        <option value="Lubricants">Lubricants</option>
                        <option value="Electrical">Electrical</option>
                        <option value="Consumables">Consumables</option>
                    </select>
                    <select id="stockFilter" onchange="filterParts()">
                        <option value="">All Stock Levels</option>
                        <option value="in_stock">In Stock</option>
                        <option value="low_stock">Low Stock</option>
                        <option value="out_of_stock">Out of Stock</option>
                    </select>
                    <select id="supplierFilter" onchange="filterParts()">
                        <option value="">All Suppliers</option>
                        <option value="Industrial Supply Co">Industrial Supply Co</option>
                        <option value="Bearings Direct">Bearings Direct</option>
                        <option value="Filter Solutions">Filter Solutions</option>
                        <option value="Belt & Chain Co">Belt & Chain Co</option>
                    </select>
                    <input type="text" id="searchFilter" placeholder="Search parts..." onkeyup="filterParts()">
                    <div style="margin-left: auto;">
                        <button class="btn btn-success" onclick="addPart()">Add New Part</button>
                        <button class="btn btn-warning" onclick="createPurchaseRequest()">Create PR</button>
                        <button class="btn" onclick="window.location.href='/cmms/parts/manuals'">📚 Manuals</button>
                    </div>
                </div>
                
                <!-- Parts Grid -->
                <div class="parts-grid" id="partsGrid">
                    {parts_html}
                </div>
            </div>

            <!-- Procurement Tab Content -->
            <div id="procurementContent" class="tab-content">
                <div class="procurement-dashboard">
                    <div class="procurement-stats">
                        <div class="stat-card">
                            <span class="stat-value" id="pendingPRs">0</span>
                            <span class="stat-label">Pending PRs</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value" id="activeRFQs">0</span>
                            <span class="stat-label">Active RFQs</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value" id="pendingApprovals">0</span>
                            <span class="stat-label">Pending Approvals</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value" id="monthlySpend">$0</span>
                            <span class="stat-label">Monthly Spend</span>
                        </div>
                    </div>
                    
                    <div class="procurement-actions">
                        <button class="btn btn-success" onclick="createPurchaseRequest()">
                            ➕ Create Purchase Request
                        </button>
                        <button class="btn" onclick="viewPurchaseRequests()">
                            📋 View PRs
                        </button>
                        <button class="btn" onclick="viewRFQs()">
                            📤 View RFQs  
                        </button>
                        <button class="btn" onclick="viewQuoteComparisons()">
                            ⚖️ Compare Quotes
                        </button>
                        <button class="btn" onclick="viewPurchaseOrders()">
                            🛒 Purchase Orders
                        </button>
                    </div>
                    
                    <div class="workflow-status">
                        <h3>Procurement Workflow Status</h3>
                        <div id="procurementWorkflows" class="workflow-cards">
                            <!-- Dynamic content loaded here -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Analytics Tab Content -->
            <div id="analyticsContent" class="tab-content">
                <div class="analytics-dashboard">
                    <div class="analytics-section">
                        <h3>📊 Procurement Analytics</h3>
                        <div class="analytics-grid" id="analyticsGrid">
                            <!-- Dynamic content loaded here -->
                        </div>
                    </div>
                    
                    <div class="analytics-section">
                        <h3>📈 Vendor Performance</h3>
                        <div class="vendor-performance" id="vendorPerformance">
                            <!-- Dynamic content loaded here -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Vendors Tab Content -->
            <div id="vendorsContent" class="tab-content">
                <div class="vendors-dashboard">
                    <div class="vendors-actions">
                        <button class="btn btn-success" onclick="addVendor()">
                            ➕ Add Vendor
                        </button>
                        <button class="btn" onclick="refreshVendors()">
                            🔄 Refresh
                        </button>
                    </div>
                    
                    <div class="vendors-grid" id="vendorsGrid">
                        <!-- Dynamic content loaded here -->
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            {nav_js}
            function toggleNav() {{
                const nav = document.getElementById('navbarNav');
                nav.classList.toggle('show');
            }}
            
            // Close mobile nav when clicking outside
            document.addEventListener('click', function(event) {{
                const nav = document.getElementById('navbarNav');
                const toggle = document.querySelector('.navbar-toggle');
                if (!nav.contains(event.target) && !toggle.contains(event.target)) {{
                    nav.classList.remove('show');
                }}
            }});
            
            function filterParts() {{
                const categoryFilter = document.getElementById('categoryFilter').value;
                const stockFilter = document.getElementById('stockFilter').value;
                const supplierFilter = document.getElementById('supplierFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const partCards = document.querySelectorAll('.parts-card');
                partCards.forEach(card => {{
                    const category = card.dataset.category;
                    const supplier = card.dataset.supplier;
                    const stockLevel = card.dataset.stockLevel;
                    const name = card.dataset.name.toLowerCase();
                    
                    const categoryMatch = !categoryFilter || category === categoryFilter;
                    const supplierMatch = !supplierFilter || supplier === supplierFilter;
                    const stockMatch = !stockFilter || stockLevel === stockFilter;
                    const searchMatch = !searchFilter || name.includes(searchFilter);
                    
                    card.style.display = (categoryMatch && supplierMatch && stockMatch && searchMatch) ? 'block' : 'none';
                }});
            }}
            
            function addPart() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; max-height: 90%; overflow-y: auto;" onclick="event.stopPropagation()">
                            <h3>Add New Part</h3>
                            <form id="addPartForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Part Number:</label>
                                    <input type="text" name="part_number" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Part Name:</label>
                                    <input type="text" name="name" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Description:</label>
                                    <textarea name="description" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 60px;"></textarea>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Category:</label>
                                        <select name="category" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="">Select Category</option>
                                            <option value="Mechanical">Mechanical</option>
                                            <option value="Electrical">Electrical</option>
                                            <option value="Hydraulic">Hydraulic</option>
                                            <option value="Pneumatic">Pneumatic</option>
                                            <option value="Consumable">Consumable</option>
                                            <option value="Safety">Safety</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Unit:</label>
                                        <select name="unit" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="each">Each</option>
                                            <option value="box">Box</option>
                                            <option value="gallon">Gallon</option>
                                            <option value="liter">Liter</option>
                                            <option value="meter">Meter</option>
                                            <option value="kg">Kilogram</option>
                                            <option value="pound">Pound</option>
                                        </select>
                                    </div>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Unit Cost:</label>
                                        <input type="number" step="0.01" name="unit_cost" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                    <div>
                                        <label>Min Stock:</label>
                                        <input type="number" name="min_stock" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                    <div>
                                        <label>Max Stock:</label>
                                        <input type="number" name="max_stock" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Location:</label>
                                    <input type="text" name="location" required placeholder="e.g., Warehouse A-1-3" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Supplier:</label>
                                    <input type="text" name="supplier" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" style="padding: 0.5rem 1rem; background: #38a169; color: white; border: none; border-radius: 4px;">Add Part</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('addPartForm').addEventListener('submit', function(e) {{
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const partData = Object.fromEntries(formData);
                    
                    fetch('/parts/', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(partData)
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        alert('Part added successfully!');
                        document.body.removeChild(document.querySelector('[onclick="closeModal(event)"]'));
                        location.reload();
                    }})
                    .catch(error => {{
                        alert('Error adding part: ' + error.message);
                    }});
                }});
            }}
            
            function closeModal(event) {{
                if (event.target === event.currentTarget) {{
                    document.body.removeChild(event.currentTarget);
                }}
            }}
            
            function viewPartDetails(partId) {{
                window.open(`/cmms/parts/${{partId}}/view`, '_blank');
            }}
            
            function adjustStock(partId, currentStock) {{
                const newQuantity = prompt(`Current stock: ${{currentStock}}\\nEnter new quantity:`);
                const reason = prompt('Reason for adjustment:');
                
                if (newQuantity !== null && newQuantity !== '' && reason) {{
                    fetch(`/parts/${{partId}}/adjust-stock`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            new_quantity: parseInt(newQuantity),
                            reason: reason
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        alert('Stock adjusted successfully!');
                        location.reload();
                    }})
                    .catch(error => {{
                        alert('Error adjusting stock: ' + error.message);
                    }});
                }}
            }}
            
            function issuePart(partId) {{
                const quantity = prompt('Enter quantity to issue:');
                const workOrder = prompt('Work order ID (optional):');
                
                if (quantity !== null && quantity !== '') {{
                    fetch(`/parts/${{partId}}/issue`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            quantity: parseInt(quantity),
                            work_order_id: workOrder || null,
                            notes: 'Issued from parts dashboard'
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        alert('Part issued successfully!');
                        location.reload();
                    }})
                    .catch(error => {{
                        alert('Error issuing part: ' + error.message);
                    }});
                }}
            }}
            
            function orderPart(partId) {{
                window.location.href = `/cmms/parts/${{partId}}/order`;
            }}
            
            function createPurchaseOrder() {{
                alert('Create purchase order functionality');
            }}
            
            // =============================================================================
            // Procurement Dashboard JavaScript Functions
            // =============================================================================
            
            function showTab(tabName) {{
                // Hide all tab content
                document.querySelectorAll('.tab-content').forEach(content => {{
                    content.classList.remove('active');
                }});
                
                // Remove active class from all tabs
                document.querySelectorAll('.tab-btn').forEach(tab => {{
                    tab.classList.remove('active');
                }});
                
                // Show selected tab content
                document.getElementById(tabName + 'Content').classList.add('active');
                document.getElementById(tabName + 'Tab').classList.add('active');
                
                // Load tab-specific data
                switch(tabName) {{
                    case 'procurement':
                        loadProcurementData();
                        break;
                    case 'analytics':
                        loadAnalyticsData();
                        break;
                    case 'vendors':
                        loadVendorsData();
                        break;
                }}
            }}
            
            async function loadProcurementData() {{
                try {{
                    // Load purchase requests
                    const prResponse = await fetch('/parts/purchase-requests');
                    const purchaseRequests = await prResponse.json();
                    
                    // Update procurement stats
                    document.getElementById('pendingPRs').textContent = 
                        purchaseRequests.filter(pr => pr.status === 'draft' || pr.status === 'submitted').length;
                    
                    // Load procurement analytics for monthly spend
                    const analyticsResponse = await fetch('/parts/analytics/procurement?period_days=30');
                    const analytics = await analyticsResponse.json();
                    
                    document.getElementById('monthlySpend').textContent = 
                        '$' + analytics.total_spend.toLocaleString();
                    
                    // Load workflow cards
                    loadWorkflowCards(purchaseRequests);
                    
                }} catch (error) {{
                    console.error('Failed to load procurement data:', error);
                }}
            }}
            
            function loadWorkflowCards(purchaseRequests) {{
                const workflowContainer = document.getElementById('procurementWorkflows');
                
                if (purchaseRequests.length === 0) {{
                    workflowContainer.innerHTML = '<p style="text-align: center; color: rgba(255,255,255,0.7);">No active procurement workflows</p>';
                    return;
                }}
                
                const workflowHtml = purchaseRequests.slice(0, 6).map(pr => {{
                    const statusClass = pr.priority === 'critical' ? 'urgent' : 
                                      pr.status === 'approved' ? 'completed' : '';
                    const priorityIcon = pr.priority === 'critical' ? '🚨' : 
                                       pr.priority === 'urgent' ? '⚡' : '📋';
                    
                    return `
                        <div class="workflow-card ${{statusClass}}">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                                <div>
                                    <h4 style="margin: 0; color: white;">${{priorityIcon}} ${{pr.id}}</h4>
                                    <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.8); font-size: 0.9rem;">
                                        ${{pr.lines.length}} line items • $$${{pr.total_estimated.toFixed(2)}}
                                    </p>
                                </div>
                                <span style="background: rgba(255,255,255,0.2); padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.8rem;">
                                    ${{pr.status.toUpperCase()}}
                                </span>
                            </div>
                            
                            <div style="margin-bottom: 1rem;">
                                <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Requested by:</div>
                                <div style="color: white; font-weight: 500;">${{pr.requested_by}}</div>
                            </div>
                            
                            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                <button class="btn btn-sm" onclick="viewPurchaseRequest('${{pr.id}}')">View Details</button>
                                ${{pr.status === 'draft' ? 
                                    '<button class="btn btn-sm btn-success" onclick="createRFQFromPR(\'' + pr.id + '\')">Create RFQ</button>' : ''}}
                                ${{pr.status === 'pending_approval' ? 
                                    '<button class="btn btn-sm btn-warning" onclick="approvePR(\'' + pr.id + '\')">Approve</button>' : ''}}
                            </div>
                        </div>
                    `;
                }}).join('');
                
                workflowContainer.innerHTML = workflowHtml;
            }}
            
            async function loadAnalyticsData() {{
                try {{
                    const response = await fetch('/parts/analytics/procurement?period_days=30');
                    const analytics = await response.json();
                    
                    const analyticsHtml = `
                        <div class="stat-card">
                            <span class="stat-value">$$${{analytics.total_spend.toLocaleString()}}</span>
                            <span class="stat-label">Total Spend (30d)</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value">$$${{analytics.cost_savings.toLocaleString()}}</span>
                            <span class="stat-label">Cost Savings</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value">${{analytics.purchase_orders_count}}</span>
                            <span class="stat-label">Purchase Orders</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value">${{analytics.avg_approval_time_hours.toFixed(1)}}h</span>
                            <span class="stat-label">Avg Approval Time</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value">${{analytics.procurement_cycle_time_days.toFixed(1)}} days</span>
                            <span class="stat-label">Cycle Time</span>
                        </div>
                    `;
                    
                    document.getElementById('analyticsGrid').innerHTML = analyticsHtml;
                    
                    // Load vendor performance
                    const vendorHtml = analytics.vendor_performance.slice(0, 5).map(vendor => `
                        <div class="vendor-card">
                            <div>
                                <div style="font-weight: bold; color: white;">${{vendor.vendor_name}}</div>
                                <div style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">
                                    ${{vendor.total_orders}} orders • $$${{vendor.total_spend_ytd.toLocaleString()}}
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div style="color: #38ef7d; font-weight: bold;">${{vendor.on_time_delivery_pct}}%</div>
                                <div style="color: rgba(255,255,255,0.7); font-size: 0.8rem;">On-time</div>
                            </div>
                        </div>
                    `).join('');
                    
                    document.getElementById('vendorPerformance').innerHTML = vendorHtml;
                    
                }} catch (error) {{
                    console.error('Failed to load analytics data:', error);
                }}
            }}
            
            async function loadVendorsData() {{
                try {{
                    const response = await fetch('/parts/vendors');
                    const vendors = await response.json();
                    
                    const vendorsHtml = vendors.map(vendor => {{
                        const stars = '★'.repeat(Math.floor(vendor.rating)) + 
                                     '☆'.repeat(5 - Math.floor(vendor.rating));
                        
                        return `
                            <div class="vendor-detail-card">
                                <div class="vendor-header">
                                    <div>
                                        <h4 style="margin: 0; color: white;">${{vendor.name}}</h4>
                                        <div style="color: rgba(255,255,255,0.8); margin-top: 0.25rem;">
                                            ${{vendor.contact_person || 'No contact person'}}
                                        </div>
                                    </div>
                                    <div class="vendor-rating">
                                        <span class="rating-stars">${{stars}}</span>
                                        <span style="color: white; font-weight: bold;">${{vendor.rating.toFixed(1)}}</span>
                                    </div>
                                </div>
                                
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 1rem 0;">
                                    <div>
                                        <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Email:</div>
                                        <div style="color: white; font-size: 0.9rem;">${{vendor.contact_email || 'N/A'}}</div>
                                    </div>
                                    <div>
                                        <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Phone:</div>
                                        <div style="color: white; font-size: 0.9rem;">${{vendor.contact_phone || 'N/A'}}</div>
                                    </div>
                                    <div>
                                        <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Terms:</div>
                                        <div style="color: white; font-size: 0.9rem;">${{vendor.terms}}</div>
                                    </div>
                                    <div>
                                        <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Lead Time:</div>
                                        <div style="color: white; font-size: 0.9rem;">${{vendor.default_lead_days}} days</div>
                                    </div>
                                </div>
                                
                                <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                                    <button class="btn btn-sm" onclick="editVendor('${{vendor.id}}')">Edit</button>
                                    <button class="btn btn-sm btn-success" onclick="createRFQWithVendor('${{vendor.id}}')">Send RFQ</button>
                                </div>
                            </div>
                        `;
                    }}).join('');
                    
                    document.getElementById('vendorsGrid').innerHTML = vendorsHtml;
                    
                }} catch (error) {{
                    console.error('Failed to load vendors data:', error);
                }}
            }}
            
            // Procurement Action Functions
            function createPurchaseRequest() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; max-height: 90%; overflow-y: auto; color: black;" onclick="event.stopPropagation()">
                            <h3>Create Purchase Request</h3>
                            <form id="createPRForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Priority:</label>
                                    <select name="priority" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="normal">Normal</option>
                                        <option value="urgent">Urgent</option>
                                        <option value="critical">Critical</option>
                                    </select>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Need By Date:</label>
                                    <input type="date" name="need_by_date" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Justification:</label>
                                    <textarea name="justification" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 80px;" placeholder="Reason for this purchase request..."></textarea>
                                </div>
                                
                                <h4>Line Items</h4>
                                <div id="prLines">
                                    <div class="pr-line" style="border: 1px solid #ccc; padding: 1rem; margin-bottom: 1rem; border-radius: 4px;">
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                            <div>
                                                <label>Description:</label>
                                                <input type="text" name="description[]" required style="width: 100%; padding: 0.5rem;">
                                            </div>
                                            <div>
                                                <label>Quantity:</label>
                                                <input type="number" name="quantity[]" required min="1" style="width: 100%; padding: 0.5rem;">
                                            </div>
                                        </div>
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                            <div>
                                                <label>Estimated Cost:</label>
                                                <input type="number" step="0.01" name="estimated_cost[]" style="width: 100%; padding: 0.5rem;">
                                            </div>
                                            <div>
                                                <label>Part ID (optional):</label>
                                                <input type="text" name="part_id[]" style="width: 100%; padding: 0.5rem;">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div style="text-align: center; margin: 1rem 0;">
                                    <button type="button" onclick="addPRLine()" style="background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer;">Add Line Item</button>
                                </div>
                                
                                <div style="text-align: right; margin-top: 1rem;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" style="padding: 0.5rem 1rem; background: #38a169; color: white; border: none; border-radius: 4px;">Create PR</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('createPRForm').addEventListener('submit', async function(e) {{
                    e.preventDefault();
                    
                    const formData = new FormData(e.target);
                    const descriptions = formData.getAll('description[]');
                    const quantities = formData.getAll('quantity[]');
                    const costs = formData.getAll('estimated_cost[]');
                    const partIds = formData.getAll('part_id[]');
                    
                    const lines = descriptions.map((desc, index) => ({{
                        description: desc,
                        quantity: parseInt(quantities[index]),
                        estimated_cost: costs[index] ? parseFloat(costs[index]) : null,
                        part_id: partIds[index] || null
                    }}));
                    
                    const prData = {{
                        lines: lines,
                        priority: formData.get('priority'),
                        need_by_date: formData.get('need_by_date') || null,
                        justification: formData.get('justification') || null
                    }};
                    
                    try {{
                        const response = await fetch('/parts/purchase-request', {{
                            method: 'POST',
                            headers: {{ 'Content-Type': 'application/json' }},
                            body: JSON.stringify(prData)
                        }});
                        
                        if (response.ok) {{
                            const result = await response.json();
                            alert('Purchase Request created successfully: ' + result.id);
                            document.body.removeChild(document.querySelector('[onclick="closeModal(event)"]'));
                            if (document.getElementById('procurementContent').classList.contains('active')) {{
                                loadProcurementData();
                            }}
                        }} else {{
                            const error = await response.text();
                            alert('Error creating PR: ' + error);
                        }}
                    }} catch (error) {{
                        alert('Error creating PR: ' + error.message);
                    }}
                }});
            }}
            
            function addPRLine() {{
                const linesContainer = document.getElementById('prLines');
                const lineHtml = `
                    <div class="pr-line" style="border: 1px solid #ccc; padding: 1rem; margin-bottom: 1rem; border-radius: 4px;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                            <div>
                                <label>Description:</label>
                                <input type="text" name="description[]" required style="width: 100%; padding: 0.5rem;">
                            </div>
                            <div>
                                <label>Quantity:</label>
                                <input type="number" name="quantity[]" required min="1" style="width: 100%; padding: 0.5rem;">
                            </div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                            <div>
                                <label>Estimated Cost:</label>
                                <input type="number" step="0.01" name="estimated_cost[]" style="width: 100%; padding: 0.5rem;">
                            </div>
                            <div>
                                <label>Part ID (optional):</label>
                                <input type="text" name="part_id[]" style="width: 100%; padding: 0.5rem;">
                            </div>
                            <div style="display: flex; align-items: end;">
                                <button type="button" onclick="this.parentElement.parentElement.parentElement.remove()" style="background: #e53e3e; color: white; border: none; padding: 0.5rem; border-radius: 4px; cursor: pointer; width: 100%;">Remove</button>
                            </div>
                        </div>
                    </div>
                `;
                linesContainer.insertAdjacentHTML('beforeend', lineHtml);
            }}
            
            function viewPurchaseRequests() {{
                window.open('/api/parts/purchase-requests', '_blank');
            }}
            
            function viewRFQs() {{
                alert('RFQ management interface - Coming soon!');
            }}
            
            function viewQuoteComparisons() {{
                alert('Quote comparison interface - Coming soon!');
            }}
            
            function viewPurchaseOrders() {{
                alert('Purchase order management interface - Coming soon!');
            }}
            
            function addVendor() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; max-height: 90%; overflow-y: auto; color: black;" onclick="event.stopPropagation()">
                            <h3>Add New Vendor</h3>
                            <form id="addVendorForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Vendor Name:</label>
                                    <input type="text" name="name" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Contact Email:</label>
                                        <input type="email" name="contact_email" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                    <div>
                                        <label>Contact Phone:</label>
                                        <input type="text" name="contact_phone" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Contact Person:</label>
                                    <input type="text" name="contact_person" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Address:</label>
                                    <textarea name="address" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 60px;"></textarea>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Payment Terms:</label>
                                        <select name="terms" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="NET30">NET30</option>
                                            <option value="NET15">NET15</option>
                                            <option value="NET7">NET7</option>
                                            <option value="COD">COD</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Default Lead Days:</label>
                                        <input type="number" name="default_lead_days" value="7" min="1" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Notes:</label>
                                    <textarea name="notes" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 60px;"></textarea>
                                </div>
                                
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" style="padding: 0.5rem 1rem; background: #38a169; color: white; border: none; border-radius: 4px;">Add Vendor</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('addVendorForm').addEventListener('submit', async function(e) {{
                    e.preventDefault();
                    
                    const formData = new FormData(e.target);
                    const vendorData = Object.fromEntries(formData);
                    vendorData.default_lead_days = parseInt(vendorData.default_lead_days);
                    
                    try {{
                        const response = await fetch('/parts/vendors', {{
                            method: 'POST',
                            headers: {{ 'Content-Type': 'application/json' }},
                            body: JSON.stringify(vendorData)
                        }});
                        
                        if (response.ok) {{
                            const result = await response.json();
                            alert('Vendor added successfully: ' + result.name);
                            document.body.removeChild(document.querySelector('[onclick="closeModal(event)"]'));
                            if (document.getElementById('vendorsContent').classList.contains('active')) {{
                                loadVendorsData();
                            }}
                        }} else {{
                            const error = await response.text();
                            alert('Error adding vendor: ' + error);
                        }}
                    }} catch (error) {{
                        alert('Error adding vendor: ' + error.message);
                    }}
                }});
            }}
            
            function refreshVendors() {{
                loadVendorsData();
            }}
            
            // Initialize the procurement dashboard on page load
            document.addEventListener('DOMContentLoaded', function() {{
                // Load initial data for the active tab
                showTab('inventory');
            }});
        </script>
    </body>
    </html>
    """
    
    # Generate parts HTML
    parts_html = ""
    for part in parts_db:
        stock_level = 'out_of_stock' if part['quantity_on_hand'] == 0 else 'low_stock' if part['quantity_on_hand'] <= part['reorder_point'] else 'in_stock'
        stock_status = 'OUT OF STOCK' if part['quantity_on_hand'] == 0 else 'LOW STOCK' if part['quantity_on_hand'] <= part['reorder_point'] else 'IN STOCK'
        status_color = '#f87171' if part['quantity_on_hand'] == 0 else '#fbbf24' if part['quantity_on_hand'] <= part['reorder_point'] else '#38ef7d'
        
        parts_html += f'''
        <div class="parts-card {stock_level}" data-category="{part['category']}" data-supplier="{part['supplier']}" data-stock-level="{stock_level}" data-name="{part['name']}">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1.5rem;">
                <div style="flex: 1;">
                    <h4 style="margin: 0; color: white; font-size: 1.25rem;">{part['name']}</h4>
                    <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.7);">{part['part_number']} • {part['category']}</p>
                    <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.6); font-size: 0.9rem;">{part['description']}</p>
                </div>
                <span style="background: {status_color}; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: bold;">{stock_status}</span>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; padding: 1rem; background: rgba(0,0,0,0.2); border-radius: 8px;">
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">On Hand</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">{part['quantity_on_hand']} {part['unit_of_measure']}</div>
                </div>
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Unit Cost</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">${part['unit_cost']:.2f}</div>
                </div>
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Reorder Point</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">{part['reorder_point']}</div>
                </div>
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Total Value</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">${part['quantity_on_hand'] * part['unit_cost']:.2f}</div>
                </div>
            </div>
            
            <div style="margin-bottom: 1rem; padding: 0.75rem; background: rgba(255,255,255,0.05); border-radius: 8px;">
                <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-bottom: 0.5rem;">Supply Details</div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                    <span style="color: rgba(255,255,255,0.8);">Supplier:</span>
                    <span style="color: white;">{part['supplier']}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                    <span style="color: rgba(255,255,255,0.8);">Manufacturer:</span>
                    <span style="color: white;">{part['manufacturer']}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: rgba(255,255,255,0.8);">Location:</span>
                    <span style="color: white;">{part['location']}</span>
                </div>
            </div>
            
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                <button class="btn btn-sm" onclick="viewPartDetails('{part['id']}')">View Details</button>
                <button class="btn btn-sm btn-warning" onclick="adjustStock('{part['id']}', {part['quantity_on_hand']})">Adjust Stock</button>
                <button class="btn btn-sm" onclick="issuePart('{part['id']}')">Issue Part</button>
                <button class="btn btn-sm {'btn-danger' if part['quantity_on_hand'] <= part['reorder_point'] else 'btn-success'}" onclick="orderPart('{part['id']}')">{'🚨 Order Now' if part['quantity_on_hand'] <= part['reorder_point'] else 'Order'}</button>
            </div>
        </div>'''
    
    return html_template.format(
        base_styles=get_base_styles(),
        nav_styles=get_navigation_styles(),
        nav_html=get_navigation_html("parts"),
        nav_js=get_navigation_javascript(),
        total_parts=total_parts,
        in_stock_parts=in_stock_parts,
        low_stock_parts=low_stock_parts,
        out_of_stock_parts=out_of_stock_parts,
        pending_orders=pending_orders,
        total_inventory_value=total_inventory_value,
        parts_html=parts_html
    )

# Include other necessary routes from the original file
@parts_router.get("/")
async def parts_root():
    """Redirect to parts dashboard"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/parts/dashboard", status_code=302)

@parts_router.get("/api")
async def get_parts(
    category: Optional[str] = Query(None),
    supplier: Optional[str] = Query(None),
    low_stock: Optional[bool] = Query(None)
) -> List[Dict]:
    """Get all parts with optional filtering"""
    filtered_parts = parts_db
    
    if category:
        filtered_parts = [p for p in filtered_parts if p['category'] == category]
    if supplier:
        filtered_parts = [p for p in filtered_parts if p['supplier'] == supplier]
    if low_stock:
        filtered_parts = [p for p in filtered_parts if p['quantity_on_hand'] <= p['reorder_point']]
    
    return filtered_parts

# =============================================================================
# Complete CRUD API Endpoints with RBAC and Audit Trail
# =============================================================================

@parts_router.get("/{part_id}", response_model=PartResponse)
@require_permissions(Permission.PARTS_VIEW)
async def get_part(
    part_id: str,
    current_user: AuthUser = Depends(get_current_user)
):
    """Get specific part details"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    # Calculate additional fields
    part['is_low_stock'] = part['quantity_on_hand'] <= part['reorder_point']
    part['last_issued'] = None  # TODO: Get from transactions
    part['total_issued'] = 0    # TODO: Calculate from transactions
    
    return PartResponse(**part)

@parts_router.post("/", response_model=PartResponse)
@require_permissions(Permission.PARTS_CREATE)
@audit_create("part")
async def create_part(
    part_data: PartCreate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Create new part"""
    # Check if part number already exists
    if any(p['part_number'] == part_data.part_number for p in parts_db):
        raise HTTPException(
            status_code=400, 
            detail=f"Part number {part_data.part_number} already exists"
        )
    
    # Generate new part ID
    part_id = f"PART-{len(parts_db) + 1:04d}"
    
    # Create part record
    new_part = {
        "id": part_id,
        "created_date": datetime.now(),
        "updated_date": datetime.now(),
        **part_data.model_dump()
    }
    
    # Add calculated fields
    new_part['is_low_stock'] = new_part['quantity'] <= new_part['min_stock']
    new_part['last_issued'] = None
    new_part['total_issued'] = 0
    
    parts_db.append(new_part)
    
    return PartResponse(**new_part)

@parts_router.put("/{part_id}", response_model=PartResponse)
@require_permissions(Permission.PARTS_UPDATE)
@audit_update("part")
async def update_part(
    part_id: str,
    part_data: PartUpdate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Update part"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    # Update fields
    update_data = part_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        part[field] = value
    
    part['updated_date'] = datetime.now()
    part['is_low_stock'] = part['quantity'] <= part['min_stock']
    
    return PartResponse(**part)

@parts_router.delete("/{part_id}", response_model=BaseResponse)
@require_permissions(Permission.PARTS_DELETE)
@audit_delete("part")
async def delete_part(
    part_id: str,
    force_delete: bool = False,
    current_user: AuthUser = Depends(get_current_user)
):
    """Delete part"""
    part_index = next((i for i, p in enumerate(parts_db) if p['id'] == part_id), None)
    if part_index is None:
        raise HTTPException(status_code=404, detail="Part not found")
    
    part = parts_db[part_index]
    
    # Check if part is used in work orders (safety check)
    if not force_delete and part['total_issued'] > 0:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete part with issue history. Use force_delete=true to override."
        )
    
    # Remove part
    parts_db.pop(part_index)
    
    return BaseResponse(message=f"Part {part['part_number']} deleted successfully")

@parts_router.post("/{part_id}/adjust-stock", response_model=StockTransaction)
@require_permissions(Permission.PARTS_ADJUST_STOCK)
async def adjust_stock(
    part_id: str,
    adjustment: StockAdjustment,
    current_user: AuthUser = Depends(get_current_user)
):
    """Adjust part stock levels"""
    part = next((p for p in parts_db if p['id'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    # Record transaction
    global stock_transactions_db
    transaction_id = f"TXN-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{len(stock_transactions_db) + 1}"
    
    quantity_before = part['quantity']
    quantity_after = quantity_before + adjustment.quantity
    
    if quantity_after < 0:
        raise HTTPException(
            status_code=400,
            detail="Adjustment would result in negative stock"
        )
    
    # Create transaction record
    transaction = {
        "id": transaction_id,
        "part_id": part_id,
        "transaction_type": adjustment.adjustment_type,
        "quantity": adjustment.quantity,
        "quantity_before": quantity_before,
        "quantity_after": quantity_after,
        "reason": adjustment.reason,
        "reference": adjustment.reference,
        "cost_per_unit": adjustment.cost_per_unit,
        "total_cost": adjustment.cost_per_unit * abs(adjustment.quantity) if adjustment.cost_per_unit else None,
        "performed_by": current_user.id,
        "performed_date": datetime.now()
    }
    
    # Update part quantity
    part['quantity'] = quantity_after
    part['updated_date'] = datetime.now()
    part['is_low_stock'] = quantity_after <= part['min_stock']
    
    # Log audit trail
    audit_stock_adjustment(
        current_user.id,
        current_user.username,
        part_id,
        adjustment.adjustment_type,
        adjustment.quantity,
        adjustment.reason
    )
    
    # Add to transactions (initialize if needed)
    if 'stock_transactions_db' not in globals():
        stock_transactions_db = []
    
    stock_transactions_db.append(transaction)
    
    return StockTransaction(**transaction)

@parts_router.get("/{part_id}/transactions", response_model=List[StockTransaction])
@require_permissions(Permission.PARTS_VIEW)
async def get_part_transactions(
    part_id: str,
    current_user: AuthUser = Depends(get_current_user)
):
    """Get stock transaction history for a part"""
    if 'stock_transactions_db' not in globals():
        return []
    
    transactions = [
        StockTransaction(**txn) 
        for txn in stock_transactions_db 
        if txn['part_id'] == part_id
    ]
    
    return sorted(transactions, key=lambda x: x.performed_date, reverse=True)

@parts_router.post("/bulk-delete", response_model=BulkResponse)
@require_permissions(Permission.PARTS_DELETE)
@audit_bulk_operation("part", "delete")
async def bulk_delete_parts(
    delete_request: BulkDeleteRequest,
    current_user: AuthUser = Depends(get_current_user)
):
    """Bulk delete parts"""
    deleted = 0
    errors = []
    
    for part_id in delete_request.ids:
        try:
            part_index = next((i for i, p in enumerate(parts_db) if p['id'] == part_id), None)
            if part_index is None:
                errors.append({"id": part_id, "error": "Part not found"})
                continue
            
            part = parts_db[part_index]
            
            # Safety check
            if not delete_request.force_delete and part.get('total_issued', 0) > 0:
                errors.append({"id": part_id, "error": "Part has issue history"})
                continue
            
            parts_db.pop(part_index)
            deleted += 1
            
        except Exception as e:
            errors.append({"id": part_id, "error": str(e)})
    
    return BulkResponse(
        processed=len(delete_request.ids),
        successful=deleted,
        failed=len(errors),
        errors=errors
    )

@parts_router.get("/export/{format}", response_model=BaseResponse)
@require_permissions(Permission.PARTS_EXPORT)
async def export_parts(
    format: ExportFormat,
    include_inactive: bool = Query(False, description="Include inactive parts"),
    category: Optional[str] = Query(None, description="Filter by category"),
    supplier: Optional[str] = Query(None, description="Filter by supplier"),
    low_stock: bool = Query(False, description="Only low stock parts"),
    current_user: AuthUser = Depends(get_current_user)
):
    """Export parts data in various formats"""
    
    # Filter parts based on request
    filtered_parts = parts_db.copy()
    
    # Apply filters
    if not include_inactive:
        filtered_parts = [p for p in filtered_parts if p.get('is_active', True)]
    
    if category:
        filtered_parts = [p for p in filtered_parts if p.get('category') == category]
    if supplier:
        filtered_parts = [p for p in filtered_parts if p.get('supplier') == supplier]
    if low_stock:
        filtered_parts = [p for p in filtered_parts if p['quantity_on_hand'] <= p['reorder_point']]
    
    # Generate export file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"parts_export_{timestamp}"
    
    if format == ExportFormat.CSV:
        import csv
        import io
        
        output = io.StringIO()
        fieldnames = ['id', 'name', 'part_number', 'category', 'quantity', 'min_stock', 
                     'unit_cost', 'supplier', 'location', 'is_low_stock']
        
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        
        for part in filtered_parts:
            writer.writerow({k: part.get(k, '') for k in fieldnames})
        
        # Save to temp file (in production, save to proper storage)
        csv_content = output.getvalue()
        filepath = f"/tmp/{filename}.csv"
        
        with open(filepath, 'w') as f:
            f.write(csv_content)
        
        return BaseResponse(message=f"Parts exported to {filepath}")
    
    elif format == ExportFormat.JSON:
        import json
        
        filepath = f"/tmp/{filename}.json"
        with open(filepath, 'w') as f:
            json.dump(filtered_parts, f, indent=2, default=str)
        
        return BaseResponse(message=f"Parts exported to {filepath}")
    
    else:
        raise HTTPException(status_code=400, detail=f"Export format {format} not yet implemented")

@parts_router.get("/list/paginated", response_model=PartList)
@require_permissions(Permission.PARTS_VIEW)
async def get_parts_paginated(
    pagination: PaginationParams = Depends(),
    category: Optional[str] = Query(None),
    supplier: Optional[str] = Query(None),
    low_stock: Optional[bool] = Query(None),
    search: Optional[str] = Query(None),
    current_user: AuthUser = Depends(get_current_user)
):
    """Get paginated list of parts with filtering and search"""
    
    # Apply filters
    filtered_parts = parts_db.copy()
    
    if category:
        filtered_parts = [p for p in filtered_parts if p.get('category') == category]
    if supplier:
        filtered_parts = [p for p in filtered_parts if p.get('supplier') == supplier]
    if low_stock:
        filtered_parts = [p for p in filtered_parts if p.get('quantity_on_hand', 0) <= p.get('reorder_point', 0)]
    if search:
        search_lower = search.lower()
        filtered_parts = [
            p for p in filtered_parts 
            if search_lower in p['name'].lower() 
            or search_lower in p['part_number'].lower()
            or search_lower in p.get('description', '').lower()
        ]
    
    # Sort
    if pagination.sort_by:
        sort_field = pagination.sort_by or ''
        reverse_order = pagination.sort_order == "desc"
        def safe_key(x):
            val = x.get(sort_field)
            if isinstance(val, (int, float)):
                return val
            return str(val) if val is not None else ''
        filtered_parts.sort(key=safe_key, reverse=reverse_order)
    
    # Paginate
    total = len(filtered_parts)
    start_index = (pagination.page - 1) * pagination.limit
    end_index = start_index + pagination.limit
    paginated_parts = filtered_parts[start_index:end_index]
    
    # Convert to response models
    part_responses = []
    for part in paginated_parts:
        part_copy = part.copy()
        part_copy['is_low_stock'] = part_copy.get('quantity_on_hand', 0) <= part_copy.get('reorder_point', 0)
        part_copy['last_issued'] = None
        part_copy['total_issued'] = 0
        part_responses.append(PartResponse(**part_copy))
    
    return PartList(
        items=part_responses,
        total=total,
        page=pagination.page,
        limit=pagination.limit,
        has_more=end_index < total
    )

# Initialize stock transactions database if not exists
stock_transactions_db = []

# =============================================================================
# Phase 2: Procurement Workflow Endpoints
# =============================================================================

@parts_router.post("/purchase-request", response_model=PurchaseRequestResponse)
@require_permissions(Permission.PARTS_CREATE)
async def create_purchase_request(
    pr_data: PurchaseRequestCreate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Create purchase request from reorder suggestions or manual entry"""
    try:
        # Generate PR ID
        pr_id = f"PR-{datetime.now().strftime('%Y%m%d')}-{len(purchase_requests_db) + 1:03d}"
        
        # Calculate total estimated cost
        total_estimated = 0.0
        pr_lines = []
        
        for line in pr_data.lines:
            # If part_id provided, get current cost from parts database
            if line.part_id:
                part = next((p for p in parts_db if p['id'] == line.part_id), None)
                if part:
                    estimated_cost = line.estimated_cost or (part['unit_cost'] * line.quantity)
                    total_estimated += estimated_cost
                    pr_lines.append({
                        "id": f"PRL-{len(pr_lines) + 1:03d}",
                        "pr_id": pr_id,
                        "part_id": line.part_id,
                        "description": line.description,
                        "quantity": line.quantity,
                        "estimated_cost": estimated_cost,
                        "asset_id": line.asset_id,
                        "notes": line.notes
                    })
                else:
                    raise HTTPException(status_code=404, detail=f"Part {line.part_id} not found")
            else:
                # Manual entry without part ID
                estimated_cost = line.estimated_cost or 0.0
                total_estimated += estimated_cost
                pr_lines.append({
                    "id": f"PRL-{len(pr_lines) + 1:03d}",
                    "pr_id": pr_id,
                    "part_id": None,
                    "description": line.description,
                    "quantity": line.quantity,
                    "estimated_cost": estimated_cost,
                    "asset_id": line.asset_id,
                    "notes": line.notes
                })
        
        # Create purchase request
        purchase_request = {
            "id": pr_id,
            "requested_by": current_user.username,
            "status": "draft",
            "priority": pr_data.priority,
            "need_by_date": pr_data.need_by_date,
            "created_at": datetime.now().isoformat(),
            "approved_by": None,
            "approved_at": None,
            "total_estimated": total_estimated,
            "justification": pr_data.justification,
            "work_order_id": pr_data.work_order_id,
            "lines": pr_lines
        }
        
        purchase_requests_db.append(purchase_request)
        
        return PurchaseRequestResponse(**purchase_request)
        
    except Exception as e:
        logger.error(f"Failed to create purchase request: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.get("/purchase-requests", response_model=List[PurchaseRequestResponse])
@require_permissions(Permission.PARTS_VIEW)
async def list_purchase_requests(
    status: Optional[str] = Query(None, description="Filter by status"),
    requested_by: Optional[str] = Query(None, description="Filter by requester"),
    current_user: AuthUser = Depends(get_current_user)
):
    """List purchase requests with optional filtering"""
    try:
        filtered_prs = purchase_requests_db.copy()
        
        if status:
            filtered_prs = [pr for pr in filtered_prs if pr['status'] == status]
        if requested_by:
            filtered_prs = [pr for pr in filtered_prs if pr['requested_by'] == requested_by]
        
        return [PurchaseRequestResponse(**pr) for pr in filtered_prs]
        
    except Exception as e:
        logger.error(f"Failed to list purchase requests: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.post("/rfq", response_model=RFQResponse)
@require_permissions(Permission.PARTS_CREATE)
async def create_rfq(
    rfq_data: RFQCreate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Create RFQ from purchase request"""
    try:
        # Validate PR exists
        pr = next((pr for pr in purchase_requests_db if pr['id'] == rfq_data.pr_id), None)
        if not pr:
            raise HTTPException(status_code=404, detail="Purchase request not found")
        
        # Validate vendors exist
        for vendor_id in rfq_data.vendor_ids:
            vendor = next((v for v in vendors_db if v['id'] == vendor_id), None)
            if not vendor:
                raise HTTPException(status_code=404, detail=f"Vendor {vendor_id} not found")
        
        # Generate RFQ ID
        rfq_id = f"RFQ-{datetime.now().strftime('%Y%m%d')}-{len(rfqs_db) + 1:03d}"
        
        # Create RFQ
        rfq = {
            "id": rfq_id,
            "pr_id": rfq_data.pr_id,
            "status": "sent",
            "sent_date": datetime.now().isoformat(),
            "response_due_date": rfq_data.response_due_date,
            "created_by": current_user.username,
            "vendor_ids": rfq_data.vendor_ids,
            "notes": rfq_data.notes
        }
        
        rfqs_db.append(rfq)
        
        # Update PR status
        pr['status'] = "rfq_sent"
        
        return RFQResponse(**rfq)
        
    except Exception as e:
        logger.error(f"Failed to create RFQ: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.post("/quotes/attach", response_model=QuoteResponse)
@require_permissions(Permission.PARTS_CREATE)
async def attach_quote(
    quote_data: QuoteAttach,
    current_user: AuthUser = Depends(get_current_user)
):
    """Attach vendor quote to RFQ"""
    try:
        # Validate RFQ exists
        rfq = next((rfq for rfq in rfqs_db if rfq['id'] == quote_data.rfq_id), None)
        if not rfq:
            raise HTTPException(status_code=404, detail="RFQ not found")
        
        # Validate vendor is part of RFQ
        if quote_data.vendor_id not in rfq['vendor_ids']:
            raise HTTPException(status_code=400, detail="Vendor not included in RFQ")
        
        # Get vendor info for lead time calculation
        vendor = next((v for v in vendors_db if v['id'] == quote_data.vendor_id), None)
        default_lead_time = vendor['default_lead_days'] if vendor else 7
        
        # Calculate quote totals
        total_amount = 0.0
        quote_lines = []
        max_lead_time = 0
        
        for line in quote_data.lines:
            line_total = line.unit_price * line.quantity_available
            total_amount += line_total
            max_lead_time = max(max_lead_time, line.lead_time_days)
            
            quote_lines.append({
                "id": f"QL-{len(quote_lines) + 1:03d}",
                "pr_line_id": line.pr_line_id,
                "unit_price": line.unit_price,
                "quantity_available": line.quantity_available,
                "lead_time_days": line.lead_time_days,
                "line_total": line_total,
                "notes": line.notes
            })
        
        # Generate Quote ID
        quote_id = f"QT-{datetime.now().strftime('%Y%m%d')}-{len(quotes_db) + 1:03d}"
        
        # Create quote
        quote = {
            "id": quote_id,
            "rfq_id": quote_data.rfq_id,
            "vendor_id": quote_data.vendor_id,
            "quote_number": quote_data.quote_number,
            "total_amount": total_amount,
            "currency": "USD",
            "validity_date": quote_data.validity_date,
            "lead_time_days": max_lead_time,
            "terms": quote_data.terms,
            "received_date": datetime.now().isoformat(),
            "status": "received",
            "notes": quote_data.notes,
            "lines": quote_lines
        }
        
        quotes_db.append(quote)
        
        # Update RFQ status if all vendors have responded
        rfq_quotes = [q for q in quotes_db if q['rfq_id'] == quote_data.rfq_id]
        if len(rfq_quotes) == len(rfq['vendor_ids']):
            rfq['status'] = "responses_received"
        
        return QuoteResponse(**quote)
        
    except Exception as e:
        logger.error(f"Failed to attach quote: {e}")
        raise HTTPException(status_code=500, detail=str(e))

def calculate_quote_score(quote: Dict, vendor: Dict) -> Dict[str, Any]:
    """Calculate quote scoring with multiple factors"""
    try:
        # Scoring factors (weights sum to 1.0)
        price_weight = 0.4
        lead_time_weight = 0.2
        vendor_rating_weight = 0.3
        terms_weight = 0.1
        
        # Get all quotes for comparison (for relative scoring)
        rfq_quotes = [q for q in quotes_db if q['rfq_id'] == quote['rfq_id']]
        
        # Price Score (lower is better)
        prices = [q['total_amount'] for q in rfq_quotes]
        min_price = min(prices) if prices else quote['total_amount']
        price_score = (min_price / quote['total_amount']) * 100 * price_weight
        
        # Lead Time Score (shorter is better)
        lead_times = [q['lead_time_days'] for q in rfq_quotes]
        min_lead_time = min(lead_times) if lead_times else quote['lead_time_days']
        lead_time_score = (min_lead_time / max(quote['lead_time_days'], 1)) * 100 * lead_time_weight
        
        # Vendor Rating Score
        vendor_score = (vendor['rating'] / 5.0) * 100 * vendor_rating_weight
        
        # Terms Score (basic implementation)
        terms_score = 75 * terms_weight  # Default score
        if 'NET30' in quote.get('terms', ''):
            terms_score = 85 * terms_weight
        elif 'NET15' in quote.get('terms', ''):
            terms_score = 80 * terms_weight
        elif 'NET7' in quote.get('terms', ''):
            terms_score = 70 * terms_weight
        
        # Total Score
        total_score = price_score + lead_time_score + vendor_score + terms_score
        
        # Generate pros and cons
        pros = []
        cons = []
        
        if quote['total_amount'] == min_price:
            pros.append("Lowest price")
        elif quote['total_amount'] > min_price * 1.1:
            cons.append("Higher price than competitors")
        
        if quote['lead_time_days'] == min_lead_time:
            pros.append("Fastest delivery")
        elif quote['lead_time_days'] > min_lead_time * 1.5:
            cons.append("Longer lead time")
        
        if vendor['rating'] >= 4.5:
            pros.append("Highly rated vendor")
        elif vendor['rating'] < 4.0:
            cons.append("Lower vendor rating")
        
        return {
            "score": round(total_score, 1),
            "price_score": round(price_score, 1),
            "lead_time_score": round(lead_time_score, 1),
            "vendor_score": round(vendor_score, 1),
            "terms_score": round(terms_score, 1),
            "pros": pros,
            "cons": cons
        }
        
    except Exception as e:
        logger.error(f"Quote scoring failed: {e}")
        return {"score": 50.0, "pros": [], "cons": ["Scoring error"]}

@parts_router.get("/quotes/compare/{rfq_id}", response_model=QuoteComparisonResponse)
@require_permissions(Permission.PARTS_VIEW)
async def compare_quotes(
    rfq_id: str,
    current_user: AuthUser = Depends(get_current_user)
):
    """Compare quotes with scoring algorithm"""
    try:
        # Validate RFQ exists
        rfq = next((rfq for rfq in rfqs_db if rfq['id'] == rfq_id), None)
        if not rfq:
            raise HTTPException(status_code=404, detail="RFQ not found")
        
        # Get all quotes for this RFQ
        rfq_quotes = [q for q in quotes_db if q['rfq_id'] == rfq_id]
        if not rfq_quotes:
            raise HTTPException(status_code=404, detail="No quotes found for RFQ")
        
        # Build comparison data
        comparisons = []
        
        for quote in rfq_quotes:
            # Get vendor details
            vendor = next((v for v in vendors_db if v['id'] == quote['vendor_id']), None)
            if not vendor:
                continue
            
            # Calculate price per unit for each line item
            price_per_unit = {}
            for line in quote['lines']:
                line_id = line['pr_line_id']
                price_per_unit[line_id] = line['unit_price']
            
            # Calculate quote score
            score_data = calculate_quote_score(quote, vendor)
            
            comparison = {
                "quote_id": quote['id'],
                "vendor_name": vendor['name'],
                "vendor_rating": vendor['rating'],
                "total_amount": quote['total_amount'],
                "lead_time_days": quote['lead_time_days'],
                "price_per_unit": price_per_unit,
                "terms": quote.get('terms', vendor['terms']),
                "score": score_data['score'],
                "pros": score_data['pros'],
                "cons": score_data['cons']
            }
            
            comparisons.append(comparison)
        
        # Sort by score (highest first)
        comparisons.sort(key=lambda x: x['score'], reverse=True)
        
        # Determine recommendation
        recommended_quote_id = None
        recommendation_reason = None
        total_savings_potential = None
        
        if len(comparisons) >= 2:
            best_quote = comparisons[0]
            recommended_quote_id = best_quote['quote_id']
            
            # Calculate potential savings
            highest_price = max(c['total_amount'] for c in comparisons)
            lowest_price = min(c['total_amount'] for c in comparisons)
            total_savings_potential = highest_price - lowest_price
            
            # Generate recommendation reason
            if best_quote['score'] > 80:
                recommendation_reason = f"Best overall value with {best_quote['score']:.1f}/100 score"
            elif best_quote['total_amount'] == lowest_price:
                recommendation_reason = "Lowest total cost"
            else:
                recommendation_reason = "Best balance of price, quality, and delivery time"
        
        return QuoteComparisonResponse(
            rfq_id=rfq_id,
            quotes=comparisons,
            recommended_quote_id=recommended_quote_id,
            recommendation_reason=recommendation_reason,
            total_savings_potential=total_savings_potential
        )
        
    except Exception as e:
        logger.error(f"Quote comparison failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

def determine_approval_requirements(amount: float, current_user: AuthUser) -> Dict[str, Any]:
    """Determine approval requirements based on amount and user role"""
    approval_info = {
        "requires_approval": False,
        "requires_manager_approval": False,
        "requires_admin_approval": False,
        "approval_level": 0,
        "threshold_exceeded": False,
        "can_auto_approve": False
    }
    
    if amount < APPROVAL_THRESHOLDS["auto_approve"]:
        # Under $1K - can be auto-approved by purchaser or higher
        approval_info["can_auto_approve"] = current_user.role in ["admin", "manager", "purchaser"]
        if not approval_info["can_auto_approve"]:
            approval_info["requires_approval"] = True
            approval_info["requires_manager_approval"] = True
            approval_info["approval_level"] = 1
    
    elif amount < APPROVAL_THRESHOLDS["manager_approve"]:
        # $1K - $10K - requires manager approval
        approval_info["requires_approval"] = True
        approval_info["requires_manager_approval"] = True
        approval_info["approval_level"] = 1
        approval_info["threshold_exceeded"] = True
        approval_info["can_auto_approve"] = current_user.role in ["admin", "manager"]
    
    else:
        # Over $10K - requires admin approval
        approval_info["requires_approval"] = True
        approval_info["requires_admin_approval"] = True
        approval_info["approval_level"] = 2
        approval_info["threshold_exceeded"] = True
        approval_info["can_auto_approve"] = current_user.role == "admin"
    
    return approval_info

@parts_router.post("/purchase-order", response_model=PurchaseOrderResponse)
@require_permissions(Permission.PARTS_CREATE)
async def create_purchase_order(
    po_data: POCreate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Create purchase order from selected quote"""
    try:
        # Validate quote exists
        quote = next((q for q in quotes_db if q['id'] == po_data.quote_id), None)
        if not quote:
            raise HTTPException(status_code=404, detail="Quote not found")
        
        # Get vendor details
        vendor = next((v for v in vendors_db if v['id'] == po_data.vendor_id), None)
        if not vendor:
            raise HTTPException(status_code=404, detail="Vendor not found")
        
        # Check approval requirements
        approval_info = determine_approval_requirements(quote['total_amount'], current_user)
        
        # Generate PO number and ID
        po_number = f"PO-{datetime.now().strftime('%Y%m%d')}-{len(purchase_orders_extended_db) + 1:03d}"
        po_id = f"PO-{len(purchase_orders_extended_db) + 1:04d}"
        
        # Create PO lines from quote
        po_lines = []
        for quote_line in quote['lines']:
            po_lines.append({
                "id": f"POL-{len(po_lines) + 1:03d}",
                "po_id": po_id,
                "pr_line_id": quote_line['pr_line_id'],
                "part_id": None,  # TODO: Link to parts if available
                "description": f"Quote line for {quote_line['pr_line_id']}",
                "quantity_ordered": quote_line['quantity_available'],
                "quantity_received": 0,
                "unit_price": quote_line['unit_price'],
                "total_price": quote_line['line_total'],
                "notes": quote_line.get('notes', '')
            })
        
        # Determine initial status based on approval requirements
        initial_status = "draft"
        if approval_info["can_auto_approve"] or po_data.approval_override:
            initial_status = "approved"
        elif approval_info["requires_approval"]:
            initial_status = "pending_approval"
        
        # Create purchase order
        purchase_order = {
            "id": po_id,
            "vendor_id": po_data.vendor_id,
            "po_number": po_number,
            "status": initial_status,
            "order_date": datetime.now().isoformat(),
            "expected_delivery": po_data.expected_delivery,
            "actual_delivery": None,
            "total_amount": quote['total_amount'],
            "created_by": current_user.username,
            "approved_by": current_user.username if initial_status == "approved" else None,
            "approved_at": datetime.now().isoformat() if initial_status == "approved" else None,
            "terms": po_data.terms or quote.get('terms', vendor['terms']),
            "notes": po_data.notes,
            "lines": po_lines,
            "quote_id": quote['id'],
            "rfq_id": quote['rfq_id']
        }
        
        purchase_orders_extended_db.append(purchase_order)
        
        # Update quote status
        quote['status'] = "selected"
        
        # Mark other quotes for this RFQ as not selected
        for other_quote in quotes_db:
            if other_quote['rfq_id'] == quote['rfq_id'] and other_quote['id'] != quote['id']:
                other_quote['status'] = "not_selected"
        
        # Prepare response
        response_data = {
            **purchase_order,
            "approval_required": approval_info["requires_approval"],
            "approval_threshold_exceeded": approval_info["threshold_exceeded"]
        }
        
        return PurchaseOrderResponse(**response_data)
        
    except Exception as e:
        logger.error(f"Failed to create purchase order: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.post("/receiving", response_model=ReceivingResponse)
@require_permissions(Permission.PARTS_CREATE)
async def receive_parts(
    receiving_data: ReceivingCreate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Process receiving against purchase order with partial shipment support"""
    try:
        # Validate PO exists
        po = next((po for po in purchase_orders_extended_db if po['id'] == receiving_data.po_id), None)
        if not po:
            raise HTTPException(status_code=404, detail="Purchase order not found")
        
        # Generate receiving ID
        receiving_id = f"RCV-{datetime.now().strftime('%Y%m%d')}-{len(receiving_db) + 1:03d}"
        
        # Process receiving lines
        receiving_lines = []
        inventory_updates = []
        
        for line in receiving_data.lines:
            # Find corresponding PO line
            po_line = next((pol for pol in po['lines'] if pol['id'] == line.po_line_id), None)
            if not po_line:
                raise HTTPException(status_code=404, detail=f"PO line {line.po_line_id} not found")
            
            # Validate quantity doesn't exceed ordered amount
            remaining_qty = po_line['quantity_ordered'] - po_line['quantity_received']
            if line.quantity_received > remaining_qty:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Cannot receive {line.quantity_received} - only {remaining_qty} remaining"
                )
            
            # Create receiving line
            receiving_line = {
                "id": f"RCL-{len(receiving_lines) + 1:03d}",
                "receiving_id": receiving_id,
                "po_line_id": line.po_line_id,
                "part_id": line.part_id,
                "quantity_received": line.quantity_received,
                "condition": line.condition,
                "bin_location": line.bin_location,
                "notes": line.notes
            }
            
            receiving_lines.append(receiving_line)
            
            # Update PO line received quantity
            po_line['quantity_received'] += line.quantity_received
            
            # If condition is good and part_id provided, update inventory
            if line.condition == "good" and line.part_id:
                part = next((p for p in parts_db if p['id'] == line.part_id), None)
                if part:
                    part['quantity_on_hand'] += line.quantity_received
                    inventory_updates.append({
                        "part_id": line.part_id,
                        "quantity_added": line.quantity_received,
                        "new_quantity": part['quantity_on_hand']
                    })
        
        # Create receiving record
        receiving = {
            "id": receiving_id,
            "po_id": receiving_data.po_id,
            "received_by": current_user.username,
            "received_date": datetime.now().isoformat(),
            "packing_slip": receiving_data.packing_slip,
            "partial_shipment": receiving_data.partial_shipment,
            "notes": receiving_data.notes,
            "lines": receiving_lines
        }
        
        receiving_db.append(receiving)
        
        # Update PO status based on completion
        total_ordered = sum(line['quantity_ordered'] for line in po['lines'])
        total_received = sum(line['quantity_received'] for line in po['lines'])
        
        if total_received >= total_ordered:
            po['status'] = "received"
            po['actual_delivery'] = datetime.now().isoformat()
        elif total_received > 0:
            po['status'] = "partially_received"
        
        # Create inventory transactions
        for update in inventory_updates:
            transaction = {
                "id": f"TXN-{datetime.now().strftime('%Y%m%d%H%M%S')}-{len(inventory_transactions_db) + 1}",
                "part_id": update['part_id'],
                "transaction_type": "received",
                "quantity": update['quantity_added'],
                "work_order_id": None,
                "date": datetime.now().isoformat(),
                "notes": f"Received from PO {po['po_number']} - {receiving_id}",
                "reference": receiving_id
            }
            inventory_transactions_db.append(transaction)
        
        response_data = {
            **receiving,
            "inventory_updated": len(inventory_updates) > 0
        }
        
        return ReceivingResponse(**response_data)
        
    except Exception as e:
        logger.error(f"Failed to process receiving: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.get("/vendors", response_model=List[VendorResponse])
@require_permissions(Permission.PARTS_VIEW)
async def list_vendors(
    active_only: bool = Query(True, description="Filter to active vendors only"),
    current_user: AuthUser = Depends(get_current_user)
):
    """List all vendors"""
    try:
        filtered_vendors = vendors_db.copy()
        
        if active_only:
            filtered_vendors = [v for v in filtered_vendors if v['active']]
        
        return [VendorResponse(**vendor) for vendor in filtered_vendors]
        
    except Exception as e:
        logger.error(f"Failed to list vendors: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.post("/vendors", response_model=VendorResponse)
@require_permissions(Permission.PARTS_CREATE)
async def create_vendor(
    vendor_data: VendorCreate,
    current_user: AuthUser = Depends(get_current_user)
):
    """Create new vendor"""
    try:
        # Check for duplicate vendor names
        existing_vendor = next((v for v in vendors_db if v['name'].lower() == vendor_data.name.lower()), None)
        if existing_vendor:
            raise HTTPException(status_code=400, detail="Vendor name already exists")
        
        # Generate vendor ID
        vendor_id = f"VEN-{len(vendors_db) + 1:03d}"
        
        # Create vendor
        vendor = {
            "id": vendor_id,
            "name": vendor_data.name,
            "contact_email": vendor_data.contact_email,
            "contact_phone": vendor_data.contact_phone,
            "contact_person": vendor_data.contact_person,
            "address": vendor_data.address,
            "terms": vendor_data.terms,
            "default_lead_days": vendor_data.default_lead_days,
            "rating": 0.0,  # New vendors start with no rating
            "active": True,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "notes": vendor_data.notes
        }
        
        vendors_db.append(vendor)
        
        return VendorResponse(**vendor)
        
    except Exception as e:
        logger.error(f"Failed to create vendor: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Helper function to calculate procurement analytics
def calculate_procurement_analytics(period_days: int = 30) -> Dict[str, Any]:
    """Calculate procurement analytics and KPIs"""
    try:
        cutoff_date = datetime.now() - timedelta(days=period_days)
        
        # Get recent POs
        recent_pos = [
            po for po in purchase_orders_extended_db 
            if datetime.fromisoformat(po['created_at']) > cutoff_date
        ]
        
        # Total spend
        total_spend = sum(po['total_amount'] for po in recent_pos)
        
        # Cost savings calculation (simplified)
        cost_savings = 0.0
        for po in recent_pos:
            if 'quote_id' in po:
                quote = next((q for q in quotes_db if q['id'] == po['quote_id']), None)
                if quote:
                    # Find other quotes for the same RFQ
                    other_quotes = [q for q in quotes_db if q['rfq_id'] == quote['rfq_id'] and q['id'] != quote['id']]
                    if other_quotes:
                        highest_quote = max(other_quotes, key=lambda x: x['total_amount'])
                        cost_savings += max(0, highest_quote['total_amount'] - quote['total_amount'])
        
        # Vendor performance
        vendor_performance = []
        for vendor in vendors_db:
            vendor_pos = [po for po in recent_pos if po['vendor_id'] == vendor['id']]
            if vendor_pos:
                total_orders = len(vendor_pos)
                on_time_deliveries = len([
                    po for po in vendor_pos 
                    if po.get('actual_delivery') and po['actual_delivery'] <= po['expected_delivery']
                ])
                on_time_pct = (on_time_deliveries / total_orders * 100) if total_orders > 0 else 0
                total_spend_vendor = sum(po['total_amount'] for po in vendor_pos)
                
                # Calculate average lead time
                delivered_pos = [po for po in vendor_pos if po.get('actual_delivery')]
                if delivered_pos:
                    lead_times = []
                    for po in delivered_pos:
                        order_date = datetime.fromisoformat(po['order_date'])
                        delivery_date = datetime.fromisoformat(po['actual_delivery'])
                        lead_times.append((delivery_date - order_date).days)
                    avg_lead_time = sum(lead_times) / len(lead_times)
                else:
                    avg_lead_time = vendor['default_lead_days']
                
                vendor_performance.append({
                    "vendor_id": vendor['id'],
                    "vendor_name": vendor['name'],
                    "rating": vendor['rating'],
                    "total_orders": total_orders,
                    "on_time_deliveries": on_time_deliveries,
                    "on_time_delivery_pct": round(on_time_pct, 1),
                    "quality_score": vendor['rating'] * 20,  # Convert 5-scale to 100-scale
                    "price_competitiveness": 75.0,  # Simplified metric
                    "total_spend_ytd": round(total_spend_vendor, 2),
                    "avg_lead_time_days": round(avg_lead_time, 1),
                    "last_order_date": max([po['order_date'] for po in vendor_pos]) if vendor_pos else None
                })
        
        # Sort by spend
        vendor_performance.sort(key=lambda x: x['total_spend_ytd'], reverse=True)
        
        # Top categories by spend (simplified)
        top_categories = [
            {"category": "Bearings", "spend": total_spend * 0.3, "percentage": 30},
            {"category": "Filters", "spend": total_spend * 0.25, "percentage": 25},
            {"category": "Belts", "spend": total_spend * 0.2, "percentage": 20},
            {"category": "Seals", "spend": total_spend * 0.15, "percentage": 15},
            {"category": "Lubricants", "spend": total_spend * 0.1, "percentage": 10}
        ]
        
        # Approval time calculation
        avg_approval_time_hours = 24.0  # Simplified - would calculate from actual approval times
        
        # Procurement cycle time
        procurement_cycle_time_days = 14.0  # Simplified - from PR to PO delivery
        
        return {
            "period_days": period_days,
            "total_spend": round(total_spend, 2),
            "cost_savings": round(cost_savings, 2),
            "purchase_orders_count": len(recent_pos),
            "avg_approval_time_hours": avg_approval_time_hours,
            "vendor_performance": vendor_performance,
            "top_categories_by_spend": top_categories,
            "procurement_cycle_time_days": procurement_cycle_time_days,
            "generated_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Procurement analytics calculation failed: {e}")
        return {
            "period_days": period_days,
            "total_spend": 0.0,
            "cost_savings": 0.0,
            "purchase_orders_count": 0,
            "avg_approval_time_hours": 0.0,
            "vendor_performance": [],
            "top_categories_by_spend": [],
            "procurement_cycle_time_days": 0.0,
            "generated_at": datetime.now().isoformat()
        }

@parts_router.get("/analytics/procurement", response_model=ProcurementAnalyticsResponse)
@require_permissions(Permission.PARTS_VIEW)
async def get_procurement_analytics(
    period_days: int = Query(30, ge=1, le=365, description="Period in days"),
    current_user: AuthUser = Depends(get_current_user)
):
    """Get procurement analytics and performance metrics"""
    try:
        analytics_data = calculate_procurement_analytics(period_days)
        return ProcurementAnalyticsResponse(**analytics_data)
        
    except Exception as e:
        logger.error(f"Failed to get procurement analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@parts_router.post("/demo/create-sample-procurement-data")
async def create_sample_procurement_data(
    current_user: AuthUser = Depends(get_current_user)
):
    """Create sample procurement data for demonstration"""
    try:
        # Clear existing data
        purchase_requests_db.clear()
        rfqs_db.clear()
        quotes_db.clear()
        purchase_orders_extended_db.clear()
        receiving_db.clear()
        
        # Create sample purchase request
        pr_id = "PR-20250909-001"
        purchase_request = {
            "id": pr_id,
            "requested_by": current_user.username,
            "status": "draft",
            "priority": "urgent",
            "need_by_date": "2025-09-20",
            "created_at": datetime.now().isoformat(),
            "approved_by": None,
            "approved_at": None,
            "total_estimated": 150.00,
            "justification": "Replacement parts for critical equipment maintenance",
            "work_order_id": "WO-001",
            "lines": [
                {
                    "id": "PRL-001",
                    "pr_id": pr_id,
                    "part_id": "PRT-001",
                    "description": "Deep Groove Ball Bearing 25x52x15mm",
                    "quantity": 3,
                    "estimated_cost": 73.50,
                    "asset_id": "AST-001",
                    "notes": "For pump bearing replacement"
                },
                {
                    "id": "PRL-002",
                    "pr_id": pr_id,
                    "part_id": "PRT-002",
                    "description": "Air Filter Element - High Efficiency",
                    "quantity": 4,
                    "estimated_cost": 75.00,
                    "asset_id": "AST-001",
                    "notes": "Quarterly filter replacement"
                }
            ]
        }
        purchase_requests_db.append(purchase_request)
        
        # Create second PR for low priority
        pr_id_2 = "PR-20250909-002"
        purchase_request_2 = {
            "id": pr_id_2,
            "requested_by": current_user.username,
            "status": "approved",
            "priority": "normal",
            "need_by_date": "2025-10-01",
            "created_at": (datetime.now() - timedelta(days=2)).isoformat(),
            "approved_by": "admin",
            "approved_at": (datetime.now() - timedelta(days=1)).isoformat(),
            "total_estimated": 89.40,
            "justification": "Preventive maintenance supplies",
            "work_order_id": None,
            "lines": [
                {
                    "id": "PRL-003",
                    "pr_id": pr_id_2,
                    "part_id": "PRT-005",
                    "description": "EP2 Lithium Grease",
                    "quantity": 6,
                    "estimated_cost": 93.60,
                    "asset_id": None,
                    "notes": "Stock replenishment"
                }
            ]
        }
        purchase_requests_db.append(purchase_request_2)
        
        # Create RFQ from first PR
        rfq_id = "RFQ-20250909-001"
        rfq = {
            "id": rfq_id,
            "pr_id": pr_id,
            "status": "responses_received",
            "sent_date": (datetime.now() - timedelta(days=3)).isoformat(),
            "response_due_date": "2025-09-15",
            "created_by": current_user.username,
            "vendor_ids": ["VEN-001", "VEN-002", "VEN-004"],
            "notes": "Urgent requirement for maintenance"
        }
        rfqs_db.append(rfq)
        
        # Create quotes from multiple vendors
        quote_1 = {
            "id": "QT-20250909-001",
            "rfq_id": rfq_id,
            "vendor_id": "VEN-001",
            "quote_number": "ISC-Q-2025-789",
            "total_amount": 142.50,
            "currency": "USD",
            "validity_date": "2025-10-01",
            "lead_time_days": 5,
            "terms": "NET30",
            "received_date": (datetime.now() - timedelta(days=2)).isoformat(),
            "status": "selected",
            "notes": "Best price and delivery time",
            "lines": [
                {
                    "id": "QL-001",
                    "pr_line_id": "PRL-001",
                    "unit_price": 23.50,
                    "quantity_available": 3,
                    "lead_time_days": 5,
                    "line_total": 70.50,
                    "notes": "In stock"
                },
                {
                    "id": "QL-002",
                    "pr_line_id": "PRL-002",
                    "unit_price": 18.00,
                    "quantity_available": 4,
                    "lead_time_days": 3,
                    "line_total": 72.00,
                    "notes": "Special pricing"
                }
            ]
        }
        quotes_db.append(quote_1)
        
        quote_2 = {
            "id": "QT-20250909-002",
            "rfq_id": rfq_id,
            "vendor_id": "VEN-002",
            "quote_number": "FS-2025-Q456",
            "total_amount": 155.75,
            "currency": "USD",
            "validity_date": "2025-10-15",
            "lead_time_days": 3,
            "terms": "NET30",
            "received_date": (datetime.now() - timedelta(days=1)).isoformat(),
            "status": "not_selected",
            "notes": "Premium quality but higher price",
            "lines": [
                {
                    "id": "QL-003",
                    "pr_line_id": "PRL-001",
                    "unit_price": 26.00,
                    "quantity_available": 3,
                    "lead_time_days": 3,
                    "line_total": 78.00,
                    "notes": "Premium quality"
                },
                {
                    "id": "QL-004",
                    "pr_line_id": "PRL-002",
                    "unit_price": 19.44,
                    "quantity_available": 4,
                    "lead_time_days": 3,
                    "line_total": 77.75,
                    "notes": "High efficiency model"
                }
            ]
        }
        quotes_db.append(quote_2)
        
        quote_3 = {
            "id": "QT-20250909-003",
            "rfq_id": rfq_id,
            "vendor_id": "VEN-004",
            "quote_number": "EPE-RUSH-999",
            "total_amount": 189.00,
            "currency": "USD",
            "validity_date": "2025-09-25",
            "lead_time_days": 1,
            "terms": "NET7",
            "received_date": (datetime.now() - timedelta(hours=12)).isoformat(),
            "status": "not_selected",
            "notes": "Emergency pricing - premium for speed",
            "lines": [
                {
                    "id": "QL-005",
                    "pr_line_id": "PRL-001",
                    "unit_price": 32.00,
                    "quantity_available": 3,
                    "lead_time_days": 1,
                    "line_total": 96.00,
                    "notes": "Rush order premium"
                },
                {
                    "id": "QL-006",
                    "pr_line_id": "PRL-002",
                    "unit_price": 23.25,
                    "quantity_available": 4,
                    "lead_time_days": 1,
                    "line_total": 93.00,
                    "notes": "Express shipping included"
                }
            ]
        }
        quotes_db.append(quote_3)
        
        # Create purchase order from selected quote
        po_id = "PO-0001"
        purchase_order = {
            "id": po_id,
            "vendor_id": "VEN-001",
            "po_number": "PO-20250909-001",
            "status": "sent",
            "order_date": (datetime.now() - timedelta(days=1)).isoformat(),
            "expected_delivery": "2025-09-15",
            "actual_delivery": None,
            "total_amount": 142.50,
            "created_by": current_user.username,
            "approved_by": current_user.username,
            "approved_at": (datetime.now() - timedelta(days=1)).isoformat(),
            "terms": "NET30",
            "notes": "Urgent delivery required",
            "lines": [
                {
                    "id": "POL-001",
                    "po_id": po_id,
                    "pr_line_id": "PRL-001",
                    "part_id": "PRT-001",
                    "description": "Deep Groove Ball Bearing 25x52x15mm",
                    "quantity_ordered": 3,
                    "quantity_received": 0,
                    "unit_price": 23.50,
                    "total_price": 70.50,
                    "notes": "Critical component"
                },
                {
                    "id": "POL-002",
                    "po_id": po_id,
                    "pr_line_id": "PRL-002",
                    "part_id": "PRT-002",
                    "description": "Air Filter Element - High Efficiency",
                    "quantity_ordered": 4,
                    "quantity_received": 0,
                    "unit_price": 18.00,
                    "total_price": 72.00,
                    "notes": "Maintenance filters"
                }
            ],
            "quote_id": "QT-20250909-001",
            "rfq_id": rfq_id
        }
        purchase_orders_extended_db.append(purchase_order)
        
        return {
            "success": True,
            "message": "Sample procurement data created successfully",
            "data": {
                "purchase_requests": len(purchase_requests_db),
                "rfqs": len(rfqs_db),
                "quotes": len(quotes_db),
                "purchase_orders": len(purchase_orders_extended_db)
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to create sample data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Missing routes for parts workflow

@parts_router.get("/{part_id}/view", response_class=HTMLResponse)
async def view_part_details(part_id: str, current_user: AuthUser = Depends(get_current_user)):
    """View detailed part information"""
    part = next((p for p in parts_db if p['part_number'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    # Calculate additional metrics
    total_value = part['quantity'] * part['unit_cost']
    is_low_stock = part['quantity'] <= part['min_stock']
    stock_percentage = (part['quantity'] / part['max_stock'] * 100) if part['max_stock'] > 0 else 0
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Part Details: {part['name']}</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1000px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; text-decoration: none; display: inline-block; }}
            .btn-success {{ background: #38a169; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 0.5rem 0; padding: 0.5rem; background: #f7fafc; border-radius: 4px; }}
            .stat-value {{ font-weight: bold; }}
            .alert {{ padding: 1rem; border-radius: 4px; margin: 1rem 0; }}
            .alert-warning {{ background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }}
            .alert-danger {{ background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }}
            .progress-bar {{ width: 100%; height: 20px; background: #e2e8f0; border-radius: 10px; overflow: hidden; }}
            .progress-fill {{ height: 100%; background: #38a169; transition: width 0.3s; }}
            .progress-fill.low {{ background: #e53e3e; }}
            .progress-fill.medium {{ background: #d69e2e; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📦 Part Details</h1>
            <p>{part['name']} ({part_id})</p>
        </div>
        
        <div class="container">
            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                    <div>
                        <h2>{part['name']}</h2>
                        <p style="color: #718096; margin: 0;">{part['description']}</p>
                    </div>
                    <div style="text-align: right;">
                        <button class="btn btn-success" onclick="adjustStock('{part_id}', {part['quantity']})">Adjust Stock</button>
                        <button class="btn btn-warning" onclick="issuePart('{part_id}')">Issue Part</button>
                        <button class="btn" onclick="orderPart('{part_id}')">Order More</button>
                    </div>
                </div>
                
                {'<div class="alert alert-danger">⚠️ Out of Stock!</div>' if part['quantity'] == 0 else ''}
                {'<div class="alert alert-warning">⚠️ Low Stock Warning</div>' if is_low_stock and part['quantity'] > 0 else ''}
            </div>
            
            <div class="grid">
                <div class="card">
                    <h3>📊 Stock Information</h3>
                    <div class="stat">
                        <span>Current Stock:</span>
                        <span class="stat-value">{part['quantity']} {part['unit']}</span>
                    </div>
                    <div class="stat">
                        <span>Minimum Stock:</span>
                        <span class="stat-value">{part['min_stock']} {part['unit']}</span>
                    </div>
                    <div class="stat">
                        <span>Maximum Stock:</span>
                        <span class="stat-value">{part['max_stock']} {part['unit']}</span>
                    </div>
                    <div style="margin: 1rem 0;">
                        <label>Stock Level: {stock_percentage:.1f}%</label>
                        <div class="progress-bar">
                            <div class="progress-fill {'low' if stock_percentage < 20 else 'medium' if stock_percentage < 50 else ''}" style="width: {stock_percentage}%;"></div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <h3>💰 Cost Information</h3>
                    <div class="stat">
                        <span>Unit Cost:</span>
                        <span class="stat-value">${part['unit_cost']:.2f}</span>
                    </div>
                    <div class="stat">
                        <span>Total Value:</span>
                        <span class="stat-value">${total_value:.2f}</span>
                    </div>
                    <div class="stat">
                        <span>Category:</span>
                        <span class="stat-value">{part['category']}</span>
                    </div>
                    <div class="stat">
                        <span>Supplier:</span>
                        <span class="stat-value">{part['supplier']}</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>📍 Location & Details</h3>
                    <div class="stat">
                        <span>Location:</span>
                        <span class="stat-value">{part['location']}</span>
                    </div>
                    <div class="stat">
                        <span>Barcode:</span>
                        <span class="stat-value">{part.get('barcode', 'N/A')}</span>
                    </div>
                    <div class="stat">
                        <span>Lead Time:</span>
                        <span class="stat-value">{part.get('lead_time_days', 'N/A')} days</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>🔧 Compatible Assets</h3>
                    <div>
                        {', '.join(part.get('compatible_assets', ['Not specified']))}
                    </div>
                </div>
            </div>
            
            <div style="text-align: center; margin: 2rem 0;">
                <a href="/cmms/parts/dashboard" class="btn">📋 Back to Parts</a>
                <button class="btn" onclick="editPart('{part_id}')">✏️ Edit Part</button>
                <button class="btn btn-danger" onclick="deletePart('{part_id}')">🗑️ Delete</button>
            </div>
        </div>
        
        <script>
            function adjustStock(partId, currentStock) {{
                const newQuantity = prompt(`Current stock: ${{currentStock}}\\nEnter new quantity:`);
                const reason = prompt('Reason for adjustment:');
                
                if (newQuantity !== null && reason) {{
                    fetch(`/parts/${{partId}}/adjust-stock`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            new_quantity: parseInt(newQuantity),
                            reason: reason
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        alert('Stock adjusted successfully!');
                        location.reload();
                    }})
                    .catch(error => alert('Error adjusting stock: ' + error.message));
                }}
            }}
            
            function issuePart(partId) {{
                const quantity = prompt('Enter quantity to issue:');
                const workOrder = prompt('Work order ID (optional):');
                
                if (quantity !== null && quantity !== '') {{
                    fetch(`/parts/${{partId}}/issue`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            quantity: parseInt(quantity),
                            work_order_id: workOrder || null,
                            notes: 'Manual issue from part details'
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        alert('Part issued successfully!');
                        location.reload();
                    }})
                    .catch(error => alert('Error issuing part: ' + error.message));
                }}
            }}
            
            function orderPart(partId) {{
                window.location.href = `/cmms/parts/${{partId}}/order`;
            }}
            
            function editPart(partId) {{
                window.location.href = `/cmms/parts/${{partId}}/edit`;
            }}
            
            function deletePart(partId) {{
                if (confirm('Are you sure you want to delete this part?')) {{
                    fetch(`/parts/${{partId}}`, {{ method: 'DELETE' }})
                    .then(() => {{
                        alert('Part deleted successfully!');
                        window.location.href = '/cmms/parts/dashboard';
                    }})
                    .catch(error => alert('Error deleting part: ' + error.message));
                }}
            }}
        </script>
    </body>
    </html>
    """

@parts_router.get("/manuals", response_class=HTMLResponse)
async def parts_manuals(current_user: AuthUser = Depends(get_current_user)):
    """Parts manuals and documentation"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Parts Manuals & Documentation</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; text-decoration: none; display: inline-block; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }}
            .manual-card {{ border: 1px solid #e2e8f0; border-radius: 8px; padding: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📚 Parts Manuals & Documentation</h1>
            <p>Technical documentation and installation guides</p>
        </div>
        
        <div class="container">
            <div class="card">
                <h3>Available Manuals</h3>
                <div class="grid">
                    <div class="manual-card">
                        <h4>🔧 Mechanical Parts Manual</h4>
                        <p>Installation and maintenance procedures for mechanical components</p>
                        <button class="btn" onclick="viewManual('mechanical')">View Manual</button>
                    </div>
                    
                    <div class="manual-card">
                        <h4>⚡ Electrical Parts Guide</h4>
                        <p>Wiring diagrams and electrical component specifications</p>
                        <button class="btn" onclick="viewManual('electrical')">View Manual</button>
                    </div>
                    
                    <div class="manual-card">
                        <h4>🔩 Fasteners & Hardware</h4>
                        <p>Torque specifications and fastener selection guide</p>
                        <button class="btn" onclick="viewManual('fasteners')">View Manual</button>
                    </div>
                    
                    <div class="manual-card">
                        <h4>🧴 Fluids & Lubricants</h4>
                        <p>Fluid compatibility and lubrication schedules</p>
                        <button class="btn" onclick="viewManual('fluids')">View Manual</button>
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <a href="/cmms/parts/dashboard" class="btn">📋 Back to Parts</a>
                    <button class="btn" onclick="uploadManual()">📤 Upload Manual</button>
                </div>
            </div>
        </div>
        
        <script>
            function viewManual(type) {{
                alert(`Opening ${{type}} manual - Feature coming soon!`);
            }}
            
            function uploadManual() {{
                alert('Manual upload - Feature coming soon!');
            }}
        </script>
    </body>
    </html>
    """

@parts_router.post("/{part_id}/issue")
async def issue_part(
    part_id: str,
    issue_data: dict,
    current_user: AuthUser = Depends(get_current_user)
):
    """Issue part for work order or general use"""
    global stock_transactions_db
    part = next((p for p in parts_db if p['part_number'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    quantity = issue_data.get('quantity', 1)
    if part['quantity'] < quantity:
        raise HTTPException(status_code=400, detail="Insufficient stock")
    
    # Update part quantity
    part['quantity'] -= quantity
    
    # Create transaction record
    transaction = {
        "id": f"TXN-{len(stock_transactions_db) + 1:04d}",
        "part_number": part_id,
        "transaction_type": "issue",
        "quantity": -quantity,
        "work_order_id": issue_data.get('work_order_id'),
        "notes": issue_data.get('notes', ''),
        "user": current_user.username,
        "timestamp": datetime.now().isoformat()
    }
    
    stock_transactions_db.append(transaction)
    
    return {
        "id": part_id,
        "message": f"Issued {quantity} {part['unit']} of {part['name']}",
        "new_quantity": part['quantity'],
        "transaction_id": transaction["id"]
    }

# =============================================================================
# AI Copilot Endpoints for Parts Identification and Sourcing  
# =============================================================================

@parts_router.post("/ai/identify-from-image")
async def ai_identify_part_from_image(
    image: UploadFile,
    context: Optional[str] = Form(None),
    safety_critical: bool = Form(False),
    current_user: AuthUser = Depends(get_current_user)
):
    """AI Copilot: Identify parts from image with confidence scoring and vendor sourcing"""
    
    # Read image data
    image_data = await image.read()
    
    # Use AI voice processor for part identification
    from ai_voice_processor import work_order_part_identifier
    
    identification_result = await work_order_part_identifier.identify_part_from_image(
        image_data, 
        {'context': context} if context else None
    )
    
    # If confidence is low, return clarifying questions
    if identification_result['overall_confidence'] < 0.7:
        return {
            "success": False,
            "confidence": identification_result['overall_confidence'],
            "message": "Unable to confidently identify the part from this image",
            "clarifying_questions": identification_result.get('recommendations', []),
            "alternative_actions": identification_result.get('alternative_actions', []),
            "candidates": [],
            "vendor_sources": [],
            "processing_time_ms": identification_result['processing_time_ms']
        }
    
    # Get vendor sources for top candidates
    vendor_sources = []
    if identification_result['candidates']:
        from rag_system import vendor_catalog_searcher
        
        for candidate in identification_result['candidates'][:3]:  # Top 3 candidates
            try:
                part_info = {
                    'part_number': candidate.get('part_number', ''),
                    'manufacturer': candidate.get('manufacturer', ''),
                    'description': candidate.get('description', ''),
                    'category': candidate.get('category', '')
                }
                sources = await vendor_catalog_searcher.find_part_sources(part_info)
                vendor_sources.extend(sources)
            except Exception as e:
                logger.warning(f"Vendor search failed for {candidate.get('part_number')}: {e}")
    
    return {
        "success": True,
        "confidence": identification_result['overall_confidence'],
        "message": f"Identified {len(identification_result['candidates'])} candidate parts",
        "candidates": identification_result['candidates'],
        "vendor_sources": [asdict(source) for source in vendor_sources],
        "safety_critical": safety_critical,
        "requires_approval": safety_critical and identification_result['overall_confidence'] < 0.9,
        "processing_time_ms": identification_result['processing_time_ms']
    }

@parts_router.post("/ai/find-vendors")
async def ai_find_part_vendors(
    part_number: str,
    manufacturer: Optional[str] = None,
    description: Optional[str] = None,
    category: Optional[str] = None,
    current_user: AuthUser = Depends(get_current_user)
):
    """AI Copilot: Find vendors and pricing for specific parts"""
    
    from rag_system import vendor_catalog_searcher
    
    part_info = {
        'part_number': part_number.strip(),
        'manufacturer': manufacturer.strip() if manufacturer else '',
        'description': description.strip() if description else '',
        'category': category.strip() if category else ''
    }
    
    # Validate input
    if not part_number.strip():
        return {
            "success": False,
            "message": "Part number is required",
            "clarifying_questions": ["Please provide the part number you're looking for"],
            "vendor_sources": []
        }
    
    try:
        sources = await vendor_catalog_searcher.find_part_sources(part_info, confidence_threshold=0.7)
        
        if not sources:
            return {
                "success": False,
                "message": "No reliable vendor sources found for this part",
                "clarifying_questions": [
                    "Can you provide the manufacturer name?",
                    "Do you have additional part specifications?",
                    "Is this part available under a different part number?"
                ],
                "alternative_actions": [
                    "Contact your regular suppliers directly",
                    "Check with the equipment manufacturer",
                    "Search for substitute parts"
                ],
                "vendor_sources": []
            }
        
        return {
            "success": True,
            "message": f"Found {len(sources)} vendor sources",
            "vendor_sources": [asdict(source) for source in sources],
            "best_price": min([s.price for s in sources if s.price]) if any(s.price for s in sources) else None,
            "fastest_delivery": min([s.lead_time_days for s in sources if s.lead_time_days]) if any(s.lead_time_days for s in sources) else None
        }
        
    except Exception as e:
        logger.error(f"Vendor search failed: {e}")
        return {
            "success": False,
            "message": "Vendor search service temporarily unavailable",
            "error": str(e),
            "alternative_actions": ["Try again later", "Contact vendors directly"]
        }

@parts_router.post("/ai/suggest-substitutes") 
async def ai_suggest_substitute_parts(
    part_number: str,
    safety_critical: bool = False,
    current_user: AuthUser = Depends(get_current_user)
):
    """AI Copilot: Suggest substitute parts with safety checks"""
    
    # Find the original part
    original_part = None
    for part in parts_db:
        if part['part_number'] == part_number:
            original_part = part
            break
    
    if not original_part:
        return {
            "success": False,
            "message": "Original part not found in database",
            "clarifying_questions": ["Is the part number correct?", "Is this part in your catalog?"],
            "substitutes": []
        }
    
    from rag_system import vendor_catalog_searcher
    
    try:
        substitute_result = await vendor_catalog_searcher.get_substitute_parts(
            original_part, 
            safety_critical=safety_critical
        )
        
        # If confidence is too low or requires approval, add warnings
        if substitute_result['confidence'] < 0.8 or substitute_result['requires_approval']:
            return {
                "success": True,
                "message": "Substitute parts found but require engineering review",
                "substitutes": substitute_result['substitutes'],
                "safety_warnings": substitute_result['safety_warnings'],
                "requires_approval": substitute_result['requires_approval'],
                "confidence": substitute_result['confidence'],
                "approval_required_reasons": [
                    "Safety-critical application" if safety_critical else None,
                    "Low compatibility confidence" if substitute_result['confidence'] < 0.8 else None
                ]
            }
        
        return {
            "success": True,
            "message": f"Found {len(substitute_result['substitutes'])} compatible substitutes",
            "substitutes": substitute_result['substitutes'],
            "safety_warnings": substitute_result['safety_warnings'],
            "requires_approval": substitute_result['requires_approval'],
            "confidence": substitute_result['confidence']
        }
        
    except Exception as e:
        logger.error(f"Substitute search failed: {e}")
        return {
            "success": False,
            "message": "Substitute search service temporarily unavailable",
            "error": str(e)
        }

@parts_router.post("/ai/procurement-assistant")
async def ai_procurement_assistant(
    intent: str,
    part_numbers: List[str],
    context: Optional[str] = None,
    current_user: AuthUser = Depends(get_current_user)
):
    """AI Copilot: Intelligent procurement assistance with optimization"""
    
    # Define supported intents
    supported_intents = [
        "draft_rfq", "compare_quotes", "draft_po", 
        "reorder_recommendation", "optimize_inventory", "analyze_spend"
    ]
    
    if intent not in supported_intents:
        return {
            "success": False,
            "message": f"Unsupported intent: {intent}",
            "clarifying_questions": [f"Did you mean one of: {', '.join(supported_intents)}?"],
            "supported_intents": supported_intents
        }
    
    try:
        if intent == "reorder_recommendation":
            return await _ai_reorder_recommendations(part_numbers, current_user)
        elif intent == "draft_rfq":
            return await _ai_draft_rfq(part_numbers, context, current_user)
        elif intent == "optimize_inventory":
            return await _ai_optimize_inventory(part_numbers, current_user)
        else:
            return {
                "success": False,
                "message": f"Intent '{intent}' not yet implemented",
                "alternative_actions": ["Use manual procurement workflow", "Contact procurement team"]
            }
    
    except Exception as e:
        logger.error(f"Procurement AI failed: {e}")
        return {
            "success": False,
            "message": "Procurement AI service temporarily unavailable",
            "error": str(e)
        }

async def _ai_reorder_recommendations(part_numbers: List[str], current_user: AuthUser) -> Dict:
    """Generate intelligent reorder recommendations"""
    recommendations = []
    
    for part_number in part_numbers:
        part = next((p for p in parts_db if p['part_number'] == part_number), None)
        if not part:
            continue
            
        current_stock = part.get('quantity_on_hand', 0)
        reorder_point = part.get('reorder_point', 0)
        max_stock = part.get('max_stock', 100)
        avg_usage = part.get('average_monthly_usage', 5)  # Estimated
        
        # Calculate optimal order quantity using simple EOQ approximation
        optimal_qty = min(max_stock - current_stock, max(reorder_point, avg_usage * 2))
        
        urgency = "HIGH" if current_stock == 0 else "MEDIUM" if current_stock <= reorder_point else "LOW"
        
        recommendations.append({
            "part_number": part_number,
            "name": part.get('name', ''),
            "current_stock": current_stock,
            "recommended_order_qty": optimal_qty,
            "urgency": urgency,
            "estimated_cost": part.get('unit_cost', 0) * optimal_qty,
            "justification": f"Stock level ({current_stock}) below reorder point ({reorder_point})" if current_stock <= reorder_point else "Proactive reordering based on usage patterns",
            "lead_time_days": part.get('lead_time_days', 7)
        })
    
    return {
        "success": True,
        "message": f"Generated recommendations for {len(recommendations)} parts",
        "recommendations": recommendations,
        "total_estimated_cost": sum([r['estimated_cost'] for r in recommendations]),
        "high_priority_count": len([r for r in recommendations if r['urgency'] == 'HIGH'])
    }

async def _ai_draft_rfq(part_numbers: List[str], context: Optional[str], current_user: AuthUser) -> Dict:
    """Generate RFQ draft with intelligent vendor selection"""
    
    # Get part details
    parts_details = []
    for part_number in part_numbers:
        part = next((p for p in parts_db if p['part_number'] == part_number), None)
        if part:
            parts_details.append({
                "part_number": part_number,
                "description": part.get('description', ''),
                "quantity_needed": 1,  # Default - would come from PR
                "specifications": part.get('specifications', '')
            })
    
    # Select appropriate vendors based on part categories
    recommended_vendors = []
    categories = set([part.get('category', '').lower() for part in parts_details])
    
    for vendor in vendors_db:
        # Simple vendor matching logic
        vendor_specialties = vendor.get('specialties', [])
        if any(cat in [s.lower() for s in vendor_specialties] for cat in categories):
            recommended_vendors.append({
                "vendor_id": vendor['id'],
                "name": vendor['name'],
                "contact_email": vendor.get('contact_email', ''),
                "rating": vendor.get('rating', 0),
                "default_lead_days": vendor.get('default_lead_days', 7),
                "match_reason": f"Specializes in: {', '.join(vendor_specialties)}"
            })
    
    # Sort by rating
    recommended_vendors.sort(key=lambda x: x['rating'], reverse=True)
    
    rfq_draft = {
        "subject": f"RFQ for {len(parts_details)} Parts - {datetime.now().strftime('%Y-%m-%d')}",
        "requested_by": current_user.username,
        "parts": parts_details,
        "delivery_requirements": "Standard shipping to facility",
        "quote_validity_required": "30 days",
        "payment_terms": "Net 30",
        "context": context or "Standard procurement request"
    }
    
    return {
        "success": True,
        "message": f"Generated RFQ draft for {len(parts_details)} parts",
        "rfq_draft": rfq_draft,
        "recommended_vendors": recommended_vendors[:5],  # Top 5
        "estimated_response_time": "3-5 business days"
    }

async def _ai_optimize_inventory(part_numbers: List[str], current_user: AuthUser) -> Dict:
    """Provide inventory optimization recommendations"""
    
    optimizations = []
    total_savings = 0.0
    
    for part_number in part_numbers:
        part = next((p for p in parts_db if p['part_number'] == part_number), None)
        if not part:
            continue
            
        current_stock = part.get('quantity_on_hand', 0)
        unit_cost = part.get('unit_cost', 0)
        reorder_point = part.get('reorder_point', 0)
        max_stock = part.get('max_stock', 100)
        
        # Calculate carrying cost (estimated 20% annually)
        carrying_cost_annual = current_stock * unit_cost * 0.20
        
        # Recommendations based on stock levels
        recommendations = []
        if current_stock > max_stock:
            excess_qty = current_stock - max_stock
            potential_savings = excess_qty * unit_cost
            total_savings += potential_savings
            recommendations.append({
                "type": "REDUCE_EXCESS",
                "description": f"Reduce excess inventory by {excess_qty} units",
                "potential_savings": potential_savings,
                "action": "Use excess stock first, delay next order"
            })
        
        if current_stock < reorder_point:
            recommendations.append({
                "type": "REORDER_NEEDED",
                "description": f"Stock below reorder point ({reorder_point})",
                "urgency": "HIGH",
                "action": f"Order {max_stock - current_stock} units immediately"
            })
        
        optimizations.append({
            "part_number": part_number,
            "name": part.get('name', ''),
            "current_stock": current_stock,
            "optimal_range": f"{reorder_point}-{max_stock}",
            "carrying_cost_annual": carrying_cost_annual,
            "recommendations": recommendations
        })
    
    return {
        "success": True,
        "message": f"Generated inventory optimization for {len(optimizations)} parts",
        "optimizations": optimizations,
        "total_potential_savings": total_savings,
        "summary": {
            "parts_analyzed": len(part_numbers),
            "excess_inventory_items": len([o for o in optimizations if any(r['type'] == 'REDUCE_EXCESS' for r in o['recommendations'])]),
            "reorder_needed_items": len([o for o in optimizations if any(r['type'] == 'REORDER_NEEDED' for r in o['recommendations'])])
        }
    }

@parts_router.get("/{part_id}/order", response_class=HTMLResponse)
async def create_purchase_order_form(part_id: str, current_user: AuthUser = Depends(get_current_user)):
    """Create purchase order form for a part"""
    part = next((p for p in parts_db if p['part_number'] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    suggested_quantity = max(part['max_stock'] - part['quantity'], part['min_stock'])
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Create Purchase Order: {part['name']}</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 800px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .form-group {{ margin: 1rem 0; }}
            .form-group label {{ display: block; margin-bottom: 0.5rem; font-weight: 600; }}
            .form-group input, .form-group textarea, .form-group select {{ width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn-success {{ background: #38a169; }}
            .part-info {{ background: #f7fafc; padding: 1rem; border-left: 4px solid #4299e1; margin-bottom: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🛒 Create Purchase Order</h1>
            <p>Order more stock for {part['name']}</p>
        </div>
        
        <div class="container">
            <div class="part-info">
                <h3>{part['name']} ({part_id})</h3>
                <p><strong>Current Stock:</strong> {part['quantity']} {part['unit']}</p>
                <p><strong>Minimum Stock:</strong> {part['min_stock']} {part['unit']}</p>
                <p><strong>Supplier:</strong> {part['supplier']}</p>
                <p><strong>Unit Cost:</strong> ${part['unit_cost']:.2f}</p>
            </div>
            
            <div class="card">
                <form id="purchaseOrderForm">
                    <div class="form-group">
                        <label>Quantity to Order:</label>
                        <input type="number" name="quantity" value="{suggested_quantity}" required min="1">
                    </div>
                    
                    <div class="form-group">
                        <label>Supplier:</label>
                        <select name="supplier" required>
                            <option value="{part['supplier']}" selected>{part['supplier']}</option>
                            <option value="Alternative Supplier 1">Alternative Supplier 1</option>
                            <option value="Alternative Supplier 2">Alternative Supplier 2</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Expected Unit Cost:</label>
                        <input type="number" step="0.01" name="unit_cost" value="{part['unit_cost']}" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Priority:</label>
                        <select name="priority">
                            <option value="normal">Normal</option>
                            <option value="urgent">Urgent</option>
                            <option value="critical">Critical</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Delivery Required By:</label>
                        <input type="date" name="required_date" value="{(datetime.now() + timedelta(days=part.get('lead_time_days', 14))).strftime('%Y-%m-%d')}">
                    </div>
                    
                    <div class="form-group">
                        <label>Notes:</label>
                        <textarea name="notes" rows="3" placeholder="Any special instructions or requirements..."></textarea>
                    </div>
                    
                    <div style="text-align: center; padding-top: 1rem;">
                        <button type="submit" class="btn btn-success">🛒 Create Purchase Order</button>
                        <button type="button" class="btn" onclick="window.history.back()">↩️ Cancel</button>
                        <a href="/cmms/parts/dashboard" class="btn">📋 Back to Parts</a>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            document.getElementById('purchaseOrderForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const orderData = Object.fromEntries(formData);
                orderData.part_id = '{part_id}';
                
                // For now, just show success message
                const quantity = orderData.quantity;
                const totalCost = (parseFloat(orderData.unit_cost) * parseInt(quantity)).toFixed(2);
                alert(`Purchase Order created!\\n\\nPart: {part['name']}\\nQuantity: ${{quantity}} {part['unit']}\\nTotal Cost: $${{totalCost}}`);
                window.location.href = '/cmms/parts/dashboard';
            }});
        </script>
    </body>
    </html>
    """

# File Management Integration Endpoints
@parts_router.post("/upload")
async def upload_part_file(
    file: UploadFile = File(...),
    part_id: Optional[str] = None,
    description: Optional[str] = None,
    tags: Optional[str] = None
):
    """Upload file for part"""
    from file_manager import upload_file
    return await upload_file(
        file=file,
        entity_type="part",
        entity_id=part_id or "new",
        description=description or "",
        tags=tags or "",
        uploaded_by="inventory_manager"
    )

@parts_router.get("/export")
async def export_parts_data(
    format: str = Query("excel", regex="^(excel|csv|pdf|json)$"),
    part_id: Optional[str] = None,
    category: Optional[str] = None,
    status: Optional[str] = None,
    low_stock: bool = False
):
    """Export parts data in various formats"""
    # Filter parts based on parameters
    filtered_data = []
    
    for part in parts_db:
        if part_id and part["id"] != part_id:
            continue
        if category and part.get("category") != category:
            continue
        if status and part.get("status") != status:
            continue
        if low_stock and part.get("quantity", 0) >= part.get("min_stock", 0):
            continue
        filtered_data.append(part)
    
    if format == "excel":
        try:
            import pandas as pd
            from io import BytesIO
            from fastapi.responses import StreamingResponse
            
            df = pd.DataFrame(filtered_data)
            output = BytesIO()
            df.to_excel(output, index=False, sheet_name="Parts")
            output.seek(0)
            
            return StreamingResponse(
                BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": "attachment; filename=parts_export.xlsx"}
            )
        except ImportError:
            raise HTTPException(status_code=400, detail="Excel export requires pandas")
    
    elif format == "csv":
        try:
            import pandas as pd
            from io import BytesIO
            from fastapi.responses import StreamingResponse
            
            df = pd.DataFrame(filtered_data)
            output = BytesIO()
            df.to_csv(output, index=False)
            output.seek(0)
            
            return StreamingResponse(
                output,
                media_type="text/csv",
                headers={"Content-Disposition": "attachment; filename=parts_export.csv"}
            )
        except ImportError:
            # Fallback CSV creation without pandas
            import csv
            from io import StringIO, BytesIO
            
            output = StringIO()
            if filtered_data:
                writer = csv.DictWriter(output, fieldnames=filtered_data[0].keys())
                writer.writeheader()
                writer.writerows(filtered_data)
            
            from fastapi.responses import StreamingResponse
            return StreamingResponse(
                BytesIO(output.getvalue().encode()),
                media_type="text/csv",
                headers={"Content-Disposition": "attachment; filename=parts_export.csv"}
            )
    
    elif format == "json":
        from fastapi.responses import JSONResponse
        return JSONResponse(
            content={"parts": filtered_data, "exported_at": datetime.now().isoformat()},
            headers={"Content-Disposition": "attachment; filename=parts_export.json"}
        )
    
    elif format == "pdf":
        raise HTTPException(status_code=501, detail="PDF export not yet implemented")

@parts_router.post("/import")
async def import_parts_data(
    file: UploadFile = File(...),
    overwrite: bool = False,
    validate_only: bool = False
):
    """Import parts data from Excel/CSV file"""
    if not file.filename or not file.filename.endswith(('.xlsx', '.xls', '.csv')):
        raise HTTPException(status_code=400, detail="Only Excel and CSV files are supported")
    
    try:
        content = await file.read()
        
        if file.filename.endswith('.csv'):
            import csv
            from io import StringIO
            
            csv_content = StringIO(content.decode('utf-8'))
            reader = csv.DictReader(csv_content)
            imported_data = list(reader)
        else:
            try:
                import pandas as pd
                from io import BytesIO
                
                df = pd.read_excel(BytesIO(content))
                imported_data = df.to_dict('records')
            except ImportError:
                raise HTTPException(status_code=400, detail="Excel import requires pandas")
        
        # Validate data
        validation_errors = []
        valid_records = []
        
        for i, record in enumerate(imported_data):
            try:
                # Basic validation
                if not record.get('part_number'):
                    validation_errors.append(f"Row {i+1}: Part number is required")
                    continue
                
                if not record.get('name'):
                    validation_errors.append(f"Row {i+1}: Part name is required")
                    continue
                
                if not record.get('unit_cost'):
                    record['unit_cost'] = 0.0
                
                if not record.get('quantity'):
                    record['quantity'] = 0
                
                # Create part object
                part = {
                    "id": record.get('id', f"PRT-IMP-{int(time.time())}-{i}"),
                    "part_number": record['part_number'],
                    "name": record['name'],
                    "description": record.get('description', ''),
                    "category": record.get('category', 'General'),
                    "unit": record.get('unit', 'pcs'),
                    "unit_cost": float(record.get('unit_cost', 0)),
                    "quantity": int(record.get('quantity', 0)),
                    "min_stock": int(record.get('min_stock', 0)),
                    "max_stock": int(record.get('max_stock', 100)),
                    "location": record.get('location', ''),
                    "supplier": record.get('supplier', ''),
                    "status": record.get('status', 'active'),
                    "created_date": datetime.now().isoformat(),
                    "imported": True
                }
                
                valid_records.append(part)
                
            except Exception as e:
                validation_errors.append(f"Row {i+1}: {str(e)}")
        
        if validate_only:
            return {
                "validation_result": {
                    "total_rows": len(imported_data),
                    "valid_rows": len(valid_records),
                    "errors": validation_errors,
                    "preview": valid_records[:5]  # Show first 5 valid records
                }
            }
        
        # Import valid records
        imported_count = 0
        for part in valid_records:
            if overwrite or not any(p["id"] == part["id"] for p in parts_db):
                if overwrite:
                    # Remove existing record
                    parts_db[:] = [p for p in parts_db if p["id"] != part["id"]]
                
                parts_db.append(part)
                imported_count += 1
        
        return {
            "import_result": {
                "total_rows": len(imported_data),
                "imported_rows": imported_count,
                "skipped_rows": len(valid_records) - imported_count,
                "errors": validation_errors
            }
        }
        
    except Exception as e:
        logger.error(f"Parts import failed: {e}")
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

@parts_router.get("/files/{part_id}")
async def get_part_files(part_id: str):
    """Get all files associated with a part"""
    from file_manager import list_files
    return await list_files(entity_type="part", entity_id=part_id)