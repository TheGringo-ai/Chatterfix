#!/usr/bin/env python3
"""
CMMS Parts Module - Enhanced Version
Parts inventory management, ordering, and tracking with modern UI
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Parts router
parts_router = APIRouter(prefix="/parts", tags=["parts"])

# Data models
class Part(BaseModel):
    id: str
    part_number: str
    name: str
    description: str
    category: str
    manufacturer: str
    supplier: str
    unit_cost: float
    quantity_on_hand: int
    reorder_point: int
    maximum_stock: int
    unit_of_measure: str
    location: str
    last_ordered: Optional[str] = None
    compatible_assets: List[str]

# Sample parts data (same as original)
parts_db = [
    {
        "id": "PRT-001",
        "part_number": "BRG-6205-2RS",
        "name": "Deep Groove Ball Bearing",
        "description": "25x52x15mm sealed bearing",
        "category": "Bearings",
        "manufacturer": "SKF",
        "supplier": "Industrial Supply Co",
        "unit_cost": 24.50,
        "quantity_on_hand": 12,
        "reorder_point": 5,
        "maximum_stock": 25,
        "unit_of_measure": "each",
        "location": "A-1-15",
        "last_ordered": "2025-07-15",
        "compatible_assets": ["AST-001", "AST-002", "AST-005"]
    },
    {
        "id": "PRT-002",
        "part_number": "FLT-AIR-AC37",
        "name": "Air Filter Element",
        "description": "High-efficiency particulate air filter",
        "category": "Filters",
        "manufacturer": "Donaldson",
        "supplier": "Filter Solutions",
        "unit_cost": 18.75,
        "quantity_on_hand": 8,
        "reorder_point": 3,
        "maximum_stock": 15,
        "unit_of_measure": "each",
        "location": "B-2-08",
        "last_ordered": "2025-08-01",
        "compatible_assets": ["AST-001", "AST-003"]
    },
    {
        "id": "PRT-003",
        "part_number": "BLT-V-A32",
        "name": "V-Belt A32",
        "description": "Classical V-belt, 32 inch length",
        "category": "Belts",
        "manufacturer": "Gates",
        "supplier": "Belt & Chain Co",
        "unit_cost": 12.30,
        "quantity_on_hand": 0,
        "reorder_point": 2,
        "maximum_stock": 10,
        "unit_of_measure": "each",
        "location": "C-1-12",
        "last_ordered": "2025-06-20",
        "compatible_assets": ["AST-002", "AST-004"]
    },
    {
        "id": "PRT-004",
        "part_number": "SEAL-OS-25X40",
        "name": "Oil Seal 25x40x7",
        "description": "Nitrile rubber oil seal",
        "category": "Seals",
        "manufacturer": "NOK",
        "supplier": "Industrial Supply Co",
        "unit_cost": 8.95,
        "quantity_on_hand": 15,
        "reorder_point": 8,
        "maximum_stock": 20,
        "unit_of_measure": "each",
        "location": "A-3-22",
        "last_ordered": "2025-07-30",
        "compatible_assets": ["AST-001", "AST-005"]
    },
    {
        "id": "PRT-005",
        "part_number": "LUB-EP2-1KG",
        "name": "EP2 Lithium Grease",
        "description": "Multi-purpose lithium complex grease",
        "category": "Lubricants",
        "manufacturer": "Shell",
        "supplier": "Bearings Direct",
        "unit_cost": 15.60,
        "quantity_on_hand": 4,
        "reorder_point": 6,
        "maximum_stock": 12,
        "unit_of_measure": "kg",
        "location": "D-1-05",
        "last_ordered": "2025-08-10",
        "compatible_assets": ["AST-001", "AST-002", "AST-003", "AST-004", "AST-005"]
    }
]

# Sample purchase orders
purchase_orders_db = [
    {
        "id": "PO-001",
        "supplier": "Industrial Supply Co",
        "order_date": "2025-08-15",
        "expected_delivery": "2025-08-22",
        "status": "pending",
        "total_cost": 245.50,
        "parts": [
            {"part_id": "PRT-001", "quantity": 10, "unit_cost": 24.50}
        ]
    },
    {
        "id": "PO-002",
        "supplier": "Belt & Chain Co",
        "order_date": "2025-08-18",
        "expected_delivery": "2025-08-25",
        "status": "pending",
        "total_cost": 123.00,
        "parts": [
            {"part_id": "PRT-003", "quantity": 10, "unit_cost": 12.30}
        ]
    }
]

# Sample inventory transactions
inventory_transactions_db = [
    {
        "id": "TXN-001",
        "part_id": "PRT-001",
        "transaction_type": "issued",
        "quantity": -2,
        "work_order_id": "WO-001",
        "date": "2025-08-12",
        "notes": "Issued to compressor maintenance"
    },
    {
        "id": "TXN-002",
        "part_id": "PRT-002",
        "transaction_type": "received",
        "quantity": 5,
        "work_order_id": None,
        "date": "2025-08-10",
        "notes": "Received shipment - PO-003"
    },
    {
        "id": "TXN-003",
        "part_id": "PRT-005",
        "transaction_type": "issued",
        "quantity": -1,
        "work_order_id": "WO-002",
        "date": "2025-08-14",
        "notes": "Issued for conveyor belt maintenance"
    }
]

@parts_router.get("/dashboard", response_class=HTMLResponse)
async def parts_dashboard():
    """Parts inventory dashboard with comprehensive overview and management"""
    total_parts = len(parts_db)
    low_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] <= p['reorder_point']])
    out_of_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] == 0])
    pending_orders = len([po for po in purchase_orders_db if po['status'] == 'pending'])
    total_inventory_value = sum(p['quantity_on_hand'] * p['unit_cost'] for p in parts_db)
    in_stock_parts = len([p for p in parts_db if p['quantity_on_hand'] > p['reorder_point']])
    
    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix Parts Management</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
            }}
            
            /* Navigation Styles */
            .navbar {{
                background: rgba(0,0,0,0.3);
                backdrop-filter: blur(10px);
                border-bottom: 1px solid rgba(255,255,255,0.1);
                padding: 0;
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .navbar-brand {{
                color: white;
                font-size: 1.5rem;
                font-weight: bold;
                text-decoration: none;
                padding: 1rem;
                display: inline-block;
            }}
            .navbar-nav {{
                list-style: none;
                display: flex;
                margin: 0;
                padding: 0;
                flex-wrap: wrap;
            }}
            .nav-item {{
                position: relative;
            }}
            .nav-link {{
                color: rgba(255,255,255,0.8);
                text-decoration: none;
                padding: 1rem 1.5rem;
                display: block;
                transition: all 0.3s ease;
                border-bottom: 2px solid transparent;
            }}
            .nav-link:hover {{
                color: white;
                background: rgba(255,255,255,0.1);
                border-bottom-color: #38ef7d;
            }}
            .nav-link.active {{
                color: white;
                background: rgba(255,255,255,0.15);
                border-bottom-color: #38ef7d;
            }}
            
            /* Mobile Navigation */
            .navbar-toggle {{
                display: none;
                background: none;
                border: none;
                color: white;
                font-size: 1.5rem;
                padding: 1rem;
                cursor: pointer;
            }}
            
            @media (max-width: 768px) {{
                .navbar-nav {{
                    display: none;
                    width: 100%;
                    flex-direction: column;
                    background: rgba(0,0,0,0.5);
                }}
                .navbar-nav.show {{
                    display: flex;
                }}
                .navbar-toggle {{
                    display: block;
                }}
                .navbar {{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    flex-wrap: wrap;
                }}
            }}
            
            /* Dashboard Content */
            .header {{ 
                padding: 3rem 2rem 2rem;
                text-align: center;
            }}
            .header h1 {{ 
                font-size: 3rem; 
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }}
            .container {{ 
                max-width: 1400px; 
                margin: 0 auto; 
                padding: 0 2rem 2rem; 
            }}
            .stats-grid {{ 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                gap: 2rem; 
                margin-bottom: 3rem;
            }}
            .stat-card {{ 
                background: rgba(255,255,255,0.15); 
                border-radius: 15px; 
                padding: 2rem; 
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                text-align: center;
                transition: transform 0.3s ease;
            }}
            .stat-card:hover {{
                transform: translateY(-5px);
            }}
            .stat-value {{
                font-size: 3rem;
                font-weight: bold;
                color: #38ef7d;
                display: block;
                margin-bottom: 0.5rem;
            }}
            .stat-value.warning {{
                color: #fbbf24;
            }}
            .stat-value.critical {{
                color: #f87171;
            }}
            .stat-label {{
                color: rgba(255,255,255,0.8);
                font-size: 1.1rem;
            }}
            
            .parts-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 2rem;
                margin-top: 2rem;
            }}
            .parts-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }}
            .parts-card.low-stock {{
                border-left: 4px solid #fbbf24;
            }}
            .parts-card.out-of-stock {{
                border-left: 4px solid #f87171;
            }}
            .parts-card.in-stock {{
                border-left: 4px solid #38ef7d;
            }}
            .parts-title {{
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            }}
            .btn {{ 
                background: #4299e1; 
                color: white; 
                border: none; 
                padding: 0.75rem 1.5rem; 
                border-radius: 8px; 
                cursor: pointer; 
                margin: 0.5rem; 
                font-size: 1rem;
                transition: all 0.3s ease;
            }}
            .btn:hover {{ 
                background: #3182ce; 
                transform: translateY(-2px);
            }}
            .btn-success {{ background: #38a169; }}
            .btn-success:hover {{ background: #2f855a; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-warning:hover {{ background: #b7791f; }}
            .btn-danger {{ background: #e53e3e; }}
            .btn-danger:hover {{ background: #c53030; }}
            .btn-sm {{ 
                padding: 0.5rem 1rem; 
                font-size: 0.875rem; 
                margin: 0.25rem;
            }}
            
            .filter-bar {{ 
                background: rgba(255,255,255,0.1); 
                padding: 1.5rem; 
                border-radius: 15px; 
                margin-bottom: 2rem; 
                display: flex; 
                gap: 1rem; 
                align-items: center;
                flex-wrap: wrap;
                backdrop-filter: blur(10px);
            }}
            .filter-bar select, .filter-bar input {{ 
                padding: 0.75rem; 
                border: 1px solid rgba(255,255,255,0.3); 
                border-radius: 8px;
                background: rgba(255,255,255,0.1);
                color: white;
                backdrop-filter: blur(10px);
            }}
            .filter-bar select option {{
                background: #2d3748;
                color: white;
            }}
            .filter-bar input::placeholder {{
                color: rgba(255,255,255,0.6);
            }}
        </style>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar">
            <a href="/cmms/" class="navbar-brand">⚡ ChatterFix CMMS</a>
            <button class="navbar-toggle" onclick="toggleNav()">☰</button>
            <ul class="navbar-nav" id="navbarNav">
                <li class="nav-item"><a href="/cmms/dashboard/main" class="nav-link">📊 Dashboard</a></li>
                <li class="nav-item"><a href="/cmms/workorders/dashboard" class="nav-link">📋 Work Orders</a></li>
                <li class="nav-item"><a href="/cmms/assets/dashboard" class="nav-link">⚙️ Assets</a></li>
                <li class="nav-item"><a href="/cmms/parts/dashboard" class="nav-link active">📦 Parts</a></li>
                <li class="nav-item"><a href="/cmms/preventive/dashboard" class="nav-link">🔄 Preventive</a></li>
                <li class="nav-item"><a href="/cmms/technicians/portal" class="nav-link">👷 Technicians</a></li>
                <li class="nav-item"><a href="/cmms/ai-enhanced/dashboard/universal" class="nav-link">🤖 AI Assistant</a></li>
                <li class="nav-item"><a href="/cmms/admin/dashboard" class="nav-link">⚖️ Admin</a></li>
            </ul>
        </nav>
        
        <!-- Header -->
        <div class="header">
            <h1>📦 Parts Management</h1>
            <p>Inventory Control, Ordering & Stock Management</p>
        </div>
        
        <!-- Main Content -->
        <div class="container">
            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value">{total_parts}</span>
                    <span class="stat-label">Total Parts</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">{in_stock_parts}</span>
                    <span class="stat-label">In Stock</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value warning">{low_stock_parts}</span>
                    <span class="stat-label">Low Stock Alert</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value critical">{out_of_stock_parts}</span>
                    <span class="stat-label">Out of Stock</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">{pending_orders}</span>
                    <span class="stat-label">Pending Orders</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">${total_inventory_value:,.0f}</span>
                    <span class="stat-label">Total Inventory Value</span>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <label style="color: rgba(255,255,255,0.9); font-weight: 500;">Filter by:</label>
                <select id="categoryFilter" onchange="filterParts()">
                    <option value="">All Categories</option>
                    <option value="Bearings">Bearings</option>
                    <option value="Filters">Filters</option>
                    <option value="Belts">Belts</option>
                    <option value="Seals">Seals</option>
                    <option value="Lubricants">Lubricants</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Consumables">Consumables</option>
                </select>
                <select id="stockFilter" onchange="filterParts()">
                    <option value="">All Stock Levels</option>
                    <option value="in_stock">In Stock</option>
                    <option value="low_stock">Low Stock</option>
                    <option value="out_of_stock">Out of Stock</option>
                </select>
                <select id="supplierFilter" onchange="filterParts()">
                    <option value="">All Suppliers</option>
                    <option value="Industrial Supply Co">Industrial Supply Co</option>
                    <option value="Bearings Direct">Bearings Direct</option>
                    <option value="Filter Solutions">Filter Solutions</option>
                    <option value="Belt & Chain Co">Belt & Chain Co</option>
                </select>
                <input type="text" id="searchFilter" placeholder="Search parts..." onkeyup="filterParts()">
                <div style="margin-left: auto;">
                    <button class="btn btn-success" onclick="addPart()">Add New Part</button>
                    <button class="btn btn-warning" onclick="createPurchaseOrder()">Create Order</button>
                    <button class="btn" onclick="window.location.href='/cmms/parts/manuals'">📚 Manuals</button>
                </div>
            </div>
            
            <!-- Parts Grid -->
            <div class="parts-grid" id="partsGrid">
                {parts_html}
            </div>
        </div>
        
        <script>
            function toggleNav() {{
                const nav = document.getElementById('navbarNav');
                nav.classList.toggle('show');
            }}
            
            // Close mobile nav when clicking outside
            document.addEventListener('click', function(event) {{
                const nav = document.getElementById('navbarNav');
                const toggle = document.querySelector('.navbar-toggle');
                if (!nav.contains(event.target) && !toggle.contains(event.target)) {{
                    nav.classList.remove('show');
                }}
            }});
            
            function filterParts() {{
                const categoryFilter = document.getElementById('categoryFilter').value;
                const stockFilter = document.getElementById('stockFilter').value;
                const supplierFilter = document.getElementById('supplierFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const partCards = document.querySelectorAll('.parts-card');
                partCards.forEach(card => {{
                    const category = card.dataset.category;
                    const supplier = card.dataset.supplier;
                    const stockLevel = card.dataset.stockLevel;
                    const name = card.dataset.name.toLowerCase();
                    
                    const categoryMatch = !categoryFilter || category === categoryFilter;
                    const supplierMatch = !supplierFilter || supplier === supplierFilter;
                    const stockMatch = !stockFilter || stockLevel === stockFilter;
                    const searchMatch = !searchFilter || name.includes(searchFilter);
                    
                    card.style.display = (categoryMatch && supplierMatch && stockMatch && searchMatch) ? 'block' : 'none';
                }});
            }}
            
            function addPart() {{
                alert('Add new part functionality - would open modal form');
            }}
            
            function viewPartDetails(partId) {{
                window.open(`/cmms/parts/${{partId}}/view`, '_blank');
            }}
            
            function adjustStock(partId, currentStock) {{
                const newQuantity = prompt(`Current stock: ${{currentStock}}\\nEnter new quantity:`);
                if (newQuantity !== null && newQuantity !== '') {{
                    alert(`Would adjust stock for ${{partId}} to ${{newQuantity}}`);
                    // Would make API call here
                }}
            }}
            
            function issuePart(partId) {{
                const quantity = prompt('Enter quantity to issue:');
                const workOrder = prompt('Work order ID (optional):');
                if (quantity !== null && quantity !== '') {{
                    alert(`Would issue ${{quantity}} of ${{partId}} to work order ${{workOrder || 'N/A'}}`);
                    // Would make API call here
                }}
            }}
            
            function orderPart(partId) {{
                alert(`Would create purchase order for part ${{partId}}`);
                // Would open purchase order creation
            }}
            
            function createPurchaseOrder() {{
                alert('Create purchase order functionality');
            }}
        </script>
    </body>
    </html>
    """
    
    # Generate parts HTML
    parts_html = ""
    for part in parts_db:
        stock_level = 'out_of_stock' if part['quantity_on_hand'] == 0 else 'low_stock' if part['quantity_on_hand'] <= part['reorder_point'] else 'in_stock'
        stock_status = 'OUT OF STOCK' if part['quantity_on_hand'] == 0 else 'LOW STOCK' if part['quantity_on_hand'] <= part['reorder_point'] else 'IN STOCK'
        status_color = '#f87171' if part['quantity_on_hand'] == 0 else '#fbbf24' if part['quantity_on_hand'] <= part['reorder_point'] else '#38ef7d'
        
        parts_html += f'''
        <div class="parts-card {stock_level}" data-category="{part['category']}" data-supplier="{part['supplier']}" data-stock-level="{stock_level}" data-name="{part['name']}">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1.5rem;">
                <div style="flex: 1;">
                    <h4 style="margin: 0; color: white; font-size: 1.25rem;">{part['name']}</h4>
                    <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.7);">{part['part_number']} • {part['category']}</p>
                    <p style="margin: 0.25rem 0; color: rgba(255,255,255,0.6); font-size: 0.9rem;">{part['description']}</p>
                </div>
                <span style="background: {status_color}; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: bold;">{stock_status}</span>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; padding: 1rem; background: rgba(0,0,0,0.2); border-radius: 8px;">
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">On Hand</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">{part['quantity_on_hand']} {part['unit_of_measure']}</div>
                </div>
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Unit Cost</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">${part['unit_cost']:.2f}</div>
                </div>
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Reorder Point</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">{part['reorder_point']}</div>
                </div>
                <div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Total Value</div>
                    <div style="color: white; font-size: 1.25rem; font-weight: bold;">${part['quantity_on_hand'] * part['unit_cost']:.2f}</div>
                </div>
            </div>
            
            <div style="margin-bottom: 1rem; padding: 0.75rem; background: rgba(255,255,255,0.05); border-radius: 8px;">
                <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-bottom: 0.5rem;">Supply Details</div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                    <span style="color: rgba(255,255,255,0.8);">Supplier:</span>
                    <span style="color: white;">{part['supplier']}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                    <span style="color: rgba(255,255,255,0.8);">Manufacturer:</span>
                    <span style="color: white;">{part['manufacturer']}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: rgba(255,255,255,0.8);">Location:</span>
                    <span style="color: white;">{part['location']}</span>
                </div>
            </div>
            
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                <button class="btn btn-sm" onclick="viewPartDetails('{part['id']}')">View Details</button>
                <button class="btn btn-sm btn-warning" onclick="adjustStock('{part['id']}', {part['quantity_on_hand']})">Adjust Stock</button>
                <button class="btn btn-sm" onclick="issuePart('{part['id']}')">Issue Part</button>
                <button class="btn btn-sm {'btn-danger' if part['quantity_on_hand'] <= part['reorder_point'] else 'btn-success'}" onclick="orderPart('{part['id']}')">{'🚨 Order Now' if part['quantity_on_hand'] <= part['reorder_point'] else 'Order'}</button>
            </div>
        </div>'''
    
    return html_template.format(
        total_parts=total_parts,
        in_stock_parts=in_stock_parts,
        low_stock_parts=low_stock_parts,
        out_of_stock_parts=out_of_stock_parts,
        pending_orders=pending_orders,
        total_inventory_value=total_inventory_value,
        parts_html=parts_html
    )

# Include other necessary routes from the original file
@parts_router.get("/")
async def get_parts(
    category: Optional[str] = Query(None),
    supplier: Optional[str] = Query(None),
    low_stock: Optional[bool] = Query(None)
) -> List[Dict]:
    """Get all parts with optional filtering"""
    filtered_parts = parts_db
    
    if category:
        filtered_parts = [p for p in filtered_parts if p['category'] == category]
    if supplier:
        filtered_parts = [p for p in filtered_parts if p['supplier'] == supplier]
    if low_stock:
        filtered_parts = [p for p in filtered_parts if p['quantity_on_hand'] <= p['reorder_point']]
    
    return filtered_parts