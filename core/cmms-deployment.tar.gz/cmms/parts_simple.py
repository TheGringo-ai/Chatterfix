#!/usr/bin/env python3
"""
ChatterFix CMMS - Simple Parts Module
Simplified version without email-validator dependency
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from typing import List, Dict, Any, Optional
from datetime import datetime

router = APIRouter(prefix="/cmms/parts", tags=["parts"])

# Simple parts inventory data
PARTS = [
    {
        "id": "PRT-001",
        "name": "Water Pump Seal",
        "part_number": "WPS-A123",
        "category": "seals",
        "location": "Warehouse A-15",
        "quantity": 12,
        "min_quantity": 5,
        "unit_cost": 25.50,
        "supplier": "Industrial Parts Co",
        "last_ordered": "2025-08-15T10:00:00Z"
    },
    {
        "id": "PRT-002",
        "name": "V-Belt",
        "part_number": "VB-32X2",
        "category": "belts",
        "location": "Warehouse B-08", 
        "quantity": 3,
        "min_quantity": 5,
        "unit_cost": 45.75,
        "supplier": "Belt Systems Inc",
        "last_ordered": "2025-07-20T14:30:00Z"
    },
    {
        "id": "PRT-003", 
        "name": "Motor Bearing",
        "part_number": "MB-6203",
        "category": "bearings",
        "location": "Warehouse A-22",
        "quantity": 8,
        "min_quantity": 3,
        "unit_cost": 65.25,
        "supplier": "Bearing World",
        "last_ordered": "2025-09-01T09:15:00Z"
    },
    {
        "id": "PRT-004",
        "name": "HVAC Filter",
        "part_number": "HF-20X25",
        "category": "filters", 
        "location": "Warehouse C-12",
        "quantity": 1,
        "min_quantity": 4,
        "unit_cost": 15.99,
        "supplier": "Air Quality Plus",
        "last_ordered": "2025-06-10T16:00:00Z"
    },
    {
        "id": "PRT-005",
        "name": "Conveyor Roller",
        "part_number": "CR-6IN-STL",
        "category": "rollers",
        "location": "Warehouse D-05",
        "quantity": 15,
        "min_quantity": 8, 
        "unit_cost": 125.00,
        "supplier": "Conveyor Solutions",
        "last_ordered": "2025-08-30T11:45:00Z"
    }
]

@router.get("/dashboard")
async def parts_dashboard():
    """Live Parts inventory dashboard with full CRUD functionality"""
    return HTMLResponse('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Parts Inventory - ChatterFix CMMS</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #3498db 0%, #2c3e50 100%);
                min-height: 100vh;
                color: white;
                padding: 2rem;
            }
            .card { 
                background: rgba(255,255,255,0.1);
                backdrop-filter: blur(15px);
                border-radius: 20px;
                padding: 2rem;
                margin: 1rem 0;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .low-stock { color: #e74c3c; }
            .critical-stock { color: #c0392b; font-weight: bold; }
            .normal-stock { color: #27ae60; }
            h1 { margin-bottom: 2rem; text-align: center; }
            .part { 
                background: rgba(255,255,255,0.05);
                border-radius: 15px;
                padding: 1.5rem;
                margin: 1rem 0;
                border-left: 4px solid #3498db;
                position: relative;
            }
            .part-actions {
                position: absolute;
                top: 1rem;
                right: 1rem;
                display: flex;
                gap: 0.5rem;
            }
            .stock-indicator {
                display: inline-block;
                padding: 0.3rem 0.8rem;
                border-radius: 15px;
                font-size: 0.8rem;
                font-weight: bold;
                margin-left: 1rem;
            }
            .btn {
                background: linear-gradient(135deg, #3498db, #2980b9);
                color: white;
                border: none;
                padding: 0.8rem 1.5rem;
                border-radius: 10px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 0.25rem;
                transition: all 0.3s ease;
                font-size: 0.9rem;
            }
            .btn:hover { transform: translateY(-2px); }
            .btn-small {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }
            .btn-warning {
                background: linear-gradient(135deg, #f39c12, #e67e22);
            }
            .btn-success {
                background: linear-gradient(135deg, #27ae60, #229954);
            }
            .btn-danger {
                background: linear-gradient(135deg, #e74c3c, #c0392b);
            }
            .modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }
            .modal-content {
                background: rgba(44,62,80,0.95);
                backdrop-filter: blur(15px);
                margin: 5% auto;
                padding: 2rem;
                border-radius: 20px;
                width: 90%;
                max-width: 600px;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .form-group {
                margin: 1rem 0;
            }
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: bold;
            }
            .form-group input, .form-group select {
                width: 100%;
                padding: 0.8rem;
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 10px;
                background: rgba(255,255,255,0.1);
                color: white;
                font-size: 1rem;
            }
            .form-group input::placeholder {
                color: rgba(255,255,255,0.6);
            }
            .loading {
                text-align: center;
                padding: 2rem;
                font-size: 1.2rem;
            }
            .stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin: 2rem 0;
            }
            .stat-card {
                text-align: center;
                padding: 1rem;
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>📦 Parts Inventory Dashboard</h1>
            
            <div style="text-align: center; margin-bottom: 2rem;">
                <button class="btn btn-success" onclick="showCreateModal()">➕ Create New Part</button>
                <button class="btn" onclick="loadParts()">🔄 Refresh</button>
                <a href="/cmms/dashboard/main" class="btn">← Back to Dashboard</a>
            </div>

            <div id="stats-container" class="stats">
                <div class="stat-card" style="background: rgba(52,152,219,0.2);">
                    <h3 id="total-parts">-</h3>
                    <p>Total Parts</p>
                </div>
                <div class="stat-card" style="background: rgba(243,156,18,0.2);">
                    <h3 id="low-stock">-</h3>
                    <p>Low Stock</p>
                </div>
                <div class="stat-card" style="background: rgba(231,76,60,0.2);">
                    <h3 id="critical-stock">-</h3>
                    <p>Critical</p>
                </div>
                <div class="stat-card" style="background: rgba(39,174,96,0.2);">
                    <h3 id="total-value">-</h3>
                    <p>Total Value</p>
                </div>
            </div>

            <div id="parts-container">
                <div class="loading">Loading parts...</div>
            </div>
        </div>

        <!-- Create/Edit Part Modal -->
        <div id="part-modal" class="modal">
            <div class="modal-content">
                <h2 id="modal-title">Create New Part</h2>
                <form id="part-form">
                    <div class="form-group">
                        <label for="name">Part Name *</label>
                        <input type="text" id="name" name="name" required placeholder="Enter part name">
                    </div>
                    <div class="form-group">
                        <label for="part_number">Part Number *</label>
                        <input type="text" id="part_number" name="part_number" required placeholder="Enter part number">
                    </div>
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category">
                            <option value="seals">Seals</option>
                            <option value="belts">Belts</option>
                            <option value="bearings">Bearings</option>
                            <option value="filters">Filters</option>
                            <option value="rollers">Rollers</option>
                            <option value="motors">Motors</option>
                            <option value="pumps">Pumps</option>
                            <option value="valves">Valves</option>
                            <option value="electrical">Electrical</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="location">Location</label>
                        <input type="text" id="location" name="location" placeholder="Warehouse location">
                    </div>
                    <div class="form-group">
                        <label for="quantity">Current Quantity</label>
                        <input type="number" id="quantity" name="quantity" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label for="min_quantity">Minimum Quantity</label>
                        <input type="number" id="min_quantity" name="min_quantity" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label for="unit_cost">Unit Cost</label>
                        <input type="number" id="unit_cost" name="unit_cost" step="0.01" min="0" value="0.00">
                    </div>
                    <div class="form-group">
                        <label for="supplier">Supplier</label>
                        <input type="text" id="supplier" name="supplier" placeholder="Supplier name">
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-success">💾 Save Part</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Issue Part Modal -->
        <div id="issue-modal" class="modal">
            <div class="modal-content">
                <h2>Issue Part</h2>
                <form id="issue-form">
                    <div class="form-group">
                        <label for="issue-quantity">Quantity to Issue *</label>
                        <input type="number" id="issue-quantity" name="quantity" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="work-order">Work Order ID</label>
                        <input type="text" id="work-order" name="work_order_id" placeholder="WO-12345">
                    </div>
                    <div class="form-group">
                        <label for="reason">Reason</label>
                        <input type="text" id="reason" name="reason" placeholder="Maintenance, repair, etc.">
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-warning">📦 Issue Part</button>
                        <button type="button" class="btn btn-danger" onclick="closeIssueModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            let currentParts = [];
            let editingPartId = null;
            let issuingPartId = null;

            // Load parts on page load
            document.addEventListener('DOMContentLoaded', loadParts);

            async function loadParts() {
                try {
                    const response = await fetch('/parts-test/');
                    const data = await response.json();
                    
                    if (data.success) {
                        currentParts = data.parts;
                        updateStats();
                        renderParts();
                    } else {
                        showError('Failed to load parts');
                    }
                } catch (error) {
                    showError('Error loading parts: ' + error.message);
                }
            }

            function updateStats() {
                const totalParts = currentParts.length;
                const lowStock = currentParts.filter(p => p.quantity <= p.min_quantity).length;
                const critical = currentParts.filter(p => p.quantity < p.min_quantity).length;
                const totalValue = currentParts.reduce((sum, p) => sum + (p.quantity * p.unit_cost), 0);

                document.getElementById('total-parts').textContent = totalParts;
                document.getElementById('low-stock').textContent = lowStock;
                document.getElementById('critical-stock').textContent = critical;
                document.getElementById('total-value').textContent = '$' + totalValue.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
            }

            function renderParts() {
                const container = document.getElementById('parts-container');
                
                if (currentParts.length === 0) {
                    container.innerHTML = '<div class="loading">No parts found. Create your first part!</div>';
                    return;
                }

                container.innerHTML = currentParts.map(part => {
                    let stockClass, stockIndicator;
                    if (part.quantity < part.min_quantity) {
                        stockClass = 'critical-stock';
                        stockIndicator = '<span class="stock-indicator" style="background: #c0392b;">CRITICAL</span>';
                    } else if (part.quantity <= part.min_quantity) {
                        stockClass = 'low-stock';
                        stockIndicator = '<span class="stock-indicator" style="background: #e67e22;">LOW STOCK</span>';
                    } else {
                        stockClass = 'normal-stock';
                        stockIndicator = '<span class="stock-indicator" style="background: #27ae60;">IN STOCK</span>';
                    }

                    const totalValue = part.quantity * part.unit_cost;

                    return `
                        <div class="part">
                            <div class="part-actions">
                                <button class="btn btn-small btn-success" onclick="showEditModal('${part.id}')">✏️ Edit</button>
                                <button class="btn btn-small btn-warning" onclick="showIssueModal('${part.id}')">📦 Issue</button>
                                <button class="btn btn-small btn-danger" onclick="deletePart('${part.id}')">🗑️ Delete</button>
                            </div>
                            <h3>${part.name} <span class="${stockClass}">(${part.quantity} units)</span> ${stockIndicator}</h3>
                            <p><strong>ID:</strong> ${part.id} | <strong>Part #:</strong> ${part.part_number} | <strong>Category:</strong> ${part.category}</p>
                            <p><strong>Location:</strong> ${part.location} | <strong>Supplier:</strong> ${part.supplier}</p>
                            <p><strong>Unit Cost:</strong> $${part.unit_cost.toFixed(2)} | <strong>Total Value:</strong> $${totalValue.toFixed(2)}</p>
                            <p><strong>Min Quantity:</strong> ${part.min_quantity} | <strong>Last Ordered:</strong> ${part.last_ordered}</p>
                        </div>
                    `;
                }).join('');
            }

            function showCreateModal() {
                editingPartId = null;
                document.getElementById('modal-title').textContent = 'Create New Part';
                document.getElementById('part-form').reset();
                document.getElementById('part-modal').style.display = 'block';
            }

            async function showEditModal(partId) {
                try {
                    const response = await fetch(`/parts-test/${partId}`);
                    const data = await response.json();
                    
                    if (data.success) {
                        editingPartId = partId;
                        const part = data.part;
                        
                        document.getElementById('modal-title').textContent = 'Edit Part';
                        document.getElementById('name').value = part.name;
                        document.getElementById('part_number').value = part.part_number;
                        document.getElementById('category').value = part.category;
                        document.getElementById('location').value = part.location;
                        document.getElementById('quantity').value = part.quantity;
                        document.getElementById('min_quantity').value = part.min_quantity;
                        document.getElementById('unit_cost').value = part.unit_cost;
                        document.getElementById('supplier').value = part.supplier;
                        
                        document.getElementById('part-modal').style.display = 'block';
                    } else {
                        showError('Failed to load part details');
                    }
                } catch (error) {
                    showError('Error loading part: ' + error.message);
                }
            }

            function showIssueModal(partId) {
                const part = currentParts.find(p => p.id === partId);
                if (!part) return;

                issuingPartId = partId;
                document.getElementById('issue-quantity').max = part.quantity;
                document.getElementById('issue-form').reset();
                document.getElementById('issue-modal').style.display = 'block';
            }

            function closeModal() {
                document.getElementById('part-modal').style.display = 'none';
            }

            function closeIssueModal() {
                document.getElementById('issue-modal').style.display = 'none';
            }

            // Handle part form submission
            document.getElementById('part-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const partData = Object.fromEntries(formData.entries());
                
                // Convert numeric fields
                partData.quantity = parseInt(partData.quantity) || 0;
                partData.min_quantity = parseInt(partData.min_quantity) || 0;
                partData.unit_cost = parseFloat(partData.unit_cost) || 0.0;

                try {
                    let response;
                    if (editingPartId) {
                        response = await fetch(`/parts-test/${editingPartId}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(partData)
                        });
                    } else {
                        response = await fetch('/parts-test/', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(partData)
                        });
                    }

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeModal();
                        loadParts();
                    } else {
                        showError('Failed to save part');
                    }
                } catch (error) {
                    showError('Error saving part: ' + error.message);
                }
            });

            // Handle issue form submission
            document.getElementById('issue-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const issueData = Object.fromEntries(formData.entries());
                issueData.quantity = parseInt(issueData.quantity);

                try {
                    const response = await fetch(`/parts-test/${issuingPartId}/issue`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(issueData)
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeIssueModal();
                        loadParts();
                    } else {
                        showError(data.detail || 'Failed to issue part');
                    }
                } catch (error) {
                    showError('Error issuing part: ' + error.message);
                }
            });

            async function deletePart(partId) {
                if (!confirm('Are you sure you want to delete this part? This action cannot be undone.')) {
                    return;
                }

                try {
                    const response = await fetch(`/parts-test/${partId}`, {
                        method: 'DELETE'
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadParts();
                    } else {
                        showError('Failed to delete part');
                    }
                } catch (error) {
                    showError('Error deleting part: ' + error.message);
                }
            }

            function showSuccess(message) {
                alert('✅ ' + message);
            }

            function showError(message) {
                alert('❌ ' + message);
            }

            // Close modals when clicking outside
            window.onclick = function(event) {
                const partModal = document.getElementById('part-modal');
                const issueModal = document.getElementById('issue-modal');
                
                if (event.target === partModal) {
                    partModal.style.display = 'none';
                }
                if (event.target === issueModal) {
                    issueModal.style.display = 'none';
                }
            }
        </script>
    </body>
    </html>
    ''')

def generate_parts_html():
    html = ""
    for part in PARTS:
        if part['quantity'] < part['min_quantity']:
            stock_class = "critical-stock" 
            stock_indicator = f'<span class="stock-indicator" style="background: #c0392b;">CRITICAL</span>'
        elif part['quantity'] <= part['min_quantity']:
            stock_class = "low-stock"
            stock_indicator = f'<span class="stock-indicator" style="background: #e67e22;">LOW STOCK</span>'
        else:
            stock_class = "normal-stock"
            stock_indicator = f'<span class="stock-indicator" style="background: #27ae60;">IN STOCK</span>'
        
        total_value = part['quantity'] * part['unit_cost']
        
        html += f'''
        <div class="part">
            <h3>{part['name']} <span class="{stock_class}">({part['quantity']} units)</span> {stock_indicator}</h3>
            <p><strong>ID:</strong> {part['id']} | <strong>Part #:</strong> {part['part_number']} | <strong>Category:</strong> {part['category']}</p>
            <p><strong>Location:</strong> {part['location']} | <strong>Supplier:</strong> {part['supplier']}</p>
            <p><strong>Unit Cost:</strong> ${part['unit_cost']:.2f} | <strong>Total Value:</strong> ${total_value:.2f}</p>
            <p><strong>Min Quantity:</strong> {part['min_quantity']} | <strong>Last Ordered:</strong> {part['last_ordered']}</p>
        </div>
        '''
    return html

def generate_csv_data():
    csv_lines = []
    for part in PARTS:
        line = f'"{part["id"]}","{part["name"]}","{part["part_number"]}",{part["quantity"]},{part["min_quantity"]},{part["unit_cost"]},"{part["location"]}","{part["supplier"]}"'
        csv_lines.append(line)
    return '"' + '\\n" +\n                    "'.join(csv_lines) + '"'

@router.get("/")
async def list_parts():
    """Get all parts as JSON"""
    return {"parts": PARTS, "count": len(PARTS)}

@router.get("/{part_id}")
async def get_part(part_id: str):
    """Get specific part"""
    part = next((p for p in PARTS if p["id"] == part_id), None)
    if not part:
        raise HTTPException(status_code=404, detail="Part not found")
    return part

@router.get("/low-stock/alerts")
async def get_low_stock_alerts():
    """Get parts that need reordering"""
    low_stock = [p for p in PARTS if p['quantity'] <= p['min_quantity']]
    return {"low_stock_parts": low_stock, "count": len(low_stock)}

print("✅ Simple Parts module loaded")