#!/usr/bin/env python3
"""
Quick Comprehensive CMMS Validation Script
Tests all major workflows with rate limiting to avoid crashes
"""

import requests
import time
import json
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:8000"
DELAY_BETWEEN_REQUESTS = 1.0  # 1 second delay to avoid overwhelming the server

class CMMSValidator:
    def __init__(self):
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "base_url": BASE_URL,
            "test_results": {},
            "summary": {
                "total_tests": 0,
                "passed": 0,
                "failed": 0,
                "warnings": 0
            }
        }
        
    def test_endpoint(self, name, url, method="GET", data=None, headers=None):
        """Test an endpoint with rate limiting"""
        print(f"🧪 Testing {name}...")
        time.sleep(DELAY_BETWEEN_REQUESTS)  # Rate limiting
        
        try:
            if method == "GET":
                response = requests.get(f"{BASE_URL}{url}", timeout=10)
            elif method == "POST":
                response = requests.post(f"{BASE_URL}{url}", json=data, headers=headers, timeout=10)
            
            self.results["test_results"][name] = {
                "url": url,
                "method": method,
                "status_code": response.status_code,
                "success": 200 <= response.status_code < 400,
                "response_time": response.elapsed.total_seconds(),
                "content_length": len(response.content)
            }
            
            if 200 <= response.status_code < 400:
                print(f"  ✅ {name}: {response.status_code}")
                self.results["summary"]["passed"] += 1
            else:
                print(f"  ❌ {name}: {response.status_code}")
                self.results["summary"]["failed"] += 1
                
        except Exception as e:
            print(f"  🔴 {name}: Exception - {str(e)}")
            self.results["test_results"][name] = {
                "url": url,
                "method": method,
                "error": str(e),
                "success": False
            }
            self.results["summary"]["failed"] += 1
            
        self.results["summary"]["total_tests"] += 1
        
    def run_tests(self):
        print("🚀 Starting Comprehensive CMMS Validation")
        print("=" * 60)
        
        # Core System Tests
        print("\n📊 Testing Core System...")
        self.test_endpoint("health_check", "/health")
        self.test_endpoint("system_status", "/status") 
        self.test_endpoint("main_page", "/")
        
        # Dashboard Tests
        print("\n📈 Testing Dashboard Module...")
        self.test_endpoint("main_dashboard", "/dashboard/dashboard/main")
        
        # Work Orders Tests  
        print("\n📋 Testing Work Orders Module...")
        self.test_endpoint("workorders_dashboard", "/workorders/workorders/dashboard")
        self.test_endpoint("workorders_list", "/workorders/workorders/")
        self.test_endpoint("workorders_calendar", "/workorders/workorders/calendar")
        
        # Assets Tests
        print("\n⚙️ Testing Assets Module...")
        self.test_endpoint("assets_dashboard", "/assets/assets/dashboard")
        self.test_endpoint("assets_list", "/assets/assets/")
        self.test_endpoint("assets_kpis", "/assets/assets/kpis/dashboard")
        
        # AI Tests
        print("\n🤖 Testing AI Module...")
        self.test_endpoint("ai_health", "/ai/ai/health")
        self.test_endpoint("ai_dashboard", "/ai/ai/dashboard")
        
        # AI Chat Test (POST)
        self.test_endpoint("ai_chat", "/ai/ai/chat", "POST", {
            "message": "Test maintenance question",
            "context": "general",
            "user_type": "technician"
        })
        
        # Technician Tests
        print("\n👷 Testing Technician Module...")
        self.test_endpoint("technician_portal", "/technician/technicians/portal")
        self.test_endpoint("technician_list", "/technician/technicians/")
        
        # Admin Tests
        print("\n⚖️ Testing Admin Module...")
        self.test_endpoint("admin_dashboard", "/admin/admin/dashboard")
        self.test_endpoint("admin_stats", "/admin/admin/stats")
        
        print("\n" + "=" * 60)
        print("🎉 Testing Complete!")
        
        # Generate summary
        total = self.results["summary"]["total_tests"]
        passed = self.results["summary"]["passed"]
        failed = self.results["summary"]["failed"]
        success_rate = (passed / total * 100) if total > 0 else 0
        
        print(f"📊 Results: {passed}/{total} tests passed ({success_rate:.1f}% success rate)")
        
        if success_rate >= 90:
            print("🟢 System Health: EXCELLENT")
        elif success_rate >= 75:
            print("🟡 System Health: GOOD")
        elif success_rate >= 50:
            print("🟠 System Health: FAIR") 
        else:
            print("🔴 System Health: POOR")
            
        return self.results

if __name__ == "__main__":
    validator = CMMSValidator()
    validator.run_tests()
