#!/usr/bin/env python3
"""
ChatterFix CMMS - RAG API Router
REST API endpoints for document search and question answering with citations
"""

import asyncio
import time
from typing import Dict, List, Optional, Any
from fastapi import APIRouter, HTTPException, Query, UploadFile, File, Form, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import secrets
from pathlib import Path
import shutil
import os

from rag_system import (
    rag_system,
    build_document_index,
    search_documents,
    answer_question,
    get_rag_statistics,
    SearchResult,
    RAGResponse,
    Citation
)

# =============================================================================
# API Models
# =============================================================================

class SearchRequest(BaseModel):
    query: str
    max_results: Optional[int] = 10
    category_filter: Optional[str] = None
    score_threshold: Optional[float] = 0.0

class SearchResponse(BaseModel):
    query: str
    results: List[Dict[str, Any]]
    total_results: int
    processing_time_ms: int

class AnswerRequest(BaseModel):
    question: str
    max_context_chunks: Optional[int] = 5
    category_filter: Optional[str] = None

class AnswerResponse(BaseModel):
    question: str
    answer: str
    citations: List[Dict[str, Any]]
    confidence_score: Optional[float] = None
    processing_time_ms: int
    sources_count: int

class IndexBuildRequest(BaseModel):
    force_rebuild: Optional[bool] = False
    category_filter: Optional[str] = None

class IndexBuildResponse(BaseModel):
    status: str
    documents_processed: int
    total_chunks: int
    build_time_seconds: float
    message: str

class DocumentUploadResponse(BaseModel):
    filename: str
    document_id: str
    file_size: int
    category: str
    chunks_created: int
    processing_time_ms: int
    status: str

# =============================================================================
# Router Setup
# =============================================================================

router = APIRouter(prefix="/ai", tags=["AI/RAG"])

# =============================================================================
# Document Management Endpoints
# =============================================================================

@router.post("/documents/upload", response_model=DocumentUploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    category: str = Form("general"),
    description: Optional[str] = Form(None)
):
    """
    Upload a document for RAG processing
    Supports: PDF, TXT, MD, PNG, JPG, JPEG, TIFF, BMP
    """
    start_time = time.time()
    
    try:
        # Validate file type
        allowed_extensions = {'.pdf', '.txt', '.md', '.png', '.jpg', '.jpeg', '.tiff', '.bmp'}
        file_extension = Path(file.filename).suffix.lower()
        
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file_extension}. Allowed: {', '.join(allowed_extensions)}"
            )
        
        # Create category directory
        upload_dir = Path("documents") / category
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate safe filename
        safe_filename = f"{int(time.time())}_{secrets.token_urlsafe(8)}_{file.filename}"
        file_path = upload_dir / safe_filename
        
        # Save uploaded file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        file_size = file_path.stat().st_size
        
        # Process the document
        try:
            doc_metadata, doc_chunks = rag_system.document_processor.process_document(
                str(file_path), 
                category
            )
            
            # Add to vector store (if index is loaded)
            if rag_system.index_loaded:
                rag_system.vector_store.add_documents([doc_metadata], [doc_chunks])
                rag_system.vector_store.save_index(str(rag_system.index_dir))
            
            processing_time = int((time.time() - start_time) * 1000)
            
            return DocumentUploadResponse(
                filename=file.filename,
                document_id=doc_metadata.document_id,
                file_size=file_size,
                category=category,
                chunks_created=len(doc_chunks),
                processing_time_ms=processing_time,
                status="processed"
            )
            
        except Exception as e:
            # Clean up file if processing failed
            if file_path.exists():
                file_path.unlink()
            
            raise HTTPException(
                status_code=500,
                detail=f"Document processing failed: {str(e)}"
            )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Upload failed: {str(e)}"
        )

@router.post("/documents/build-index", response_model=IndexBuildResponse)
async def build_index(request: IndexBuildRequest):
    """
    Build or rebuild the document index
    This processes all documents in the documents/ directory
    """
    try:
        result = await build_document_index(force_rebuild=request.force_rebuild)
        
        if result["status"] == "completed":
            return IndexBuildResponse(
                status="success",
                documents_processed=result["documents_processed"],
                total_chunks=result["total_chunks"],
                build_time_seconds=result["build_time_seconds"],
                message=f"Index built successfully in {result['build_time_seconds']:.2f} seconds"
            )
        elif result["status"] == "skipped":
            return IndexBuildResponse(
                status="skipped",
                documents_processed=0,
                total_chunks=0,
                build_time_seconds=0,
                message="Index already exists and force_rebuild=False"
            )
        elif result["status"] == "no_documents":
            return IndexBuildResponse(
                status="no_documents",
                documents_processed=0,
                total_chunks=0,
                build_time_seconds=0,
                message=f"No documents found in {result['directory']}"
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Index build failed with status: {result['status']}"
            )
            
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Index build failed: {str(e)}"
        )

@router.get("/documents/statistics")
async def get_document_statistics():
    """Get RAG system statistics"""
    try:
        stats = get_rag_statistics()
        
        if stats.get("status") == "index_not_loaded":
            return JSONResponse(
                status_code=503,
                content={
                    "error": "Index not loaded",
                    "message": "Run /ai/documents/build-index first"
                }
            )
        
        return stats
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get statistics: {str(e)}"
        )

# =============================================================================
# Search Endpoints
# =============================================================================

@router.get("/search", response_model=SearchResponse)
async def search_endpoint(
    q: str = Query(..., description="Search query"),
    max_results: int = Query(10, ge=1, le=50, description="Maximum number of results"),
    category: Optional[str] = Query(None, description="Filter by document category"),
    min_score: float = Query(0.0, ge=0.0, le=1.0, description="Minimum relevance score")
):
    """
    Search for relevant document chunks
    Returns ranked results with citations
    """
    start_time = time.time()
    
    try:
        # Perform search
        search_results = await search_documents(
            query=q,
            k=max_results,
            category=category
        )
        
        # Filter by minimum score
        if min_score > 0:
            search_results = [r for r in search_results if r.score >= min_score]
        
        # Convert to API response format
        results = []
        for result in search_results:
            chunk = result.chunk
            doc_metadata = rag_system.vector_store.document_metadata.get(chunk.document_id, {})
            
            result_dict = {
                "chunk_id": chunk.chunk_id,
                "document_id": chunk.document_id,
                "filename": chunk.filename,
                "page_number": chunk.page_number,
                "section_title": chunk.section_title,
                "text": chunk.text,
                "chunk_type": chunk.chunk_type,
                "relevance_score": result.score,
                "rank": result.rank,
                "category": getattr(doc_metadata, 'category', 'unknown'),
                "file_type": getattr(doc_metadata, 'file_type', 'unknown')
            }
            results.append(result_dict)
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return SearchResponse(
            query=q,
            results=results,
            total_results=len(results),
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Search failed: {str(e)}"
        )

@router.post("/search", response_model=SearchResponse)
async def search_post_endpoint(request: SearchRequest):
    """
    Search for relevant document chunks (POST version for complex queries)
    """
    start_time = time.time()
    
    try:
        # Perform search
        search_results = await search_documents(
            query=request.query,
            k=request.max_results,
            category=request.category_filter
        )
        
        # Filter by minimum score
        if request.score_threshold > 0:
            search_results = [r for r in search_results if r.score >= request.score_threshold]
        
        # Convert to API response format
        results = []
        for result in search_results:
            chunk = result.chunk
            doc_metadata = rag_system.vector_store.document_metadata.get(chunk.document_id, {})
            
            result_dict = {
                "chunk_id": chunk.chunk_id,
                "document_id": chunk.document_id,
                "filename": chunk.filename,
                "page_number": chunk.page_number,
                "section_title": chunk.section_title,
                "text": chunk.text,
                "chunk_type": chunk.chunk_type,
                "relevance_score": result.score,
                "rank": result.rank,
                "category": getattr(doc_metadata, 'category', 'unknown'),
                "file_type": getattr(doc_metadata, 'file_type', 'unknown')
            }
            results.append(result_dict)
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return SearchResponse(
            query=request.query,
            results=results,
            total_results=len(results),
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Search failed: {str(e)}"
        )

# =============================================================================
# Question Answering Endpoints
# =============================================================================

@router.get("/answer", response_model=AnswerResponse)
async def answer_endpoint(
    q: str = Query(..., description="Question to answer"),
    max_context: int = Query(5, ge=1, le=20, description="Maximum context chunks to use"),
    category: Optional[str] = Query(None, description="Filter by document category")
):
    """
    Answer a question using RAG with citations
    Returns an answer grounded in the document corpus with source citations
    """
    try:
        # Get RAG response
        rag_response = await answer_question(q, max_context)
        
        # Convert citations to API format
        citations = []
        for citation in rag_response.citations:
            citation_dict = {
                "document_id": citation.document_id,
                "filename": citation.filename,
                "page_number": citation.page_number,
                "section_title": citation.section_title,
                "excerpt": citation.chunk_text,
                "relevance_score": citation.relevance_score
            }
            citations.append(citation_dict)
        
        # Calculate confidence score based on top result score
        confidence_score = None
        if rag_response.search_results:
            confidence_score = float(rag_response.search_results[0].score)
        
        return AnswerResponse(
            question=q,
            answer=rag_response.answer,
            citations=citations,
            confidence_score=confidence_score,
            processing_time_ms=rag_response.processing_time_ms,
            sources_count=len(citations)
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Question answering failed: {str(e)}"
        )

@router.post("/answer", response_model=AnswerResponse)
async def answer_post_endpoint(request: AnswerRequest):
    """
    Answer a question using RAG (POST version for complex requests)
    """
    try:
        # Get RAG response
        rag_response = await answer_question(request.question, request.max_context_chunks)
        
        # Convert citations to API format
        citations = []
        for citation in rag_response.citations:
            citation_dict = {
                "document_id": citation.document_id,
                "filename": citation.filename,
                "page_number": citation.page_number,
                "section_title": citation.section_title,
                "excerpt": citation.chunk_text,
                "relevance_score": citation.relevance_score
            }
            citations.append(citation_dict)
        
        # Calculate confidence score based on top result score
        confidence_score = None
        if rag_response.search_results:
            confidence_score = float(rag_response.search_results[0].score)
        
        return AnswerResponse(
            question=request.question,
            answer=rag_response.answer,
            citations=citations,
            confidence_score=confidence_score,
            processing_time_ms=rag_response.processing_time_ms,
            sources_count=len(citations)
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Question answering failed: {str(e)}"
        )

# =============================================================================
# Specialized Query Endpoints
# =============================================================================

@router.get("/torque-specs")
async def get_torque_specs(
    component: str = Query(..., description="Component name (e.g., Motor-X)"),
    part_number: Optional[str] = Query(None, description="Specific part number")
):
    """
    Specialized endpoint for torque specifications
    Example: /ai/torque-specs?component=Motor-X
    """
    try:
        # Construct torque-specific query
        query_parts = [f"torque specification for {component}"]
        if part_number:
            query_parts.append(f"part number {part_number}")
        
        query = " ".join(query_parts)
        
        # Get answer focused on torque specs
        rag_response = await answer_question(query, max_context=3)
        
        # Extract torque values using regex
        import re
        torque_pattern = r'(\d+\.?\d*)\s*(?:Nm|N·m|ft\.?lbs?|in\.?lbs?)'
        
        torque_specs = []
        for result in rag_response.search_results:
            matches = re.finditer(torque_pattern, result.chunk.text, re.IGNORECASE)
            for match in matches:
                context_start = max(0, match.start() - 30)
                context_end = min(len(result.chunk.text), match.end() + 50)
                context = result.chunk.text[context_start:context_end].strip()
                
                torque_specs.append({
                    "value": match.group(0),
                    "context": context,
                    "filename": result.chunk.filename,
                    "page_number": result.chunk.page_number,
                    "confidence": result.score
                })
        
        return {
            "component": component,
            "part_number": part_number,
            "query": query,
            "torque_specifications": torque_specs,
            "answer": rag_response.answer,
            "sources": len(rag_response.citations)
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Torque spec lookup failed: {str(e)}"
        )

@router.get("/sop-lookup")
async def get_sop_procedure(
    procedure: str = Query(..., description="Procedure name (e.g., Pump-12 seal replacement)"),
    step_filter: Optional[str] = Query(None, description="Filter for specific steps")
):
    """
    Specialized endpoint for SOP procedures
    Example: /ai/sop-lookup?procedure=Pump-12 seal replacement
    """
    try:
        # Construct SOP-specific query
        query = f"SOP procedure for {procedure}"
        if step_filter:
            query += f" {step_filter}"
        
        # Get answer focused on procedures
        rag_response = await answer_question(query, max_context=5)
        
        # Extract structured steps
        steps = []
        for result in rag_response.search_results:
            text = result.chunk.text
            
            # Look for numbered steps
            step_patterns = [
                r'(?:Step\s*)?(\d+)[\.\:\-]\s*([^\n]+)',
                r'^\s*(\d+)[\.\:\-]\s*([^\n]+)',
            ]
            
            for pattern in step_patterns:
                matches = re.finditer(pattern, text, re.MULTILINE)
                for match in matches:
                    if len(match.groups()) >= 2:
                        steps.append({
                            "step_number": match.group(1),
                            "instruction": match.group(2).strip(),
                            "source_file": result.chunk.filename,
                            "page_number": result.chunk.page_number,
                            "confidence": result.score
                        })
        
        return {
            "procedure": procedure,
            "query": query,
            "steps": steps[:20],  # Limit to 20 steps
            "full_answer": rag_response.answer,
            "citations": [
                {
                    "filename": c.filename,
                    "page_number": c.page_number,
                    "section": c.section_title,
                    "relevance": c.relevance_score
                }
                for c in rag_response.citations
            ]
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"SOP lookup failed: {str(e)}"
        )

# =============================================================================
# Health Check
# =============================================================================

@router.get("/rag/health")
async def rag_health_check():
    """RAG system health check"""
    try:
        stats = get_rag_statistics()
        
        health_status = {
            "status": "healthy" if stats.get("total_documents", 0) > 0 else "no_documents",
            "index_loaded": rag_system.index_loaded,
            "documents": stats.get("total_documents", 0),
            "chunks": stats.get("total_chunks", 0),
            "embedding_model": stats.get("embedding_model", "unknown"),
            "categories": stats.get("categories", {}),
            "timestamp": time.time()
        }
        
        return health_status
        
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "timestamp": time.time()
        }