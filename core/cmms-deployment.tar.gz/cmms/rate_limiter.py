#!/usr/bin/env python3
"""
ChatterFix CMMS - Advanced Rate Limiting Module
Comprehensive rate limiting for authentication and AI endpoints with Redis and memory backends
"""

import os
import time
import json
import hashlib
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta, timezone
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
import secrets
import asyncio

# =============================================================================
# Configuration
# =============================================================================

# Rate limiting configuration from environment
REDIS_URL = os.getenv("REDIS_URL", None)  # Redis connection for distributed limiting
RATE_LIMIT_BACKEND = os.getenv("RATE_LIMIT_BACKEND", "memory")  # "redis" or "memory"
ENABLE_RATE_LIMITING = os.getenv("ENABLE_RATE_LIMITING", "true").lower() == "true"

# Default rate limits (requests per time window)
DEFAULT_RATE_LIMITS = {
    # Authentication endpoints - stricter limits
    "auth_login": {"requests": 5, "window": 300, "burst": 10},      # 5/5min, burst 10
    "auth_refresh": {"requests": 20, "window": 300, "burst": 30},   # 20/5min, burst 30
    "auth_logout": {"requests": 10, "window": 60, "burst": 15},     # 10/1min, burst 15
    "auth_change_password": {"requests": 3, "window": 600, "burst": 5},  # 3/10min, burst 5
    
    # AI endpoints - optimized for production use
    "ai_chat": {"requests": 60, "window": 300, "burst": 100},       # 60/5min, burst 100
    "ai_analyze": {"requests": 40, "window": 300, "burst": 60},     # 40/5min, burst 60
    "ai_voice": {"requests": 30, "window": 300, "burst": 45},       # 30/5min, burst 45
    "ai_suggestions": {"requests": 80, "window": 300, "burst": 120}, # 80/5min, burst 120
    
    # Llama-specific endpoints - more conservative limits
    "llama_chat": {"requests": 30, "window": 300, "burst": 50},     # 30/5min, burst 50
    "llama_analysis": {"requests": 20, "window": 300, "burst": 30}, # 20/5min, burst 30
    "llama_voice": {"requests": 15, "window": 300, "burst": 25},    # 15/5min, burst 25
    
    # General API endpoints - more permissive
    "api_general": {"requests": 100, "window": 300, "burst": 150},  # 100/5min, burst 150
    "api_read": {"requests": 200, "window": 300, "burst": 300},     # 200/5min, burst 300
    
    # Admin endpoints - restricted
    "admin": {"requests": 50, "window": 300, "burst": 75},          # 50/5min, burst 75
    
    # File upload endpoints - very strict
    "upload": {"requests": 10, "window": 600, "burst": 15},         # 10/10min, burst 15
}

# Per-user vs per-IP rate limiting
USER_RATE_LIMITS = {
    "admin": {"multiplier": 2.0},      # Admins get 2x limits
    "manager": {"multiplier": 1.5},    # Managers get 1.5x limits
    "technician": {"multiplier": 1.0}, # Standard limits
    "viewer": {"multiplier": 0.8}      # Viewers get reduced limits
}

# Llama-specific rate limiting configuration
LLAMA_RATE_LIMITS = {
    "max_concurrent_requests": 3,       # Max concurrent Llama requests
    "cooldown_after_burst": 60,         # Cooldown period after burst limit hit (seconds)
    "analysis_timeout": 120,            # Max time for analysis requests (seconds)
    "chat_timeout": 60,                 # Max time for chat requests (seconds)
    "voice_timeout": 90                 # Max time for voice requests (seconds)
}

# Suspicious activity thresholds
SUSPICIOUS_THRESHOLDS = {
    "failed_auth_attempts": 10,        # Failed auth attempts in window
    "burst_requests": 5,               # Times burst limit hit
    "blocked_requests": 20,            # Blocked requests in window
    "unique_endpoints": 15             # Different endpoints hit rapidly
}

# =============================================================================
# Data Models
# =============================================================================

@dataclass
class RateLimitInfo:
    """Rate limit information for a key"""
    requests: int           # Current request count
    window_start: float    # Window start timestamp
    window_size: int       # Window size in seconds
    limit: int             # Request limit
    burst_limit: int       # Burst limit
    burst_count: int       # Current burst count
    last_request: float    # Last request timestamp
    blocked_count: int     # Number of blocked requests
    reset_time: float      # When the window resets

@dataclass
class RateLimitResult:
    """Result of rate limit check"""
    allowed: bool
    limit: int
    remaining: int
    reset_time: float
    retry_after: Optional[int]
    burst_remaining: int
    reason: Optional[str] = None
    request_id: Optional[str] = None

@dataclass
class SuspiciousActivity:
    """Suspicious activity tracking"""
    ip_address: str
    user_id: Optional[str]
    activity_type: str
    count: int
    first_seen: datetime
    last_seen: datetime
    endpoints: List[str]
    blocked: bool = False

# =============================================================================
# Memory Backend Implementation
# =============================================================================

class MemoryRateLimitBackend:
    """In-memory rate limiting backend"""
    
    def __init__(self):
        self.limits: Dict[str, RateLimitInfo] = {}
        self.suspicious_activity: Dict[str, SuspiciousActivity] = {}
        self.llama_concurrent_requests: Dict[str, int] = {}  # Track concurrent Llama requests
        self.cleanup_interval = 300  # 5 minutes
        self.last_cleanup = time.time()
    
    def _cleanup_expired(self):
        """Clean up expired rate limit entries"""
        now = time.time()
        
        # Only cleanup periodically to avoid performance impact
        if now - self.last_cleanup < self.cleanup_interval:
            return
        
        expired_keys = []
        for key, info in self.limits.items():
            if now - info.window_start > info.window_size * 2:  # Keep for 2 windows
                expired_keys.append(key)
        
        for key in expired_keys:
            del self.limits[key]
        
        # Cleanup suspicious activity older than 1 hour
        expired_suspicious = []
        cutoff_time = datetime.now(timezone.utc) - timedelta(hours=1)
        for key, activity in self.suspicious_activity.items():
            if activity.last_seen < cutoff_time:
                expired_suspicious.append(key)
        
        for key in expired_suspicious:
            del self.suspicious_activity[key]
        
        self.last_cleanup = now
    
    async def check_rate_limit(
        self,
        key: str,
        limit: int,
        window: int,
        burst_limit: int
    ) -> RateLimitResult:
        """Check if request is within rate limits"""
        self._cleanup_expired()
        
        now = time.time()
        
        if key not in self.limits:
            # First request for this key
            self.limits[key] = RateLimitInfo(
                requests=1,
                window_start=now,
                window_size=window,
                limit=limit,
                burst_limit=burst_limit,
                burst_count=1,
                last_request=now,
                blocked_count=0,
                reset_time=now + window
            )
            
            return RateLimitResult(
                allowed=True,
                limit=limit,
                remaining=limit - 1,
                reset_time=now + window,
                retry_after=None,
                burst_remaining=burst_limit - 1
            )
        
        info = self.limits[key]
        
        # Check if we're in a new window
        if now - info.window_start >= info.window_size:
            # Start new window
            info.requests = 1
            info.window_start = now
            info.burst_count = 1
            info.last_request = now
            info.reset_time = now + window
            
            return RateLimitResult(
                allowed=True,
                limit=limit,
                remaining=limit - 1,
                reset_time=info.reset_time,
                retry_after=None,
                burst_remaining=burst_limit - 1
            )
        
        # Check burst limit (short-term)
        time_since_last = now - info.last_request
        if time_since_last < 1.0:  # Within 1 second
            info.burst_count += 1
            if info.burst_count > burst_limit:
                info.blocked_count += 1
                return RateLimitResult(
                    allowed=False,
                    limit=limit,
                    remaining=max(0, limit - info.requests),
                    reset_time=info.reset_time,
                    retry_after=int(info.reset_time - now),
                    burst_remaining=0,
                    reason="Burst limit exceeded"
                )
        else:
            # Reset burst counter if enough time has passed
            info.burst_count = 1
        
        # Check regular rate limit
        if info.requests >= limit:
            info.blocked_count += 1
            return RateLimitResult(
                allowed=False,
                limit=limit,
                remaining=0,
                reset_time=info.reset_time,
                retry_after=int(info.reset_time - now),
                burst_remaining=max(0, burst_limit - info.burst_count),
                reason="Rate limit exceeded"
            )
        
        # Allow the request
        info.requests += 1
        info.last_request = now
        
        return RateLimitResult(
            allowed=True,
            limit=limit,
            remaining=limit - info.requests,
            reset_time=info.reset_time,
            retry_after=None,
            burst_remaining=max(0, burst_limit - info.burst_count)
        )
    
    async def record_suspicious_activity(
        self,
        ip_address: str,
        user_id: Optional[str],
        activity_type: str,
        endpoint: str
    ):
        """Record suspicious activity"""
        key = f"{ip_address}:{user_id or 'anonymous'}"
        now = datetime.now(timezone.utc)
        
        if key in self.suspicious_activity:
            activity = self.suspicious_activity[key]
            activity.count += 1
            activity.last_seen = now
            if endpoint not in activity.endpoints:
                activity.endpoints.append(endpoint)
        else:
            self.suspicious_activity[key] = SuspiciousActivity(
                ip_address=ip_address,
                user_id=user_id,
                activity_type=activity_type,
                count=1,
                first_seen=now,
                last_seen=now,
                endpoints=[endpoint]
            )
    
    async def get_suspicious_activities(self) -> List[Dict]:
        """Get list of suspicious activities"""
        return [asdict(activity) for activity in self.suspicious_activity.values()]
    
    async def is_blocked(self, ip_address: str, user_id: Optional[str] = None) -> bool:
        """Check if IP/user is blocked due to suspicious activity"""
        key = f"{ip_address}:{user_id or 'anonymous'}"
        activity = self.suspicious_activity.get(key)
        
        if not activity:
            return False
        
        return activity.blocked
    
    async def check_llama_concurrent_limit(self, client_key: str) -> bool:
        """Check if client has exceeded Llama concurrent request limit"""
        current_requests = self.llama_concurrent_requests.get(client_key, 0)
        max_concurrent = LLAMA_RATE_LIMITS["max_concurrent_requests"]
        
        return current_requests < max_concurrent
    
    async def increment_llama_requests(self, client_key: str):
        """Increment Llama concurrent request counter"""
        current = self.llama_concurrent_requests.get(client_key, 0)
        self.llama_concurrent_requests[client_key] = current + 1
    
    async def decrement_llama_requests(self, client_key: str):
        """Decrement Llama concurrent request counter"""
        current = self.llama_concurrent_requests.get(client_key, 0)
        if current > 0:
            self.llama_concurrent_requests[client_key] = current - 1
        
        # Clean up if no active requests
        if self.llama_concurrent_requests.get(client_key, 0) == 0:
            self.llama_concurrent_requests.pop(client_key, None)

# =============================================================================
# Rate Limiter Core
# =============================================================================

class RateLimiter:
    """Advanced rate limiter with multiple backends"""
    
    def __init__(self):
        self.backend = MemoryRateLimitBackend()  # Default to memory backend
        self.enabled = ENABLE_RATE_LIMITING
        
        # Try to initialize Redis if configured
        if REDIS_URL and RATE_LIMIT_BACKEND == "redis":
            try:
                # Would implement Redis backend here
                pass
            except Exception:
                # Fallback to memory backend
                pass
    
    def _get_endpoint_category(self, path: str, method: str) -> str:
        """Categorize endpoint for appropriate rate limiting"""
        path_lower = path.lower()
        
        # Authentication endpoints
        if "/auth/login" in path_lower:
            return "auth_login"
        elif "/auth/refresh" in path_lower:
            return "auth_refresh"
        elif "/auth/logout" in path_lower:
            return "auth_logout"
        elif "/auth/change-password" in path_lower:
            return "auth_change_password"
        elif path_lower.startswith("/auth"):
            return "auth_login"  # Default for auth endpoints
        
        # Llama-specific endpoints (check first for specificity)
        elif "llama" in path_lower and ("/chat" in path_lower or "/ai/chat" in path_lower):
            return "llama_chat"
        elif "llama" in path_lower and ("/analyze" in path_lower or "/analysis" in path_lower):
            return "llama_analysis" 
        elif "llama" in path_lower and "/voice" in path_lower:
            return "llama_voice"
        elif "llama" in path_lower:
            return "llama_chat"  # Default for Llama endpoints
        
        # General AI endpoints
        elif "/ai/chat" in path_lower or "/chat" in path_lower:
            return "ai_chat"
        elif "/ai/analyze" in path_lower:
            return "ai_analyze"
        elif "/ai/voice" in path_lower or "/voice" in path_lower:
            return "ai_voice"
        elif "/ai/suggestions" in path_lower:
            return "ai_suggestions"
        elif path_lower.startswith("/ai"):
            return "ai_chat"  # Default for AI endpoints
        
        # Admin endpoints
        elif "/admin" in path_lower:
            return "admin"
        
        # Upload endpoints
        elif "upload" in path_lower:
            return "upload"
        
        # Read vs Write operations
        elif method in ["GET", "HEAD", "OPTIONS"]:
            return "api_read"
        else:
            return "api_general"
    
    def _get_client_identifier(self, request: Request) -> Tuple[str, Optional[str]]:
        """Get client identifier (IP + user if authenticated)"""
        # Get IP address (considering proxies)
        ip = request.client.host if request.client else "unknown"
        
        # Check for forwarded headers
        forwarded_for = request.headers.get("x-forwarded-for")
        if forwarded_for:
            ip = forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            ip = real_ip.strip()
        
        # Get user ID if available (from auth token)
        user_id = None
        try:
            auth_header = request.headers.get("authorization")
            if auth_header and auth_header.startswith("Bearer "):
                from auth_rbac import decode_token
                token = auth_header[7:]  # Remove "Bearer "
                token_data = decode_token(token)
                if token_data:
                    user_id = token_data.user_id
        except Exception:
            pass
        
        return ip, user_id
    
    def _apply_user_multiplier(self, limits: Dict, user_role: Optional[str]) -> Dict:
        """Apply user role multiplier to limits"""
        if not user_role or user_role not in USER_RATE_LIMITS:
            return limits
        
        multiplier = USER_RATE_LIMITS[user_role]["multiplier"]
        
        return {
            "requests": int(limits["requests"] * multiplier),
            "window": limits["window"],
            "burst": int(limits["burst"] * multiplier)
        }
    
    async def check_rate_limit(self, request: Request) -> RateLimitResult:
        """Check rate limit for incoming request"""
        if not self.enabled:
            return RateLimitResult(
                allowed=True,
                limit=999999,
                remaining=999999,
                reset_time=time.time() + 3600,
                retry_after=None,
                burst_remaining=999999
            )
        
        ip_address, user_id = self._get_client_identifier(request)
        
        # Check if client is blocked
        if await self.backend.is_blocked(ip_address, user_id):
            return RateLimitResult(
                allowed=False,
                limit=0,
                remaining=0,
                reset_time=time.time() + 3600,
                retry_after=3600,
                burst_remaining=0,
                reason="Client blocked due to suspicious activity"
            )
        
        # Get endpoint category and limits
        category = self._get_endpoint_category(str(request.url.path), request.method)
        base_limits = DEFAULT_RATE_LIMITS.get(category, DEFAULT_RATE_LIMITS["api_general"])
        
        # Apply user role multiplier if authenticated
        user_role = None
        try:
            if user_id:
                # Would get user role from database/cache
                # For now, using default
                pass
        except Exception:
            pass
        
        limits = self._apply_user_multiplier(base_limits, user_role)
        
        # Create rate limit key
        key_parts = [ip_address, category]
        if user_id:
            key_parts.append(user_id)
        
        rate_limit_key = ":".join(key_parts)
        
        # Check Llama-specific concurrent limits if applicable
        if category.startswith("llama_"):
            client_key = f"{ip_address}:{user_id or 'anonymous'}"
            if not await self.backend.check_llama_concurrent_limit(client_key):
                return RateLimitResult(
                    allowed=False,
                    limit=limits["requests"],
                    remaining=0,
                    reset_time=time.time() + LLAMA_RATE_LIMITS["cooldown_after_burst"],
                    retry_after=LLAMA_RATE_LIMITS["cooldown_after_burst"],
                    burst_remaining=0,
                    reason="Llama concurrent request limit exceeded",
                    request_id=getattr(request.state, "request_id", secrets.token_urlsafe(8))
                )
        
        # Check rate limit
        result = await self.backend.check_rate_limit(
            key=rate_limit_key,
            limit=limits["requests"],
            window=limits["window"],
            burst_limit=limits["burst"]
        )
        
        result.request_id = getattr(request.state, "request_id", secrets.token_urlsafe(8))
        
        # If Llama request is allowed, increment concurrent counter
        if result.allowed and category.startswith("llama_"):
            await self.backend.increment_llama_requests(client_key)
        
        # Record suspicious activity if rate limited
        if not result.allowed:
            await self.backend.record_suspicious_activity(
                ip_address=ip_address,
                user_id=user_id,
                activity_type="rate_limit_exceeded",
                endpoint=str(request.url.path)
            )
        
        return result
    
    async def get_rate_limit_info(self, ip_address: str, user_id: Optional[str] = None) -> Dict:
        """Get rate limit information for client"""
        activities = await self.backend.get_suspicious_activities()
        
        client_key = f"{ip_address}:{user_id or 'anonymous'}"
        client_activity = None
        
        for activity in activities:
            activity_key = f"{activity['ip_address']}:{activity['user_id'] or 'anonymous'}"
            if activity_key == client_key:
                client_activity = activity
                break
        
        return {
            "ip_address": ip_address,
            "user_id": user_id,
            "suspicious_activity": client_activity,
            "rate_limits": DEFAULT_RATE_LIMITS,
            "user_multipliers": USER_RATE_LIMITS
        }

# =============================================================================
# Rate Limiting Middleware
# =============================================================================

class RateLimitingMiddleware:
    """Middleware for rate limiting"""
    
    def __init__(self, app):
        self.app = app
        self.rate_limiter = RateLimiter()
    
    async def __call__(self, scope, receive, send):
        """ASGI middleware call"""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        # Create request object
        from fastapi import Request
        request = Request(scope, receive)
        
        # Check rate limit
        rate_limit_result = await self.rate_limiter.check_rate_limit(request)
        
        if not rate_limit_result.allowed:
            # Rate limit exceeded - return 429
            response_body = json.dumps({
                "error": "Rate limit exceeded",
                "limit": rate_limit_result.limit,
                "remaining": rate_limit_result.remaining,
                "reset_time": rate_limit_result.reset_time,
                "retry_after": rate_limit_result.retry_after,
                "reason": rate_limit_result.reason,
                "request_id": rate_limit_result.request_id
            }).encode()
            
            response = {
                "type": "http.response.start",
                "status": 429,
                "headers": [
                    [b"content-type", b"application/json"],
                    [b"x-ratelimit-limit", str(rate_limit_result.limit).encode()],
                    [b"x-ratelimit-remaining", str(rate_limit_result.remaining).encode()],
                    [b"x-ratelimit-reset", str(int(rate_limit_result.reset_time)).encode()],
                    [b"retry-after", str(rate_limit_result.retry_after or 60).encode()],
                    [b"x-request-id", (rate_limit_result.request_id or "unknown").encode()]
                ]
            }
            
            await send(response)
            await send({
                "type": "http.response.body",
                "body": response_body
            })
            return
        
        # Add rate limit headers to successful responses
        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend([
                    [b"x-ratelimit-limit", str(rate_limit_result.limit).encode()],
                    [b"x-ratelimit-remaining", str(rate_limit_result.remaining).encode()],
                    [b"x-ratelimit-reset", str(int(rate_limit_result.reset_time)).encode()],
                    [b"x-ratelimit-burst-remaining", str(rate_limit_result.burst_remaining).encode()]
                ])
                message["headers"] = headers
            await send(message)
        
        await self.app(scope, receive, send_wrapper)

# Global rate limiter instance
rate_limiter = RateLimiter()