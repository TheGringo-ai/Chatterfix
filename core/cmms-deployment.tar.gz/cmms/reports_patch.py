#!/usr/bin/env python3
"""
Maintenance Report Summarization Feature
AI-powered daily/weekly maintenance summaries and insights
"""

# Report summarization endpoints to add to app.py
REPORTS_ENDPOINTS = '''

@app.post("/cmms/reports/daily-summary")
async def daily_maintenance_summary() -> Dict:
    """Generate AI-powered daily maintenance summary"""
    try:
        from datetime import datetime, timedelta
        from workorders import work_orders_db
        from assets import assets_db
        
        today = datetime.now().strftime("%Y-%m-%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        
        # Get today's work orders
        todays_work = [wo for wo in work_orders_db 
                      if wo.get("created_date") == today or wo.get("due_date") == today]
        
        # Get completed work from yesterday
        completed_yesterday = [wo for wo in work_orders_db 
                             if wo.get("created_date") == yesterday and wo.get("status") == "completed"]
        
        # Calculate metrics
        total_today = len(todays_work)
        completed_today = len([wo for wo in todays_work if wo.get("status") == "completed"])
        emergency_today = len([wo for wo in todays_work if wo.get("priority") == "high" or wo.get("priority") == "critical"])
        
        # Use AI to generate summary
        ai_prompt = f"""
Generate a daily maintenance summary report for {today}:

TODAY'S WORK ORDERS ({total_today} total):
- Completed: {completed_today}
- Emergency/High Priority: {emergency_today}
- Status breakdown: {', '.join([wo.get('status', 'unknown') for wo in todays_work])}

YESTERDAY'S COMPLETED WORK ({len(completed_yesterday)}):
{chr(10).join([f"- {wo.get('title', 'Untitled')}: {wo.get('asset_id', 'Unknown asset')}" for wo in completed_yesterday[:5]])}

Please provide:
1. Brief overview of maintenance activity
2. Key highlights or concerns
3. Recommendations for tomorrow
4. Equipment health insights

Keep it concise and actionable for management (3-4 sentences):"""

        from ai import query_llama
        ai_summary = await query_llama(ai_prompt, "daily_report", "report_generator")
        
        return {
            "report_type": "daily_summary",
            "date": today,
            "metrics": {
                "total_work_orders": total_today,
                "completed_today": completed_today,
                "emergency_priority": emergency_today,
                "completion_rate": round((completed_today / max(1, total_today)) * 100, 1),
                "completed_yesterday": len(completed_yesterday)
            },
            "ai_summary": ai_summary,
            "work_orders_today": [
                {
                    "id": wo.get("id"),
                    "title": wo.get("title"),
                    "status": wo.get("status"),
                    "priority": wo.get("priority"),
                    "asset": wo.get("asset_id")
                } for wo in todays_work[:10]  # Limit to 10 for brevity
            ],
            "generated_at": datetime.now().isoformat(),
            "ai_generated": True
        }
        
    except Exception as e:
        logger.error(f"Daily summary generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Report generation failed: {str(e)}")

@app.post("/cmms/reports/weekly-summary")
async def weekly_maintenance_summary() -> Dict:
    """Generate AI-powered weekly maintenance summary"""
    try:
        from datetime import datetime, timedelta
        from workorders import work_orders_db
        
        # Get date range for this week
        today = datetime.now()
        week_start = (today - timedelta(days=today.weekday())).strftime("%Y-%m-%d")
        week_end = today.strftime("%Y-%m-%d")
        
        # Filter work orders for this week
        week_work = [wo for wo in work_orders_db 
                    if week_start <= wo.get("created_date", "2000-01-01") <= week_end]
        
        # Calculate weekly metrics
        total_week = len(week_work)
        completed_week = len([wo for wo in week_work if wo.get("status") == "completed"])
        emergency_week = len([wo for wo in week_work if wo.get("priority") in ["high", "critical"]])
        
        # Analyze by type
        types_count = {}
        for wo in week_work:
            wo_type = wo.get("type", "unknown")
            types_count[wo_type] = types_count.get(wo_type, 0) + 1
        
        # Use AI to generate weekly insights
        ai_prompt = f"""
Generate a weekly maintenance summary for week {week_start} to {week_end}:

WEEKLY STATISTICS:
- Total Work Orders: {total_week}
- Completed: {completed_week}
- Emergency/Critical: {emergency_week}
- Completion Rate: {round((completed_week / max(1, total_week)) * 100, 1)}%

WORK BREAKDOWN BY TYPE:
{chr(10).join([f"- {wtype}: {count}" for wtype, count in types_count.items()])}

TOP WORK ORDERS:
{chr(10).join([f"- {wo.get('title', 'Untitled')} ({wo.get('status', 'unknown')})" for wo in week_work[:5]])}

Provide:
1. Weekly performance assessment
2. Trends and patterns observed
3. Areas needing attention
4. Recommendations for next week

Keep professional and management-ready (4-5 sentences):"""

        from ai import query_llama
        ai_insights = await query_llama(ai_prompt, "weekly_report", "report_generator")
        
        return {
            "report_type": "weekly_summary",
            "week_start": week_start,
            "week_end": week_end,
            "metrics": {
                "total_work_orders": total_week,
                "completed": completed_week,
                "completion_rate": round((completed_week / max(1, total_week)) * 100, 1),
                "emergency_priority": emergency_week,
                "average_per_day": round(total_week / 7, 1)
            },
            "breakdown_by_type": types_count,
            "ai_insights": ai_insights,
            "top_work_orders": [
                {
                    "id": wo.get("id"),
                    "title": wo.get("title"),
                    "status": wo.get("status"),
                    "priority": wo.get("priority"),
                    "type": wo.get("type"),
                    "asset": wo.get("asset_id")
                } for wo in week_work[:10]
            ],
            "generated_at": datetime.now().isoformat(),
            "ai_generated": True
        }
        
    except Exception as e:
        logger.error(f"Weekly summary generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Weekly report generation failed: {str(e)}")

@app.get("/cmms/reports/demo")
async def reports_demo_page():
    """Demo page for maintenance reports"""
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Reports Demo</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; }
        .demo-card { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .report-btn { background: #3498db; color: white; border: none; padding: 12px 24px; 
                     border-radius: 6px; cursor: pointer; font-size: 16px; margin: 10px; }
        .report-btn:hover { background: #2980b9; }
        .metric { display: inline-block; background: white; padding: 15px; margin: 10px; 
                 border-radius: 6px; text-align: center; min-width: 120px; }
        .metric-value { font-size: 24px; font-weight: bold; color: #3498db; }
        .metric-label { font-size: 14px; color: #666; }
        .summary-text { background: white; padding: 20px; border-radius: 8px; margin: 15px 0; 
                       border-left: 4px solid #3498db; }
        .work-item { background: white; padding: 10px; margin: 5px 0; border-radius: 4px; 
                    border-left: 3px solid #27ae60; }
        .work-item.emergency { border-left-color: #e74c3c; }
    </style>
</head>
<body>
    <h1>📊 AI Maintenance Reports</h1>
    
    <div class="demo-card">
        <h3>Generate Intelligent Reports:</h3>
        <button class="report-btn" onclick="generateReport('daily')">📅 Daily Summary</button>
        <button class="report-btn" onclick="generateReport('weekly')">📊 Weekly Analysis</button>
    </div>
    
    <div id="results"></div>
    
    <script>
        async function generateReport(type) {
            const results = document.getElementById('results');
            results.innerHTML = '<div class="demo-card">🤖 Generating AI-powered maintenance report...</div>';
            
            try {
                const response = await fetch(`/cmms/reports/${type}-summary`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    displayReport(data, type);
                } else {
                    results.innerHTML = `<div class="demo-card" style="color: red;">Error: ${data.detail}</div>`;
                }
                
            } catch (error) {
                results.innerHTML = `<div class="demo-card" style="color: red;">Error: ${error.message}</div>`;
            }
        }
        
        function displayReport(data, type) {
            const metrics = data.metrics || {};
            const workOrders = data.work_orders_today || data.top_work_orders || [];
            
            let html = `
                <div class="demo-card">
                    <h3>📋 ${type.charAt(0).toUpperCase() + type.slice(1)} Maintenance Report</h3>
                    <p><strong>Period:</strong> ${data.date || (data.week_start + ' to ' + data.week_end)}</p>
                    
                    <div style="text-align: center;">
                        <div class="metric">
                            <div class="metric-value">${metrics.total_work_orders || 0}</div>
                            <div class="metric-label">Total Work Orders</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">${metrics.completed || metrics.completed_today || 0}</div>
                            <div class="metric-label">Completed</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">${metrics.completion_rate || 0}%</div>
                            <div class="metric-label">Completion Rate</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">${metrics.emergency_priority || 0}</div>
                            <div class="metric-label">Emergency Priority</div>
                        </div>
                    </div>
                </div>
                
                <div class="demo-card">
                    <h3>🤖 AI Analysis</h3>
                    <div class="summary-text">${data.ai_summary || data.ai_insights || 'No analysis available'}</div>
                </div>
            `;
            
            if (workOrders.length > 0) {
                html += `
                    <div class="demo-card">
                        <h3>📋 Recent Work Orders</h3>
                `;
                
                workOrders.forEach(wo => {
                    const isEmergency = wo.priority === 'high' || wo.priority === 'critical';
                    html += `
                        <div class="work-item ${isEmergency ? 'emergency' : ''}">
                            <strong>${wo.title || wo.id}</strong> 
                            <span style="float: right;">
                                ${wo.status || 'Unknown'} | 
                                ${wo.priority || 'medium'} priority
                            </span>
                            <br><small>${wo.asset || 'Unknown asset'}</small>
                        </div>
                    `;
                });
                
                html += '</div>';
            }
            
            document.getElementById('results').innerHTML = html;
        }
    </script>
</body>
</html>""")
'''

def apply_patch():
    """Apply maintenance reports patch to app.py"""
    print("📊 Adding Maintenance Report Summarization feature...")
    
    # Read current app.py
    with open('/opt/chatterfix/app.py', 'r') as f:
        content = f.read()
    
    # Check if already patched
    if '/cmms/reports/daily-summary' in content:
        print("✅ Reports feature already exists")
        return True
    
    # Find insertion point - at the end before if __name__ == "__main__"
    main_pos = content.find('if __name__ == "__main__"')
    if main_pos != -1:
        insertion_point = content.rfind('\\n', 0, main_pos)
    else:
        insertion_point = len(content)
    
    # Insert the reports endpoints
    new_content = (content[:insertion_point] + 
                   REPORTS_ENDPOINTS + 
                   content[insertion_point:])
    
    # Write updated content
    with open('/opt/chatterfix/app.py', 'w') as f:
        f.write(new_content)
    
    print("✅ Maintenance Report Summarization feature added to app.py")
    return True

if __name__ == "__main__":
    apply_patch()