#!/usr/bin/env python3
"""
ChatterFix CMMS - Safety Module
Safety incidents, compliance, training, and hazard management
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Safety router
safety_router = APIRouter(prefix="/safety", tags=["safety"])

# Mock database for demo purposes
safety_incidents_db = [
    {
        "id": "SF-001",
        "title": "Near Miss - Forklift Operation",
        "type": "near_miss",
        "severity": "medium",
        "status": "investigating",
        "reported_by": "TECH-002",
        "incident_date": "2025-09-14",
        "location": "Warehouse A",
        "description": "Forklift nearly collided with pedestrian in blind spot",
        "corrective_actions": ["Install mirrors", "Retraining scheduled"],
        "follow_up_date": "2025-09-20"
    },
    {
        "id": "SF-002", 
        "title": "Chemical Spill Cleanup",
        "type": "incident",
        "severity": "high",
        "status": "closed",
        "reported_by": "TECH-001",
        "incident_date": "2025-09-10",
        "location": "Chemical Storage",
        "description": "Minor hydraulic fluid spill during maintenance",
        "corrective_actions": ["Spill kit used", "Area cleaned", "PPE verified"],
        "follow_up_date": "2025-09-15"
    },
    {
        "id": "SF-003",
        "title": "Lockout/Tagout Procedure Review",
        "type": "audit",
        "severity": "low", 
        "status": "completed",
        "reported_by": "Safety Officer",
        "incident_date": "2025-09-12",
        "location": "Production Line B",
        "description": "Routine LOTO procedure compliance check",
        "corrective_actions": ["All procedures followed correctly"],
        "follow_up_date": "2025-12-12"
    }
]

@safety_router.get("/")
async def safety_root():
    """Redirect to safety dashboard"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/safety/dashboard", status_code=302)

@safety_router.get("/dashboard", response_class=HTMLResponse)
async def safety_dashboard():
    """Safety Management Dashboard"""
    
    # Calculate safety metrics
    total_incidents = len(safety_incidents_db)
    open_incidents = len([s for s in safety_incidents_db if s['status'] != 'closed'])
    high_severity = len([s for s in safety_incidents_db if s['severity'] == 'high'])
    near_misses = len([s for s in safety_incidents_db if s['type'] == 'near_miss'])
    
    return HTMLResponse(f"""
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatterFix CMMS - Safety Management</title>
    <style>
        body{{font-family:'Montserrat',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(135deg,#3498db 0%,#2c3e50 50%,#34495e 100%);min-height:100vh;color:white;line-height:1.6;overflow-x:hidden;font-weight:400}}
        .container{{max-width:1200px;margin:0 auto;padding:2rem}}
        .card{{background:rgba(255,255,255,0.1);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.2);border-radius:20px;padding:2rem;margin:1rem 0}}
        .title{{font-size:2.5rem;font-weight:700;margin-bottom:1rem;text-align:center}}
        .stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1rem;margin:2rem 0}}
        .stat-card{{background:rgba(255,255,255,0.05);padding:1.5rem;border-radius:15px;text-align:center}}
        .stat-value{{font-size:2rem;font-weight:700;color:#f1c40f}}
        .nav{{background:rgba(255,255,255,0.1);padding:1rem;border-radius:15px;margin-bottom:2rem}}
        .nav a{{color:white;text-decoration:none;margin:0 1rem;padding:0.5rem 1rem;border-radius:10px;background:rgba(255,255,255,0.1)}}
        .nav a:hover{{background:rgba(255,255,255,0.2)}}
        .high{{background:rgba(231,76,60,0.2);border-left:4px solid #e74c3c}}
        .medium{{background:rgba(241,196,15,0.2);border-left:4px solid #f1c40f}}
        .low{{background:rgba(56,239,125,0.2);border-left:4px solid #38ef7d}}
        .safety-btn{{background:#e74c3c;border:none;color:white;padding:0.5rem 1rem;border-radius:10px;cursor:pointer;margin:0.5rem}}
        .safety-btn:hover{{background:#c0392b}}
    </style>
</head>
<body>
    <div class="container">
        <nav class="nav">
            <a href="/cmms/workorders/">📋 Work Orders</a>
            <a href="/cmms/assets/">🏭 Assets</a>
            <a href="/cmms/parts/">🔧 Parts</a>
            <a href="/cmms/quality/">✅ Quality</a>
            <a href="/cmms/safety/">🦺 Safety</a>
            <a href="/cmms/technician/">👷 Technician</a>
            <a href="/cmms/admin/">⚙️ Admin</a>
            <a href="/cmms/ai/">🤖 AI</a>
        </nav>
        
        <div class="card">
            <h1 class="title">🦺 Safety Management Dashboard</h1>
            <div style="text-align:center;margin-bottom:2rem">
                <button class="safety-btn">🚨 Report Incident</button>
                <button class="safety-btn">📋 Safety Checklist</button>
                <button class="safety-btn">🎓 Training Records</button>
                <button class="safety-btn">⚠️ Hazard Assessment</button>
            </div>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">{total_incidents}</div>
                    <div>Total Incidents</div>
                    <small>🤖 📊 Last 30 days</small>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{open_incidents}</div>
                    <div>Open Cases</div>
                    <small>🤖 ⚠️ Need attention</small>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{high_severity}</div>
                    <div>High Severity</div>
                    <small>🤖 🚨 Critical issues</small>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{near_misses}</div>
                    <div>Near Misses</div>
                    <small>🤖 📈 Learning opportunities</small>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h3>🚨 Recent Safety Incidents</h3>
            <div style="margin-top:1rem">
                <div class="medium" style="padding:1rem;border-radius:10px;margin:0.5rem 0">
                    <strong>SF-001</strong> - Near Miss - Forklift Operation
                    <span style="float:right;background:#f1c40f;color:#000;padding:0.25rem 0.5rem;border-radius:5px">INVESTIGATING</span>
                    <br><small>📍 Warehouse A • Reported: Sep 14 • Follow-up: Sep 20</small>
                </div>
                <div class="high" style="padding:1rem;border-radius:10px;margin:0.5rem 0">
                    <strong>SF-002</strong> - Chemical Spill Cleanup
                    <span style="float:right;background:#38ef7d;color:#000;padding:0.25rem 0.5rem;border-radius:5px">CLOSED</span>
                    <br><small>📍 Chemical Storage • Reported: Sep 10 • Resolved quickly</small>
                </div>
                <div class="low" style="padding:1rem;border-radius:10px;margin:0.5rem 0">
                    <strong>SF-003</strong> - Lockout/Tagout Procedure Review
                    <span style="float:right;background:#38ef7d;color:#000;padding:0.25rem 0.5rem;border-radius:5px">COMPLETED</span>
                    <br><small>📍 Production Line B • Routine audit • All compliant</small>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h3>🎯 Safety Performance</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1rem;margin-top:1rem">
                <div style="background:rgba(255,255,255,0.05);padding:1.5rem;border-radius:15px">
                    <h4>📊 This Month</h4>
                    <p>✅ 28 days without injury</p>
                    <p>⚠️ 1 near miss reported</p>
                    <p>📋 95% training compliance</p>
                </div>
                <div style="background:rgba(255,255,255,0.05);padding:1.5rem;border-radius:15px">
                    <h4>🎓 Training Status</h4>
                    <p>✅ 45/48 employees current</p>
                    <p>⚠️ 3 renewals due this week</p>
                    <p>📅 Next safety meeting: Sep 20</p>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h3>🤖 AI Safety Insights</h3>
            <div style="margin-top:1rem">
                <div style="padding:1rem;background:rgba(255,255,255,0.05);border-radius:10px;margin:0.5rem 0">
                    🎯 <strong>Pattern Detection</strong><br>
                    <small>Forklift incidents increased 15% - recommend visibility improvements</small>
                </div>
                <div style="padding:1rem;background:rgba(255,255,255,0.05);border-radius:10px;margin:0.5rem 0">
                    📋 <strong>Training Reminder</strong><br>
                    <small>Chemical handling certification expires for 3 techs this month</small>
                </div>
                <div style="padding:1rem;background:rgba(255,255,255,0.05);border-radius:10px;margin:0.5rem 0">
                    ⚠️ <strong>Proactive Alert</strong><br>
                    <small>Weather forecast shows high winds - secure outdoor equipment</small>
                </div>
                <div style="padding:1rem;background:rgba(255,255,255,0.05);border-radius:10px;margin:0.5rem 0">
                    📊 <strong>Benchmarking</strong><br>
                    <small>Safety performance 23% above industry average - excellent work!</small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
""")

@safety_router.get("/api")
async def get_safety_incidents(
    status: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    type: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all safety incidents with optional filtering"""
    filtered_incidents = safety_incidents_db
    
    if status:
        filtered_incidents = [s for s in filtered_incidents if s['status'] == status]
    if severity:
        filtered_incidents = [s for s in filtered_incidents if s['severity'] == severity]
    if type:
        filtered_incidents = [s for s in filtered_incidents if s['type'] == type]
    
    return filtered_incidents

@safety_router.get("/{incident_id}")
async def get_safety_incident(incident_id: str) -> Dict:
    """Get specific safety incident details"""
    incident = next((s for s in safety_incidents_db if s['id'] == incident_id), None)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    return incident