#!/usr/bin/env python3
"""
Security Monitoring and Threat Detection System
Advanced security event monitoring with real-time threat detection
"""

import asyncio
import logging
import hashlib
import hmac
import time
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import json
import ipaddress
from pathlib import Path

from shared_state import shared_state, EventType, SystemEvent

logger = logging.getLogger(__name__)

class SecurityThreatLevel(Enum):
    """Security threat severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SecurityEventType(Enum):
    """Types of security events to monitor"""
    AUTH_FAILURE = "auth_failure"
    AUTH_SUCCESS = "auth_success"
    BRUTE_FORCE_ATTEMPT = "brute_force_attempt"
    RATE_LIMIT_VIOLATION = "rate_limit_violation"
    CSP_VIOLATION = "csp_violation"
    SUSPICIOUS_REQUEST = "suspicious_request"
    SQL_INJECTION_ATTEMPT = "sql_injection_attempt"
    XSS_ATTEMPT = "xss_attempt"
    UNAUTHORIZED_ACCESS = "unauthorized_access"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DATA_BREACH_ATTEMPT = "data_breach_attempt"
    SYSTEM_INTRUSION = "system_intrusion"

@dataclass
class SecurityEvent:
    """Security event data structure"""
    event_type: SecurityEventType
    threat_level: SecurityThreatLevel
    source_ip: str
    user_agent: Optional[str]
    endpoint: Optional[str]
    user_id: Optional[str]
    details: Dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    event_id: str = field(default_factory=lambda: f"sec_{int(time.time() * 1000)}")
    location_info: Optional[Dict[str, Any]] = None

@dataclass
class ThreatSignature:
    """Known threat signature patterns"""
    name: str
    pattern: str
    threat_level: SecurityThreatLevel
    description: str
    category: SecurityEventType

class SecurityMonitor:
    """Advanced security monitoring and threat detection"""
    
    def __init__(self, data_dir: str = "/tmp/chatterfix-security"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # Security event storage
        self.security_events: List[SecurityEvent] = []
        self.max_events = 5000
        
        # Threat detection patterns
        self.threat_signatures = self._initialize_threat_signatures()
        
        # Rate limiting and brute force detection
        self.failed_attempts: Dict[str, List[datetime]] = {}
        self.suspicious_ips: Set[str] = set()
        self.blocked_ips: Set[str] = set()
        
        # Configuration
        self.config = {
            "brute_force_threshold": 5,  # attempts
            "brute_force_window": 300,   # seconds
            "rate_limit_window": 60,     # seconds
            "max_requests_per_minute": 100,
            "auto_block_enabled": True,
            "block_duration": 3600,      # seconds
        }
        
        # Real-time monitoring
        self.active_sessions: Dict[str, Dict] = {}
        self.request_counts: Dict[str, List[datetime]] = {}
        
        # Subscribe to system events for security analysis
        shared_state.subscribe_to_event(EventType.USER_ACTION, self._analyze_user_action)
        shared_state.subscribe_to_event(EventType.SYSTEM_HEALTH_CHANGED, self._analyze_system_health)
        
        logger.info("🔐 Security Monitor initialized with threat detection")
    
    def _initialize_threat_signatures(self) -> List[ThreatSignature]:
        """Initialize known threat signature patterns"""
        return [
            ThreatSignature(
                "SQL Injection - UNION",
                r"(?i)(union\s+select|union\s+all\s+select)",
                SecurityThreatLevel.HIGH,
                "SQL injection attempt using UNION statements",
                SecurityEventType.SQL_INJECTION_ATTEMPT
            ),
            ThreatSignature(
                "SQL Injection - OR 1=1",
                r"(?i)(or\s+1\s*=\s*1|or\s+'1'\s*=\s*'1')",
                SecurityThreatLevel.HIGH,
                "SQL injection attempt using OR 1=1",
                SecurityEventType.SQL_INJECTION_ATTEMPT
            ),
            ThreatSignature(
                "XSS - Script Tags",
                r"(?i)<script[^>]*>.*?</script>",
                SecurityThreatLevel.MEDIUM,
                "Cross-site scripting attempt with script tags",
                SecurityEventType.XSS_ATTEMPT
            ),
            ThreatSignature(
                "XSS - JavaScript Events",
                r"(?i)(onload|onerror|onclick|onmouseover)\s*=",
                SecurityThreatLevel.MEDIUM,
                "Cross-site scripting attempt with event handlers",
                SecurityEventType.XSS_ATTEMPT
            ),
            ThreatSignature(
                "Directory Traversal",
                r"(\.\./|\.\.\\|%2e%2e%2f|%2e%2e%5c)",
                SecurityThreatLevel.HIGH,
                "Directory traversal attempt",
                SecurityEventType.UNAUTHORIZED_ACCESS
            ),
            ThreatSignature(
                "Command Injection",
                r"(?i)(;|\||\&)(cat|ls|pwd|whoami|id|uname)",
                SecurityThreatLevel.CRITICAL,
                "Command injection attempt",
                SecurityEventType.SYSTEM_INTRUSION
            )
        ]
    
    async def log_security_event(self, 
                                event_type: SecurityEventType,
                                threat_level: SecurityThreatLevel,
                                source_ip: str,
                                details: Dict[str, Any],
                                user_agent: str = None,
                                endpoint: str = None,
                                user_id: str = None) -> SecurityEvent:
        """Log a security event with threat assessment"""
        
        # Create security event
        event = SecurityEvent(
            event_type=event_type,
            threat_level=threat_level,
            source_ip=source_ip,
            user_agent=user_agent,
            endpoint=endpoint,
            user_id=user_id,
            details=details
        )
        
        # Add to event storage
        self.security_events.append(event)
        if len(self.security_events) > self.max_events:
            self.security_events = self.security_events[-self.max_events:]
        
        # Update threat tracking
        await self._update_threat_tracking(event)
        
        # Emit security event to shared state
        await shared_state.emit_event(
            EventType.MODULE_STATUS_CHANGED,
            "security_monitor",
            {
                "security_event": {
                    "type": event_type.value,
                    "threat_level": threat_level.value,
                    "source_ip": source_ip,
                    "endpoint": endpoint,
                    "timestamp": event.timestamp.isoformat()
                }
            },
            priority=1 if threat_level in [SecurityThreatLevel.HIGH, SecurityThreatLevel.CRITICAL] else 2
        )
        
        # Real-time response for critical threats
        if threat_level == SecurityThreatLevel.CRITICAL:
            await self._handle_critical_threat(event)
        
        logger.warning(f"🚨 Security Event: {event_type.value} from {source_ip} - {threat_level.value}")
        return event
    
    async def _update_threat_tracking(self, event: SecurityEvent) -> None:
        """Update threat tracking for IP addresses"""
        ip = event.source_ip
        
        # Track failed authentication attempts
        if event.event_type == SecurityEventType.AUTH_FAILURE:
            if ip not in self.failed_attempts:
                self.failed_attempts[ip] = []
            
            self.failed_attempts[ip].append(event.timestamp)
            
            # Remove old attempts outside the window
            cutoff = event.timestamp - timedelta(seconds=self.config["brute_force_window"])
            self.failed_attempts[ip] = [
                attempt for attempt in self.failed_attempts[ip] 
                if attempt > cutoff
            ]
            
            # Check for brute force
            if len(self.failed_attempts[ip]) >= self.config["brute_force_threshold"]:
                await self.log_security_event(
                    SecurityEventType.BRUTE_FORCE_ATTEMPT,
                    SecurityThreatLevel.HIGH,
                    ip,
                    {"failed_attempts": len(self.failed_attempts[ip])}
                )
                
                if self.config["auto_block_enabled"]:
                    self.blocked_ips.add(ip)
                    logger.critical(f"🚫 Auto-blocked IP {ip} for brute force attack")
        
        # Track request rates
        if ip not in self.request_counts:
            self.request_counts[ip] = []
        
        self.request_counts[ip].append(event.timestamp)
        
        # Remove old requests outside the window
        cutoff = event.timestamp - timedelta(seconds=self.config["rate_limit_window"])
        self.request_counts[ip] = [
            req for req in self.request_counts[ip] 
            if req > cutoff
        ]
        
        # Check for rate limit violations
        if len(self.request_counts[ip]) > self.config["max_requests_per_minute"]:
            await self.log_security_event(
                SecurityEventType.RATE_LIMIT_VIOLATION,
                SecurityThreatLevel.MEDIUM,
                ip,
                {"requests_per_minute": len(self.request_counts[ip])}
            )
    
    async def _handle_critical_threat(self, event: SecurityEvent) -> None:
        """Handle critical security threats with immediate response"""
        logger.critical(f"🚨 CRITICAL THREAT DETECTED: {event.event_type.value} from {event.source_ip}")
        
        # Auto-block the IP for critical threats
        self.blocked_ips.add(event.source_ip)
        
        # Emit high-priority alert
        await shared_state.emit_event(
            EventType.SYSTEM_HEALTH_CHANGED,
            "security_monitor",
            {
                "critical_threat": {
                    "event_id": event.event_id,
                    "type": event.event_type.value,
                    "source_ip": event.source_ip,
                    "details": event.details,
                    "auto_blocked": True
                }
            },
            priority=1
        )
    
    async def analyze_request_for_threats(self, 
                                        request_data: Dict[str, Any]) -> Optional[SecurityEvent]:
        """Analyze incoming request for security threats"""
        
        # Extract request information
        source_ip = request_data.get("client_ip", "unknown")
        user_agent = request_data.get("user_agent", "")
        endpoint = request_data.get("endpoint", "")
        query_params = request_data.get("query_params", {})
        post_data = request_data.get("post_data", {})
        
        # Combine all request data for analysis
        request_content = f"{endpoint} {query_params} {post_data} {user_agent}"
        
        # Check against threat signatures
        for signature in self.threat_signatures:
            import re
            if re.search(signature.pattern, request_content):
                return await self.log_security_event(
                    signature.category,
                    signature.threat_level,
                    source_ip,
                    {
                        "signature_matched": signature.name,
                        "pattern": signature.pattern,
                        "endpoint": endpoint,
                        "user_agent": user_agent
                    },
                    user_agent=user_agent,
                    endpoint=endpoint
                )
        
        return None
    
    def is_ip_blocked(self, ip_address: str) -> bool:
        """Check if an IP address is blocked"""
        return ip_address in self.blocked_ips
    
    def is_ip_suspicious(self, ip_address: str) -> bool:
        """Check if an IP address is flagged as suspicious"""
        return ip_address in self.suspicious_ips
    
    async def get_security_status(self) -> Dict[str, Any]:
        """Get comprehensive security status"""
        recent_events = [
            {
                "type": event.event_type.value,
                "threat_level": event.threat_level.value,
                "source_ip": event.source_ip,
                "endpoint": event.endpoint,
                "timestamp": event.timestamp.isoformat()
            }
            for event in self.security_events[-20:]  # Last 20 events
        ]
        
        # Threat level distribution
        threat_distribution = {}
        for event in self.security_events[-100:]:  # Last 100 events
            level = event.threat_level.value
            threat_distribution[level] = threat_distribution.get(level, 0) + 1
        
        return {
            "total_events": len(self.security_events),
            "recent_events": recent_events,
            "threat_distribution": threat_distribution,
            "blocked_ips": list(self.blocked_ips),
            "suspicious_ips": list(self.suspicious_ips),
            "active_sessions": len(self.active_sessions),
            "threat_signatures_loaded": len(self.threat_signatures),
            "config": self.config
        }
    
    async def _analyze_user_action(self, event: SystemEvent) -> None:
        """Analyze user actions for security implications"""
        # This would analyze user actions logged by other modules
        # and correlate them for security insights
        pass
    
    async def _analyze_system_health(self, event: SystemEvent) -> None:
        """Analyze system health changes for security implications"""
        # This would analyze system health changes that might indicate
        # security issues like resource exhaustion attacks
        pass
    
    def unblock_ip(self, ip_address: str) -> bool:
        """Manually unblock an IP address"""
        if ip_address in self.blocked_ips:
            self.blocked_ips.remove(ip_address)
            logger.info(f"✅ Unblocked IP address: {ip_address}")
            return True
        return False
    
    def add_threat_signature(self, signature: ThreatSignature) -> None:
        """Add a custom threat signature"""
        self.threat_signatures.append(signature)
        logger.info(f"🎯 Added threat signature: {signature.name}")

# Global security monitor instance
security_monitor = SecurityMonitor()

# Convenience functions for security logging
async def log_auth_failure(ip: str, user_id: str = None, details: Dict = None):
    """Log authentication failure"""
    await security_monitor.log_security_event(
        SecurityEventType.AUTH_FAILURE,
        SecurityThreatLevel.MEDIUM,
        ip,
        details or {},
        user_id=user_id
    )

async def log_auth_success(ip: str, user_id: str, details: Dict = None):
    """Log successful authentication"""
    await security_monitor.log_security_event(
        SecurityEventType.AUTH_SUCCESS,
        SecurityThreatLevel.LOW,
        ip,
        details or {},
        user_id=user_id
    )

async def log_csp_violation(ip: str, details: Dict):
    """Log CSP violation"""
    await security_monitor.log_security_event(
        SecurityEventType.CSP_VIOLATION,
        SecurityThreatLevel.MEDIUM,
        ip,
        details
    )

async def analyze_request_security(request_data: Dict) -> bool:
    """Analyze request for security threats. Returns True if safe, False if threat detected."""
    threat = await security_monitor.analyze_request_for_threats(request_data)
    return threat is None

if __name__ == "__main__":
    # Test the security monitor
    async def test_security():
        # Test threat detection
        threat_event = await security_monitor.log_security_event(
            SecurityEventType.SQL_INJECTION_ATTEMPT,
            SecurityThreatLevel.HIGH,
            "192.168.1.100",
            {"payload": "' OR 1=1 --"}
        )
        
        print(f"Logged threat event: {threat_event.event_id}")
        
        status = await security_monitor.get_security_status()
        print("Security status:", json.dumps(status, indent=2, default=str))
    
    asyncio.run(test_security())