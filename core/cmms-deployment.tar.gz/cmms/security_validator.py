#!/usr/bin/env python3
"""
ChatterFix CMMS - OWASP Security Validator & Pen-Test Suite
Comprehensive security validation against OWASP Top 10 and security best practices
"""

import os
import re
import json
import hashlib
import requests
import asyncio
import subprocess
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import dataclass, asdict
import secrets
import ssl
import socket
from urllib.parse import urlparse
import time

# =============================================================================
# Configuration
# =============================================================================

# Target application configuration
TARGET_URL = os.getenv("TARGET_URL", "http://localhost:8000")
API_BASE = f"{TARGET_URL}/api"
TEST_USER_CREDS = {"username": "testuser", "password": "testpass123"}

# Security test configuration
TIMEOUT_SECONDS = 10
MAX_RETRIES = 3
SEVERITY_THRESHOLD = "MEDIUM"  # CRITICAL, HIGH, MEDIUM, LOW

# =============================================================================
# Data Models
# =============================================================================

@dataclass
class SecurityIssue:
    """Security issue found during testing"""
    test_name: str
    category: str              # OWASP category
    severity: str             # CRITICAL, HIGH, MEDIUM, LOW
    title: str
    description: str
    evidence: Dict[str, Any]
    remediation: str
    cwe_id: Optional[str] = None
    owasp_category: Optional[str] = None
    confidence: str = "HIGH"   # HIGH, MEDIUM, LOW

@dataclass
class SecurityTestResult:
    """Result of a security test"""
    test_name: str
    passed: bool
    issues: List[SecurityIssue]
    duration_ms: int
    error_message: Optional[str] = None

@dataclass
class SecurityReport:
    """Comprehensive security assessment report"""
    timestamp: datetime
    target_url: str
    total_tests: int
    passed_tests: int
    failed_tests: int
    total_issues: int
    critical_issues: int
    high_issues: int
    medium_issues: int
    low_issues: int
    test_results: List[SecurityTestResult]
    overall_score: float
    compliance_status: Dict[str, bool]

# =============================================================================
# Security Test Categories
# =============================================================================

class OWASPSecurityValidator:
    """OWASP Top 10 security validator"""
    
    def __init__(self, target_url: str):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.timeout = TIMEOUT_SECONDS
        self.test_results: List[SecurityTestResult] = []
        self.auth_token = None
    
    async def authenticate(self) -> bool:
        """Authenticate with test credentials if available"""
        try:
            login_url = f"{self.target_url}/auth/login"
            response = self.session.post(login_url, json=TEST_USER_CREDS)
            
            if response.status_code == 200:
                data = response.json()
                self.auth_token = data.get("access_token")
                if self.auth_token:
                    self.session.headers.update({
                        "Authorization": f"Bearer {self.auth_token}"
                    })
                return True
        except Exception as e:
            print(f"Authentication failed: {e}")
        
        return False
    
    def _make_request(self, method: str, url: str, **kwargs) -> Optional[requests.Response]:
        """Make HTTP request with error handling"""
        try:
            response = self.session.request(method, url, **kwargs)
            return response
        except Exception as e:
            print(f"Request failed for {url}: {e}")
            return None
    
    def _create_issue(
        self,
        test_name: str,
        category: str,
        severity: str,
        title: str,
        description: str,
        evidence: Dict[str, Any],
        remediation: str,
        cwe_id: Optional[str] = None,
        owasp_category: Optional[str] = None
    ) -> SecurityIssue:
        """Create a security issue"""
        return SecurityIssue(
            test_name=test_name,
            category=category,
            severity=severity,
            title=title,
            description=description,
            evidence=evidence,
            remediation=remediation,
            cwe_id=cwe_id,
            owasp_category=owasp_category
        )
    
    # =============================================================================
    # A01: Broken Access Control
    # =============================================================================
    
    async def test_broken_access_control(self) -> SecurityTestResult:
        """Test for broken access control vulnerabilities"""
        start_time = time.time()
        issues = []
        
        try:
            # Test 1: Unauthenticated access to protected endpoints
            protected_endpoints = [
                f"{API_BASE}/admin/users",
                f"{API_BASE}/admin/config",
                f"{self.target_url}/admin",
                f"{API_BASE}/auth/sessions"
            ]
            
            for endpoint in protected_endpoints:
                # Remove auth header temporarily
                auth_header = self.session.headers.get("Authorization")
                if auth_header:
                    del self.session.headers["Authorization"]
                
                response = self._make_request("GET", endpoint)
                
                # Restore auth header
                if auth_header:
                    self.session.headers["Authorization"] = auth_header
                
                if response and response.status_code not in [401, 403]:
                    issues.append(self._create_issue(
                        test_name="broken_access_control",
                        category="Access Control",
                        severity="HIGH",
                        title="Unauthenticated Access to Protected Resource",
                        description=f"Protected endpoint {endpoint} accessible without authentication",
                        evidence={
                            "endpoint": endpoint,
                            "status_code": response.status_code,
                            "response_headers": dict(response.headers)
                        },
                        remediation="Ensure all protected endpoints require proper authentication",
                        cwe_id="CWE-862",
                        owasp_category="A01"
                    ))
            
            # Test 2: Horizontal privilege escalation
            if self.auth_token:
                # Try to access other users' data
                user_endpoints = [
                    f"{API_BASE}/auth/sessions",
                    f"{API_BASE}/users/profile"
                ]
                
                for endpoint in user_endpoints:
                    response = self._make_request("GET", endpoint)
                    if response and response.status_code == 200:
                        # This would need more sophisticated testing in practice
                        pass
            
            # Test 3: Directory traversal
            traversal_payloads = [
                "../../../etc/passwd",
                "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
                "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd"
            ]
            
            for payload in traversal_payloads:
                test_url = f"{self.target_url}/static/{payload}"
                response = self._make_request("GET", test_url)
                
                if response and (
                    "root:" in response.text.lower() or
                    "windows" in response.text.lower() or
                    response.status_code == 200
                ):
                    issues.append(self._create_issue(
                        test_name="broken_access_control",
                        category="Access Control",
                        severity="CRITICAL",
                        title="Directory Traversal Vulnerability",
                        description="Application vulnerable to directory traversal attacks",
                        evidence={
                            "payload": payload,
                            "response_preview": response.text[:200]
                        },
                        remediation="Implement proper path validation and sanitization",
                        cwe_id="CWE-22",
                        owasp_category="A01"
                    ))
            
        except Exception as e:
            return SecurityTestResult(
                test_name="broken_access_control",
                passed=False,
                issues=[],
                duration_ms=int((time.time() - start_time) * 1000),
                error_message=str(e)
            )
        
        duration = int((time.time() - start_time) * 1000)
        return SecurityTestResult(
            test_name="broken_access_control",
            passed=len(issues) == 0,
            issues=issues,
            duration_ms=duration
        )
    
    # =============================================================================
    # A02: Cryptographic Failures
    # =============================================================================
    
    async def test_cryptographic_failures(self) -> SecurityTestResult:
        """Test for cryptographic vulnerabilities"""
        start_time = time.time()
        issues = []
        
        try:
            # Test 1: Weak SSL/TLS configuration
            parsed_url = urlparse(self.target_url)
            if parsed_url.scheme == "https":
                try:
                    context = ssl.create_default_context()
                    with socket.create_connection((parsed_url.hostname, parsed_url.port or 443)) as sock:
                        with context.wrap_socket(sock, server_hostname=parsed_url.hostname) as ssock:
                            cipher = ssock.cipher()
                            protocol = ssock.version()
                            
                            # Check for weak protocols
                            if protocol in ["SSLv2", "SSLv3", "TLSv1", "TLSv1.1"]:
                                issues.append(self._create_issue(
                                    test_name="cryptographic_failures",
                                    category="Cryptography",
                                    severity="HIGH",
                                    title="Weak TLS Protocol Version",
                                    description=f"Server supports weak TLS protocol: {protocol}",
                                    evidence={"protocol": protocol, "cipher": cipher},
                                    remediation="Configure server to use TLS 1.2 or higher",
                                    cwe_id="CWE-327",
                                    owasp_category="A02"
                                ))
                            
                            # Check for weak ciphers
                            if cipher and any(weak in cipher[0].lower() for weak in ['rc4', 'des', 'md5']):
                                issues.append(self._create_issue(
                                    test_name="cryptographic_failures",
                                    category="Cryptography",
                                    severity="MEDIUM",
                                    title="Weak Cipher Suite",
                                    description=f"Server supports weak cipher: {cipher[0]}",
                                    evidence={"cipher": cipher},
                                    remediation="Configure strong cipher suites only",
                                    cwe_id="CWE-327",
                                    owasp_category="A02"
                                ))
                            
                except Exception as ssl_error:
                    print(f"SSL test failed: {ssl_error}")
            else:
                # HTTP instead of HTTPS
                issues.append(self._create_issue(
                    test_name="cryptographic_failures",
                    category="Cryptography",
                    severity="HIGH",
                    title="Unencrypted Communication",
                    description="Application uses HTTP instead of HTTPS",
                    evidence={"scheme": parsed_url.scheme},
                    remediation="Configure HTTPS with valid TLS certificate",
                    cwe_id="CWE-319",
                    owasp_category="A02"
                ))
            
            # Test 2: Check security headers
            response = self._make_request("GET", self.target_url)
            if response:
                headers = response.headers
                
                # Check for HSTS
                if "strict-transport-security" not in headers:
                    issues.append(self._create_issue(
                        test_name="cryptographic_failures",
                        category="Cryptography",
                        severity="MEDIUM",
                        title="Missing HSTS Header",
                        description="HTTP Strict Transport Security header not set",
                        evidence={"missing_header": "Strict-Transport-Security"},
                        remediation="Configure HSTS header with appropriate max-age",
                        cwe_id="CWE-523",
                        owasp_category="A02"
                    ))
                
                # Check Content-Security-Policy
                if "content-security-policy" not in headers:
                    issues.append(self._create_issue(
                        test_name="cryptographic_failures",
                        category="Cryptography",
                        severity="MEDIUM",
                        title="Missing CSP Header",
                        description="Content Security Policy header not configured",
                        evidence={"missing_header": "Content-Security-Policy"},
                        remediation="Configure Content Security Policy to prevent XSS",
                        cwe_id="CWE-693",
                        owasp_category="A02"
                    ))
            
        except Exception as e:
            return SecurityTestResult(
                test_name="cryptographic_failures",
                passed=False,
                issues=[],
                duration_ms=int((time.time() - start_time) * 1000),
                error_message=str(e)
            )
        
        duration = int((time.time() - start_time) * 1000)
        return SecurityTestResult(
            test_name="cryptographic_failures",
            passed=len(issues) == 0,
            issues=issues,
            duration_ms=duration
        )
    
    # =============================================================================
    # A03: Injection
    # =============================================================================
    
    async def test_injection_vulnerabilities(self) -> SecurityTestResult:
        """Test for injection vulnerabilities"""
        start_time = time.time()
        issues = []
        
        try:
            # SQL Injection payloads
            sql_payloads = [
                "' OR '1'='1",
                "'; DROP TABLE users; --",
                "' UNION SELECT 1,2,3--",
                "admin'--",
                "' OR 1=1#"
            ]
            
            # Test endpoints that might be vulnerable
            test_endpoints = [
                f"{API_BASE}/auth/login",
                f"{API_BASE}/users/search",
                f"{self.target_url}/search"
            ]
            
            for endpoint in test_endpoints:
                for payload in sql_payloads:
                    # Test in JSON body
                    test_data = {
                        "username": payload,
                        "password": "test",
                        "search": payload,
                        "query": payload
                    }
                    
                    response = self._make_request("POST", endpoint, json=test_data)
                    
                    if response and self._detect_sql_injection(response):
                        issues.append(self._create_issue(
                            test_name="injection_vulnerabilities",
                            category="Injection",
                            severity="CRITICAL",
                            title="SQL Injection Vulnerability",
                            description=f"SQL injection detected in endpoint {endpoint}",
                            evidence={
                                "endpoint": endpoint,
                                "payload": payload,
                                "status_code": response.status_code,
                                "response_preview": response.text[:200]
                            },
                            remediation="Use parameterized queries and input validation",
                            cwe_id="CWE-89",
                            owasp_category="A03"
                        ))
                        break  # Don't test more payloads for this endpoint
                    
                    # Also test in URL parameters
                    if "?" not in endpoint:
                        test_url = f"{endpoint}?search={payload}"
                    else:
                        test_url = f"{endpoint}&search={payload}"
                    
                    response = self._make_request("GET", test_url)
                    if response and self._detect_sql_injection(response):
                        issues.append(self._create_issue(
                            test_name="injection_vulnerabilities",
                            category="Injection",
                            severity="CRITICAL",
                            title="SQL Injection in URL Parameters",
                            description=f"SQL injection detected in URL parameters for {endpoint}",
                            evidence={
                                "endpoint": endpoint,
                                "payload": payload,
                                "test_url": test_url
                            },
                            remediation="Validate and sanitize URL parameters",
                            cwe_id="CWE-89",
                            owasp_category="A03"
                        ))
                        break
            
            # Command injection test
            command_payloads = [
                "; ls -la",
                "| whoami",
                "&& cat /etc/passwd",
                "`id`",
                "$(whoami)"
            ]
            
            for payload in command_payloads:
                test_data = {"filename": payload, "command": payload}
                
                # Test file upload endpoints or command execution endpoints
                for endpoint in [f"{self.target_url}/upload", f"{API_BASE}/files/process"]:
                    response = self._make_request("POST", endpoint, json=test_data)
                    
                    if response and self._detect_command_injection(response):
                        issues.append(self._create_issue(
                            test_name="injection_vulnerabilities",
                            category="Injection",
                            severity="CRITICAL",
                            title="Command Injection Vulnerability",
                            description=f"Command injection detected in {endpoint}",
                            evidence={
                                "endpoint": endpoint,
                                "payload": payload,
                                "response_preview": response.text[:200]
                            },
                            remediation="Never execute user input as system commands",
                            cwe_id="CWE-78",
                            owasp_category="A03"
                        ))
            
        except Exception as e:
            return SecurityTestResult(
                test_name="injection_vulnerabilities",
                passed=False,
                issues=[],
                duration_ms=int((time.time() - start_time) * 1000),
                error_message=str(e)
            )
        
        duration = int((time.time() - start_time) * 1000)
        return SecurityTestResult(
            test_name="injection_vulnerabilities",
            passed=len(issues) == 0,
            issues=issues,
            duration_ms=duration
        )
    
    def _detect_sql_injection(self, response: requests.Response) -> bool:
        """Detect SQL injection vulnerabilities in response"""
        if not response:
            return False
        
        # SQL error patterns
        sql_errors = [
            "sql syntax",
            "mysql_fetch",
            "ora-[0-9]{4}",
            "postgresql",
            "sqlite_master",
            "mssql",
            "microsoft jet database",
            "unclosed quotation mark"
        ]
        
        response_text = response.text.lower()
        
        for pattern in sql_errors:
            if re.search(pattern, response_text):
                return True
        
        return False
    
    def _detect_command_injection(self, response: requests.Response) -> bool:
        """Detect command injection vulnerabilities in response"""
        if not response:
            return False
        
        # Command injection indicators
        command_indicators = [
            "uid=",
            "gid=",
            "/bin/sh",
            "/bin/bash",
            "root:",
            "www-data:",
            "total [0-9]+"
        ]
        
        response_text = response.text.lower()
        
        for pattern in command_indicators:
            if re.search(pattern, response_text):
                return True
        
        return False
    
    # =============================================================================
    # Security Configuration Tests
    # =============================================================================
    
    async def test_security_configuration(self) -> SecurityTestResult:
        """Test security configuration and headers"""
        start_time = time.time()
        issues = []
        
        try:
            response = self._make_request("GET", self.target_url)
            
            if response:
                headers = response.headers
                
                # Check for security headers
                required_headers = {
                    "X-Content-Type-Options": "nosniff",
                    "X-Frame-Options": ["DENY", "SAMEORIGIN"],
                    "X-XSS-Protection": "1; mode=block",
                    "Referrer-Policy": ["strict-origin-when-cross-origin", "no-referrer", "strict-origin"]
                }
                
                for header_name, expected_values in required_headers.items():
                    header_value = headers.get(header_name)
                    
                    if not header_value:
                        issues.append(self._create_issue(
                            test_name="security_configuration",
                            category="Security Configuration",
                            severity="MEDIUM",
                            title=f"Missing {header_name} Header",
                            description=f"Security header {header_name} is not configured",
                            evidence={"missing_header": header_name},
                            remediation=f"Configure {header_name} header with appropriate value",
                            cwe_id="CWE-16",
                            owasp_category="A05"
                        ))
                    elif isinstance(expected_values, list) and header_value not in expected_values:
                        issues.append(self._create_issue(
                            test_name="security_configuration",
                            category="Security Configuration",
                            severity="LOW",
                            title=f"Weak {header_name} Configuration",
                            description=f"{header_name} header has weak configuration: {header_value}",
                            evidence={"header": header_name, "value": header_value, "expected": expected_values},
                            remediation=f"Use stronger {header_name} configuration",
                            cwe_id="CWE-16",
                            owasp_category="A05"
                        ))
                
                # Check Server header information disclosure
                server_header = headers.get("Server", "")
                if server_header and any(info in server_header.lower() for info in ["apache", "nginx", "iis", "version"]):
                    issues.append(self._create_issue(
                        test_name="security_configuration",
                        category="Information Disclosure",
                        severity="LOW",
                        title="Server Information Disclosure",
                        description="Server header reveals information about the web server",
                        evidence={"server_header": server_header},
                        remediation="Configure server to hide version information",
                        cwe_id="CWE-200",
                        owasp_category="A05"
                    ))
            
            # Test for default credentials
            default_creds = [
                {"username": "admin", "password": "admin"},
                {"username": "admin", "password": "password"},
                {"username": "root", "password": "root"},
                {"username": "administrator", "password": "administrator"}
            ]
            
            login_endpoint = f"{self.target_url}/auth/login"
            for creds in default_creds:
                response = self._make_request("POST", login_endpoint, json=creds)
                
                if response and response.status_code == 200:
                    try:
                        data = response.json()
                        if data.get("access_token"):
                            issues.append(self._create_issue(
                                test_name="security_configuration",
                                category="Authentication",
                                severity="CRITICAL",
                                title="Default Credentials",
                                description=f"Default credentials accepted: {creds['username']}",
                                evidence={"credentials": creds},
                                remediation="Change all default passwords and disable default accounts",
                                cwe_id="CWE-521",
                                owasp_category="A07"
                            ))
                    except:
                        pass
            
        except Exception as e:
            return SecurityTestResult(
                test_name="security_configuration",
                passed=False,
                issues=[],
                duration_ms=int((time.time() - start_time) * 1000),
                error_message=str(e)
            )
        
        duration = int((time.time() - start_time) * 1000)
        return SecurityTestResult(
            test_name="security_configuration",
            passed=len(issues) == 0,
            issues=issues,
            duration_ms=duration
        )
    
    # =============================================================================
    # Main Test Execution
    # =============================================================================
    
    async def run_all_tests(self) -> SecurityReport:
        """Run all security tests and generate comprehensive report"""
        print("🔒 Starting OWASP Security Validation...")
        start_time = datetime.now(timezone.utc)
        
        # Attempt authentication
        await self.authenticate()
        
        # Define test functions
        test_functions = [
            self.test_broken_access_control,
            self.test_cryptographic_failures,
            self.test_injection_vulnerabilities,
            self.test_security_configuration,
        ]
        
        # Run all tests
        for test_func in test_functions:
            try:
                result = await test_func()
                self.test_results.append(result)
                status = "✅ PASS" if result.passed else "❌ FAIL"
                print(f"{status} {result.test_name} ({result.duration_ms}ms)")
                if not result.passed:
                    print(f"   Found {len(result.issues)} issues")
            except Exception as e:
                error_result = SecurityTestResult(
                    test_name=test_func.__name__,
                    passed=False,
                    issues=[],
                    duration_ms=0,
                    error_message=str(e)
                )
                self.test_results.append(error_result)
                print(f"❌ ERROR {test_func.__name__}: {e}")
        
        # Generate report
        return self._generate_report(start_time)
    
    def _generate_report(self, start_time: datetime) -> SecurityReport:
        """Generate comprehensive security report"""
        all_issues = []
        passed_tests = 0
        failed_tests = 0
        
        for result in self.test_results:
            all_issues.extend(result.issues)
            if result.passed:
                passed_tests += 1
            else:
                failed_tests += 1
        
        # Count issues by severity
        issue_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for issue in all_issues:
            issue_counts[issue.severity] = issue_counts.get(issue.severity, 0) + 1
        
        # Calculate security score (0-100)
        total_possible_score = 100
        severity_weights = {"CRITICAL": 25, "HIGH": 15, "MEDIUM": 8, "LOW": 2}
        
        deductions = sum(issue_counts[severity] * weight for severity, weight in severity_weights.items())
        security_score = max(0, total_possible_score - deductions)
        
        # OWASP compliance check
        compliance_status = {
            "A01_Broken_Access_Control": issue_counts["CRITICAL"] == 0,
            "A02_Cryptographic_Failures": issue_counts["HIGH"] <= 1,
            "A03_Injection": issue_counts["CRITICAL"] == 0,
            "A05_Security_Misconfiguration": issue_counts["MEDIUM"] <= 2,
            "A07_Identification_Authentication_Failures": issue_counts["CRITICAL"] == 0
        }
        
        return SecurityReport(
            timestamp=start_time,
            target_url=self.target_url,
            total_tests=len(self.test_results),
            passed_tests=passed_tests,
            failed_tests=failed_tests,
            total_issues=len(all_issues),
            critical_issues=issue_counts["CRITICAL"],
            high_issues=issue_counts["HIGH"],
            medium_issues=issue_counts["MEDIUM"],
            low_issues=issue_counts["LOW"],
            test_results=self.test_results,
            overall_score=security_score,
            compliance_status=compliance_status
        )

# =============================================================================
# Report Generation
# =============================================================================

def generate_security_report(report: SecurityReport, output_file: str = "security_report.json"):
    """Generate detailed security report"""
    
    # Create report directory
    report_dir = Path("./security_reports")
    report_dir.mkdir(exist_ok=True)
    
    # Generate JSON report
    report_data = asdict(report)
    
    # Convert datetime to ISO string
    report_data["timestamp"] = report.timestamp.isoformat()
    
    json_file = report_dir / output_file
    with open(json_file, 'w') as f:
        json.dump(report_data, f, indent=2, default=str)
    
    # Generate human-readable report
    md_file = report_dir / output_file.replace('.json', '.md')
    
    with open(md_file, 'w') as f:
        f.write(f"# Security Assessment Report\n\n")
        f.write(f"**Target:** {report.target_url}\n")
        f.write(f"**Date:** {report.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
        f.write(f"**Overall Score:** {report.overall_score:.1f}/100\n\n")
        
        f.write("## Executive Summary\n\n")
        f.write(f"- **Total Tests:** {report.total_tests}\n")
        f.write(f"- **Passed:** {report.passed_tests}\n") 
        f.write(f"- **Failed:** {report.failed_tests}\n")
        f.write(f"- **Total Issues:** {report.total_issues}\n")
        f.write(f"  - Critical: {report.critical_issues}\n")
        f.write(f"  - High: {report.high_issues}\n")
        f.write(f"  - Medium: {report.medium_issues}\n")
        f.write(f"  - Low: {report.low_issues}\n\n")
        
        f.write("## OWASP Compliance Status\n\n")
        for category, status in report.compliance_status.items():
            status_icon = "✅" if status else "❌"
            f.write(f"- {status_icon} {category.replace('_', ' ')}\n")
        
        f.write("\n## Detailed Findings\n\n")
        
        # Group issues by severity
        severity_order = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
        all_issues = []
        for result in report.test_results:
            all_issues.extend(result.issues)
        
        for severity in severity_order:
            severity_issues = [issue for issue in all_issues if issue.severity == severity]
            if severity_issues:
                f.write(f"### {severity} Issues ({len(severity_issues)})\n\n")
                
                for issue in severity_issues:
                    f.write(f"#### {issue.title}\n\n")
                    f.write(f"**Category:** {issue.category}\n")
                    if issue.owasp_category:
                        f.write(f"**OWASP:** {issue.owasp_category}\n")
                    if issue.cwe_id:
                        f.write(f"**CWE:** {issue.cwe_id}\n")
                    f.write(f"**Description:** {issue.description}\n\n")
                    f.write(f"**Remediation:** {issue.remediation}\n\n")
                    f.write("---\n\n")
    
    return str(json_file), str(md_file)

# =============================================================================
# Main Execution
# =============================================================================

async def run_security_validation(target_url: str = None) -> Tuple[SecurityReport, str, str]:
    """Run complete security validation suite"""
    if not target_url:
        target_url = TARGET_URL
    
    validator = OWASPSecurityValidator(target_url)
    report = await validator.run_all_tests()
    
    # Generate report files
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_file, md_file = generate_security_report(report, f"security_report_{timestamp}.json")
    
    print(f"\n🔒 Security Validation Complete!")
    print(f"📊 Overall Score: {report.overall_score:.1f}/100")
    print(f"📄 Reports saved:")
    print(f"   - JSON: {json_file}")
    print(f"   - Markdown: {md_file}")
    
    return report, json_file, md_file

if __name__ == "__main__":
    asyncio.run(run_security_validation())