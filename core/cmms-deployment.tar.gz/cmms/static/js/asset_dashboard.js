/*
Asset Dashboard JavaScript
Interactive functionality for the asset dashboard including data refresh, PM scheduling, and history management
*/

// =============================================================================
// Global State & Configuration
// =============================================================================

let currentAssetId = null;
let refreshInterval = null;
let isHistoryVisible = false;

// Configuration
const config = {
    refreshIntervalMs: 30000, // 30 seconds for critical assets
    apiBaseUrl: '/assets',
    chartUpdateDelay: 500
};

// =============================================================================
// Initialization
// =============================================================================

document.addEventListener('DOMContentLoaded', function() {
    // Extract asset ID from URL or page data
    currentAssetId = extractAssetId();
    
    // Initialize components
    initializeDashboard();
    initializeEventListeners();
    startAutoRefresh();
    
    console.log('Asset Dashboard initialized for asset:', currentAssetId);
});

function extractAssetId() {
    // Try to extract from URL path like /assets/dashboard/AST-001/view
    const path = window.location.pathname;
    const match = path.match(/\/dashboard\/([^\/]+)\/view/);
    return match ? match[1] : null;
}

function initializeDashboard() {
    // Set up initial UI state
    const header = document.querySelector('.dashboard-header');
    if (header) {
        header.style.opacity = '0';
        header.style.transform = 'translateY(-20px)';
        setTimeout(() => {
            header.style.transition = 'all 0.6s ease';
            header.style.opacity = '1';
            header.style.transform = 'translateY(0)';
        }, 100);
    }
    
    // Initialize KPI cards with loading states
    initializeKPICards();
    
    // Set up history timeline
    initializeHistoryTimeline();
}

function initializeEventListeners() {
    // Refresh button
    const refreshBtn = document.querySelector('[onclick="refreshDashboard()"]');
    if (refreshBtn) {
        refreshBtn.removeAttribute('onclick');
        refreshBtn.addEventListener('click', refreshDashboard);
    }
    
    // Create work order button
    const createWoBtn = document.querySelector('[onclick="createWorkOrder()"]');
    if (createWoBtn) {
        createWoBtn.removeAttribute('onclick');
        createWoBtn.addEventListener('click', createWorkOrder);
    }
    
    // Schedule PM button
    const schedulePmBtn = document.querySelector('[onclick="schedulePM()"]');
    if (schedulePmBtn) {
        schedulePmBtn.removeAttribute('onclick');
        schedulePmBtn.addEventListener('click', schedulePM);
    }
    
    // History toggle
    const historyToggle = document.querySelector('[onclick="toggleHistory()"]');
    if (historyToggle) {
        historyToggle.removeAttribute('onclick');
        historyToggle.addEventListener('click', toggleHistory);
    }
    
    // Document links
    initializeDocumentLinks();
    
    // Keyboard shortcuts
    initializeKeyboardShortcuts();
}

// =============================================================================
// Data Refresh & API Calls
// =============================================================================

async function refreshDashboard() {
    if (!currentAssetId) {
        console.error('No asset ID available for refresh');
        return;
    }
    
    const refreshBtn = document.querySelector('[onclick*="refreshDashboard"], .btn:has-text("🔄")') || 
                      document.querySelector('button:contains("🔄")');
    
    // Show loading state
    if (refreshBtn) {
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '⏳ Refreshing...';
        refreshBtn.classList.add('loading');
    }
    
    try {
        // Fetch fresh dashboard data
        const response = await fetch(`${config.apiBaseUrl}/dashboard/${currentAssetId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        // Update UI components with fresh data
        await updateKPICards(data.kpis);
        updateHistoryTimeline(data.history);
        updateSidebarData(data);
        
        // Show success feedback
        showNotification('Dashboard refreshed successfully', 'success');
        
    } catch (error) {
        console.error('Failed to refresh dashboard:', error);
        showNotification('Failed to refresh dashboard data', 'error');
    } finally {
        // Reset refresh button
        if (refreshBtn) {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = '🔄 Refresh';
            refreshBtn.classList.remove('loading');
        }
    }
}

async function fetchAssetKPIs(windowDays = 90) {
    try {
        const response = await fetch(`${config.apiBaseUrl}/dashboard/${currentAssetId}/kpis?window_days=${windowDays}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error('Failed to fetch KPIs:', error);
        return null;
    }
}

// =============================================================================
// KPI Cards Management
// =============================================================================

function initializeKPICards() {
    const kpiCards = document.querySelectorAll('.kpi-card');
    kpiCards.forEach((card, index) => {
        // Add click handlers for detailed views
        card.addEventListener('click', () => showKPIDetails(card));
        
        // Add hover effects
        card.addEventListener('mouseenter', animateKPICard);
        
        // Stagger animations
        card.style.animationDelay = `${index * 0.1}s`;
    });
}

async function updateKPICards(kpis) {
    if (!kpis) return;
    
    const updates = [
        { selector: '.kpi-card.mtbf .kpi-value', value: `${kpis.mtbf_hours.toFixed(1)}h` },
        { selector: '.kpi-card.mttr .kpi-value', value: `${kpis.mttr_hours.toFixed(1)}h` },
        { selector: '.kpi-card.compliance .kpi-value', value: `${kpis.pm_compliance_pct.toFixed(1)}%` },
        { selector: '.kpi-card.uptime .kpi-value', value: `${kpis.uptime_pct.toFixed(1)}%` },
        { selector: '.kpi-card.backlog .kpi-value', value: kpis.backlog_days.toFixed(1) },
        { selector: '.kpi-card.cost .kpi-value', value: `$${kpis.total_cost_ytd.toLocaleString()}` }
    ];
    
    updates.forEach(update => {
        const element = document.querySelector(update.selector);
        if (element) {
            animateValueChange(element, update.value);
        }
    });
}

function animateValueChange(element, newValue) {
    // Fade out
    element.style.transition = 'opacity 0.3s ease';
    element.style.opacity = '0';
    
    setTimeout(() => {
        element.textContent = newValue;
        element.style.opacity = '1';
    }, 300);
}

function animateKPICard(event) {
    const card = event.currentTarget;
    const value = card.querySelector('.kpi-value');
    
    if (value) {
        value.style.transform = 'scale(1.05)';
        value.style.transition = 'transform 0.2s ease';
        
        card.addEventListener('mouseleave', () => {
            value.style.transform = 'scale(1)';
        }, { once: true });
    }
}

function showKPIDetails(card) {
    const kpiType = Array.from(card.classList).find(cls => 
        ['mtbf', 'mttr', 'compliance', 'uptime', 'backlog', 'cost'].includes(cls)
    );
    
    if (!kpiType) return;
    
    const details = getKPIDetails(kpiType);
    showModal(details.title, details.content);
}

function getKPIDetails(kpiType) {
    const details = {
        mtbf: {
            title: 'Mean Time Between Failures (MTBF)',
            content: `
                <div class="kpi-detail">
                    <p><strong>Calculation:</strong> Total Operating Time ÷ Number of Failures</p>
                    <p><strong>Industry Benchmark:</strong> 720-8760 hours</p>
                    <p><strong>Current Window:</strong> Last 90 days</p>
                    <p><strong>Trend Analysis:</strong> Higher values indicate better reliability</p>
                </div>
            `
        },
        mttr: {
            title: 'Mean Time To Repair (MTTR)',
            content: `
                <div class="kpi-detail">
                    <p><strong>Calculation:</strong> Total Repair Time ÷ Number of Repairs</p>
                    <p><strong>Industry Benchmark:</strong> 2-8 hours</p>
                    <p><strong>Includes:</strong> Diagnosis + Repair + Testing</p>
                    <p><strong>Excludes:</strong> Parts procurement delays</p>
                </div>
            `
        },
        compliance: {
            title: 'Preventive Maintenance Compliance',
            content: `
                <div class="kpi-detail">
                    <p><strong>Calculation:</strong> (Completed On Time ÷ Total Scheduled) × 100</p>
                    <p><strong>Target:</strong> ≥95% for critical assets</p>
                    <p><strong>Grace Period:</strong> ±7 days for routine maintenance</p>
                    <p><strong>Impact:</strong> Higher compliance reduces unexpected failures</p>
                </div>
            `
        },
        uptime: {
            title: 'Asset Uptime Percentage',
            content: `
                <div class="kpi-detail">
                    <p><strong>Calculation:</strong> (Total Time - Downtime) ÷ Total Time × 100</p>
                    <p><strong>Industry Target:</strong> 95-99% depending on criticality</p>
                    <p><strong>Includes:</strong> Planned and unplanned downtime</p>
                    <p><strong>Current Window:</strong> Last 90 days</p>
                </div>
            `
        },
        backlog: {
            title: 'Work Order Backlog',
            content: `
                <div class="kpi-detail">
                    <p><strong>Calculation:</strong> Total Open WO Hours ÷ Available Hours per Day</p>
                    <p><strong>Target:</strong> ≤3 days for optimal performance</p>
                    <p><strong>Priority Weighting:</strong> Urgent=3x, High=2x, Medium=1x, Low=0.5x</p>
                    <p><strong>Available Capacity:</strong> 8 hours per day assumed</p>
                </div>
            `
        },
        cost: {
            title: 'Year-to-Date Maintenance Cost',
            content: `
                <div class="kpi-detail">
                    <p><strong>Includes:</strong> Parts, labor, contractor costs</p>
                    <p><strong>Period:</strong> January 1 to current date</p>
                    <p><strong>Budget Tracking:</strong> Monitor against annual allocation</p>
                    <p><strong>Trend:</strong> Compare with previous periods</p>
                </div>
            `
        }
    };
    
    return details[kpiType] || { title: 'KPI Details', content: '<p>Details not available.</p>' };
}

// =============================================================================
// History Timeline Management
// =============================================================================

function initializeHistoryTimeline() {
    const timeline = document.getElementById('historyTimeline');
    if (timeline) {
        // Initially hidden as per spec
        isHistoryVisible = false;
        timeline.style.display = 'none';
    }
}

function toggleHistory() {
    const timeline = document.getElementById('historyTimeline');
    const toggle = document.getElementById('historyToggle');
    
    if (!timeline || !toggle) return;
    
    isHistoryVisible = !isHistoryVisible;
    
    if (isHistoryVisible) {
        timeline.style.display = 'flex';
        timeline.style.opacity = '0';
        timeline.style.transform = 'translateY(-10px)';
        
        setTimeout(() => {
            timeline.style.transition = 'all 0.3s ease';
            timeline.style.opacity = '1';
            timeline.style.transform = 'translateY(0)';
        }, 50);
        
        toggle.innerHTML = '🔼 Hide Details';
    } else {
        timeline.style.opacity = '0';
        timeline.style.transform = 'translateY(-10px)';
        
        setTimeout(() => {
            timeline.style.display = 'none';
        }, 300);
        
        toggle.innerHTML = '🔽 Show Details';
    }
}

function updateHistoryTimeline(history) {
    if (!history || !Array.isArray(history)) return;
    
    const timeline = document.getElementById('historyTimeline');
    if (!timeline) return;
    
    // Clear existing events
    timeline.innerHTML = '';
    
    if (history.length === 0) {
        timeline.innerHTML = '<p>No maintenance history available.</p>';
        return;
    }
    
    // Generate new events
    history.forEach((event, index) => {
        const eventElement = createHistoryEventElement(event);
        eventElement.style.animationDelay = `${index * 0.1}s`;
        timeline.appendChild(eventElement);
    });
}

function createHistoryEventElement(event) {
    const eventDiv = document.createElement('div');
    eventDiv.className = `history-event ${event.event_type}`;
    
    const eventIcon = {
        'repair': '🔧',
        'pm': '📋',
        'inspection': '🔍',
        'failure': '⚠️'
    }[event.event_type] || '📝';
    
    const costText = event.cost ? `$${event.cost.toFixed(2)}` : 'N/A';
    const durationText = event.duration_hours ? `${event.duration_hours}h` : 'N/A';
    const eventDate = new Date(event.timestamp).toLocaleDateString();
    
    eventDiv.innerHTML = `
        <div class="event-icon">${eventIcon}</div>
        <div class="event-content">
            <div class="event-header">
                <span class="event-type">${event.event_type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                <span class="event-date">${eventDate}</span>
            </div>
            <div class="event-description">${event.description}</div>
            <div class="event-meta">
                <span>By: ${event.technician || 'System'}</span>
                <span>Duration: ${durationText}</span>
                <span>Cost: ${costText}</span>
            </div>
        </div>
    `;
    
    // Add click handler for detailed view
    eventDiv.addEventListener('click', () => showEventDetails(event));
    
    return eventDiv;
}

function showEventDetails(event) {
    const content = `
        <div class="event-detail">
            <h4>${event.event_type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} Event</h4>
            <p><strong>Date:</strong> ${new Date(event.timestamp).toLocaleString()}</p>
            <p><strong>Description:</strong> ${event.description}</p>
            <p><strong>Technician:</strong> ${event.technician || 'System'}</p>
            ${event.duration_hours ? `<p><strong>Duration:</strong> ${event.duration_hours} hours</p>` : ''}
            ${event.cost ? `<p><strong>Cost:</strong> $${event.cost.toFixed(2)}</p>` : ''}
            ${event.work_order_id ? `<p><strong>Work Order:</strong> ${event.work_order_id}</p>` : ''}
            ${event.parts_used.length > 0 ? `<p><strong>Parts Used:</strong> ${event.parts_used.join(', ')}</p>` : ''}
        </div>
    `;
    
    showModal('Event Details', content);
}

// =============================================================================
// Work Order & PM Management
// =============================================================================

async function createWorkOrder() {
    if (!currentAssetId) {
        showNotification('Asset ID not available', 'error');
        return;
    }
    
    const content = `
        <form id="createWorkOrderForm" class="modal-form">
            <div class="form-group">
                <label for="woTitle">Title*</label>
                <input type="text" id="woTitle" name="title" required 
                       placeholder="Brief description of the work">
            </div>
            
            <div class="form-group">
                <label for="woDescription">Description*</label>
                <textarea id="woDescription" name="description" required rows="4"
                          placeholder="Detailed description of the work to be performed"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="woType">Type</label>
                    <select id="woType" name="type" required>
                        <option value="reactive">Reactive</option>
                        <option value="preventive">Preventive</option>
                        <option value="predictive">Predictive</option>
                        <option value="emergency">Emergency</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="woPriority">Priority</label>
                    <select id="woPriority" name="priority" required>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="critical">Critical</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="woEstimatedHours">Estimated Hours</label>
                    <input type="number" id="woEstimatedHours" name="estimated_hours" 
                           min="0.1" step="0.5" placeholder="0.0">
                </div>
                
                <div class="form-group">
                    <label for="woDueDate">Due Date</label>
                    <input type="date" id="woDueDate" name="due_date">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Work Order</button>
            </div>
        </form>
    `;
    
    showModal('Create Work Order', content);
    
    // Handle form submission
    document.getElementById('createWorkOrderForm').addEventListener('submit', handleWorkOrderSubmission);
}

async function handleWorkOrderSubmission(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const workOrderData = {
        title: formData.get('title'),
        description: formData.get('description'),
        asset_id: currentAssetId,
        type: formData.get('type'),
        priority: formData.get('priority'),
        estimated_hours: formData.get('estimated_hours') ? parseFloat(formData.get('estimated_hours')) : null,
        due_date: formData.get('due_date') || null
    };
    
    try {
        const response = await fetch('/cmms/workorders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(workOrderData)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        closeModal();
        showNotification(`Work Order ${result.id} created successfully`, 'success');
        
        // Refresh dashboard to show new work order
        setTimeout(refreshDashboard, 1000);
        
    } catch (error) {
        console.error('Failed to create work order:', error);
        showNotification('Failed to create work order', 'error');
    }
}

async function schedulePM() {
    if (!currentAssetId) {
        showNotification('Asset ID not available', 'error');
        return;
    }
    
    const content = `
        <form id="schedulePMForm" class="modal-form">
            <div class="form-group">
                <label for="pmName">PM Name*</label>
                <input type="text" id="pmName" name="name" required 
                       placeholder="e.g., Quarterly Compressor Service">
            </div>
            
            <div class="form-group">
                <label for="pmDescription">Description*</label>
                <textarea id="pmDescription" name="description" required rows="3"
                          placeholder="Brief description of the preventive maintenance tasks"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="pmFrequency">Frequency (days)*</label>
                    <select id="pmFrequency" name="frequency_days" required>
                        <option value="7">Weekly (7 days)</option>
                        <option value="14">Bi-weekly (14 days)</option>
                        <option value="30" selected>Monthly (30 days)</option>
                        <option value="60">Bi-monthly (60 days)</option>
                        <option value="90">Quarterly (90 days)</option>
                        <option value="180">Semi-annual (180 days)</option>
                        <option value="365">Annual (365 days)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="pmDuration">Estimated Duration (hours)*</label>
                    <input type="number" id="pmDuration" name="estimated_duration" 
                           min="0.1" step="0.5" value="2.0" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="pmPriority">Priority</label>
                <select id="pmPriority" name="priority">
                    <option value="low">Low</option>
                    <option value="medium" selected>Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="pmInstructions">Instructions</label>
                <textarea id="pmInstructions" name="instructions" rows="4"
                          placeholder="Detailed step-by-step instructions for the maintenance tasks"></textarea>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-warning">Schedule PM</button>
            </div>
        </form>
    `;
    
    showModal('Schedule Preventive Maintenance', content);
    
    // Handle form submission
    document.getElementById('schedulePMForm').addEventListener('submit', handlePMScheduling);
}

async function handlePMScheduling(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const pmData = {
        name: formData.get('name'),
        asset_id: currentAssetId,
        frequency_days: parseInt(formData.get('frequency_days')),
        estimated_duration: parseFloat(formData.get('estimated_duration')),
        priority: formData.get('priority'),
        description: formData.get('description'),
        instructions: formData.get('instructions') || null,
        required_parts: [],
        required_skills: [],
        safety_requirements: []
    };
    
    try {
        const response = await fetch(`${config.apiBaseUrl}/dashboard/${currentAssetId}/pm`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(pmData)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        closeModal();
        showNotification(`PM Schedule ${result.id} created successfully`, 'success');
        
        // Refresh dashboard to show new PM schedule
        setTimeout(refreshDashboard, 1000);
        
    } catch (error) {
        console.error('Failed to schedule PM:', error);
        showNotification('Failed to schedule preventive maintenance', 'error');
    }
}

// =============================================================================
// Sidebar Updates
// =============================================================================

function updateSidebarData(data) {
    // Update upcoming PMs
    updateUpcomingPMs(data.upcoming_pms);
    
    // Update documents
    updateDocuments(data.documents);
    
    // Update parts inventory
    updatePartsInventory(data.inventory);
}

function updateUpcomingPMs(pms) {
    const pmSection = document.querySelector('.pm-schedule');
    if (!pmSection || !Array.isArray(pms)) return;
    
    // Update next due date if PM data is available
    if (pms.length > 0) {
        const nextPM = pms[0];
        const nextDueParagraph = pmSection.querySelector('p:first-child strong');
        if (nextDueParagraph) {
            nextDueParagraph.nextSibling.textContent = ` ${nextPM.due_date}`;
        }
    }
}

function updateDocuments(documents) {
    const docList = document.querySelector('.document-list');
    if (!docList || !Array.isArray(documents)) return;
    
    // Clear existing documents
    docList.innerHTML = '';
    
    // Add updated documents
    documents.forEach(doc => {
        const docItem = document.createElement('div');
        docItem.className = 'document-item';
        docItem.innerHTML = `
            <span>📘 ${doc.name}</span>
            <button class="btn-link" data-doc-url="${doc.url}">View</button>
        `;
        
        docList.appendChild(docItem);
    });
    
    // Re-initialize document links
    initializeDocumentLinks();
}

function updatePartsInventory(inventory) {
    const partsStatus = document.querySelector('.parts-status');
    if (!partsStatus || !Array.isArray(inventory)) return;
    
    // Clear existing parts
    partsStatus.innerHTML = '';
    
    // Add updated parts
    inventory.forEach(part => {
        const partItem = document.createElement('div');
        partItem.className = `part-item status-${part.status.replace('_', '-')}`;
        partItem.innerHTML = `
            <span>${part.name}</span>
            <span>${part.current_stock} in stock</span>
        `;
        
        partsStatus.appendChild(partItem);
    });
}

// =============================================================================
// Document Management
// =============================================================================

function initializeDocumentLinks() {
    const docLinks = document.querySelectorAll('.document-item .btn-link');
    docLinks.forEach(link => {
        link.addEventListener('click', handleDocumentView);
    });
}

function handleDocumentView(event) {
    event.preventDefault();
    
    const docUrl = event.target.getAttribute('data-doc-url');
    if (docUrl) {
        // In a real implementation, this would open the document
        // For now, show a placeholder
        showNotification('Document viewer would open here', 'info');
    }
}

// =============================================================================
// Utility Functions
// =============================================================================

function showModal(title, content) {
    const modalHtml = `
        <div class="modal-overlay" onclick="closeModal(event)">
            <div class="modal-content" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close" onclick="closeModal()">×</button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Focus management
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        modal.focus();
    }
}

function closeModal(event) {
    if (event && event.target !== event.currentTarget) return;
    
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        modal.remove();
    }
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${getNotificationIcon(type)}</span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        min-width: 300px;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    return icons[type] || icons.info;
}

function getNotificationColor(type) {
    const colors = {
        success: '#38a169',
        error: '#e53e3e',
        warning: '#d69e2e',
        info: '#4299e1'
    };
    return colors[type] || colors.info;
}

function startAutoRefresh() {
    // Only start auto-refresh for critical assets
    const statusBadge = document.querySelector('.status-badge');
    if (statusBadge && statusBadge.textContent.toLowerCase().includes('operational')) {
        refreshInterval = setInterval(refreshDashboard, config.refreshIntervalMs);
        console.log('Auto-refresh enabled for critical asset');
    }
}

function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
        console.log('Auto-refresh stopped');
    }
}

function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function(event) {
        // Don't trigger shortcuts when typing in inputs
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
            return;
        }
        
        switch (event.key) {
            case 'r':
            case 'R':
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    refreshDashboard();
                }
                break;
            case 'w':
            case 'W':
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    createWorkOrder();
                }
                break;
            case 'p':
            case 'P':
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    schedulePM();
                }
                break;
            case 'h':
            case 'H':
                if (!event.ctrlKey && !event.metaKey) {
                    toggleHistory();
                }
                break;
            case 'Escape':
                closeModal();
                break;
        }
    });
}

// =============================================================================
// Cleanup & Page Unload
// =============================================================================

window.addEventListener('beforeunload', function() {
    stopAutoRefresh();
});

// Add modal styles to document
const modalStyles = `
<style>
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}

.modal-content {
    background: white;
    border-radius: 12px;
    max-width: 500px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #e2e8f0;
}

.modal-header h3 {
    margin: 0;
    color: #1a202c;
}

.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #718096;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-close:hover {
    color: #2d3748;
}

.modal-body {
    padding: 1.5rem;
}

.modal-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group label {
    font-weight: 600;
    color: #2d3748;
    font-size: 0.875rem;
}

.form-group input,
.form-group select,
.form-group textarea {
    padding: 0.75rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    font-size: 0.875rem;
    transition: border-color 0.2s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #4299e1;
    box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.1);
}

.form-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid #e2e8f0;
}

.kpi-detail {
    line-height: 1.6;
}

.kpi-detail p {
    margin-bottom: 1rem;
}

.kpi-detail strong {
    color: #2d3748;
}

.event-detail h4 {
    color: #1a202c;
    margin-bottom: 1rem;
}

.event-detail p {
    margin-bottom: 0.5rem;
}

@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', modalStyles);