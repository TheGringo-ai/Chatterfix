/**
 * ChatterFix CMMS - Additional UI Components
 * Enhanced components for work orders, assets, and notifications
 */

/**
 * Enhanced Work Orders List Component
 */
class WorkOrdersList extends BaseComponent {
    constructor(initialState, eventBus) {
        super(initialState, eventBus);
        this.filters = {
            status: 'all',
            priority: 'all',
            assignee: 'all'
        };
        this.sortBy = 'created_at';
        this.sortOrder = 'desc';
    }
    
    createElement() {
        const element = document.createElement('div');
        element.className = 'work-orders-container';
        element.innerHTML = `
            <div class="page-header">
                <div class="header-content">
                    <h1 class="page-title">
                        <span class="page-icon">📋</span>
                        Work Orders
                    </h1>
                    <div class="header-actions">
                        <button class="btn btn-primary" id="new-wo-btn">
                            <span>✚</span> New Work Order
                        </button>
                        <button class="btn btn-secondary" id="export-btn">
                            <span>📊</span> Export
                        </button>
                    </div>
                </div>
                
                <div class="filters-bar">
                    <div class="filter-group">
                        <label>Status:</label>
                        <select id="status-filter">
                            <option value="all">All Status</option>
                            <option value="open">Open</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="overdue">Overdue</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Priority:</label>
                        <select id="priority-filter">
                            <option value="all">All Priority</option>
                            <option value="critical">Critical</option>
                            <option value="high">High</option>
                            <option value="medium">Medium</option>
                            <option value="low">Low</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Sort:</label>
                        <select id="sort-filter">
                            <option value="created_at">Created Date</option>
                            <option value="due_date">Due Date</option>
                            <option value="priority">Priority</option>
                            <option value="status">Status</option>
                        </select>
                    </div>
                    
                    <div class="search-group">
                        <input type="search" id="search-input" placeholder="Search work orders..." 
                               class="form-control">
                        <button class="btn-icon" id="voice-search-btn" title="Voice Search">🎤</button>
                    </div>
                </div>
            </div>
            
            <div class="work-orders-grid" id="work-orders-list">
                <!-- Work orders will be populated here -->
            </div>
            
            <div class="pagination-container">
                <div class="pagination-info">
                    <span id="pagination-info">Showing 1-20 of 150 work orders</span>
                </div>
                <div class="pagination-controls">
                    <button class="btn btn-sm" id="prev-page" disabled>← Previous</button>
                    <span class="page-numbers" id="page-numbers"></span>
                    <button class="btn btn-sm" id="next-page">Next →</button>
                </div>
            </div>
        `;
        
        return element;
    }
    
    onMount() {
        // Bind event listeners
        this.element.querySelector('#new-wo-btn').addEventListener('click', () => {
            this.showNewWorkOrderModal();
        });
        
        this.element.querySelector('#export-btn').addEventListener('click', () => {
            this.exportWorkOrders();
        });
        
        this.element.querySelector('#voice-search-btn').addEventListener('click', () => {
            this.startVoiceSearch();
        });
        
        // Filter event listeners
        ['status-filter', 'priority-filter', 'sort-filter'].forEach(id => {
            this.element.querySelector(`#${id}`).addEventListener('change', (e) => {
                this.updateFilters(id.replace('-filter', ''), e.target.value);
            });
        });
        
        // Search input
        const searchInput = this.element.querySelector('#search-input');
        searchInput.addEventListener('input', this.debounce((e) => {
            this.searchWorkOrders(e.target.value);
        }, 300));
        
        // Initial render
        this.renderWorkOrders();
    }
    
    onUpdate(oldState, newState) {
        if (newState.workOrders !== oldState.workOrders) {
            this.renderWorkOrders();
        }
    }
    
    renderWorkOrders() {
        const container = this.element.querySelector('#work-orders-list');
        const workOrders = this.getFilteredWorkOrders();
        
        if (workOrders.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📋</div>
                    <h3>No Work Orders Found</h3>
                    <p>Try adjusting your filters or create a new work order to get started.</p>
                    <button class="btn btn-primary" onclick="this.showNewWorkOrderModal()">
                        Create First Work Order
                    </button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = workOrders.map(wo => this.renderWorkOrderCard(wo)).join('');
        
        // Bind card event listeners
        container.querySelectorAll('.work-order-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.work-order-actions')) {
                    const woId = card.dataset.woId;
                    this.showWorkOrderDetails(woId);
                }
            });
        });
    }
    
    renderWorkOrderCard(workOrder) {
        const priorityClass = `priority-${workOrder.priority || 'medium'}`;
        const statusClass = `status-${workOrder.status || 'open'}`;
        const overdue = new Date(workOrder.due_date) < new Date() && workOrder.status !== 'completed';
        
        return `
            <div class="work-order-card ${statusClass} ${overdue ? 'overdue' : ''}" 
                 data-wo-id="${workOrder.id}" data-priority="${workOrder.priority}">
                <div class="work-order-header">
                    <div class="wo-id-section">
                        <span class="work-order-id">WO-${workOrder.id}</span>
                        <span class="priority-badge ${priorityClass}">${workOrder.priority || 'Medium'}</span>
                    </div>
                    <div class="wo-status">
                        <span class="status-badge ${statusClass}">${workOrder.status || 'Open'}</span>
                        ${overdue ? '<span class="overdue-indicator">⚠️ Overdue</span>' : ''}
                    </div>
                </div>
                
                <div class="work-order-content">
                    <h3 class="work-order-title">${workOrder.title || 'Untitled Work Order'}</h3>
                    <p class="work-order-description">${workOrder.description || 'No description provided.'}</p>
                    
                    <div class="work-order-meta">
                        <div class="meta-item">
                            <span class="meta-icon">🏭</span>
                            <span class="meta-text">${workOrder.asset_name || 'No Asset'}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-icon">👤</span>
                            <span class="meta-text">${workOrder.assigned_to || 'Unassigned'}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-icon">📅</span>
                            <span class="meta-text">${this.formatDate(workOrder.due_date)}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-icon">⏱️</span>
                            <span class="meta-text">${workOrder.estimated_hours || 0}h estimated</span>
                        </div>
                    </div>
                </div>
                
                <div class="work-order-actions">
                    <button class="btn btn-sm btn-primary" onclick="this.editWorkOrder('${workOrder.id}')">
                        <span>✏️</span> Edit
                    </button>
                    <button class="btn btn-sm btn-success" onclick="this.completeWorkOrder('${workOrder.id}')">
                        <span>✅</span> Complete
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="this.duplicateWorkOrder('${workOrder.id}')">
                        <span>📋</span> Duplicate
                    </button>
                </div>
            </div>
        `;
    }
    
    getFilteredWorkOrders() {
        let filtered = [...(this.state.workOrders || [])];
        
        // Apply filters
        if (this.filters.status !== 'all') {
            filtered = filtered.filter(wo => wo.status === this.filters.status);
        }
        
        if (this.filters.priority !== 'all') {
            filtered = filtered.filter(wo => wo.priority === this.filters.priority);
        }
        
        // Apply search
        if (this.searchQuery) {
            const query = this.searchQuery.toLowerCase();
            filtered = filtered.filter(wo => 
                (wo.title || '').toLowerCase().includes(query) ||
                (wo.description || '').toLowerCase().includes(query) ||
                (wo.asset_name || '').toLowerCase().includes(query)
            );
        }
        
        // Apply sorting
        filtered.sort((a, b) => {
            let aVal = a[this.sortBy];
            let bVal = b[this.sortBy];
            
            if (this.sortBy === 'priority') {
                const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
                aVal = priorityOrder[aVal] || 0;
                bVal = priorityOrder[bVal] || 0;
            }
            
            if (this.sortOrder === 'desc') {
                return bVal > aVal ? 1 : -1;
            }
            return aVal > bVal ? 1 : -1;
        });
        
        return filtered;
    }
    
    updateFilters(type, value) {
        this.filters[type] = value;
        this.renderWorkOrders();
    }
    
    searchWorkOrders(query) {
        this.searchQuery = query;
        this.renderWorkOrders();
    }
    
    startVoiceSearch() {
        if (window.cmmsApp && window.cmmsApp.voiceController) {
            window.cmmsApp.voiceController.startVoiceSession();
            this.speak('What would you like to search for?');
        }
    }
    
    showNewWorkOrderModal() {
        // Implementation would show a modal for creating new work orders
        this.emit('show-modal', { 
            type: 'new-work-order',
            title: 'Create New Work Order'
        });
    }
    
    showWorkOrderDetails(woId) {
        this.emit('navigate', { path: `/work-orders/${woId}` });
    }
    
    formatDate(dateString) {
        if (!dateString) return 'No date set';
        
        const date = new Date(dateString);
        const today = new Date();
        const diffTime = date - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) return 'Today';
        if (diffDays === 1) return 'Tomorrow';
        if (diffDays === -1) return 'Yesterday';
        if (diffDays > 1 && diffDays <= 7) return `In ${diffDays} days`;
        if (diffDays < -1 && diffDays >= -7) return `${Math.abs(diffDays)} days ago`;
        
        return date.toLocaleDateString();
    }
    
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    exportWorkOrders() {
        const workOrders = this.getFilteredWorkOrders();
        const csvContent = this.convertToCSV(workOrders);
        this.downloadCSV(csvContent, 'work-orders.csv');
    }
    
    convertToCSV(data) {
        const headers = ['ID', 'Title', 'Status', 'Priority', 'Assigned To', 'Due Date', 'Created Date'];
        const rows = data.map(wo => [
            wo.id,
            wo.title || '',
            wo.status || '',
            wo.priority || '',
            wo.assigned_to || '',
            wo.due_date || '',
            wo.created_at || ''
        ]);
        
        return [headers, ...rows]
            .map(row => row.map(field => `"${field}"`).join(','))
            .join('\n');
    }
    
    downloadCSV(content, filename) {
        const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

/**
 * Enhanced Assets List Component
 */
class AssetsList extends BaseComponent {
    createElement() {
        const element = document.createElement('div');
        element.className = 'assets-container';
        element.innerHTML = `
            <div class="page-header">
                <div class="header-content">
                    <h1 class="page-title">
                        <span class="page-icon">⚙️</span>
                        Asset Management
                    </h1>
                    <div class="header-actions">
                        <button class="btn btn-primary" id="new-asset-btn">
                            <span>✚</span> Add Asset
                        </button>
                        <button class="btn btn-secondary" id="qr-scan-btn">
                            <span>📱</span> QR Scan
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="assets-grid-container">
                <div class="assets-sidebar">
                    <div class="sidebar-section">
                        <h3>Categories</h3>
                        <div class="category-list" id="category-list">
                            <!-- Categories will be populated -->
                        </div>
                    </div>
                    
                    <div class="sidebar-section">
                        <h3>Status Overview</h3>
                        <div class="status-overview" id="status-overview">
                            <!-- Status counts will be populated -->
                        </div>
                    </div>
                </div>
                
                <div class="assets-main">
                    <div class="assets-toolbar">
                        <div class="view-controls">
                            <button class="view-btn active" data-view="grid" title="Grid View">⊞</button>
                            <button class="view-btn" data-view="list" title="List View">☰</button>
                            <button class="view-btn" data-view="map" title="Map View">🗺️</button>
                        </div>
                        
                        <div class="search-controls">
                            <input type="search" id="asset-search" placeholder="Search assets..." class="form-control">
                            <button class="btn-icon" id="asset-voice-search" title="Voice Search">🎤</button>
                        </div>
                    </div>
                    
                    <div class="assets-grid" id="assets-grid">
                        <!-- Assets will be populated here -->
                    </div>
                </div>
            </div>
        `;
        
        return element;
    }
    
    onMount() {
        this.renderAssets();
        this.renderCategories();
        this.renderStatusOverview();
        
        // View controls
        this.element.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchView(e.target.dataset.view);
            });
        });
    }
    
    renderAssets() {
        const container = this.element.querySelector('#assets-grid');
        const assets = this.state.assets || [];
        
        container.innerHTML = assets.map(asset => `
            <div class="asset-card" data-asset-id="${asset.id}">
                <div class="asset-header">
                    <div class="asset-status ${asset.status}"></div>
                    <div class="asset-id">#${asset.id}</div>
                    <div class="asset-qr" title="QR Code">📱</div>
                </div>
                
                <div class="asset-image">
                    <img src="${asset.image || '/static/images/default-asset.png'}" 
                         alt="${asset.name}" loading="lazy">
                </div>
                
                <div class="asset-content">
                    <h3 class="asset-name">${asset.name}</h3>
                    <p class="asset-location">📍 ${asset.location}</p>
                    <div class="asset-metrics">
                        <div class="metric">
                            <span class="metric-label">Uptime</span>
                            <span class="metric-value">${asset.uptime || 0}%</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Last Service</span>
                            <span class="metric-value">${this.formatDate(asset.last_service)}</span>
                        </div>
                    </div>
                </div>
                
                <div class="asset-actions">
                    <button class="btn btn-sm btn-primary">View Details</button>
                    <button class="btn btn-sm btn-secondary">Create WO</button>
                </div>
            </div>
        `).join('');
    }
    
    renderCategories() {
        // Implementation for category sidebar
        const container = this.element.querySelector('#category-list');
        const categories = this.getAssetCategories();
        
        container.innerHTML = categories.map(cat => `
            <div class="category-item" data-category="${cat.name}">
                <span class="category-name">${cat.name}</span>
                <span class="category-count">${cat.count}</span>
            </div>
        `).join('');
    }
    
    renderStatusOverview() {
        // Implementation for status overview
        const container = this.element.querySelector('#status-overview');
        const statusCounts = this.getStatusCounts();
        
        container.innerHTML = Object.entries(statusCounts).map(([status, count]) => `
            <div class="status-item ${status}">
                <div class="status-indicator"></div>
                <div class="status-info">
                    <span class="status-name">${status.charAt(0).toUpperCase() + status.slice(1)}</span>
                    <span class="status-count">${count}</span>
                </div>
            </div>
        `).join('');
    }
    
    getAssetCategories() {
        // Group assets by category
        const categories = {};
        (this.state.assets || []).forEach(asset => {
            const cat = asset.category || 'Uncategorized';
            categories[cat] = (categories[cat] || 0) + 1;
        });
        
        return Object.entries(categories).map(([name, count]) => ({ name, count }));
    }
    
    getStatusCounts() {
        const counts = { operational: 0, warning: 0, critical: 0, offline: 0 };
        (this.state.assets || []).forEach(asset => {
            counts[asset.status] = (counts[asset.status] || 0) + 1;
        });
        return counts;
    }
    
    switchView(viewType) {
        this.element.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === viewType);
        });
        
        const container = this.element.querySelector('#assets-grid');
        container.className = `assets-grid view-${viewType}`;
    }
    
    formatDate(dateString) {
        if (!dateString) return 'Never';
        return new Date(dateString).toLocaleDateString();
    }
}

/**
 * Enhanced Notification Center Component
 */
class NotificationCenter extends BaseComponent {
    createElement() {
        const element = document.createElement('div');
        element.className = 'notification-center';
        element.innerHTML = `
            <div class="notification-header">
                <h3>Notifications</h3>
                <button class="btn btn-sm" id="mark-all-read">Mark All Read</button>
            </div>
            
            <div class="notification-list" id="notification-list">
                <!-- Notifications will be populated here -->
            </div>
        `;
        
        return element;
    }
    
    onMount() {
        this.renderNotifications();
        
        this.element.querySelector('#mark-all-read').addEventListener('click', () => {
            this.markAllRead();
        });
    }
    
    onUpdate(oldState, newState) {
        if (newState.notifications !== oldState.notifications) {
            this.renderNotifications();
        }
    }
    
    renderNotifications() {
        const container = this.element.querySelector('#notification-list');
        const notifications = this.state.notifications || [];
        
        if (notifications.length === 0) {
            container.innerHTML = `
                <div class="empty-notifications">
                    <div class="empty-icon">🔔</div>
                    <p>No new notifications</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = notifications.map(notification => `
            <div class="notification-item ${notification.type}" data-id="${notification.id}">
                <div class="notification-icon">${this.getNotificationIcon(notification.type)}</div>
                <div class="notification-content">
                    <div class="notification-message">${notification.message}</div>
                    <div class="notification-time">${this.formatTimeAgo(notification.timestamp)}</div>
                </div>
                <button class="notification-close" onclick="this.removeNotification('${notification.id}')">×</button>
            </div>
        `).join('');
    }
    
    getNotificationIcon(type) {
        const icons = {
            info: 'ℹ️',
            success: '✅',
            warning: '⚠️',
            error: '❌'
        };
        return icons[type] || 'ℹ️';
    }
    
    formatTimeAgo(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const seconds = Math.floor((now - date) / 1000);
        
        if (seconds < 60) return 'Just now';
        if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
        if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
        return Math.floor(seconds / 86400) + 'd ago';
    }
    
    markAllRead() {
        this.emit('notifications-clear');
    }
    
    removeNotification(id) {
        this.emit('notification-remove', { id });
    }
}

// Export components for use in main app
if (typeof window !== 'undefined') {
    window.WorkOrdersList = WorkOrdersList;
    window.AssetsList = AssetsList;
    window.NotificationCenter = NotificationCenter;
}

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { WorkOrdersList, AssetsList, NotificationCenter };
}