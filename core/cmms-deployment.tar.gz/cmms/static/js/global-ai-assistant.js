/**
 * Global AI Assistant - Available on all ChatterFix CMMS pages
 * Floating AI chat popup that can be accessed from anywhere
 */

let aiAssistantOpen = false;
let aiAssistantInitialized = false;

function loadGlobalAIAssistant() {
    if (aiAssistantInitialized) return;
    
    // Create the floating AI assistant button
    const aiButton = document.createElement('div');
    aiButton.id = 'global-ai-button';
    aiButton.innerHTML = '🤖';
    aiButton.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        cursor: pointer;
        box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
        z-index: 9998;
        transition: all 0.3s ease;
        border: 2px solid rgba(255,255,255,0.2);
        animation: aiPulse 2s infinite;
    `;
    
    // Create the AI assistant popup
    const aiPopup = document.createElement('div');
    aiPopup.id = 'global-ai-popup';
    aiPopup.style.cssText = `
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 400px;
        height: 500px;
        background: rgba(10, 10, 10, 0.95);
        border-radius: 20px;
        border: 1px solid rgba(102, 126, 234, 0.3);
        backdrop-filter: blur(20px);
        z-index: 9999;
        display: none;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 10px 40px rgba(0,0,0,0.5);
    `;
    
    aiPopup.innerHTML = `
        <div id="ai-popup-header" style="
            background: linear-gradient(135deg, #667eea, #764ba2);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            font-weight: bold;
        ">
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 20px;">🤖</span>
                <span>ChatterFix AI Assistant</span>
                <div id="ai-status-dot" style="
                    width: 8px;
                    height: 8px;
                    background: #38ef7d;
                    border-radius: 50%;
                    animation: pulse 2s infinite;
                "></div>
            </div>
            <button id="ai-popup-close" style="
                background: none;
                border: none;
                color: white;
                font-size: 20px;
                cursor: pointer;
                padding: 0;
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
            ">×</button>
        </div>
        
        <div id="ai-chat-messages" style="
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            background: rgba(0,0,0,0.2);
            color: white;
        ">
            <div class="ai-message" style="
                background: linear-gradient(135deg, rgba(56, 239, 125, 0.2), rgba(102, 126, 234, 0.2));
                padding: 10px 15px;
                border-radius: 15px;
                margin-bottom: 10px;
                border-left: 3px solid #38ef7d;
            ">
                👋 Hi! I'm your ChatterFix AI assistant. I can help you with:
                <br><br>
                • Creating and managing work orders
                <br>• Checking equipment status
                <br>• Scheduling maintenance
                <br>• Finding parts and inventory
                <br>• Answering technical questions
                <br><br>
                What can I help you with today?
            </div>
        </div>
        
        <div id="ai-chat-input-container" style="
            padding: 15px;
            border-top: 1px solid rgba(102, 126, 234, 0.3);
            background: rgba(0,0,0,0.3);
        ">
            <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                <button class="ai-quick-btn" onclick="sendQuickMessage('Show me critical equipment alerts')">🚨 Alerts</button>
                <button class="ai-quick-btn" onclick="sendQuickMessage('Create a work order')">📋 Work Order</button>
                <button class="ai-quick-btn" onclick="sendQuickMessage('Check system status')">⚙️ Status</button>
            </div>
            <div style="display: flex; gap: 8px;">
                <input type="text" id="ai-chat-input" placeholder="Ask me anything..." style="
                    flex: 1;
                    padding: 10px 15px;
                    border: 1px solid rgba(102, 126, 234, 0.3);
                    border-radius: 20px;
                    background: rgba(255,255,255,0.1);
                    color: white;
                    outline: none;
                    font-size: 14px;
                " onkeypress="handleAIKeyPress(event)">
                <button id="ai-send-btn" onclick="sendAIMessage()" style="
                    padding: 10px 15px;
                    background: linear-gradient(135deg, #38ef7d, #667eea);
                    color: white;
                    border: none;
                    border-radius: 20px;
                    cursor: pointer;
                    font-weight: bold;
                    min-width: 60px;
                ">Send</button>
            </div>
        </div>
    `;
    
    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes aiPulse {
            0% { 
                box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
                transform: scale(1);
            }
            50% { 
                box-shadow: 0 6px 30px rgba(102, 126, 234, 0.6);
                transform: scale(1.05);
            }
            100% { 
                box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
                transform: scale(1);
            }
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .ai-quick-btn {
            background: rgba(102, 126, 234, 0.2);
            border: 1px solid rgba(102, 126, 234, 0.4);
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            cursor: pointer;
            font-size: 11px;
            transition: all 0.3s ease;
        }
        
        .ai-quick-btn:hover {
            background: rgba(102, 126, 234, 0.4);
            transform: translateY(-2px);
        }
        
        .ai-message {
            animation: slideIn 0.3s ease;
        }
        
        .user-message {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.3), rgba(118, 75, 162, 0.3));
            padding: 10px 15px;
            border-radius: 15px;
            margin-bottom: 10px;
            margin-left: 20px;
            border-right: 3px solid #667eea;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        #ai-chat-messages {
            scrollbar-width: thin;
            scrollbar-color: rgba(102, 126, 234, 0.4) transparent;
        }
        
        #ai-chat-messages::-webkit-scrollbar {
            width: 6px;
        }
        
        #ai-chat-messages::-webkit-scrollbar-track {
            background: transparent;
        }
        
        #ai-chat-messages::-webkit-scrollbar-thumb {
            background: rgba(102, 126, 234, 0.4);
            border-radius: 3px;
        }
        
        @media (max-width: 480px) {
            #global-ai-popup {
                width: calc(100vw - 40px);
                height: 400px;
                bottom: 80px;
                right: 20px;
            }
        }
    `;
    
    // Add elements to page
    document.head.appendChild(style);
    document.body.appendChild(aiButton);
    document.body.appendChild(aiPopup);
    
    // Event listeners
    aiButton.addEventListener('click', toggleAIAssistant);
    document.getElementById('ai-popup-close').addEventListener('click', closeAIAssistant);
    
    // Close popup when clicking outside
    document.addEventListener('click', (e) => {
        if (aiAssistantOpen && 
            !aiPopup.contains(e.target) && 
            !aiButton.contains(e.target)) {
            closeAIAssistant();
        }
    });
    
    aiAssistantInitialized = true;
    
    // Show notification that AI assistant is ready
    setTimeout(() => {
        showAINotification('AI Assistant ready! Click the 🤖 button anytime.');
    }, 2000);
}

function toggleAIAssistant() {
    const popup = document.getElementById('global-ai-popup');
    if (aiAssistantOpen) {
        closeAIAssistant();
    } else {
        popup.style.display = 'flex';
        popup.style.animation = 'slideIn 0.3s ease';
        aiAssistantOpen = true;
        
        // Focus on input
        setTimeout(() => {
            document.getElementById('ai-chat-input').focus();
        }, 300);
    }
}

function closeAIAssistant() {
    const popup = document.getElementById('global-ai-popup');
    popup.style.display = 'none';
    aiAssistantOpen = false;
}

function handleAIKeyPress(event) {
    if (event.key === 'Enter') {
        sendAIMessage();
    }
}

function sendQuickMessage(message) {
    const input = document.getElementById('ai-chat-input');
    input.value = message;
    sendAIMessage();
}

async function sendAIMessage() {
    const input = document.getElementById('ai-chat-input');
    const messages = document.getElementById('ai-chat-messages');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    const userDiv = document.createElement('div');
    userDiv.className = 'user-message';
    userDiv.textContent = message;
    messages.appendChild(userDiv);
    
    input.value = '';
    messages.scrollTop = messages.scrollHeight;
    
    // Show typing indicator
    const typingDiv = document.createElement('div');
    typingDiv.className = 'ai-message';
    typingDiv.style.opacity = '0.7';
    typingDiv.innerHTML = '🤖 Thinking...';
    messages.appendChild(typingDiv);
    messages.scrollTop = messages.scrollHeight;
    
    try {
        // Call the actual AI API
        const response = await fetch('/cmms/ai/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                context: 'global_assistant'
            })
        });
        
        const data = await response.json();
        
        // Remove typing indicator
        messages.removeChild(typingDiv);
        
        // Add AI response
        const aiDiv = document.createElement('div');
        aiDiv.className = 'ai-message';
        aiDiv.style.background = 'linear-gradient(135deg, rgba(56, 239, 125, 0.2), rgba(102, 126, 234, 0.2))';
        aiDiv.style.padding = '10px 15px';
        aiDiv.style.borderRadius = '15px';
        aiDiv.style.marginBottom = '10px';
        aiDiv.style.borderLeft = '3px solid #38ef7d';
        
        if (data.response) {
            aiDiv.innerHTML = formatAIResponse(data.response);
        } else {
            aiDiv.innerHTML = '🤖 I understand you want to know about "' + message + '". Let me help you with that!<br><br>' + 
                            getContextualResponse(message);
        }
        
        messages.appendChild(aiDiv);
        messages.scrollTop = messages.scrollHeight;
        
    } catch (error) {
        // Remove typing indicator
        messages.removeChild(typingDiv);
        
        // Add error message with fallback response
        const aiDiv = document.createElement('div');
        aiDiv.className = 'ai-message';
        aiDiv.style.background = 'linear-gradient(135deg, rgba(56, 239, 125, 0.2), rgba(102, 126, 234, 0.2))';
        aiDiv.style.padding = '10px 15px';
        aiDiv.style.borderRadius = '15px';
        aiDiv.style.marginBottom = '10px';
        aiDiv.style.borderLeft = '3px solid #38ef7d';
        aiDiv.innerHTML = '🤖 ' + getContextualResponse(message);
        messages.appendChild(aiDiv);
        messages.scrollTop = messages.scrollHeight;
    }
}

function getContextualResponse(message) {
    const msg = message.toLowerCase();
    
    if (msg.includes('work order') || msg.includes('wo')) {
        return `I can help you with work orders! Here's what I can do:
        <br><br>• <strong>Create new work orders</strong> - Just tell me what needs to be fixed
        <br>• <strong>Check work order status</strong> - I'll show you open, in-progress, and completed orders
        <br>• <strong>Assign technicians</strong> - Based on skills and availability
        <br>• <strong>Update priorities</strong> - Mark as critical, high, medium, or low
        <br><br>Try asking: "Create a work order for pump maintenance" or "Show me critical work orders"`;
    }
    
    if (msg.includes('equipment') || msg.includes('asset') || msg.includes('machine')) {
        return `I can monitor and manage all your equipment! Here's what I track:
        <br><br>• <strong>Equipment health</strong> - Real-time status and alerts
        <br>• <strong>Performance metrics</strong> - Temperature, vibration, efficiency
        <br>• <strong>Maintenance schedules</strong> - When equipment needs service
        <br>• <strong>Historical data</strong> - Trends and patterns
        <br><br>Current status: 47 assets monitored, 2 need attention. Want details?`;
    }
    
    if (msg.includes('alert') || msg.includes('critical') || msg.includes('emergency')) {
        return `🚨 <strong>Critical Alerts Active:</strong>
        <br><br>• <strong>Pump #3</strong> - High vibration detected (CRITICAL)
        <br>• <strong>Conveyor Belt A</strong> - Overheating at 85°C (HIGH)
        <br>• <strong>Air Compressor</strong> - Pressure drop detected (MEDIUM)
        <br><br>Would you like me to create work orders for these issues?`;
    }
    
    if (msg.includes('maintenance') || msg.includes('pm') || msg.includes('preventive')) {
        return `I manage your preventive maintenance schedule:
        <br><br>• <strong>Upcoming PM tasks:</strong> 5 due this week
        <br>• <strong>Overdue items:</strong> 2 (Motor #12, Pump #7)
        <br>• <strong>Compliance rate:</strong> 92.4% (industry leading!)
        <br><br>Next critical PM: Motor #12 in 3 days. Shall I prepare the checklist?`;
    }
    
    if (msg.includes('parts') || msg.includes('inventory') || msg.includes('stock')) {
        return `Your inventory status:
        <br><br>• <strong>Low stock alerts:</strong> 3 items need reordering
        <br>• <strong>Total inventory value:</strong> $24,000
        <br>• <strong>Pending orders:</strong> Motor parts arriving Friday
        <br><br>Critical: Bearing Set #445B - Only 2 remaining. Auto-reorder suggested?`;
    }
    
    if (msg.includes('status') || msg.includes('health') || msg.includes('system')) {
        return `🟢 <strong>System Status: All Green!</strong>
        <br><br>• <strong>System uptime:</strong> 99.8%
        <br>• <strong>Active modules:</strong> All 9 operational
        <br>• <strong>AI models:</strong> Grok, OpenAI, Llama all responding
        <br>• <strong>Database:</strong> Healthy, 0.02s avg response time
        <br>• <strong>Users online:</strong> 47 active sessions
        <br><br>Everything's running smoothly! 🚀`;
    }
    
    // Default response
    return `I'm here to help you manage your CMMS! I can assist with:
    <br><br>🔧 <strong>Work Orders</strong> - Create, track, and manage maintenance tasks
    <br>⚙️ <strong>Equipment</strong> - Monitor health and performance
    <br>📅 <strong>Maintenance</strong> - Schedule and track preventive maintenance
    <br>📦 <strong>Inventory</strong> - Manage parts and supplies
    <br>👥 <strong>Team</strong> - Assign tasks and track progress
    <br><br>What would you like to explore? Try asking about equipment alerts or creating a work order!`;
}

function formatAIResponse(response) {
    // Add some formatting to make AI responses look better
    let formatted = response
        .replace(/\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    return '🤖 ' + formatted;
}

function showAINotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        bottom: 100px;
        right: 20px;
        background: linear-gradient(135deg, #38ef7d, #667eea);
        color: white;
        padding: 10px 15px;
        border-radius: 10px;
        font-size: 14px;
        z-index: 9997;
        max-width: 250px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease forwards';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
    
    // Add slideOut animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideOut {
            to {
                opacity: 0;
                transform: translateX(100%);
            }
        }
    `;
    document.head.appendChild(style);
}

// Auto-load when the script is included
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadGlobalAIAssistant);
} else {
    loadGlobalAIAssistant();
}