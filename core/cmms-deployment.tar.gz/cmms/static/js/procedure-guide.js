/**
 * Procedural Guide System for ChatterFix CMMS
 * Voice-guided step-by-step procedures with TTS read-out mode
 */

class ProcedureGuide {
    constructor() {
        this.currentProcedure = null;
        this.currentStep = 0;
        this.isActive = false;
        this.ttsEnabled = true;
        this.autoAdvance = false;
        this.overlay = null;
        this.synthesis = window.speechSynthesis;
        this.voice = null;
        
        // Procedure templates
        this.procedures = {
            'pump_maintenance': {
                title: 'Pump Maintenance Procedure',
                asset_type: 'pump',
                estimated_time: '45 minutes',
                difficulty: 'medium',
                safety_notes: [
                    'Ensure power is disconnected',
                    'Wear safety goggles and gloves',
                    'Have spill containment ready'
                ],
                tools_required: [
                    'Wrench set',
                    'Seal kit',
                    'Torque wrench',
                    'Cleaning supplies'
                ],
                steps: [
                    {
                        title: 'Safety Preparation',
                        description: 'Disconnect power and lockout/tagout the pump. Verify zero energy state.',
                        voice_text: 'First, disconnect power and apply lockout tagout to the pump. Verify zero energy state with a meter.',
                        type: 'safety',
                        estimated_time: '5 minutes',
                        checkpoints: [
                            'Power disconnected',
                            'LOTO applied',
                            'Energy verified zero'
                        ],
                        voice_commands: ['next step', 'repeat', 'help']
                    },
                    {
                        title: 'Drain System',
                        description: 'Open drain valves and allow system to fully drain. Clean any spills.',
                        voice_text: 'Next, open the drain valves and allow the system to fully drain. Clean up any spills immediately.',
                        type: 'procedure',
                        estimated_time: '10 minutes',
                        checkpoints: [
                            'Valves opened',
                            'System drained',
                            'Spills cleaned'
                        ],
                        voice_commands: ['next step', 'repeat', 'previous step']
                    },
                    {
                        title: 'Disconnect Piping',
                        description: 'Remove bolts from suction and discharge flanges. Support piping weight.',
                        voice_text: 'Carefully remove bolts from suction and discharge flanges. Make sure to support the piping weight.',
                        type: 'procedure',
                        estimated_time: '15 minutes',
                        checkpoints: [
                            'Suction flange disconnected',
                            'Discharge flange disconnected',
                            'Piping supported'
                        ],
                        voice_commands: ['next step', 'repeat', 'torque specs']
                    },
                    {
                        title: 'Remove Pump Casing',
                        description: 'Remove casing bolts in cross pattern. Lift casing carefully.',
                        voice_text: 'Remove the casing bolts in a cross pattern to avoid warping. Lift the casing carefully and set aside.',
                        type: 'procedure',
                        estimated_time: '10 minutes',
                        checkpoints: [
                            'Bolts removed in sequence',
                            'Casing lifted safely',
                            'Parts organized'
                        ],
                        voice_commands: ['next step', 'repeat', 'bolt pattern']
                    },
                    {
                        title: 'Inspect Components',
                        description: 'Check impeller, wear rings, and seals for damage or wear.',
                        voice_text: 'Inspect the impeller, wear rings, and seals for any damage or excessive wear. Document findings.',
                        type: 'inspection',
                        estimated_time: '5 minutes',
                        checkpoints: [
                            'Impeller inspected',
                            'Wear rings checked',
                            'Seals examined',
                            'Findings documented'
                        ],
                        voice_commands: ['next step', 'repeat', 'take photo', 'add note']
                    }
                ]
            },
            'motor_inspection': {
                title: 'Motor Inspection Procedure',
                asset_type: 'motor',
                estimated_time: '30 minutes',
                difficulty: 'easy',
                safety_notes: [
                    'Ensure motor is de-energized',
                    'Allow cooling time if recently operated',
                    'Use proper PPE'
                ],
                tools_required: [
                    'Multimeter',
                    'Megohmmeter',
                    'Temperature gun',
                    'Vibration meter'
                ],
                steps: [
                    {
                        title: 'Visual Inspection',
                        description: 'Check for physical damage, corrosion, or contamination.',
                        voice_text: 'Start with a thorough visual inspection. Look for physical damage, corrosion, or contamination on the motor housing.',
                        type: 'inspection',
                        estimated_time: '5 minutes',
                        checkpoints: [
                            'Housing inspected',
                            'Connections checked',
                            'Mounting verified'
                        ],
                        voice_commands: ['next step', 'repeat', 'take photo']
                    },
                    {
                        title: 'Electrical Testing',
                        description: 'Test insulation resistance and winding continuity.',
                        voice_text: 'Test the insulation resistance and winding continuity using your megohmmeter and multimeter.',
                        type: 'testing',
                        estimated_time: '15 minutes',
                        checkpoints: [
                            'Insulation tested',
                            'Continuity verified',
                            'Results recorded'
                        ],
                        voice_commands: ['next step', 'repeat', 'record reading']
                    },
                    {
                        title: 'Vibration Analysis',
                        description: 'Measure vibration levels at bearing locations.',
                        voice_text: 'Measure vibration levels at all bearing locations. Compare with baseline readings.',
                        type: 'testing',
                        estimated_time: '10 minutes',
                        checkpoints: [
                            'DE bearing measured',
                            'NDE bearing measured',
                            'Readings compared'
                        ],
                        voice_commands: ['next step', 'repeat', 'record reading', 'compare baseline']
                    }
                ]
            }
        };
        
        this.init();
    }
    
    init() {
        this.setupVoice();
        this.createUI();
        this.bindEvents();
        console.log('📋 Procedure Guide initialized');
    }
    
    setupVoice() {
        if (!this.synthesis) {
            console.warn('❌ Text-to-Speech not supported');
            return;
        }
        
        // Get available voices
        const voices = this.synthesis.getVoices();
        
        // Prefer English voices
        this.voice = voices.find(voice => 
            voice.lang.startsWith('en-') && 
            (voice.name.includes('Google') || voice.name.includes('Microsoft'))
        ) || voices.find(voice => voice.lang.startsWith('en-')) || voices[0];
        
        console.log(`🔊 TTS Voice: ${this.voice?.name || 'Default'}`);
    }
    
    createUI() {
        // Create procedure overlay (initially hidden)
        this.overlay = document.createElement('div');
        this.overlay.className = 'procedure-overlay';
        this.overlay.style.display = 'none';
        document.body.appendChild(this.overlay);
    }
    
    bindEvents() {
        // Global voice commands for procedure navigation
        document.addEventListener('keydown', (e) => {
            if (!this.isActive) return;
            
            switch(e.key.toLowerCase()) {
                case 'n': // Next step
                    if (e.ctrlKey) {
                        e.preventDefault();
                        this.nextStep();
                    }
                    break;
                case 'p': // Previous step
                    if (e.ctrlKey) {
                        e.preventDefault();
                        this.previousStep();
                    }
                    break;
                case 'r': // Repeat current step
                    if (e.ctrlKey) {
                        e.preventDefault();
                        this.repeatStep();
                    }
                    break;
                case 'h': // Help
                    if (e.ctrlKey) {
                        e.preventDefault();
                        this.showHelp();
                    }
                    break;
                case 'escape':
                    this.closeProcedure();
                    break;
            }
        });
        
        // Listen for voice commands if voice controller is available
        if (window.voiceController) {
            this.integrateWithVoiceController();
        }
    }
    
    integrateWithVoiceController() {
        // Add procedure-specific voice commands
        const originalProcessCommand = window.voiceController.processCommand;
        
        window.voiceController.processCommand = async (transcript, confidence) => {
            if (this.isActive && this.handleProcedureVoiceCommand(transcript)) {
                return; // Command handled by procedure guide
            }
            
            // Fall back to original processing
            return originalProcessCommand.call(window.voiceController, transcript, confidence);
        };
    }
    
    handleProcedureVoiceCommand(transcript) {
        const text = transcript.toLowerCase();
        
        // Step navigation commands
        if (text.includes('next step') || text.includes('continue')) {
            this.nextStep();
            return true;
        }
        
        if (text.includes('previous step') || text.includes('go back')) {
            this.previousStep();
            return true;
        }
        
        if (text.includes('repeat') || text.includes('say again')) {
            this.repeatStep();
            return true;
        }
        
        if (text.includes('complete step') || text.includes('step done')) {
            this.completeCurrentStep();
            return true;
        }
        
        if (text.includes('help') || text.includes('commands')) {
            this.showHelp();
            return true;
        }
        
        if (text.includes('close procedure') || text.includes('exit procedure')) {
            this.closeProcedure();
            return true;
        }
        
        // Step-specific commands
        const currentStep = this.getCurrentStep();
        if (currentStep && currentStep.voice_commands) {
            for (const command of currentStep.voice_commands) {
                if (text.includes(command.toLowerCase())) {
                    this.handleStepCommand(command);
                    return true;
                }
            }
        }
        
        return false; // Command not handled
    }
    
    async startProcedure(procedureId, assetId = null) {
        if (!this.procedures[procedureId]) {
            console.error(`❌ Procedure not found: ${procedureId}`);
            return;
        }
        
        this.currentProcedure = { ...this.procedures[procedureId] };
        this.currentProcedure.id = procedureId;
        this.currentProcedure.assetId = assetId;
        this.currentProcedure.startTime = new Date();
        this.currentStep = 0;
        this.isActive = true;
        
        this.renderProcedure();
        this.overlay.style.display = 'block';
        
        // Welcome message
        this.speak(`Starting ${this.currentProcedure.title}. Estimated time: ${this.currentProcedure.estimated_time}. 
                   Please review safety notes before beginning.`);
        
        console.log(`📋 Started procedure: ${procedureId}`);
    }
    
    renderProcedure() {
        if (!this.currentProcedure) return;
        
        const procedure = this.currentProcedure;
        const currentStepData = procedure.steps[this.currentStep];
        
        this.overlay.innerHTML = `
            <div class="procedure-header">
                <div class="procedure-title">
                    <h3>${procedure.title}</h3>
                    <div class="procedure-meta">
                        ${procedure.assetId ? `Asset: ${procedure.assetId} | ` : ''}
                        Step ${this.currentStep + 1} of ${procedure.steps.length} | 
                        ${procedure.estimated_time}
                    </div>
                </div>
                <div class="procedure-controls">
                    <button id="proc-tts-toggle" class="btn-icon" title="Toggle Text-to-Speech">
                        ${this.ttsEnabled ? '🔊' : '🔇'}
                    </button>
                    <button id="proc-settings" class="btn-icon" title="Settings">⚙️</button>
                    <button id="proc-close" class="btn-icon" title="Close">×</button>
                </div>
            </div>
            
            <div class="procedure-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${((this.currentStep + 1) / procedure.steps.length) * 100}%"></div>
                </div>
                <div class="step-indicator">
                    ${procedure.steps.map((step, index) => `
                        <div class="step-dot ${index < this.currentStep ? 'completed' : index === this.currentStep ? 'current' : ''}">
                            ${index < this.currentStep ? '✓' : index + 1}
                        </div>
                    `).join('')}
                </div>
            </div>
            
            ${this.renderSafetyNotes()}
            ${this.renderCurrentStep()}
            ${this.renderStepNavigation()}
            ${this.renderVoiceHints()}
        `;
        
        this.bindProcedureEvents();
    }
    
    renderSafetyNotes() {
        if (this.currentStep > 0) return ''; // Only show at start
        
        return `
            <div class="safety-panel">
                <h4>⚠️ Safety Requirements</h4>
                <ul>
                    ${this.currentProcedure.safety_notes.map(note => `<li>${note}</li>`).join('')}
                </ul>
                <h4>🔧 Tools Required</h4>
                <ul>
                    ${this.currentProcedure.tools_required.map(tool => `<li>${tool}</li>`).join('')}
                </ul>
                <div class="safety-confirm">
                    <button id="safety-confirmed" class="btn-primary">✓ Safety Confirmed - Begin Procedure</button>
                </div>
            </div>
        `;
    }
    
    renderCurrentStep() {
        const step = this.getCurrentStep();
        if (!step) return '';
        
        const stepTypeIcons = {
            'safety': '⚠️',
            'procedure': '🔧',
            'inspection': '👁️',
            'testing': '📊',
            'documentation': '📝'
        };
        
        return `
            <div class="procedure-step current">
                <div class="step-header">
                    <div class="step-number">${this.currentStep + 1}</div>
                    <div class="step-info">
                        <div class="step-title">
                            ${stepTypeIcons[step.type] || '📋'} ${step.title}
                        </div>
                        <div class="step-meta">
                            ${step.type.toUpperCase()} | ${step.estimated_time}
                        </div>
                    </div>
                </div>
                
                <div class="step-content">
                    <div class="step-description">
                        ${step.description}
                    </div>
                    
                    ${step.checkpoints ? `
                        <div class="step-checkpoints">
                            <h5>Checkpoints:</h5>
                            <div class="checkpoint-list">
                                ${step.checkpoints.map(checkpoint => `
                                    <label class="checkpoint-item">
                                        <input type="checkbox" class="checkpoint-box">
                                        <span>${checkpoint}</span>
                                    </label>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                    
                    <div class="step-actions">
                        <button id="read-step" class="btn-secondary">
                            🔊 Read Step Aloud
                        </button>
                        <button id="take-photo" class="btn-secondary">
                            📷 Take Photo
                        </button>
                        <button id="add-note" class="btn-secondary">
                            📝 Add Note
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
    
    renderStepNavigation() {
        const isFirstStep = this.currentStep === 0;
        const isLastStep = this.currentStep === this.currentProcedure.steps.length - 1;
        
        return `
            <div class="step-navigation">
                <button id="prev-step" class="nav-btn ${isFirstStep ? 'disabled' : ''}" 
                        ${isFirstStep ? 'disabled' : ''}>
                    ← Previous Step
                </button>
                
                <div class="nav-center">
                    <button id="complete-step" class="btn-primary">
                        ✓ Complete Step
                    </button>
                </div>
                
                <button id="next-step" class="nav-btn ${isLastStep ? 'disabled' : ''}"
                        ${isLastStep ? 'disabled' : ''}>
                    ${isLastStep ? 'Finish Procedure' : 'Next Step'} →
                </button>
            </div>
        `;
    }
    
    renderVoiceHints() {
        const step = this.getCurrentStep();
        const commands = step?.voice_commands || ['next step', 'repeat', 'help'];
        
        return `
            <div class="voice-hints">
                <h5>🎤 Voice Commands:</h5>
                <div class="voice-commands">
                    ${commands.map(cmd => `<span class="voice-hint">"${cmd}"</span>`).join('')}
                </div>
            </div>
        `;
    }
    
    bindProcedureEvents() {
        // Safety confirmation
        const safetyBtn = document.getElementById('safety-confirmed');
        if (safetyBtn) {
            safetyBtn.addEventListener('click', () => {
                this.confirmSafety();
            });
        }
        
        // Navigation buttons
        document.getElementById('prev-step')?.addEventListener('click', () => {
            this.previousStep();
        });
        
        document.getElementById('next-step')?.addEventListener('click', () => {
            if (this.currentStep === this.currentProcedure.steps.length - 1) {
                this.completeProcedure();
            } else {
                this.nextStep();
            }
        });
        
        document.getElementById('complete-step')?.addEventListener('click', () => {
            this.completeCurrentStep();
        });
        
        // Step actions
        document.getElementById('read-step')?.addEventListener('click', () => {
            this.readCurrentStep();
        });
        
        document.getElementById('take-photo')?.addEventListener('click', () => {
            this.takePhoto();
        });
        
        document.getElementById('add-note')?.addEventListener('click', () => {
            this.addNote();
        });
        
        // Controls
        document.getElementById('proc-tts-toggle')?.addEventListener('click', () => {
            this.toggleTTS();
        });
        
        document.getElementById('proc-settings')?.addEventListener('click', () => {
            this.showSettings();
        });
        
        document.getElementById('proc-close')?.addEventListener('click', () => {
            this.closeProcedure();
        });
        
        // Checkpoint tracking
        document.querySelectorAll('.checkpoint-box').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updateProgress();
            });
        });
    }
    
    confirmSafety() {
        this.speak('Safety confirmed. Beginning first step.');
        this.currentStep = 0;
        this.renderProcedure();
        this.readCurrentStep();
    }
    
    nextStep() {
        if (this.currentStep < this.currentProcedure.steps.length - 1) {
            this.currentStep++;
            this.renderProcedure();
            this.readCurrentStep();
            this.speak(`Step ${this.currentStep + 1} of ${this.currentProcedure.steps.length}`);
        }
    }
    
    previousStep() {
        if (this.currentStep > 0) {
            this.currentStep--;
            this.renderProcedure();
            this.readCurrentStep();
            this.speak(`Returning to step ${this.currentStep + 1}`);
        }
    }
    
    completeCurrentStep() {
        // Check if all checkpoints are completed
        const checkboxes = document.querySelectorAll('.checkpoint-box');
        const completed = Array.from(checkboxes).every(cb => cb.checked);
        
        if (checkboxes.length > 0 && !completed) {
            this.speak('Please complete all checkpoints before proceeding.');
            return;
        }
        
        this.speak('Step completed. Great work!');
        
        // Auto-advance to next step
        setTimeout(() => {
            if (this.currentStep < this.currentProcedure.steps.length - 1) {
                this.nextStep();
            } else {
                this.completeProcedure();
            }
        }, 1000);
    }
    
    repeatStep() {
        this.readCurrentStep();
    }
    
    readCurrentStep() {
        const step = this.getCurrentStep();
        if (step && step.voice_text) {
            this.speak(step.voice_text);
        }
    }
    
    completeProcedure() {
        const duration = new Date() - this.currentProcedure.startTime;
        const minutes = Math.round(duration / 60000);
        
        this.speak(`Procedure completed successfully in ${minutes} minutes. Great work!`);
        
        // Show completion summary
        this.showCompletionSummary(minutes);
        
        setTimeout(() => {
            this.closeProcedure();
        }, 10000);
    }
    
    showCompletionSummary(duration) {
        const summary = document.createElement('div');
        summary.className = 'completion-summary ar-overlay';
        summary.innerHTML = `
            <div class="ar-header">
                <h4>✅ Procedure Completed</h4>
            </div>
            <div class="ar-content">
                <div class="summary-stats">
                    <div class="stat">
                        <span class="stat-label">Duration:</span>
                        <span class="stat-value">${duration} minutes</span>
                    </div>
                    <div class="stat">
                        <span class="stat-label">Steps:</span>
                        <span class="stat-value">${this.currentProcedure.steps.length}</span>
                    </div>
                    <div class="stat">
                        <span class="stat-label">Asset:</span>
                        <span class="stat-value">${this.currentProcedure.assetId || 'General'}</span>
                    </div>
                </div>
                <div class="completion-actions">
                    <button class="qr-btn primary" onclick="this.parentElement.parentElement.remove()">
                        Close
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(summary);
    }
    
    closeProcedure() {
        this.isActive = false;
        this.currentProcedure = null;
        this.currentStep = 0;
        this.overlay.style.display = 'none';
        
        // Stop any ongoing speech
        if (this.synthesis) {
            this.synthesis.cancel();
        }
        
        this.speak('Procedure guide closed.');
    }
    
    getCurrentStep() {
        if (!this.currentProcedure || this.currentStep >= this.currentProcedure.steps.length) {
            return null;
        }
        return this.currentProcedure.steps[this.currentStep];
    }
    
    handleStepCommand(command) {
        switch(command.toLowerCase()) {
            case 'torque specs':
                this.speak('Standard torque specification is 45 foot pounds for coupling bolts.');
                break;
            case 'bolt pattern':
                this.speak('Remove bolts in cross pattern: top, bottom, left, right. This prevents casing warpage.');
                break;
            case 'take photo':
                this.takePhoto();
                break;
            case 'add note':
                this.addNote();
                break;
            case 'record reading':
                this.recordReading();
                break;
            case 'compare baseline':
                this.compareBaseline();
                break;
            default:
                this.speak('Command not recognized for current step.');
        }
    }
    
    takePhoto() {
        if (window.qrScanner) {
            // Use existing camera functionality
            this.speak('Opening camera for documentation photo.');
            // Could integrate with QR scanner's camera access
        } else {
            this.speak('Camera not available for photo capture.');
        }
    }
    
    addNote() {
        const note = prompt('Enter maintenance note:');
        if (note) {
            this.speak('Note added to procedure record.');
            console.log(`📝 Note added: ${note}`);
        }
    }
    
    recordReading() {
        const reading = prompt('Enter measurement reading:');
        if (reading) {
            this.speak(`Reading of ${reading} recorded.`);
            console.log(`📊 Reading recorded: ${reading}`);
        }
    }
    
    compareBaseline() {
        this.speak('Comparing to baseline readings. Current reading is within acceptable range.');
    }
    
    updateProgress() {
        // Update visual progress based on completed checkpoints
        const checkboxes = document.querySelectorAll('.checkpoint-box');
        const completed = Array.from(checkboxes).filter(cb => cb.checked).length;
        const total = checkboxes.length;
        
        if (completed === total && total > 0) {
            this.speak('All checkpoints completed for this step.');
        }
    }
    
    toggleTTS() {
        this.ttsEnabled = !this.ttsEnabled;
        const btn = document.getElementById('proc-tts-toggle');
        if (btn) {
            btn.textContent = this.ttsEnabled ? '🔊' : '🔇';
        }
        
        this.speak(this.ttsEnabled ? 'Text to speech enabled.' : 'Text to speech disabled.');
    }
    
    showSettings() {
        // Create settings modal for procedure guide
        const modal = document.createElement('div');
        modal.className = 'modal procedure-settings-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Procedure Settings</h3>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body">
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" ${this.ttsEnabled ? 'checked' : ''}> 
                            Enable Text-to-Speech
                        </label>
                    </div>
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" ${this.autoAdvance ? 'checked' : ''}> 
                            Auto-advance steps
                        </label>
                    </div>
                    <div class="setting-group">
                        <label>Speech Rate</label>
                        <input type="range" id="speech-rate" min="0.5" max="2.0" step="0.1" value="1.0">
                        <span>1.0x</span>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
    }
    
    showHelp() {
        const helpText = `Available voice commands: next step, previous step, repeat, complete step, 
                         take photo, add note, help, and close procedure. You can also use keyboard shortcuts: 
                         Control N for next, Control P for previous, Control R for repeat.`;
        this.speak(helpText);
    }
    
    speak(text) {
        if (!this.ttsEnabled || !this.synthesis) return;
        
        // Cancel any ongoing speech
        this.synthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 0.8;
        
        if (this.voice) {
            utterance.voice = this.voice;
        }
        
        this.synthesis.speak(utterance);
    }
    
    // Public API methods
    loadProcedure(procedureId, assetId = null) {
        return this.startProcedure(procedureId, assetId);
    }
    
    getAvailableProcedures() {
        return Object.keys(this.procedures).map(id => ({
            id,
            title: this.procedures[id].title,
            asset_type: this.procedures[id].asset_type,
            estimated_time: this.procedures[id].estimated_time,
            difficulty: this.procedures[id].difficulty
        }));
    }
    
    isRunning() {
        return this.isActive;
    }
    
    getCurrentProgress() {
        if (!this.isActive) return null;
        
        return {
            procedure: this.currentProcedure.title,
            step: this.currentStep + 1,
            total_steps: this.currentProcedure.steps.length,
            progress: ((this.currentStep + 1) / this.currentProcedure.steps.length) * 100
        };
    }
}

// Initialize procedure guide when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.procedureGuide = new ProcedureGuide();
    
    // Integration with voice controller
    if (window.voiceController) {
        window.voiceController.procedureGuide = window.procedureGuide;
    }
});

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProcedureGuide;
}