/**
 * QR/Barcode Scanner for ChatterFix CMMS
 * Smart glasses and mobile optimized scanning
 */

class QRScanner {
    constructor(options = {}) {
        this.options = {
            video: true,
            audio: false,
            facingMode: 'environment', // Use back camera
            width: { ideal: 1280 },
            height: { ideal: 720 },
            ...options
        };
        
        this.isScanning = false;
        this.stream = null;
        this.video = null;
        this.canvas = null;
        this.context = null;
        this.overlay = null;
        this.onResult = null;
        this.onError = null;
        
        // Detection patterns for different codes
        this.patterns = {
            asset_id: /^[A-Z]+-\d+$/,
            work_order: /^WO-\d{8}-\d+$/,
            part_number: /^PN-[A-Z0-9]+$/,
            barcode: /^\d{8,14}$/  // UPC/EAN barcodes
        };
        
        this.init();
    }
    
    init() {
        this.checkSupport();
        this.createUI();
        this.bindEvents();
    }
    
    checkSupport() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.error('❌ Camera access not supported');
            return false;
        }
        
        // Check for QR code detection API
        if ('BarcodeDetector' in window) {
            this.useNativeDetection = true;
            this.barcodeDetector = new BarcodeDetector({
                formats: ['qr_code', 'code_128', 'ean_13', 'ean_8']
            });
            console.log('✅ Using native barcode detection');
        } else {
            this.useNativeDetection = false;
            console.log('⚠️ Using fallback QR detection');
        }
        
        return true;
    }
    
    createUI() {
        // Create QR scanner overlay
        this.overlay = document.createElement('div');
        this.overlay.className = 'qr-scanner-overlay';
        this.overlay.style.display = 'none';
        
        this.overlay.innerHTML = `
            <div class="qr-scanner-header">
                <h3>📷 Scan QR Code / Barcode</h3>
                <p>Point camera at equipment label or QR code</p>
            </div>
            
            <div class="qr-scanner-container">
                <video id="qr-video" autoplay playsinline></video>
                <canvas id="qr-canvas" style="display: none;"></canvas>
                
                <div class="qr-scanner-frame">
                    <div class="qr-scanner-corners"></div>
                    <div class="qr-scanner-line"></div>
                </div>
                
                <div class="qr-result" id="qr-result" style="display: none;">
                    <div class="result-content">
                        <div class="result-icon">✅</div>
                        <div class="result-text" id="result-text"></div>
                        <div class="result-type" id="result-type"></div>
                    </div>
                </div>
            </div>
            
            <div class="qr-scanner-controls">
                <button id="qr-close" class="qr-btn">Cancel</button>
                <button id="qr-flashlight" class="qr-btn" style="display: none;">💡 Flash</button>
                <button id="qr-switch-camera" class="qr-btn" style="display: none;">🔄 Flip</button>
            </div>
            
            <div class="qr-scanner-status">
                <div id="scan-status">Ready to scan</div>
                <div class="scan-tips">
                    <p>💡 Tips:</p>
                    <ul>
                        <li>Hold steady and align code in frame</li>
                        <li>Ensure good lighting</li>
                        <li>Clean camera lens if needed</li>
                    </ul>
                </div>
            </div>
        `;
        
        document.body.appendChild(this.overlay);
        
        this.video = document.getElementById('qr-video');
        this.canvas = document.getElementById('qr-canvas');
        this.context = this.canvas.getContext('2d');
        
        // Add floating scan button
        this.createFloatingScanButton();
    }
    
    createFloatingScanButton() {
        const scanButton = document.createElement('button');
        scanButton.id = 'floating-scan-btn';
        scanButton.className = 'floating-scan-btn';
        scanButton.innerHTML = '📷';
        scanButton.title = 'Scan QR Code';
        
        scanButton.style.cssText = `
            position: fixed;
            bottom: 140px;
            right: 20px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%);
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 16px rgba(33, 150, 243, 0.3);
            z-index: 998;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        `;
        
        scanButton.addEventListener('mouseenter', () => {
            scanButton.style.transform = 'scale(1.1)';
            scanButton.style.boxShadow = '0 6px 20px rgba(33, 150, 243, 0.4)';
        });
        
        scanButton.addEventListener('mouseleave', () => {
            scanButton.style.transform = 'scale(1)';
            scanButton.style.boxShadow = '0 4px 16px rgba(33, 150, 243, 0.3)';
        });
        
        document.body.appendChild(scanButton);
        
        scanButton.addEventListener('click', () => this.startScanning());
    }
    
    bindEvents() {
        // Close scanner
        document.getElementById('qr-close').addEventListener('click', () => {
            this.stopScanning();
        });
        
        // Flashlight toggle (if supported)
        document.getElementById('qr-flashlight').addEventListener('click', () => {
            this.toggleFlashlight();
        });
        
        // Camera switch (if multiple cameras)
        document.getElementById('qr-switch-camera').addEventListener('click', () => {
            this.switchCamera();
        });
        
        // Close on overlay click
        this.overlay.addEventListener('click', (e) => {
            if (e.target === this.overlay) {
                this.stopScanning();
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (this.isScanning) {
                if (e.key === 'Escape') {
                    this.stopScanning();
                } else if (e.key === ' ') {
                    e.preventDefault();
                    // Manual capture could be added here
                }
            }
        });
    }
    
    async startScanning(callback) {
        if (this.isScanning) return;
        
        this.onResult = callback;
        this.isScanning = true;
        
        try {
            // Show overlay
            this.overlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            
            // Get camera stream
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: this.options.facingMode,
                    width: this.options.width,
                    height: this.options.height
                }
            });
            
            this.video.srcObject = this.stream;
            await this.video.play();
            
            // Setup canvas
            this.canvas.width = this.video.videoWidth;
            this.canvas.height = this.video.videoHeight;
            
            // Check for flashlight support
            const track = this.stream.getVideoTracks()[0];
            const capabilities = track.getCapabilities();
            if (capabilities.torch) {
                document.getElementById('qr-flashlight').style.display = 'block';
            }
            
            // Start detection loop
            this.updateStatus('Scanning... Point camera at code');
            this.detectCodes();
            
            console.log('📷 QR Scanner started');
            
        } catch (error) {
            console.error('Camera access failed:', error);
            this.updateStatus('Camera access denied or failed');
            
            if (this.onError) {
                this.onError(error);
            } else {
                alert('Camera access is required for scanning. Please allow camera permission.');
            }
            
            this.stopScanning();
        }
    }
    
    stopScanning() {
        if (!this.isScanning) return;
        
        this.isScanning = false;
        
        // Stop camera stream
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        // Hide overlay
        this.overlay.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        // Clear video
        if (this.video) {
            this.video.srcObject = null;
        }
        
        // Hide result
        document.getElementById('qr-result').style.display = 'none';
        
        console.log('📷 QR Scanner stopped');
    }
    
    async detectCodes() {
        if (!this.isScanning || !this.video.videoWidth) {
            requestAnimationFrame(() => this.detectCodes());
            return;
        }
        
        try {
            let detectedCodes = [];
            
            if (this.useNativeDetection) {
                // Use native BarcodeDetector API
                detectedCodes = await this.barcodeDetector.detect(this.video);
            } else {
                // Use fallback detection
                detectedCodes = await this.fallbackDetection();
            }
            
            if (detectedCodes.length > 0) {
                const code = detectedCodes[0];
                await this.handleDetectedCode(code);
            } else {
                // Continue scanning
                requestAnimationFrame(() => this.detectCodes());
            }
            
        } catch (error) {
            console.error('Code detection error:', error);
            requestAnimationFrame(() => this.detectCodes());
        }
    }
    
    async fallbackDetection() {
        // Draw video frame to canvas for analysis
        this.context.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
        
        // In a real implementation, you would use a QR code library here
        // For demo purposes, we'll simulate detection
        
        // Check if we can find QR-like patterns in the image
        const imageData = this.context.getImageData(0, 0, this.canvas.width, this.canvas.height);
        
        // Simple pattern detection (mock)
        // In reality, use libraries like jsQR, qr-scanner, or ZXing
        if (Math.random() < 0.1) { // 10% chance to simulate detection
            return [{
                rawValue: 'PUMP-001', // Mock detected value
                format: 'qr_code',
                boundingBox: { x: 100, y: 100, width: 200, height: 200 }
            }];
        }
        
        return [];
    }
    
    async handleDetectedCode(code) {
        const value = code.rawValue || code.data;
        const type = this.identifyCodeType(value);
        
        console.log(`📷 Detected ${type}: ${value}`);
        
        // Show result
        this.showResult(value, type);
        
        // Process the code
        await this.processCode(value, type);
        
        // Auto-close after showing result
        setTimeout(() => {
            this.stopScanning();
        }, 2000);
    }
    
    identifyCodeType(value) {
        for (const [type, pattern] of Object.entries(this.patterns)) {
            if (pattern.test(value)) {
                return type;
            }
        }
        return 'unknown';
    }
    
    showResult(value, type) {
        const resultElement = document.getElementById('qr-result');
        const textElement = document.getElementById('result-text');
        const typeElement = document.getElementById('result-type');
        
        textElement.textContent = value;
        typeElement.textContent = type.replace('_', ' ').toUpperCase();
        
        resultElement.style.display = 'flex';
        
        // Add success animation
        resultElement.classList.add('result-success');
        setTimeout(() => {
            resultElement.classList.remove('result-success');
        }, 1000);
    }
    
    async processCode(value, type) {
        try {
            let response;
            
            switch (type) {
                case 'asset_id':
                    response = await this.loadAssetInfo(value);
                    break;
                case 'work_order':
                    response = await this.loadWorkOrderInfo(value);
                    break;
                case 'part_number':
                    response = await this.loadPartInfo(value);
                    break;
                default:
                    response = await this.searchGeneric(value);
            }
            
            if (this.onResult) {
                this.onResult({ value, type, data: response });
            } else {
                this.displayCodeInfo(value, type, response);
            }
            
        } catch (error) {
            console.error('Code processing error:', error);
            this.updateStatus('Error processing code');
        }
    }
    
    async loadAssetInfo(assetId) {
        // Mock asset lookup - in production, call actual API
        const response = await fetch(`/api/assets/${assetId}`).catch(() => null);
        
        if (response && response.ok) {
            return await response.json();
        } else {
            // Mock data for demo
            return {
                id: assetId,
                name: `Equipment ${assetId}`,
                status: 'operational',
                location: 'Building A, Room 101',
                last_maintenance: '2024-08-15',
                procedures: [
                    'Daily inspection checklist',
                    'Weekly lubrication',
                    'Monthly calibration'
                ]
            };
        }
    }
    
    async loadWorkOrderInfo(workOrderId) {
        // Mock work order lookup
        return {
            id: workOrderId,
            title: 'Routine Maintenance',
            status: 'open',
            priority: 'medium',
            assigned_to: 'John Smith',
            due_date: '2024-12-15'
        };
    }
    
    async loadPartInfo(partNumber) {
        // Mock parts lookup
        return {
            number: partNumber,
            name: 'Pump Seal Kit',
            stock: 5,
            location: 'A-1-3',
            cost: 89.99
        };
    }
    
    async searchGeneric(value) {
        // Generic search for unknown codes
        return {
            query: value,
            results: [],
            suggestions: ['Check asset database', 'Search parts catalog']
        };
    }
    
    displayCodeInfo(value, type, data) {
        // Create info overlay for scanned code
        const infoOverlay = document.createElement('div');
        infoOverlay.className = 'ar-overlay code-info-overlay';
        
        let content = `
            <div class="ar-header">
                <h4>📷 Scanned: ${type.replace('_', ' ').toUpperCase()}</h4>
                <button class="ar-close">×</button>
            </div>
            <div class="ar-content">
                <div class="code-value">${value}</div>
        `;
        
        if (type === 'asset_id' && data) {
            content += `
                <div class="asset-info">
                    <h5>Asset Information</h5>
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Status:</strong> ${data.status}</p>
                    <p><strong>Location:</strong> ${data.location}</p>
                    <p><strong>Last Maintenance:</strong> ${data.last_maintenance}</p>
                </div>
                <div class="asset-procedures">
                    <h5>Procedures Available</h5>
                    ${data.procedures.map(proc => `<div class="procedure-item">${proc}</div>`).join('')}
                </div>
            `;
        }
        
        content += `
            </div>
            <div class="code-actions">
                <button class="qr-btn primary" onclick="window.voiceController.speak('Asset ${value} loaded. What would you like to do?')">
                    🎤 Voice Commands
                </button>
                <button class="qr-btn" onclick="this.parentElement.parentElement.remove()">
                    Close
                </button>
            </div>
        `;
        
        infoOverlay.innerHTML = content;
        
        // Bind close button
        infoOverlay.querySelector('.ar-close').addEventListener('click', () => {
            infoOverlay.remove();
        });
        
        document.body.appendChild(infoOverlay);
        
        // Auto-remove after 30 seconds
        setTimeout(() => {
            if (infoOverlay.parentElement) {
                infoOverlay.remove();
            }
        }, 30000);
    }
    
    updateStatus(message) {
        const statusElement = document.getElementById('scan-status');
        if (statusElement) {
            statusElement.textContent = message;
        }
    }
    
    async toggleFlashlight() {
        if (!this.stream) return;
        
        const track = this.stream.getVideoTracks()[0];
        const capabilities = track.getCapabilities();
        
        if (capabilities.torch) {
            try {
                const settings = track.getSettings();
                await track.applyConstraints({
                    advanced: [{ torch: !settings.torch }]
                });
                
                const flashButton = document.getElementById('qr-flashlight');
                flashButton.textContent = settings.torch ? '💡 Flash' : '🔦 Flash ON';
                
            } catch (error) {
                console.error('Flashlight toggle failed:', error);
            }
        }
    }
    
    async switchCamera() {
        // Switch between front and back camera
        this.options.facingMode = this.options.facingMode === 'environment' ? 'user' : 'environment';
        
        if (this.isScanning) {
            this.stopScanning();
            setTimeout(() => {
                this.startScanning(this.onResult);
            }, 500);
        }
    }
    
    // Public API methods
    scan(callback) {
        return this.startScanning(callback);
    }
    
    stop() {
        this.stopScanning();
    }
    
    isActive() {
        return this.isScanning;
    }
}

// Initialize QR scanner when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.qrScanner = new QRScanner();
    
    // Add to voice controller for integration
    if (window.voiceController) {
        window.voiceController.qrScanner = window.qrScanner;
    }
});

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = QRScanner;
}