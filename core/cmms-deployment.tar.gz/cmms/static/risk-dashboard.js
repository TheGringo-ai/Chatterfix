/**
 * Risk Dashboard Component for ChatterFix CMMS
 * Displays top at-risk assets with predictive maintenance insights
 */

class RiskDashboard {
    constructor(containerId = 'risk-dashboard-container') {
        this.containerId = containerId;
        this.refreshInterval = 60000; // 1 minute refresh
        this.autoRefreshTimer = null;
        this.currentData = null;
        
        this.init();
    }
    
    init() {
        this.createUI();
        this.loadRiskData();
        this.startAutoRefresh();
        
        console.log('🔮 Risk Dashboard initialized');
    }
    
    createUI() {
        const container = document.getElementById(this.containerId) || this.createContainer();
        
        container.innerHTML = `
            <div class="risk-dashboard">
                <div class="dashboard-header">
                    <h2 class="dashboard-title">
                        <span class="risk-icon">⚠️</span>
                        Predictive Maintenance Dashboard
                    </h2>
                    <div class="dashboard-controls">
                        <button id="refresh-dashboard" class="refresh-btn">
                            <span class="refresh-icon">🔄</span>
                            Refresh
                        </button>
                        <div class="last-updated" id="last-updated">
                            Loading...
                        </div>
                    </div>
                </div>
                
                <div class="risk-summary" id="risk-summary">
                    <div class="summary-card critical">
                        <div class="card-number" id="critical-count">-</div>
                        <div class="card-label">Critical</div>
                    </div>
                    <div class="summary-card high">
                        <div class="card-number" id="high-count">-</div>
                        <div class="card-label">High Risk</div>
                    </div>
                    <div class="summary-card medium">
                        <div class="card-number" id="medium-count">-</div>
                        <div class="card-label">Medium Risk</div>
                    </div>
                    <div class="summary-card low">
                        <div class="card-number" id="low-count">-</div>
                        <div class="card-label">Low Risk</div>
                    </div>
                </div>
                
                <div class="assets-table-container">
                    <table class="risk-assets-table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Asset ID</th>
                                <th>Risk Score</th>
                                <th>Risk Level</th>
                                <th>Primary Risk Factor</th>
                                <th>Next Check</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="assets-table-body">
                            <tr>
                                <td colspan="7" class="loading-row">
                                    <div class="loading-spinner">Loading risk data...</div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="dashboard-footer">
                    <div class="system-info">
                        <span class="info-badge baseline">Baseline Statistical Model</span>
                        <span class="info-badge upgrade">ML Upgrade Available</span>
                    </div>
                </div>
            </div>
        `;
        
        this.setupEventListeners();
    }
    
    createContainer() {
        const container = document.createElement('div');
        container.id = this.containerId;
        container.style.cssText = `
            width: 100%;
            min-height: 600px;
            margin: 20px 0;
        `;
        document.body.appendChild(container);
        return container;
    }
    
    setupEventListeners() {
        const refreshBtn = document.getElementById('refresh-dashboard');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadRiskData();
            });
        }
    }
    
    async loadRiskData() {
        try {
            this.showLoading();
            
            // Fetch top risk assets from API
            const response = await fetch('/ai/predict/top-risk?limit=20');
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            this.currentData = data;
            
            this.updateSummaryCards(data.risk_summary);
            this.updateAssetsTable(data.top_risk_assets);
            this.updateLastUpdated(data.generated_at);
            
            console.log('✅ Risk dashboard data loaded successfully');
            
        } catch (error) {
            console.error('❌ Failed to load risk dashboard data:', error);
            this.showError(error.message);
        }
    }
    
    showLoading() {
        const tableBody = document.getElementById('assets-table-body');
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="loading-row">
                        <div class="loading-spinner">
                            <div class="spinner"></div>
                            Loading risk predictions...
                        </div>
                    </td>
                </tr>
            `;
        }
    }
    
    showError(message) {
        const tableBody = document.getElementById('assets-table-body');
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="error-row">
                        <div class="error-message">
                            ❌ Error: ${message}
                            <button onclick="riskDashboard.loadRiskData()" class="retry-btn">Retry</button>
                        </div>
                    </td>
                </tr>
            `;
        }
    }
    
    updateSummaryCards(riskSummary) {
        // Update risk summary cards
        const counts = {
            'critical-count': riskSummary.critical || 0,
            'high-count': riskSummary.high || 0,
            'medium-count': riskSummary.medium || 0,
            'low-count': riskSummary.low || 0
        };
        
        Object.entries(counts).forEach(([elementId, count]) => {
            const element = document.getElementById(elementId);
            if (element) {
                element.textContent = count;
                
                // Add animation for changes
                element.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    element.style.transform = 'scale(1)';
                }, 200);
            }
        });
    }
    
    updateAssetsTable(assets) {
        const tableBody = document.getElementById('assets-table-body');
        if (!tableBody) return;
        
        if (!assets || assets.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="no-data-row">
                        No high-risk assets found
                    </td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = assets.map((asset, index) => {
            const primaryReason = asset.reasons && asset.reasons.length > 0 ? 
                                 asset.reasons[0] : { description: 'No specific risk factors identified' };
            
            const nextCheck = new Date(asset.next_check_date).toLocaleDateString();
            const riskClass = this.getRiskClass(asset.risk_level);
            const riskColor = this.getRiskColor(asset.risk_score);
            
            return `
                <tr class="asset-row ${riskClass}" data-asset-id="${asset.asset_id}">
                    <td class="rank-cell">${index + 1}</td>
                    <td class="asset-id-cell">
                        <strong>${asset.asset_id}</strong>
                    </td>
                    <td class="risk-score-cell">
                        <div class="risk-score-bar">
                            <div class="score-value" style="color: ${riskColor}">
                                ${(asset.risk_score * 100).toFixed(0)}%
                            </div>
                            <div class="score-bar">
                                <div class="score-fill" style="width: ${asset.risk_score * 100}%; background-color: ${riskColor}"></div>
                            </div>
                        </div>
                    </td>
                    <td class="risk-level-cell">
                        <span class="risk-badge ${asset.risk_level}">
                            ${asset.risk_level.charAt(0).toUpperCase() + asset.risk_level.slice(1)}
                        </span>
                    </td>
                    <td class="primary-reason-cell" title="${primaryReason.description}">
                        ${this.truncateText(primaryReason.description, 50)}
                    </td>
                    <td class="next-check-cell">
                        ${nextCheck}
                    </td>
                    <td class="actions-cell">
                        <button class="action-btn detail-btn" onclick="riskDashboard.showAssetDetail('${asset.asset_id}')">
                            Details
                        </button>
                        <button class="action-btn schedule-btn" onclick="riskDashboard.scheduleCheck('${asset.asset_id}')">
                            Schedule
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        
        // Add click handlers for rows
        tableBody.querySelectorAll('.asset-row').forEach(row => {
            row.addEventListener('click', (e) => {
                if (!e.target.closest('button')) {
                    const assetId = row.dataset.assetId;
                    this.showAssetDetail(assetId);
                }
            });
        });
    }
    
    updateLastUpdated(timestamp) {
        const lastUpdatedElement = document.getElementById('last-updated');
        if (lastUpdatedElement) {
            const updateTime = new Date(timestamp).toLocaleString();
            lastUpdatedElement.textContent = `Last updated: ${updateTime}`;
        }
    }
    
    getRiskClass(riskLevel) {
        return `risk-${riskLevel}`;
    }
    
    getRiskColor(riskScore) {
        if (riskScore >= 0.8) return '#e74c3c';      // Critical - red
        if (riskScore >= 0.6) return '#f39c12';      // High - orange  
        if (riskScore >= 0.3) return '#f1c40f';      // Medium - yellow
        return '#27ae60';                             // Low - green
    }
    
    truncateText(text, maxLength) {
        if (!text) return 'N/A';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }
    
    async showAssetDetail(assetId) {
        try {
            // Fetch detailed asset prediction
            const response = await fetch(`/ai/predict/asset/${assetId}`);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const assetData = await response.json();
            
            // Create modal with detailed information
            this.showAssetModal(assetData);
            
        } catch (error) {
            console.error(`Failed to load details for asset ${assetId}:`, error);
            alert(`Failed to load asset details: ${error.message}`);
        }
    }
    
    showAssetModal(assetData) {
        const modal = document.createElement('div');
        modal.className = 'asset-detail-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Asset Risk Analysis: ${assetData.asset_id}</h3>
                    <button class="close-modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="risk-overview">
                        <div class="risk-score-large">
                            <div class="score-circle" style="background: conic-gradient(${this.getRiskColor(assetData.risk_score)} ${assetData.risk_score * 360}deg, #eee 0deg)">
                                <span class="score-text">${(assetData.risk_score * 100).toFixed(0)}%</span>
                            </div>
                            <div class="risk-level-large ${assetData.risk_level}">
                                ${assetData.risk_level.toUpperCase()} RISK
                            </div>
                        </div>
                        <div class="risk-details">
                            <p><strong>Confidence:</strong> ${(assetData.confidence * 100).toFixed(0)}%</p>
                            <p><strong>Data Quality:</strong> ${(assetData.data_quality * 100).toFixed(0)}%</p>
                            <p><strong>Next Check:</strong> ${new Date(assetData.next_check_date).toLocaleDateString()}</p>
                        </div>
                    </div>
                    
                    <div class="risk-reasons">
                        <h4>Risk Factors</h4>
                        ${assetData.reasons.map((reason, index) => `
                            <div class="reason-item">
                                <div class="reason-header">
                                    <span class="reason-code">${reason.code.replace('_', ' ').toUpperCase()}</span>
                                    <span class="reason-weight">${(reason.weight * 100).toFixed(0)}%</span>
                                </div>
                                <p class="reason-description">${reason.description}</p>
                            </div>
                        `).join('')}
                    </div>
                    
                    <div class="upgrade-recommendations">
                        <h4>Recommendations</h4>
                        <ul>
                            ${assetData.upgrade_recommendations.map(rec => `<li>${rec}</li>`).join('')}
                        </ul>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn secondary close-modal">Close</button>
                    <button class="btn primary" onclick="riskDashboard.scheduleCheck('${assetData.asset_id}')">Schedule Maintenance</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add close handlers
        modal.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                document.body.removeChild(modal);
            });
        });
        
        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        });
    }
    
    scheduleCheck(assetId) {
        // Placeholder for maintenance scheduling
        alert(`Scheduling maintenance check for ${assetId}...\\n\\nThis would integrate with the work order system to create a preventive maintenance task.`);
    }
    
    startAutoRefresh() {
        this.autoRefreshTimer = setInterval(() => {
            this.loadRiskData();
        }, this.refreshInterval);
    }
    
    stopAutoRefresh() {
        if (this.autoRefreshTimer) {
            clearInterval(this.autoRefreshTimer);
            this.autoRefreshTimer = null;
        }
    }
    
    // Public API methods
    refresh() {
        this.loadRiskData();
    }
    
    setRefreshInterval(milliseconds) {
        this.refreshInterval = milliseconds;
        this.stopAutoRefresh();
        this.startAutoRefresh();
    }
    
    destroy() {
        this.stopAutoRefresh();
        const container = document.getElementById(this.containerId);
        if (container) {
            container.innerHTML = '';
        }
    }
}

// Initialize risk dashboard when DOM is ready
let riskDashboard;

document.addEventListener('DOMContentLoaded', () => {
    // Create risk dashboard
    riskDashboard = new RiskDashboard();
    
    // Make it globally accessible
    window.riskDashboard = riskDashboard;
});

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RiskDashboard;
}