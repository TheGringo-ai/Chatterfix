#!/usr/bin/env python3
"""
Simple test for AIOps components without running the full app
"""

import asyncio
import time
import subprocess
from datetime import datetime
from pathlib import Path

# Test imports
try:
    from aiops_monitor import aiops_monitor, LogEvent
    from aiops_playbooks import playbook_registry
    print("✅ AIOps modules imported successfully")
except ImportError as e:
    print(f"❌ Failed to import AIOps modules: {e}")
    exit(1)

async def test_incident_detection():
    """Test incident detection from log events"""
    print("\n🧪 Testing incident detection...")
    
    # Create test log events
    test_events = [
        LogEvent(
            timestamp=datetime.now(),
            level="ERROR",
            source="app",
            message="Application crashed with exception: Traceback (most recent call last)",
            request_id="req_12345"
        ),
        LogEvent(
            timestamp=datetime.now(),
            level="ERROR", 
            source="nginx",
            message='127.0.0.1 - - "GET /api/test HTTP/1.1" 500 1234',
            response_code=500,
            response_time_ms=250
        ),
        LogEvent(
            timestamp=datetime.now(),
            level="WARNING",
            source="app", 
            message="Response took 3500ms - slow database query",
            response_time_ms=3500
        )
    ]
    
    # Analyze events for incidents
    incidents = aiops_monitor.analyze_log_events(test_events)
    
    print(f"   ✅ Detected {len(incidents)} incidents from {len(test_events)} log events")
    
    for incident in incidents:
        print(f"   📋 {incident.incident_type.value}: {incident.title}")
        print(f"      Request ID: {incident.request_id}")
        print(f"      Severity: {incident.severity.value}")
        print(f"      Root cause: {incident.root_cause}")
    
    return len(incidents) > 0

async def test_playbook_execution():
    """Test playbook execution"""
    print("\n🧪 Testing playbook execution...")
    
    # List available playbooks
    playbooks = playbook_registry.get_playbook_list()
    print(f"   ✅ Found {len(playbooks)} available playbooks:")
    for pb in playbooks:
        print(f"      - {pb['name']}: {pb['description']} ({pb['steps']} steps)")
    
    # Test system health check playbook
    print(f"\n   🔧 Executing system_health_check playbook...")
    execution = await playbook_registry.execute_playbook(
        "system_health_check",
        {"test_mode": True}
    )
    
    print(f"   📊 Execution result: {execution.status.value}")
    print(f"   📝 Steps completed: {execution.steps_completed}/{execution.total_steps}")
    
    if execution.output_log:
        print(f"   📋 Sample output:")
        for log_entry in execution.output_log[:3]:
            print(f"      {log_entry}")
    
    if execution.error_message:
        print(f"   ❌ Error: {execution.error_message}")
    
    return execution.steps_completed > 0

async def test_log_file_processing():
    """Test log file processing"""
    print("\n🧪 Testing log file processing...")
    
    # Create a temporary log file with test data
    test_log_file = "/tmp/test_chatterfix.log"
    
    test_log_content = f"""
{datetime.now().isoformat()} INFO Application starting up...
{datetime.now().isoformat()} ERROR Process crashed with SIGTERM
{datetime.now().isoformat()} WARNING High response time detected: 2500ms
{datetime.now().isoformat()} ERROR HTTP/1.1 500 Internal Server Error
{datetime.now().isoformat()} CRITICAL System out of memory
"""
    
    with open(test_log_file, 'w') as f:
        f.write(test_log_content)
    
    print(f"   ✅ Created test log file: {test_log_file}")
    
    # Process the log file
    incidents = aiops_monitor.process_log_file(test_log_file, "test_app")
    
    print(f"   📊 Detected {len(incidents)} incidents from log file")
    
    for incident in incidents:
        print(f"   🚨 {incident.incident_type.value}: {incident.title}")
        print(f"      Count: {incident.count}, Severity: {incident.severity.value}")
    
    # Clean up
    Path(test_log_file).unlink(missing_ok=True)
    
    return len(incidents) > 0

async def test_daily_summary():
    """Test daily summary generation"""
    print("\n🧪 Testing daily summary generation...")
    
    # Create some mock incidents
    from aiops_monitor import Incident, IncidentType, IncidentSeverity
    
    mock_incidents = [
        Incident(
            incident_id="test_001",
            request_id="req_test_001",
            incident_type=IncidentType.APP_CRASH,
            severity=IncidentSeverity.CRITICAL,
            title="Test app crash",
            description="Simulated app crash for testing",
            first_seen=datetime.now(),
            last_seen=datetime.now(),
            count=1,
            affected_components=["main_app"],
            root_cause="Test scenario",
            remediation_taken=["restart_app playbook"]
        )
    ]
    
    # Save summary
    summary_file = aiops_monitor.save_incident_summary(datetime.now(), mock_incidents)
    
    if summary_file:
        print(f"   ✅ Generated summary file: {summary_file}")
        
        # Test retrieval
        summary = aiops_monitor.get_daily_summary()
        print(f"   📊 Summary contains {summary['total_incidents']} incidents")
        
        return True
    else:
        print("   ❌ Failed to generate summary file")
        return False

async def test_auto_restart_playbook():
    """Test the app restart playbook"""
    print("\n🧪 Testing app restart playbook...")
    
    execution = await playbook_registry.execute_playbook(
        "restart_app",
        {"test_mode": True}
    )
    
    print(f"   📊 Restart execution: {execution.status.value}")
    print(f"   📝 Steps completed: {execution.steps_completed}/{execution.total_steps}")
    
    # Check if we got expected steps
    expected_steps = ["check app process", "stop app", "start app", "verify"]
    actual_output = " ".join(execution.output_log).lower()
    
    steps_found = sum(1 for step in expected_steps if any(word in actual_output for word in step.split()))
    print(f"   ✅ Found {steps_found}/{len(expected_steps)} expected restart steps")
    
    return execution.steps_completed >= 3  # At least 3 steps should complete

async def main():
    """Run all tests"""
    print("🤖 AIOps Self-Healing System - Standalone Tests")
    print("=" * 55)
    
    tests = [
        ("Incident Detection", test_incident_detection),
        ("Playbook Execution", test_playbook_execution),
        ("Log File Processing", test_log_file_processing),
        ("Daily Summary", test_daily_summary),
        ("Auto-Restart Playbook", test_auto_restart_playbook)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            print(f"\n📋 Running: {test_name}")
            result = await test_func()
            results.append((test_name, result))
            print(f"   {'✅ PASS' if result else '❌ FAIL'}")
        except Exception as e:
            print(f"   💥 Test crashed: {e}")
            results.append((test_name, False))
        
        await asyncio.sleep(0.5)  # Brief pause between tests
    
    # Print summary
    print("\n" + "=" * 55)
    print("📊 Test Results Summary:")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status} {test_name}")
    
    print(f"\n🎯 Overall: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("🎉 All tests passed! AIOps core components working correctly.")
    elif passed >= total * 0.8:
        print("⚠️  Most tests passed. Minor issues detected.")
    else:
        print("🚨 Multiple test failures. Core components may need fixes.")
    
    # Show acceptance criteria status
    print(f"\n✅ Acceptance Criteria:")
    print(f"   - Incident detection from logs: {'✅' if any('Detection' in name and result for name, result in results) else '❌'}")
    print(f"   - Self-healing playbooks: {'✅' if any('Playbook' in name and result for name, result in results) else '❌'}")
    print(f"   - Daily summaries: {'✅' if any('Summary' in name and result for name, result in results) else '❌'}")
    print(f"   - Auto-restart capability: {'✅' if any('Restart' in name and result for name, result in results) else '❌'}")
    
    return passed >= total * 0.8

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)