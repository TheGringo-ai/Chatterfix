#!/usr/bin/env python3
"""
Simple test route to verify emoji encoding
"""
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI()

@app.get("/test-emoji", response_class=HTMLResponse)
async def test_emoji():
    """Test emoji encoding in HTML response"""
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emoji Test</title>
</head>
<body>
    <h1>📋 ChatterFix Work Orders</h1>
    <h2>📊 Work Order Overview</h2>
    <h3>⚡ Quick Actions</h3>
    <h4>📈 Performance Metrics</h4>
    <p>✅ Success!</p>
</body>
</html>"""
    return HTMLResponse(content=html, media_type="text/html; charset=utf-8")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9000)