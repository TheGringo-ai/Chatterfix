#!/usr/bin/env python3
"""
Test Grok Integration with ChatterFix CMMS
Demonstrates direct Grok API integration for development assistance
"""

import asyncio
import os
import sys
from ai_model_provider import CentralizedAIProvider, AIConfig, AIProvider

async def test_grok_integration():
    """Test Grok integration for ChatterFix development"""
    
    print("🚀 Testing Grok Integration with ChatterFix CMMS")
    print("=" * 60)
    
    # Configure Grok
    config = AIConfig()
    config.grok_api_key = os.getenv("XAI_API_KEY", "")
    config.grok_model = "grok-2-1212"
    config.provider_priority = ["grok", "fallback"]
    
    ai_provider = CentralizedAIProvider(config)
    
    # Test cases for CMMS development
    test_cases = [
        {
            "name": "🔧 CMMS Feature Development", 
            "task": "Create a Python function to calculate equipment downtime cost based on hourly rate and duration",
            "context": "coding"
        },
        {
            "name": "🤖 AI Enhancement", 
            "task": "Design an algorithm to predict equipment failure based on sensor data patterns", 
            "context": "analysis"
        },
        {
            "name": "📊 Dashboard Component", 
            "task": "Write JavaScript code for a real-time maintenance status dashboard widget",
            "context": "coding"
        },
        {
            "name": "🔍 Troubleshooting Logic", 
            "task": "Create a decision tree for diagnosing HVAC system failures",
            "context": "analysis"
        }
    ]
    
    results = []
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. {test_case['name']}")
        print(f"Task: {test_case['task']}")
        print("-" * 50)
        
        try:
            response = await ai_provider.generate(
                message=test_case['task'],
                context=test_case['context'],
                system_prompt="You are an expert software engineer helping develop a CMMS (Computerized Maintenance Management System). Provide practical, production-ready code with proper error handling.",
                max_tokens=1000,
                temperature=0.2
            )
            
            print(f"✅ Provider: {response.provider.value}")
            print(f"✅ Model: {response.model}")
            print(f"✅ Response Time: {response.response_time_ms}ms")
            print(f"✅ Confidence: {response.confidence}")
            print(f"\n🎯 Response:\n{response.content[:500]}...")
            
            results.append({
                "test": test_case['name'],
                "success": True,
                "provider": response.provider.value,
                "model": response.model,
                "response_time": response.response_time_ms,
                "confidence": response.confidence
            })
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            results.append({
                "test": test_case['name'],
                "success": False,
                "error": str(e)
            })
    
    # Summary
    print("\n" + "=" * 60)
    print("🏁 GROK INTEGRATION TEST SUMMARY")
    print("=" * 60)
    
    successful_tests = [r for r in results if r['success']]
    failed_tests = [r for r in results if not r['success']]
    
    print(f"✅ Successful Tests: {len(successful_tests)}/{len(results)}")
    print(f"❌ Failed Tests: {len(failed_tests)}/{len(results)}")
    
    if successful_tests:
        avg_response_time = sum(r['response_time'] for r in successful_tests) / len(successful_tests)
        avg_confidence = sum(r['confidence'] for r in successful_tests) / len(successful_tests)
        providers_used = list(set(r['provider'] for r in successful_tests))
        
        print(f"⚡ Average Response Time: {avg_response_time:.0f}ms")
        print(f"🎯 Average Confidence: {avg_confidence:.2f}")
        print(f"🤖 Providers Used: {', '.join(providers_used)}")
    
    print("\n🎉 Grok is ready to help develop ChatterFix CMMS!")
    print("💡 You can now use Grok for:")
    print("   • Fast code generation and debugging")
    print("   • Architecture planning and design")
    print("   • Algorithm optimization")
    print("   • Database schema design") 
    print("   • API endpoint development")
    print("   • Testing strategy")
    
    return results

if __name__ == "__main__":
    results = asyncio.run(test_grok_integration())