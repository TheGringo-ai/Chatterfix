from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import JSONResponse
import json

app = FastAPI(title="ChatterFix CMMS Test")

@app.get("/")
async def root():
    return {"message": "ChatterFix CMMS Test Server", "status": "running"}

@app.get("/api")
async def api_overview():
    return {
        "service": "ChatterFix CMMS API",
        "version": "3.0.0-test",
        "total_routes": 8,
        "endpoints": [
            "/",
            "/api", 
            "/health",
            "/cmms/dashboard",
            "/cmms/workorders",
            "/cmms/assets",
            "/cmms/parts"
        ]
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": "2025-09-13T23:06:00Z"}

@app.get("/cmms/dashboard")
async def dashboard():
    return {
        "active_work_orders": 12,
        "assets_monitored": 45,
        "critical_alerts": 2,
        "system_health": "good",
        "technicians_online": 8,
        "parts_inventory": 156
    }

@app.get("/cmms/workorders")
async def workorders():
    return {
        "total": 23,
        "active": 12,
        "completed": 11,
        "overdue": 2
    }

@app.get("/cmms/assets")
async def assets():
    return {
        "total": 45,
        "critical": 2,
        "maintenance_due": 5,
        "operational": 38
    }

@app.get("/cmms/parts")
async def parts():
    return {
        "total_parts": 156,
        "low_stock": 8,
        "out_of_stock": 2,
        "total_value": 24500
    }

# Missing Dashboard Endpoints
@app.get("/cmms/dashboard/main")
async def dashboard_main():
    return {
        "active_work_orders": 12,
        "assets_monitored": 45,
        "critical_alerts": 2,
        "system_health": "good",
        "technicians_online": 8,
        "parts_inventory": 156,
        "mttr_hours": 3.2,
        "mtbf_days": 47,
        "pm_compliance_pct": 92.4
    }

@app.get("/cmms/kpis")
async def kpis():
    return {
        "mttr_hours": 3.2,
        "mtbf_days": 47,
        "pm_compliance_pct": 92.4,
        "overdue_work_orders": 3,
        "critical_assets": 2,
        "inventory_value_usd": 2400
    }

# Work Order Endpoints
@app.get("/cmms/workorders/view")
async def workorders_view():
    return {"redirect": "/cmms/workorders", "status": "success"}

# Work Order Storage (in-memory for testing)
workorders_db = {}
wo_counter = 123

@app.post("/cmms/workorders")
async def create_workorder(workorder: dict):
    global wo_counter
    wo_id = f"WO-{wo_counter}"
    wo_counter += 1
    
    workorder_data = {
        "id": wo_id,
        "title": workorder.get("title", ""),
        "asset_id": workorder.get("asset_id", ""),
        "type": workorder.get("type", "Corrective"),
        "priority": workorder.get("priority", "Medium"),
        "description": workorder.get("description", ""),
        "requested_by": workorder.get("requested_by", ""),
        "status": "Open",
        "created_at": "2025-09-13T19:00:00Z",
        "assigned_to": None,
        "planned_start": None,
        "planned_end": None,
        "due_date": None,
        "comments": []
    }
    
    workorders_db[wo_id] = workorder_data
    return workorder_data

@app.get("/cmms/workorders/{work_order_id}")
async def get_workorder(work_order_id: str):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    return workorders_db[work_order_id]

@app.put("/cmms/workorders/{work_order_id}")
async def update_workorder(work_order_id: str, updates: dict):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    workorders_db[work_order_id].update(updates)
    workorders_db[work_order_id]["updated_at"] = "2025-09-13T19:10:00Z"
    return {"status": "updated", "work_order": workorders_db[work_order_id]}

@app.patch("/cmms/workorders/{work_order_id}/schedule")
async def schedule_workorder(work_order_id: str, schedule: dict):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    workorders_db[work_order_id].update({
        "planned_start": schedule.get("planned_start"),
        "planned_end": schedule.get("planned_end"),
        "due_date": schedule.get("due_date")
    })
    return {"status": "scheduled", "work_order": workorders_db[work_order_id]}

@app.patch("/cmms/workorders/{work_order_id}/assign")
async def assign_workorder(work_order_id: str, assignment: dict):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    workorders_db[work_order_id]["assigned_to"] = assignment.get("assigned_to")
    return {"status": "assigned", "work_order": workorders_db[work_order_id]}

@app.patch("/cmms/workorders/{work_order_id}/status")
async def update_workorder_status(work_order_id: str, status_update: dict):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    new_status = status_update.get("status")
    workorders_db[work_order_id]["status"] = new_status
    
    if new_status == "Completed":
        workorders_db[work_order_id]["completed_at"] = "2025-09-13T19:30:00Z"
    
    return {"status": "completed" if new_status == "Completed" else "updated", 
            "work_order": workorders_db[work_order_id]}

@app.post("/cmms/workorders/{work_order_id}/comment")
async def add_workorder_comment(work_order_id: str, comment: dict):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    comment_data = {
        "id": f"C-{len(workorders_db[work_order_id]['comments']) + 1}",
        "message": comment.get("message", ""),
        "author": "TECH-001",
        "timestamp": "2025-09-13T19:25:00Z"
    }
    
    workorders_db[work_order_id]["comments"].append(comment_data)
    return {"status": "comment added", "comment": comment_data}

@app.post("/cmms/workorders/{work_order_id}/attach-document")
async def attach_workorder_document(work_order_id: str, file: UploadFile = File(...)):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    return {"work_order_id": work_order_id, "document_attached": True, "filename": file.filename}

@app.delete("/cmms/workorders/{work_order_id}")
async def delete_workorder(work_order_id: str):
    if work_order_id not in workorders_db:
        return JSONResponse({"error": "Work order not found"}, status_code=404)
    
    del workorders_db[work_order_id]
    return JSONResponse({"status": "deleted"}, status_code=204)

@app.get("/cmms/workorders/active")
async def active_workorders():
    return {"count": 12, "items": [{"id": "WO-001", "title": "Pump maintenance", "priority": "high"}]}

@app.get("/cmms/workorders/completed")
async def completed_workorders():
    return {"count": 11, "items": [{"id": "WO-002", "title": "Belt replacement", "status": "completed"}]}

# Asset Endpoints
@app.get("/cmms/assets/manage")
async def assets_manage():
    return {"redirect": "/cmms/assets", "status": "success"}

@app.post("/cmms/assets")
async def create_asset(name: str = Form(...), asset_id: str = Form(...)):
    return {"id": asset_id, "name": name, "status": "created"}

@app.get("/cmms/assets/critical")
async def critical_assets():
    return {"count": 2, "items": [{"id": "PUMP-001", "status": "critical", "alert": "overheating"}]}

# Parts Endpoints
@app.get("/cmms/parts/inventory")
async def parts_inventory():
    return {"redirect": "/cmms/parts", "status": "success"}

@app.post("/cmms/parts")
async def create_part(name: str = Form(...), part_number: str = Form(...)):
    return {"id": part_number, "name": name, "status": "created"}

@app.get("/cmms/parts/low-stock")
async def low_stock_parts():
    return {"count": 8, "items": [{"id": "BELT-001", "stock": 2, "min_stock": 5}]}

# Preventive Maintenance
@app.get("/cmms/preventive")
async def preventive_maintenance():
    return {"scheduled": 15, "overdue": 2, "completed_this_month": 23}

@app.get("/cmms/preventive/scheduled")
async def scheduled_pm():
    return {"count": 15, "items": [{"id": "PM-001", "asset": "CONV-001", "due_date": "2025-09-15"}]}

@app.get("/cmms/preventive/overdue")
async def overdue_pm():
    return {"count": 2, "items": [{"id": "PM-002", "asset": "PUMP-001", "days_overdue": 3}]}

# Technicians
@app.get("/cmms/technicians")
async def technicians():
    return {"total": 12, "active": 8, "on_break": 2, "off_duty": 2}

@app.get("/cmms/technicians/active")
async def active_technicians():
    return {"count": 8, "items": [{"id": "TECH-001", "name": "John Smith", "status": "active"}]}

@app.get("/cmms/technicians/assignments")
async def technician_assignments():
    return {"count": 12, "items": [{"tech_id": "TECH-001", "work_order": "WO-001", "priority": "high"}]}

# AI Assistant Endpoints
@app.post("/cmms/ai/voice-command")
async def ai_voice_command(audio: UploadFile = File(...)):
    return {"message": "Voice command processed", "transcription": "Create work order for pump maintenance", "action": "work_order_created"}

@app.post("/cmms/ai/chat")
async def ai_chat(message: str = Form(...)):
    return {"response": "I'll help you create a work order for pump maintenance.", "action": "work_order_suggested"}

@app.post("/cmms/ai/analyze")
async def ai_analyze(description: str = Form(...)):
    return {"analysis": "Based on vibration symptoms, likely bearing failure", "recommendation": "Replace bearings immediately", "priority": "high"}

# Quality Analysis (viral demo endpoints)
@app.post("/erp/quality/analyze")
async def quality_analyze(description: str = Form(...)):
    return {"quality_score": 319, "analysis": f"Quality analysis for: {description}", "time_ms": 319}

@app.post("/erp/quality/ocr")
async def quality_ocr(photo: UploadFile = File(...)):
    return {"extracted_text": "Sample OCR text", "confidence": 0.95, "processing_time_ms": 250}

# Admin Endpoints
@app.get("/cmms/admin")
async def admin_dashboard():
    return {"users": 25, "active_sessions": 8, "system_status": "healthy", "uptime": "99.9%"}

@app.get("/cmms/admin/users")
async def admin_users():
    return {"count": 25, "items": [{"id": "USER-001", "name": "Admin User", "role": "admin"}]}

@app.get("/cmms/admin/settings")
async def admin_settings():
    return {"maintenance_schedule": "enabled", "notifications": "enabled", "backup": "daily"}

# Photo Attachments
@app.post("/cmms/workorders/{work_order_id}/attach-photo")
async def attach_workorder_photo(work_order_id: str, photo: UploadFile = File(...)):
    return {"work_order_id": work_order_id, "photo_uploaded": True, "filename": photo.filename}

@app.post("/cmms/assets/{asset_id}/attach-photo")
async def attach_asset_photo(asset_id: str, photo: UploadFile = File(...)):
    return {"asset_id": asset_id, "photo_uploaded": True, "filename": photo.filename}

@app.post("/cmms/parts/{part_id}/attach-photo")
async def attach_part_photo(part_id: str, photo: UploadFile = File(...)):
    return {"part_id": part_id, "photo_uploaded": True, "filename": photo.filename}

# Export & Reports
@app.get("/cmms/export")
async def export_options():
    return {"formats": ["csv", "excel", "pdf"], "modules": ["workorders", "assets", "parts"]}

@app.get("/cmms/export/workorders")
async def export_workorders():
    return {"status": "export_generated", "download_url": "/downloads/workorders.csv"}

@app.get("/cmms/export/assets")
async def export_assets():
    return {"status": "export_generated", "download_url": "/downloads/assets.csv"}

@app.get("/cmms/export/parts")
async def export_parts():
    return {"status": "export_generated", "download_url": "/downloads/parts.csv"}

@app.get("/cmms/reports/dashboard")
async def dashboard_reports():
    return {"kpi_summary": "available", "charts": ["workorders", "assets", "maintenance"], "last_updated": "2025-09-13T18:00:00Z"}

# Additional Health Endpoints
@app.get("/cmms/health")
async def cmms_health():
    return {"status": "healthy", "database": "connected", "ai_service": "running"}

@app.get("/metrics")
async def prometheus_metrics():
    return {"format": "prometheus", "metrics": "cmms_requests_total 1234\ncmms_response_time_seconds 0.1"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)