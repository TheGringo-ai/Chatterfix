#!/usr/bin/env python3
"""
ChatterFix CMMS - Simple Work Orders Module
Complete CRUD functionality for work order management
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from typing import List, Dict, Any, Optional
from datetime import datetime
import json

router = APIRouter(prefix="/cmms/workorders", tags=["workorders"])

# Simple work orders data
WORK_ORDERS = [
    {
        "id": "WO-001",
        "title": "Pump Maintenance",
        "description": "Replace seals and check pressure",
        "asset_id": "AST-001",
        "priority": "high",
        "status": "open",
        "assigned_to": "John Smith",
        "due_date": "2025-09-20",
        "estimated_hours": 4.0,
        "created_at": "2025-09-10T10:00:00Z",
        "comments": "Customer reported unusual noise during operation"
    },
    {
        "id": "WO-002", 
        "title": "Conveyor Belt Alignment",
        "description": "Adjust belt tracking and tension",
        "asset_id": "AST-002",
        "priority": "medium",
        "status": "in_progress", 
        "assigned_to": "Mike Johnson",
        "due_date": "2025-09-18",
        "estimated_hours": 2.5,
        "created_at": "2025-09-11T14:30:00Z",
        "comments": "Belt showing wear patterns on left side"
    },
    {
        "id": "WO-003",
        "title": "Motor Vibration Check",
        "description": "Investigate unusual vibration in motor",
        "asset_id": "AST-003", 
        "priority": "urgent",
        "status": "completed",
        "assigned_to": "John Smith",
        "due_date": "2025-09-15",
        "estimated_hours": 3.0,
        "created_at": "2025-09-12T09:15:00Z",
        "comments": "Completed bearing replacement - issue resolved"
    },
    {
        "id": "WO-004",
        "title": "HVAC Filter Replacement",
        "description": "Replace air filters in HVAC system",
        "asset_id": "AST-003",
        "priority": "low",
        "status": "open",
        "assigned_to": "Sarah Wilson",
        "due_date": "2025-09-25",
        "estimated_hours": 1.0,
        "created_at": "2025-09-13T11:20:00Z",
        "comments": "Scheduled maintenance - quarterly filter change"
    },
    {
        "id": "WO-005",
        "title": "Generator Load Test",
        "description": "Perform monthly load test on backup generator",
        "asset_id": "AST-004",
        "priority": "medium",
        "status": "assigned",
        "assigned_to": "Mike Johnson",
        "due_date": "2025-09-22",
        "estimated_hours": 1.5,
        "created_at": "2025-09-14T08:45:00Z",
        "comments": "Monthly compliance test required"
    }
]

@router.get("/dashboard")
async def workorders_dashboard():
    """Live Work Orders management dashboard with full CRUD functionality"""
    return HTMLResponse('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Work Order Management - ChatterFix CMMS</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #9b59b6 0%, #2c3e50 100%);
                min-height: 100vh;
                color: white;
                padding: 2rem;
            }
            .card { 
                background: rgba(255,255,255,0.1);
                backdrop-filter: blur(15px);
                border-radius: 20px;
                padding: 2rem;
                margin: 1rem 0;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .open { color: #f39c12; }
            .in_progress { color: #3498db; }
            .assigned { color: #2ecc71; }
            .completed { color: #27ae60; font-weight: bold; }
            .cancelled { color: #e74c3c; }
            .urgent { color: #e74c3c; font-weight: bold; }
            .high { color: #f39c12; font-weight: bold; }
            .medium { color: #f1c40f; }
            .low { color: #95a5a6; }
            h1 { margin-bottom: 2rem; text-align: center; }
            .workorder { 
                background: rgba(255,255,255,0.05);
                border-radius: 15px;
                padding: 1.5rem;
                margin: 1rem 0;
                border-left: 4px solid #9b59b6;
                position: relative;
            }
            .workorder-actions {
                position: absolute;
                top: 1rem;
                right: 1rem;
                display: flex;
                gap: 0.5rem;
            }
            .status-indicator {
                display: inline-block;
                padding: 0.3rem 0.8rem;
                border-radius: 15px;
                font-size: 0.8rem;
                font-weight: bold;
                margin-left: 1rem;
            }
            .priority-indicator {
                display: inline-block;
                padding: 0.3rem 0.8rem;
                border-radius: 15px;
                font-size: 0.8rem;
                font-weight: bold;
                margin-left: 0.5rem;
            }
            .btn {
                background: linear-gradient(135deg, #9b59b6, #8e44ad);
                color: white;
                border: none;
                padding: 0.8rem 1.5rem;
                border-radius: 10px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 0.25rem;
                transition: all 0.3s ease;
                font-size: 0.9rem;
            }
            .btn:hover { transform: translateY(-2px); }
            .btn-small {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }
            .btn-warning {
                background: linear-gradient(135deg, #f39c12, #e67e22);
            }
            .btn-success {
                background: linear-gradient(135deg, #27ae60, #229954);
            }
            .btn-danger {
                background: linear-gradient(135deg, #e74c3c, #c0392b);
            }
            .btn-info {
                background: linear-gradient(135deg, #3498db, #2980b9);
            }
            .modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }
            .modal-content {
                background: rgba(44,62,80,0.95);
                backdrop-filter: blur(15px);
                margin: 5% auto;
                padding: 2rem;
                border-radius: 20px;
                width: 90%;
                max-width: 600px;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .form-group {
                margin: 1rem 0;
            }
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: bold;
            }
            .form-group input, .form-group select, .form-group textarea {
                width: 100%;
                padding: 0.8rem;
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 10px;
                background: rgba(255,255,255,0.1);
                color: white;
                font-size: 1rem;
            }
            .form-group input::placeholder, .form-group textarea::placeholder {
                color: rgba(255,255,255,0.6);
            }
            .loading {
                text-align: center;
                padding: 2rem;
                font-size: 1.2rem;
            }
            .stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin: 2rem 0;
            }
            .stat-card {
                text-align: center;
                padding: 1rem;
                border-radius: 10px;
            }
            .kanban {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
                margin: 2rem 0;
            }
            .kanban-column {
                background: rgba(255,255,255,0.05);
                border-radius: 10px;
                padding: 1rem;
                min-height: 400px;
            }
            .kanban-header {
                font-weight: bold;
                margin-bottom: 1rem;
                text-align: center;
                padding: 0.5rem;
                border-radius: 5px;
            }
            .kanban-card {
                background: rgba(255,255,255,0.1);
                padding: 1rem;
                margin: 0.5rem 0;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .kanban-card:hover {
                background: rgba(255,255,255,0.15);
                transform: translateY(-2px);
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>📋 Work Order Management Dashboard</h1>
            
            <div style="text-align: center; margin-bottom: 2rem;">
                <button class="btn btn-success" onclick="showCreateModal()">➕ Create New Work Order</button>
                <button class="btn" onclick="loadWorkOrders()">🔄 Refresh</button>
                <button class="btn btn-info" onclick="toggleView()">🏗️ Toggle Kanban</button>
                <a href="/cmms/dashboard/main" class="btn">← Back to Dashboard</a>
            </div>

            <div id="stats-container" class="stats">
                <div class="stat-card" style="background: rgba(155,89,182,0.2);">
                    <h3 id="total-workorders">-</h3>
                    <p>Total Work Orders</p>
                </div>
                <div class="stat-card" style="background: rgba(243,156,18,0.2);">
                    <h3 id="open-workorders">-</h3>
                    <p>Open</p>
                </div>
                <div class="stat-card" style="background: rgba(52,152,219,0.2);">
                    <h3 id="in-progress-workorders">-</h3>
                    <p>In Progress</p>
                </div>
                <div class="stat-card" style="background: rgba(39,174,96,0.2);">
                    <h3 id="completed-workorders">-</h3>
                    <p>Completed</p>
                </div>
            </div>

            <div id="list-view" class="view-container">
                <div id="workorders-container">
                    <div class="loading">Loading work orders...</div>
                </div>
            </div>

            <div id="kanban-view" class="view-container" style="display: none;">
                <div class="kanban">
                    <div class="kanban-column">
                        <div class="kanban-header" style="background: rgba(243,156,18,0.3);">Open</div>
                        <div id="kanban-open"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-header" style="background: rgba(46,204,113,0.3);">Assigned</div>
                        <div id="kanban-assigned"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-header" style="background: rgba(52,152,219,0.3);">In Progress</div>
                        <div id="kanban-in-progress"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-header" style="background: rgba(39,174,96,0.3);">Completed</div>
                        <div id="kanban-completed"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Create/Edit Work Order Modal -->
        <div id="workorder-modal" class="modal">
            <div class="modal-content">
                <h2 id="modal-title">Create New Work Order</h2>
                <form id="workorder-form">
                    <div class="form-group">
                        <label for="title">Title *</label>
                        <input type="text" id="title" name="title" required placeholder="Enter work order title">
                    </div>
                    <div class="form-group">
                        <label for="description">Description *</label>
                        <textarea id="description" name="description" required placeholder="Detailed description of work to be done" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="asset_id">Asset ID</label>
                        <input type="text" id="asset_id" name="asset_id" placeholder="Asset ID (e.g. AST-001)">
                    </div>
                    <div class="form-group">
                        <label for="priority">Priority</label>
                        <select id="priority" name="priority">
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                            <option value="urgent">Urgent</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="open">Open</option>
                            <option value="assigned">Assigned</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="assigned_to">Assigned To</label>
                        <input type="text" id="assigned_to" name="assigned_to" placeholder="Technician name">
                    </div>
                    <div class="form-group">
                        <label for="due_date">Due Date</label>
                        <input type="date" id="due_date" name="due_date">
                    </div>
                    <div class="form-group">
                        <label for="estimated_hours">Estimated Hours</label>
                        <input type="number" id="estimated_hours" name="estimated_hours" step="0.5" min="0" value="0.0">
                    </div>
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea id="comments" name="comments" placeholder="Additional comments or notes" rows="2"></textarea>
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-success">💾 Save Work Order</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Status Update Modal -->
        <div id="status-modal" class="modal">
            <div class="modal-content">
                <h2>Update Work Order Status</h2>
                <form id="status-form">
                    <div class="form-group">
                        <label for="new-status">New Status *</label>
                        <select id="new-status" name="status" required>
                            <option value="open">Open</option>
                            <option value="assigned">Assigned</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status-notes">Notes</label>
                        <textarea id="status-notes" name="notes" placeholder="Status update notes" rows="3"></textarea>
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-warning">🔄 Update Status</button>
                        <button type="button" class="btn btn-danger" onclick="closeStatusModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            let currentWorkOrders = [];
            let editingWorkOrderId = null;
            let statusWorkOrderId = null;
            let currentView = 'list';

            // Load work orders on page load
            document.addEventListener('DOMContentLoaded', loadWorkOrders);

            async function loadWorkOrders() {
                try {
                    const response = await fetch('/workorders-test/');
                    const data = await response.json();
                    
                    if (data.success) {
                        currentWorkOrders = data.work_orders;
                        updateStats();
                        if (currentView === 'list') {
                            renderWorkOrders();
                        } else {
                            renderKanban();
                        }
                    } else {
                        showError('Failed to load work orders');
                    }
                } catch (error) {
                    showError('Error loading work orders: ' + error.message);
                }
            }

            function updateStats() {
                const totalWorkOrders = currentWorkOrders.length;
                const openWorkOrders = currentWorkOrders.filter(wo => wo.status === 'open').length;
                const inProgressWorkOrders = currentWorkOrders.filter(wo => wo.status === 'in_progress').length;
                const completedWorkOrders = currentWorkOrders.filter(wo => wo.status === 'completed').length;

                document.getElementById('total-workorders').textContent = totalWorkOrders;
                document.getElementById('open-workorders').textContent = openWorkOrders;
                document.getElementById('in-progress-workorders').textContent = inProgressWorkOrders;
                document.getElementById('completed-workorders').textContent = completedWorkOrders;
            }

            function renderWorkOrders() {
                const container = document.getElementById('workorders-container');
                
                if (currentWorkOrders.length === 0) {
                    container.innerHTML = '<div class="loading">No work orders found. Create your first work order!</div>';
                    return;
                }

                container.innerHTML = currentWorkOrders.map(workorder => {
                    let statusClass, statusIndicator;
                    let priorityClass, priorityIndicator;

                    // Status styling
                    if (workorder.status === 'open') {
                        statusClass = 'open';
                        statusIndicator = '<span class="status-indicator" style="background: #f39c12;">OPEN</span>';
                    } else if (workorder.status === 'assigned') {
                        statusClass = 'assigned';
                        statusIndicator = '<span class="status-indicator" style="background: #2ecc71;">ASSIGNED</span>';
                    } else if (workorder.status === 'in_progress') {
                        statusClass = 'in_progress';
                        statusIndicator = '<span class="status-indicator" style="background: #3498db;">IN PROGRESS</span>';
                    } else if (workorder.status === 'completed') {
                        statusClass = 'completed';
                        statusIndicator = '<span class="status-indicator" style="background: #27ae60;">COMPLETED</span>';
                    } else {
                        statusClass = 'cancelled';
                        statusIndicator = '<span class="status-indicator" style="background: #e74c3c;">CANCELLED</span>';
                    }

                    // Priority styling
                    if (workorder.priority === 'urgent') {
                        priorityClass = 'urgent';
                        priorityIndicator = '<span class="priority-indicator" style="background: #e74c3c;">URGENT</span>';
                    } else if (workorder.priority === 'high') {
                        priorityClass = 'high';
                        priorityIndicator = '<span class="priority-indicator" style="background: #f39c12;">HIGH</span>';
                    } else if (workorder.priority === 'medium') {
                        priorityClass = 'medium';
                        priorityIndicator = '<span class="priority-indicator" style="background: #f1c40f;">MEDIUM</span>';
                    } else {
                        priorityClass = 'low';
                        priorityIndicator = '<span class="priority-indicator" style="background: #95a5a6;">LOW</span>';
                    }

                    return `
                        <div class="workorder">
                            <div class="workorder-actions">
                                <button class="btn btn-small btn-success" onclick="showEditModal('${workorder.id}')">✏️ Edit</button>
                                <button class="btn btn-small btn-warning" onclick="showStatusModal('${workorder.id}')">🔄 Status</button>
                                <button class="btn btn-small btn-info" onclick="assignWorkOrder('${workorder.id}')">👤 Assign</button>
                                <button class="btn btn-small btn-danger" onclick="deleteWorkOrder('${workorder.id}')">🗑️ Delete</button>
                            </div>
                            <h3>${workorder.title} <span class="${statusClass}">(${workorder.status.replace('_', ' ')})</span> ${statusIndicator} ${priorityIndicator}</h3>
                            <p><strong>ID:</strong> ${workorder.id} | <strong>Asset:</strong> ${workorder.asset_id} | <strong>Assigned To:</strong> ${workorder.assigned_to}</p>
                            <p><strong>Description:</strong> ${workorder.description}</p>
                            <p><strong>Due Date:</strong> ${workorder.due_date} | <strong>Estimated Hours:</strong> ${workorder.estimated_hours}</p>
                            <p><strong>Created:</strong> ${workorder.created_at} | <strong>Comments:</strong> ${workorder.comments}</p>
                        </div>
                    `;
                }).join('');
            }

            function renderKanban() {
                const statuses = ['open', 'assigned', 'in_progress', 'completed'];
                
                statuses.forEach(status => {
                    const containerId = `kanban-${status.replace('_', '-')}`;
                    const container = document.getElementById(containerId);
                    const statusWorkOrders = currentWorkOrders.filter(wo => wo.status === status);
                    
                    container.innerHTML = statusWorkOrders.map(workorder => {
                        let priorityColor = '#95a5a6';
                        if (workorder.priority === 'urgent') priorityColor = '#e74c3c';
                        else if (workorder.priority === 'high') priorityColor = '#f39c12';
                        else if (workorder.priority === 'medium') priorityColor = '#f1c40f';

                        return `
                            <div class="kanban-card" style="border-left: 4px solid ${priorityColor};" onclick="showEditModal('${workorder.id}')">
                                <div style="font-weight: bold; margin-bottom: 0.5rem;">${workorder.title}</div>
                                <div style="font-size: 0.9rem; margin-bottom: 0.5rem;">${workorder.asset_id}</div>
                                <div style="font-size: 0.8rem; opacity: 0.8;">${workorder.assigned_to}</div>
                                <div style="font-size: 0.8rem; opacity: 0.7;">Due: ${workorder.due_date}</div>
                            </div>
                        `;
                    }).join('');
                });
            }

            function toggleView() {
                const listView = document.getElementById('list-view');
                const kanbanView = document.getElementById('kanban-view');
                
                if (currentView === 'list') {
                    listView.style.display = 'none';
                    kanbanView.style.display = 'block';
                    currentView = 'kanban';
                    renderKanban();
                } else {
                    listView.style.display = 'block';
                    kanbanView.style.display = 'none';
                    currentView = 'list';
                    renderWorkOrders();
                }
            }

            function showCreateModal() {
                editingWorkOrderId = null;
                document.getElementById('modal-title').textContent = 'Create New Work Order';
                document.getElementById('workorder-form').reset();
                document.getElementById('workorder-modal').style.display = 'block';
            }

            async function showEditModal(workOrderId) {
                try {
                    const response = await fetch(`/workorders-test/${workOrderId}`);
                    const data = await response.json();
                    
                    if (data.success) {
                        editingWorkOrderId = workOrderId;
                        const workorder = data.work_order;
                        
                        document.getElementById('modal-title').textContent = 'Edit Work Order';
                        document.getElementById('title').value = workorder.title;
                        document.getElementById('description').value = workorder.description;
                        document.getElementById('asset_id').value = workorder.asset_id;
                        document.getElementById('priority').value = workorder.priority;
                        document.getElementById('status').value = workorder.status;
                        document.getElementById('assigned_to').value = workorder.assigned_to;
                        document.getElementById('due_date').value = workorder.due_date;
                        document.getElementById('estimated_hours').value = workorder.estimated_hours;
                        document.getElementById('comments').value = workorder.comments;
                        
                        document.getElementById('workorder-modal').style.display = 'block';
                    } else {
                        showError('Failed to load work order details');
                    }
                } catch (error) {
                    showError('Error loading work order: ' + error.message);
                }
            }

            function showStatusModal(workOrderId) {
                const workorder = currentWorkOrders.find(wo => wo.id === workOrderId);
                if (!workorder) return;

                statusWorkOrderId = workOrderId;
                document.getElementById('new-status').value = workorder.status;
                document.getElementById('status-form').reset();
                document.getElementById('status-modal').style.display = 'block';
            }

            async function assignWorkOrder(workOrderId) {
                const newAssignee = prompt('Assign to technician:');
                if (!newAssignee) return;

                try {
                    const response = await fetch(`/workorders-test/${workOrderId}/assign`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ assigned_to: newAssignee })
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadWorkOrders();
                    } else {
                        showError(data.detail || 'Failed to assign work order');
                    }
                } catch (error) {
                    showError('Error assigning work order: ' + error.message);
                }
            }

            function closeModal() {
                document.getElementById('workorder-modal').style.display = 'none';
            }

            function closeStatusModal() {
                document.getElementById('status-modal').style.display = 'none';
            }

            // Handle work order form submission
            document.getElementById('workorder-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const workorderData = Object.fromEntries(formData.entries());
                
                // Convert numeric fields
                workorderData.estimated_hours = parseFloat(workorderData.estimated_hours) || 0.0;

                try {
                    let response;
                    if (editingWorkOrderId) {
                        response = await fetch(`/workorders-test/${editingWorkOrderId}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(workorderData)
                        });
                    } else {
                        response = await fetch('/workorders-test/', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(workorderData)
                        });
                    }

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeModal();
                        loadWorkOrders();
                    } else {
                        showError('Failed to save work order');
                    }
                } catch (error) {
                    showError('Error saving work order: ' + error.message);
                }
            });

            // Handle status form submission
            document.getElementById('status-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const statusData = Object.fromEntries(formData.entries());

                try {
                    const response = await fetch(`/workorders-test/${statusWorkOrderId}/status`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(statusData)
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeStatusModal();
                        loadWorkOrders();
                    } else {
                        showError(data.detail || 'Failed to update status');
                    }
                } catch (error) {
                    showError('Error updating status: ' + error.message);
                }
            });

            async function deleteWorkOrder(workOrderId) {
                if (!confirm('Are you sure you want to delete this work order? This action cannot be undone.')) {
                    return;
                }

                try {
                    const response = await fetch(`/workorders-test/${workOrderId}`, {
                        method: 'DELETE'
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadWorkOrders();
                    } else {
                        showError('Failed to delete work order');
                    }
                } catch (error) {
                    showError('Error deleting work order: ' + error.message);
                }
            }

            function showSuccess(message) {
                alert('✅ ' + message);
            }

            function showError(message) {
                alert('❌ ' + message);
            }

            // Close modals when clicking outside
            window.onclick = function(event) {
                const workorderModal = document.getElementById('workorder-modal');
                const statusModal = document.getElementById('status-modal');
                
                if (event.target === workorderModal) {
                    workorderModal.style.display = 'none';
                }
                if (event.target === statusModal) {
                    statusModal.style.display = 'none';
                }
            }
        </script>
    </body>
    </html>
    ''')

@router.get("/")
async def list_workorders():
    """Get all work orders as JSON"""
    return {"work_orders": WORK_ORDERS, "count": len(WORK_ORDERS)}

@router.get("/{work_order_id}")
async def get_workorder(work_order_id: str):
    """Get specific work order"""
    wo = next((wo for wo in WORK_ORDERS if wo["id"] == work_order_id), None)
    if not wo:
        raise HTTPException(status_code=404, detail="Work order not found")
    return wo

@router.get("/status/open")
async def get_open_workorders():
    """Get open work orders"""
    open_workorders = [wo for wo in WORK_ORDERS if wo['status'] == 'open']
    return {"open_work_orders": open_workorders, "count": len(open_workorders)}

@router.get("/priority/urgent")
async def get_urgent_workorders():
    """Get urgent work orders"""
    urgent_workorders = [wo for wo in WORK_ORDERS if wo['priority'] == 'urgent']
    return {"urgent_work_orders": urgent_workorders, "count": len(urgent_workorders)}

print("✅ Simple Work Orders module loaded")