# 🎮 Demo/Production Mode Switch

## Overview

ChatterFix CMMS now includes a comprehensive demo and production mode system that allows administrators to easily switch between demonstration mode (for demos, training, and testing) and production mode (for live operations).

## Features

### 🧪 Demo Mode
- **Sample Data**: Shows realistic demo data instead of live data
- **Limited Functionality**: Restricts potentially destructive operations
- **Demo Watermark**: Displays clear visual indicators that the system is in demo mode
- **Auto Reset**: Allows easy reset of demo data to initial state
- **Safety**: Prevents accidental data loss during demos

### 🚀 Production Mode
- **Live Data**: Full access to production data and functionality
- **Complete Features**: All system features available
- **No Restrictions**: Full operational capability
- **Security**: Normal security and access controls

## Admin Dashboard Controls

### Visual Indicators
- **Mode Display**: Clear indication of current mode with color coding
  - 🧪 **Demo Mode**: Red indicator with "DEMO MODE" text
  - 🚀 **Production Mode**: Green indicator with "PRODUCTION MODE" text
- **Demo Banner**: When in demo mode, a red banner appears at the top: "🧪 DEMO MODE ACTIVE - Sample Data Only"

### Toggle Switch
- **Interactive Toggle**: Stylized toggle switch to change modes
- **Confirmation**: Prompts for confirmation before switching modes
- **Instant Feedback**: Visual updates immediately upon mode change

### Demo Controls
- **Reset Demo Data**: Button to restore demo data to initial state (only visible in demo mode)
- **Mode Status**: Real-time display of current mode and features

## API Endpoints

### Mode Management
- `POST /cmms/admin/system-mode` - Toggle between demo and production mode
- `POST /cmms/admin/reset-demo` - Reset demo data to initial state
- `GET /cmms/admin/system-info` - Get current system mode information

### Request/Response Examples

**Switch to Demo Mode:**
```bash
curl -X POST "/cmms/admin/system-mode" \
  -H "Content-Type: application/json" \
  -d '{"mode": "demo"}'
```

**Response:**
```json
{
  "status": "success",
  "mode": "demo",
  "message": "System switched to demo mode",
  "timestamp": "2025-09-16T...",
  "demo_features_enabled": true
}
```

## Developer Integration

### Using System Mode in Code

```python
from system_mode import is_demo_mode, is_production_mode, demo_mode_decorator

# Simple checks
if is_demo_mode():
    # Demo behavior
    data = get_sample_data()
else:
    # Production behavior  
    data = get_live_data()

# Using decorator
@demo_mode_decorator
def create_work_order(title, **kwargs):
    if kwargs.get('demo_mode'):
        return create_demo_work_order(title)
    else:
        return create_production_work_order(title)
```

### Helper Functions
- `is_demo_mode()` - Returns True if in demo mode
- `is_production_mode()` - Returns True if production mode  
- `get_system_mode()` - Returns current mode string
- `get_demo_features()` - Returns demo features configuration
- `@demo_mode_decorator` - Decorator that adds mode context
- `@production_only` - Decorator that restricts functions to production only

## Configuration

### System Config
```python
system_config = {
    "system_mode": "production",  # "demo" or "production"
    "demo_mode_features": {
        "show_sample_data": True,
        "limited_functionality": True, 
        "demo_watermark": True,
        "auto_reset_data": True
    }
}
```

### Demo Features
- **show_sample_data**: Use sample/demo data instead of live data
- **limited_functionality**: Restrict certain operations for safety
- **demo_watermark**: Show visual indicators of demo mode
- **auto_reset_data**: Enable data reset functionality

## Security

### Access Control
- Mode switching requires admin access (IP-based authentication)
- All mode changes are logged with IP address and timestamp
- Demo data reset only available in demo mode

### Safety Features
- Confirmation dialogs prevent accidental mode switches
- Demo mode protects production data
- Clear visual indicators prevent confusion
- Automatic page refresh ensures UI consistency

## Use Cases

### 🎯 Demo/Sales Presentations
1. Switch to demo mode
2. Use realistic sample data
3. Demo all features safely
4. Reset data between demos

### 📚 Training Sessions
1. Enable demo mode for trainees
2. Let users experiment safely
3. Reset data after training
4. No risk to production data

### 🧪 Testing & Development
1. Use demo mode for testing
2. Validate new features safely
3. Test UI/UX changes
4. Quick data reset for fresh tests

### 🚀 Production Operations
1. Switch to production mode
2. Full access to live data
3. Complete feature set
4. Normal operational security

## Technical Implementation

### Files Modified
- `admin.py` - Main implementation with UI and API endpoints
- `system_mode.py` - Utility module for other components
- Tests and documentation included

### UI Components
- Stylized toggle switch with smooth animations
- Color-coded mode indicators
- Demo banner for clear visual feedback
- Responsive design works on all screen sizes

### Backend Features
- RESTful API endpoints for mode management
- Comprehensive logging and audit trail
- Error handling and validation
- Safe data reset functionality

## Getting Started

1. **Access Admin Dashboard**: Navigate to `/cmms/admin/dashboard`
2. **Locate Mode Controls**: Find "System Configuration" card
3. **Toggle Mode**: Use the toggle switch to change modes
4. **Confirm Change**: Click OK in confirmation dialog
5. **Verify Mode**: Check visual indicators and banner

The system is now ready for both demonstration and production use with full administrative control over the operating mode!