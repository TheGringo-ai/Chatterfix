"""CMMS application package init to allow absolute imports"""
