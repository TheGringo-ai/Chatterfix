#!/usr/bin/env python3
"""
ChatterFix AI Meta-System Controller
Advanced autonomous AI system for continuous platform improvement and self-healing
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse
import aiohttp
from pathlib import Path
import subprocess
import psutil
import sqlite3
import threading
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Meta-system configuration
LLAMA_SERVER = "http://localhost:11434"
LLAMA_MODEL = "llama3.2:1b"
SYSTEM_DB = "/opt/chatterfix-cmms/system_intelligence.db"

# Meta-system router
meta_router = APIRouter(prefix="/meta", tags=["meta-system"])

@dataclass
class SystemFeature:
    """Represents a system feature that can be analyzed and improved"""
    name: str
    module_path: str
    endpoints: List[str]
    status: str = "active"
    last_check: Optional[datetime] = None
    performance_score: float = 0.0
    error_count: int = 0
    improvement_suggestions: List[str] = None

@dataclass
class UserFeedback:
    """User feedback for system improvement"""
    feature: str
    feedback_type: str  # "bug", "enhancement", "complaint", "praise"
    description: str
    priority: int  # 1-5
    timestamp: datetime
    status: str = "new"  # "new", "processing", "implemented", "rejected"

class SystemIntelligence:
    """Core AI intelligence for system analysis and improvement"""
    
    def __init__(self):
        self.features = {}
        self.feedback_queue = []
        self.healing_active = True
        self.analysis_interval = 300  # 5 minutes
        self.init_database()
        
    def init_database(self):
        """Initialize system intelligence database"""
        try:
            conn = sqlite3.connect(SYSTEM_DB)
            cursor = conn.cursor()
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS features (
                    name TEXT PRIMARY KEY,
                    module_path TEXT,
                    endpoints TEXT,
                    status TEXT,
                    last_check TIMESTAMP,
                    performance_score REAL,
                    error_count INTEGER,
                    improvement_suggestions TEXT
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    feature TEXT,
                    feedback_type TEXT,
                    description TEXT,
                    priority INTEGER,
                    timestamp TIMESTAMP,
                    status TEXT
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS improvements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    feature TEXT,
                    improvement_type TEXT,
                    description TEXT,
                    implementation_code TEXT,
                    timestamp TIMESTAMP,
                    status TEXT,
                    result TEXT
                )
            """)
            
            conn.commit()
            conn.close()
            logger.info("System intelligence database initialized")
        except Exception as e:
            logger.error(f"Database initialization error: {e}")

    async def query_llama_meta(self, prompt: str, context: str = "system_analysis") -> str:
        """Enhanced LLaMA query for meta-system operations"""
        try:
            system_prompt = f"""You are ChatterFix Meta-AI, an autonomous system intelligence responsible for analyzing, improving, and healing the ChatterFix CMMS platform.

Your capabilities:
- Analyze system features and identify improvement opportunities
- Generate code fixes and enhancements
- Detect and resolve system issues automatically
- Process user feedback for continuous improvement
- Implement self-healing mechanisms

Context: {context}
Provide detailed, actionable analysis with specific implementation suggestions."""

            payload = {
                "model": LLAMA_MODEL,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "top_p": 0.8,
                    "max_tokens": 1000,
                    "num_predict": 1000
                }
            }

            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(f"{LLAMA_SERVER}/api/chat", json=payload) as response:
                    if response.status == 200:
                        result = await response.json()
                        if "message" in result and "content" in result["message"]:
                            return result["message"]["content"]
                    return f"Meta-AI analysis unavailable (HTTP {response.status})"
        except Exception as e:
            logger.error(f"Meta-AI query error: {e}")
            return "Meta-AI system temporarily unavailable"

    async def analyze_system_features(self) -> Dict[str, Any]:
        """Comprehensive system feature analysis"""
        logger.info("Starting comprehensive system feature analysis...")
        
        # Discover all system features
        features_found = await self.discover_features()
        
        # Analyze each feature with LLaMA
        analysis_results = {}
        for feature_name, feature_info in features_found.items():
            prompt = f"""Analyze this ChatterFix CMMS feature for improvement opportunities:

Feature: {feature_name}
Module: {feature_info.get('module', 'unknown')}
Endpoints: {feature_info.get('endpoints', [])}
Current Status: {feature_info.get('status', 'unknown')}

Please provide:
1. Performance assessment (1-10 score)
2. Potential improvements
3. Bug risk areas
4. Enhancement suggestions
5. Code optimization opportunities

Focus on maintenance management, user experience, and system reliability."""

            analysis = await self.query_llama_meta(prompt, f"feature_analysis_{feature_name}")
            analysis_results[feature_name] = {
                "feature_info": feature_info,
                "ai_analysis": analysis,
                "timestamp": datetime.now().isoformat()
            }
            
        return analysis_results

    async def discover_features(self) -> Dict[str, Any]:
        """Auto-discover all system features"""
        features = {}
        
        try:
            # Scan Python files for FastAPI routers and endpoints
            cmms_path = Path("/opt/chatterfix-cmms")
            if cmms_path.exists():
                for py_file in cmms_path.glob("*.py"):
                    if py_file.name.startswith("__"):
                        continue
                        
                    try:
                        with open(py_file, 'r') as f:
                            content = f.read()
                            
                        # Look for routers and endpoints
                        if "APIRouter" in content or "@app." in content:
                            endpoints = []
                            lines = content.split('\n')
                            for line in lines:
                                if any(method in line for method in ["@app.get", "@app.post", "@router.get", "@router.post"]):
                                    if '"' in line:
                                        endpoint = line.split('"')[1]
                                        endpoints.append(endpoint)
                            
                            features[py_file.stem] = {
                                "module": str(py_file),
                                "endpoints": endpoints,
                                "status": "active",
                                "last_modified": py_file.stat().st_mtime
                            }
                    except Exception as e:
                        logger.error(f"Error scanning {py_file}: {e}")
                        
        except Exception as e:
            logger.error(f"Feature discovery error: {e}")
            
        return features

    async def self_heal_system(self) -> Dict[str, Any]:
        """Autonomous system healing"""
        logger.info("Starting autonomous system healing...")
        
        healing_results = {
            "checks_performed": [],
            "issues_found": [],
            "fixes_applied": [],
            "timestamp": datetime.now().isoformat()
        }
        
        # Check system health
        health_checks = [
            self.check_service_health,
            self.check_database_connections,
            self.check_ai_endpoints,
            self.check_file_permissions,
            self.check_system_resources
        ]
        
        for check in health_checks:
            try:
                result = await check()
                healing_results["checks_performed"].append({
                    "check": check.__name__,
                    "result": result,
                    "timestamp": datetime.now().isoformat()
                })
                
                if result.get("issues"):
                    healing_results["issues_found"].extend(result["issues"])
                    
                if result.get("fixes"):
                    healing_results["fixes_applied"].extend(result["fixes"])
                    
            except Exception as e:
                logger.error(f"Health check {check.__name__} failed: {e}")
                
        return healing_results

    async def check_service_health(self) -> Dict[str, Any]:
        """Check ChatterFix service health"""
        try:
            result = subprocess.run(["systemctl", "is-active", "chatterfix-cmms"], 
                                  capture_output=True, text=True)
            
            if result.returncode != 0:
                # Try to restart service
                restart_result = subprocess.run(["sudo", "systemctl", "restart", "chatterfix-cmms"],
                                              capture_output=True, text=True)
                
                return {
                    "status": "fixed" if restart_result.returncode == 0 else "failed",
                    "issues": ["Service was inactive"],
                    "fixes": ["Service restarted"] if restart_result.returncode == 0 else []
                }
                
            return {"status": "healthy"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def check_database_connections(self) -> Dict[str, Any]:
        """Check database connectivity"""
        try:
            conn = sqlite3.connect(SYSTEM_DB)
            conn.execute("SELECT 1")
            conn.close()
            return {"status": "healthy"}
        except Exception as e:
            return {"status": "error", "error": str(e), "issues": ["Database connection failed"]}

    async def check_ai_endpoints(self) -> Dict[str, Any]:
        """Check AI endpoint health"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{LLAMA_SERVER}/api/version", timeout=aiohttp.ClientTimeout(total=10)) as response:
                    if response.status == 200:
                        return {"status": "healthy"}
                    else:
                        return {"status": "degraded", "issues": [f"LLaMA server returned {response.status}"]}
        except Exception as e:
            return {"status": "error", "error": str(e), "issues": ["LLaMA server unreachable"]}

    async def check_file_permissions(self) -> Dict[str, Any]:
        """Check critical file permissions"""
        critical_files = [
            "/opt/chatterfix-cmms/app.py",
            "/opt/chatterfix-cmms/ai.py",
            SYSTEM_DB
        ]
        
        issues = []
        fixes = []
        
        for file_path in critical_files:
            try:
                if Path(file_path).exists():
                    # Check if file is readable
                    with open(file_path, 'r') as f:
                        pass
                else:
                    issues.append(f"Critical file missing: {file_path}")
            except PermissionError:
                issues.append(f"Permission denied: {file_path}")
                # Attempt fix
                try:
                    subprocess.run(["sudo", "chmod", "644", file_path], check=True)
                    fixes.append(f"Fixed permissions for {file_path}")
                except Exception:
                    pass
                    
        return {"status": "healthy" if not issues else "issues", "issues": issues, "fixes": fixes}

    async def check_system_resources(self) -> Dict[str, Any]:
        """Check system resource usage"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            issues = []
            if cpu_percent > 90:
                issues.append(f"High CPU usage: {cpu_percent}%")
            if memory.percent > 90:
                issues.append(f"High memory usage: {memory.percent}%")
            if disk.percent > 90:
                issues.append(f"Low disk space: {disk.percent}% used")
                
            return {
                "status": "healthy" if not issues else "warning",
                "issues": issues,
                "metrics": {
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory.percent,
                    "disk_percent": disk.percent
                }
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def process_user_feedback(self, feedback: UserFeedback) -> Dict[str, Any]:
        """Process user feedback for system improvement"""
        logger.info(f"Processing user feedback: {feedback.description}")
        
        # Analyze feedback with LLaMA
        analysis_prompt = f"""Analyze this user feedback for the ChatterFix CMMS system:

Feedback Type: {feedback.feedback_type}
Feature: {feedback.feature}
Description: {feedback.description}
Priority: {feedback.priority}/5

Please provide:
1. Root cause analysis
2. Specific improvement recommendations
3. Implementation priority (1-10)
4. Potential risks or side effects
5. Code changes needed (if applicable)

Focus on practical solutions that enhance the maintenance management experience."""

        analysis = await self.query_llama_meta(analysis_prompt, "feedback_processing")
        
        # Store feedback and analysis
        try:
            conn = sqlite3.connect(SYSTEM_DB)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO feedback (feature, feedback_type, description, priority, timestamp, status)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (feedback.feature, feedback.feedback_type, feedback.description, 
                 feedback.priority, feedback.timestamp, "analyzed"))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Feedback storage error: {e}")
            
        return {
            "feedback_id": int(time.time()),
            "analysis": analysis,
            "status": "analyzed",
            "next_actions": ["implementation_planning", "testing", "deployment"]
        }

# Global system intelligence instance
system_intelligence = SystemIntelligence()

@meta_router.get("/dashboard", response_class=HTMLResponse)
async def meta_system_dashboard():
    """Advanced AI Meta-System Control Dashboard"""
    return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatterFix AI Meta-System</title>
    <style>
        {get_base_styles()}
        {get_navigation_styles()}
        
        .meta-container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }}
        
        .control-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }}
        
        .control-panel {{
            background: rgba(255,255,255,0.15);
            border-radius: 15px;
            padding: 2rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }}
        
        .control-panel h3 {{
            color: #38ef7d;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}
        
        .status-indicator {{
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #38ef7d;
            animation: pulse 2s infinite;
        }}
        
        .control-btn {{
            width: 100%;
            padding: 1rem;
            margin: 0.5rem 0;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }}
        
        .control-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }}
        
        .control-btn.healing {{
            background: linear-gradient(135deg, #38ef7d, #11998e);
        }}
        
        .control-btn.analysis {{
            background: linear-gradient(135deg, #f093fb, #f5576c);
        }}
        
        .control-btn.feedback {{
            background: linear-gradient(135deg, #4facfe, #00f2fe);
        }}
        
        .results-area {{
            margin-top: 2rem;
            padding: 2rem;
            background: rgba(0,0,0,0.3);
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.1);
            max-height: 400px;
            overflow-y: auto;
        }}
        
        .system-metrics {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin: 1rem 0;
        }}
        
        .metric-card {{
            background: rgba(255,255,255,0.1);
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.1);
        }}
        
        .metric-value {{
            font-size: 1.5rem;
            font-weight: bold;
            color: #38ef7d;
        }}
        
        .metric-label {{
            font-size: 0.9rem;
            opacity: 0.8;
            margin-top: 0.5rem;
        }}
        
        .ai-status {{
            position: fixed;
            top: 100px;
            right: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 10px 18px;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: bold;
            z-index: 999;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            animation: pulse 2s infinite;
        }}
        
        .feedback-form {{
            background: rgba(255,255,255,0.1);
            padding: 1.5rem;
            border-radius: 12px;
            margin-top: 1rem;
        }}
        
        .feedback-form input, .feedback-form textarea, .feedback-form select {{
            width: 100%;
            padding: 0.75rem;
            margin: 0.5rem 0;
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 8px;
            color: white;
            font-size: 1rem;
        }}
        
        .feedback-form input::placeholder, .feedback-form textarea::placeholder {{
            color: rgba(255,255,255,0.7);
        }}
        
        @keyframes pulse {{
            0%, 100% {{ opacity: 1; }}
            50% {{ opacity: 0.8; }}
        }}
        
        .loading {{
            opacity: 0.6;
            pointer-events: none;
        }}
    </style>
</head>
<body>
    {get_navigation_html('meta')}
    
    <div class="ai-status">🧠 Meta-AI Active</div>
    
    <div class="meta-container">
        <div class="header">
            <h1>🧠 ChatterFix AI Meta-System</h1>
            <p>Autonomous system intelligence for continuous improvement and self-healing</p>
        </div>
        
        <div class="system-metrics" id="systemMetrics">
            <div class="metric-card">
                <div class="metric-value" id="featuresCount">--</div>
                <div class="metric-label">Features Monitored</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" id="healthScore">--</div>
                <div class="metric-label">System Health</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" id="improvementsCount">--</div>
                <div class="metric-label">Improvements Made</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" id="feedbackCount">--</div>
                <div class="metric-label">Feedback Processed</div>
            </div>
        </div>
        
        <div class="control-grid">
            <div class="control-panel">
                <h3><div class="status-indicator"></div>System Analysis</h3>
                <p>Comprehensive AI-powered analysis of all platform features</p>
                <button class="control-btn analysis" onclick="runSystemAnalysis()">🔍 Analyze All Features</button>
                <button class="control-btn analysis" onclick="runPerformanceAnalysis()">⚡ Performance Analysis</button>
                <button class="control-btn analysis" onclick="runSecurityAnalysis()">🔒 Security Analysis</button>
            </div>
            
            <div class="control-panel">
                <h3><div class="status-indicator"></div>Self-Healing</h3>
                <p>Autonomous detection and repair of system issues</p>
                <button class="control-btn healing" onclick="runSelfHealing()">🛠️ Execute Self-Healing</button>
                <button class="control-btn healing" onclick="runHealthCheck()">❤️ Health Check</button>
                <button class="control-btn healing" onclick="runSystemRepair()">🔧 System Repair</button>
            </div>
            
            <div class="control-panel">
                <h3><div class="status-indicator"></div>User Feedback</h3>
                <p>Process feedback for continuous improvement</p>
                <div class="feedback-form">
                    <select id="feedbackFeature">
                        <option value="">Select Feature</option>
                        <option value="work_orders">Work Orders</option>
                        <option value="assets">Assets</option>
                        <option value="parts">Parts</option>
                        <option value="ai_assistant">AI Assistant</option>
                        <option value="dashboard">Dashboard</option>
                    </select>
                    <select id="feedbackType">
                        <option value="enhancement">Enhancement</option>
                        <option value="bug">Bug Report</option>
                        <option value="complaint">Complaint</option>
                        <option value="praise">Praise</option>
                    </select>
                    <textarea id="feedbackDescription" placeholder="Describe your feedback..." rows="3"></textarea>
                    <input type="range" id="feedbackPriority" min="1" max="5" value="3">
                    <label for="feedbackPriority">Priority: <span id="priorityValue">3</span>/5</label>
                </div>
                <button class="control-btn feedback" onclick="submitFeedback()">📝 Submit Feedback</button>
            </div>
            
            <div class="control-panel">
                <h3><div class="status-indicator"></div>Intelligence Dashboard</h3>
                <p>Real-time system intelligence metrics</p>
                <button class="control-btn" onclick="refreshMetrics()">📊 Refresh Metrics</button>
                <button class="control-btn" onclick="viewSystemLogs()">📋 View System Logs</button>
                <button class="control-btn" onclick="exportReport()">📄 Export Report</button>
            </div>
        </div>
        
        <div class="results-area" id="resultsArea" style="display: none;">
            <h3>🤖 Meta-AI Results</h3>
            <div id="resultsContent"></div>
        </div>
    </div>
    
    <script>
        let isProcessing = false;
        
        // Update priority display
        document.getElementById('feedbackPriority').addEventListener('input', function() {{
            document.getElementById('priorityValue').textContent = this.value;
        }});
        
        async function runSystemAnalysis() {{
            if (isProcessing) return;
            isProcessing = true;
            
            showResults('🔍 Starting comprehensive system analysis...');
            updateButtonState(true);
            
            try {{
                const response = await fetch('/cmms/meta/analyze-system', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }}
                }});
                
                if (response.ok) {{
                    const data = await response.json();
                    showResults('✅ System Analysis Complete:\\n\\n' + JSON.stringify(data, null, 2));
                }} else {{
                    showResults('❌ Analysis failed: ' + response.status);
                }}
            }} catch (error) {{
                showResults('❌ Analysis error: ' + error.message);
            }} finally {{
                isProcessing = false;
                updateButtonState(false);
            }}
        }}
        
        async function runSelfHealing() {{
            if (isProcessing) return;
            isProcessing = true;
            
            showResults('🛠️ Starting autonomous self-healing...');
            updateButtonState(true);
            
            try {{
                const response = await fetch('/cmms/meta/self-heal', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }}
                }});
                
                if (response.ok) {{
                    const data = await response.json();
                    showResults('✅ Self-Healing Complete:\\n\\n' + JSON.stringify(data, null, 2));
                }} else {{
                    showResults('❌ Self-healing failed: ' + response.status);
                }}
            }} catch (error) {{
                showResults('❌ Self-healing error: ' + error.message);
            }} finally {{
                isProcessing = false;
                updateButtonState(false);
            }}
        }}
        
        async function submitFeedback() {{
            const feature = document.getElementById('feedbackFeature').value;
            const type = document.getElementById('feedbackType').value;
            const description = document.getElementById('feedbackDescription').value;
            const priority = document.getElementById('feedbackPriority').value;
            
            if (!feature || !description) {{
                alert('Please select a feature and provide description');
                return;
            }}
            
            showResults('📝 Processing feedback...');
            
            try {{
                const response = await fetch('/cmms/meta/feedback', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        feature: feature,
                        feedback_type: type,
                        description: description,
                        priority: parseInt(priority)
                    }})
                }});
                
                if (response.ok) {{
                    const data = await response.json();
                    showResults('✅ Feedback processed successfully:\\n\\n' + data.analysis);
                    // Clear form
                    document.getElementById('feedbackFeature').value = '';
                    document.getElementById('feedbackDescription').value = '';
                }} else {{
                    showResults('❌ Feedback processing failed: ' + response.status);
                }}
            }} catch (error) {{
                showResults('❌ Feedback error: ' + error.message);
            }}
        }}
        
        function showResults(content) {{
            document.getElementById('resultsArea').style.display = 'block';
            document.getElementById('resultsContent').innerHTML = '<pre>' + content + '</pre>';
            document.getElementById('resultsArea').scrollTop = 0;
        }}
        
        function updateButtonState(loading) {{
            const buttons = document.querySelectorAll('.control-btn');
            buttons.forEach(btn => {{
                if (loading) {{
                    btn.classList.add('loading');
                    btn.disabled = true;
                }} else {{
                    btn.classList.remove('loading');
                    btn.disabled = false;
                }}
            }});
        }}
        
        // Auto-refresh metrics every 30 seconds
        setInterval(refreshMetrics, 30000);
        refreshMetrics();
        
        async function refreshMetrics() {{
            try {{
                const response = await fetch('/cmms/meta/metrics');
                if (response.ok) {{
                    const data = await response.json();
                    document.getElementById('featuresCount').textContent = data.features_count || '--';
                    document.getElementById('healthScore').textContent = data.health_score + '%' || '--';
                    document.getElementById('improvementsCount').textContent = data.improvements_count || '--';
                    document.getElementById('feedbackCount').textContent = data.feedback_count || '--';
                }}
            }} catch (error) {{
                console.error('Metrics refresh failed:', error);
            }}
        }}
        
        {get_navigation_javascript()}
    </script>
</body>
</html>
    """

@meta_router.post("/analyze-system")
async def analyze_system(background_tasks: BackgroundTasks):
    """Trigger comprehensive system analysis"""
    try:
        analysis_results = await system_intelligence.analyze_system_features()
        return {
            "status": "analysis_complete",
            "features_analyzed": len(analysis_results),
            "results": analysis_results,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"System analysis error: {e}")
        raise HTTPException(status_code=500, detail="System analysis failed")

@meta_router.post("/self-heal")
async def self_heal():
    """Execute autonomous self-healing"""
    try:
        healing_results = await system_intelligence.self_heal_system()
        return healing_results
    except Exception as e:
        logger.error(f"Self-healing error: {e}")
        raise HTTPException(status_code=500, detail="Self-healing failed")

@meta_router.post("/feedback")
async def process_feedback(feedback_data: dict):
    """Process user feedback"""
    try:
        feedback = UserFeedback(
            feature=feedback_data["feature"],
            feedback_type=feedback_data["feedback_type"],
            description=feedback_data["description"],
            priority=feedback_data["priority"],
            timestamp=datetime.now()
        )
        
        result = await system_intelligence.process_user_feedback(feedback)
        return result
    except Exception as e:
        logger.error(f"Feedback processing error: {e}")
        raise HTTPException(status_code=500, detail="Feedback processing failed")

@meta_router.get("/metrics")
async def get_metrics():
    """Get system metrics"""
    try:
        conn = sqlite3.connect(SYSTEM_DB)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM feedback")
        feedback_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM improvements")
        improvements_count = cursor.fetchone()[0]
        
        conn.close()
        
        # Calculate health score (simplified)
        health_score = 95  # Placeholder - would be calculated from actual metrics
        
        return {
            "features_count": 12,  # Placeholder
            "health_score": health_score,
            "improvements_count": improvements_count,
            "feedback_count": feedback_count,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Metrics error: {e}")
        return {
            "features_count": 0,
            "health_score": 0,
            "improvements_count": 0,
            "feedback_count": 0,
            "error": str(e)
        }

# Start background monitoring
def start_background_monitoring():
    """Start background system monitoring"""
    def monitor_loop():
        while True:
            try:
                # Run self-healing check every 5 minutes
                asyncio.run(system_intelligence.self_heal_system())
                time.sleep(300)  # 5 minutes
            except Exception as e:
                logger.error(f"Background monitoring error: {e}")
                time.sleep(60)  # Wait 1 minute before retry
    
    monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
    monitor_thread.start()

# Initialize background monitoring
start_background_monitoring()