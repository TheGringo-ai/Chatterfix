#!/usr/bin/env python3
"""
Dynamic AI Model Selector - User Configurable Multi-Provider AI System
Allows users to choose and configure multiple AI providers dynamically
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from fastapi import APIRouter, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from ai_model_provider import CentralizedAIProvider, AIConfig, AIProvider

logger = logging.getLogger(__name__)

class AIProviderConfig(BaseModel):
    provider: str
    api_key: str
    model: str
    base_url: Optional[str] = None
    max_tokens: Optional[int] = 4096
    enabled: bool = True
    priority: int = 1

class UserAIPreferences(BaseModel):
    user_id: str
    active_providers: List[AIProviderConfig]
    default_provider: str
    coding_provider: str  # Specialized provider for code tasks
    analysis_provider: str  # Provider for data analysis
    creative_provider: str  # Provider for creative tasks
    temperature_settings: Dict[str, float] = {
        "coding": 0.1,
        "analysis": 0.2,
        "creative": 0.7,
        "general": 0.3
    }

# Global configuration storage (in production, use database)
user_ai_configs: Dict[str, UserAIPreferences] = {}

# Available provider templates
PROVIDER_TEMPLATES = {
    "groq": {
        "name": "Groq",
        "description": "Ultra-fast inference, excellent for coding",
        "base_url": "https://api.groq.com/openai/v1",
        "default_models": ["llama3-70b-8192", "mixtral-8x7b-32768", "llama3-8b-8192"],
        "strengths": ["Speed", "Code Generation", "Mathematical Reasoning"],
        "best_for": "coding"
    },
    "openai": {
        "name": "OpenAI",
        "description": "Industry-leading models with broad capabilities",
        "base_url": "https://api.openai.com/v1",
        "default_models": ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
        "strengths": ["General Purpose", "Creative Writing", "Complex Reasoning"],
        "best_for": "general"
    },
    "anthropic": {
        "name": "Anthropic Claude",
        "description": "Constitutional AI with strong reasoning",
        "base_url": "https://api.anthropic.com",
        "default_models": ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"],
        "strengths": ["Safety", "Long Context", "Analysis"],
        "best_for": "analysis"
    },
    "grok": {
        "name": "Grok (X.AI)",
        "description": "Innovative AI with real-time web access",
        "base_url": "https://api.x.ai/v1",
        "default_models": ["grok-beta"],
        "strengths": ["Real-time Data", "Humor", "Current Events"],
        "best_for": "creative"
    },
    "google": {
        "name": "Google Gemini",
        "description": "Multimodal AI with strong integration",
        "base_url": "https://generativelanguage.googleapis.com/v1beta",
        "default_models": ["gemini-pro", "gemini-pro-vision"],
        "strengths": ["Multimodal", "Integration", "Fast"],
        "best_for": "general"
    },
    "cohere": {
        "name": "Cohere",
        "description": "Enterprise-focused AI with strong RAG capabilities",
        "base_url": "https://api.cohere.ai/v1",
        "default_models": ["command-r-plus", "command-r", "command"],
        "strengths": ["RAG", "Embeddings", "Enterprise"],
        "best_for": "analysis"
    }
}

router = APIRouter(prefix="/ai-config", tags=["AI Configuration"])

@router.get("/", response_class=HTMLResponse)
async def ai_config_dashboard():
    """Dynamic AI configuration dashboard"""
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>AI Model Configuration - ChatterFix CMMS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
                line-height: 1.6;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                padding: 2rem;
            }}
            .header {{
                text-align: center;
                color: white;
                margin-bottom: 3rem;
            }}
            .header h1 {{
                font-size: 3rem;
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }}
            .header p {{
                font-size: 1.2rem;
                opacity: 0.9;
            }}
            .config-grid {{
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 2rem;
                margin-bottom: 2rem;
            }}
            .config-card {{
                background: white;
                border-radius: 15px;
                padding: 2rem;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                transition: transform 0.3s ease;
            }}
            .config-card:hover {{
                transform: translateY(-5px);
            }}
            .card-title {{
                font-size: 1.5rem;
                color: #333;
                margin-bottom: 1rem;
                border-bottom: 3px solid #667eea;
                padding-bottom: 0.5rem;
            }}
            .provider-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 1.5rem;
                margin-top: 2rem;
            }}
            .provider-card {{
                background: white;
                border-radius: 12px;
                padding: 1.5rem;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                border-left: 4px solid #667eea;
            }}
            .provider-header {{
                display: flex;
                justify-content: between;
                align-items: center;
                margin-bottom: 1rem;
            }}
            .provider-name {{
                font-size: 1.3rem;
                font-weight: bold;
                color: #333;
            }}
            .provider-status {{
                padding: 0.25rem 0.75rem;
                border-radius: 20px;
                font-size: 0.8rem;
                font-weight: bold;
            }}
            .status-active {{ background: #10b981; color: white; }}
            .status-inactive {{ background: #ef4444; color: white; }}
            .provider-description {{
                color: #666;
                margin-bottom: 1rem;
                font-size: 0.9rem;
            }}
            .strengths {{
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                margin-bottom: 1rem;
            }}
            .strength-tag {{
                background: #e0e7ff;
                color: #3730a3;
                padding: 0.25rem 0.75rem;
                border-radius: 15px;
                font-size: 0.8rem;
            }}
            .form-group {{
                margin-bottom: 1rem;
            }}
            .form-group label {{
                display: block;
                margin-bottom: 0.5rem;
                font-weight: 600;
                color: #333;
            }}
            .form-group input, .form-group select {{
                width: 100%;
                padding: 0.75rem;
                border: 2px solid #e5e5e5;
                border-radius: 8px;
                font-size: 1rem;
                transition: border-color 0.3s ease;
            }}
            .form-group input:focus, .form-group select:focus {{
                outline: none;
                border-color: #667eea;
            }}
            .btn {{
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 0.75rem 1.5rem;
                border: none;
                border-radius: 8px;
                font-size: 1rem;
                cursor: pointer;
                transition: transform 0.2s ease;
            }}
            .btn:hover {{
                transform: translateY(-2px);
            }}
            .btn-secondary {{
                background: #6b7280;
            }}
            .model-selector {{
                margin-top: 1rem;
            }}
            .current-config {{
                background: #f8fafc;
                border-left: 4px solid #10b981;
                padding: 1rem;
                margin-bottom: 1rem;
                border-radius: 0 8px 8px 0;
            }}
            .config-summary {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-top: 1rem;
            }}
            .config-item {{
                text-align: center;
                padding: 1rem;
                background: #f1f5f9;
                border-radius: 8px;
            }}
            .config-value {{
                font-size: 1.2rem;
                font-weight: bold;
                color: #667eea;
            }}
            .config-label {{
                font-size: 0.9rem;
                color: #666;
                margin-top: 0.25rem;
            }}
            .floating-action {{
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
                color: white;
                padding: 1rem;
                border-radius: 50%;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                cursor: pointer;
                font-size: 1.5rem;
                border: none;
                transition: transform 0.3s ease;
            }}
            .floating-action:hover {{
                transform: scale(1.1);
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🤖 AI Model Configuration</h1>
                <p>Configure multiple AI providers for enhanced CMMS capabilities</p>
            </div>
            
            <div class="current-config">
                <h3>Current AI Configuration</h3>
                <div class="config-summary">
                    <div class="config-item">
                        <div class="config-value" id="active-providers">0</div>
                        <div class="config-label">Active Providers</div>
                    </div>
                    <div class="config-item">
                        <div class="config-value" id="default-model">Not Set</div>
                        <div class="config-label">Default Model</div>
                    </div>
                    <div class="config-item">
                        <div class="config-value" id="coding-model">Not Set</div>
                        <div class="config-label">Coding Model</div>
                    </div>
                    <div class="config-item">
                        <div class="config-value" id="total-requests">0</div>
                        <div class="config-label">Requests Today</div>
                    </div>
                </div>
            </div>

            <div class="config-grid">
                <div class="config-card">
                    <h2 class="card-title">Provider Templates</h2>
                    <p>Quick setup with recommended configurations for different use cases:</p>
                    <div style="margin-top: 1rem;">
                        <button class="btn" onclick="setupOptimalConfig()" style="margin-right: 1rem;">🚀 Optimal Setup</button>
                        <button class="btn btn-secondary" onclick="setupCodingFocus()">💻 Coding Focus</button>
                    </div>
                </div>
                
                <div class="config-card">
                    <h2 class="card-title">Usage Analytics</h2>
                    <div id="usage-chart" style="height: 200px; background: #f8fafc; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #666;">
                        Analytics loading...
                    </div>
                </div>
            </div>

            <div class="provider-grid">
    """
    
    # Generate provider cards
    for provider_id, provider_info in PROVIDER_TEMPLATES.items():
        html += f"""
                <div class="provider-card">
                    <div class="provider-header">
                        <div class="provider-name">{provider_info['name']}</div>
                        <div class="provider-status status-inactive" id="status-{provider_id}">Inactive</div>
                    </div>
                    <div class="provider-description">{provider_info['description']}</div>
                    <div class="strengths">
        """
        
        for strength in provider_info['strengths']:
            html += f'<span class="strength-tag">{strength}</span>'
        
        html += f"""
                    </div>
                    <div class="form-group">
                        <label for="api-key-{provider_id}">API Key</label>
                        <input type="password" id="api-key-{provider_id}" placeholder="Enter API key">
                    </div>
                    <div class="form-group">
                        <label for="model-{provider_id}">Model</label>
                        <select id="model-{provider_id}">
        """
        
        for model in provider_info['default_models']:
            html += f'<option value="{model}">{model}</option>'
        
        html += f"""
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="priority-{provider_id}">Priority (1-10)</label>
                        <input type="number" id="priority-{provider_id}" value="5" min="1" max="10">
                    </div>
                    <button class="btn" onclick="configureProvider('{provider_id}')">Configure Provider</button>
                </div>
        """
    
    html += """
            </div>
        </div>
        
        <button class="floating-action" onclick="saveConfiguration()" title="Save All Configurations">
            💾
        </button>

        <script>
            // Load current configuration
            async function loadCurrentConfig() {
                try {
                    const response = await fetch('/ai-config/current');
                    const config = await response.json();
                    updateConfigDisplay(config);
                } catch (error) {
                    console.error('Failed to load configuration:', error);
                }
            }
            
            function updateConfigDisplay(config) {
                document.getElementById('active-providers').textContent = config.active_providers || 0;
                document.getElementById('default-model').textContent = config.default_model || 'Not Set';
                document.getElementById('coding-model').textContent = config.coding_model || 'Not Set';
                document.getElementById('total-requests').textContent = config.requests_today || 0;
            }
            
            async function configureProvider(providerId) {
                const apiKey = document.getElementById(`api-key-${providerId}`).value;
                const model = document.getElementById(`model-${providerId}`).value;
                const priority = document.getElementById(`priority-${providerId}`).value;
                
                if (!apiKey) {
                    alert('Please enter an API key');
                    return;
                }
                
                try {
                    const response = await fetch('/ai-config/provider', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            provider: providerId,
                            api_key: apiKey,
                            model: model,
                            priority: parseInt(priority)
                        })
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        document.getElementById(`status-${providerId}`).textContent = 'Active';
                        document.getElementById(`status-${providerId}`).className = 'provider-status status-active';
                        alert(`${providerId} configured successfully!`);
                    } else {
                        alert(`Configuration failed: ${result.error}`);
                    }
                } catch (error) {
                    alert(`Configuration failed: ${error.message}`);
                }
            }
            
            async function setupOptimalConfig() {
                // Configure multiple providers for optimal performance
                const providers = ['groq', 'openai', 'anthropic'];
                alert('Setting up optimal configuration with multiple providers for redundancy and performance');
            }
            
            async function setupCodingFocus() {
                // Focus on coding-optimized providers
                alert('Setting up coding-focused configuration with Groq as primary provider');
            }
            
            async function saveConfiguration() {
                try {
                    const response = await fetch('/ai-config/save-all', {
                        method: 'POST'
                    });
                    const result = await response.json();
                    if (result.success) {
                        alert('Configuration saved successfully!');
                    }
                } catch (error) {
                    alert(`Save failed: ${error.message}`);
                }
            }
            
            // Load configuration on page load
            loadCurrentConfig();
            
            // Auto-refresh every 30 seconds
            setInterval(loadCurrentConfig, 30000);
        </script>
    </body>
    </html>
    """
    
    return html

@router.get("/current")
async def get_current_config():
    """Get current AI configuration"""
    # In production, load from database
    return {
        "active_providers": len([p for p in user_ai_configs.values() if p.active_providers]),
        "default_model": "groq/llama3-70b-8192",
        "coding_model": "groq/llama3-70b-8192",
        "requests_today": 127,
        "providers": PROVIDER_TEMPLATES
    }

@router.post("/provider")
async def configure_provider(request: Request):
    """Configure a specific AI provider"""
    data = await request.json()
    provider = data.get('provider')
    api_key = data.get('api_key')
    model = data.get('model')
    priority = data.get('priority', 5)
    
    try:
        # Test the provider configuration
        config = AIConfig()
        setattr(config, f"{provider}_api_key", api_key)
        setattr(config, f"{provider}_model", model)
        
        # Create test provider instance
        ai_provider = CentralizedAIProvider(config)
        
        # Test with a simple request
        test_response = await ai_provider.generate(
            message="Test configuration",
            context="test",
            max_tokens=50
        )
        
        if test_response.content:
            return {"success": True, "message": f"Provider {provider} configured successfully"}
        else:
            return {"success": False, "error": "Provider test failed"}
            
    except Exception as e:
        logger.error(f"Provider configuration failed: {str(e)}")
        return {"success": False, "error": str(e)}

@router.post("/save-all")
async def save_all_configuration():
    """Save all AI configurations"""
    try:
        # In production, save to database
        config_file = "ai_user_configs.json"
        with open(config_file, 'w') as f:
            json.dump(user_ai_configs, f, indent=2, default=str)
        
        return {"success": True, "message": "All configurations saved"}
    except Exception as e:
        logger.error(f"Configuration save failed: {str(e)}")
        return {"success": False, "error": str(e)}

@router.get("/test-provider/{provider_name}")
async def test_provider(provider_name: str):
    """Test a specific AI provider with coding task"""
    
    test_prompts = {
        "coding": "Write a Python function to calculate factorial recursively",
        "analysis": "Analyze the maintenance trends for HVAC systems",
        "creative": "Explain quantum computing in simple terms",
        "general": "What are the key principles of predictive maintenance?"
    }
    
    try:
        config = AIConfig()
        # Set provider priority to test specific provider
        config.provider_priority = [provider_name, "fallback"]
        
        ai_provider = CentralizedAIProvider(config)
        
        results = {}
        for task_type, prompt in test_prompts.items():
            try:
                response = await ai_provider.generate(
                    message=prompt,
                    context=task_type,
                    max_tokens=200
                )
                results[task_type] = {
                    "success": True,
                    "response_time": response.response_time_ms,
                    "provider_used": response.provider.value,
                    "confidence": response.confidence
                }
            except Exception as e:
                results[task_type] = {
                    "success": False,
                    "error": str(e)
                }
        
        return {"provider": provider_name, "test_results": results}
        
    except Exception as e:
        logger.error(f"Provider test failed: {str(e)}")
        return {"success": False, "error": str(e)}

# Add routes for Groq-specific coding assistance
@router.post("/groq-code-assistant")
async def groq_code_assistant(request: Request):
    """Specialized Groq-powered coding assistant"""
    data = await request.json()
    task = data.get('task', '')
    code_type = data.get('type', 'general')  # python, javascript, etc.
    
    if not task:
        raise HTTPException(400, "Task description required")
    
    # Create Groq-focused configuration
    config = AIConfig()
    config.provider_priority = ["groq", "openai", "fallback"]
    
    coding_prompts = {
        "python": f"As a Python expert, {task}. Provide production-ready code with error handling and documentation.",
        "javascript": f"As a JavaScript expert, {task}. Use modern ES6+ syntax and best practices.",
        "sql": f"As a SQL expert, {task}. Write optimized queries with proper indexing considerations.",
        "general": f"As a software engineering expert, {task}. Focus on clean, maintainable code."
    }
    
    prompt = coding_prompts.get(code_type, coding_prompts["general"])
    
    try:
        ai_provider = CentralizedAIProvider(config)
        response = await ai_provider.generate(
            message=prompt,
            context="coding",
            system_prompt="You are an expert software engineer with deep knowledge of best practices, optimization, and maintainable code architecture.",
            max_tokens=2000,
            temperature=0.1  # Low temperature for precise code generation
        )
        
        return {
            "success": True,
            "code": response.content,
            "provider": response.provider.value,
            "model": response.model,
            "response_time": response.response_time_ms,
            "confidence": response.confidence,
            "task_type": code_type,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Groq coding assistant failed: {str(e)}")
        return {"success": False, "error": str(e)}

# Export the router
ai_config_router = router