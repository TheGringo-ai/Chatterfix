#!/usr/bin/env python3
"""
ChatterFix AI Orchestrator - Multi-Model Collaborative Intelligence System
Core LLaMA assistant with optional super-intelligent API models
"""

import os
import json
import logging
import asyncio
import time
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass
from enum import Enum
import aiohttp
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

class AIModelType(Enum):
    CORE = "core"          # LLaMA (always available)
    SUPER = "super"        # API models (requires keys)
    FALLBACK = "fallback"  # Basic responses

@dataclass 
class ModelCapability:
    name: str
    type: AIModelType
    available: bool
    api_key_required: bool
    strengths: List[str]
    cost_per_1k_tokens: float
    max_context: int
    response_speed: str  # "fast", "medium", "slow"
    
class AIOrchestrator:
    """Multi-model AI orchestrator with LLaMA core and optional super models"""
    
    def __init__(self):
        self.models = self._initialize_models()
        self.collaborative_sessions = {}
        self.model_performance = {}
        self._setup_llama()
        
    def _initialize_models(self) -> Dict[str, ModelCapability]:
        """Initialize all available AI models"""
        
        models = {
            # Core LLaMA (always available)
            "llama3.2:3b": ModelCapability(
                name="LLaMA 3.2 3B",
                type=AIModelType.CORE,
                available=self._check_llama_available(),
                api_key_required=False,
                strengths=["maintenance", "diagnostics", "code_generation", "reasoning"],
                cost_per_1k_tokens=0.0,  # Local model
                max_context=4096,
                response_speed="fast"
            ),
            
            "llama3.2:1b": ModelCapability(
                name="LLaMA 3.2 1B", 
                type=AIModelType.CORE,
                available=self._check_llama_available(),
                api_key_required=False,
                strengths=["quick_responses", "chat", "basic_analysis"],
                cost_per_1k_tokens=0.0,
                max_context=2048,
                response_speed="very_fast"
            ),
            
            # Super Intelligence Models (API)
            "grok-2": ModelCapability(
                name="Grok-2 (X.AI)",
                type=AIModelType.SUPER,
                available=bool(os.getenv("XAI_API_KEY") or os.getenv("GROK_API_KEY")),
                api_key_required=True,
                strengths=["reasoning", "real_time_data", "humor", "advanced_analysis"],
                cost_per_1k_tokens=0.002,
                max_context=131072,
                response_speed="medium"
            ),
            
            "gpt-4": ModelCapability(
                name="GPT-4 (OpenAI)",
                type=AIModelType.SUPER, 
                available=bool(os.getenv("OPENAI_API_KEY")),
                api_key_required=True,
                strengths=["complex_reasoning", "code_review", "creative_tasks"],
                cost_per_1k_tokens=0.03,
                max_context=8192,
                response_speed="slow"
            ),
            
            "claude-3-sonnet": ModelCapability(
                name="Claude 3 Sonnet (Anthropic)",
                type=AIModelType.SUPER,
                available=bool(os.getenv("ANTHROPIC_API_KEY")),
                api_key_required=True, 
                strengths=["safety", "analysis", "long_context", "structured_output"],
                cost_per_1k_tokens=0.015,
                max_context=200000,
                response_speed="medium"
            ),
            
            "gemini-pro": ModelCapability(
                name="Gemini Pro (Google)",
                type=AIModelType.SUPER,
                available=bool(os.getenv("GOOGLE_API_KEY")),
                api_key_required=True,
                strengths=["multimodal", "math", "science", "code_execution"],
                cost_per_1k_tokens=0.001,
                max_context=30720,
                response_speed="fast"
            ),
            
            "llama3-70b": ModelCapability(
                name="LLaMA 3 70B (Groq)",
                type=AIModelType.SUPER,
                available=bool(os.getenv("GROQ_API_KEY")),
                api_key_required=True,
                strengths=["fast_inference", "code_generation", "reasoning"],
                cost_per_1k_tokens=0.0008,
                max_context=8192,
                response_speed="very_fast"
            ),
            
            "command-r-plus": ModelCapability(
                name="Command R+ (Cohere)",
                type=AIModelType.SUPER,
                available=bool(os.getenv("COHERE_API_KEY")),
                api_key_required=True,
                strengths=["rag", "enterprise", "multilingual"],
                cost_per_1k_tokens=0.003,
                max_context=128000,
                response_speed="medium"
            )
        }
        
        return models
    
    def _setup_llama(self):
        """Ensure LLaMA is available locally"""
        try:
            # Check if Ollama is running
            result = subprocess.run(['curl', '-s', 'http://localhost:11434/api/tags'], 
                                 capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                logger.info("✅ LLaMA (Ollama) is running and available")
                return True
        except Exception as e:
            logger.warning(f"LLaMA not available locally: {e}")
            
        # Try to start Ollama if not running
        try:
            subprocess.Popen(['ollama', 'serve'], 
                           stdout=subprocess.DEVNULL, 
                           stderr=subprocess.DEVNULL)
            time.sleep(3)  # Give it time to start
            logger.info("🚀 Started LLaMA (Ollama) service")
        except Exception as e:
            logger.error(f"Failed to start LLaMA: {e}")
            
        return self._check_llama_available()
    
    def _check_llama_available(self) -> bool:
        """Check if LLaMA is available"""
        try:
            result = subprocess.run(['curl', '-s', 'http://localhost:11434/api/tags'], 
                                 capture_output=True, text=True, timeout=2)
            return result.returncode == 0
        except:
            return False
    
    async def intelligent_response(
        self, 
        message: str, 
        context: str = "general",
        user_preference: Optional[str] = None,
        complexity_level: str = "medium"
    ) -> Dict[str, Any]:
        """Generate intelligent response using best available model(s)"""
        
        # Analyze message to determine optimal approach
        analysis = await self._analyze_request(message, context, complexity_level)
        
        # Select best model(s) for the task
        selected_models = self._select_optimal_models(analysis)
        
        # Generate response(s)
        if len(selected_models) == 1:
            # Single model response
            response = await self._generate_single_response(
                selected_models[0], message, context, analysis
            )
        else:
            # Multi-model collaborative response
            response = await self._generate_collaborative_response(
                selected_models, message, context, analysis
            )
        
        return response
    
    async def _analyze_request(
        self, 
        message: str, 
        context: str, 
        complexity_level: str
    ) -> Dict[str, Any]:
        """Analyze request to determine optimal AI strategy"""
        
        message_lower = message.lower()
        
        analysis = {
            "complexity": complexity_level,
            "task_type": "general",
            "requires_reasoning": False,
            "requires_code": False,
            "requires_creativity": False,
            "requires_real_time": False,
            "requires_multimodal": False,
            "safety_critical": False,
            "estimated_tokens": len(message.split()) * 1.5,  # Rough estimation
            "urgency": "normal"
        }
        
        # Task type analysis
        if any(word in message_lower for word in ["code", "script", "function", "programming"]):
            analysis["task_type"] = "coding"
            analysis["requires_code"] = True
            
        elif any(word in message_lower for word in ["diagnose", "troubleshoot", "analyze", "debug"]):
            analysis["task_type"] = "diagnostic"
            analysis["requires_reasoning"] = True
            
        elif any(word in message_lower for word in ["create", "design", "generate", "invent"]):
            analysis["task_type"] = "creative"
            analysis["requires_creativity"] = True
            
        elif any(word in message_lower for word in ["safety", "danger", "emergency", "critical"]):
            analysis["task_type"] = "safety"
            analysis["safety_critical"] = True
            analysis["urgency"] = "high"
            
        # Complexity indicators
        if any(word in message_lower for word in ["complex", "advanced", "sophisticated", "detailed"]):
            analysis["complexity"] = "high"
            
        elif any(word in message_lower for word in ["simple", "basic", "quick", "brief"]):
            analysis["complexity"] = "low"
            
        # Real-time data needs
        if any(word in message_lower for word in ["current", "latest", "now", "today", "real-time"]):
            analysis["requires_real_time"] = True
            
        return analysis
    
    def _select_optimal_models(self, analysis: Dict[str, Any]) -> List[str]:
        """Select optimal model(s) based on request analysis"""
        
        available_models = {name: model for name, model in self.models.items() if model.available}
        
        if not available_models:
            return ["fallback"]
            
        # Always prefer core LLaMA for basic tasks
        if analysis["complexity"] == "low" and not analysis["requires_real_time"]:
            llama_models = [name for name, model in available_models.items() 
                          if model.type == AIModelType.CORE]
            if llama_models:
                return [llama_models[0]]  # Use fastest LLaMA
        
        # Task-specific model selection
        if analysis["task_type"] == "coding":
            preferred = ["llama3-70b", "gpt-4", "gemini-pro", "llama3.2:3b"]
            
        elif analysis["task_type"] == "creative":
            preferred = ["gpt-4", "claude-3-sonnet", "grok-2", "llama3.2:3b"]
            
        elif analysis["safety_critical"]:
            preferred = ["claude-3-sonnet", "gpt-4", "llama3.2:3b"]
            
        elif analysis["requires_real_time"]:
            preferred = ["grok-2", "gemini-pro", "llama3.2:3b"]
            
        elif analysis["complexity"] == "high":
            # Use collaborative approach for complex tasks
            preferred = ["gpt-4", "claude-3-sonnet", "llama3.2:3b"]
            collaborative_candidates = [name for name in preferred if name in available_models]
            if len(collaborative_candidates) >= 2:
                return collaborative_candidates[:2]  # Use top 2 available
            
        else:
            preferred = ["llama3.2:3b", "grok-2", "llama3-70b", "gemini-pro"]
        
        # Select first available from preferred list
        for model_name in preferred:
            if model_name in available_models:
                return [model_name]
        
        # Fallback to any available core model
        core_models = [name for name, model in available_models.items() 
                      if model.type == AIModelType.CORE]
        if core_models:
            return [core_models[0]]
            
        return ["fallback"]
    
    async def _generate_single_response(
        self, 
        model_name: str, 
        message: str, 
        context: str, 
        analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Generate response from single model"""
        
        start_time = time.time()
        
        try:
            if model_name in ["llama3.2:3b", "llama3.2:1b"]:
                response_content = await self._query_llama(model_name, message, context, analysis)
                
            elif model_name == "grok-2":
                response_content = await self._query_grok(message, context, analysis)
                
            elif model_name == "gpt-4":
                response_content = await self._query_openai(message, context, analysis)
                
            elif model_name == "claude-3-sonnet":
                response_content = await self._query_anthropic(message, context, analysis)
                
            elif model_name == "gemini-pro":
                response_content = await self._query_google(message, context, analysis)
                
            elif model_name == "llama3-70b":
                response_content = await self._query_groq(message, context, analysis)
                
            else:
                response_content = self._generate_fallback_response(message, context)
            
            response_time = int((time.time() - start_time) * 1000)
            
            return {
                "response": response_content,
                "model_used": self.models[model_name].name if model_name in self.models else model_name,
                "model_type": self.models[model_name].type.value if model_name in self.models else "fallback",
                "response_time_ms": response_time,
                "confidence": 0.95 if model_name != "fallback" else 0.6,
                "collaborative": False,
                "cost_estimate": self._calculate_cost(model_name, analysis["estimated_tokens"]),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Single response generation failed for {model_name}: {e}")
            return await self._generate_single_response("fallback", message, context, analysis)
    
    async def _generate_collaborative_response(
        self, 
        model_names: List[str], 
        message: str, 
        context: str, 
        analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Generate collaborative response from multiple models"""
        
        start_time = time.time()
        responses = []
        
        # Generate responses from all models concurrently
        tasks = []
        for model_name in model_names:
            task = self._generate_single_response(model_name, message, context, analysis)
            tasks.append(task)
        
        model_responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process responses
        valid_responses = []
        for i, response in enumerate(model_responses):
            if isinstance(response, dict) and not isinstance(response, Exception):
                response["model_rank"] = i + 1
                valid_responses.append(response)
        
        if not valid_responses:
            return await self._generate_single_response("fallback", message, context, analysis)
        
        # Synthesize collaborative response
        synthesized_response = await self._synthesize_responses(valid_responses, analysis)
        
        total_time = int((time.time() - start_time) * 1000)
        
        return {
            "response": synthesized_response,
            "model_used": " + ".join([r.get("model_used", "Unknown") for r in valid_responses]),
            "model_type": "collaborative",
            "response_time_ms": total_time,
            "confidence": 0.98,  # Higher confidence for collaborative responses
            "collaborative": True,
            "individual_responses": valid_responses,
            "synthesis_method": "intelligent_merge",
            "cost_estimate": sum(r.get("cost_estimate", 0) for r in valid_responses),
            "timestamp": datetime.now().isoformat()
        }
    
    async def _query_llama(
        self, 
        model_name: str, 
        message: str, 
        context: str, 
        analysis: Dict[str, Any]
    ) -> str:
        """Query local LLaMA model"""
        
        # Enhanced system prompt based on analysis
        system_prompt = self._create_context_prompt(context, analysis)
        
        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ],
            "stream": False,
            "options": {
                "temperature": 0.1 if analysis["safety_critical"] else 0.3,
                "top_p": 0.9,
                "max_tokens": 2000 if analysis["complexity"] == "high" else 1000
            }
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "http://localhost:11434/api/chat",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    return result["message"]["content"].strip()
                else:
                    raise Exception(f"LLaMA API error: {response.status}")
    
    async def _query_grok(self, message: str, context: str, analysis: Dict[str, Any]) -> str:
        """Query Grok API"""
        api_key = os.getenv("XAI_API_KEY") or os.getenv("GROK_API_KEY")
        if not api_key:
            raise Exception("Grok API key not found")
            
        # Implementation for Grok API call
        return "Grok response placeholder - implement API call"
    
    async def _query_openai(self, message: str, context: str, analysis: Dict[str, Any]) -> str:
        """Query OpenAI API"""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise Exception("OpenAI API key not found")
            
        # Implementation for OpenAI API call
        return "OpenAI response placeholder - implement API call"
    
    async def _query_anthropic(self, message: str, context: str, analysis: Dict[str, Any]) -> str:
        """Query Anthropic API"""
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise Exception("Anthropic API key not found")
            
        # Implementation for Anthropic API call
        return "Anthropic response placeholder - implement API call"
    
    async def _query_google(self, message: str, context: str, analysis: Dict[str, Any]) -> str:
        """Query Google Gemini API"""
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise Exception("Google API key not found")
            
        # Implementation for Google API call
        return "Google response placeholder - implement API call"
    
    async def _query_groq(self, message: str, context: str, analysis: Dict[str, Any]) -> str:
        """Query Groq API"""
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise Exception("Groq API key not found")
            
        # Implementation for Groq API call  
        return "Groq response placeholder - implement API call"
    
    def _create_context_prompt(self, context: str, analysis: Dict[str, Any]) -> str:
        """Create context-aware system prompt"""
        
        base_prompt = """You are ChatterFix AI, an expert industrial maintenance assistant with advanced capabilities."""
        
        if analysis["task_type"] == "coding":
            return base_prompt + " You specialize in generating production-ready code with proper error handling and documentation."
            
        elif analysis["task_type"] == "diagnostic":
            return base_prompt + " You provide systematic diagnostic procedures with specific measurements and technical analysis."
            
        elif analysis["safety_critical"]:
            return base_prompt + " SAFETY IS PARAMOUNT. Always prioritize OSHA compliance and proper safety procedures."
            
        else:
            return base_prompt + " Provide practical, actionable advice for industrial maintenance and operations."
    
    async def _synthesize_responses(
        self, 
        responses: List[Dict[str, Any]], 
        analysis: Dict[str, Any]
    ) -> str:
        """Synthesize multiple responses into a cohesive answer"""
        
        if len(responses) == 1:
            return responses[0]["response"]
        
        # Simple synthesis - combine best parts from each response
        combined_content = []
        
        for i, response in enumerate(responses):
            model_name = response.get("model_used", f"Model {i+1}")
            content = response.get("response", "")
            
            if content and len(content.strip()) > 10:  # Valid response
                combined_content.append(f"**{model_name} Analysis:**\n{content}\n")
        
        if not combined_content:
            return "Unable to generate collaborative response."
        
        # Add synthesis header
        synthesis = f"🤖 **COLLABORATIVE AI ANALYSIS** ({len(responses)} models)\n\n"
        synthesis += "\n".join(combined_content)
        
        # Add confidence note
        synthesis += f"\n**Synthesis:** This collaborative response combines insights from {len(responses)} AI models for enhanced accuracy and completeness."
        
        return synthesis
    
    def _calculate_cost(self, model_name: str, estimated_tokens: float) -> float:
        """Calculate estimated cost for the request"""
        if model_name in self.models:
            model = self.models[model_name]
            return (estimated_tokens / 1000) * model.cost_per_1k_tokens
        return 0.0
    
    def _generate_fallback_response(self, message: str, context: str) -> str:
        """Generate basic fallback response"""
        return """🔧 ChatterFix AI Assistant

I'm your industrial maintenance AI assistant. While some advanced features may be limited, I can help with:

• Equipment diagnostics and troubleshooting
• Maintenance procedures and safety protocols  
• Technical documentation and analysis
• Code generation and automation scripts

Please describe your maintenance challenge and I'll provide the best guidance available."""

    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        
        available_models = {}
        super_models = {}
        
        for name, model in self.models.items():
            model_info = {
                "name": model.name,
                "type": model.type.value,
                "available": model.available,
                "strengths": model.strengths,
                "speed": model.response_speed,
                "cost": model.cost_per_1k_tokens
            }
            
            if model.available:
                available_models[name] = model_info
                
            if model.type == AIModelType.SUPER and model.available:
                super_models[name] = model_info
        
        return {
            "system_status": "operational",
            "core_ai": "LLaMA (always available)",
            "available_models": len(available_models),
            "super_intelligence_models": len(super_models),
            "collaborative_mode": len(super_models) > 0,
            "models": available_models,
            "capabilities": [
                "Industrial Maintenance Expertise",
                "Code Generation & Automation", 
                "Diagnostic Analysis",
                "Safety Protocol Compliance",
                "Multi-Model Collaboration" if super_models else "Single Model Operation",
                "Real-time Learning & Adaptation"
            ],
            "cost_optimization": "Automatic model selection based on task complexity",
            "response_quality": "Enhanced" if super_models else "Standard"
        }

# Global orchestrator instance
ai_orchestrator = AIOrchestrator()

# Convenience functions
async def intelligent_chat(
    message: str, 
    context: str = "general", 
    complexity: str = "medium"
) -> Dict[str, Any]:
    """Main chat function using intelligent model selection"""
    return await ai_orchestrator.intelligent_response(message, context, complexity_level=complexity)

async def get_ai_status() -> Dict[str, Any]:
    """Get comprehensive AI system status"""
    return ai_orchestrator.get_system_status()

# Export main components
__all__ = [
    'AIOrchestrator',
    'ai_orchestrator', 
    'intelligent_chat',
    'get_ai_status'
]