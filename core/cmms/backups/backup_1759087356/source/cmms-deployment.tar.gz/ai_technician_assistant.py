#!/usr/bin/env python3
"""
ChatterFix AI Technician Assistant - ChatGPT + LLaMA Integration
Advanced natural language processing for maintenance workflows
Surpasses MaintainX and Fiix with intelligent automation
"""

import os
import json
import re
import logging
from typing import Dict, List, Any, Optional, Union, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import asyncio
from ai_model_provider import CentralizedAIProvider, AIResponse, AIProvider
from workorders import WorkOrder
from pydantic import BaseModel

logger = logging.getLogger(__name__)

class IntentType(Enum):
    CREATE_WORK_ORDER = "create_work_order"
    DIAGNOSE_ISSUE = "diagnose_issue"
    LOOKUP_PART = "lookup_part"
    COMPLETE_ORDER = "complete_order"
    UPDATE_STATUS = "update_status"
    SAFETY_GUIDANCE = "safety_guidance"
    GENERATE_SOP = "generate_sop"
    LOOKUP_ASSET = "lookup_asset"
    SCHEDULE_MAINTENANCE = "schedule_maintenance"
    VOICE_COMMAND = "voice_command"
    UNKNOWN = "unknown"

@dataclass
class ExtractedData:
    """Structured data extracted from natural language"""
    intent: IntentType
    confidence: float
    asset_id: Optional[str] = None
    asset_name: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    urgency: Optional[str] = None
    problem_type: Optional[str] = None
    symptoms: List[str] = None
    part_number: Optional[str] = None
    part_description: Optional[str] = None
    estimated_duration: Optional[str] = None
    required_skills: List[str] = None
    tools_needed: List[str] = None
    downtime_impact: Optional[str] = None
    preventive_action: Optional[str] = None
    work_instructions: Optional[str] = None
    safety_concern: bool = False
    equipment_type: Optional[str] = None
    work_order_id: Optional[str] = None
    technician_id: Optional[str] = None
    raw_input: Optional[str] = None

class AITechnicianAssistant:
    """Advanced AI assistant for maintenance technicians"""
    
    def __init__(self, ai_provider: Optional[CentralizedAIProvider] = None):
        self.ai_provider = ai_provider or CentralizedAIProvider()
        self.asset_registry = self._load_asset_registry()
        self.parts_database = self._load_parts_database()
        self.safety_protocols = self._load_safety_protocols()
        self.diagnostic_knowledge = self._load_diagnostic_knowledge()
        
    def _load_asset_registry(self) -> Dict[str, Any]:
        """Load asset registry with equipment details"""
        return {
            "conveyor_belt_1": {
                "name": "Main Conveyor Belt #1",
                "location": "Plant A - Production Line 1",
                "type": "conveyor_system",
                "manufacturer": "BeltCorp",
                "model": "BC-2000",
                "common_issues": ["belt_misalignment", "motor_vibration", "bearing_wear"],
                "critical_parts": ["drive_motor", "idler_rollers", "belt_tensioner"]
            },
            "boiler_2": {
                "name": "Steam Boiler #2",
                "location": "Plant A - Utility Room",
                "type": "boiler",
                "manufacturer": "SteamTech",
                "model": "ST-500",
                "common_issues": ["pressure_regulation", "flame_failure", "water_level"],
                "critical_parts": ["burner_assembly", "pressure_valve", "water_pump"]
            },
            "pump_3": {
                "name": "Cooling Water Pump #3",
                "location": "Building B - Mechanical Room",
                "type": "centrifugal_pump",
                "manufacturer": "FlowMax",
                "model": "FM-150",
                "common_issues": ["seal_leak", "cavitation", "impeller_wear"],
                "critical_parts": ["mechanical_seal", "impeller", "bearing_housing"]
            }
        }
    
    def _load_parts_database(self) -> Dict[str, Any]:
        """Load parts database with inventory"""
        return {
            "mechanical_seal_fm150": {
                "part_number": "MS-FM150-01",
                "description": "Mechanical Seal for FlowMax FM-150 Pump",
                "stock_quantity": 5,
                "reorder_point": 2,
                "supplier": "SealCorp",
                "cost": 125.50,
                "lead_time_days": 7,
                "compatible_assets": ["pump_3"]
            },
            "drive_belt_bc2000": {
                "part_number": "DB-BC2000-02",
                "description": "Drive Belt for BeltCorp BC-2000 Conveyor",
                "stock_quantity": 2,
                "reorder_point": 1,
                "supplier": "BeltCorp",
                "cost": 450.00,
                "lead_time_days": 14,
                "compatible_assets": ["conveyor_belt_1"]
            },
            "pressure_valve_st500": {
                "part_number": "PV-ST500-03",
                "description": "Safety Pressure Valve for SteamTech ST-500",
                "stock_quantity": 1,
                "reorder_point": 1,
                "supplier": "SteamTech",
                "cost": 275.00,
                "lead_time_days": 10,
                "compatible_assets": ["boiler_2"]
            }
        }
    
    def _load_safety_protocols(self) -> Dict[str, List[str]]:
        """Load safety protocols by equipment type"""
        return {
            "boiler": [
                "Ensure proper PPE: heat-resistant gloves, safety glasses",
                "Verify system is depressurized before maintenance",
                "Follow lockout/tagout procedures",
                "Check for gas leaks before ignition",
                "Maintain proper ventilation"
            ],
            "conveyor_system": [
                "Engage emergency stop before maintenance",
                "Follow lockout/tagout procedures",
                "Verify all energy sources are isolated",
                "Use fall protection if working at height",
                "Clear area of personnel during testing"
            ],
            "centrifugal_pump": [
                "Isolate electrical supply",
                "Close inlet and outlet valves",
                "Drain system if required",
                "Use appropriate lifting equipment for heavy components",
                "Check for hazardous chemicals"
            ]
        }
    
    def _load_diagnostic_knowledge(self) -> Dict[str, Dict]:
        """Load diagnostic knowledge base"""
        return {
            "belt_misalignment": {
                "symptoms": ["rubbing noise", "uneven wear", "belt tracking issues"],
                "causes": ["improper tension", "worn rollers", "frame misalignment"],
                "solutions": ["adjust tension", "replace rollers", "realign frame"],
                "tools_required": ["tension gauge", "alignment laser", "wrench set"]
            },
            "pump_cavitation": {
                "symptoms": ["loud noise", "vibration", "reduced flow", "pitting on impeller"],
                "causes": ["insufficient NPSH", "blocked suction", "high fluid temperature"],
                "solutions": ["check suction conditions", "clear blockages", "reduce temperature"],
                "tools_required": ["pressure gauge", "flow meter", "temperature probe"]
            },
            "motor_vibration": {
                "symptoms": ["excessive vibration", "noise", "heat buildup", "bearing wear"],
                "causes": ["unbalanced rotor", "misalignment", "bearing failure", "loose mounting"],
                "solutions": ["balance rotor", "realign coupling", "replace bearings", "tighten bolts"],
                "tools_required": ["vibration analyzer", "dial indicator", "torque wrench"]
            }
        }

    async def process_natural_language(self, input_text: str, user_context: Dict = None) -> ExtractedData:
        """Process natural language input and extract structured data"""
        
        # Enhanced system prompt for ChatterFix AI
        system_prompt = """You are ChatChatterFix, the expert AI technician assistant for ChatterFix CMMS.
        
You excel at understanding complex maintenance requests, technical terminology, and extracting comprehensive structured information. You have deep knowledge of industrial equipment, failure modes, and maintenance best practices.

Parse the following technician input and return a JSON response with these enhanced fields:

{
    "intent": "create_work_order|diagnose_issue|lookup_part|complete_order|update_status|safety_guidance|generate_sop|lookup_asset|schedule_maintenance|voice_command",
    "confidence": 0.0-1.0,
    "asset_id": "extracted_asset_identifier",
    "asset_name": "full_asset_name", 
    "location": "building/area/zone/department",
    "description": "detailed_technical_problem_description",
    "priority": "low|medium|high|critical",
    "urgency": "routine|urgent|emergency|immediate",
    "problem_type": "mechanical|electrical|hydraulic|pneumatic|thermal|software|structural|process",
    "symptoms": ["specific", "observable", "symptoms"],
    "part_number": "if_specific_part_mentioned",
    "part_description": "detailed_part_description",
    "safety_concern": true/false,
    "equipment_type": "pump|motor|conveyor|boiler|valve|compressor|generator|hvac|packaging|injection_molding|cnc|robot|plc",
    "estimated_duration": "time_estimate_if_determinable",
    "required_skills": ["electrical", "mechanical", "hydraulic", "etc"],
    "tools_needed": ["specific", "tools", "if_mentioned"],
    "downtime_impact": "none|low|medium|high|critical",
    "preventive_action": "suggested_prevention_if_applicable",
    "work_instructions": "step_by_step_if_determinable"
}

Equipment Knowledge Base:
- Conveyor systems: belt_conveyor_1, roller_conveyor_2, chain_conveyor_3
- Pumps: centrifugal_pump_1, hydraulic_pump_2, coolant_pump_3  
- Motors: ac_motor_1, servo_motor_2, stepper_motor_3
- Compressors: air_compressor_1, refrigeration_compressor_2
- HVAC: hvac_unit_1, exhaust_fan_2, heating_boiler_3
- Generators: emergency_generator_1, backup_generator_2
- Packaging: packaging_machine_1, labeling_machine_2
- Production: injection_molding_1, cnc_machine_2, robotic_arm_3

Common failure modes: bearing wear, seal leakage, belt misalignment, motor overheating, valve sticking, sensor malfunction, lubrication issues, electrical faults, vibration, contamination.

Safety priorities: MANDATORY safety guidance for all maintenance work:
- Electrical hazards: Arc flash, shock, electrocution - require PPE, LOTO, voltage testing
- Confined spaces: Permit required, atmospheric testing, ventilation, attendant
- Chemical exposure: SDS review, proper PPE, spill containment, eye wash stations
- Hot surfaces: Thermal burns, proper gloves, cooling time requirements
- Rotating equipment: Lockout/tagout mandatory, guards in place, no loose clothing
- Pressure systems: Depressurization required, pressure testing, relief valves
- Fall protection: Harnesses for work >6ft, guardrails, ladder safety
- LOTO procedures: Energy isolation, verification, authorized personnel only
- Arc flash boundaries: PPE categories, incident energy calculations, approach limits
- Permit-required confined spaces: Atmospheric monitoring, emergency procedures"""

        user_prompt = f"""Technician Input: "{input_text}"

Parse this request and extract maintenance information. Be specific about asset identification and problem classification."""

        try:
            # Query the AI provider
            response = await self.ai_provider.query_provider(
                prompt=user_prompt,
                system_context=system_prompt,
                provider_type=AIProvider.LLAMA
            )
            
            # Try to parse JSON response
            try:
                parsed_data = json.loads(response.content)
                extracted = ExtractedData(
                    intent=IntentType(parsed_data.get("intent", "unknown")),
                    confidence=parsed_data.get("confidence", 0.5),
                    asset_id=parsed_data.get("asset_id"),
                    asset_name=parsed_data.get("asset_name"),
                    location=parsed_data.get("location"),
                    description=parsed_data.get("description"),
                    priority=parsed_data.get("priority"),
                    urgency=parsed_data.get("urgency"),
                    problem_type=parsed_data.get("problem_type"),
                    symptoms=parsed_data.get("symptoms", []),
                    part_number=parsed_data.get("part_number"),
                    part_description=parsed_data.get("part_description"),
                    safety_concern=parsed_data.get("safety_concern", False),
                    equipment_type=parsed_data.get("equipment_type"),
                    estimated_duration=parsed_data.get("estimated_duration"),
                    required_skills=parsed_data.get("required_skills", []),
                    tools_needed=parsed_data.get("tools_needed", []),
                    downtime_impact=parsed_data.get("downtime_impact"),
                    preventive_action=parsed_data.get("preventive_action"),
                    work_instructions=parsed_data.get("work_instructions"),
                    raw_input=input_text
                )
                
            except json.JSONDecodeError:
                # Fallback to rule-based parsing if AI response isn't JSON
                extracted = self._fallback_parse(input_text, response.content)
                
        except Exception as e:
            logger.error(f"AI processing failed: {e}")
            extracted = self._fallback_parse(input_text, "")
            
        # Enhance with asset registry lookup
        extracted = self._enhance_with_asset_data(extracted)
        
        return extracted

    def _fallback_parse(self, input_text: str, ai_response: str) -> ExtractedData:
        """Fallback rule-based parsing when AI fails"""
        text_lower = input_text.lower()
        
        # Intent detection
        intent = IntentType.UNKNOWN
        if any(word in text_lower for word in ["create", "new", "issue", "problem", "broken", "failed"]):
            intent = IntentType.CREATE_WORK_ORDER
        elif any(word in text_lower for word in ["diagnose", "troubleshoot", "why", "cause", "what's wrong"]):
            intent = IntentType.DIAGNOSE_ISSUE
        elif any(word in text_lower for word in ["part", "component", "replace", "spare"]):
            intent = IntentType.LOOKUP_PART
        elif any(word in text_lower for word in ["complete", "done", "finished", "close"]):
            intent = IntentType.COMPLETE_ORDER
            
        # Priority detection  
        priority = "medium"
        if any(word in text_lower for word in ["emergency", "critical", "urgent", "down", "stopped"]):
            priority = "critical"
        elif any(word in text_lower for word in ["high", "important", "asap"]):
            priority = "high"
        elif any(word in text_lower for word in ["low", "routine", "when possible"]):
            priority = "low"
            
        # Asset detection
        asset_id = None
        for asset_key in self.asset_registry:
            asset_data = self.asset_registry[asset_key]
            if asset_key.replace("_", " ") in text_lower or asset_data["name"].lower() in text_lower:
                asset_id = asset_key
                break
                
        # Safety detection
        safety_concern = any(word in text_lower for word in [
            "danger", "safety", "leak", "fire", "explosion", "electrical", "shock", "burn"
        ])
        
        return ExtractedData(
            intent=intent,
            confidence=0.6,
            asset_id=asset_id,
            description=input_text,
            priority=priority,
            safety_concern=safety_concern,
            raw_input=input_text
        )

    def _enhance_with_asset_data(self, extracted: ExtractedData) -> ExtractedData:
        """Enhance extracted data with asset registry information"""
        if extracted.asset_id and extracted.asset_id in self.asset_registry:
            asset_data = self.asset_registry[extracted.asset_id]
            extracted.asset_name = extracted.asset_name or asset_data["name"]
            extracted.location = extracted.location or asset_data["location"]
            extracted.equipment_type = extracted.equipment_type or asset_data["type"]
            
        return extracted

    async def create_work_order_from_nl(self, extracted: ExtractedData) -> Dict[str, Any]:
        """Create work order from natural language extraction"""
        work_order_id = f"WO-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Enhanced description with AI insights
        enhanced_description = await self._enhance_description(extracted)
        
        work_order = {
            "id": work_order_id,
            "title": f"{extracted.asset_name or 'Asset'} - {extracted.problem_type or 'Maintenance'} Issue",
            "description": enhanced_description,
            "asset_id": extracted.asset_id or "unknown",
            "type": "reactive",  # Could be enhanced to determine type
            "priority": extracted.priority or "medium",
            "status": "open",
            "created_date": datetime.now().isoformat(),
            "created_by": "ai_assistant",
            "estimated_hours": self._estimate_hours(extracted),
            "safety_notes": self._get_safety_notes(extracted)
        }
        
        return {
            "work_order": work_order,
            "ai_insights": {
                "confidence": extracted.confidence,
                "suggested_parts": self._suggest_parts(extracted),
                "safety_alerts": self._get_safety_alerts(extracted),
                "estimated_completion": self._estimate_completion(extracted)
            }
        }

    async def _enhance_description(self, extracted: ExtractedData) -> str:
        """Use AI to enhance work order description"""
        if not extracted.description:
            return "Maintenance required"
            
        enhancement_prompt = f"""Enhance this maintenance description with technical details:
        
Original: {extracted.description}
Asset: {extracted.asset_name}
Equipment Type: {extracted.equipment_type}
Symptoms: {extracted.symptoms}

Provide a clear, technical description suitable for a work order."""

        try:
            response = await self.ai_provider.query_provider(
                prompt=enhancement_prompt,
                system_context="You are a maintenance expert. Provide clear, actionable work order descriptions.",
                provider_type=AIProvider.LLAMA
            )
            return response.content if response else extracted.description
        except:
            return extracted.description

    def _estimate_hours(self, extracted: ExtractedData) -> float:
        """Estimate work hours based on problem type and asset"""
        base_hours = 2.0
        
        # Adjust based on equipment type
        equipment_multipliers = {
            "boiler": 3.0,
            "conveyor_system": 2.5, 
            "centrifugal_pump": 2.0,
            "motor": 1.5
        }
        
        # Adjust based on priority
        priority_multipliers = {
            "critical": 1.5,
            "high": 1.2,
            "medium": 1.0,
            "low": 0.8
        }
        
        multiplier = equipment_multipliers.get(extracted.equipment_type, 1.0)
        multiplier *= priority_multipliers.get(extracted.priority, 1.0)
        
        return round(base_hours * multiplier, 1)

    def _suggest_parts(self, extracted: ExtractedData) -> List[Dict]:
        """Suggest relevant parts based on problem and asset"""
        if not extracted.asset_id:
            return []
            
        suggested_parts = []
        for part_key, part_data in self.parts_database.items():
            if extracted.asset_id in part_data.get("compatible_assets", []):
                # Check if symptoms match common issues
                if extracted.symptoms:
                    symptoms_text = " ".join(extracted.symptoms).lower()
                    part_desc_lower = part_data["description"].lower()
                    
                    # Simple relevance scoring
                    relevance_score = 0
                    for symptom in extracted.symptoms:
                        if any(keyword in part_desc_lower for keyword in symptom.lower().split()):
                            relevance_score += 1
                            
                    if relevance_score > 0:
                        suggested_parts.append({
                            "part_number": part_data["part_number"],
                            "description": part_data["description"],
                            "stock_quantity": part_data["stock_quantity"],
                            "cost": part_data["cost"],
                            "relevance_score": relevance_score
                        })
        
        # Sort by relevance score
        return sorted(suggested_parts, key=lambda x: x["relevance_score"], reverse=True)[:3]

    def _get_safety_notes(self, extracted: ExtractedData) -> List[str]:
        """Get safety notes for the equipment type"""
        if extracted.equipment_type in self.safety_protocols:
            return self.safety_protocols[extracted.equipment_type]
        return ["Follow standard safety protocols", "Use appropriate PPE"]

    def _get_safety_alerts(self, extracted: ExtractedData) -> List[str]:
        """Generate safety alerts based on the issue"""
        alerts = []
        
        if extracted.safety_concern:
            alerts.append("⚠️ SAFETY CONCERN IDENTIFIED - Immediate attention required")
            
        if extracted.priority == "critical":
            alerts.append("🚨 CRITICAL PRIORITY - Production impact likely")
            
        if extracted.equipment_type == "boiler":
            alerts.append("🔥 High temperature equipment - Heat protection required")
            
        if any(symptom in str(extracted.symptoms).lower() for symptom in ["leak", "fluid", "chemical"]):
            alerts.append("🧪 Potential fluid/chemical exposure - Use appropriate PPE")
            
        return alerts

    def _estimate_completion(self, extracted: ExtractedData) -> str:
        """Estimate completion timeframe"""
        hours = self._estimate_hours(extracted)
        
        if hours <= 1:
            return "Within 1 hour"
        elif hours <= 4:
            return "Same day"
        elif hours <= 8:
            return "1-2 days"
        else:
            return "2-5 days"

    async def diagnose_issue(self, extracted: ExtractedData) -> Dict[str, Any]:
        """Provide AI-powered diagnostic assistance"""
        
        # Look up known diagnostic patterns
        diagnostic_info = None
        if extracted.symptoms:
            for issue_key, issue_data in self.diagnostic_knowledge.items():
                if any(symptom.lower() in issue_data["symptoms"] for symptom in extracted.symptoms):
                    diagnostic_info = issue_data
                    break
                    
        # Use AI for advanced diagnosis
        diagnostic_prompt = f"""You are an expert maintenance diagnostician. Analyze this equipment issue:

Asset: {extracted.asset_name} ({extracted.equipment_type})
Location: {extracted.location}
Symptoms: {extracted.symptoms}
Description: {extracted.description}

Provide diagnostic analysis in this format:
1. Most likely causes (ranked by probability)
2. Recommended diagnostic steps
3. Required tools/equipment
4. Estimated diagnosis time
5. Safety considerations"""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=diagnostic_prompt,
                system_context="You are a maintenance expert with 20+ years experience in industrial equipment.",
                provider_type=AIProvider.LLAMA
            )
            
            diagnosis = {
                "asset_info": {
                    "name": extracted.asset_name,
                    "type": extracted.equipment_type,
                    "location": extracted.location
                },
                "symptoms_analysis": extracted.symptoms,
                "ai_diagnosis": ai_response.content if ai_response else "Diagnosis unavailable",
                "known_patterns": diagnostic_info,
                "confidence": extracted.confidence,
                "recommended_actions": self._get_recommended_actions(extracted, diagnostic_info),
                "tools_required": diagnostic_info.get("tools_required", []) if diagnostic_info else [],
                "safety_notes": self._get_safety_notes(extracted)
            }
            
        except Exception as e:
            logger.error(f"Diagnosis failed: {e}")
            diagnosis = {
                "error": "AI diagnosis unavailable",
                "fallback_info": diagnostic_info,
                "safety_notes": self._get_safety_notes(extracted)
            }
            
        return diagnosis

    def _get_recommended_actions(self, extracted: ExtractedData, diagnostic_info: Dict) -> List[str]:
        """Get recommended diagnostic/repair actions"""
        actions = []
        
        if diagnostic_info:
            actions.extend(diagnostic_info.get("solutions", []))
        
        # General recommendations based on equipment type
        if extracted.equipment_type == "centrifugal_pump":
            actions.append("Check suction and discharge pressure")
            actions.append("Inspect mechanical seal for leakage")
            actions.append("Verify proper alignment")
            
        elif extracted.equipment_type == "conveyor_system":
            actions.append("Check belt tension and tracking")
            actions.append("Inspect drive motor and coupling")
            actions.append("Verify safety systems")
            
        elif extracted.equipment_type == "boiler":
            actions.append("Check pressure and temperature readings")
            actions.append("Inspect burner operation")
            actions.append("Verify safety valve function")
            
        return actions[:5]  # Limit to top 5 recommendations

# Global instance
ai_assistant = AITechnicianAssistant()

async def initialize_ai_assistant() -> bool:
    """Initialize the AI assistant"""
    try:
        # Test AI connectivity
        test_response = await ai_assistant.process_natural_language("Test connection")
        logger.info("✅ AI Technician Assistant initialized successfully")
        return True
    except Exception as e:
        logger.error(f"❌ AI Assistant initialization failed: {e}")
        return False

# Export main functions
__all__ = ['AITechnicianAssistant', 'ai_assistant', 'IntentType', 'ExtractedData', 'initialize_ai_assistant']