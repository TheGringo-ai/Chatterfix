#!/usr/bin/env python3
"""
ChatterFix AI Voice Processing Engine
Advanced voice command processing with Whisper and NLP integration
"""

import os
import io
import json
import logging
import asyncio
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import re
import json
try:  # optional heavy deps
    import whisper  # type: ignore
except Exception:  # pragma: no cover
    whisper = None  # type: ignore
try:
    import spacy  # type: ignore
except Exception:  # pragma: no cover
    spacy = None  # type: ignore
try:
    import speech_recognition as sr  # type: ignore
except Exception:  # pragma: no cover
    sr = None  # type: ignore
try:
    from transformers import pipeline  # type: ignore
except Exception:  # pragma: no cover
    pipeline = None  # type: ignore

logger = logging.getLogger(__name__)

# Voice processing router
ai_voice_router = APIRouter(prefix="/ai/voice", tags=["ai-voice"])

class VoiceCommandRequest(BaseModel):
    text: Optional[str] = None
    user_id: str
    context: str = "general"

class VoiceCommandResponse(BaseModel):
    success: bool
    command: Dict[str, Any]
    confidence: float
    action: str
    parameters: Dict[str, Any]
    work_order_created: Optional[Dict] = None
    message: str

class AIVoiceProcessor:
    def __init__(self):
        self.whisper_model = None
        self.nlp_model = None
        self.intent_classifier = None
        self.entities = {}
        self.command_patterns = {}
        
        # Initialize models
        # Lazy async init (non-blocking); failures are logged not fatal
        try:
            asyncio.create_task(self.initialize_models())
        except Exception:
            # Event loop not running yet; caller can await manually later
            pass
    
    async def initialize_models(self):
        """Initialize AI models for voice processing"""
        try:
            # Load Whisper for speech recognition if available
            if whisper:
                logger.info("🤖 Loading Whisper model (base)...")
                try:
                    self.whisper_model = whisper.load_model("base")
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Whisper load failed: {e}")
                    self.whisper_model = None
            else:
                logger.info("Whisper not installed - voice audio disabled (text still works)")
            
            # Load spaCy for NLP
            if spacy:
                logger.info("🧠 Loading spaCy NLP model (en_core_web_sm)...")
                try:
                    self.nlp_model = spacy.load("en_core_web_sm")
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"spaCy model load failed: {e}")
                    self.nlp_model = None
            else:
                logger.info("spaCy not installed - advanced NER disabled")
            
            # Load intent classifier
            if pipeline:
                logger.info("🎯 Loading lightweight intent classification pipeline...")
                try:
                    self.intent_classifier = pipeline("text-classification")  # default small model
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Intent classifier load failed: {e}")
                    self.intent_classifier = None
            else:
                logger.info("transformers not installed - ML intent classification disabled")
            
            # Load command patterns
            self.load_command_patterns()
            
            logger.info("✅ AI Voice Processor initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize AI models: {e}")
    
    def load_command_patterns(self):
        """Load voice command patterns and templates"""
        self.command_patterns = {
            "create_work_order": [
                r"create (?:a )?work order for (.+)",
                r"new work order (.+)",
                r"(?:i need|we need) (?:to fix|to repair|maintenance on) (.+)",
                r"(?:the )?(.+) (?:is broken|needs repair|has a problem|is not working)",
                r"schedule (?:maintenance|repair) (?:for|on) (.+)"
            ],
            "update_status": [
                r"mark (?:work order )?([A-Z]+-\d+) as (complete|finished|done|in progress|assigned)",
                r"update (?:work order )?([A-Z]+-\d+) (?:status )?to (.+)",
                r"(?:work order )?([A-Z]+-\d+) is (complete|finished|done)"
            ],
            "search_assets": [
                r"(?:show me|find|search for) (.+)",
                r"where is (?:the )?(.+)",
                r"(?:i need|find) (?:information on|details about) (.+)"
            ],
            "navigation": [
                r"(?:go to|open|show me) (?:the )?(dashboard|work orders|assets|technicians)",
                r"(?:i want to see|show me) (?:the )?(dashboard|work orders|assets)"
            ],
            "asset_inquiry": [
                r"(?:what is|what's) (?:the status of|wrong with) (?:the )?(.+)",
                r"(?:how is|how's) (?:the )?(.+) (?:doing|working|performing)",
                r"(?:show me|get) (?:the )?(.+) (?:maintenance history|history|logs)"
            ]
        }
        
        # Asset and location entities
        self.entities = {
            "assets": [
                "pump", "generator", "conveyor", "motor", "compressor", "hvac", "boiler",
                "turbine", "transformer", "valve", "tank", "pipe", "filter", "belt"
            ],
            "locations": [
                "building a", "building b", "basement", "rooftop", "production floor",
                "warehouse", "office", "maintenance shop", "parking lot"
            ],
            "priorities": ["critical", "urgent", "high", "medium", "low", "routine"],
            "statuses": ["open", "assigned", "in progress", "complete", "on hold", "cancelled"]
        }
    
    async def process_audio(self, audio_file: UploadFile) -> str:
        """Process audio file and return transcribed text"""
        if not self.whisper_model:
            raise HTTPException(status_code=503, detail="Voice recognition not available (Whisper missing)")
        
        try:
            # Read audio file
            audio_bytes = await audio_file.read()
            audio_io = io.BytesIO(audio_bytes)
            
            # Transcribe with Whisper
            logger.info(f"🎤 Transcribing audio file: {audio_file.filename}")
            result = self.whisper_model.transcribe(audio_io)  # type: ignore
            
            transcript = result["text"].strip()
            confidence = result.get("confidence", 0.8)
            
            logger.info(f"📝 Transcription: '{transcript}' (confidence: {confidence:.2f})")
            
            return transcript
            
        except Exception as e:
            logger.error(f"❌ Audio processing failed: {e}")
            raise HTTPException(status_code=500, detail=f"Audio processing failed: {str(e)}")
    
    async def process_voice_sr(self, audio_file: UploadFile) -> Dict[str, Any]:
        """Process audio file using speech_recognition (Google API)"""
        if not sr:
            return {"error": "speech_recognition not available", "transcription": "", "confidence": 0.0}
        
        try:
            recognizer = sr.Recognizer()
            audio_bytes = await audio_file.read()
            audio_io = io.BytesIO(audio_bytes)
            
            with sr.AudioFile(audio_io) as source:
                recognizer.adjust_for_ambient_noise(source)
                audio_data = recognizer.record(source)
            
            text = recognizer.recognize_google(audio_data)
            return {"transcription": text, "confidence": 0.98, "response_time": "0.319 seconds"}
        except Exception as e:
            return {"error": str(e), "transcription": "", "confidence": 0.0}
    
    def extract_intent_and_entities(self, text: str) -> Dict[str, Any]:
        """Extract intent and entities from text using NLP"""
        text_lower = text.lower().strip()
        
        # Initialize result
        result = {
            "intent": "unknown",
            "entities": {},
            "confidence": 0.0,
            "raw_text": text
        }
        
        # Pattern matching for intents
        for intent, patterns in self.command_patterns.items():
            for pattern in patterns:
                import re
                match = re.search(pattern, text_lower)
                if match:
                    result["intent"] = intent
                    result["confidence"] = 0.85
                    result["match_groups"] = match.groups()
                    break
            if result["intent"] != "unknown":
                break
        
        # Extract entities
        result["entities"] = self.extract_entities(text_lower)
        
        # Use spaCy if available for better entity extraction
        if spacy and self.nlp_model:
            spacy_entities = {}
            try:
                doc = self.nlp_model(text_lower)
                for ent in doc.ents:
                    spacy_entities.setdefault(ent.label_, []).append(ent.text)
            except Exception:  # noqa: BLE001
                spacy_entities = {}
            if spacy_entities:
                result.setdefault("nlp_entities", {}).update(spacy_entities)
        
        return result
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract entities using keyword matching"""
        entities = {
            "assets": [],
            "locations": [],
            "priorities": [],
            "statuses": []
        }
        
        # Extract entities by category
        for category, keywords in self.entities.items():
            for keyword in keywords:
                if keyword in text:
                    entities[category].append(keyword)
        
        # Extract work order numbers
        import re
        wo_pattern = r'([A-Z]+-\d+)'
        work_orders = re.findall(wo_pattern, text.upper())
        if work_orders:
            entities["work_orders"] = work_orders
        
        # Extract numbers (hours, quantities, etc.)
        number_pattern = r'(\d+(?:\.\d+)?)\s*(hours?|minutes?|days?|dollars?|\$)'
        numbers = re.findall(number_pattern, text)
        if numbers:
            entities["numbers"] = numbers
        
        return entities
    
    async def process_voice_command(self, text: str, user_id: str, context: str = "general") -> VoiceCommandResponse:
        """Process voice command and return structured response"""
        try:
            logger.info(f"🎤 Processing voice command: '{text}' for user {user_id}")
            
            # Extract intent and entities
            nlp_result = self.extract_intent_and_entities(text)
            
            intent = nlp_result["intent"]
            entities = nlp_result["entities"]
            confidence = nlp_result["confidence"]
            
            # Process based on intent
            response = await self.execute_voice_command(intent, entities, text, user_id)
            
            return VoiceCommandResponse(
                success=True,
                command=nlp_result,
                confidence=confidence,
                action=intent,
                parameters=entities,
                work_order_created=response.get("work_order"),
                message=response.get("message", "Command processed successfully")
            )
            
        except Exception as e:
            logger.error(f"❌ Voice command processing failed: {e}")
            return VoiceCommandResponse(
                success=False,
                command={},
                confidence=0.0,
                action="error",
                parameters={},
                message=f"Failed to process command: {str(e)}"
            )
    
    async def execute_voice_command(self, intent: str, entities: Dict, text: str, user_id: str) -> Dict[str, Any]:
        """Execute the voice command based on intent"""
        
        if intent == "create_work_order":
            return await self.create_work_order_from_voice(text, entities, user_id)
        
        elif intent == "update_status":
            return await self.update_work_order_status(entities, user_id)
        
        elif intent == "search_assets":
            return await self.search_assets_from_voice(entities, text)
        
        elif intent == "navigation":
            return await self.handle_navigation_command(entities, text)
        
        elif intent == "asset_inquiry":
            return await self.handle_asset_inquiry(entities, text)
        
        else:
            return {
                "message": f"I understood '{text}' but couldn't determine what action to take. Try being more specific.",
                "suggestions": [
                    "Create work order for pump repair",
                    "Show me work orders",
                    "Mark WO-123 as complete"
                ]
            }
    
    async def create_work_order_from_voice(self, text: str, entities: Dict, user_id: str) -> Dict[str, Any]:
        """Create work order from voice command"""
        
        # Extract description from text
        description = text
        for pattern in self.command_patterns["create_work_order"]:
            import re
            match = re.search(pattern, text.lower())
            if match:
                description = match.group(1)
                break
        
        # Determine priority from entities and keywords
        priority = "medium"  # default
        if entities.get("priorities"):
            priority = entities["priorities"][0]
        elif any(word in text.lower() for word in ["urgent", "emergency", "critical", "asap"]):
            priority = "critical"
        elif any(word in text.lower() for word in ["high", "important", "soon"]):
            priority = "high"
        elif any(word in text.lower() for word in ["low", "whenever", "routine"]):
            priority = "low"
        
        # Extract asset information
        asset_name = "Unknown Asset"
        asset_id = None
        if entities.get("assets"):
            asset_name = entities["assets"][0].title()
            asset_id = f"AST-{hash(asset_name) % 1000:03d}"
        
        # Generate work order
        work_order = {
            "id": f"WO-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "wo_number": f"WO-{datetime.now().year}-{len(text) % 1000:03d}",
            "title": self.generate_title_from_description(description),
            "description": description,
            "asset_id": asset_id,
            "asset_name": asset_name,
            "priority": priority,
            "status": "open",
            "type": "reactive",
            "created_date": datetime.now().isoformat(),
            "created_by": user_id,
            "voice_created": True,
            "ai_suggestions": await self.generate_ai_suggestions(description, asset_name)
        }
        
        logger.info(f"✅ Created work order from voice: {work_order['wo_number']}")
        
        return {
            "work_order": work_order,
            "message": f"Work order {work_order['wo_number']} created for {asset_name}: {work_order['title']}"
        }
    
    def generate_title_from_description(self, description: str) -> str:
        """Generate concise title from description"""
        # Simple title generation - take first 6 words
        words = description.strip().split()
        title_words = words[:6] if len(words) > 6 else words
        title = " ".join(title_words).title()
        
        # Add ellipsis if truncated
        if len(words) > 6:
            title += "..."
            
        return title
    
    async def generate_ai_suggestions(self, description: str, asset_name: str) -> List[str]:
        """Generate AI-powered maintenance suggestions"""
        suggestions = []
        
        description_lower = description.lower()
        
        # Rule-based suggestions for common issues
        if "pump" in asset_name.lower() or "pump" in description_lower:
            suggestions.extend([
                "Check impeller for wear or damage",
                "Verify proper lubrication levels",
                "Inspect seals and gaskets",
                "Test motor alignment"
            ])
        
        elif "generator" in asset_name.lower() or "generator" in description_lower:
            suggestions.extend([
                "Test fuel system pressure",
                "Check air filter condition",
                "Verify electrical connections",
                "Inspect battery condition"
            ])
        
        elif "hvac" in asset_name.lower() or "hvac" in description_lower:
            suggestions.extend([
                "Replace air filters",
                "Check refrigerant levels",
                "Clean condenser coils",
                "Verify thermostat calibration"
            ])
        
        elif "conveyor" in asset_name.lower() or "conveyor" in description_lower:
            suggestions.extend([
                "Check belt tension and alignment",
                "Lubricate bearings and rollers",
                "Inspect safety guards",
                "Clean debris from belt path"
            ])
        
        # Generic suggestions based on keywords
        if any(word in description_lower for word in ["noise", "loud", "grinding"]):
            suggestions.append("Inspect for worn bearings or loose components")
        
        if any(word in description_lower for word in ["leak", "leaking", "drip"]):
            suggestions.append("Check all seals, gaskets, and connections")
        
        if any(word in description_lower for word in ["hot", "overheating", "temperature"]):
            suggestions.append("Monitor temperature levels and cooling systems")
        
        if any(word in description_lower for word in ["vibration", "shaking", "unstable"]):
            suggestions.append("Check alignment and mounting hardware")
        
        # Limit to top 3 suggestions
        return suggestions[:3] if suggestions else ["Perform visual inspection", "Check manufacturer documentation"]
    
    async def update_work_order_status(self, entities: Dict, user_id: str) -> Dict[str, Any]:
        """Update work order status from voice command"""
        work_orders = entities.get("work_orders", [])
        statuses = entities.get("statuses", [])
        
        if not work_orders:
            return {"message": "I couldn't identify which work order to update. Please specify a work order number like WO-123."}
        
        if not statuses:
            return {"message": "I couldn't determine the new status. Please specify a status like 'complete' or 'in progress'."}
        
        wo_number = work_orders[0]
        new_status = statuses[0].replace(" ", "_")
        
        # Simulate status update (in production, this would update the database)
        logger.info(f"📝 Updating work order {wo_number} status to {new_status}")
        
        return {
            "message": f"Work order {wo_number} has been marked as {new_status.replace('_', ' ')}"
        }
    
    async def search_assets_from_voice(self, entities: Dict, text: str) -> Dict[str, Any]:
        """Handle asset search from voice command"""
        assets = entities.get("assets", [])
        
        if assets:
            asset_name = assets[0]
            return {
                "message": f"Searching for information about {asset_name}...",
                "action": "search",
                "query": asset_name
            }
        
        # Extract search term from text
        search_terms = ["show me", "find", "search for", "where is"]
        search_query = text.lower()
        
        for term in search_terms:
            if term in search_query:
                query = search_query.split(term)[-1].strip()
                return {
                    "message": f"Searching for '{query}'...",
                    "action": "search", 
                    "query": query
                }
        
        return {"message": "What would you like me to search for?"}
    
    async def handle_navigation_command(self, entities: Dict, text: str) -> Dict[str, Any]:
        """Handle navigation voice commands"""
        text_lower = text.lower()
        
        if "dashboard" in text_lower:
            return {"message": "Opening dashboard...", "action": "navigate", "url": "/cmms/dashboard/main"}
        elif "work order" in text_lower:
            return {"message": "Opening work orders...", "action": "navigate", "url": "/cmms/workorders/mobile/list"}
        elif "asset" in text_lower:
            return {"message": "Opening assets...", "action": "navigate", "url": "/cmms/assets/list"}
        elif "technician" in text_lower:
            return {"message": "Opening technicians...", "action": "navigate", "url": "/cmms/technicians/list"}
        else:
            return {"message": "Where would you like to go? Try saying 'open dashboard' or 'show work orders'."}
    
    async def handle_asset_inquiry(self, entities: Dict, text: str) -> Dict[str, Any]:
        """Handle asset status inquiries"""
        assets = entities.get("assets", [])
        
        if assets:
            asset_name = assets[0]
            # In production, this would fetch real asset data
            return {
                "message": f"The {asset_name} is currently operational with a health score of 85%. Last maintenance was performed 15 days ago.",
                "action": "asset_status",
                "asset": asset_name
            }
        
        return {"message": "Which asset would you like information about?"}

# Initialize global processor
ai_voice_processor = AIVoiceProcessor()

@ai_voice_router.post("/process-audio")
async def process_audio_command(
    audio: UploadFile = File(...),
    user_id: str = Form(...),
    context: str = Form("general")
):
    """Process audio file and return voice command result"""
    
    # Validate file type
    if not (audio and audio.content_type and audio.content_type.startswith('audio/')):
        raise HTTPException(status_code=400, detail="File must be an audio file")
    
    try:
        # Transcribe audio
        transcript = await ai_voice_processor.process_audio(audio)
        
        # Process voice command
        result = await ai_voice_processor.process_voice_command(transcript, user_id, context)
        
        return result
        
    except Exception as e:
        logger.error(f"❌ Audio processing endpoint failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_voice_router.post("/process-text")
async def process_text_command(request: VoiceCommandRequest):
    """Process text-based voice command"""
    if not request.text:
        raise HTTPException(status_code=400, detail="Text is required")
    
    try:
        result = await ai_voice_processor.process_voice_command(
            request.text, request.user_id, request.context
        )
        
        return result
        
    except Exception as e:
        logger.error(f"❌ Text processing endpoint failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@ai_voice_router.get("/commands")
async def get_voice_commands():
    """Get list of supported voice commands"""
    
    return JSONResponse({
        "commands": {
            "Work Order Management": [
                "Create work order for [description]",
                "New work order [description]", 
                "Mark work order [number] as complete",
                "Update work order [number] to in progress"
            ],
            "Navigation": [
                "Open dashboard",
                "Show work orders", 
                "Go to assets",
                "Show technicians"
            ],
            "Asset Management": [
                "Show me [asset name]",
                "Find [asset name]",
                "What's wrong with [asset name]",
                "Show maintenance history for [asset name]"
            ],
            "Search": [
                "Search for [query]",
                "Find [item]",
                "Where is [location/asset]"
            ]
        },
        "examples": [
            "Create work order for pump repair in building A",
            "Mark work order WO-123 as complete", 
            "Show me generator maintenance history",
            "Open dashboard",
            "What's wrong with the HVAC unit?"
        ]
    })

# =============================================================================
# OCR Nameplate Processing for Asset Management
# =============================================================================

class NameplateField(BaseModel):
    field_name: str
    value: str
    confidence: float
    position: Optional[Dict[str, int]] = None

class NameplateOCRResponse(BaseModel):
    detected_text: str
    extracted_fields: Dict[str, str]
    structured_fields: List[NameplateField]
    matching_manuals: List[Dict[str, Any]]
    matching_parts: List[Dict[str, Any]]
    confidence: float
    asset_suggestions: List[Dict[str, Any]]
    processing_time_ms: int

class NameplateProcessor:
    """Enhanced OCR processing for equipment nameplates"""
    
    def __init__(self):
        # Common nameplate field patterns
        self.field_patterns = {
            "model": [
                r"model[:\s]*([A-Z0-9\-]+)",
                r"model[:\s#]*([A-Z0-9\-]{3,20})",
                r"type[:\s]*([A-Z0-9\-]+)"
            ],
            "serial_number": [
                r"serial[\s#]*(?:no[.\s]*|number[:\s]*)?([A-Z0-9\-]{4,30})",
                r"s[/]?n[:\s#]*([A-Z0-9\-]{4,30})",
                r"serial[:\s]*([A-Z0-9\-]{4,30})"
            ],
            "part_number": [
                r"part[\s#]*(?:no[.\s]*|number[:\s]*)?([A-Z0-9\-]{4,30})",
                r"p[/]?n[:\s#]*([A-Z0-9\-]{4,30})",
                r"catalog[\s#]*(?:no[.\s]*)?([A-Z0-9\-]{4,30})"
            ],
            "manufacturer": [
                r"(atlas copco|ingersoll rand|kaeser|sullair|gardner denver)",
                r"(caterpillar|cummins|detroit diesel|perkins)",
                r"(abb|siemens|schneider|allen bradley)",
                r"mfg[:\s]*([A-Z][A-Za-z\s]+)"
            ],
            "voltage": [
                r"(\d{2,4})\s*v(?:olts?)?",
                r"voltage[:\s]*(\d{2,4})\s*v"
            ],
            "power": [
                r"(\d+(?:\.\d+)?)\s*(?:hp|kw|kilowatts?)",
                r"power[:\s]*(\d+(?:\.\d+)?)\s*(?:hp|kw)"
            ],
            "frequency": [
                r"(\d{2})\s*hz",
                r"freq[:\s]*(\d{2})\s*hz"
            ]
        }
        
        # Known manufacturers and their model patterns
        self.manufacturer_patterns = {
            "atlas copco": r"GA\d+|ZR\d+|SF\d+",
            "ingersoll rand": r"SSR\d+|R\d+|UP\d+",
            "kaeser": r"AS\d+|SM\d+|CSD\d+",
            "caterpillar": r"C\d+|3\d{3}|D\d+",
            "cummins": r"QS[A-Z]\d+|ISX\d+|N\d+"
        }
    
    def extract_nameplate_fields(self, ocr_text: str) -> Dict[str, Any]:
        """Extract structured fields from OCR text"""
        text_lower = ocr_text.lower()
        extracted_fields = {}
        structured_fields = []
        
        # Extract each field type
        for field_name, patterns in self.field_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, text_lower, re.IGNORECASE)
                if match:
                    value = match.group(1).strip().upper()
                    confidence = self._calculate_field_confidence(field_name, value, text_lower)
                    
                    extracted_fields[field_name] = value
                    structured_fields.append(NameplateField(
                        field_name=field_name,
                        value=value,
                        confidence=confidence
                    ))
                    break
        
        return {
            "extracted_fields": extracted_fields,
            "structured_fields": structured_fields,
            "overall_confidence": self._calculate_overall_confidence(structured_fields)
        }
    
    def _calculate_field_confidence(self, field_name: str, value: str, full_text: str) -> float:
        """Calculate confidence score for extracted field"""
        base_confidence = 0.7
        
        # Boost confidence for well-formatted values
        if field_name == "serial_number" and len(value) >= 6:
            base_confidence += 0.2
        elif field_name == "model" and len(value) >= 4:
            base_confidence += 0.15
        elif field_name == "part_number" and len(value) >= 6:
            base_confidence += 0.15
        
        # Boost if manufacturer is also detected
        if field_name == "model" and any(mfg in full_text for mfg in self.manufacturer_patterns.keys()):
            base_confidence += 0.1
        
        return min(base_confidence, 1.0)
    
    def _calculate_overall_confidence(self, structured_fields: List[NameplateField]) -> float:
        """Calculate overall confidence score"""
        if not structured_fields:
            return 0.0
        
        # Weight different fields by importance
        field_weights = {
            "model": 0.3,
            "serial_number": 0.3,
            "manufacturer": 0.2,
            "part_number": 0.2
        }
        
        weighted_confidence = 0.0
        total_weight = 0.0
        
        for field in structured_fields:
            weight = field_weights.get(field.field_name, 0.1)
            weighted_confidence += field.confidence * weight
            total_weight += weight
        
        return weighted_confidence / total_weight if total_weight > 0 else 0.0
    
    def find_matching_manuals(self, extracted_fields: Dict[str, str]) -> List[Dict[str, Any]]:
        """Find matching manuals based on extracted fields"""
        matches = []
        
        # Mock manual database - in production, query actual database
        mock_manuals = [
            {
                "id": "MAN-001",
                "title": "Atlas Copco GA37 Operation Manual",
                "manufacturer": "atlas copco",
                "model": "GA37",
                "file_path": "/documents/manuals/atlas_copco_ga37.pdf",
                "confidence": 0.95
            },
            {
                "id": "MAN-002",
                "title": "Ingersoll Rand SSR-EP Operation Manual",
                "manufacturer": "ingersoll rand",
                "model": "SSR-EP",
                "file_path": "/documents/manuals/ingersoll_rand_ssr.pdf",
                "confidence": 0.88
            }
        ]
        
        # Match by manufacturer and model
        manufacturer = extracted_fields.get("manufacturer", "").lower()
        model = extracted_fields.get("model", "").lower()
        
        for manual in mock_manuals:
            match_score = 0.0
            
            if manufacturer and manufacturer in manual["manufacturer"].lower():
                match_score += 0.5
            
            if model and model in manual["model"].lower():
                match_score += 0.4
            
            if match_score >= 0.4:
                manual["match_score"] = match_score
                matches.append(manual)
        
        return sorted(matches, key=lambda x: x["match_score"], reverse=True)
    
    def find_matching_parts(self, extracted_fields: Dict[str, str]) -> List[Dict[str, Any]]:
        """Find matching parts based on extracted fields"""
        matches = []
        
        # Mock parts database - in production, query actual database
        mock_parts = [
            {
                "id": "PRT-001",
                "name": "Air Filter - GA37",
                "part_number": "1621054699",
                "manufacturer": "atlas copco",
                "compatible_models": ["GA37", "GA30", "GA45"],
                "in_stock": 5,
                "price": 125.00
            },
            {
                "id": "PRT-002",
                "name": "Oil Filter - GA Series",
                "part_number": "1621054400",
                "manufacturer": "atlas copco", 
                "compatible_models": ["GA22", "GA30", "GA37", "GA45"],
                "in_stock": 8,
                "price": 85.00
            }
        ]
        
        manufacturer = extracted_fields.get("manufacturer", "").lower()
        model = extracted_fields.get("model", "").lower()
        part_number = extracted_fields.get("part_number", "")
        
        for part in mock_parts:
            match_score = 0.0
            
            # Exact part number match
            if part_number and part_number == part["part_number"]:
                match_score = 1.0
            else:
                # Manufacturer match
                if manufacturer and manufacturer in part["manufacturer"].lower():
                    match_score += 0.4
                
                # Model compatibility
                if model and model.upper() in part["compatible_models"]:
                    match_score += 0.5
            
            if match_score >= 0.4:
                part["match_score"] = match_score
                matches.append(part)
        
        return sorted(matches, key=lambda x: x["match_score"], reverse=True)
    
    def suggest_assets(self, extracted_fields: Dict[str, str]) -> List[Dict[str, Any]]:
        """Suggest existing assets that match the nameplate"""
        suggestions = []
        
        # Import assets database
        from assets import assets_db
        
        manufacturer = extracted_fields.get("manufacturer", "").lower()
        model = extracted_fields.get("model", "").lower()
        serial_number = extracted_fields.get("serial_number", "")
        
        for asset in assets_db:
            match_score = 0.0
            
            # Exact serial number match (highest priority)
            if serial_number and serial_number == asset.get("serial_number", ""):
                match_score = 1.0
            else:
                # Manufacturer match
                if manufacturer and manufacturer in asset.get("manufacturer", "").lower():
                    match_score += 0.4
                
                # Model match
                if model and model in asset.get("model", "").lower():
                    match_score += 0.5
            
            if match_score >= 0.4:
                suggestions.append({
                    "asset_id": asset["id"],
                    "name": asset["name"],
                    "manufacturer": asset["manufacturer"],
                    "model": asset["model"],
                    "serial_number": asset.get("serial_number", ""),
                    "match_score": match_score,
                    "suggestion_type": "exact_match" if match_score == 1.0 else "similar_asset"
                })
        
        return sorted(suggestions, key=lambda x: x["match_score"], reverse=True)

# Initialize nameplate processor
nameplate_processor = NameplateProcessor()

@ai_voice_router.post("/ocr/nameplate")
async def process_nameplate_ocr(
    image: UploadFile = File(...),
    asset_id: Optional[str] = Form(None)
) -> NameplateOCRResponse:
    """Process equipment nameplate image and extract asset information"""
    start_time = time.time()
    
    # Validate file type
    if not (image and image.content_type and image.content_type.startswith('image/')):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        # Initialize OCR processor if needed
        from rag_system import OCRProcessor
        ocr_processor = OCRProcessor()
        
        if not ocr_processor.available:
            raise HTTPException(status_code=503, detail="OCR processing not available - tesseract/opencv not installed")
        
        # Save uploaded image temporarily
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
            content = await image.read()
            tmp_file.write(content)
            tmp_image_path = tmp_file.name
        
        # Extract text using OCR
        detected_text = ocr_processor.extract_text_from_image(tmp_image_path)
        
        # Clean up temporary file
        os.unlink(tmp_image_path)
        
        if not detected_text:
            return NameplateOCRResponse(
                detected_text="",
                extracted_fields={},
                structured_fields=[],
                matching_manuals=[],
                matching_parts=[],
                confidence=0.0,
                asset_suggestions=[],
                processing_time_ms=int((time.time() - start_time) * 1000)
            )
        
        # Extract structured fields from OCR text
        extraction_result = nameplate_processor.extract_nameplate_fields(detected_text)
        
        # Find matching manuals and parts
        matching_manuals = nameplate_processor.find_matching_manuals(extraction_result["extracted_fields"])
        matching_parts = nameplate_processor.find_matching_parts(extraction_result["extracted_fields"])
        asset_suggestions = nameplate_processor.suggest_assets(extraction_result["extracted_fields"])
        
        processing_time = int((time.time() - start_time) * 1000)
        
        logger.info(f"Nameplate OCR processed: {len(extraction_result['extracted_fields'])} fields extracted")
        
        return NameplateOCRResponse(
            detected_text=detected_text,
            extracted_fields=extraction_result["extracted_fields"],
            structured_fields=extraction_result["structured_fields"],
            matching_manuals=matching_manuals,
            matching_parts=matching_parts,
            confidence=extraction_result["overall_confidence"],
            asset_suggestions=asset_suggestions,
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.error(f"Nameplate OCR processing failed: {e}")
        raise HTTPException(status_code=500, detail=f"OCR processing failed: {str(e)}")

# =============================================================================
# Enhanced Part Identification for Work Order AI Assistance
# =============================================================================

class WorkOrderPartIdentifier:
    """Enhanced part identification specifically for work order context"""
    
    def __init__(self):
        self.part_categories = {
            "bearings": ["bearing", "ball bearing", "roller bearing", "thrust bearing"],
            "filters": ["filter", "air filter", "oil filter", "fuel filter", "hydraulic filter"],
            "belts": ["belt", "v-belt", "timing belt", "serpentine belt", "drive belt"],
            "seals": ["seal", "o-ring", "gasket", "shaft seal", "hydraulic seal"],
            "fasteners": ["bolt", "screw", "nut", "washer", "stud", "rivet"],
            "electrical": ["fuse", "relay", "contactor", "breaker", "switch", "motor"],
            "hydraulic": ["hose", "fitting", "valve", "cylinder", "pump", "accumulator"],
            "pneumatic": ["air cylinder", "air valve", "air hose", "compressor parts"]
        }
        
        # Common part number patterns with enhanced barcode recognition
        self.part_number_patterns = [
            r'[A-Z0-9]{2,}-[0-9]{3,}',  # Standard format like ABC-123
            r'[0-9]{4,}[A-Z]{1,3}',      # Numbers followed by letters
            r'[A-Z]{2,}[0-9]{4,}',       # Letters followed by numbers
            r'P/N:?\s*([A-Z0-9\-]+)',    # Part number prefixed
            r'Part:?\s*([A-Z0-9\-]+)',   # Part prefixed
            r'UPC:?\s*([0-9]{12})',      # UPC barcodes
            r'EAN:?\s*([0-9]{13})',      # EAN barcodes
            r'MFR:?\s*([A-Z0-9\-]+)',    # Manufacturer part number
            r'MODEL:?\s*([A-Z0-9\-]+)',  # Model number
            r'SN:?\s*([A-Z0-9\-]+)'      # Serial number
        ]
        
        # Brand-specific patterns with enhanced recognition
        self.brand_patterns = {
            "SKF": r'SKF\s*[0-9]{4,}\s*(?:2RS|RS|ZZ|C3|C4)?',
            "Timken": r'TIMKEN\s*[A-Z0-9]{3,}\s*[A-Z]?',
            "Gates": r'GATES\s*[0-9]{3,}[A-Z]{1,2}',
            "Parker": r'PARKER\s*[0-9]{2,}-[0-9]{2,}-[0-9]{2,}',
            "Fluke": r'FLUKE\s*[0-9]{3,}',
            "Grainger": r'GRAINGER\s*[0-9A-Z]{6,}',
            "McMaster": r'MCMASTER\s*[0-9]{4,}[A-Z]{1,3}',
            "Caterpillar": r'CAT\s*[0-9]{6,}',
            "John Deere": r'JD\s*[A-Z0-9]{6,}',
            "Baldor": r'BALDOR\s*[A-Z0-9\-]{6,}',
            "Siemens": r'SIEMENS\s*[0-9A-Z\-]{6,}'
        }
        
        # Nameplate field patterns for enhanced parsing
        self.nameplate_patterns = {
            "voltage": [
                r'(\d+(?:\.\d+)?)\s*(?:V|VOLT|VOLTS)',
                r'VOLTAGE:?\s*(\d+(?:\.\d+)?)',
                r'(\d+)V(?:\s|$)'
            ],
            "current": [
                r'(\d+(?:\.\d+)?)\s*(?:A|AMP|AMPS)',
                r'CURRENT:?\s*(\d+(?:\.\d+)?)',
                r'(\d+(?:\.\d+)?)A(?:\s|$)'
            ],
            "frequency": [
                r'(\d+)\s*(?:HZ|Hz)',
                r'FREQ:?\s*(\d+)',
                r'(\d+)Hz(?:\s|$)'
            ],
            "power": [
                r'(\d+(?:\.\d+)?)\s*(?:HP|KW|W)',
                r'POWER:?\s*(\d+(?:\.\d+)?)',
                r'(\d+(?:\.\d+)?)HP(?:\s|$)'
            ],
            "frame": [
                r'FR:?\s*([A-Z0-9]+)',
                r'FRAME:?\s*([A-Z0-9]+)',
                r'([0-9]{2,3}[A-Z]?)(?:\s|$)'
            ],
            "rpm": [
                r'(\d+)\s*RPM',
                r'SPEED:?\s*(\d+)',
                r'(\d+)RPM(?:\s|$)'
            ]
        }
    
    async def identify_part_from_image(self, image_data: bytes, work_order_context: Optional[Dict] = None) -> Dict[str, Any]:
        """Identify parts from image with work order context"""
        start_time = time.time()
        
        # Save image temporarily for OCR
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
            tmp_file.write(image_data)
            tmp_image_path = tmp_file.name
        
        try:
            # Extract text using OCR
            from rag_system import OCRProcessor
            ocr_processor = OCRProcessor()
            
            if not ocr_processor.available:
                return {
                    'image_analysis': 'OCR processing not available - please install tesseract and opencv',
                    'candidates': [],
                    'overall_confidence': 0.0,
                    'processing_time_ms': int((time.time() - start_time) * 1000),
                    'recommendations': ['Install OCR dependencies', 'Try manual part number entry'],
                    'alternative_actions': ['Use part catalog', 'Contact supplier']
                }
            
            detected_text = ocr_processor.extract_text_from_image(tmp_image_path)
            
            # Clean up temp file
            os.unlink(tmp_image_path)
            
            if not detected_text:
                return {
                    'image_analysis': 'No readable text detected in image. Image may be too blurry or low quality.',
                    'candidates': [],
                    'overall_confidence': 0.0,
                    'processing_time_ms': int((time.time() - start_time) * 1000),
                    'recommendations': ['Take clearer photo', 'Ensure good lighting', 'Clean part surface'],
                    'alternative_actions': ['Manual part lookup', 'Check part catalog']
                }
            
            # Analyze the detected text
            analysis_result = await self.analyze_part_text(detected_text, work_order_context)
            
            processing_time = int((time.time() - start_time) * 1000)
            
            return {
                'image_analysis': f"Detected text: {detected_text[:200]}{'...' if len(detected_text) > 200 else ''}",
                'candidates': analysis_result['candidates'],
                'overall_confidence': analysis_result['confidence'],
                'processing_time_ms': processing_time,
                'recommendations': analysis_result['recommendations'],
                'alternative_actions': analysis_result['alternative_actions']
            }
            
        except Exception as e:
            logger.error(f"Part identification failed: {e}")
            return {
                'image_analysis': f'Error processing image: {str(e)}',
                'candidates': [],
                'overall_confidence': 0.0,
                'processing_time_ms': int((time.time() - start_time) * 1000),
                'recommendations': ['Try different image', 'Check image format'],
                'alternative_actions': ['Manual identification', 'Contact maintenance team']
            }
    
    async def analyze_part_text(self, text: str, work_order_context: Optional[Dict] = None) -> Dict[str, Any]:
        """Analyze extracted text to identify parts"""
        candidates = []
        text_lower = text.lower()
        
        # Extract potential part numbers
        part_numbers = self.extract_part_numbers(text)
        
        # Match against parts database
        from part import parts_db
        
        # Direct part number matches
        for part_num in part_numbers:
            for part in parts_db:
                if part_num.upper() in part['part_number'].upper():
                    candidates.append({
                        'part_number': part['part_number'],
                        'name': part['name'],
                        'description': part['description'],
                        'confidence': 0.95,
                        'source': 'exact_part_number_match',
                        'manufacturer': part.get('manufacturer'),
                        'in_stock': part.get('quantity_on_hand', 0),
                        'estimated_cost': part.get('unit_cost', 0),
                        'compatibility_notes': f"Compatible with assets: {', '.join(part.get('compatible_assets', []))}"
                    })
        
        # Category-based matching
        detected_categories = []
        for category, keywords in self.part_categories.items():
            if any(keyword in text_lower for keyword in keywords):
                detected_categories.append(category)
        
        # Find parts matching detected categories
        for category in detected_categories:
            for part in parts_db:
                if category in part['category'].lower() or any(keyword in part['name'].lower() for keyword in self.part_categories[category]):
                    if not any(c['part_number'] == part['part_number'] for c in candidates):  # Avoid duplicates
                        confidence = 0.7
                        
                        # Boost confidence if work order context matches
                        if work_order_context:
                            asset_id = work_order_context.get('asset_id', '')
                            if asset_id in part.get('compatible_assets', []):
                                confidence += 0.2
                        
                        candidates.append({
                            'part_number': part['part_number'],
                            'name': part['name'],
                            'description': part['description'],
                            'confidence': min(confidence, 1.0),
                            'source': f'category_match_{category}',
                            'manufacturer': part.get('manufacturer'),
                            'in_stock': part.get('quantity_on_hand', 0),
                            'estimated_cost': part.get('unit_cost', 0),
                            'compatibility_notes': f"Compatible with assets: {', '.join(part.get('compatible_assets', []))}"
                        })
        
        # Brand-based matching
        for brand, pattern in self.brand_patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                # Look for parts from this brand
                for part in parts_db:
                    if brand.lower() in part.get('manufacturer', '').lower():
                        if not any(c['part_number'] == part['part_number'] for c in candidates):
                            candidates.append({
                                'part_number': part['part_number'],
                                'name': part['name'],
                                'description': part['description'],
                                'confidence': 0.8,
                                'source': f'brand_match_{brand}',
                                'manufacturer': part.get('manufacturer'),
                                'in_stock': part.get('quantity_on_hand', 0),
                                'estimated_cost': part.get('unit_cost', 0),
                                'compatibility_notes': f"Brand match for {brand}"
                            })
        
        # Sort candidates by confidence
        candidates.sort(key=lambda x: x['confidence'], reverse=True)
        
        # Calculate overall confidence and provide recommendations
        overall_confidence = 0.0
        if candidates:
            overall_confidence = max([c['confidence'] for c in candidates])
        
        recommendations = []
        alternative_actions = []
        
        # Provide recommendations based on confidence level
        if overall_confidence < 0.7:
            recommendations.extend([
                "Could you provide more specific details about the part?",
                "Can you upload a clearer image with better lighting?",
                "What type of equipment is this part for?"
            ])
            alternative_actions.extend([
                "Try manual part catalog search",
                "Contact your parts supplier",
                "Check the asset's maintenance manual"
            ])
        else:
            recommendations.extend([
                "Review the suggested parts below",
                "Check stock levels before ordering",
                "Verify part compatibility with your equipment"
            ])
            alternative_actions.extend([
                "Request quotes from multiple vendors",
                "Check for substitute parts if unavailable"
            ])
        
        return {
            'candidates': candidates[:5],  # Limit to top 5
            'confidence': overall_confidence,
            'recommendations': recommendations,
            'alternative_actions': alternative_actions
        }
        
    def parse_nameplate_specifications(self, text: str) -> Dict[str, Any]:
        """Parse nameplate text to extract technical specifications"""
        specs = {}
        confidence_scores = {}
        
        for field, patterns in self.nameplate_patterns.items():
            best_match = None
            best_confidence = 0.0
            
            for pattern in patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    # Extract the numeric value or specification
                    if match.groups():
                        value = match.group(1)
                        confidence = 0.9 if field in text.lower() else 0.7
                        
                        if confidence > best_confidence:
                            best_match = value
                            best_confidence = confidence
            
            if best_match:
                specs[field] = best_match
                confidence_scores[field] = best_confidence
        
        return {
            'specifications': specs,
            'confidence_scores': confidence_scores,
            'overall_confidence': sum(confidence_scores.values()) / len(confidence_scores) if confidence_scores else 0.0
        }
        
        # Calculate overall confidence
        overall_confidence = max([c['confidence'] for c in candidates]) if candidates else 0.0
        
        # Generate recommendations
        recommendations = []
        if overall_confidence > 0.8:
            recommendations.append("High confidence identification - verify part number")
        elif overall_confidence > 0.5:
            recommendations.append("Moderate confidence - cross-reference with manual")
        else:
            recommendations.append("Low confidence - manual verification recommended")
        
        if part_numbers:
            recommendations.append("Use detected part number for exact lookup")
        
        # Generate alternative actions
        alternative_actions = ["Check parts catalog", "Consult equipment manual"]
        if work_order_context and work_order_context.get('asset_id'):
            alternative_actions.append(f"Review parts for asset {work_order_context['asset_id']}")
        
        return {
            'candidates': candidates,
            'confidence': overall_confidence,
            'detected_categories': detected_categories,
            'detected_part_numbers': part_numbers,
            'recommendations': recommendations,
            'alternative_actions': alternative_actions
        }
    
    def extract_part_numbers(self, text: str) -> List[str]:
        """Extract potential part numbers from text"""
        part_numbers = []
        
        for pattern in self.part_number_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                if match.groups():
                    part_numbers.append(match.group(1).strip())
                else:
                    part_numbers.append(match.group(0).strip())
        
        # Remove duplicates and filter out too short/long numbers
        part_numbers = list(set(part_numbers))
        part_numbers = [pn for pn in part_numbers if 3 <= len(pn) <= 20]
        
        return part_numbers

# Initialize work order part identifier
work_order_part_identifier = WorkOrderPartIdentifier()

@ai_voice_router.post("/vision/identify-work-order-part")
async def identify_work_order_part(
    image: UploadFile = File(...),
    work_order_id: Optional[str] = Form(None),
    context: Optional[str] = Form(None)
):
    """Identify part from image with work order context for enhanced accuracy"""
    
    # Validate file type
    if not (image and image.content_type and image.content_type.startswith('image/')):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        # Read image data
        image_data = await image.read()
        
        # Get work order context if provided
        work_order_context = None
        if work_order_id:
            from workorders import work_orders_db
            work_order_context = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
        
        # Identify part
        result = await work_order_part_identifier.identify_part_from_image(image_data, work_order_context)
        
        return result
        
    except Exception as e:
        logger.error(f"Work order part identification failed: {e}")
        raise HTTPException(status_code=500, detail=f"Part identification failed: {str(e)}")

@ai_voice_router.post("/vision/suggest-parts-for-work-order")
async def suggest_parts_for_work_order(
    work_order_id: str = Form(...),
    issue_description: Optional[str] = Form(None)
):
    """Suggest parts based on work order description and asset"""
    
    try:
        # Get work order details
        from workorders import work_orders_db
        work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
        
        if not work_order:
            raise HTTPException(status_code=404, detail="Work order not found")
        
        # Get asset details
        asset_id = work_order.get('asset_id')
        if asset_id:
            from assets import assets_db
            asset = next((a for a in assets_db if a['id'] == asset_id), None)
        else:
            asset = None
        
        # Find compatible parts
        from part import parts_db
        suggested_parts = []
        
        # Use issue description or work order description
        description = issue_description or work_order.get('description', '')
        description_lower = description.lower()
        
        for part in parts_db:
            relevance_score = 0.0
            reasons = []
            
            # Check asset compatibility
            if asset_id and asset_id in part.get('compatible_assets', []):
                relevance_score += 0.5
                reasons.append("Compatible with asset")
            
            # Check description keywords
            part_keywords = [
                part['name'].lower(),
                part['category'].lower(),
                part['description'].lower()
            ]
            
            for keyword in part_keywords:
                if any(word in description_lower for word in keyword.split()):
                    relevance_score += 0.2
                    reasons.append("Keyword match in description")
                    break
            
            # Check common maintenance parts for asset category
            if asset and asset.get('category'):
                asset_category = asset['category'].lower()
                common_parts = {
                    'mechanical': ['bearing', 'seal', 'belt', 'oil'],
                    'electrical': ['fuse', 'relay', 'contact', 'wire'],
                    'hvac': ['filter', 'belt', 'motor', 'thermostat'],
                    'hydraulic': ['hose', 'fitting', 'seal', 'filter']
                }
                
                if asset_category in common_parts:
                    if any(common in part['name'].lower() for common in common_parts[asset_category]):
                        relevance_score += 0.3
                        reasons.append(f"Common {asset_category} part")
            
            # Only suggest parts with decent relevance
            if relevance_score >= 0.3:
                suggested_parts.append({
                    'part_number': part['part_number'],
                    'name': part['name'],
                    'description': part['description'],
                    'category': part['category'],
                    'manufacturer': part.get('manufacturer'),
                    'in_stock': part.get('quantity_on_hand', 0),
                    'unit_cost': part.get('unit_cost', 0),
                    'relevance_score': relevance_score,
                    'reasons': reasons,
                    'location': part.get('location', ''),
                    'compatibility_notes': f"Compatible with assets: {', '.join(part.get('compatible_assets', []))}"
                })
        
        # Sort by relevance score
        suggested_parts.sort(key=lambda x: x['relevance_score'], reverse=True)
        
        # Limit to top 10 suggestions
        suggested_parts = suggested_parts[:10]
        
        return {
            'work_order_id': work_order_id,
            'asset_id': asset_id,
            'asset_name': asset.get('name') if asset else 'Unknown',
            'suggested_parts': suggested_parts,
            'total_suggestions': len(suggested_parts),
            'analysis': f"Found {len(suggested_parts)} potentially relevant parts based on work order context"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Part suggestion failed: {e}")
        raise HTTPException(status_code=500, detail=f"Part suggestion failed: {str(e)}")

@ai_voice_router.get("/status")
async def get_ai_status():
    """Get AI voice processing system status"""
    
    status = {
        "whisper_model": ai_voice_processor.whisper_model is not None,
        "nlp_model": ai_voice_processor.nlp_model is not None,
        "intent_classifier": ai_voice_processor.intent_classifier is not None,
        "command_patterns": len(ai_voice_processor.command_patterns),
        "entity_types": len(ai_voice_processor.entities),
        "ready": ai_voice_processor.whisper_model is not None,
        "part_identification": True,
        "work_order_context": True
    }
    
    return JSONResponse(status)