"""
Self-Healing Playbooks for ChatterFix CMMS
Automated remediation actions for common system failures.
"""

import os
import json
import asyncio
import subprocess
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)

class PlaybookStatus(Enum):
    SUCCESS = "success"
    FAILED = "failed"
    RUNNING = "running"
    SKIPPED = "skipped"

class PlaybookTrigger(Enum):
    MANUAL = "manual"
    INCIDENT = "incident"
    SCHEDULED = "scheduled"
    THRESHOLD = "threshold"

@dataclass
class PlaybookExecution:
    """Record of playbook execution"""
    execution_id: str
    playbook_name: str
    triggered_by: PlaybookTrigger
    trigger_data: Dict[str, Any]
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: PlaybookStatus = PlaybookStatus.RUNNING
    steps_completed: int = 0
    total_steps: int = 0
    output_log: List[str] = None
    error_message: Optional[str] = None
    
    def __post_init__(self):
        if self.output_log is None:
            self.output_log = []

class SelfHealingPlaybook:
    """Base class for self-healing playbooks"""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.steps = []
        
    async def execute(self, context: Dict[str, Any] = None) -> PlaybookExecution:
        """Execute the playbook with given context"""
        execution = PlaybookExecution(
            execution_id=f"{self.name}_{int(time.time())}",
            playbook_name=self.name,
            triggered_by=context.get('trigger', PlaybookTrigger.MANUAL),
            trigger_data=context or {},
            started_at=datetime.now(),
            total_steps=len(self.steps)
        )
        
        try:
            logger.info(f"🔧 Starting playbook: {self.name}")
            execution.output_log.append(f"Starting playbook: {self.name}")
            
            for i, step in enumerate(self.steps):
                try:
                    step_result = await step(context)
                    execution.steps_completed += 1
                    execution.output_log.append(f"Step {i+1}: {step_result}")
                    logger.info(f"  ✅ Step {i+1}/{len(self.steps)}: {step_result}")
                except Exception as e:
                    execution.status = PlaybookStatus.FAILED
                    execution.error_message = str(e)
                    execution.output_log.append(f"Step {i+1} FAILED: {e}")
                    logger.error(f"  ❌ Step {i+1} failed: {e}")
                    break
            
            if execution.steps_completed == len(self.steps):
                execution.status = PlaybookStatus.SUCCESS
                logger.info(f"✅ Playbook completed: {self.name}")
            
        except Exception as e:
            execution.status = PlaybookStatus.FAILED
            execution.error_message = str(e)
            logger.error(f"❌ Playbook failed: {self.name} - {e}")
        
        execution.completed_at = datetime.now()
        return execution

class PlaybookRegistry:
    """Registry for all self-healing playbooks"""
    
    def __init__(self):
        self.playbooks: Dict[str, SelfHealingPlaybook] = {}
        self.execution_history: List[PlaybookExecution] = []
        self.setup_default_playbooks()
        
    def setup_default_playbooks(self):
        """Set up default playbooks for common issues"""
        
        # App restart playbook
        app_restart = SelfHealingPlaybook(
            "restart_app", 
            "Restart the ChatterFix CMMS application service"
        )
        app_restart.steps = [
            self._check_app_process,
            self._stop_app_gracefully, 
            self._wait_for_shutdown,
            self._start_app_service,
            self._verify_app_running,
            self._health_check
        ]
        self.register_playbook(app_restart)
        
        # Nginx reload playbook
        nginx_reload = SelfHealingPlaybook(
            "reload_nginx",
            "Reload Nginx configuration (for cert renewals, config changes)"
        )
        nginx_reload.steps = [
            self._test_nginx_config,
            self._reload_nginx_service,
            self._verify_nginx_running
        ]
        self.register_playbook(nginx_reload)
        
        # Log rotation playbook
        log_rotation = SelfHealingPlaybook(
            "rotate_logs",
            "Clean up old log files to free disk space"
        )
        log_rotation.steps = [
            self._check_disk_usage,
            self._archive_old_logs,
            self._compress_archived_logs,
            self._clean_temp_files,
            self._verify_disk_space
        ]
        self.register_playbook(log_rotation)
        
        # Cache warming playbook
        cache_warming = SelfHealingPlaybook(
            "warm_caches",
            "Pre-load application caches after startup"
        )
        cache_warming.steps = [
            self._check_app_health,
            self._warm_dashboard_cache,
            self._warm_asset_cache,
            self._warm_workorder_cache,
            self._verify_cache_performance
        ]
        self.register_playbook(cache_warming)
        
        # System health check playbook
        health_check = SelfHealingPlaybook(
            "system_health_check",
            "Comprehensive system health verification"
        )
        health_check.steps = [
            self._check_system_resources,
            self._check_database_connection,
            self._check_external_services,
            self._check_ssl_certificates,
            self._generate_health_report
        ]
        self.register_playbook(health_check)
        
        logger.info(f"🔧 Registered {len(self.playbooks)} default playbooks")
    
    def register_playbook(self, playbook: SelfHealingPlaybook):
        """Register a new playbook"""
        self.playbooks[playbook.name] = playbook
        logger.info(f"📋 Registered playbook: {playbook.name}")
    
    async def execute_playbook(self, name: str, context: Dict[str, Any] = None) -> PlaybookExecution:
        """Execute a playbook by name"""
        if name not in self.playbooks:
            raise ValueError(f"Playbook '{name}' not found")
        
        playbook = self.playbooks[name]
        execution = await playbook.execute(context or {})
        self.execution_history.append(execution)
        
        # Keep only last 100 executions
        if len(self.execution_history) > 100:
            self.execution_history = self.execution_history[-100:]
        
        return execution
    
    def get_playbook_list(self) -> List[Dict[str, Any]]:
        """Get list of all available playbooks"""
        return [
            {
                "name": name,
                "description": playbook.description,
                "steps": len(playbook.steps)
            }
            for name, playbook in self.playbooks.items()
        ]
    
    def get_execution_history(self, limit: int = 50) -> List[PlaybookExecution]:
        """Get recent playbook execution history"""
        return self.execution_history[-limit:]
    
    # =============================================================================
    # Playbook Step Implementations
    # =============================================================================
    
    async def _check_app_process(self, context: Dict[str, Any]) -> str:
        """Check if the app process is running"""
        try:
            result = subprocess.run(
                ["pgrep", "-f", "chatterfix|main_app"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                pids = result.stdout.strip().split('\n')
                return f"App process found with PIDs: {', '.join(pids)}"
            else:
                return "App process not found"
        except Exception as e:
            return f"Failed to check app process: {e}"
    
    async def _stop_app_gracefully(self, context: Dict[str, Any]) -> str:
        """Gracefully stop the application"""
        try:
            # Try systemctl first
            result = subprocess.run(
                ["systemctl", "stop", "chatterfix-cmms"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                return "App stopped via systemctl"
            
            # Fallback to killing processes
            result = subprocess.run(
                ["pkill", "-TERM", "-f", "chatterfix"],
                capture_output=True, text=True, timeout=10
            )
            await asyncio.sleep(5)  # Wait for graceful shutdown
            return "App stopped via SIGTERM"
            
        except Exception as e:
            return f"Failed to stop app gracefully: {e}"
    
    async def _wait_for_shutdown(self, context: Dict[str, Any]) -> str:
        """Wait for application shutdown"""
        for i in range(10):  # Wait up to 10 seconds
            try:
                result = subprocess.run(
                    ["pgrep", "-f", "chatterfix"],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode != 0:
                    return f"App shutdown confirmed after {i+1} seconds"
                await asyncio.sleep(1)
            except:
                pass
        return "App may still be running after 10 seconds"
    
    async def _start_app_service(self, context: Dict[str, Any]) -> str:
        """Start the application service"""
        try:
            # Try systemctl first
            result = subprocess.run(
                ["systemctl", "start", "chatterfix-cmms"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                return "App started via systemctl"
            
            # Fallback to direct execution
            app_dir = "/Users/fredtaylor/Desktop/Projects/ai-tools/core/cmms"
            subprocess.Popen(
                ["python3", "app.py"],
                cwd=app_dir,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
            await asyncio.sleep(3)
            return "App started directly"
            
        except Exception as e:
            return f"Failed to start app: {e}"
    
    async def _verify_app_running(self, context: Dict[str, Any]) -> str:
        """Verify the application is running"""
        await asyncio.sleep(5)  # Give app time to start
        try:
            result = subprocess.run(
                ["pgrep", "-f", "chatterfix"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                return "App process verified running"
            else:
                raise Exception("App process not found after restart")
        except Exception as e:
            return f"Failed to verify app running: {e}"
    
    async def _health_check(self, context: Dict[str, Any]) -> str:
        """Perform health check on the application"""
        try:
            import aiohttp
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                async with session.get('http://localhost:8000/health') as resp:
                    if resp.status == 200:
                        return "App health check passed"
                    else:
                        return f"App health check failed: HTTP {resp.status}"
        except Exception as e:
            return f"Health check failed: {e}"
    
    async def _test_nginx_config(self, context: Dict[str, Any]) -> str:
        """Test Nginx configuration"""
        try:
            result = subprocess.run(
                ["nginx", "-t"], 
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                return "Nginx configuration test passed"
            else:
                raise Exception(f"Nginx config test failed: {result.stderr}")
        except Exception as e:
            return f"Failed to test nginx config: {e}"
    
    async def _reload_nginx_service(self, context: Dict[str, Any]) -> str:
        """Reload Nginx service"""
        try:
            result = subprocess.run(
                ["systemctl", "reload", "nginx"],
                capture_output=True, text=True, timeout=20
            )
            if result.returncode == 0:
                return "Nginx reloaded successfully"
            else:
                raise Exception(f"Nginx reload failed: {result.stderr}")
        except Exception as e:
            return f"Failed to reload nginx: {e}"
    
    async def _verify_nginx_running(self, context: Dict[str, Any]) -> str:
        """Verify Nginx is running"""
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "nginx"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and "active" in result.stdout:
                return "Nginx verified running"
            else:
                raise Exception("Nginx not active")
        except Exception as e:
            return f"Failed to verify nginx: {e}"
    
    async def _check_disk_usage(self, context: Dict[str, Any]) -> str:
        """Check current disk usage"""
        try:
            import shutil
            total, used, free = shutil.disk_usage("/")
            usage_percent = (used / total) * 100
            free_gb = free / (1024**3)
            return f"Disk usage: {usage_percent:.1f}% ({free_gb:.1f}GB free)"
        except Exception as e:
            return f"Failed to check disk usage: {e}"
    
    async def _archive_old_logs(self, context: Dict[str, Any]) -> str:
        """Archive old log files"""
        try:
            log_dirs = ["/var/log", "/tmp", "logs"]
            archived_count = 0
            
            for log_dir in log_dirs:
                if os.path.exists(log_dir):
                    # Find old log files (older than 7 days)
                    result = subprocess.run(
                        ["find", log_dir, "-name", "*.log", "-mtime", "+7"],
                        capture_output=True, text=True, timeout=30
                    )
                    if result.returncode == 0:
                        old_files = result.stdout.strip().split('\n')
                        old_files = [f for f in old_files if f]
                        archived_count += len(old_files)
            
            return f"Found {archived_count} old log files to archive"
        except Exception as e:
            return f"Failed to archive old logs: {e}"
    
    async def _compress_archived_logs(self, context: Dict[str, Any]) -> str:
        """Compress archived log files"""
        try:
            # Compress logs older than 1 day
            result = subprocess.run(
                ["find", "/var/log", "-name", "*.log", "-mtime", "+1", "-exec", "gzip", "{}", ";"],
                capture_output=True, text=True, timeout=60
            )
            return "Log compression completed"
        except Exception as e:
            return f"Failed to compress logs: {e}"
    
    async def _clean_temp_files(self, context: Dict[str, Any]) -> str:
        """Clean temporary files"""
        try:
            temp_dirs = ["/tmp", "/var/tmp"]
            cleaned_count = 0
            
            for temp_dir in temp_dirs:
                if os.path.exists(temp_dir):
                    # Remove files older than 3 days
                    result = subprocess.run(
                        ["find", temp_dir, "-type", "f", "-mtime", "+3", "-delete"],
                        capture_output=True, text=True, timeout=30
                    )
                    if result.returncode == 0:
                        cleaned_count += 1
            
            return f"Cleaned temporary files from {cleaned_count} directories"
        except Exception as e:
            return f"Failed to clean temp files: {e}"
    
    async def _verify_disk_space(self, context: Dict[str, Any]) -> str:
        """Verify disk space after cleanup"""
        try:
            import shutil
            total, used, free = shutil.disk_usage("/")
            usage_percent = (used / total) * 100
            free_gb = free / (1024**3)
            
            if usage_percent < 85:
                return f"Disk cleanup successful: {usage_percent:.1f}% used, {free_gb:.1f}GB free"
            else:
                return f"Disk still high: {usage_percent:.1f}% used - may need manual intervention"
        except Exception as e:
            return f"Failed to verify disk space: {e}"
    
    async def _check_app_health(self, context: Dict[str, Any]) -> str:
        """Check application health before cache warming"""
        return await self._health_check(context)
    
    async def _warm_dashboard_cache(self, context: Dict[str, Any]) -> str:
        """Warm up dashboard cache"""
        try:
            import aiohttp
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as session:
                endpoints = [
                    'http://localhost:8000/',
                    'http://localhost:8000/ai/predict/top-risk',
                    'http://localhost:8000/cmms/dashboard'
                ]
                
                for endpoint in endpoints:
                    try:
                        async with session.get(endpoint) as resp:
                            if resp.status == 200:
                                continue
                    except:
                        pass
                
                return "Dashboard cache warmed"
        except Exception as e:
            return f"Failed to warm dashboard cache: {e}"
    
    async def _warm_asset_cache(self, context: Dict[str, Any]) -> str:
        """Warm up asset data cache"""
        try:
            import aiohttp
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as session:
                async with session.get('http://localhost:8000/cmms/assets') as resp:
                    if resp.status == 200:
                        return "Asset cache warmed"
                    else:
                        return f"Asset cache warming failed: HTTP {resp.status}"
        except Exception as e:
            return f"Failed to warm asset cache: {e}"
    
    async def _warm_workorder_cache(self, context: Dict[str, Any]) -> str:
        """Warm up work order cache"""
        try:
            import aiohttp
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as session:
                async with session.get('http://localhost:8000/cmms/work_orders') as resp:
                    if resp.status == 200:
                        return "Work order cache warmed"
                    else:
                        return f"Work order cache warming failed: HTTP {resp.status}"
        except Exception as e:
            return f"Failed to warm work order cache: {e}"
    
    async def _verify_cache_performance(self, context: Dict[str, Any]) -> str:
        """Verify cache performance after warming"""
        try:
            start_time = time.time()
            import aiohttp
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                async with session.get('http://localhost:8000/') as resp:
                    response_time = (time.time() - start_time) * 1000
                    if response_time < 500:  # Less than 500ms
                        return f"Cache performance good: {response_time:.0f}ms response time"
                    else:
                        return f"Cache performance slow: {response_time:.0f}ms response time"
        except Exception as e:
            return f"Failed to verify cache performance: {e}"
    
    async def _check_system_resources(self, context: Dict[str, Any]) -> str:
        """Check system resource usage"""
        try:
            # Check memory usage
            with open('/proc/meminfo', 'r') as f:
                meminfo = f.read()
                total_mem = int([line for line in meminfo.split('\n') if line.startswith('MemTotal')][0].split()[1])
                available_mem = int([line for line in meminfo.split('\n') if line.startswith('MemAvailable')][0].split()[1])
                mem_usage = ((total_mem - available_mem) / total_mem) * 100
            
            # Check load average
            with open('/proc/loadavg', 'r') as f:
                load_avg = float(f.read().split()[0])
            
            return f"Memory: {mem_usage:.1f}% used, Load: {load_avg:.2f}"
        except Exception as e:
            return f"Failed to check system resources: {e}"
    
    async def _check_database_connection(self, context: Dict[str, Any]) -> str:
        """Check database connection"""
        try:
            # Simple database check - would be more sophisticated in production
            return "Database connection check passed (mock)"
        except Exception as e:
            return f"Database connection failed: {e}"
    
    async def _check_external_services(self, context: Dict[str, Any]) -> str:
        """Check external service connections"""
        try:
            # Check connectivity to external services
            return "External services check passed (mock)"
        except Exception as e:
            return f"External services check failed: {e}"
    
    async def _check_ssl_certificates(self, context: Dict[str, Any]) -> str:
        """Check SSL certificate expiration"""
        try:
            # Check SSL certificate validity
            import ssl
            import socket
            from datetime import datetime, timezone
            
            hostname = "localhost"  # Would be actual domain in production
            port = 443
            
            try:
                context = ssl.create_default_context()
                with socket.create_connection((hostname, port), timeout=10) as sock:
                    with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                        cert = ssock.getpeercert()
                        expiry_date = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                        days_until_expiry = (expiry_date - datetime.now()).days
                        
                        if days_until_expiry > 30:
                            return f"SSL certificate valid for {days_until_expiry} days"
                        else:
                            return f"SSL certificate expires soon: {days_until_expiry} days"
            except:
                return "SSL certificate check skipped (no HTTPS configured)"
                
        except Exception as e:
            return f"SSL certificate check failed: {e}"
    
    async def _generate_health_report(self, context: Dict[str, Any]) -> str:
        """Generate overall health report"""
        try:
            timestamp = datetime.now().isoformat()
            return f"System health report generated at {timestamp}"
        except Exception as e:
            return f"Failed to generate health report: {e}"

# Global playbook registry instance
playbook_registry = PlaybookRegistry()