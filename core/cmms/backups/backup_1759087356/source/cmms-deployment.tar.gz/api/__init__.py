#!/usr/bin/env python3
"""
CMMS API Package - CRUD routers for all entities
"""
from .parts_api import router as parts_router
from .equipment_api import router as equipment_router  
from .work_orders_api import router as work_orders_router

__all__ = ["parts_router", "equipment_router", "work_orders_router"]