#!/usr/bin/env python3
"""
CMMS Authentication Middleware and Dependencies
Complete RBAC system with consistent error handling and request IDs
"""
from __future__ import annotations
import os
import uuid
import secrets
from typing import Dict, List, Optional, Set, Union
from datetime import datetime, timezone
from functools import wraps

from fastapi import Depends, HTTPException, status, Request, Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from pydantic import BaseModel
from enum import Enum


# =============================================================================
# Configuration and Constants
# =============================================================================

# Use the same JWT config as existing system
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-secret-key-change-in-production")
ALGORITHM = "HS256"

# Security instance
security = HTTPBearer(auto_error=False)


# =============================================================================
# Data Models
# =============================================================================

class UserRole(str, Enum):
    ADMIN = "admin"
    MANAGER = "manager" 
    TECHNICIAN = "technician"
    VIEWER = "viewer"


class Permission(str, Enum):
    # Work Orders
    WORK_ORDERS_VIEW = "work_orders:view"
    WORK_ORDERS_CREATE = "work_orders:create"
    WORK_ORDERS_UPDATE = "work_orders:update"
    WORK_ORDERS_DELETE = "work_orders:delete"
    
    # Assets/Equipment
    ASSETS_VIEW = "assets:view"
    ASSETS_CREATE = "assets:create"
    ASSETS_UPDATE = "assets:update"
    ASSETS_DELETE = "assets:delete"
    
    # Parts
    PARTS_VIEW = "parts:view"
    PARTS_CREATE = "parts:create"
    PARTS_UPDATE = "parts:update"
    PARTS_DELETE = "parts:delete"


class AuthUser(BaseModel):
    id: str
    username: str
    email: str
    role: UserRole
    is_active: bool = True
    permissions: Set[str] = set()

    def has_permission(self, permission: Union[Permission, str]) -> bool:
        """Check if user has specific permission"""
        perm_str = permission.value if isinstance(permission, Permission) else permission
        return perm_str in self.permissions

    def has_any_permission(self, *permissions: Union[Permission, str]) -> bool:
        """Check if user has any of the specified permissions"""
        return any(self.has_permission(perm) for perm in permissions)


# =============================================================================
# Role-Based Permissions Matrix
# =============================================================================

ROLE_PERMISSIONS: Dict[UserRole, Set[Permission]] = {
    UserRole.ADMIN: {
        # Full access to everything
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_CREATE,
        Permission.WORK_ORDERS_UPDATE,
        Permission.WORK_ORDERS_DELETE,
        Permission.ASSETS_VIEW,
        Permission.ASSETS_CREATE,
        Permission.ASSETS_UPDATE,
        Permission.ASSETS_DELETE,
        Permission.PARTS_VIEW,
        Permission.PARTS_CREATE,
        Permission.PARTS_UPDATE,
        Permission.PARTS_DELETE,
    },
    
    UserRole.MANAGER: {
        # Management access - can view, create, update most things, limited delete
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_CREATE,
        Permission.WORK_ORDERS_UPDATE,
        Permission.ASSETS_VIEW,
        Permission.ASSETS_CREATE,
        Permission.ASSETS_UPDATE,
        Permission.PARTS_VIEW,
        Permission.PARTS_CREATE,
        Permission.PARTS_UPDATE,
    },
    
    UserRole.TECHNICIAN: {
        # Technician access - can view most, update work orders assigned to them
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_UPDATE,  # Only own work orders (enforced in business logic)
        Permission.ASSETS_VIEW,
        Permission.PARTS_VIEW,
    },
    
    UserRole.VIEWER: {
        # Read-only access
        Permission.WORK_ORDERS_VIEW,
        Permission.ASSETS_VIEW,
        Permission.PARTS_VIEW,
    }
}


# =============================================================================
# Mock User Database (for testing)
# =============================================================================

# Mock users for testing different roles
MOCK_USERS: Dict[str, Dict] = {
    "admin": {
        "id": "user-admin-001",
        "username": "admin",
        "email": "admin@chatterfix.com",
        "role": UserRole.ADMIN,
        "is_active": True,
    },
    "manager": {
        "id": "user-manager-001", 
        "username": "manager",
        "email": "manager@chatterfix.com",
        "role": UserRole.MANAGER,
        "is_active": True,
    },
    "tech": {
        "id": "user-tech-001",
        "username": "tech",
        "email": "tech@chatterfix.com", 
        "role": UserRole.TECHNICIAN,
        "is_active": True,
    },
    "viewer": {
        "id": "user-viewer-001",
        "username": "viewer",
        "email": "viewer@chatterfix.com",
        "role": UserRole.VIEWER,
        "is_active": True,
    }
}


# =============================================================================
# Error Response Models
# =============================================================================

class ErrorResponse(BaseModel):
    error: str
    message: str
    request_id: str
    timestamp: str = datetime.utcnow().isoformat()


# =============================================================================
# Authentication Functions
# =============================================================================

def generate_request_id() -> str:
    """Generate unique request ID"""
    return str(uuid.uuid4())[:8]


def create_mock_token(username: str) -> str:
    """Create a mock JWT token for testing (simplified)"""
    user = MOCK_USERS.get(username)
    if not user:
        raise ValueError(f"Unknown user: {username}")
    
    payload = {
        "user_id": user["id"],
        "username": user["username"],
        "role": user["role"].value,
        "exp": datetime.now(timezone.utc).timestamp() + 3600,  # 1 hour
    }
    
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def get_user_permissions(role: UserRole) -> Set[str]:
    """Get permissions for a role"""
    permissions = ROLE_PERMISSIONS.get(role, set())
    return {perm.value for perm in permissions}


async def get_current_user(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> AuthUser:
    """Get current authenticated user"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={
            "error": "authentication_required",
            "message": "Valid authentication credentials required",
            "request_id": generate_request_id()
        },
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    if not credentials:
        raise credentials_exception
    
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("username")
        role_str: str = payload.get("role")
        user_id: str = payload.get("user_id")
        
        if username is None or role_str is None:
            raise credentials_exception
            
        role = UserRole(role_str)
        
    except (JWTError, ValueError):
        raise credentials_exception
    
    # Get user data (in production, this would be from database)
    user_data = MOCK_USERS.get(username)
    if not user_data or not user_data["is_active"]:
        raise credentials_exception
    
    # Create AuthUser with permissions
    permissions = get_user_permissions(role)
    user = AuthUser(
        id=user_id,
        username=username,
        email=user_data["email"],
        role=role,
        is_active=user_data["is_active"],
        permissions=permissions
    )
    
    return user


# =============================================================================
# RBAC Decorators and Dependencies
# =============================================================================

def require_permissions(*required_permissions: Permission):
    """Dependency factory to require specific permissions"""
    async def permission_checker(
        request: Request,
        user: AuthUser = Depends(get_current_user)
    ) -> AuthUser:
        request_id = generate_request_id()
        
        # Add request ID to response headers
        request.state.request_id = request_id
        
        missing_permissions = []
        for perm in required_permissions:
            if not user.has_permission(perm):
                missing_permissions.append(perm.value)
        
        if missing_permissions:
            error_response = ErrorResponse(
                error="insufficient_permissions",
                message=f"Access denied. Required permissions: {', '.join(missing_permissions)}",
                request_id=request_id
            )
            
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=error_response.dict(),
                headers={"X-Request-ID": request_id}
            )
        
        return user
    
    return permission_checker


def require_role(*required_roles: UserRole):
    """Dependency factory to require specific roles"""
    async def role_checker(
        request: Request,
        user: AuthUser = Depends(get_current_user)
    ) -> AuthUser:
        request_id = generate_request_id()
        
        # Add request ID to response headers  
        request.state.request_id = request_id
        
        if user.role not in required_roles:
            role_names = [role.value for role in required_roles]
            error_response = ErrorResponse(
                error="insufficient_role_access",
                message=f"Access denied. Required roles: {', '.join(role_names)}. Current role: {user.role.value}",
                request_id=request_id
            )
            
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=error_response.dict(),
                headers={"X-Request-ID": request_id}
            )
        
        return user
    
    return role_checker


# =============================================================================
# Specific Permission Dependencies
# =============================================================================

# Work Orders
RequireWorkOrdersView = require_permissions(Permission.WORK_ORDERS_VIEW)
RequireWorkOrdersCreate = require_permissions(Permission.WORK_ORDERS_CREATE) 
RequireWorkOrdersUpdate = require_permissions(Permission.WORK_ORDERS_UPDATE)
RequireWorkOrdersDelete = require_permissions(Permission.WORK_ORDERS_DELETE)

# Assets/Equipment
RequireAssetsView = require_permissions(Permission.ASSETS_VIEW)
RequireAssetsCreate = require_permissions(Permission.ASSETS_CREATE)
RequireAssetsUpdate = require_permissions(Permission.ASSETS_UPDATE)
RequireAssetsDelete = require_permissions(Permission.ASSETS_DELETE)

# Parts
RequirePartsView = require_permissions(Permission.PARTS_VIEW)
RequirePartsCreate = require_permissions(Permission.PARTS_CREATE)
RequirePartsUpdate = require_permissions(Permission.PARTS_UPDATE)
RequirePartsDelete = require_permissions(Permission.PARTS_DELETE)

# Role-based dependencies
RequireAdmin = require_role(UserRole.ADMIN)
RequireManager = require_role(UserRole.MANAGER, UserRole.ADMIN)
RequireTechnician = require_role(UserRole.TECHNICIAN, UserRole.MANAGER, UserRole.ADMIN)


# =============================================================================
# Helper Functions for Testing
# =============================================================================

def create_test_tokens() -> Dict[str, str]:
    """Create test tokens for all user roles (for testing)"""
    return {
        "admin": create_mock_token("admin"),
        "manager": create_mock_token("manager"), 
        "technician": create_mock_token("tech"),
        "viewer": create_mock_token("viewer")
    }


# =============================================================================
# Middleware for Adding Request ID to Responses
# =============================================================================

async def add_request_id_header(request: Request, call_next):
    """Middleware to add request ID to response headers"""
    response = await call_next(request)
    
    # Add request ID if it was set during processing
    if hasattr(request.state, 'request_id'):
        response.headers["X-Request-ID"] = request.state.request_id
    
    return response