#!/usr/bin/env python3
"""
CMMS Equipment/Assets API - CRUD operations for equipment management
"""
from __future__ import annotations
import uuid
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends, Query, status, Request
from fastapi.responses import JSONResponse

from .schemas import (
    AssetCreate, AssetUpdate, AssetResponse, AssetsListResponse,
    AssetQueryParams, ErrorResponse
)
from .auth_middleware import (
    AuthUser, RequireAssetsView, RequireAssetsCreate,
    RequireAssetsUpdate, RequireAssetsDelete, generate_request_id
)
from db.repository.assets import (
    list_assets, session_scope
)
from db.models import AssetORM

# =============================================================================
# Router Setup
# =============================================================================

router = APIRouter(prefix="/api/equipment", tags=["equipment"])


# =============================================================================
# Helper Functions
# =============================================================================

def create_error_response(error: str, message: str, status_code: int = 500, request_id: str = None) -> JSONResponse:
    """Create consistent error response with request ID"""
    if not request_id:
        request_id = generate_request_id()
    
    return JSONResponse(
        status_code=status_code,
        content={
            "error": error,
            "message": message,
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat()
        },
        headers={"X-Request-ID": request_id}
    )


def orm_to_response(asset: AssetORM) -> AssetResponse:
    """Convert ORM model to response schema"""
    return AssetResponse(
        id=asset.id,
        name=asset.name,
        category=asset.category,
        location=asset.location,
        status=asset.status,
        condition=asset.condition,
        manufacturer=asset.manufacturer,
        model=asset.model,
        serial_number=asset.serial_number,
        installation_date=asset.installation_date,
        last_maintenance=asset.last_maintenance,
        next_maintenance=asset.next_maintenance,
        maintenance_frequency=asset.maintenance_frequency,
        criticality=asset.criticality,
        cost_center=asset.cost_center,
        specifications=asset.specifications,
        parent_asset_id=asset.parent_asset_id,
        health_score=asset.health_score,
    )


def create_asset_orm(asset_data: AssetCreate, asset_id: str) -> AssetORM:
    """Create ORM model from schema"""
    return AssetORM(
        id=asset_id,
        name=asset_data.name,
        category=asset_data.category,
        location=asset_data.location,
        status=asset_data.status,
        condition=asset_data.condition,
        manufacturer=asset_data.manufacturer,
        model=asset_data.model,
        serial_number=asset_data.serial_number,
        installation_date=asset_data.installation_date,
        maintenance_frequency=asset_data.maintenance_frequency,
        criticality=asset_data.criticality,
        cost_center=asset_data.cost_center,
        specifications=asset_data.specifications,
        parent_asset_id=asset_data.parent_asset_id,
        health_score=asset_data.health_score,
    )


# =============================================================================
# API Endpoints
# =============================================================================

@router.get("/", response_model=AssetsListResponse)
async def list_equipment_endpoint(
    request: Request,
    category: Optional[str] = Query(None, description="Filter by category"),
    limit: int = Query(100, ge=1, le=1000, description="Number of items to return"),
    offset: int = Query(0, ge=0, description="Number of items to skip"),
    order_by: str = Query("name", description="Sort field: name, category, location"),
    current_user: AuthUser = Depends(RequireAssetsView)
) -> AssetsListResponse:
    """Get list of equipment/assets with optional filtering and pagination"""
    try:
        # Get assets from repository
        assets = list_assets(
            category=category,
            limit=limit + 1,  # Get one extra to check if has_next
            offset=offset,
            order_by=order_by
        )
        
        # Determine if there are more results
        has_next = len(assets) > limit
        if has_next:
            assets = assets[:-1]  # Remove the extra item
        
        # Convert to response format
        items = [orm_to_response(asset) for asset in assets]
        
        # Get total count (simplified - in production you'd optimize this)
        total_assets = list_assets(category=category, limit=10000, offset=0)
        total = len(total_assets)
        
        return AssetsListResponse(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
            has_next=has_next
        )
        
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to retrieve equipment: {str(e)}",
                "request_id": request_id
            }
        )


@router.get("/{asset_id}", response_model=AssetResponse)
async def get_equipment(asset_id: str) -> AssetResponse:
    """Get a specific piece of equipment by ID"""
    try:
        with session_scope() as session:
            asset = session.get(AssetORM, asset_id)
            if not asset:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Equipment with ID {asset_id} not found"
                )
            return orm_to_response(asset)
            
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to retrieve equipment: {str(e)}",
                "request_id": request_id
            }
        )


@router.post("/", response_model=AssetResponse, status_code=status.HTTP_201_CREATED)
async def create_equipment(asset_data: AssetCreate) -> AssetResponse:
    """Create a new piece of equipment"""
    try:
        asset_id = str(uuid.uuid4())
        asset = create_asset_orm(asset_data, asset_id)
        
        with session_scope() as session:
            session.add(asset)
            # session.commit() is handled by session_scope context manager
            session.refresh(asset)
            
        return orm_to_response(asset)
        
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to create equipment: {str(e)}",
                "request_id": request_id
            }
        )


@router.put("/{asset_id}", response_model=AssetResponse)
async def update_equipment(asset_id: str, asset_update: AssetUpdate) -> AssetResponse:
    """Update an existing piece of equipment"""
    try:
        with session_scope() as session:
            asset = session.get(AssetORM, asset_id)
            if not asset:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Equipment with ID {asset_id} not found"
                )
            
            # Update only provided fields
            for field, value in asset_update.model_dump(exclude_unset=True).items():
                setattr(asset, field, value)
            
            # session.commit() is handled by session_scope
            session.refresh(asset)
            
        return orm_to_response(asset)
        
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to update equipment: {str(e)}",
                "request_id": request_id
            }
        )


@router.delete("/{asset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_equipment(asset_id: str):
    """Delete a piece of equipment"""
    try:
        with session_scope() as session:
            asset = session.get(AssetORM, asset_id)
            if not asset:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Equipment with ID {asset_id} not found"
                )
            
            session.delete(asset)
            # session.commit() is handled by session_scope
            
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to delete equipment: {str(e)}",
                "request_id": request_id
            }
        )


# =============================================================================
# Additional Equipment-specific Endpoints
# =============================================================================

@router.get("/{asset_id}/health", response_model=dict)
async def get_equipment_health(asset_id: str):
    """Get health information for a specific piece of equipment"""
    try:
        with session_scope() as session:
            asset = session.get(AssetORM, asset_id)
            if not asset:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Equipment with ID {asset_id} not found"
                )
            
            # Calculate health metrics
            health_data = {
                "asset_id": asset_id,
                "name": asset.name,
                "health_score": asset.health_score or 0.0,
                "status": asset.status or "unknown",
                "condition": asset.condition or "unknown",
                "last_maintenance": asset.last_maintenance,
                "next_maintenance": asset.next_maintenance,
                "criticality": asset.criticality or "medium",
                "recommendations": []
            }
            
            # Add recommendations based on health score
            if asset.health_score and asset.health_score < 0.3:
                health_data["recommendations"].append("Schedule immediate maintenance inspection")
            elif asset.health_score and asset.health_score < 0.6:
                health_data["recommendations"].append("Plan preventive maintenance soon")
            
            return health_data
            
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to retrieve equipment health: {str(e)}",
                "request_id": request_id
            }
        )


# =============================================================================
# Health Check
# =============================================================================

@router.get("/health", include_in_schema=False)
async def equipment_health():
    """Health check for equipment API"""
    return {"status": "healthy", "service": "equipment_api"}