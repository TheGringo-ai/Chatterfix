#!/usr/bin/env python3
"""
CMMS Parts API - CRUD operations for parts management
"""
from __future__ import annotations
import uuid
from datetime import datetime
from typing import List, Optional, Annotated
from fastapi import APIRouter, HTTPException, Depends, Query, status, Request
from fastapi.responses import JSONResponse

from .schemas import (
    PartCreate, PartUpdate, PartResponse, PartsListResponse, 
    PartQueryParams, ErrorResponse
)
from .auth_middleware import (
    AuthUser, RequirePartsView, RequirePartsCreate, 
    RequirePartsUpdate, RequirePartsDelete, generate_request_id
)
from db.repository.parts import (
    list_parts, list_low_stock_parts, session_scope
)
from db.models import PartORM

# =============================================================================
# Router Setup
# =============================================================================

router = APIRouter(prefix="/api/parts", tags=["parts"])


# =============================================================================
# Helper Functions
# =============================================================================

def create_error_response(error: str, message: str, status_code: int = 500, request_id: str = None) -> JSONResponse:
    """Create consistent error response with request ID"""
    if not request_id:
        request_id = generate_request_id()
    
    return JSONResponse(
        status_code=status_code,
        content={
            "error": error,
            "message": message,
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat()
        },
        headers={"X-Request-ID": request_id}
    )


def orm_to_response(part: PartORM) -> PartResponse:
    """Convert ORM model to response schema"""
    return PartResponse(
        id=part.id,
        part_number=part.part_number,
        name=part.name,
        description=part.description,
        category=part.category,
        manufacturer=part.manufacturer,
        supplier=part.supplier,
        unit_cost=part.unit_cost,
        quantity_on_hand=part.quantity_on_hand,
        reorder_point=part.reorder_point,
        maximum_stock=part.maximum_stock,
        unit_of_measure=part.unit_of_measure,
        location=part.location,
        last_ordered=part.last_ordered,
        compatible_assets=part.compatible_assets,
    )


def create_part_orm(part_data: PartCreate, part_id: str) -> PartORM:
    """Create ORM model from schema"""
    return PartORM(
        id=part_id,
        part_number=part_data.part_number,
        name=part_data.name,
        description=part_data.description,
        category=part_data.category,
        manufacturer=part_data.manufacturer,
        supplier=part_data.supplier,
        unit_cost=part_data.unit_cost,
        quantity_on_hand=part_data.quantity_on_hand,
        reorder_point=part_data.reorder_point,
        maximum_stock=part_data.maximum_stock,
        unit_of_measure=part_data.unit_of_measure,
        location=part_data.location,
        compatible_assets=part_data.compatible_assets,
    )


# =============================================================================
# API Endpoints
# =============================================================================

@router.get("/", response_model=PartsListResponse)
async def list_parts_endpoint(
    request: Request,
    category: Optional[str] = Query(None, description="Filter by category"),
    low_stock: bool = Query(False, description="Show only low stock items"),
    limit: int = Query(100, ge=1, le=1000, description="Number of items to return"),
    offset: int = Query(0, ge=0, description="Number of items to skip"),
    order_by: str = Query("name", description="Sort field: name, category, quantity_on_hand, reorder_point"),
    current_user: AuthUser = Depends(RequirePartsView)
) -> PartsListResponse:
    """Get list of parts with optional filtering and pagination"""
    try:
        # Get parts from repository
        parts = list_parts(
            category=category,
            low_stock=low_stock,
            limit=limit + 1,  # Get one extra to check if has_next
            offset=offset,
            order_by=order_by
        )
        
        # Determine if there are more results
        has_next = len(parts) > limit
        if has_next:
            parts = parts[:-1]  # Remove the extra item
        
        # Convert to response format
        items = [orm_to_response(part) for part in parts]
        
        # Get total count (simplified - in production you'd optimize this)
        total_parts = list_parts(category=category, low_stock=low_stock, limit=10000, offset=0)
        total = len(total_parts)
        
        return PartsListResponse(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
            has_next=has_next
        )
        
    except Exception as e:
        return create_error_response(
            error="internal_server_error",
            message=f"Failed to retrieve parts: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@router.get("/low-stock", response_model=PartsListResponse)
async def get_low_stock_parts(
    request: Request,
    category: Optional[str] = Query(None, description="Filter by category"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    current_user: AuthUser = Depends(RequirePartsView)
) -> PartsListResponse:
    """Get parts that are low on stock"""
    try:
        parts = list_low_stock_parts(category=category)
        
        # Apply pagination manually for this endpoint
        total = len(parts)
        has_next = offset + limit < total
        paginated_parts = parts[offset:offset + limit]
        
        items = [orm_to_response(part) for part in paginated_parts]
        
        return PartsListResponse(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
            has_next=has_next
        )
        
    except Exception as e:
        return create_error_response(
            error="internal_server_error",
            message=f"Failed to retrieve low stock parts: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@router.get("/{part_id}", response_model=PartResponse)
async def get_part(
    part_id: str,
    request: Request,
    current_user: AuthUser = Depends(RequirePartsView)
) -> PartResponse:
    """Get a specific part by ID"""
    try:
        with session_scope() as session:
            part = session.get(PartORM, part_id)
            if not part:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Part with ID {part_id} not found"
                )
            return orm_to_response(part)
            
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to retrieve part: {str(e)}",
                "request_id": request_id
            }
        )


@router.post("/", response_model=PartResponse, status_code=status.HTTP_201_CREATED)
async def create_part(
    part_data: PartCreate,
    request: Request,
    current_user: AuthUser = Depends(RequirePartsCreate)
) -> PartResponse:
    """Create a new part"""
    try:
        part_id = str(uuid.uuid4())
        part = create_part_orm(part_data, part_id)
        
        with session_scope() as session:
            session.add(part)
            # session.commit() is handled by session_scope context manager
            # Refresh to get any database-generated fields
            session.refresh(part)
            
        return orm_to_response(part)
        
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to create part: {str(e)}",
                "request_id": request_id
            }
        )


@router.put("/{part_id}", response_model=PartResponse)
async def update_part(
    part_id: str,
    part_update: PartUpdate,
    request: Request,
    current_user: AuthUser = Depends(RequirePartsUpdate)
) -> PartResponse:
    """Update an existing part"""
    try:
        with session_scope() as session:
            part = session.get(PartORM, part_id)
            if not part:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Part with ID {part_id} not found"
                )
            
            # Update only provided fields
            for field, value in part_update.model_dump(exclude_unset=True).items():
                setattr(part, field, value)
            
            # session.commit() is handled by session_scope
            session.refresh(part)
            
        return orm_to_response(part)
        
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to update part: {str(e)}",
                "request_id": request_id
            }
        )


@router.delete("/{part_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_part(
    part_id: str,
    request: Request,
    current_user: AuthUser = Depends(RequirePartsDelete)
):
    """Delete a part"""
    try:
        with session_scope() as session:
            part = session.get(PartORM, part_id)
            if not part:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Part with ID {part_id} not found"
                )
            
            session.delete(part)
            # session.commit() is handled by session_scope
            
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to delete part: {str(e)}",
                "request_id": request_id
            }
        )


# =============================================================================
# Health Check
# =============================================================================

@router.get("/health", include_in_schema=False)
async def parts_health():
    """Health check for parts API"""
    return {"status": "healthy", "service": "parts_api"}