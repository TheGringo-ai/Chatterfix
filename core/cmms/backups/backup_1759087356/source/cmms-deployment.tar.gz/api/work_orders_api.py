#!/usr/bin/env python3
"""
CMMS Work Orders API - CRUD operations for work order management
"""
from __future__ import annotations
import uuid
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi import status as http_status
from fastapi.responses import JSONResponse

from .schemas import (
    WorkOrderCreate, WorkOrderUpdate, WorkOrderResponse, WorkOrdersListResponse,
    WorkOrderQueryParams, ErrorResponse
)
from db.repository.work_orders import (
    list_work_orders, get_work_order, create_work_order, 
    update_work_order, session_scope
)
from db.models import WorkOrderORM

# =============================================================================
# Router Setup
# =============================================================================

router = APIRouter(prefix="/api/work-orders", tags=["work_orders"])


# =============================================================================
# Helper Functions
# =============================================================================

def generate_request_id() -> str:
    """Generate unique request ID for error tracking"""
    return str(uuid.uuid4())[:8]


def orm_to_response(work_order: WorkOrderORM) -> WorkOrderResponse:
    """Convert ORM model to response schema"""
    return WorkOrderResponse(
        id=work_order.id,
        title=work_order.title,
        description=work_order.description,
        asset_id=work_order.asset_id,
        type=work_order.type,
        priority=work_order.priority,
        status=work_order.status,
        created_at=work_order.created_at,
        created_by=work_order.created_by,
        assigned_to=work_order.assigned_to,
        due_date=work_order.due_date,
        estimated_hours=work_order.estimated_hours,
        actual_hours=work_order.actual_hours,
        cost=work_order.cost,
        sla_hours=work_order.sla_hours,
        acknowledged_at=work_order.acknowledged_at,
        closed_date=work_order.closed_date,
        escalated=work_order.escalated,
    )


def create_work_order_orm(work_order_data: WorkOrderCreate, work_order_id: str) -> WorkOrderORM:
    """Create ORM model from schema"""
    current_time = datetime.utcnow().isoformat()
    
    return WorkOrderORM(
        id=work_order_id,
        title=work_order_data.title,
        description=work_order_data.description,
        asset_id=work_order_data.asset_id,
        type=work_order_data.type,
        priority=work_order_data.priority or "medium",
        status=work_order_data.status or "open",
        created_at=current_time,
        created_by="system",  # In production, get from auth context
        assigned_to=work_order_data.assigned_to,
        due_date=work_order_data.due_date,
        estimated_hours=work_order_data.estimated_hours,
        cost=work_order_data.cost,
        sla_hours=work_order_data.sla_hours,
    )


# =============================================================================
# API Endpoints
# =============================================================================

@router.get("/", response_model=WorkOrdersListResponse)
async def list_work_orders_endpoint(
    status: Optional[str] = Query(None, description="Filter by status"),
    priority: Optional[str] = Query(None, description="Filter by priority"),
    assigned_to: Optional[str] = Query(None, description="Filter by assigned technician"),
    limit: int = Query(100, ge=1, le=1000, description="Number of items to return"),
    offset: int = Query(0, ge=0, description="Number of items to skip"),
    order_by: str = Query("created_at", description="Sort field: created_at, due_date, priority, status")
) -> WorkOrdersListResponse:
    """Get list of work orders with optional filtering and pagination"""
    try:
        # Get work orders from repository
        work_orders = list_work_orders(
            status=status,
            priority=priority,
            assigned_to=assigned_to,
            limit=limit + 1,  # Get one extra to check if has_next
            offset=offset,
            order_by=order_by
        )
        
        # Determine if there are more results
        has_next = len(work_orders) > limit
        if has_next:
            work_orders = work_orders[:-1]  # Remove the extra item
        
        # Convert to response format
        items = [orm_to_response(wo) for wo in work_orders]
        
        # Get total count (simplified - in production you'd optimize this)
        total_work_orders = list_work_orders(
            status=status, 
            priority=priority, 
            assigned_to=assigned_to, 
            limit=10000, 
            offset=0
        )
        total = len(total_work_orders)
        
        return WorkOrdersListResponse(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
            has_next=has_next
        )
        
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to retrieve work orders: {str(e)}",
                "request_id": request_id
            }
        )


@router.get("/{work_order_id}", response_model=WorkOrderResponse)
async def get_work_order_endpoint(work_order_id: str) -> WorkOrderResponse:
    """Get a specific work order by ID"""
    try:
        work_order = get_work_order(work_order_id)
        if not work_order:
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Work order with ID {work_order_id} not found"
            )
        return orm_to_response(work_order)
        
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to retrieve work order: {str(e)}",
                "request_id": request_id
            }
        )


@router.post("/", response_model=WorkOrderResponse, status_code=http_status.HTTP_201_CREATED)
async def create_work_order_endpoint(work_order_data: WorkOrderCreate) -> WorkOrderResponse:
    """Create a new work order"""
    try:
        work_order_id = str(uuid.uuid4())
        
        # Convert to dictionary for the repository function
        work_order_dict = {
            "id": work_order_id,
            "title": work_order_data.title,
            "description": work_order_data.description,
            "asset_id": work_order_data.asset_id,
            "type": work_order_data.type,
            "priority": work_order_data.priority or "medium",
            "status": work_order_data.status or "open",
            "created_at": datetime.utcnow().isoformat(),
            "created_by": "system",  # In production, get from auth context
            "assigned_to": work_order_data.assigned_to,
            "due_date": work_order_data.due_date,
            "estimated_hours": work_order_data.estimated_hours,
            "cost": work_order_data.cost,
            "sla_hours": work_order_data.sla_hours,
        }
        
        work_order = create_work_order(work_order_dict)
        return orm_to_response(work_order)
        
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to create work order: {str(e)}",
                "request_id": request_id
            }
        )


@router.put("/{work_order_id}", response_model=WorkOrderResponse)
async def update_work_order_endpoint(work_order_id: str, work_order_update: WorkOrderUpdate) -> WorkOrderResponse:
    """Update an existing work order"""
    try:
        # Get only the fields that were provided
        changes = work_order_update.model_dump(exclude_unset=True)
        
        # Handle special status changes
        if "status" in changes:
            if changes["status"] == "completed" and "closed_date" not in changes:
                changes["closed_date"] = datetime.utcnow().isoformat()
            elif changes["status"] == "in_progress" and "acknowledged_at" not in changes:
                changes["acknowledged_at"] = datetime.utcnow().isoformat()
        
        work_order = update_work_order(work_order_id, changes)
        if not work_order:
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Work order with ID {work_order_id} not found"
            )
        
        return orm_to_response(work_order)
        
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to update work order: {str(e)}",
                "request_id": request_id
            }
        )


@router.delete("/{work_order_id}", status_code=http_status.HTTP_204_NO_CONTENT)
async def delete_work_order_endpoint(work_order_id: str):
    """Delete a work order"""
    try:
        with session_scope() as session:
            work_order = session.get(WorkOrderORM, work_order_id)
            if not work_order:
                raise HTTPException(
                    status_code=http_status.HTTP_404_NOT_FOUND,
                    detail=f"Work order with ID {work_order_id} not found"
                )
            
            session.delete(work_order)
            # session.commit() is handled by session_scope
            
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to delete work order: {str(e)}",
                "request_id": request_id
            }
        )


# =============================================================================
# Additional Work Order-specific Endpoints
# =============================================================================

@router.post("/{work_order_id}/assign", response_model=WorkOrderResponse)
async def assign_work_order(work_order_id: str, assigned_to: str = Query(..., description="Technician to assign to")):
    """Assign a work order to a technician"""
    try:
        changes = {
            "assigned_to": assigned_to,
            "status": "assigned",
            "acknowledged_at": datetime.utcnow().isoformat()
        }
        
        work_order = update_work_order(work_order_id, changes)
        if not work_order:
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Work order with ID {work_order_id} not found"
            )
        
        return orm_to_response(work_order)
        
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to assign work order: {str(e)}",
                "request_id": request_id
            }
        )


@router.post("/{work_order_id}/complete", response_model=WorkOrderResponse)
async def complete_work_order(work_order_id: str, actual_hours: Optional[float] = Query(None, description="Actual hours spent")):
    """Mark a work order as completed"""
    try:
        changes = {
            "status": "completed",
            "closed_date": datetime.utcnow().isoformat()
        }
        
        if actual_hours is not None:
            changes["actual_hours"] = actual_hours
        
        work_order = update_work_order(work_order_id, changes)
        if not work_order:
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Work order with ID {work_order_id} not found"
            )
        
        return orm_to_response(work_order)
        
    except HTTPException:
        raise
    except Exception as e:
        request_id = generate_request_id()
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "internal_server_error",
                "message": f"Failed to complete work order: {str(e)}",
                "request_id": request_id
            }
        )


# =============================================================================
# Health Check
# =============================================================================

@router.get("/health", include_in_schema=False)
async def work_orders_health():
    """Health check for work orders API"""
    return {"status": "healthy", "service": "work_orders_api"}