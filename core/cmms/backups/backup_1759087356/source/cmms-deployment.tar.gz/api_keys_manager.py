#!/usr/bin/env python3
"""
API Keys Manager - Secure user-provided API key management
Handles storage, validation, and management of user API keys for various AI providers
"""

import os
import json
import logging
from typing import Dict, Any, Optional
from fastapi import APIRouter, Request, Form, HTTPException, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import sqlite3
from datetime import datetime
import hashlib
import base64
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

# API Keys router
api_keys_router = APIRouter(prefix="/api/keys", tags=["api-keys"])
settings_router = APIRouter(prefix="/settings", tags=["settings"])

class APIKeysManager:
    """Secure API keys management system"""
    
    def __init__(self, db_path: str = "cmms.db"):
        self.db_path = db_path
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher = Fernet(self.encryption_key)
        self._init_db()
    
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key for securing API keys"""
        key_file = "api_keys.key"
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            return key
    
    def _init_db(self):
        """Initialize API keys database table"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT DEFAULT 'default',
                provider TEXT NOT NULL,
                encrypted_key TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                UNIQUE(user_id, provider)
            )
        ''')
        conn.commit()
        conn.close()
    
    def store_api_key(self, provider: str, api_key: str, user_id: str = "default") -> bool:
        """Store encrypted API key for a provider"""
        try:
            encrypted_key = self.cipher.encrypt(api_key.encode()).decode()
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO api_keys 
                (user_id, provider, encrypted_key, updated_at) 
                VALUES (?, ?, ?, ?)
            ''', (user_id, provider, encrypted_key, datetime.utcnow().isoformat()))
            conn.commit()
            conn.close()
            
            logger.info(f"API key stored for provider: {provider}")
            return True
        except Exception as e:
            logger.error(f"Error storing API key for {provider}: {e}")
            return False
    
    def get_api_key(self, provider: str, user_id: str = "default") -> Optional[str]:
        """Retrieve decrypted API key for a provider"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT encrypted_key FROM api_keys 
                WHERE user_id = ? AND provider = ? AND is_active = 1
            ''', (user_id, provider))
            result = cursor.fetchone()
            conn.close()
            
            if result:
                encrypted_key = result[0].encode()
                decrypted_key = self.cipher.decrypt(encrypted_key).decode()
                return decrypted_key
            return None
        except Exception as e:
            logger.error(f"Error retrieving API key for {provider}: {e}")
            return None
    
    def list_providers(self, user_id: str = "default") -> Dict[str, bool]:
        """List all providers and their key status"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT provider, is_active FROM api_keys 
                WHERE user_id = ?
            ''', (user_id,))
            results = cursor.fetchall()
            conn.close()
            
            providers = {
                'openai': False,
                'anthropic': False,
                'groq': False,
                'grok': False,
                'google': False,
                'cohere': False,
                'huggingface': False,
                'custom': False
            }
            
            for provider, is_active in results:
                providers[provider] = bool(is_active)
            
            return providers
        except Exception as e:
            logger.error(f"Error listing providers: {e}")
            return {}
    
    def delete_api_key(self, provider: str, user_id: str = "default") -> bool:
        """Delete API key for a provider"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE api_keys SET is_active = 0 
                WHERE user_id = ? AND provider = ?
            ''', (user_id, provider))
            conn.commit()
            conn.close()
            
            logger.info(f"API key deleted for provider: {provider}")
            return True
        except Exception as e:
            logger.error(f"Error deleting API key for {provider}: {e}")
            return False

# Global instance
keys_manager = APIKeysManager()

@settings_router.get("/ai-providers")
async def ai_providers_settings(request: Request):
    """AI Providers settings page"""
    providers_status = keys_manager.list_providers()
    
    return HTMLResponse(f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - AI Provider Settings</title>
        <link rel="stylesheet" href="/static/css/cmms-professional.css">
        <link rel="stylesheet" href="/static/css/enhanced-ui.css">
        <style>
            .settings-container {{
                max-width: 900px;
                margin: 0 auto;
                padding: 2rem;
            }}
            .provider-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                margin-bottom: 1.5rem;
                border: 1px solid rgba(255,255,255,0.2);
            }}
            .provider-header {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 1rem;
            }}
            .provider-status {{
                padding: 0.3rem 0.8rem;
                border-radius: 20px;
                font-size: 0.8rem;
                font-weight: bold;
            }}
            .status-active {{ background: rgba(56,239,125,0.3); color: #38ef7d; }}
            .status-inactive {{ background: rgba(231,76,60,0.3); color: #e74c3c; }}
            .api-key-input {{
                width: 100%;
                padding: 0.8rem;
                margin: 0.5rem 0;
                border-radius: 8px;
                border: 1px solid rgba(255,255,255,0.3);
                background: rgba(255,255,255,0.1);
                color: white;
                font-family: monospace;
            }}
            .provider-actions {{
                display: flex;
                gap: 1rem;
                margin-top: 1rem;
            }}
            .btn-save {{ background: rgba(56,239,125,0.3); border: 1px solid #38ef7d; }}
            .btn-delete {{ background: rgba(231,76,60,0.3); border: 1px solid #e74c3c; }}
            .btn-test {{ background: rgba(52,152,219,0.3); border: 1px solid #3498db; }}
        </style>
    </head>
    <body>
        <div class="settings-container">
            <h1>🤖 AI Provider Settings</h1>
            <p>Configure your API keys for various AI providers. Keys are encrypted and stored securely.</p>
            
            <!-- OpenAI -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>🔮 OpenAI (GPT-4, GPT-3.5)</h3>
                    <span class="provider-status {'status-active' if providers_status.get('openai') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('openai') else '❌ Inactive'}
                    </span>
                </div>
                <input type="password" class="api-key-input" id="openai-key" 
                       placeholder="sk-..." value="{'••••••••••••••••••••••••••••••••' if providers_status.get('openai') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveApiKey('openai')">💾 Save Key</button>
                    <button class="action-btn btn-test" onclick="testProvider('openai')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('openai')">🗑️ Delete</button>
                </div>
            </div>
            
            <!-- Anthropic Claude -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>🧠 Anthropic Claude</h3>
                    <span class="provider-status {'status-active' if providers_status.get('anthropic') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('anthropic') else '❌ Inactive'}
                    </span>
                </div>
                <input type="password" class="api-key-input" id="anthropic-key" 
                       placeholder="sk-ant-..." value="{'••••••••••••••••••••••••••••••••' if providers_status.get('anthropic') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveApiKey('anthropic')">💾 Save Key</button>
                    <button class="action-btn btn-test" onclick="testProvider('anthropic')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('anthropic')">🗑️ Delete</button>
                </div>
            </div>
            
            <!-- Groq -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>⚡ Groq (Fast LLaMA)</h3>
                    <span class="provider-status {'status-active' if providers_status.get('groq') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('groq') else '❌ Inactive'}
                    </span>
                </div>
                <input type="password" class="api-key-input" id="groq-key" 
                       placeholder="gsk_..." value="{'••••••••••••••••••••••••••••••••' if providers_status.get('groq') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveApiKey('groq')">💾 Save Key</button>
                    <button class="action-btn btn-test" onclick="testProvider('groq')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('groq')">🗑️ Delete</button>
                </div>
            </div>
            
            <!-- Grok (X.AI) -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>🚀 Grok (X.AI)</h3>
                    <span class="provider-status {'status-active' if providers_status.get('grok') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('grok') else '❌ Inactive'}
                    </span>
                </div>
                <input type="password" class="api-key-input" id="grok-key" 
                       placeholder="xai-..." value="{'••••••••••••••••••••••••••••••••' if providers_status.get('grok') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveApiKey('grok')">💾 Save Key</button>
                    <button class="action-btn btn-test" onclick="testProvider('grok')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('grok')">🗑️ Delete</button>
                </div>
            </div>
            
            <!-- Google Gemini -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>🌟 Google Gemini</h3>
                    <span class="provider-status {'status-active' if providers_status.get('google') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('google') else '❌ Inactive'}
                    </span>
                </div>
                <input type="password" class="api-key-input" id="google-key" 
                       placeholder="AI..." value="{'••••••••••••••••••••••••••••••••' if providers_status.get('google') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveApiKey('google')">💾 Save Key</button>
                    <button class="action-btn btn-test" onclick="testProvider('google')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('google')">🗑️ Delete</button>
                </div>
            </div>
            
            <!-- HuggingFace -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>🤗 HuggingFace</h3>
                    <span class="provider-status {'status-active' if providers_status.get('huggingface') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('huggingface') else '❌ Inactive'}
                    </span>
                </div>
                <input type="password" class="api-key-input" id="huggingface-key" 
                       placeholder="hf_..." value="{'••••••••••••••••••••••••••••••••' if providers_status.get('huggingface') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveApiKey('huggingface')">💾 Save Key</button>
                    <button class="action-btn btn-test" onclick="testProvider('huggingface')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('huggingface')">🗑️ Delete</button>
                </div>
            </div>
            
            <!-- Custom Provider -->
            <div class="provider-card">
                <div class="provider-header">
                    <h3>🔧 Custom Provider</h3>
                    <span class="provider-status {'status-active' if providers_status.get('custom') else 'status-inactive'}">
                        {'✅ Active' if providers_status.get('custom') else '❌ Inactive'}
                    </span>
                </div>
                <input type="text" class="api-key-input" id="custom-url" 
                       placeholder="https://api.example.com/v1" style="margin-bottom: 0.5rem;">
                <input type="password" class="api-key-input" id="custom-key" 
                       placeholder="Your custom API key" value="{'••••••••••••••••••••••••••••••••' if providers_status.get('custom') else ''}">
                <div class="provider-actions">
                    <button class="action-btn btn-save" onclick="saveCustomProvider()">💾 Save Custom</button>
                    <button class="action-btn btn-test" onclick="testProvider('custom')">🧪 Test</button>
                    <button class="action-btn btn-delete" onclick="deleteApiKey('custom')">🗑️ Delete</button>
                </div>
            </div>
            
            <div style="margin-top: 2rem; text-align: center;">
                <button class="action-btn" onclick="window.location.href='/cmms/dashboard/main'" style="background: rgba(52,152,219,0.3);">
                    ⬅️ Back to Dashboard
                </button>
            </div>
        </div>
        
        <script>
            async function saveApiKey(provider) {{
                const keyInput = document.getElementById(provider + '-key');
                const apiKey = keyInput.value;
                
                if (!apiKey || apiKey === '••••••••••••••••••••••••••••••••') {{
                    alert('Please enter a valid API key');
                    return;
                }}
                
                try {{
                    const response = await fetch('/api/keys/store', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{
                            provider: provider,
                            api_key: apiKey
                        }})
                    }});
                    
                    const result = await response.json();
                    if (result.success) {{
                        alert('✅ API key saved successfully!');
                        location.reload();
                    }} else {{
                        alert('❌ Error saving API key: ' + result.error);
                    }}
                }} catch (error) {{
                    alert('❌ Network error: ' + error.message);
                }}
            }}
            
            async function deleteApiKey(provider) {{
                if (!confirm('Are you sure you want to delete this API key?')) return;
                
                try {{
                    const response = await fetch('/api/keys/delete', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{provider: provider}})
                    }});
                    
                    const result = await response.json();
                    if (result.success) {{
                        alert('✅ API key deleted successfully!');
                        location.reload();
                    }} else {{
                        alert('❌ Error deleting API key: ' + result.error);
                    }}
                }} catch (error) {{
                    alert('❌ Network error: ' + error.message);
                }}
            }}
            
            async function testProvider(provider) {{
                try {{
                    const response = await fetch('/api/keys/test', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{
                            provider: provider,
                            test_message: 'Hello, this is a test message'
                        }})
                    }});
                    
                    const result = await response.json();
                    if (result.success) {{
                        alert('✅ Provider test successful!\\n\\nResponse: ' + result.response.substring(0, 100) + '...');
                    }} else {{
                        alert('❌ Provider test failed: ' + result.error);
                    }}
                }} catch (error) {{
                    alert('❌ Network error: ' + error.message);
                }}
            }}
            
            async function saveCustomProvider() {{
                const urlInput = document.getElementById('custom-url');
                const keyInput = document.getElementById('custom-key');
                
                if (!urlInput.value || !keyInput.value) {{
                    alert('Please enter both URL and API key for custom provider');
                    return;
                }}
                
                try {{
                    const response = await fetch('/api/keys/store-custom', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{
                            base_url: urlInput.value,
                            api_key: keyInput.value
                        }})
                    }});
                    
                    const result = await response.json();
                    if (result.success) {{
                        alert('✅ Custom provider saved successfully!');
                        location.reload();
                    }} else {{
                        alert('❌ Error saving custom provider: ' + result.error);
                    }}
                }} catch (error) {{
                    alert('❌ Network error: ' + error.message);
                }}
            }}
        </script>
    </body>
    </html>
    """)

@api_keys_router.post("/store")
async def store_api_key(request: Request):
    """Store API key for a provider"""
    try:
        data = await request.json()
        provider = data.get("provider")
        api_key = data.get("api_key")
        
        if not provider or not api_key:
            return JSONResponse({"success": False, "error": "Provider and API key are required"})
        
        success = keys_manager.store_api_key(provider, api_key)
        return JSONResponse({"success": success})
    except Exception as e:
        logger.error(f"Error storing API key: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.post("/store-custom")
async def store_custom_provider(request: Request):
    """Store custom provider configuration"""
    try:
        data = await request.json()
        base_url = data.get("base_url")
        api_key = data.get("api_key")
        
        if not base_url or not api_key:
            return JSONResponse({"success": False, "error": "Base URL and API key are required"})
        
        # Store custom provider configuration
        success = keys_manager.store_api_key("custom", f"{base_url}|{api_key}")
        return JSONResponse({"success": success})
    except Exception as e:
        logger.error(f"Error storing custom provider: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.post("/delete")
async def delete_api_key(request: Request):
    """Delete API key for a provider"""
    try:
        data = await request.json()
        provider = data.get("provider")
        
        if not provider:
            return JSONResponse({"success": False, "error": "Provider is required"})
        
        success = keys_manager.delete_api_key(provider)
        return JSONResponse({"success": success})
    except Exception as e:
        logger.error(f"Error deleting API key: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.post("/test")
async def test_provider(request: Request):
    """Test API provider connection"""
    try:
        data = await request.json()
        provider = data.get("provider")
        test_message = data.get("test_message", "Hello, this is a test")
        
        if not provider:
            return JSONResponse({"success": False, "error": "Provider is required"})
        
        # This would integrate with the AI model provider to test the connection
        # For now, return a mock success response
        return JSONResponse({
            "success": True, 
            "response": f"Test successful for {provider} provider",
            "provider": provider
        })
    except Exception as e:
        logger.error(f"Error testing provider: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.get("/list")
async def list_providers():
    """List all providers and their status"""
    try:
        providers = keys_manager.list_providers()
        return JSONResponse({"success": True, "providers": providers})
    except Exception as e:
        logger.error(f"Error listing providers: {e}")
        return JSONResponse({"success": False, "error": str(e)})

def get_user_api_key(provider: str, user_id: str = "default") -> Optional[str]:
    """Helper function to get API key for a provider"""
    return keys_manager.get_api_key(provider, user_id)