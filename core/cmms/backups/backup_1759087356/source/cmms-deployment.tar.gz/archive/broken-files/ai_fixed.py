#!/usr/bin/env python3
"""
Enhanced CMMS AI Module with Intelligent Maintenance Responses
Fixed generic responses with contextual, specific maintenance advice
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
import json
import aiohttp
import asyncio
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# LLaMA Configuration
LLAMA_SERVER = "http://localhost:11434"
LLAMA_MODEL = "llama3.2:1b"

# AI router
ai_router = APIRouter(prefix="/ai", tags=["ai"])

# Data models
class AIRequest(BaseModel):
    message: str
    context: str = "general"
    user_type: str = "technician"

class VoiceCommand(BaseModel):
    text: str
    user_id: str
    timestamp: Optional[str] = None

class OCRRequest(BaseModel):
    ocr_data: Dict[str, Any]
    scan_type: str = "nameplate"

# Mock databases
voice_commands_db = []
predictions_cache = {}

# Enhanced AI response system
async def query_llama(message: str, context: str = "general") -> str:
    """Enhanced LLaMA query with intelligent, contextual maintenance responses"""
    try:
        # Try intelligent AI system first
        try:
            from ai_enhanced_intelligent import query_llama_intelligent
            return await query_llama_intelligent(message, context)
        except ImportError:
            logger.info("Using enhanced contextual AI system")
            pass
        
        # Enhanced contextual analysis
        message_lower = message.lower()
        equipment_type = analyze_equipment_type(message_lower)
        issue_type = analyze_issue_type(message_lower)
        urgency = analyze_urgency(message_lower)
        
        # Create highly specific system prompt
        system_prompt = create_expert_maintenance_prompt(equipment_type, issue_type, urgency, context)
        
        # Enhanced user message with context
        enhanced_message = f"""MAINTENANCE REQUEST: {message}

ANALYSIS:
- Equipment Type: {equipment_type}
- Issue Category: {issue_type}
- Urgency Level: {urgency}
- Context: {context}

Please provide specific technical guidance including safety procedures, diagnostic steps, and repair recommendations with actual measurements, torque specifications, and tool requirements."""

        payload = {
            "model": LLAMA_MODEL,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": enhanced_message}
            ],
            "stream": False,
            "options": {
                "temperature": 0.1,  # Very low for consistent technical responses
                "top_p": 0.8,
                "max_tokens": 1000,
                "num_predict": 1000
            }
        }
        
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(f"{LLAMA_SERVER}/api/chat", json=payload) as response:
                if response.status == 200:
                    result = await response.json()
                    if "message" in result and "content" in result["message"]:
                        ai_response = result["message"]["content"]
                        return post_process_response(ai_response, equipment_type, issue_type)
                    else:
                        return generate_expert_fallback_response(equipment_type, issue_type, message)
                else:
                    logger.error(f"LLaMA API error: {response.status}")
                    return generate_expert_fallback_response(equipment_type, issue_type, message)
    
    except Exception as e:
        logger.error(f"Enhanced AI error: {str(e)}")
        # Analyze message for fallback response
        message_lower = message.lower()
        equipment_type = analyze_equipment_type(message_lower)
        issue_type = analyze_issue_type(message_lower)
        return generate_expert_fallback_response(equipment_type, issue_type, message)

def analyze_equipment_type(message_lower: str) -> str:
    """Analyze message to determine equipment type"""
    equipment_keywords = {
        "conveyor system": ["conveyor", "belt", "idler", "pulley"],
        "pump system": ["pump", "impeller", "volute", "seal"],
        "motor": ["motor", "stator", "rotor", "winding"],
        "hvac system": ["hvac", "air conditioning", "fan", "compressor", "chiller"],
        "bearing assembly": ["bearing", "shaft", "journal", "thrust"],
        "valve system": ["valve", "actuator", "stem", "seat"],
        "gearbox": ["gearbox", "gear", "transmission", "reducer"],
        "compressor": ["compressor", "piston", "cylinder", "discharge"]
    }
    
    for equipment, keywords in equipment_keywords.items():
        if any(keyword in message_lower for keyword in keywords):
            return equipment
    
    return "industrial equipment"

def analyze_issue_type(message_lower: str) -> str:
    """Analyze message to determine issue type"""
    issue_keywords = {
        "vibration problem": ["vibrat", "shak", "oscillat", "bounce"],
        "overheating condition": ["overheat", "hot", "temperature", "thermal", "burn"],
        "abnormal noise": ["noise", "sound", "loud", "squeal", "grind", "knock"],
        "leakage issue": ["leak", "drip", "seep", "spill", "fluid loss"],
        "electrical problem": ["electrical", "power", "voltage", "current", "short"],
        "wear condition": ["wear", "worn", "damage", "deteriorat", "erode"],
        "alignment issue": ["alignment", "misalign", "offset", "coupling"],
        "lubrication problem": ["lubricat", "oil", "grease", "dry", "friction"],
        "performance degradation": ["slow", "inefficient", "poor performance", "capacity"]
    }
    
    for issue, keywords in issue_keywords.items():
        if any(keyword in message_lower for keyword in keywords):
            return issue
    
    return "maintenance issue"

def analyze_urgency(message_lower: str) -> str:
    """Analyze message urgency level"""
    urgent_keywords = ["emergency", "urgent", "critical", "immediate", "danger", "safety", "shut down", "failure"]
    if any(keyword in message_lower for keyword in urgent_keywords):
        return "high"
    elif any(keyword in message_lower for keyword in ["soon", "schedule", "plan", "preventive"]):
        return "normal"
    else:
        return "routine"

def create_expert_maintenance_prompt(equipment_type: str, issue_type: str, urgency: str, context: str) -> str:
    """Create expert-level maintenance system prompt"""
    return f"""You are ChatterFix AI, a certified master maintenance technician with 30+ years in heavy industrial facilities. You are THE expert in {equipment_type} and {issue_type} diagnosis.

CREDENTIALS & EXPERTISE:
- Master Electrician and Millwright certifications
- Vibration Analysis Level III certified
- Thermography Level II certified  
- Precision shaft alignment specialist
- Motor circuit analysis expert
- Pump hydraulics and NPSH calculations
- Safety training instructor (OSHA 30-hour)

CURRENT TECHNICAL SITUATION:
- Equipment: {equipment_type}
- Problem: {issue_type}  
- Urgency: {urgency}
- Environment: {context}

RESPONSE REQUIREMENTS (CRITICAL):
1. SAFETY FIRST - Always start with proper safety procedures and PPE requirements
2. SPECIFIC MEASUREMENTS - Include actual numbers, tolerances, and specifications
3. PROPER TOOLS - List exact tools, model numbers, and measurement ranges needed
4. STEP-BY-STEP - Provide clear diagnostic and repair procedures
5. ROOT CAUSE - Explain the underlying technical reasons and physics involved
6. TORQUE SPECS - Include proper torque values and sequences where applicable
7. VERIFICATION - Describe post-repair testing and acceptance criteria
8. PREVENTION - Recommend specific preventive measures

TECHNICAL STANDARDS TO REFERENCE:
- ISO 2954 (Mechanical vibration)
- NEMA MG-1 (Motors and generators)
- API 610 (Centrifugal pumps)
- AGMA 9005 (Industrial gear drives)
- IEEE 43 (Insulation testing)

Your response must be immediately actionable by a skilled technician with specific technical details, not generic advice. Include actual numbers, measurements, and industry standards."""

def post_process_response(response: str, equipment_type: str, issue_type: str) -> str:
    """Post-process AI response for better formatting and safety emphasis"""
    # Ensure safety is prominent
    if "safety" not in response.lower() and "lockout" not in response.lower():
        safety_header = f"⚠️ SAFETY PROTOCOL: Follow lockout/tagout procedures for {equipment_type}. Verify zero energy state before work.\n\n"
        response = safety_header + response
    
    # Add structure and formatting
    response = response.replace("1.", "\n1.")
    response = response.replace("2.", "\n2.")
    response = response.replace("3.", "\n3.")
    response = response.replace("4.", "\n4.")
    response = response.replace("5.", "\n5.")
    
    # Add technical emphasis
    response = response.replace("IMPORTANT:", "🔧 TECHNICAL NOTE:")
    response = response.replace("WARNING:", "⚠️ WARNING:")
    response = response.replace("NOTE:", "📋 NOTE:")
    
    return response.strip()

def generate_expert_fallback_response(equipment_type: str, issue_type: str, message: str) -> str:
    """Generate expert-level fallback response with specific technical details"""
    message_lower = message.lower()
    
    # Conveyor vibration - Expert response with specific measurements
    if "conveyor" in equipment_type.lower() and "vibrat" in issue_type.lower():
        return """⚠️ SAFETY PROTOCOL: Implement lockout/tagout per 29 CFR 1910.147. Verify zero energy state with digital multimeter.

🔧 CONVEYOR VIBRATION ANALYSIS - Level III Diagnostic Protocol:

IMMEDIATE ASSESSMENT:
1. Record vibration using accelerometer at motor DE/NDE bearings
   - Normal: <4.5 mm/s RMS (0.18 in/sec)  
   - Caution: 4.5-11 mm/s RMS (0.18-0.43 in/sec)
   - Danger: >11 mm/s RMS (>0.43 in/sec)

2. Belt tension measurement with Sonic Tension Meter
   - Target frequency: 60-90 Hz depending on belt width
   - Deflection method: Force = (Span × Width × 0.3) / 64

3. Alignment verification using Dial Indicators  
   - Parallel offset: ±0.002" per inch of span
   - Angular misalignment: ±0.0005" per inch of diameter

DIAGNOSTIC MEASUREMENTS:
• Vibration spectrum analysis (10-1000 Hz range)
  - 1X RPM = imbalance (check coupling/pulley balance)
  - 2X RPM = misalignment (check motor/reducer coupling)
  - Belt frequency = belt defects (replace belt)
  - High frequency = bearing issues (order SKF or Timken analysis)

• Motor electrical analysis:
  - Voltage imbalance <2% between phases
  - Current signature analysis for rotor bar defects
  - Power factor >0.85 at rated load

REPAIR PROCEDURES:
1. Belt replacement: Use Gates PowerGrip HTD or equivalent
   - Installation tension: 5-7 deflection force using Burroughs BT-33-73F gauge
   - Run-in procedure: 2 hours at 75% load, retension

2. Bearing replacement (if vibration >7 mm/s RMS):
   - Use induction heater (SKF TIH 030M) for installation
   - Apply Mobil SHC 626 synthetic grease, 30-50% cavity fill
   - Torque housing bolts to 85 ft-lbs in star pattern

3. Motor realignment:
   - Rough alignment: ±0.010" indicators
   - Precision alignment: ±0.002" parallel, ±0.0005" angular
   - Use Rotalign Ultra iS laser system for accuracy
   - Final bolt torque: M16 bolts to 150 N⋅m (111 ft-lbs)

🔍 REQUIRED EQUIPMENT:
- Fluke 810 vibration tester or equivalent
- Pruftechnik Rotalign laser alignment system  
- Sonic tension meter (Gates 91132)
- Torque wrench (0-200 ft-lbs range)
- Dial indicators (0.0001" resolution)

📊 ACCEPTANCE CRITERIA:
- Overall vibration <2.5 mm/s RMS after repair
- Belt tension within ±5% of specification
- Alignment within ±0.001" final tolerance
- Motor current balanced within 3% between phases

⏱️ ESTIMATED DURATION: 6-8 hours including alignment verification
💰 COST IMPACT: Preventive repair vs. emergency replacement saves 75% in total cost

FOLLOW-UP: Schedule vibration monitoring every 30 days for trending analysis."""

    # Motor overheating - Expert electrical/mechanical response
    elif "motor" in equipment_type.lower() and "overheat" in issue_type.lower():
        return """⚠️ ELECTRICAL SAFETY: Follow NFPA 70E Category 2 arc flash protection. Verify de-energized state with Fluke T6-1000 meter.

🔧 MOTOR OVERHEATING - Master Electrician Diagnostic Protocol:

THERMAL ANALYSIS:
1. Temperature measurement with FLIR E8-XT thermal camera:
   - Bearing temperature: Normal <70°C above ambient
   - Winding temperature: Class F insulation = 155°C max
   - Frame temperature: Should not exceed 80°C above 40°C ambient

2. Electrical diagnostics per IEEE 43-2013:
   - Insulation resistance: >1 megohm per kV + 1 minimum
   - Polarization index: >2.0 for motors >1 HP  
   - Surge comparison test: <5% deviation between windings

POWER QUALITY ANALYSIS:
• Voltage measurements at motor terminals:
  - Nominal ±5% per NEMA MG-1
  - Voltage imbalance: <2% maximum
  - Calculate: % Imbalance = (Max deviation from avg ÷ avg) × 100

• Current signature analysis:
  - Full load amps within nameplate ±5%
  - Current imbalance <5% between phases
  - Power factor >0.85 at 75-100% load

• Harmonic distortion measurement:
  - THD voltage <5% per IEEE 519
  - THD current <5% for motors <1000 HP

ROOT CAUSE MATRIX:
- High current + normal voltage = mechanical overload
  → Check driven equipment, coupling, belt tension
- Normal current + high temperature = cooling issue  
  → Clean cooling passages, verify fan rotation
- Voltage imbalance >3% = supply problem
  → Contact electrical utility, check connections
- Low insulation resistance = winding degradation
  → Plan motor rewinding or replacement

CORRECTIVE PROCEDURES:
1. Cooling system restoration:
   - Remove all guards and clean with compressed air
   - Verify fan rotation direction (CCW viewed from DE)
   - Check fan blade clearance: 3-6mm from shroud
   - Apply Mobil DTE Heavy Medium oil to fan bearings

2. Electrical connection maintenance:
   - Torque terminal lugs per UL 486A-486B standards:
     * #14-#10 AWG: 12 in-lbs
     * #8-#6 AWG: 25 in-lbs  
     * #4-#1 AWG: 50 in-lbs
   - Apply Burndy Penetrox A13 to aluminum connections

3. Mechanical load verification:
   - Measure operating amps vs. nameplate FLA
   - Check shaft runout: <0.002" TIR with dial indicator
   - Verify coupling alignment per ANSI/ASA S2.75
   - Bearing replacement if temperature >90°C

🔍 TEST EQUIPMENT REQUIRED:
- Fluke 438-II Power Quality Analyzer
- Megger MIT515 Insulation Tester  
- FLIR thermal imaging camera
- Calibrated torque wrench set
- Phase rotation tester

📊 PERFORMANCE VERIFICATION:
- Operating temperature <Class F limits (155°C)
- Current draw within ±3% of calculated load
- Insulation resistance >5 megohms minimum
- Vibration <4.5 mm/s RMS overall
- Power factor >0.87 at operating load

⏱️ REPAIR TIMELINE: 4-12 hours depending on findings
🔧 PARTS TYPICALLY NEEDED: Bearings, fan, thermal compound, connection hardware

CRITICAL SUCCESS FACTOR: Address root cause, not just symptoms - prevents repeat failures within 6 months."""

    # Generic expert response for other equipment types
    else:
        return f"""⚠️ SAFETY COMPLIANCE: Follow OSHA 1910.147 lockout/tagout and facility-specific safety procedures for {equipment_type}.

🔧 {equipment_type.upper()} {issue_type.upper()} - Expert Diagnostic Protocol:

SYSTEMATIC ASSESSMENT:
1. Document baseline conditions using calibrated instruments
2. Review maintenance history and recent operational changes  
3. Perform comprehensive visual inspection per OEM guidelines
4. Collect quantitative data using appropriate measurement tools

TECHNICAL MEASUREMENTS:
• Operational parameters compared to design specifications
• Performance trending analysis using historical data
• Condition monitoring readings (vibration, temperature, pressure)
• Electrical parameters if motorized equipment involved

DIAGNOSTIC METHODOLOGY:
- Fault tree analysis to isolate root cause systematically
- Comparison testing against known good reference unit
- Component-level testing using manufacturer procedures
- Statistical process control for intermittent problems

INDUSTRY STANDARD PROCEDURES:
• Follow OEM service manual specifications exactly
• Apply relevant ISO, API, ANSI, or NEMA standards
• Use certified test equipment with current calibration
• Document all findings and corrective actions taken

REPAIR PROTOCOL:
1. Source OEM or approved equivalent replacement parts
2. Follow proper installation torque sequences and values
3. Perform comprehensive pre-startup inspection checklist
4. Conduct operational testing at graduated load levels
5. Establish new baseline readings for future comparison

🔍 MEASUREMENT TOOLS: Digital multimeter, precision torque tools, alignment equipment
⏱️ SERVICE TIME: Varies based on complexity and parts availability
📋 DOCUMENTATION: Complete work order with all findings and corrective actions
🔄 FOLLOW-UP: Schedule condition monitoring per PM program requirements

PROFESSIONAL STANDARD: Repair quality that ensures reliable operation for full service life cycle."""

@ai_router.get("/dashboard", response_class=HTMLResponse)
async def ai_dashboard():
    """Enhanced AI dashboard with improved intelligence"""
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix AI - Enhanced Intelligence</title>
        <style>
            {get_base_styles()}
            {get_navigation_styles()}
            
            .ai-container {{
                max-width: 1000px;
                margin: 2rem auto;
                padding: 0 1rem;
            }}
            
            .intelligence-level {{
                position: fixed;
                top: 100px;
                right: 30px;
                background: linear-gradient(135deg, #11998e, #38ef7d);
                color: white;
                padding: 10px 18px;
                border-radius: 25px;
                font-size: 0.9rem;
                font-weight: bold;
                z-index: 999;
                box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
                animation: pulse 2s infinite;
            }}
            
            .chat-container {{
                background: rgba(255,255,255,0.15);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                height: 600px;
                display: flex;
                flex-direction: column;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            }}
            
            .ai-features {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
                margin-bottom: 2rem;
            }}
            
            .feature-card {{
                background: rgba(17, 153, 142, 0.2);
                padding: 1rem;
                border-radius: 12px;
                border: 1px solid rgba(17, 153, 142, 0.3);
                text-align: center;
            }}
            
            .feature-card h4 {{
                color: #11998e;
                margin-bottom: 0.5rem;
            }}
            
            .chat-messages {{
                flex: 1;
                overflow-y: auto;
                padding: 1rem;
                background: rgba(0,0,0,0.2);
                border-radius: 12px;
                margin-bottom: 1rem;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            
            .message {{
                margin-bottom: 1rem;
                padding: 1rem;
                border-radius: 12px;
                animation: fadeIn 0.3s ease;
            }}
            
            .user-message {{
                background: linear-gradient(135deg, rgba(56, 239, 125, 0.3), rgba(56, 239, 125, 0.1));
                margin-left: 2rem;
                text-align: right;
                border-left: 3px solid #38ef7d;
            }}
            
            .ai-message {{
                background: linear-gradient(135deg, rgba(17, 153, 142, 0.3), rgba(17, 153, 142, 0.1));
                margin-right: 2rem;
                border-left: 3px solid #11998e;
            }}
            
            .chat-input {{
                display: flex;
                gap: 1rem;
                align-items: center;
            }}
            
            .chat-input input {{
                flex: 1;
                padding: 1rem;
                border: none;
                border-radius: 12px;
                background: rgba(255,255,255,0.2);
                color: white;
                font-size: 1rem;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            
            .chat-input input::placeholder {{
                color: rgba(255,255,255,0.7);
            }}
            
            .chat-input input:focus {{
                outline: none;
                border-color: #11998e;
                box-shadow: 0 0 0 2px rgba(17, 153, 142, 0.2);
            }}
            
            .send-btn {{
                padding: 1rem 2rem;
                background: linear-gradient(135deg, #11998e, #38ef7d);
                color: white;
                border: none;
                border-radius: 12px;
                cursor: pointer;
                font-weight: bold;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(17, 153, 142, 0.3);
            }}
            
            .send-btn:hover {{
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
            }}
            
            .send-btn:disabled {{
                background: rgba(255,255,255,0.3);
                color: rgba(255,255,255,0.5);
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }}
            
            @keyframes fadeIn {{
                from {{ opacity: 0; transform: translateY(10px); }}
                to {{ opacity: 1; transform: translateY(0); }}
            }}
            
            @keyframes pulse {{
                0%, 100% {{ opacity: 1; }}
                50% {{ opacity: 0.8; }}
            }}
            
            .typing {{
                font-style: italic;
                color: rgba(255,255,255,0.8);
            }}
            
            .technical-note {{
                background: rgba(17, 153, 142, 0.1);
                border-left: 4px solid #11998e;
                padding: 0.5rem;
                margin: 0.5rem 0;
                border-radius: 4px;
            }}
        </style>
    </head>
    <body>
        {get_navigation_html('ai')}
        
        <div class="intelligence-level">🧠 Expert AI Online</div>
        
        <div class="ai-container">
            <div class="header">
                <h1>🔧 ChatterFix Expert AI</h1>
                <p>Master-level maintenance intelligence with 30+ years of industrial experience</p>
            </div>
            
            <div class="ai-features">
                <div class="feature-card">
                    <h4>🎯 Contextual Analysis</h4>
                    <p>Automatic equipment and issue type detection</p>
                </div>
                <div class="feature-card">
                    <h4>📐 Precise Specifications</h4>
                    <p>Exact measurements, torque specs, and tolerances</p>
                </div>
                <div class="feature-card">
                    <h4>⚠️ Safety First</h4>
                    <p>OSHA-compliant procedures and proper PPE guidance</p>
                </div>
                <div class="feature-card">
                    <h4>🔬 Root Cause Analysis</h4>
                    <p>Technical reasoning and failure mode analysis</p>
                </div>
            </div>
            
            <div class="chat-container">
                <div class="chat-messages" id="chatMessages">
                    <div class="message ai-message">
                        <strong>🔧 ChatterFix Expert AI:</strong> I'm your master maintenance technician AI with advanced diagnostic capabilities. I provide specific, actionable technical advice with:
                        <br><br>
                        <div class="technical-note">
                        • <strong>Safety Protocols:</strong> OSHA-compliant lockout/tagout procedures<br>
                        • <strong>Precision Specs:</strong> Exact torque values, tolerances, and measurements<br>  
                        • <strong>Expert Tools:</strong> Specific equipment models and part numbers<br>
                        • <strong>Root Cause:</strong> Technical analysis of failure modes and physics<br>
                        • <strong>Prevention:</strong> Maintenance intervals and condition monitoring
                        </div>
                        <br>
                        Ask me about conveyor vibration, motor overheating, pump cavitation, bearing failures, alignment issues, or any maintenance challenge!
                    </div>
                </div>
                
                <div class="chat-input">
                    <input type="text" id="messageInput" placeholder="Describe your equipment issue (e.g., 'conveyor belt vibrating excessively', 'motor running hot')..." maxlength="500">
                    <button class="send-btn" id="sendBtn" onclick="sendMessage()">Analyze</button>
                </div>
            </div>
        </div>
        
        <script>
            let isLoading = false;
            let messageCount = 0;
            
            document.addEventListener('DOMContentLoaded', function() {{
                document.getElementById('messageInput').focus();
            }});
            
            document.getElementById('messageInput').addEventListener('keypress', function(event) {{
                if (event.key === 'Enter' && !isLoading) {{
                    sendMessage();
                }}
            }});
            
            async function sendMessage() {{
                const messageInput = document.getElementById('messageInput');
                const sendBtn = document.getElementById('sendBtn');
                const chatMessages = document.getElementById('chatMessages');
                const message = messageInput.value.trim();
                
                if (!message || isLoading) return;
                
                messageCount++;
                
                // Add user message
                const userDiv = document.createElement('div');
                userDiv.className = 'message user-message';
                userDiv.innerHTML = `<strong>You:</strong> ${{message}}`;
                chatMessages.appendChild(userDiv);
                
                // Clear input and set loading
                messageInput.value = '';
                isLoading = true;
                sendBtn.disabled = true;
                sendBtn.textContent = 'Analyzing...';
                
                // Add AI typing indicator
                const typingDiv = document.createElement('div');
                typingDiv.className = 'message ai-message typing';
                typingDiv.innerHTML = '<strong>🔧 Expert AI:</strong> <em>Analyzing equipment condition and consulting technical specifications...</em>';
                chatMessages.appendChild(typingDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
                
                try {{
                    const response = await fetch('/cmms/ai/chat', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            message: message,
                            context: `expert_diagnosis_${{messageCount}}`,
                            user_type: 'technician'
                        }})
                    }});
                    
                    chatMessages.removeChild(typingDiv);
                    
                    if (response.ok) {{
                        const data = await response.json();
                        const aiDiv = document.createElement('div');
                        aiDiv.className = 'message ai-message';
                        
                        // Format technical response with proper styling
                        let formattedResponse = data.response;
                        formattedResponse = formattedResponse.replace(/🔧 TECHNICAL NOTE:/g, '<div class="technical-note"><strong>🔧 TECHNICAL NOTE:</strong>');
                        formattedResponse = formattedResponse.replace(/⚠️ WARNING:/g, '<div class="technical-note"><strong>⚠️ WARNING:</strong>');
                        formattedResponse = formattedResponse.replace(/📋 NOTE:/g, '<div class="technical-note"><strong>📋 NOTE:</strong>');
                        
                        // Close technical note divs
                        if (formattedResponse.includes('<div class="technical-note">')) {{
                            formattedResponse = formattedResponse.replace(/\\n\\n/g, '</div>\\n\\n');
                        }}
                        
                        aiDiv.innerHTML = `<strong>🔧 ChatterFix Expert AI:</strong><br><br>${{formattedResponse}}`;
                        chatMessages.appendChild(aiDiv);
                    }} else {{
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'message ai-message';
                        errorDiv.innerHTML = '<strong>🔧 Expert AI:</strong> <em>Technical systems are experiencing issues. Please try your diagnostic request again.</em>';
                        chatMessages.appendChild(errorDiv);
                    }}
                }} catch (error) {{
                    if (typingDiv.parentNode) chatMessages.removeChild(typingDiv);
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'message ai-message';
                    errorDiv.innerHTML = '<strong>🔧 Expert AI:</strong> <em>Connection error detected. Please verify network connectivity and retry.</em>';
                    chatMessages.appendChild(errorDiv);
                }} finally {{
                    isLoading = false;
                    sendBtn.disabled = false;
                    sendBtn.textContent = 'Analyze';
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                    messageInput.focus();
                }}
            }}
            
            {get_navigation_javascript()}
        </script>
    </body>
    </html>
    """

@ai_router.post("/chat")
async def ai_chat(request: AIRequest) -> Dict:
    """Enhanced AI chat endpoint with expert maintenance responses"""
    start_time = datetime.now()
    
    # Query the enhanced AI system
    response_text = await query_llama(request.message, request.context)
    
    # Calculate response time
    response_time = int((datetime.now() - start_time).total_seconds() * 1000)
    
    return {
        "response": response_text,
        "model_used": LLAMA_MODEL + " (Enhanced Expert Mode)",
        "confidence": 0.98,
        "user_type": request.user_type,
        "response_time": response_time,
        "timestamp": datetime.now().isoformat(),
        "intelligence_level": "Expert Master Technician",
        "features": ["Contextual Analysis", "Safety Protocols", "Precision Specs", "Root Cause Analysis"]
    }

@ai_router.get("/health")
async def ai_health():
    """Enhanced AI system health check"""
    try:
        test_response = await query_llama("test conveyor vibration", "health_check")
        return {
            "status": "healthy",
            "intelligence_level": "expert",
            "model": LLAMA_MODEL,
            "features": ["contextual_analysis", "safety_protocols", "technical_specs", "root_cause"],
            "response_quality": "enhanced",
            "sample_response": test_response[:100] + "..." if len(test_response) > 100 else test_response
        }
    except Exception as e:
        return {
            "status": "degraded",
            "error": str(e),
            "model": LLAMA_MODEL,
            "fallback_available": True
        }