#!/usr/bin/env python3
"""
Enhanced ChatterFix CMMS with Integrated AIOps
Production deployment with unified interface
"""

import os
import sys
import logging
from datetime import datetime
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import AIOps components
AIOPS_AVAILABLE = False
PREDICTIVE_AVAILABLE = False

try:
    from aiops_router import router as aiops_router
    AIOPS_AVAILABLE = True
    logger.info("🤖 AIOps Self-Healing System loaded successfully")
except ImportError as e:
    logger.warning(f"⚠️ AIOps Self-Healing System not available: {e}")
    aiops_router = None

try:
    from prediction_router import router as prediction_router
    PREDICTIVE_AVAILABLE = True
    logger.info("🔮 Predictive Maintenance Engine loaded successfully")
except ImportError as e:
    logger.warning(f"⚠️ Predictive Maintenance Engine not available: {e}")
    prediction_router = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info("🚀 ChatterFix CMMS with AIOps starting up...")
    logger.info("⚙️ Equipment monitoring active")
    logger.info("📋 Work order system online")
    if AIOPS_AVAILABLE:
        logger.info("🤖 AIOps system ready")
    else:
        logger.info("⚠️ AIOps system not available")
    if PREDICTIVE_AVAILABLE:
        logger.info("🔮 Predictive maintenance ready")
    else:
        logger.info("⚠️ Predictive maintenance not available")
    logger.info("✅ ChatterFix CMMS fully operational")
    yield
    logger.info("🛑 ChatterFix CMMS shutting down...")

# Create FastAPI app
app = FastAPI(
    title="ChatterFix CMMS with AIOps",
    description="Production CMMS with Integrated AIOps Self-Healing System",
    version="3.1.0-aiops",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include AIOps Router if available
if AIOPS_AVAILABLE and aiops_router:
    app.include_router(aiops_router)

# Include Predictive Maintenance Router if available
if PREDICTIVE_AVAILABLE and prediction_router:
    app.include_router(prediction_router)

# Mount static files if available
try:
    app.mount("/static", StaticFiles(directory="static"), name="static")
    logger.info("📁 Static files mounted")
except Exception as e:
    logger.warning(f"⚠️ Could not mount static files: {e}")

@app.get("/", response_class=HTMLResponse)
async def root():
    """Enhanced main dashboard with AIOps integration"""
    aiops_status = "🟢 Active" if AIOPS_AVAILABLE else "🔴 Offline"
    pred_status = "🟢 Active" if PREDICTIVE_AVAILABLE else "🔴 Offline"
    
    aiops_buttons = ""
    pred_buttons = ""
    
    if AIOPS_AVAILABLE:
        aiops_buttons = '''
                        <a href="/ai/ops/summary/today" class="btn">📊 Today's Incidents</a>
                        <a href="/ai/ops/monitor/status" class="btn">📈 System Status</a>
                        <a href="/ai/ops/actions/playbooks" class="btn">🔧 Playbooks</a>
        '''
    else:
        aiops_buttons = '''
                        <p style="margin-top: 1rem; opacity: 0.7;">AIOps features available after integration</p>
        '''
    
    if PREDICTIVE_AVAILABLE:
        pred_buttons = '''
                        <a href="/ai/predict/top-risk" class="btn">⚠️ Top Risk Assets</a>
                        <a href="/ai/predict/health" class="btn">💚 System Health</a>
        '''
    else:
        pred_buttons = '''
                        <p style="opacity: 0.7;">Predictive features available after integration</p>
        '''
    
    return f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS v3.1.0 - AIOps Enabled</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
            }}
            .header {{ 
                background: rgba(0,0,0,0.2); 
                backdrop-filter: blur(10px);
                padding: 2rem;
                text-align: center;
                border-bottom: 1px solid rgba(255,255,255,0.1);
            }}
            .container {{ max-width: 1200px; margin: 0 auto; padding: 2rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }}
            .card {{ 
                background: rgba(255,255,255,0.1); 
                backdrop-filter: blur(10px);
                padding: 2rem; 
                border-radius: 15px; 
                border: 1px solid rgba(255,255,255,0.2);
                transition: transform 0.3s ease;
            }}
            .card:hover {{ transform: translateY(-5px); }}
            .status {{ 
                display: inline-block; 
                padding: 4px 12px; 
                border-radius: 20px; 
                font-size: 0.9rem; 
                font-weight: 600;
                background: rgba(255,255,255,0.2);
                border: 1px solid rgba(255,255,255,0.3);
            }}
            .btn {{ 
                display: inline-block;
                padding: 8px 16px; 
                margin: 4px; 
                background: linear-gradient(45deg, #007bff, #0056b3);
                color: white; 
                text-decoration: none; 
                border-radius: 8px;
                border: none;
                cursor: pointer;
                transition: all 0.3s ease;
            }}
            .btn:hover {{ 
                background: linear-gradient(45deg, #0056b3, #003d82);
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            }}
            .feature-grid {{ 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
                gap: 1rem; 
                margin-top: 1rem; 
            }}
            .feature {{ 
                background: rgba(255,255,255,0.05);
                padding: 1rem;
                border-radius: 8px;
                text-align: center;
            }}
            .aiops-banner {{
                background: linear-gradient(45deg, #28a745, #20c997);
                padding: 1rem;
                border-radius: 10px;
                margin: 1rem 0;
                text-align: center;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🤖 ChatterFix CMMS v3.1.0</h1>
            <p>Production CMMS with Integrated AIOps Self-Healing System</p>
            <div class="aiops-banner">
                ✨ Now with Autonomous Incident Detection & Remediation ✨
            </div>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card">
                    <h3>🚨 AIOps Monitoring</h3>
                    <p>Status: <span class="status">{aiops_status}</span></p>
                    <p>Real-time incident detection and automated remediation</p>
                    <div style="margin-top: 1rem;">
                        {aiops_buttons}
                    </div>
                </div>
                
                <div class="card">
                    <h3>🔮 Predictive Maintenance</h3>
                    <p>Status: <span class="status">{pred_status}</span></p>
                    <p>Asset risk prediction and maintenance scheduling</p>
                    <div style="margin-top: 1rem;">
                        {pred_buttons}
                    </div>
                </div>
                
                <div class="card">
                    <h3>⚙️ Core CMMS Features</h3>
                    <div class="feature-grid">
                        <div class="feature">
                            <h4>📋</h4>
                            <p>Work Orders</p>
                        </div>
                        <div class="feature">
                            <h4>🏭</h4>
                            <p>Assets</p>
                        </div>
                        <div class="feature">
                            <h4>👷</h4>
                            <p>Technicians</p>
                        </div>
                        <div class="feature">
                            <h4>📊</h4>
                            <p>Analytics</p>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <h3>📖 API Documentation</h3>
                    <p>Interactive API documentation and testing</p>
                    <div style="margin-top: 1rem;">
                        <a href="/docs" class="btn">📚 OpenAPI Docs</a>
                        <a href="/redoc" class="btn">📖 ReDoc</a>
                    </div>
                </div>
            </div>
            
            <div class="card" style="margin-top: 2rem;">
                <h3>🧪 Test AIOps Features</h3>
                <p>Quick test buttons to verify AIOps integration</p>
                <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 1rem;">
                    <button onclick="testHealthCheck()" class="btn">🏥 Health Check</button>
                    <button onclick="testLogScan()" class="btn">🔍 Log Scan</button>
                    <button onclick="testPrediction()" class="btn">🎯 Risk Prediction</button>
                    <button onclick="testPlaybook()" class="btn">🔧 Test Playbook</button>
                </div>
                <div id="testResults" style="margin-top: 1rem; padding: 1rem; background: rgba(0,0,0,0.2); border-radius: 8px; display: none;"></div>
            </div>
        </div>
        
        <script>
            async function testHealthCheck() {{
                showResult('Testing system health...', 'info');
                try {{
                    const response = await fetch('/health');
                    const result = await response.json();
                    showResult(`Health: ${{result.status}} - AIOps: ${{result.aiops_available ? '✅' : '❌'}} - Predictive: ${{result.predictive_available ? '✅' : '❌'}}`, 'success');
                }} catch (e) {{
                    showResult(`Health check failed: ${{e.message}}`, 'error');
                }}
            }}
            
            async function testLogScan() {{
                showResult('Triggering log scan...', 'info');
                try {{
                    const response = await fetch('/ai/ops/monitor/scan-logs', {{ method: 'POST' }});
                    const result = await response.json();
                    showResult(`Log scan: ${{result.status}} - ${{result.message}}`, 'success');
                }} catch (e) {{
                    showResult(`Log scan failed: ${{e.message}}`, 'error');
                }}
            }}
            
            async function testPrediction() {{
                showResult('Testing risk prediction...', 'info');
                try {{
                    const response = await fetch('/ai/predict/asset/PUMP-001');
                    const result = await response.json();
                    showResult(`Risk: ${{result.asset_id}} - ${{(result.risk_score * 100).toFixed(0)}}% risk, Level: ${{result.risk_level}}`, 'success');
                }} catch (e) {{
                    showResult(`Prediction failed: ${{e.message}}`, 'error');
                }}
            }}
            
            async function testPlaybook() {{
                showResult('Running health check playbook...', 'info');
                try {{
                    const response = await fetch('/ai/ops/actions/run/system_health_check', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ context: {{ test: true }} }})
                    }});
                    const result = await response.json();
                    showResult(`Playbook: ${{result.status}} (${{result.steps_completed}}/${{result.total_steps}} steps)`, 'success');
                }} catch (e) {{
                    showResult(`Playbook failed: ${{e.message}}`, 'error');
                }}
            }}
            
            function showResult(message, type) {{
                const div = document.getElementById('testResults');
                div.style.display = 'block';
                const emoji = type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';
                div.innerHTML = `<strong>${{emoji}}</strong> ${{message}}`;
                div.style.background = type === 'error' ? 'rgba(220,53,69,0.3)' : type === 'success' ? 'rgba(40,167,69,0.3)' : 'rgba(23,162,184,0.3)';
            }}
        </script>
    </body>
    </html>
    '''

@app.get("/health")
async def enhanced_health_check():
    """Enhanced health check with AIOps status"""
    return {
        "status": "healthy",
        "service": "ChatterFix CMMS v3.1.0-aiops",
        "timestamp": datetime.now().isoformat(),
        "aiops_available": AIOPS_AVAILABLE,
        "predictive_available": PREDICTIVE_AVAILABLE,
        "deployment": "production-vm-integrated",
        "features": {
            "core_cmms": True,
            "aiops_monitoring": AIOPS_AVAILABLE,
            "predictive_maintenance": PREDICTIVE_AVAILABLE,
            "self_healing": AIOPS_AVAILABLE
        }
    }

@app.get("/status")
async def system_status():
    """Comprehensive system status"""
    return {
        "system": {
            "name": "ChatterFix CMMS",
            "version": "3.1.0-aiops", 
            "deployment": "production-vm",
            "uptime": "operational"
        },
        "modules": {
            "core_cmms": "active",
            "aiops_monitoring": "active" if AIOPS_AVAILABLE else "not_integrated",
            "predictive_maintenance": "active" if PREDICTIVE_AVAILABLE else "not_integrated",
            "self_healing_playbooks": "active" if AIOPS_AVAILABLE else "not_integrated"
        },
        "integration_status": "unified_deployment",
        "vm_info": {
            "ip": "35.237.149.25",
            "port": 8000,
            "load_balanced": True
        }
    }

if __name__ == "__main__":
    import uvicorn
    logger.info("🚀 Starting Enhanced ChatterFix CMMS with AIOps")
    uvicorn.run(app, host="0.0.0.0", port=8003, log_level="info")