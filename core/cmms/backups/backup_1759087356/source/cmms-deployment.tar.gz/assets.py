#!/usr/bin/env python3
"""
CMMS Assets Module
Equipment/asset management with tracking, maintenance schedules, and monitoring
"""

from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging
import time
from workorders import work_orders_db
from api_schemas import AssetDashboardResponse, AssetKPIResponse, AssetHistoryResponse, AssetHistoryEvent, PMCreate, PMResponse, DocumentReference, PartInventoryStatus
try:
    from rag_system import search_asset_manuals, search_asset_parts, search_asset_troubleshooting, answer_asset_question, SearchResult
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False
    # Create dummy functions for when RAG is not available
    async def search_asset_manuals(*args, **kwargs): return []
    async def search_asset_parts(*args, **kwargs): return []
    async def search_asset_troubleshooting(*args, **kwargs): return []
    async def answer_asset_question(*args, **kwargs): return "RAG system not available"
    class SearchResult: pass
from pydantic import BaseModel
try:
    from .db.database import get_session, get_engine  # type: ignore
    from .db.models import AssetORM  # type: ignore
    _ASSET_DB = True
except Exception:
    try:
        from db.database import get_session, get_engine  # type: ignore
        from db.models import AssetORM  # type: ignore
        _ASSET_DB = True
    except Exception:  # pragma: no cover
        _ASSET_DB = False
        get_session = None  # type: ignore
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Assets router
assets_router = APIRouter(prefix="/assets", tags=["assets"])

# Data models
class Asset(BaseModel):
    id: str
    name: str
    category: str
    location: str
    status: str
    condition: str
    manufacturer: str
    model: str
    serial_number: str
    installation_date: str
    last_maintenance: Optional[str] = None
    
    next_maintenance: Optional[str] = None
    maintenance_frequency: int  # days
    criticality: str
    cost_center: str
    specifications: Dict[str, Any]
    parent_asset_id: Optional[str] = None

class MaintenanceHistory(BaseModel):
    id: str
    asset_id: str
    date: str
    type: str
    technician: str
    description: str
    cost: float
    downtime_hours: float

class AssetMetrics(BaseModel):
    uptime_percentage: float
    mtbf: float  # Mean Time Between Failures
    mttr: float  # Mean Time To Repair
    maintenance_cost_ytd: float
    failure_count: int

# Mock database
assets_db = [
    {
        "id": "AST-001",
        "name": "Primary Air Compressor",
        "category": "Compressor",
        "location": "Building A - Mechanical Room",
        "status": "operational",
        "condition": "good",
        "manufacturer": "Atlas Copco",
        "model": "GA37VSD+",
        "serial_number": "AC2024001",
        "installation_date": "2024-01-15",
        "last_maintenance": "2025-08-15",
        "next_maintenance": "2025-11-15",
        "maintenance_frequency": 90,
        "criticality": "critical",
        "cost_center": "PROD-001",
        "health_score": 8.9,
        "specifications": {
            "power": "37kW",
            "pressure": "8 bar",
            "flow_rate": "6.2 m³/min",
            "voltage": "400V"
        }
    },
    {
        "id": "AST-002", 
        "name": "Conveyor Belt System",
        "category": "Conveyor",
        "location": "Production Floor 1",
        "status": "operational",
        "condition": "fair",
        "manufacturer": "FlexLink",
        "model": "X45-2000",
        "serial_number": "FL2023045",
        "installation_date": "2023-06-10",
        "last_maintenance": "2025-08-20",
        "next_maintenance": "2025-09-20",
        "maintenance_frequency": 30,
        "criticality": "high",
        "cost_center": "PROD-001",
        "health_score": 7.2,
        "specifications": {
            "length": "50m",
            "width": "300mm",
            "speed": "0.5-2.0 m/s",
            "load_capacity": "25kg/m"
        }
    },
    {
        "id": "AST-003",
        "name": "HVAC Unit 1",
        "category": "HVAC",
        "location": "Building A - Roof",
        "status": "maintenance_due",
        "condition": "good",
        "manufacturer": "Carrier",
        "model": "50TC024",
        "serial_number": "CR2023112",
        "installation_date": "2023-03-20",
        "last_maintenance": "2025-06-01",
        "next_maintenance": "2025-09-01",
        "maintenance_frequency": 90,
        "criticality": "medium",
        "cost_center": "FAC-001",
        "health_score": 8.5,
        "specifications": {
            "cooling_capacity": "24 tons",
            "heating_capacity": "80kW",
            "airflow": "4000 CFM",
            "efficiency": "16 SEER"
        }
    },
    {
        "id": "AST-004",
        "name": "Emergency Generator",
        "category": "Generator",
        "location": "Building A - Generator Room", 
        "status": "operational",
        "condition": "excellent",
        "manufacturer": "Caterpillar",
        "model": "DE150",
        "serial_number": "CT2024022",
        "installation_date": "2024-02-10",
        "last_maintenance": "2025-08-01",
        "next_maintenance": "2025-11-01",
        "maintenance_frequency": 90,
        "criticality": "critical",
        "cost_center": "FAC-001",
        "health_score": 9.4,
        "specifications": {
            "power": "150kW",
            "fuel_type": "Diesel",
            "fuel_capacity": "500L",
            "runtime": "24hrs at full load"
        }
    },
    {
        "id": "AST-005",
        "name": "Packaging Machine Alpha",
        "category": "Packaging",
        "location": "Production Floor 2",
        "status": "down",
        "condition": "poor",
        "manufacturer": "Bosch",
        "model": "HorizontalPacker-300",
        "serial_number": "BS2022078",
        "installation_date": "2022-11-05",
        "last_maintenance": "2025-07-10",
        "next_maintenance": "2025-08-10",
        "maintenance_frequency": 30,
        "criticality": "high",
        "cost_center": "PROD-002",
        "health_score": 4.1,
        "specifications": {
            "speed": "300 packages/min",
            "package_size": "50-500g",
            "sealing_type": "Heat seal",
            "power": "5kW"
        }
    }
]
if _ASSET_DB:
    try:
        eng = get_engine()
        from sqlalchemy import inspect  # type: ignore
        from db.database import Base  # type: ignore
        insp = inspect(eng)
        if 'assets' not in insp.get_table_names():
            Base.metadata.create_all(bind=eng)  # type: ignore
        with get_session() as s:  # type: ignore
            if not s.query(AssetORM).first():  # type: ignore
                import json
                for a in assets_db:
                    rec = a.copy(); rec['specifications'] = json.dumps(rec.get('specifications', {}))
                    s.add(AssetORM(**rec))  # type: ignore
                s.commit()
    except Exception as e:  # pragma: no cover
        logger.warning(f"Assets DB init failed: {e}")

maintenance_history_db = [
    {
        "id": "MH-001",
        "asset_id": "AST-001",
        "date": "2025-08-15",
        "type": "scheduled",
        "technician": "John Smith",
        "description": "Quarterly maintenance - oil change, filter replacement, performance check",
        "cost": 450.00,
        "downtime_hours": 4.0
    },
    {
        "id": "MH-002",
        "asset_id": "AST-002",
        "date": "2025-08-20",
        "type": "scheduled",
        "technician": "Mike Johnson",
        "description": "Monthly belt inspection and lubrication",
        "cost": 125.00,
        "downtime_hours": 1.5
    },
    {
        "id": "MH-003",
        "asset_id": "AST-005",
        "date": "2025-08-25",
        "type": "emergency",
        "technician": "Sarah Davis",
        "description": "Emergency repair - motor replacement due to bearing failure",
        "cost": 1250.00,
        "downtime_hours": 12.0
    }
]

# Mock work orders database
work_orders_db = [
    {
        "id": "WO-001",
        "asset_id": "AST-001",
        "title": "Air Filter Replacement",
        "description": "Replace the air filter in the compressor.",
        "status": "completed",
        "priority": "high",
        "scheduled_date": "2025-08-10",
        "completion_date": "2025-08-12",
        "technician": "John Doe"
    },
    {
        "id": "WO-002",
        "asset_id": "AST-001",
        "title": "Belt Tension Adjustment",
        "description": "Adjust the tension of the main drive belt.",
        "status": "in_progress",
        "priority": "medium",
        "scheduled_date": "2025-08-15",
        "technician": "Jane Smith"
    },
    {
        "id": "WO-003",
        "asset_id": "AST-002",
        "title": "Monthly Inspection",
        "description": "Conduct monthly inspection and maintenance.",
        "status": "scheduled",
        "priority": "low",
        "scheduled_date": "2025-09-01",
        "technician": "Emily Johnson"
    }
]

# =============================================================================
# KPI Calculation Functions (Industry Standards)
# =============================================================================

def calculate_mtbf(asset_id: str, window_days: int = 90) -> float:
    """Calculate Mean Time Between Failures (MTBF) in hours
    MTBF = Total Operating Time / Number of Failures
    """
    end_date = datetime.now()
    start_date = end_date - timedelta(days=window_days)
    
    # Get failure events from history
    failure_events = [
        h for h in maintenance_history_db 
        if h['asset_id'] == asset_id and h['type'] == 'emergency'
        and start_date <= datetime.strptime(h['date'], '%Y-%m-%d') <= end_date
    ]
    
    failure_count = len(failure_events)
    if failure_count == 0:
        return 8760.0  # Default: 1 year uptime if no failures
    
    # Calculate total operating time (assume 24/7 operation minus downtime)
    total_hours = window_days * 24
    total_downtime = sum(h.get('downtime_hours', 0) for h in failure_events)
    operating_hours = total_hours - total_downtime
    
    return max(operating_hours / failure_count, 0.1)

def calculate_mttr(asset_id: str, window_days: int = 90) -> float:
    """Calculate Mean Time To Repair (MTTR) in hours
    MTTR = Total Repair Time / Number of Repairs
    """
    end_date = datetime.now()
    start_date = end_date - timedelta(days=window_days)
    
    # Get repair events from history
    repair_events = [
        h for h in maintenance_history_db 
        if h['asset_id'] == asset_id and h.get('downtime_hours', 0) > 0
        and start_date <= datetime.strptime(h['date'], '%Y-%m-%d') <= end_date
    ]
    
    if not repair_events:
        return 2.0  # Default 2 hours MTTR if no repair data
    
    total_repair_time = sum(h.get('downtime_hours', 0) for h in repair_events)
    repair_count = len(repair_events)
    
    return total_repair_time / repair_count if repair_count > 0 else 2.0

def calculate_pm_compliance(asset_id: str, window_days: int = 90) -> float:
    """Calculate PM Compliance Percentage
    PM_Compliance = (PMs Completed On Time / Total PMs Scheduled) * 100
    """
    # For mock data, simulate PM compliance based on asset status
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        return 0.0
    
    # Mock calculation based on asset condition and criticality
    base_compliance = {
        'excellent': 98.0, 'good': 92.0, 'fair': 85.0, 'poor': 70.0
    }.get(asset['condition'], 80.0)
    
    # Adjust for criticality (critical assets have stricter compliance)
    criticality_modifier = {
        'critical': -5.0, 'high': -2.0, 'medium': 0.0, 'low': 2.0
    }.get(asset['criticality'], 0.0)
    
    return min(max(base_compliance + criticality_modifier, 0.0), 100.0)

def calculate_backlog_days(asset_id: str) -> float:
    """Calculate Work Order Backlog in Days
    Backlog_Days = Sum(Open_WO_Estimated_Hours) / Available_Maintenance_Hours_Per_Day
    """
    # Get open work orders for this asset
    open_work_orders = [
        wo for wo in work_orders_db 
        if wo['asset_id'] == asset_id and wo['status'] in ['assigned', 'in_progress', 'scheduled']
    ]
    
    if not open_work_orders:
        return 0.0
    
    # Estimate hours for work orders without estimates
    total_estimated_hours = 0.0
    for wo in open_work_orders:
        estimated_hours = 4.0  # Default estimate
        if wo['type'] == 'emergency':
            estimated_hours = 8.0
        elif wo['type'] == 'preventive':
            estimated_hours = 2.0
        
        # Apply priority weighting
        priority_weight = {
            'urgent': 3.0, 'high': 2.0, 'medium': 1.0, 'low': 0.5
        }.get(wo['priority'], 1.0)
        
        total_estimated_hours += estimated_hours * priority_weight
    
    # Assume 8 hours available maintenance time per day
    available_hours_per_day = 8.0
    
    return total_estimated_hours / available_hours_per_day

def calculate_uptime_percentage(asset_id: str, window_days: int = 90) -> float:
    """Calculate Asset Uptime Percentage
    Uptime = (Total_Time - Downtime) / Total_Time * 100
    """
    end_date = datetime.now()
    start_date = end_date - timedelta(days=window_days)
    
    # Get downtime from maintenance history
    downtime_events = [
        h for h in maintenance_history_db 
        if h['asset_id'] == asset_id and h.get('downtime_hours', 0) > 0
        and start_date <= datetime.strptime(h['date'], '%Y-%m-%d') <= end_date
    ]
    
    total_hours = window_days * 24
    total_downtime = sum(h.get('downtime_hours', 0) for h in downtime_events)
    
    # Consider asset status for current downtime
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if asset and asset['status'] == 'down':
        # Add estimated current downtime (assume down for 1 day)
        total_downtime += 24.0
    
    uptime_hours = total_hours - total_downtime
    return (uptime_hours / total_hours) * 100.0 if total_hours > 0 else 0.0

def get_asset_kpis(asset_id: str, window_days: int = 90) -> AssetKPIResponse:
    """Get comprehensive KPIs for an asset"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=window_days)
    
    # Calculate YTD costs
    ytd_start = datetime(end_date.year, 1, 1)
    ytd_costs = sum(
        h['cost'] for h in maintenance_history_db 
        if h['asset_id'] == asset_id and h.get('cost', 0) > 0
        and ytd_start <= datetime.strptime(h['date'], '%Y-%m-%d') <= end_date
    )
    
    # Calculate YTD failure count
    ytd_failures = len([
        h for h in maintenance_history_db 
        if h['asset_id'] == asset_id and h['type'] == 'emergency'
        and ytd_start <= datetime.strptime(h['date'], '%Y-%m-%d') <= end_date
    ])
    
    return AssetKPIResponse(
        mtbf_hours=calculate_mtbf(asset_id, window_days),
        mttr_hours=calculate_mttr(asset_id, window_days),
        pm_compliance_pct=calculate_pm_compliance(asset_id, window_days),
        backlog_days=calculate_backlog_days(asset_id),
        uptime_pct=calculate_uptime_percentage(asset_id, window_days),
        total_cost_ytd=ytd_costs,
        failure_count_ytd=ytd_failures,
        window_start=start_date.strftime('%Y-%m-%d'),
        window_end=end_date.strftime('%Y-%m-%d')
    )

@assets_router.get("/dashboard", response_class=HTMLResponse)
async def assets_dashboard():
    """Assets dashboard with equipment overview and monitoring"""
    from fastapi.templating import Jinja2Templates
    import os
    
    # Use optimized template system
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    templates = Jinja2Templates(directory=template_dir)
    
    total_assets = len(assets_db)
    operational_assets = len([a for a in assets_db if a['status'] == 'operational'])
    maintenance_due = len([a for a in assets_db if a['status'] == 'maintenance_due'])
    down_assets = len([a for a in assets_db if a['status'] == 'down'])
    
    # Build hierarchy map (parent -> children)
    hierarchy = {}
    for asset in assets_db:
        parent = asset.get('parent_asset_id') or 'ROOT'
        hierarchy.setdefault(parent, []).append(asset)
    def render_children(parent_id, level=0):
        nodes = hierarchy.get(parent_id, [])
        html = "<ul style='list-style:none; margin-left:" + str(level*12) + "px'>"
        for node in nodes:
            badge = f"<span style='font-size:0.7rem; margin-left:6px; opacity:0.7'>{node['criticality']}</span>"
            html += f"<li style='margin:4px 0'>🔧 <strong>{node['id']}</strong> - {node['name']}{badge}" \
                    f" { '(down)' if node['status']=='down' else ''}" \
                    + render_children(node['id'], level+1) + "</li>"
        html += "</ul>"
        return html
    
    # Generate hierarchy HTML
    hierarchy_html = render_children('ROOT')
    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix Assets Management</title>
        <link rel="stylesheet" href="/static/css/chatterfix-unified.css">
        <style>
            {base_styles}
            {nav_styles}
            
            /* Assets specific styles */
            .asset-card {{ border-left: 4px solid #4299e1; }}
            .asset-card.critical {{ border-left-color: #e53e3e; }}
            .asset-card.high {{ border-left-color: #d69e2e; }}
            .asset-card.medium {{ border-left-color: #38a169; }}
            
            .filter-bar {{ 
                background: rgba(255,255,255,0.1); 
                padding: 1.5rem; 
                border-radius: 15px; 
                margin-bottom: 2rem; 
                display: flex; 
                gap: 1rem; 
                align-items: center;
                flex-wrap: wrap;
                backdrop-filter: blur(10px);
            }}
            .filter-bar select, .filter-bar input {{ 
                padding: 0.75rem; 
                border: 1px solid rgba(255,255,255,0.3); 
                border-radius: 8px;
                background: rgba(255,255,255,0.1);
                color: white;
                backdrop-filter: blur(10px);
            }}
            .filter-bar select option {{
                background: #2d3748;
                color: white;
            }}
            .filter-bar input::placeholder {{
                color: rgba(255,255,255,0.6);
            }}
        </style>
    </head>
    <body>
        {nav_html}
        
        <!-- Header -->
        <div class="chatterfix-header">
            <h1>⚙️ Assets Management</h1>
            <p>Equipment Tracking, Maintenance Scheduling & Asset Monitoring</p>
        </div>
        
        <div class="chatterfix-container">
            <!-- Stats Overview -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Asset Overview</h3>
                    <div class="stat">
                        <span>Total Assets</span>
                        <span class="stat-value">{total_assets}</span>
                    </div>
                    <div class="stat">
                        <span>Operational</span>
                        <span class="stat-value status-operational">{operational_assets}</span>
                    </div>
                    <div class="stat">
                        <span>Maintenance Due</span>
                        <span class="stat-value status-maintenance">{maintenance_due}</span>
                    </div>
                    <div class="stat">
                        <span>Down</span>
                        <span class="stat-value status-down">{down_assets}</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3>Quick Actions</h3>
                    <button class="chatterfix-btn" onclick="addAsset()">Add New Asset</button>
                    <button class="chatterfix-btn chatterfix-btn-warning" onclick="scheduleMaintenanceReview()">Schedule Maintenance</button>
                    <button class="chatterfix-btn chatterfix-btn-success" onclick="generateReport()">Generate Report</button>
                    <button class="chatterfix-btn" onclick="window.open('/cmms/assets/kpis/dashboard', '_blank')" style="background: #4299e1; color: white;">📊 Real-time KPIs</button>
                    <button class="chatterfix-btn" onclick="importAssets()">Import Assets</button>
                    <button class="chatterfix-btn export-btn" onclick="exportData()">Export Data</button>
                </div>
                
                <div class="stat-card">
                    <h3>Key Metrics</h3>
                    <div class="stat">
                        <span>Overall Equipment Effectiveness</span>
                        <span class="stat-value status-operational">87%</span>
                    </div>
                    <div class="stat">
                        <span>Average Uptime</span>
                        <span class="stat-value status-operational">94.2%</span>
                    </div>
                    <div class="stat">
                        <span>Maintenance Cost (MTD)</span>
                        <span class="stat-value">$4,250</span>
                    </div>
                </div>
                <div class="stat-card">
                    <h3>🤖 AI Asset Assistant</h3>
                    <div class="ai-chat-container">
                        <input type="text" class="ai-input" placeholder="Ask AI: 'Which assets need maintenance?' or 'Generate asset health report'">
                        <button class="chatterfix-btn chatterfix-btn-sm voice-input-btn" data-target="ai-input">🎤</button>
                        <div class="ai-response"></div>
                    </div>
                </div>
                <div class="stat-card">
                    <h3>Asset Hierarchy</h3>
                    <div style="max-height:300px; overflow:auto; font-size:0.9rem; line-height:1.3;">
                        {hierarchy_html}
                    </div>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="chatterfix-filter-bar">
                <label>Filter by:</label>
                <select id="statusFilter" onchange="filterAssets()">
                    <option value="">All Status</option>
                    <option value="operational">Operational</option>
                    <option value="maintenance_due">Maintenance Due</option>
                    <option value="down">Down</option>
                </select>
                <select id="categoryFilter" onchange="filterAssets()">
                    <option value="">All Categories</option>
                    <option value="Compressor">Compressor</option>
                    <option value="Conveyor">Conveyor</option>
                    <option value="HVAC">HVAC</option>
                    <option value="Generator">Generator</option>
                    <option value="Packaging">Packaging</option>
                </select>
                <select id="criticalityFilter" onchange="filterAssets()">
                    <option value="">All Criticality</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                </select>
                <input type="text" id="searchFilter" placeholder="Search assets..." onkeyup="filterAssets()">
            </div>
            
            <!-- Assets Grid -->
            <div class="chatterfix-grid" id="assetsGrid">
                {assets_html}
            </div>
            
            <!-- Recent Maintenance History -->
            <div class="chatterfix-card" style="margin-top: 2rem;">
                <h3>Recent Maintenance History</h3>
                <table class="chatterfix-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Asset</th>
                            <th>Type</th>
                            <th>Technician</th>
                            <th>Description</th>
                            <th>Cost</th>
                            <th>Downtime</th>
                        </tr>
                    </thead>
                    <tbody>
                        {history_html}
                    </tbody>
                </table>
            </div>
        </div>
        
        <script>
            {nav_js}
            function filterAssets() {{
                const statusFilter = document.getElementById('statusFilter').value;
                const categoryFilter = document.getElementById('categoryFilter').value;
                const criticalityFilter = document.getElementById('criticalityFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const assetCards = document.querySelectorAll('.asset-card');
                assetCards.forEach(card => {{
                    const status = card.dataset.status;
                    const category = card.dataset.category;
                    const criticality = card.dataset.criticality;
                    const name = card.dataset.name.toLowerCase();
                    
                    const statusMatch = !statusFilter || status === statusFilter;
                    const categoryMatch = !categoryFilter || category === categoryFilter;
                    const criticalityMatch = !criticalityFilter || criticality === criticalityFilter;
                    const searchMatch = !searchFilter || name.includes(searchFilter);
                    
                    card.style.display = (statusMatch && categoryMatch && criticalityMatch && searchMatch) ? 'block' : 'none';
                }});
            }}
            
            function addAsset() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; max-height: 90%; overflow-y: auto;" onclick="event.stopPropagation()">
                            <h3>Add New Asset</h3>
                            <form id="addAssetForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Asset Name:</label><br>
                                    <input type="text" name="name" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Category:</label><br>
                                    <select name="category" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="">Select Category</option>
                                        <option value="Compressor">Compressor</option>
                                        <option value="Conveyor">Conveyor</option>
                                        <option value="HVAC">HVAC</option>
                                        <option value="Generator">Generator</option>
                                        <option value="Packaging">Packaging</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Location:</label><br>
                                    <input type="text" name="location" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Manufacturer:</label><br>
                                    <input type="text" name="manufacturer" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Model:</label><br>
                                    <input type="text" name="model" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Serial Number:</label><br>
                                    <input type="text" name="serial_number" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Criticality:</label><br>
                                    <select name="criticality" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="">Select Criticality</option>
                                        <option value="critical">Critical</option>
                                        <option value="high">High</option>
                                        <option value="medium">Medium</option>
                                        <option value="low">Low</option>
                                    </select>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Maintenance Frequency (days):</label><br>
                                    <input type="number" name="maintenance_frequency" value="30" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=' + "'" + '"closeModal(event)"' + "'" + ']'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" class="btn">Create Asset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('addAssetForm').addEventListener('submit', function(e) {{
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const assetData = Object.fromEntries(formData);
                    
                    fetch('/assets', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(assetData)
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Asset created:', data);
                        location.reload();
                    }});
                }});
            }}
            
            function closeModal(event) {{
                if (event.target === event.currentTarget) {{
                    document.body.removeChild(event.currentTarget);
                }}
            }}
            
            function viewAssetDetails(assetId) {{
                window.open(`/assets/${{assetId}}/view`, '_blank');
            }}
            
            function scheduleMaintenance(assetId) {{
                window.location.href = `/cmms/preventive/schedule?asset_id=${{assetId}}`;
            }}
            
            function editAsset(assetId) {{
                window.location.href = `/assets/${{assetId}}/edit`;
            }}
            
            function reportIssue(assetId) {{
                window.location.href = `/cmms/workorders/create?asset_id=${{assetId}}&type=reactive`;
            }}
            
            function scheduleMaintenanceReview() {{
                window.location.href = '/cmms/preventive/dashboard';
            }}
            
            function generateReport() {{
                window.open('/assets/reports', '_blank');
            }}
            
            function importAssets() {{
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.csv,.xlsx';
                input.onchange = function(e) {{
                    const file = e.target.files[0];
                    if (file) {{
                        console.log('Importing assets from:', file.name);
                        // Would implement actual import logic
                        alert('Import functionality would be implemented here');
                    }}
                }};
                input.click();
            }}
            
            function exportData() {{
                window.open('/assets/export/csv', '_blank');
            }}
        </script>
        <script src="/static/js/chatterfix-unified.js"></script>
        {nav_js}
    </body>
    </html>
    """
    
    # Generate assets HTML
    assets_html = ""
    for asset in assets_db:
        report_button = f'<button class="btn btn-sm btn-danger" onclick="reportIssue(\'{asset["id"]}\')">Report Issue</button>' if asset['status'] == 'operational' else ''
        assets_html += f'''
        <div class="card asset-card {asset['criticality']}" data-status="{asset['status']}" data-category="{asset['category']}" data-criticality="{asset['criticality']}" data-name="{asset['name']}">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                <div>
                    <h4 style="margin: 0; color: #2d3748;">{asset['name']}</h4>
                    <p style="margin: 0.25rem 0; color: #718096;">{asset['category']} — {asset['location']}</p>
                </div>
                <span class="btn btn-sm status-{asset['status']}">{asset['status'].replace('_', ' ').title()}</span>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <div><strong>Manufacturer:</strong> {asset['manufacturer']} {asset['model']}</div>
                <div><strong>Serial:</strong> {asset['serial_number']}</div>
                <div><strong>Condition:</strong> {asset['condition'].title()}</div>
                <div><strong>Criticality:</strong> {asset['criticality'].title()}</div>
            </div>
            
            <div style="margin-bottom: 1rem; padding: 0.75rem; background: #f7fafc; border-radius: 4px;">
                <div><strong>Last Maintenance:</strong> {asset.get('last_maintenance', 'Never')}</div>
                <div><strong>Next Maintenance:</strong> {asset.get('next_maintenance', 'Not scheduled')}</div>
                <div><strong>Frequency:</strong> Every {asset['maintenance_frequency']} days</div>
            </div>
            
            <div>
                <button class="btn btn-sm" onclick="viewAssetDetails('{asset['id']}')">View Details</button>
                <button class="btn btn-sm btn-warning" onclick="scheduleMaintenance('{asset['id']}')">Schedule</button>
                <button class="btn btn-sm" onclick="editAsset('{asset['id']}')">Edit</button>
                {report_button}
            </div>
        </div>'''
    
    # Generate maintenance history HTML
    history_html = ""
    for history in maintenance_history_db[-10:]:
        asset_name = next((a['name'] for a in assets_db if a['id'] == history['asset_id']), 'Unknown')
        btn_class = 'btn-warning' if history['type'] == 'emergency' else ''
        description = history['description'][:50] + ('...' if len(history['description']) > 50 else '')
        history_html += f'''
        <tr>
            <td>{history['date']}</td>
            <td>{asset_name}</td>
            <td><span class="btn btn-sm {btn_class}">{history['type'].title()}</span></td>
            <td>{history['technician']}</td>
            <td>{description}</td>
            <td>${history['cost']:,.2f}</td>
            <td>{history['downtime_hours']}h</td>
        </tr>'''
    
    # Prepare data for optimized template
    stats = {
        "active_workorders": operational_assets,
        "total_assets": total_assets, 
        "parts_in_stock": operational_assets,
        "system_health": round((operational_assets/total_assets)*100) if total_assets > 0 else 0
    }
    
    recent_workorders = [
        {"id": "001", "title": "Asset Inspection", "asset_name": assets_db[0]['name'] if assets_db else "Asset #1", "technician": "John D.", "status": "In Progress", "priority": "High"},
        {"id": "002", "title": "Preventive Maintenance", "asset_name": assets_db[1]['name'] if len(assets_db) > 1 else "Asset #2", "technician": "Sarah M.", "status": "Assigned", "priority": "Medium"}
    ]
    
    top_assets = []
    for asset in assets_db[:5]:
        health_score = 95 if asset['status'] == 'operational' else 70 if asset['status'] == 'maintenance_due' else 20
        top_assets.append({
            "name": asset['name'],
            "health_score": health_score,
            "status": asset['status'].replace('_', ' ').title(),
            "last_maintenance": "2 days ago"
        })
    
    # Mock request for template
    class MockRequest:
        def __init__(self):
            self.url = type('obj', (object,), {'path': '/cmms/assets/dashboard'})()
            
        def get(self, key, default=None):
            return default
    
    return templates.TemplateResponse("dashboard-rich.html", {
        "request": MockRequest(),
        "module_name": "Assets Management",
        "stats": stats,
        "recent_workorders": recent_workorders,
        "top_assets": top_assets,
        "ai_stats": {"predictions_today": 15, "automation_rate": 78, "response_time": 2.1},
        "ai_activities": [
            {"icon": "🔧", "title": "Asset Analysis", "description": "3 assets require attention this week", "timestamp": "14:30", "confidence": 89}
        ],
        "performance": {"dashboard_load": 1.8, "ai_response": 2.1, "health_check": 7.5},
        "metrics": {"uptime": 96.8, "api_success": 97.2, "satisfaction": 4.6, "cost_savings": 8500},
        "recent_activities": [
            {"timestamp": "14:25", "icon": "⚙️", "type": "Asset Update", "description": "Critical asset status changed", "user": "System", "module": "Assets", "status": "Success"}
        ]
    })

# Legacy return kept for reference
def assets_dashboard_legacy():
    # Return placeholder for legacy compatibility
    return "<div>Legacy dashboard function - deprecated</div>"

# =============================================================================
# Asset Dashboard API Endpoints
# =============================================================================

@assets_router.get("/dashboard/{asset_id}")
async def get_asset_dashboard(asset_id: str) -> AssetDashboardResponse:
    """Get comprehensive asset dashboard data"""
    # Get basic asset info
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    # Get KPIs
    kpis = get_asset_kpis(asset_id)
    
    # Get history events (convert maintenance history to events)
    history_events = []
    for h in maintenance_history_db:
        if h['asset_id'] == asset_id:
            event = AssetHistoryEvent(
                id=h['id'],
                asset_id=h['asset_id'],
                event_type="repair" if h['type'] == 'emergency' else "pm",
                timestamp=datetime.strptime(h['date'], '%Y-%m-%d'),
                description=h['description'],
                technician=h['technician'],
                duration_hours=h.get('downtime_hours'),
                cost=h.get('cost')
            )
            history_events.append(event)
    
    # Sort by timestamp descending
    history_events.sort(key=lambda x: x.timestamp, reverse=True)
    
    # Get upcoming PMs (mock data)
    upcoming_pms = [
        {
            "id": "PM-001",
            "name": "Quarterly Service",
            "due_date": asset.get('next_maintenance', '2025-11-15'),
            "estimated_hours": 6.0,
            "priority": "high"
        }
    ] if asset.get('next_maintenance') else []
    
    # Get current work orders
    current_work_orders = [
        wo for wo in work_orders_db 
        if wo['asset_id'] == asset_id and wo['status'] in ['assigned', 'in_progress']
    ]
    
    # Mock documents
    documents = [
        DocumentReference(
            id="DOC-001",
            name=f"{asset['manufacturer']} {asset['model']} Manual",
            type="manual",
            url=f"/documents/{asset_id}/manual.pdf",
            asset_id=asset_id,
            upload_date=datetime.now(),
            file_size=2048000
        ),
        DocumentReference(
            id="DOC-002", 
            name=f"{asset['name']} Parts List",
            type="parts_list",
            url=f"/documents/{asset_id}/parts.pdf",
            asset_id=asset_id,
            upload_date=datetime.now(),
            file_size=1024000
        )
    ]
    
    # Mock inventory status
    inventory = [
        PartInventoryStatus(
            part_id="PRT-001",
            name="Air Filter",
            current_stock=5,
            min_stock=2,
            status="in_stock",
            cost_per_unit=45.00
        ),
        PartInventoryStatus(
            part_id="PRT-002",
            name="Compressor Oil",
            current_stock=1,
            min_stock=3,
            status="low_stock",
            cost_per_unit=85.00
        )
    ]
    
    return AssetDashboardResponse(
        asset=asset,  # Pass the dict directly - Pydantic will handle conversion
        kpis=kpis,
        history=history_events[:20],  # Limit to 20 most recent
        upcoming_pms=upcoming_pms,
        current_work_orders=current_work_orders,
        documents=documents,
        inventory=inventory
    )

@assets_router.get("/dashboard/{asset_id}/history")
async def get_asset_history(
    asset_id: str, 
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0)
) -> AssetHistoryResponse:
    """Get asset maintenance history with pagination"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    # Convert maintenance history to events
    all_events = []
    for h in maintenance_history_db:
        if h['asset_id'] == asset_id:
            event = AssetHistoryEvent(
                id=h['id'],
                asset_id=h['asset_id'],
                event_type="repair" if h['type'] == 'emergency' else "pm",
                timestamp=datetime.strptime(h['date'], '%Y-%m-%d'),
                description=h['description'],
                technician=h['technician'],
                duration_hours=h.get('downtime_hours'),
                cost=h.get('cost')
            )
            all_events.append(event)
    
    # Sort by timestamp descending
    all_events.sort(key=lambda x: x.timestamp, reverse=True)
    
    # Apply pagination
    total_count = len(all_events)
    paginated_events = all_events[offset:offset + limit]
    
    return AssetHistoryResponse(
        asset_id=asset_id,
        history=paginated_events,
        total_count=total_count,
        page=(offset // limit) + 1,
        limit=limit
    )

@assets_router.get("/dashboard/{asset_id}/kpis")
async def get_asset_dashboard_kpis(
    asset_id: str, 
    window_days: int = Query(90, ge=1, le=365)
) -> AssetKPIResponse:
    """Get asset KPIs for specific time window"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    return get_asset_kpis(asset_id, window_days)

@assets_router.post("/dashboard/{asset_id}/pm")
async def create_asset_pm(asset_id: str, pm_data: PMCreate) -> PMResponse:
    """Create new preventive maintenance schedule for asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    # Validate asset_id matches
    if pm_data.asset_id != asset_id:
        raise HTTPException(status_code=400, detail="Asset ID mismatch")
    
    # Create PM record (in real implementation, save to database)
    pm_id = f"PM-{len(assets_db) + 1:03d}"  # Mock ID generation
    
    pm_response = PMResponse(
        id=pm_id,
        name=pm_data.name,
        asset_id=pm_data.asset_id,
        frequency_days=pm_data.frequency_days,
        estimated_duration=pm_data.estimated_duration,
        priority=pm_data.priority,
        description=pm_data.description,
        instructions=pm_data.instructions,
        required_parts=pm_data.required_parts,
        required_skills=pm_data.required_skills,
        safety_requirements=pm_data.safety_requirements,
        next_due=datetime.now().date() + timedelta(days=pm_data.frequency_days),
        status="active",
        created_date=datetime.now(),
        updated_date=datetime.now()
    )
    
    logger.info(f"PM schedule created: {pm_id} for asset {asset_id}")
    return pm_response

# Asset Dashboard HTML View
@assets_router.get("/dashboard/{asset_id}/view", response_class=HTMLResponse)
async def asset_dashboard_page(asset_id: str):
    """Render the Asset Dashboard page"""
    try:
        # Get dashboard data
        dashboard_data = await get_asset_dashboard(asset_id)
        asset_dict = next((a for a in assets_db if a['id'] == asset_id), None)  # Get raw dict for template
        
        if not asset_dict:
            raise HTTPException(status_code=404, detail="Asset not found")
            
        kpis = dashboard_data.kpis
        
        # Generate KPI cards HTML
        kpi_cards_html = f"""
        <div class="kpi-grid">
            <div class="kpi-card mtbf">
                <div class="kpi-value">{kpis.mtbf_hours:.1f}h</div>
                <div class="kpi-label">MTBF</div>
                <div class="kpi-trend">↗ +12% vs last period</div>
            </div>
            <div class="kpi-card mttr">
                <div class="kpi-value">{kpis.mttr_hours:.1f}h</div>
                <div class="kpi-label">MTTR</div>
                <div class="kpi-trend">↘ -8% vs last period</div>
            </div>
            <div class="kpi-card compliance">
                <div class="kpi-value">{kpis.pm_compliance_pct:.1f}%</div>
                <div class="kpi-label">PM Compliance</div>
                <div class="kpi-trend">{'↗' if kpis.pm_compliance_pct >= 90 else '↘'} Target: 95%</div>
            </div>
            <div class="kpi-card uptime">
                <div class="kpi-value">{kpis.uptime_pct:.1f}%</div>
                <div class="kpi-label">Uptime</div>
                <div class="kpi-trend">{'↗' if kpis.uptime_pct >= 95 else '↘'} Last 90 days</div>
            </div>
            <div class="kpi-card backlog">
                <div class="kpi-value">{kpis.backlog_days:.1f}</div>
                <div class="kpi-label">Backlog Days</div>
                <div class="kpi-trend">{'↘' if kpis.backlog_days <= 3 else '↗'} Work orders</div>
            </div>
            <div class="kpi-card cost">
                <div class="kpi-value">${kpis.total_cost_ytd:,.0f}</div>
                <div class="kpi-label">YTD Cost</div>
                <div class="kpi-trend">📊 Budget tracking</div>
            </div>
        </div>
        """
        
        # Generate history timeline HTML 
        history_html = ""
        for event in dashboard_data.history[:10]:  # Show 10 most recent
            event_icon = {"repair": "🔧", "pm": "📋", "inspection": "🔍", "failure": "⚠️"}.get(event.event_type, "📝")
            cost_text = f"${event.cost:.2f}" if event.cost else "N/A"
            duration_text = f"{event.duration_hours}h" if event.duration_hours else "N/A"
            
            history_html += f"""
            <div class="history-event {event.event_type}">
                <div class="event-icon">{event_icon}</div>
                <div class="event-content">
                    <div class="event-header">
                        <span class="event-type">{event.event_type.replace('_', ' ').title()}</span>
                        <span class="event-date">{event.timestamp.strftime('%Y-%m-%d')}</span>
                    </div>
                    <div class="event-description">{event.description}</div>
                    <div class="event-meta">
                        <span>By: {event.technician or 'System'}</span>
                        <span>Duration: {duration_text}</span>
                        <span>Cost: {cost_text}</span>
                    </div>
                </div>
            </div>
            """
        
        return f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Asset Dashboard - {asset_dict['name']}</title>
            <link rel="stylesheet" href="/static/css/asset_dashboard.css">
        </head>
        <body>
            <div class="dashboard-header">
                <div class="header-content">
                    <h1>Asset Dashboard</h1>
                    <div class="asset-info">
                        <h2>{asset_dict['name']}</h2>
                        <p>{asset_dict['manufacturer']} {asset_dict['model']} • {asset_dict['location']}</p>
                        <div class="status-badge status-{asset_dict['status']}">{asset_dict['status'].replace('_', ' ').title()}</div>
                    </div>
                </div>
                <div class="header-actions">
                    <button class="btn" onclick="refreshDashboard()">🔄 Refresh</button>
                    <button class="btn btn-primary" onclick="createWorkOrder()">➕ New Work Order</button>
                    <a href="/assets/dashboard" class="btn">← Back to Assets</a>
                </div>
            </div>
            
            <div class="dashboard-container">
                <div class="dashboard-main">
                    <!-- KPI Section -->
                    <div class="dashboard-section">
                        <h3>Key Performance Indicators</h3>
                        {kpi_cards_html}
                    </div>
                    
                    <!-- History Timeline -->
                    <div class="dashboard-section">
                        <div class="section-header">
                            <h3>Maintenance History</h3>
                            <button class="btn-link" onclick="toggleHistory()">
                                <span id="historyToggle">🔽 Show Details</span>
                            </button>
                        </div>
                        <div class="history-timeline" id="historyTimeline" style="display: none;">
                            {history_html or '<p>No maintenance history available.</p>'}
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-sidebar">
                    <!-- PM Scheduler -->
                    <div class="sidebar-section">
                        <h4>Preventive Maintenance</h4>
                        <div class="pm-schedule">
                            <p><strong>Next Due:</strong> {asset_dict.get('next_maintenance', 'Not scheduled')}</p>
                            <p><strong>Frequency:</strong> Every {asset_dict.get('maintenance_frequency', 30)} days</p>
                            <button class="btn btn-warning btn-small" onclick="schedulePM()">📅 Schedule PM</button>
                        </div>
                    </div>
                    
                    <!-- Documents -->
                    <div class="sidebar-section">
                        <h4>Documents</h4>
                        <div class="document-list">
                            <div class="document-item">
                                <span>📘 {asset_dict['manufacturer']} Manual</span>
                                <button class="btn-link">View</button>
                            </div>
                            <div class="document-item">
                                <span>📋 Parts List</span>
                                <button class="btn-link">View</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Parts Status -->
                    <div class="sidebar-section">
                        <h4>Parts Inventory</h4>
                        <div class="parts-status">
                            <div class="part-item status-in-stock">
                                <span>Air Filter</span>
                                <span>5 in stock</span>
                            </div>
                            <div class="part-item status-low-stock">
                                <span>Compressor Oil</span>
                                <span>1 in stock</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- AI Assistant Panel -->
                    <div class="sidebar-section ai-assistant-section">
                        <div class="ai-header">
                            <h4>🤖 AI Assistant</h4>
                            <button class="btn-small" onclick="toggleAIPanel()" id="aiToggleBtn">▼ Show</button>
                        </div>
                        <div class="ai-panel" id="aiAssistantPanel" style="display: none;">
                            <!-- Chat Interface -->
                            <div class="ai-chat">
                                <div class="chat-messages" id="chatMessages">
                                    <div class="ai-message">
                                        <div class="message-content">
                                            <p>👋 Hi! I can help you with:</p>
                                            <ul>
                                                <li>Manual lookups with citations</li>
                                                <li>Parts availability checks</li>
                                                <li>Maintenance scheduling</li>
                                                <li>Troubleshooting guidance</li>
                                            </ul>
                                            <p>Try asking: "Find lubrication procedure" or "Check parts availability"</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="chat-input">
                                    <input type="text" id="chatInput" placeholder="Ask about {asset_dict['name']}..." onkeypress="handleChatKeyPress(event)">
                                    <button class="btn-small" onclick="sendChatMessage()">Send</button>
                                </div>
                            </div>
                            
                            <!-- Quick Actions -->
                            <div class="ai-quick-actions">
                                <h5>Quick Actions</h5>
                                <div class="action-buttons">
                                    <button class="action-btn" onclick="quickLookup('manual')">📘 Manual Lookup</button>
                                    <button class="action-btn" onclick="quickLookup('parts')">🔧 Parts Search</button>
                                    <button class="action-btn" onclick="checkAvailability()">📅 Check Availability</button>
                                    <button class="action-btn" onclick="uploadNameplate()">📷 OCR Nameplate</button>
                                </div>
                            </div>
                            
                            <!-- Voice Input -->
                            <div class="ai-voice-section">
                                <h5>Voice Commands</h5>
                                <button class="voice-btn" id="voiceBtn" onclick="toggleVoiceInput()">
                                    <span id="voiceBtnText">🎤 Start Voice</span>
                                </button>
                                <div class="voice-status" id="voiceStatus" style="display: none;">
                                    <div class="recording-indicator">🔴 Recording...</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <style>
                /* AI Assistant Panel Styles */
                .ai-assistant-section {
                    border: 2px solid #4299e1;
                    border-radius: 8px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                }
                
                .ai-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 1rem;
                }
                
                .ai-panel {
                    animation: slideDown 0.3s ease-out;
                }
                
                @keyframes slideDown {{
                    from {{ opacity: 0; transform: translateY(-10px); }}
                    to {{ opacity: 1; transform: translateY(0); }}
                }}
                
                .ai-chat {
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 6px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }
                
                .chat-messages {
                    max-height: 200px;
                    overflow-y: auto;
                    margin-bottom: 1rem;
                    padding-right: 5px;
                }
                
                .ai-message, .user-message {
                    margin-bottom: 0.75rem;
                    padding: 0.5rem;
                    border-radius: 6px;
                    font-size: 0.9rem;
                    line-height: 1.4;
                }
                
                .ai-message {
                    background: rgba(255, 255, 255, 0.15);
                    border-left: 3px solid #48bb78;
                }
                
                .user-message {
                    background: rgba(255, 255, 255, 0.25);
                    border-left: 3px solid #4299e1;
                    margin-left: 20px;
                }
                
                .chat-input {
                    display: flex;
                    gap: 0.5rem;
                }
                
                .chat-input input {
                    flex: 1;
                    padding: 0.5rem;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    border-radius: 4px;
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                    font-size: 0.9rem;
                }
                
                .chat-input input::placeholder {
                    color: rgba(255, 255, 255, 0.7);
                }
                
                .ai-quick-actions {
                    margin-bottom: 1rem;
                }
                
                .ai-quick-actions h5 {
                    margin: 0 0 0.5rem 0;
                    font-size: 0.9rem;
                    opacity: 0.9;
                }
                
                .action-buttons {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 0.5rem;
                }
                
                .action-btn {
                    padding: 0.4rem 0.6rem;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    border-radius: 4px;
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                    font-size: 0.8rem;
                    cursor: pointer;
                    transition: all 0.2s ease;
                }
                
                .action-btn:hover {
                    background: rgba(255, 255, 255, 0.2);
                    border-color: rgba(255, 255, 255, 0.5);
                }
                
                .ai-voice-section {
                    text-align: center;
                }
                
                .ai-voice-section h5 {
                    margin: 0 0 0.5rem 0;
                    font-size: 0.9rem;
                    opacity: 0.9;
                }
                
                .voice-btn {
                    padding: 0.6rem 1rem;
                    border: 2px solid #48bb78;
                    border-radius: 20px;
                    background: linear-gradient(45deg, #48bb78, #38a169);
                    color: white;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .voice-btn:hover {
                    transform: scale(1.05);
                    box-shadow: 0 4px 8px rgba(72, 187, 120, 0.3);
                }
                
                .voice-btn.recording {
                    background: linear-gradient(45deg, #e53e3e, #c53030);
                    border-color: #e53e3e;
                    animation: pulse 1s infinite;
                }
                
                @keyframes pulse {{
                    0% {{ transform: scale(1); }}
                    50% {{ transform: scale(1.05); }}
                    100% {{ transform: scale(1); }}
                }}
                
                .recording-indicator {
                    margin-top: 0.5rem;
                    font-size: 0.9rem;
                    opacity: 0.9;
                    animation: blink 1s infinite;
                }
                
                @keyframes blink {{
                    0%, 50% {{ opacity: 1; }}
                    51%, 100% {{ opacity: 0.5; }}
                }}
                
                .btn-small {
                    padding: 0.25rem 0.5rem;
                    font-size: 0.8rem;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    border-radius: 4px;
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                    cursor: pointer;
                }
                
                .btn-small:hover {
                    background: rgba(255, 255, 255, 0.2);
                }
                
                /* Citations display */
                .citation {
                    background: rgba(255, 255, 255, 0.1);
                    border-left: 3px solid #f6e05e;
                    padding: 0.5rem;
                    margin: 0.5rem 0;
                    border-radius: 0 4px 4px 0;
                    font-size: 0.85rem;
                }
                
                .citation-header {
                    font-weight: bold;
                    margin-bottom: 0.25rem;
                }
                
                .citation-content {
                    font-style: italic;
                    opacity: 0.9;
                }
                
                .citation-source {
                    font-size: 0.75rem;
                    opacity: 0.7;
                    margin-top: 0.25rem;
                }
            </style>
            
            <script src="/static/js/asset_dashboard.js"></script>
            <script>
                // AI Assistant Panel Functionality
                let aiPanelOpen = false;
                let isRecording = false;
                let mediaRecorder = null;
                let recordedChunks = [];
                
                function toggleAIPanel() {{
                    const panel = document.getElementById('aiAssistantPanel');
                    const toggleBtn = document.getElementById('aiToggleBtn');
                    
                    if (aiPanelOpen) {{
                        panel.style.display = 'none';
                        toggleBtn.innerHTML = '▼ Show';
                        aiPanelOpen = false;
                    }} else {{
                        panel.style.display = 'block';
                        toggleBtn.innerHTML = '▲ Hide';
                        aiPanelOpen = true;
                    }}
                }}
                
                function handleChatKeyPress(event) {{
                    if (event.key === 'Enter') {{
                        sendChatMessage();
                    }}
                }}
                
                async function sendChatMessage() {{
                    const input = document.getElementById('chatInput');
                    const message = input.value.trim();
                    
                    if (!message) return;
                    
                    // Add user message to chat
                    addMessageToChat(message, 'user');
                    input.value = '';
                    
                    // Show typing indicator
                    const typingMsg = addMessageToChat('🤖 Thinking...', 'ai', true);
                    
                    try {{
                        // Call AI lookup API
                        const response = await fetch(`/assets/dashboard/{asset_id}/lookup`, {{
                            method: 'POST',
                            headers: {{
                                'Content-Type': 'application/json'
                            }},
                            body: JSON.stringify({{
                                query: message,
                                context_type: 'manual',
                                max_results: 3
                            }})
                        }});
                        
                        const data = await response.json();
                        
                        // Remove typing indicator
                        typingMsg.remove();
                        
                        if (response.ok && data.results.length > 0) {{
                            // Display results with citations
                            let aiResponse = `Found ${{data.results.length}} relevant results:\n\n`;
                            
                            data.results.forEach((result, index) => {{
                                aiResponse += `**${{index + 1}}. ${{result.title}}**\n`;
                                aiResponse += `${{result.content_snippet}}\n`;
                                aiResponse += `*Source: ${{result.source_document}}${{result.page_number ? \\`, Page ${{result.page_number}}\\` : ''}}*\\n\\n`;
                            }});
                            
                            addMessageToChat(aiResponse, 'ai');
                        }} else {{
                            addMessageToChat(`I couldn't find specific information about "${{message}}" for {asset_dict['name']}. Try asking about maintenance procedures, parts, or troubleshooting steps.`, 'ai');
                        }}
                        
                    }} catch (error) {{
                        console.error('AI lookup error:', error);
                        typingMsg.remove();
                        addMessageToChat('Sorry, I encountered an error processing your request. Please try again.', 'ai');
                    }}
                }}
                
                function addMessageToChat(message, type, isTemporary = false) {{
                    const chatMessages = document.getElementById('chatMessages');
                    const messageDiv = document.createElement('div');
                    messageDiv.className = type + '-message';
                    
                    const contentDiv = document.createElement('div');
                    contentDiv.className = 'message-content';
                    
                    // Convert markdown-like formatting to HTML
                    let htmlMessage = message
                        .replace(/\\*\\*(.*?)\\*\\*/g, '<strong>$1</strong>')
                        .replace(/\\*(.*?)\\*/g, '<em>$1</em>')
                        .replace(/\n/g, '<br>');
                    
                    contentDiv.innerHTML = htmlMessage;
                    messageDiv.appendChild(contentDiv);
                    chatMessages.appendChild(messageDiv);
                    
                    // Scroll to bottom
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                    
                    return isTemporary ? messageDiv : null;
                }}
                
                function quickLookup(contextType) {{
                    const queries = {{
                        manual: 'maintenance procedure',
                        parts: 'parts list and specifications',
                        troubleshooting: 'common issues and troubleshooting'
                    }};
                    
                    const input = document.getElementById('chatInput');
                    input.value = queries[contextType] || queries.manual;
                    sendChatMessage();
                }}
                
                async function checkAvailability() {{
                    try {{
                        const response = await fetch(`/assets/dashboard/{asset_id}/availability?date_range=2025-09-10,2025-09-17`);
                        const data = await response.json();
                        
                        if (response.ok) {{
                            let message = `**Availability Check for {asset_dict['name']}:**\n\n`;
                            message += `**Available Technicians:** ${{data.technicians_available.length}}\n`;
                            message += `**Parts Status:** ${{data.parts_status.filter(p => p.status === 'in_stock').length}} in stock, ${{data.parts_status.filter(p => p.status === 'low_stock').length}} low stock\n`;
                            message += `**Recommended Slots:** ${{data.recommended_slots.length}} available\n`;
                            
                            if (data.constraints.length > 0) {{
                                message += `\n**⚠️ Constraints:**\n`;
                                data.constraints.forEach(constraint => {{
                                    message += `• ${{constraint}} \n`;
                                }});
                            }}
                            
                            addMessageToChat(message, 'ai');
                        }} else {{
                            addMessageToChat('Error checking availability. Please try again.', 'ai');
                        }}
                    }} catch (error) {{
                        console.error('Availability check error:', error);
                        addMessageToChat('Error checking availability. Please try again.', 'ai');
                    }}
                }}
                
                function uploadNameplate() {{
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = 'image/*';
                    input.onchange = async function(e) {{
                        const file = e.target.files[0];
                        if (file) {{
                            addMessageToChat('📷 Processing nameplate image...', 'ai', true);
                            
                            try {{
                                const formData = new FormData();
                                formData.append('image', file);
                                formData.append('asset_id', '{asset_id}');
                                
                                const response = await fetch('/ai/voice/ocr/nameplate', {{
                                    method: 'POST',
                                    body: formData
                                }});
                                
                                const data = await response.json();
                                
                                if (response.ok && data.confidence > 0.5) {{
                                    let message = `**Nameplate OCR Results:**\n\n`;
                                    message += `**Confidence:** ${{(data.confidence * 100).toFixed(1)}}%\n\n`;
                                    
                                    if (Object.keys(data.extracted_fields).length > 0) {{
                                        message += `**Extracted Fields:**\n`;
                                        Object.entries(data.extracted_fields).forEach(([key, value]) => {{
                                            message += `• **${{key.replace('_', ' ').toUpperCase()}}:** ${{value}}\n`;
                                        }});
                                    }}
                                    
                                    if (data.matching_manuals.length > 0) {{
                                        message += `\n**Matching Manuals:** ${{data.matching_manuals.length}} found\n`;
                                    }}
                                    
                                    if (data.matching_parts.length > 0) {{
                                        message += `**Matching Parts:** ${{data.matching_parts.length}} found\n`;
                                    }}
                                    
                                    if (data.asset_suggestions.length > 0) {{
                                        message += `\n**Suggested Assets:**\n`;
                                        data.asset_suggestions.slice(0, 2).forEach(asset => {{
                                            message += `• ${{asset.name}} (${{asset.match_score * 100}}% match)\n`;
                                        }});
                                    }}
                                    
                                    addMessageToChat(message, 'ai');
                                }} else {{
                                    addMessageToChat('Could not extract clear information from the nameplate image. Please try a clearer photo with good lighting.', 'ai');
                                }}
                                
                            }} catch (error) {{
                                console.error('OCR processing error:', error);
                                addMessageToChat('Error processing nameplate image. Please try again.', 'ai');
                            }}
                        }}
                    }};
                    input.click();
                }}
                
                async function toggleVoiceInput() {{
                    if (!isRecording) {{
                        startVoiceRecording();
                    }} else {{
                        stopVoiceRecording();
                    }}
                }}
                
                async function startVoiceRecording() {{
                    try {{
                        const stream = await navigator.mediaDevices.getUserMedia({{ audio: true }});
                        mediaRecorder = new MediaRecorder(stream);
                        recordedChunks = [];
                        
                        mediaRecorder.addEventListener('dataavailable', event => {{
                            if (event.data.size > 0) {{
                                recordedChunks.push(event.data);
                            }}
                        }});
                        
                        mediaRecorder.addEventListener('stop', processVoiceRecording);
                        
                        mediaRecorder.start();
                        isRecording = true;
                        
                        const voiceBtn = document.getElementById('voiceBtn');
                        const voiceBtnText = document.getElementById('voiceBtnText');
                        const voiceStatus = document.getElementById('voiceStatus');
                        
                        voiceBtn.classList.add('recording');
                        voiceBtnText.textContent = '⏹️ Stop Recording';
                        voiceStatus.style.display = 'block';
                        
                    }} catch (error) {{
                        console.error('Error accessing microphone:', error);
                        addMessageToChat('Could not access microphone. Please check permissions.', 'ai');
                    }}
                }}
                
                function stopVoiceRecording() {{
                    if (mediaRecorder && isRecording) {{
                        mediaRecorder.stop();
                        mediaRecorder.stream.getTracks().forEach(track => track.stop());
                        isRecording = false;
                        
                        const voiceBtn = document.getElementById('voiceBtn');
                        const voiceBtnText = document.getElementById('voiceBtnText');
                        const voiceStatus = document.getElementById('voiceStatus');
                        
                        voiceBtn.classList.remove('recording');
                        voiceBtnText.textContent = '🎤 Start Voice';
                        voiceStatus.style.display = 'none';
                    }}
                }}
                
                async function processVoiceRecording() {{
                    if (recordedChunks.length === 0) return;
                    
                    const audioBlob = new Blob(recordedChunks, {{ type: 'audio/webm' }});
                    const formData = new FormData();
                    formData.append('audio', audioBlob, 'voice_command.webm');
                    formData.append('user_id', 'dashboard_user');
                    formData.append('context', 'asset_dashboard');
                    
                    try {{
                        addMessageToChat('🎤 Processing voice command...', 'ai', true);
                        
                        const response = await fetch('/ai/voice/process-audio', {{
                            method: 'POST',
                            body: formData
                        }});
                        
                        const data = await response.json();
                        
                        if (response.ok && data.success) {{
                            // Add the transcribed text as user message
                            addMessageToChat(`🎤 "${{data.command.raw_text}}"`, 'user');
                            
                            // Process the voice command result
                            if (data.action === 'create_work_order' && data.work_order_created) {{
                                addMessageToChat(`✅ ${{data.message}}\n\nWork Order Created: ${{data.work_order_created.wo_number}}`, 'ai');
                            }} else {{
                                addMessageToChat(data.message, 'ai');
                            }}
                        }} else {{
                            addMessageToChat('Could not process voice command. Please try speaking more clearly.', 'ai');
                        }}
                        
                    }} catch (error) {{
                        console.error('Voice processing error:', error);
                        addMessageToChat('Error processing voice command. Please try again.', 'ai');
                    }}
                }}
                
                // Auto-refresh AI panel if asset status changes
                setInterval(() => {{
                    if (aiPanelOpen) {{
                        // Could add auto-refresh logic here
                    }}
                }}, 30000);
            </script>
        </body>
        </html>
        """
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rendering asset dashboard for {asset_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@assets_router.get("/")
async def assets_root():
    """Redirect to assets dashboard"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/assets/dashboard", status_code=302)

@assets_router.get("/api")
async def get_assets(
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    criticality: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all assets with optional filtering"""
    # Debug logging
    logger.debug(f"get_assets called with: status={status}, category={category}, criticality={criticality}")
    
    filtered_assets = assets_db.copy()
    
    if status and status != "" and str(status) not in ['None', 'annotation=']:
        filtered_assets = [a for a in filtered_assets if a['status'] == status]
        logger.debug(f"Filtered by status '{status}': {len(filtered_assets)} assets")
    if category and category != "" and str(category) not in ['None', 'annotation=']:
        filtered_assets = [a for a in filtered_assets if a['category'] == category]
        logger.debug(f"Filtered by category '{category}': {len(filtered_assets)} assets")
    if criticality and criticality != "" and str(criticality) not in ['None', 'annotation=']:
        filtered_assets = [a for a in filtered_assets if a['criticality'] == criticality]
        logger.debug(f"Filtered by criticality '{criticality}': {len(filtered_assets)} assets")
    
    logger.debug(f"Returning {len(filtered_assets)} assets")
    return filtered_assets

@assets_router.get("/{asset_id}")
async def get_asset(asset_id: str) -> Dict:
    """Get specific asset details"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    # Get maintenance history for this asset
    history = [h for h in maintenance_history_db if h['asset_id'] == asset_id]
    
    return {
        "asset": asset,
        "maintenance_history": history,
        "metrics": {
            "uptime_percentage": 94.2,
            "mtbf": 720.0,  # hours
            "mttr": 4.5,    # hours
            "maintenance_cost_ytd": sum(h['cost'] for h in history),
            "failure_count": len([h for h in history if h['type'] == 'emergency'])
        }
    }

@assets_router.post("/")
async def create_asset(asset_data: Dict[str, Any]) -> Dict:
    """Create new asset"""
    asset_id = f"AST-{len(assets_db) + 1:03d}"
    
    new_asset = {
        "id": asset_id,
        "name": asset_data["name"],
        "category": asset_data["category"],
        "location": asset_data["location"],
        "status": "operational",
        "condition": "good",
        "manufacturer": asset_data["manufacturer"],
        "model": asset_data["model"],
        "serial_number": asset_data["serial_number"],
        "installation_date": datetime.now().strftime("%Y-%m-%d"),
        "last_maintenance": None,
        "next_maintenance": (datetime.now() + timedelta(days=asset_data.get("maintenance_frequency", 30))).strftime("%Y-%m-%d"),
        "maintenance_frequency": asset_data.get("maintenance_frequency", 30),
        "criticality": asset_data["criticality"],
        "cost_center": asset_data.get("cost_center", "GENERAL"),
        "specifications": asset_data.get("specifications", {})
    }
    
    assets_db.append(new_asset)
    logger.info(f"Asset created: {asset_id}")
    return new_asset

@assets_router.put("/{asset_id}")
async def update_asset(asset_id: str, asset_data: Dict[str, Any]) -> Dict:
    """Update asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    asset.update(asset_data)
    logger.info(f"Asset updated: {asset_id}")
    return asset

@assets_router.post("/{asset_id}/maintenance")
async def record_maintenance(asset_id: str, maintenance_data: Dict[str, Any]) -> Dict:
    """Record maintenance activity"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    maintenance_id = f"MH-{len(maintenance_history_db) + 1:03d}"
    
    maintenance_record = {
        "id": maintenance_id,
        "asset_id": asset_id,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "type": maintenance_data["type"],
        "technician": maintenance_data["technician"],
        "description": maintenance_data["description"],
        "cost": maintenance_data.get("cost", 0.0),
        "downtime_hours": maintenance_data.get("downtime_hours", 0.0)
    }
    
    maintenance_history_db.append(maintenance_record)
    
    # Update asset maintenance dates
    asset["last_maintenance"] = maintenance_record["date"]
    if maintenance_data["type"] == "scheduled":
        next_date = datetime.now() + timedelta(days=asset["maintenance_frequency"])
        asset["next_maintenance"] = next_date.strftime("%Y-%m-%d")
        asset["status"] = "operational"
    
    logger.info(f"Maintenance recorded: {maintenance_id} for asset {asset_id}")
    return maintenance_record

@assets_router.get("/{asset_id}/history")
async def get_asset_history(asset_id: str) -> List[Dict]:
    """Get maintenance history for specific asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    return [h for h in maintenance_history_db if h['asset_id'] == asset_id]

@assets_router.get("/reports/summary")
async def get_assets_summary() -> Dict:
    """Get asset summary report"""
    total_assets = len(assets_db)
    by_status = {}
    by_category = {}
    by_criticality = {}
    
    for asset in assets_db:
        by_status[asset['status']] = by_status.get(asset['status'], 0) + 1
        by_category[asset['category']] = by_category.get(asset['category'], 0) + 1
        by_criticality[asset['criticality']] = by_criticality.get(asset['criticality'], 0) + 1
    
    total_maintenance_cost = sum(h['cost'] for h in maintenance_history_db)
    avg_uptime = 94.2  # Would calculate from actual data
    
    return {
        "total_assets": total_assets,
        "breakdown_by_status": by_status,
        "breakdown_by_category": by_category,
        "breakdown_by_criticality": by_criticality,
        "total_maintenance_cost_ytd": total_maintenance_cost,
        "average_uptime": avg_uptime,
        "assets_requiring_attention": len([a for a in assets_db if a['status'] in ['maintenance_due', 'down']]),
        "generated_at": datetime.now().isoformat()
    }

@assets_router.get("/export/csv")
async def export_assets_csv():
    """Export assets to CSV"""
    import io
    import csv
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=assets_db[0].keys() if assets_db else [])
    writer.writeheader()
    for asset in assets_db:
        # Flatten specifications dict for CSV
        row = asset.copy()
        row['specifications'] = str(asset['specifications'])
        writer.writerow(row)
    
    return {
        "filename": f"chatterfix_assets_{datetime.now().strftime('%Y%m%d')}.csv",
        "content": output.getvalue(),
        "content_type": "text/csv"
    }

@assets_router.get("/{asset_id}/view", response_class=HTMLResponse)
async def view_asset_page(asset_id: str):
    """Display a single asset in a full HTML page."""
    try:
        asset_details = await get_asset(asset_id)
        asset = asset_details['asset']
        history = asset_details['maintenance_history']
        metrics = asset_details['metrics']
        
        # Find related work orders
        related_work_orders = [wo for wo in work_orders_db if wo['asset_id'] == asset_id]

        def generate_history_html(history):
            if not history:
                return "<p>No maintenance history recorded.</p>"
            html = ""
            for item in sorted(history, key=lambda x: x['date'], reverse=True):
                html += f"""
                <div class="history-item">
                    <div class="history-header">
                        <strong>{item['type'].title()} Maintenance</strong>
                        <span class="timestamp">{item['date']}</span>
                    </div>
                    <p>{item['description']}</p>
                    <div class="history-footer">
                        <span>Technician: {item['technician']}</span>
                        <span>Cost: ${item['cost']:.2f}</span>
                        <span>Downtime: {item['downtime_hours']}h</span>
                    </div>
                </div>
                """
            return html

        def generate_work_orders_html(work_orders):
            if not work_orders:
                return "<p>No work orders for this asset.</p>"
            html = ""
            for wo in work_orders:
                html += f"""
                <div class="wo-item">
                    <a href="/cmms/workorders/{wo['id']}/view">{wo['id']}: {wo['title']}</a>
                    <span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span>
                </div>
                """
            return html

        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Asset Details: {asset['name']}</title>
            <style>
                body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; color: #2d3748; }}
                .header {{ background: #2d3748; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }}
                .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
                .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 2rem; }}
                .grid {{ display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; }}
                h1, h2, h3 {{ color: #1a202c; }}
                .asset-title {{ font-size: 2.5rem; margin-bottom: 0.5rem; }}
                .status-badge {{ padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 1rem; font-weight: 600; display: inline-block; }}
                .status-operational {{ background: #c6f6d5; color: #276749; }}
                .status-maintenance_due {{ background: #fefcbf; color: #975a16; }}
                .status-down {{ background: #fed7d7; color: #9b2c2c; }}
                .details-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-top: 1.5rem; }}
                .detail-item {{ background: #edf2f7; padding: 1rem; border-radius: 4px; }}
                .detail-item strong {{ display: block; font-size: 0.8rem; color: #718096; margin-bottom: 0.25rem; text-transform: uppercase; }}
                .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }}
                .btn-warning {{ background: #d69e2e; }}
                .btn-danger {{ background: #e53e3e; }}
                .history-item, .wo-item {{ border: 1px solid #e2e8f0; border-radius: 4px; padding: 1rem; margin-bottom: 1rem; }}
                .history-header, .wo-item {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }}
                .timestamp {{ font-size: 0.8rem; color: #718096; }}
                .history-footer {{ font-size: 0.9rem; color: #4a5568; display: flex; gap: 1.5rem; margin-top: 1rem; border-top: 1px solid #e2e8f0; padding-top: 0.75rem; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>ChatterFix CMMS</h1>
                <a href="/cmms/assets/dashboard" class="btn">Back to Assets</a>
            </div>
            <div class="container">
                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h1 class="asset-title">{asset['name']}</h1>
                            <p style="margin:0; color: #718096;">{asset['category']} / {asset['location']}</p>
                        </div>
                        <span class="status-badge status-{asset['status']}">{asset['status'].replace('_', ' ').title()}</span>
                    </div>
                </div>

                <div class="grid">
                    <div class="main-content">
                        <div class="card">
                            <h2>Asset Details</h2>
                            <div class="details-grid">
                                <div class="detail-item"><strong>Asset ID</strong> {asset['id']}</div>
                                <div class="detail-item"><strong>Manufacturer</strong> {asset['manufacturer']}</div>
                                <div class="detail-item"><strong>Model</strong> {asset['model']}</div>
                                <div class="detail-item"><strong>Serial Number</strong> {asset['serial_number']}</div>
                                <div class="detail-item"><strong>Installation Date</strong> {asset['installation_date']}</div>
                                <div class="detail-item"><strong>Criticality</strong> <span style="font-weight:bold; color: {'critical': '#e53e3e', 'high': '#d69e2e'}.get(asset['criticality'], '#38a169');">{asset['criticality'].title()}</span></div>
                                <div class="detail-item"><strong>Condition</strong> {asset['condition'].title()}</div>
                                <div class="detail-item"><strong>Cost Center</strong> {asset['cost_center']}</div>
                            </div>
                            <h3>Specifications</h3>
                            <ul>
                                {"".join(f"<li><strong>{key.replace('_', ' ').title()}:</strong> {value}</li>" for key, value in asset['specifications'].items())}
                            </ul>
                        </div>

                        <div class="card">
                            <h2>Maintenance History</h2>
                            {generate_history_html(history)}
                        </div>
                    </div>
                    <div class="sidebar">
                        <div class="card">
                            <h2>Actions</h2>
                            <a href="/cmms/workorders/create?asset_id={asset['id']}&type=reactive" class="btn btn-danger" style="display: block; margin-bottom: 1rem; text-align: center;">Create Work Order</a>
                            <a href="/cmms/assets/{asset['id']}/edit" class="btn btn-warning" style="display: block; text-align: center;">Edit Asset</a>
                        </div>
                        <div class="card">
                            <h2>Maintenance Schedule</h2>
                            <div class="detail-item"><strong>Last Maintenance</strong> {asset.get('last_maintenance', 'N/A')}</div>
                            <div class="detail-item" style="margin-top:1rem;"><strong>Next Maintenance</strong> {asset.get('next_maintenance', 'N/A')}</div>
                            <div class="detail-item" style="margin-top:1rem;"><strong>Frequency</strong> Every {asset['maintenance_frequency']} days</div>
                        </div>
                        <div class="card">
                            <h2>Related Work Orders</h2>
                            {generate_work_orders_html(related_work_orders)}
                        </div>
                        <div class="card">
                            <h2>Performance Metrics</h2>
                            <p><strong>Uptime:</strong> {metrics['uptime_percentage']}%</p>
                            <p><strong>MTBF:</strong> {metrics['mtbf']} hours</p>
                            <p><strong>MTTR:</strong> {metrics['mttr']} hours</p>
                            <p><strong>YTD Cost:</strong> ${metrics['maintenance_cost_ytd']:.2f}</p>
                            <p><strong>Failures:</strong> {metrics['failure_count']}</p>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
    except HTTPException as e:
        return f"<h1>Error</h1><p>Could not find asset with ID {asset_id}.</p><p>{e.detail}</p>"
    except Exception as e:
        logger.error(f"Error rendering asset page for {asset_id}: {e}")
        return f"<h1>Server Error</h1><p>An unexpected error occurred.</p>"

# Missing routes for assets workflow

@assets_router.get("/{asset_id}/edit", response_class=HTMLResponse)
async def edit_asset_form(asset_id: str):
    """Edit asset form"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Edit Asset: {asset['name']}</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 800px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .form-group {{ margin: 1rem 0; }}
            .form-group label {{ display: block; margin-bottom: 0.5rem; font-weight: 600; }}
            .form-group input, .form-group textarea, .form-group select {{ width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn-success {{ background: #38a169; }}
            .asset-info {{ background: #f7fafc; padding: 1rem; border-left: 4px solid #4299e1; margin-bottom: 1rem; }}
            .grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>⚙️ Edit Asset</h1>
            <p>Update asset information and specifications</p>
        </div>
        
        <div class="container">
            <div class="asset-info">
                <h3>{asset['name']} ({asset_id})</h3>
                <p><strong>Category:</strong> {asset['category']}</p>
                <p><strong>Current Status:</strong> {asset['status'].title()}</p>
                <p><strong>Health Score:</strong> {asset.get('health_score', 8.0)}/10</p>
            </div>
            
            <div class="card">
                <form id="editAssetForm">
                    <div class="form-group">
                        <label>Asset Name:</label>
                        <input type="text" name="name" value="{asset['name']}" required>
                    </div>
                    
                    <div class="grid">
                        <div class="form-group">
                            <label>Category:</label>
                            <select name="category" required>
                                <option value="Compressor" {"selected" if asset['category'] == 'Compressor' else ""}>Compressor</option>
                                <option value="Conveyor" {"selected" if asset['category'] == 'Conveyor' else ""}>Conveyor</option>
                                <option value="HVAC" {"selected" if asset['category'] == 'HVAC' else ""}>HVAC</option>
                                <option value="Generator" {"selected" if asset['category'] == 'Generator' else ""}>Generator</option>
                                <option value="Packaging" {"selected" if asset['category'] == 'Packaging' else ""}>Packaging</option>
                                <option value="Other" {"selected" if asset['category'] == 'Other' else ""}>Other</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Status:</label>
                            <select name="status" required>
                                <option value="operational" {"selected" if asset['status'] == 'operational' else ""}>Operational</option>
                                <option value="maintenance_due" {"selected" if asset['status'] == 'maintenance_due' else ""}>Maintenance Due</option>
                                <option value="down" {"selected" if asset['status'] == 'down' else ""}>Down</option>
                                <option value="retired" {"selected" if asset['status'] == 'retired' else ""}>Retired</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="grid">
                        <div class="form-group">
                            <label>Criticality:</label>
                            <select name="criticality" required>
                                <option value="low" {"selected" if asset['criticality'] == 'low' else ""}>Low</option>
                                <option value="medium" {"selected" if asset['criticality'] == 'medium' else ""}>Medium</option>
                                <option value="high" {"selected" if asset['criticality'] == 'high' else ""}>High</option>
                                <option value="critical" {"selected" if asset['criticality'] == 'critical' else ""}>Critical</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Health Score (0-10):</label>
                            <input type="number" name="health_score" min="0" max="10" value="{asset.get('health_score', 8.0)}" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Location:</label>
                        <input type="text" name="location" value="{asset['location']}" required>
                    </div>
                    
                    <div class="grid">
                        <div class="form-group">
                            <label>Manufacturer:</label>
                            <input type="text" name="manufacturer" value="{asset['manufacturer']}" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Model:</label>
                            <input type="text" name="model" value="{asset['model']}" required>
                        </div>
                    </div>
                    
                    <div class="grid">
                        <div class="form-group">
                            <label>Serial Number:</label>
                            <input type="text" name="serial_number" value="{asset['serial_number']}" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Installation Date:</label>
                            <input type="date" name="install_date" value="{asset.get('install_date', '')}">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Description:</label>
                        <textarea name="description" rows="3">{asset.get('description', '')}</textarea>
                    </div>
                    
                    <div style="text-align: center; padding-top: 1rem;">
                        <button type="submit" class="btn btn-success">💾 Save Changes</button>
                        <button type="button" class="btn" onclick="window.history.back()">↩️ Cancel</button>
                        <a href="/assets/dashboard" class="btn">📋 Back to Assets</a>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            document.getElementById('editAssetForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const assetData = Object.fromEntries(formData);
                
                fetch('/assets/{asset_id}', {{
                    method: 'PUT',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(assetData)
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.id) {{
                        alert('Asset updated successfully!');
                        window.location.href = '/assets/dashboard';
                    }} else {{
                        alert('Error updating asset: ' + (data.message || 'Unknown error'));
                    }}
                }})
                .catch(error => {{
                    alert('Error: ' + error.message);
                }});
            }});
        </script>
    </body>
    </html>
    """

@assets_router.get("/reports", response_class=HTMLResponse)
async def assets_reports_dashboard():
    """Assets Reports Dashboard"""
    total_assets = len(assets_db)
    operational_assets = len([a for a in assets_db if a['status'] == 'operational'])
    maintenance_due = len([a for a in assets_db if a['status'] == 'maintenance_due'])
    down_assets = len([a for a in assets_db if a['status'] == 'down'])
    
    # Calculate metrics
    operational_percentage = (operational_assets / total_assets * 100) if total_assets > 0 else 0
    critical_assets = len([a for a in assets_db if a['criticality'] == 'critical'])
    avg_health_score = sum(a.get('health_score', 8.0) for a in assets_db) / total_assets if total_assets > 0 else 0
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Assets Reports Dashboard</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; margin: 0.5rem; text-decoration: none; display: inline-block; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; }}
            .stat-card {{ text-align: center; padding: 1.5rem; border: 1px solid #e2e8f0; border-radius: 8px; }}
            .stat-value {{ font-size: 2.5rem; font-weight: bold; color: #4299e1; }}
            .report-card {{ border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📊 Assets Reports Dashboard</h1>
            <p>Asset performance analytics and compliance reports</p>
        </div>
        
        <div class="container">
            <div class="card">
                <h3>Asset Overview Metrics</h3>
                <div class="grid">
                    <div class="stat-card">
                        <div class="stat-value">{total_assets}</div>
                        <div>Total Assets</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #38a169;">{operational_assets}</div>
                        <div>Operational</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #d69e2e;">{maintenance_due}</div>
                        <div>Maintenance Due</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #e53e3e;">{down_assets}</div>
                        <div>Down</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #e53e3e;">{critical_assets}</div>
                        <div>Critical Assets</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{operational_percentage:.1f}%</div>
                        <div>Uptime Rate</div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <h3>Available Reports</h3>
                <div class="grid">
                    <div class="report-card">
                        <h4>Asset Performance Report</h4>
                        <p>Comprehensive performance metrics and KPIs</p>
                        <a href="/assets/reports/summary" class="btn">View Report</a>
                    </div>
                    
                    <div class="report-card">
                        <h4>Maintenance Compliance</h4>
                        <p>Preventive maintenance adherence and scheduling</p>
                        <button class="btn" onclick="generateMaintenanceReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Asset Health Analysis</h4>
                        <p>Health scores and predictive maintenance insights</p>
                        <button class="btn" onclick="generateHealthReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Cost Analysis</h4>
                        <p>Asset lifecycle costs and maintenance expenses</p>
                        <button class="btn" onclick="generateCostReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Downtime Analysis</h4>
                        <p>Equipment downtime trends and root cause analysis</p>
                        <button class="btn" onclick="generateDowntimeReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Asset Utilization</h4>
                        <p>Equipment usage patterns and capacity analysis</p>
                        <button class="btn" onclick="generateUtilizationReport()">Generate Report</button>
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <a href="/assets/dashboard" class="btn">↩️ Back to Assets</a>
                    <button class="btn" onclick="exportAllReports()">📊 Export All Reports</button>
                </div>
            </div>
        </div>
        
        <script>
            function generateMaintenanceReport() {{
                alert('Maintenance compliance report - Feature coming soon!');
            }}
            
            function generateHealthReport() {{
                alert('Asset health analysis report - Feature coming soon!');
            }}
            
            function generateCostReport() {{
                alert('Cost analysis report - Feature coming soon!');
            }}
            
            function generateDowntimeReport() {{
                alert('Downtime analysis report - Feature coming soon!');
            }}
            
            function generateUtilizationReport() {{
                alert('Asset utilization report - Feature coming soon!');
            }}
            
            function exportAllReports() {{
                alert('Export all reports - Feature coming soon!');
            }}
        </script>
    </body>
    </html>
    """

# =============================================================================
# AI Assistant Features for Asset Dashboard
# =============================================================================

class AssetLookupRequest(BaseModel):
    query: str
    context_type: str = "manual"  # "manual", "parts", "troubleshooting"
    max_results: int = 5

class AssetLookupResponse(BaseModel):
    query: str
    asset_id: str
    context_type: str
    results: List[Dict[str, Any]]
    processing_time_ms: int
    total_results: int

@assets_router.post("/dashboard/{asset_id}/lookup")
async def lookup_asset_information(asset_id: str, request: AssetLookupRequest) -> AssetLookupResponse:
    """Search manuals, parts, or troubleshooting info for specific asset with citations"""
    start_time = time.time()
    
    # Verify asset exists
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    try:
        # Get RAG response based on context type
        rag_response = await answer_asset_question(asset_id, request.query, request.context_type)
        
        # Convert search results to API format
        results = []
        for i, result in enumerate(rag_response.search_results[:request.max_results]):
            result_dict = {
                "rank": i + 1,
                "title": result.chunk.filename,
                "content_snippet": result.chunk.text[:300] + "..." if len(result.chunk.text) > 300 else result.chunk.text,
                "source_document": result.chunk.filename,
                "page_number": result.chunk.page_number,
                "section_title": result.chunk.section_title,
                "confidence_score": round(result.score, 3),
                "document_id": result.chunk.document_id,
                "chunk_type": result.chunk.chunk_type
            }
            results.append(result_dict)
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return AssetLookupResponse(
            query=request.query,
            asset_id=asset_id,
            context_type=request.context_type,
            results=results,
            processing_time_ms=processing_time,
            total_results=len(rag_response.search_results)
        )
        
    except Exception as e:
        logger.error(f"Error in asset lookup for {asset_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Lookup failed: {str(e)}")

@assets_router.get("/dashboard/{asset_id}/availability")
async def check_asset_availability(
    asset_id: str,
    date_range: str = Query("2025-09-10,2025-09-17", description="Date range in YYYY-MM-DD,YYYY-MM-DD format"),
    required_skills: List[str] = Query([], description="Required technician skills")
) -> Dict[str, Any]:
    """Check technician availability and parts stock for maintenance scheduling"""
    # Verify asset exists
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    try:
        # Parse date range
        start_date, end_date = date_range.split(",")
        
        # Mock technician availability (in production, query from database)
        available_technicians = [
            {
                "id": "TECH-001",
                "name": "John Smith",
                "skills": ["electrical", "mechanical", "hydraulic"],
                "availability_score": 0.85,
                "available_hours": 32,
                "current_workload": "medium"
            },
            {
                "id": "TECH-002", 
                "name": "Sarah Davis",
                "skills": ["mechanical", "welding", "fabrication"],
                "availability_score": 0.92,
                "available_hours": 38,
                "current_workload": "low"
            }
        ]
        
        # Filter by required skills if specified
        if required_skills:
            available_technicians = [
                tech for tech in available_technicians
                if any(skill in tech["skills"] for skill in required_skills)
            ]
        
        # Mock parts availability (in production, query inventory database)
        parts_status = [
            {
                "part_id": "PRT-001",
                "name": "Air Filter",
                "current_stock": 5,
                "required_for_maintenance": 1,
                "status": "in_stock",
                "lead_time_days": 0
            },
            {
                "part_id": "PRT-002",
                "name": "Compressor Oil", 
                "current_stock": 1,
                "required_for_maintenance": 2,
                "status": "low_stock",
                "lead_time_days": 3
            }
        ]
        
        # Recommend optimal time slots based on availability
        recommended_slots = [
            {
                "date": "2025-09-12",
                "time": "09:00-13:00",
                "technician": "Sarah Davis",
                "confidence": 0.92,
                "estimated_duration": "4 hours"
            },
            {
                "date": "2025-09-13",
                "time": "14:00-18:00", 
                "technician": "John Smith",
                "confidence": 0.85,
                "estimated_duration": "4 hours"
            }
        ]
        
        # Identify constraints
        constraints = []
        if any(part["status"] == "out_of_stock" for part in parts_status):
            constraints.append("Parts out of stock - order required")
        if any(part["status"] == "low_stock" for part in parts_status):
            constraints.append("Low stock on critical parts")
        if not available_technicians:
            constraints.append("No technicians available with required skills")
        
        return {
            "asset_id": asset_id,
            "date_range": date_range,
            "required_skills": required_skills,
            "technicians_available": available_technicians,
            "parts_status": parts_status,
            "recommended_slots": recommended_slots,
            "constraints": constraints,
            "overall_availability": "high" if not constraints else "medium" if len(constraints) <= 2 else "low"
        }
        
    except Exception as e:
        logger.error(f"Error checking availability for asset {asset_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Availability check failed: {str(e)}")

@assets_router.get("/export", response_class=HTMLResponse)
async def export_assets_dashboard():
    """Assets Export Dashboard"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Export Assets Data</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 800px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; margin: 0.5rem; text-decoration: none; display: inline-block; }}
            .btn-success {{ background: #38a169; }}
            .export-card {{ border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📤 Export Assets Data</h1>
            <p>Download asset information in various formats</p>
        </div>
        
        <div class="container">
            <div class="card">
                <h3>Available Export Formats</h3>
                <div class="grid">
                    <div class="export-card">
                        <h4>📊 CSV Export</h4>
                        <p>Basic asset information in CSV format</p>
                        <a href="/assets/export/csv" class="btn btn-success">Download CSV</a>
                    </div>
                    
                    <div class="export-card">
                        <h4>📋 Excel Export</h4>
                        <p>Comprehensive asset data with formatting</p>
                        <button class="btn" onclick="exportExcel()">Download Excel</button>
                    </div>
                    
                    <div class="export-card">
                        <h4>📄 PDF Report</h4>
                        <p>Formatted asset report with charts</p>
                        <button class="btn" onclick="exportPDF()">Generate PDF</button>
                    </div>
                    
                    <div class="export-card">
                        <h4>🔧 Maintenance Schedule</h4>
                        <p>Upcoming maintenance calendar</p>
                        <button class="btn" onclick="exportSchedule()">Export Schedule</button>
                    </div>
                </div>
                
                <div style="margin-top: 2rem; text-align: center;">
                    <a href="/assets/dashboard" class="btn">↩️ Back to Assets</a>
                </div>
            </div>
        </div>
        
        <script>
            function exportExcel() {{
                alert('Excel export - Feature coming soon!');
            }}
            
            function exportPDF() {{
                alert('PDF report generation - Feature coming soon!');
            }}
            
            function exportSchedule() {{
                alert('Maintenance schedule export - Feature coming soon!');
            }}
        </script>
    </body>
    </html>
    """

# =============================================================================
# Real-time Asset Performance KPI System
# =============================================================================

def calculate_asset_kpis() -> Dict[str, Any]:
    """Calculate real-time asset performance KPIs"""
    now = datetime.now()
    
    # Calculate key metrics
    total_assets = len(assets_db)
    operational_count = len([a for a in assets_db if a['status'] == 'operational'])
    down_count = len([a for a in assets_db if a['status'] == 'down'])
    maintenance_count = len([a for a in assets_db if a['status'] == 'maintenance_due'])
    
    # Calculate Overall Equipment Effectiveness (OEE)
    availability = (operational_count / total_assets * 100) if total_assets > 0 else 0
    performance = 85.5  # Sample performance metric based on throughput
    quality = 92.3      # Sample quality metric based on defect rates
    oee = (availability * performance * quality) / 10000
    
    # Calculate MTBF (Mean Time Between Failures) in hours
    mtbf = 168.5  # Sample: ~7 days average
    
    # Calculate MTTR (Mean Time To Repair) in hours  
    mttr = 4.2   # Sample: ~4.2 hours average
    
    # Cost metrics
    total_maintenance_cost = sum(h.get('cost', 0) for h in maintenance_history_db)
    avg_cost_per_asset = total_maintenance_cost / total_assets if total_assets > 0 else 0
    
    return {
        "timestamp": now.isoformat(),
        "asset_metrics": {
            "total_assets": total_assets,
            "operational": operational_count,
            "down": down_count,
            "maintenance_due": maintenance_count,
            "availability_percent": round(availability, 2)
        },
        "performance_kpis": {
            "overall_equipment_effectiveness": round(oee, 2),
            "availability": round(availability, 2),
            "performance": performance,
            "quality": quality,
            "mtbf_hours": mtbf,
            "mttr_hours": mttr
        },
        "cost_metrics": {
            "total_maintenance_cost": total_maintenance_cost,
            "average_cost_per_asset": round(avg_cost_per_asset, 2),
            "cost_trend": "stable"  # Sample trend
        },
        "alerts": [
            {"level": "warning", "message": f"{down_count} assets currently down"} if down_count > 0 else None,
            {"level": "info", "message": f"{maintenance_count} assets require maintenance"} if maintenance_count > 0 else None
        ]
    }

@assets_router.get("/kpis/realtime")
async def get_realtime_kpis():
    """Get real-time asset performance KPIs"""
    try:
        kpis = calculate_asset_kpis()
        return {"status": "success", "data": kpis}
    except Exception as e:
        logger.error(f"Error calculating real-time KPIs: {e}")
        raise HTTPException(status_code=500, detail=f"KPI calculation failed: {str(e)}")

@assets_router.get("/kpis/dashboard", response_class=HTMLResponse)
async def kpi_dashboard():
    """Real-time Asset Performance KPI Dashboard"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Real-time Asset Performance KPIs - ChatterFix CMMS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
            }
            
            .dashboard-header {
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                padding: 1.5rem 2rem;
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
                color: white;
            }
            
            .dashboard-header h1 {
                font-size: 2rem;
                font-weight: 600;
                margin-bottom: 0.5rem;
            }
            
            .last-updated {
                opacity: 0.8;
                font-size: 0.9rem;
            }
            
            .dashboard-container {
                padding: 2rem;
                max-width: 1400px;
                margin: 0 auto;
            }
            
            .kpi-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 1.5rem;
                margin-bottom: 2rem;
            }
            
            .kpi-card {
                background: rgba(255, 255, 255, 0.95);
                border-radius: 16px;
                padding: 1.5rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.2);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            
            .kpi-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
            }
            
            .kpi-header {
                display: flex;
                align-items: center;
                margin-bottom: 1rem;
            }
            
            .kpi-icon {
                font-size: 2rem;
                margin-right: 0.75rem;
            }
            
            .kpi-title {
                font-size: 0.9rem;
                font-weight: 600;
                color: #4a5568;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .kpi-value {
                font-size: 2.5rem;
                font-weight: 700;
                color: #2d3748;
                margin-bottom: 0.5rem;
            }
            
            .kpi-change {
                font-size: 0.85rem;
                padding: 0.25rem 0.5rem;
                border-radius: 12px;
                font-weight: 500;
            }
            
            .positive { background: #c6f6d5; color: #22543d; }
            .negative { background: #fed7d7; color: #c53030; }
            .neutral { background: #e2e8f0; color: #4a5568; }
            
            .oee-gauge {
                position: relative;
                width: 200px;
                height: 200px;
                margin: 1rem auto;
            }
            
            .gauge-bg {
                width: 100%;
                height: 100%;
                border-radius: 50%;
                background: conic-gradient(#4ade80 0deg var(--oee-angle), #e5e7eb var(--oee-angle) 360deg);
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .gauge-inner {
                width: 150px;
                height: 150px;
                background: white;
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            }
            
            .gauge-value {
                font-size: 2rem;
                font-weight: 700;
                color: #2d3748;
            }
            
            .gauge-label {
                font-size: 0.8rem;
                color: #6b7280;
                margin-top: 0.25rem;
            }
            
            .alerts-section {
                background: rgba(255, 255, 255, 0.95);
                border-radius: 16px;
                padding: 1.5rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            
            .alert-item {
                display: flex;
                align-items: center;
                padding: 0.75rem;
                margin-bottom: 0.5rem;
                border-radius: 8px;
                background: rgba(255, 255, 255, 0.5);
            }
            
            .alert-warning { border-left: 4px solid #f59e0b; }
            .alert-info { border-left: 4px solid #3b82f6; }
            
            .refresh-btn {
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                background: #4299e1;
                color: white;
                border: none;
                border-radius: 50%;
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                transition: all 0.3s ease;
            }
            
            .refresh-btn:hover {
                background: #3182ce;
                transform: scale(1.1);
            }
            
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            .spinning {
                animation: spin 1s linear;
            }
        </style>
    </head>
    <body>
        <div class="dashboard-header">
            <h1>📊 Real-time Asset Performance KPIs</h1>
            <div class="last-updated">Last updated: <span id="lastUpdated">Loading...</span></div>
        </div>
        
        <div class="dashboard-container">
            <div class="kpi-grid">
                <!-- Asset Status Overview -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">🏭</div>
                        <div class="kpi-title">Total Assets</div>
                    </div>
                    <div class="kpi-value" id="totalAssets">--</div>
                    <div class="kpi-change neutral" id="assetsChange">No change</div>
                </div>
                
                <!-- Operational Assets -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">✅</div>
                        <div class="kpi-title">Operational</div>
                    </div>
                    <div class="kpi-value" id="operationalAssets">--</div>
                    <div class="kpi-change positive" id="operationalChange">98.5% availability</div>
                </div>
                
                <!-- Down Assets -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">🚨</div>
                        <div class="kpi-title">Assets Down</div>
                    </div>
                    <div class="kpi-value" id="downAssets">--</div>
                    <div class="kpi-change negative" id="downChange">Requires attention</div>
                </div>
                
                <!-- Maintenance Due -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">🔧</div>
                        <div class="kpi-title">Maintenance Due</div>
                    </div>
                    <div class="kpi-value" id="maintenanceDue">--</div>
                    <div class="kpi-change neutral" id="maintenanceChange">Scheduled</div>
                </div>
                
                <!-- Overall Equipment Effectiveness -->
                <div class="kpi-card" style="grid-column: span 2;">
                    <div class="kpi-header">
                        <div class="kpi-icon">⚡</div>
                        <div class="kpi-title">Overall Equipment Effectiveness (OEE)</div>
                    </div>
                    <div class="oee-gauge" id="oeeGauge">
                        <div class="gauge-bg">
                            <div class="gauge-inner">
                                <div class="gauge-value" id="oeeValue">--</div>
                                <div class="gauge-label">OEE Score</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- MTBF -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">⏱️</div>
                        <div class="kpi-title">MTBF (Hours)</div>
                    </div>
                    <div class="kpi-value" id="mtbfValue">--</div>
                    <div class="kpi-change positive" id="mtbfChange">Above target</div>
                </div>
                
                <!-- MTTR -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">🔧</div>
                        <div class="kpi-title">MTTR (Hours)</div>
                    </div>
                    <div class="kpi-value" id="mttrValue">--</div>
                    <div class="kpi-change positive" id="mttrChange">Below target</div>
                </div>
                
                <!-- Cost Metrics -->
                <div class="kpi-card">
                    <div class="kpi-header">
                        <div class="kpi-icon">💰</div>
                        <div class="kpi-title">Avg Cost/Asset</div>
                    </div>
                    <div class="kpi-value" id="avgCost">--</div>
                    <div class="kpi-change neutral" id="costChange">$0.00</div>
                </div>
            </div>
            
            <!-- Alerts Section -->
            <div class="alerts-section">
                <h3 style="margin-bottom: 1rem;">🚨 System Alerts</h3>
                <div id="alertsContainer">
                    <div class="alert-item alert-info">
                        <span>ℹ️ Loading system alerts...</span>
                    </div>
                </div>
            </div>
        </div>
        
        <button class="refresh-btn" onclick="refreshData()" id="refreshBtn">
            🔄
        </button>
        
        <script>
            let refreshInterval;
            
            async function loadKPIData() {
                try {
                    const response = await fetch('/assets/kpis/realtime');
                    const result = await response.json();
                    
                    if (result.status === 'success') {
                        updateDashboard(result.data);
                        document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString();
                    } else {
                        console.error('Failed to load KPI data:', result);
                    }
                } catch (error) {
                    console.error('Error loading KPI data:', error);
                    showError('Failed to load KPI data');
                }
            }
            
            function updateDashboard(data) {
                // Update asset metrics
                document.getElementById('totalAssets').textContent = data.asset_metrics.total_assets;
                document.getElementById('operationalAssets').textContent = data.asset_metrics.operational;
                document.getElementById('downAssets').textContent = data.asset_metrics.down;
                document.getElementById('maintenanceDue').textContent = data.asset_metrics.maintenance_due;
                
                // Update performance KPIs
                document.getElementById('oeeValue').textContent = data.performance_kpis.overall_equipment_effectiveness + '%';
                document.getElementById('mtbfValue').textContent = data.performance_kpis.mtbf_hours.toFixed(1);
                document.getElementById('mttrValue').textContent = data.performance_kpis.mttr_hours.toFixed(1);
                
                // Update cost metrics
                document.getElementById('avgCost').textContent = '$' + data.cost_metrics.average_cost_per_asset.toFixed(2);
                
                // Update OEE gauge
                const oeeAngle = (data.performance_kpis.overall_equipment_effectiveness / 100) * 360;
                document.documentElement.style.setProperty('--oee-angle', oeeAngle + 'deg');
                
                // Update alerts
                updateAlerts(data.alerts || []);
            }
            
            function updateAlerts(alerts) {
                const alertsContainer = document.getElementById('alertsContainer');
                alertsContainer.innerHTML = '';
                
                if (alerts.length === 0 || alerts.every(alert => alert === null)) {
                    alertsContainer.innerHTML = '<div class="alert-item alert-info"><span>✅ All systems operating normally</span></div>';
                    return;
                }
                
                alerts.forEach(alert => {
                    if (alert && alert.message) {
                        const alertDiv = document.createElement('div');
                        alertDiv.className = `alert-item alert-${alert.level}`;
                        
                        const icon = alert.level === 'warning' ? '⚠️' : 'ℹ️';
                        alertDiv.innerHTML = `<span>${icon} ${alert.message}</span>`;
                        
                        alertsContainer.appendChild(alertDiv);
                    }
                });
            }
            
            function refreshData() {
                const refreshBtn = document.getElementById('refreshBtn');
                refreshBtn.classList.add('spinning');
                
                loadKPIData().finally(() => {
                    setTimeout(() => {
                        refreshBtn.classList.remove('spinning');
                    }, 1000);
                });
            }
            
            function showError(message) {
                const alertsContainer = document.getElementById('alertsContainer');
                alertsContainer.innerHTML = `<div class="alert-item alert-warning"><span>⚠️ ${message}</span></div>`;
            }
            
            // Auto-refresh every 30 seconds
            function startAutoRefresh() {
                refreshInterval = setInterval(loadKPIData, 30000);
            }
            
            function stopAutoRefresh() {
                if (refreshInterval) {
                    clearInterval(refreshInterval);
                }
            }
            
            // Initialize dashboard
            document.addEventListener('DOMContentLoaded', function() {
                loadKPIData();
                startAutoRefresh();
                
                // Stop auto-refresh when page is hidden
                document.addEventListener('visibilitychange', function() {
                    if (document.hidden) {
                        stopAutoRefresh();
                    } else {
                        startAutoRefresh();
                    }
                });
            });
            
            // Keyboard shortcuts
            document.addEventListener('keydown', function(event) {
                if (event.key === 'r' || event.key === 'R') {
                    refreshData();
                }
            });
        </script>
    </body>
    </html>
    """

# File Management Integration Endpoints
@assets_router.post("/upload")
async def upload_asset_file(
    file: UploadFile = File(...),
    asset_id: Optional[str] = None,
    description: Optional[str] = None,
    tags: Optional[str] = None
):
    """Upload file for asset"""
    from file_manager import upload_file
    return await upload_file(
        file=file,
        entity_type="asset",
        entity_id=asset_id or "new",
        description=description or "",
        tags=tags or "",
        uploaded_by="technician"
    )

@assets_router.get("/export")
async def export_assets_data(
    format: str = Query("excel", regex="^(excel|csv|pdf|json)$"),
    asset_id: Optional[str] = None,
    status: Optional[str] = None,
    asset_type: Optional[str] = None
):
    """Export assets data in various formats"""
    # Filter assets based on parameters
    filtered_data = []
    
    for asset in assets_db:
        if asset_id and asset["id"] != asset_id:
            continue
        if status and asset.get("status") != status:
            continue
        if asset_type and asset.get("type") != asset_type:
            continue
        filtered_data.append(asset)
    
    if format == "excel":
        try:
            import pandas as pd
            from io import BytesIO
            from fastapi.responses import StreamingResponse
            
            df = pd.DataFrame(filtered_data)
            output = BytesIO()
            df.to_excel(output, index=False, sheet_name="Assets")
            output.seek(0)
            
            return StreamingResponse(
                BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": "attachment; filename=assets_export.xlsx"}
            )
        except ImportError:
            raise HTTPException(status_code=400, detail="Excel export requires pandas")
    
    elif format == "csv":
        try:
            import pandas as pd
            from io import BytesIO
            from fastapi.responses import StreamingResponse
            
            df = pd.DataFrame(filtered_data)
            output = BytesIO()
            df.to_csv(output, index=False)
            output.seek(0)
            
            return StreamingResponse(
                output,
                media_type="text/csv",
                headers={"Content-Disposition": "attachment; filename=assets_export.csv"}
            )
        except ImportError:
            # Fallback CSV creation without pandas
            import csv
            from io import StringIO, BytesIO
            
            output = StringIO()
            if filtered_data:
                writer = csv.DictWriter(output, fieldnames=filtered_data[0].keys())
                writer.writeheader()
                writer.writerows(filtered_data)
            
            from fastapi.responses import StreamingResponse
            return StreamingResponse(
                BytesIO(output.getvalue().encode()),
                media_type="text/csv",
                headers={"Content-Disposition": "attachment; filename=assets_export.csv"}
            )
    
    elif format == "json":
        from fastapi.responses import JSONResponse
        return JSONResponse(
            content={"assets": filtered_data, "exported_at": datetime.now().isoformat()},
            headers={"Content-Disposition": "attachment; filename=assets_export.json"}
        )
    
    elif format == "pdf":
        raise HTTPException(status_code=501, detail="PDF export not yet implemented")

@assets_router.post("/import")
async def import_assets_data(
    file: UploadFile = File(...),
    overwrite: bool = False,
    validate_only: bool = False
):
    """Import assets data from Excel/CSV file"""
    if not file.filename or not file.filename.endswith(('.xlsx', '.xls', '.csv')):
        raise HTTPException(status_code=400, detail="Only Excel and CSV files are supported")
    
    try:
        content = await file.read()
        
        if file.filename.endswith('.csv'):
            import csv
            from io import StringIO
            
            csv_content = StringIO(content.decode('utf-8'))
            reader = csv.DictReader(csv_content)
            imported_data = list(reader)
        else:
            try:
                import pandas as pd
                from io import BytesIO
                
                df = pd.read_excel(BytesIO(content))
                imported_data = df.to_dict('records')
            except ImportError:
                raise HTTPException(status_code=400, detail="Excel import requires pandas")
        
        # Validate data
        validation_errors = []
        valid_records = []
        
        for i, record in enumerate(imported_data):
            try:
                # Basic validation
                if not record.get('name'):
                    validation_errors.append(f"Row {i+1}: Asset name is required")
                    continue
                
                if not record.get('location'):
                    record['location'] = 'Unknown'
                
                if not record.get('status'):
                    record['status'] = 'active'
                
                # Create asset object
                asset = {
                    "id": record.get('id', f"AST-IMP-{int(time.time())}-{i}"),
                    "name": record['name'],
                    "description": record.get('description', ''),
                    "location": record['location'],
                    "status": record['status'],
                    "type": record.get('type', 'Equipment'),
                    "manufacturer": record.get('manufacturer', ''),
                    "model": record.get('model', ''),
                    "serial_number": record.get('serial_number', ''),
                    "purchase_date": record.get('purchase_date', ''),
                    "warranty_expiry": record.get('warranty_expiry', ''),
                    "criticality": record.get('criticality', 'medium'),
                    "installation_date": record.get('installation_date', ''),
                    "created_date": datetime.now().isoformat(),
                    "imported": True
                }
                
                valid_records.append(asset)
                
            except Exception as e:
                validation_errors.append(f"Row {i+1}: {str(e)}")
        
        if validate_only:
            return {
                "validation_result": {
                    "total_rows": len(imported_data),
                    "valid_rows": len(valid_records),
                    "errors": validation_errors,
                    "preview": valid_records[:5]  # Show first 5 valid records
                }
            }
        
        # Import valid records
        imported_count = 0
        for asset in valid_records:
            if overwrite or not any(a["id"] == asset["id"] for a in assets_db):
                if overwrite:
                    # Remove existing record
                    assets_db[:] = [a for a in assets_db if a["id"] != asset["id"]]
                
                assets_db.append(asset)
                imported_count += 1
        
        return {
            "import_result": {
                "total_rows": len(imported_data),
                "imported_rows": imported_count,
                "skipped_rows": len(valid_records) - imported_count,
                "errors": validation_errors
            }
        }
        
    except Exception as e:
        logger.error(f"Asset import failed: {e}")
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

@assets_router.get("/files/{asset_id}")
async def get_asset_files(asset_id: str):
    """Get all files associated with an asset"""
    from file_manager import list_files
    return await list_files(entity_type="asset", entity_id=asset_id)