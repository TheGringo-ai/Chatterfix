#!/usr/bin/env python3
"""
ChatterFix CMMS - Simple Assets Module
Complete CRUD functionality for asset management
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from typing import List, Dict, Any, Optional
from datetime import datetime

router = APIRouter(prefix="/cmms/assets", tags=["assets"])

# Simple assets data
ASSETS = [
    {
        "id": "AST-001",
        "name": "Main Water Pump",
        "asset_id": "PUMP-001",
        "type": "pump",
        "location": "Plant Floor A",
        "status": "operational",
        "purchase_date": "2023-01-15",
        "warranty_expiry": "2026-01-15",
        "cost": 15000.00,
        "manufacturer": "HydroDyne Systems",
        "last_maintenance": "2025-08-15T10:00:00Z"
    },
    {
        "id": "AST-002",
        "name": "Conveyor Belt System",
        "asset_id": "CONV-001",
        "type": "conveyor",
        "location": "Production Line 1",
        "status": "operational",
        "purchase_date": "2022-06-20",
        "warranty_expiry": "2025-06-20",
        "cost": 25000.00,
        "manufacturer": "BeltTech Industries",
        "last_maintenance": "2025-09-01T14:30:00Z"
    },
    {
        "id": "AST-003",
        "name": "HVAC System Unit 1",
        "asset_id": "HVAC-001",
        "type": "hvac",
        "location": "Building A - Roof",
        "status": "maintenance_required",
        "purchase_date": "2021-03-10",
        "warranty_expiry": "2024-03-10",
        "cost": 8000.00,
        "manufacturer": "Climate Control Pro",
        "last_maintenance": "2025-07-20T09:15:00Z"
    },
    {
        "id": "AST-004",
        "name": "Backup Generator",
        "asset_id": "GEN-001",
        "type": "generator",
        "location": "Utility Building",
        "status": "standby",
        "purchase_date": "2020-11-05",
        "warranty_expiry": "2023-11-05",
        "cost": 12000.00,
        "manufacturer": "PowerMax Solutions",
        "last_maintenance": "2025-06-10T16:00:00Z"
    },
    {
        "id": "AST-005",
        "name": "Compressor Unit 2",
        "asset_id": "COMP-002",
        "type": "compressor",
        "location": "Production Line 2",
        "status": "operational",
        "purchase_date": "2023-08-30",
        "warranty_expiry": "2026-08-30",
        "cost": 18000.00,
        "manufacturer": "AirFlow Dynamics",
        "last_maintenance": "2025-08-30T11:45:00Z"
    }
]

@router.get("/dashboard")
async def assets_dashboard():
    """Live Assets management dashboard with full CRUD functionality"""
    return HTMLResponse('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Asset Management - ChatterFix CMMS</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #e74c3c 0%, #8e44ad 100%);
                min-height: 100vh;
                color: white;
                padding: 2rem;
            }
            .card { 
                background: rgba(255,255,255,0.1);
                backdrop-filter: blur(15px);
                border-radius: 20px;
                padding: 2rem;
                margin: 1rem 0;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .operational { color: #27ae60; }
            .maintenance_required { color: #e74c3c; font-weight: bold; }
            .standby { color: #f39c12; }
            .out_of_service { color: #c0392b; font-weight: bold; }
            h1 { margin-bottom: 2rem; text-align: center; }
            .asset { 
                background: rgba(255,255,255,0.05);
                border-radius: 15px;
                padding: 1.5rem;
                margin: 1rem 0;
                border-left: 4px solid #e74c3c;
                position: relative;
            }
            .asset-actions {
                position: absolute;
                top: 1rem;
                right: 1rem;
                display: flex;
                gap: 0.5rem;
            }
            .status-indicator {
                display: inline-block;
                padding: 0.3rem 0.8rem;
                border-radius: 15px;
                font-size: 0.8rem;
                font-weight: bold;
                margin-left: 1rem;
            }
            .btn {
                background: linear-gradient(135deg, #e74c3c, #c0392b);
                color: white;
                border: none;
                padding: 0.8rem 1.5rem;
                border-radius: 10px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 0.25rem;
                transition: all 0.3s ease;
                font-size: 0.9rem;
            }
            .btn:hover { transform: translateY(-2px); }
            .btn-small {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }
            .btn-warning {
                background: linear-gradient(135deg, #f39c12, #e67e22);
            }
            .btn-success {
                background: linear-gradient(135deg, #27ae60, #229954);
            }
            .btn-danger {
                background: linear-gradient(135deg, #e74c3c, #c0392b);
            }
            .btn-info {
                background: linear-gradient(135deg, #3498db, #2980b9);
            }
            .modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }
            .modal-content {
                background: rgba(44,62,80,0.95);
                backdrop-filter: blur(15px);
                margin: 5% auto;
                padding: 2rem;
                border-radius: 20px;
                width: 90%;
                max-width: 600px;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .form-group {
                margin: 1rem 0;
            }
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: bold;
            }
            .form-group input, .form-group select {
                width: 100%;
                padding: 0.8rem;
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 10px;
                background: rgba(255,255,255,0.1);
                color: white;
                font-size: 1rem;
            }
            .form-group input::placeholder {
                color: rgba(255,255,255,0.6);
            }
            .loading {
                text-align: center;
                padding: 2rem;
                font-size: 1.2rem;
            }
            .stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin: 2rem 0;
            }
            .stat-card {
                text-align: center;
                padding: 1rem;
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>🏭 Asset Management Dashboard</h1>
            
            <div style="text-align: center; margin-bottom: 2rem;">
                <button class="btn btn-success" onclick="showCreateModal()">➕ Create New Asset</button>
                <button class="btn" onclick="loadAssets()">🔄 Refresh</button>
                <a href="/cmms/dashboard/main" class="btn">← Back to Dashboard</a>
            </div>

            <div id="stats-container" class="stats">
                <div class="stat-card" style="background: rgba(231,76,60,0.2);">
                    <h3 id="total-assets">-</h3>
                    <p>Total Assets</p>
                </div>
                <div class="stat-card" style="background: rgba(39,174,96,0.2);">
                    <h3 id="operational-assets">-</h3>
                    <p>Operational</p>
                </div>
                <div class="stat-card" style="background: rgba(243,156,18,0.2);">
                    <h3 id="maintenance-required">-</h3>
                    <p>Maintenance Required</p>
                </div>
                <div class="stat-card" style="background: rgba(52,152,219,0.2);">
                    <h3 id="total-value">-</h3>
                    <p>Total Value</p>
                </div>
            </div>

            <div id="assets-container">
                <div class="loading">Loading assets...</div>
            </div>
        </div>

        <!-- Create/Edit Asset Modal -->
        <div id="asset-modal" class="modal">
            <div class="modal-content">
                <h2 id="modal-title">Create New Asset</h2>
                <form id="asset-form">
                    <div class="form-group">
                        <label for="name">Asset Name *</label>
                        <input type="text" id="name" name="name" required placeholder="Enter asset name">
                    </div>
                    <div class="form-group">
                        <label for="asset_id">Asset ID *</label>
                        <input type="text" id="asset_id" name="asset_id" required placeholder="Enter asset ID">
                    </div>
                    <div class="form-group">
                        <label for="type">Asset Type</label>
                        <select id="type" name="type">
                            <option value="pump">Pump</option>
                            <option value="conveyor">Conveyor</option>
                            <option value="hvac">HVAC</option>
                            <option value="generator">Generator</option>
                            <option value="compressor">Compressor</option>
                            <option value="motor">Motor</option>
                            <option value="valve">Valve</option>
                            <option value="electrical">Electrical</option>
                            <option value="mechanical">Mechanical</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="location">Location</label>
                        <input type="text" id="location" name="location" placeholder="Asset location">
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="operational">Operational</option>
                            <option value="maintenance_required">Maintenance Required</option>
                            <option value="standby">Standby</option>
                            <option value="out_of_service">Out of Service</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="purchase_date">Purchase Date</label>
                        <input type="date" id="purchase_date" name="purchase_date">
                    </div>
                    <div class="form-group">
                        <label for="warranty_expiry">Warranty Expiry</label>
                        <input type="date" id="warranty_expiry" name="warranty_expiry">
                    </div>
                    <div class="form-group">
                        <label for="cost">Cost</label>
                        <input type="number" id="cost" name="cost" step="0.01" min="0" value="0.00">
                    </div>
                    <div class="form-group">
                        <label for="manufacturer">Manufacturer</label>
                        <input type="text" id="manufacturer" name="manufacturer" placeholder="Manufacturer name">
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-success">💾 Save Asset</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Maintenance Modal -->
        <div id="maintenance-modal" class="modal">
            <div class="modal-content">
                <h2>Schedule Maintenance</h2>
                <form id="maintenance-form">
                    <div class="form-group">
                        <label for="maintenance-type">Maintenance Type *</label>
                        <select id="maintenance-type" name="type" required>
                            <option value="preventive">Preventive</option>
                            <option value="corrective">Corrective</option>
                            <option value="emergency">Emergency</option>
                            <option value="inspection">Inspection</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="scheduled-date">Scheduled Date</label>
                        <input type="datetime-local" id="scheduled-date" name="scheduled_date">
                    </div>
                    <div class="form-group">
                        <label for="notes">Notes</label>
                        <input type="text" id="notes" name="notes" placeholder="Maintenance notes">
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-warning">🔧 Schedule Maintenance</button>
                        <button type="button" class="btn btn-danger" onclick="closeMaintenanceModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            let currentAssets = [];
            let editingAssetId = null;
            let maintenanceAssetId = null;

            // Load assets on page load
            document.addEventListener('DOMContentLoaded', loadAssets);

            async function loadAssets() {
                try {
                    const response = await fetch('/assets-test/');
                    const data = await response.json();
                    
                    if (data.success) {
                        currentAssets = data.assets;
                        updateStats();
                        renderAssets();
                    } else {
                        showError('Failed to load assets');
                    }
                } catch (error) {
                    showError('Error loading assets: ' + error.message);
                }
            }

            function updateStats() {
                const totalAssets = currentAssets.length;
                const operational = currentAssets.filter(a => a.status === 'operational').length;
                const maintenanceRequired = currentAssets.filter(a => a.status === 'maintenance_required').length;
                const totalValue = currentAssets.reduce((sum, a) => sum + a.cost, 0);

                document.getElementById('total-assets').textContent = totalAssets;
                document.getElementById('operational-assets').textContent = operational;
                document.getElementById('maintenance-required').textContent = maintenanceRequired;
                document.getElementById('total-value').textContent = '$' + totalValue.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
            }

            function renderAssets() {
                const container = document.getElementById('assets-container');
                
                if (currentAssets.length === 0) {
                    container.innerHTML = '<div class="loading">No assets found. Create your first asset!</div>';
                    return;
                }

                container.innerHTML = currentAssets.map(asset => {
                    let statusClass, statusIndicator;
                    if (asset.status === 'operational') {
                        statusClass = 'operational';
                        statusIndicator = '<span class="status-indicator" style="background: #27ae60;">OPERATIONAL</span>';
                    } else if (asset.status === 'maintenance_required') {
                        statusClass = 'maintenance_required';
                        statusIndicator = '<span class="status-indicator" style="background: #e74c3c;">MAINTENANCE REQUIRED</span>';
                    } else if (asset.status === 'standby') {
                        statusClass = 'standby';
                        statusIndicator = '<span class="status-indicator" style="background: #f39c12;">STANDBY</span>';
                    } else {
                        statusClass = 'out_of_service';
                        statusIndicator = '<span class="status-indicator" style="background: #c0392b;">OUT OF SERVICE</span>';
                    }

                    const warrantyStatus = new Date(asset.warranty_expiry) < new Date() ? 'Expired' : 'Active';
                    const warrantyClass = warrantyStatus === 'Expired' ? 'maintenance_required' : 'operational';

                    return `
                        <div class="asset">
                            <div class="asset-actions">
                                <button class="btn btn-small btn-success" onclick="showEditModal('${asset.id}')">✏️ Edit</button>
                                <button class="btn btn-small btn-warning" onclick="showMaintenanceModal('${asset.id}')">🔧 Maintenance</button>
                                <button class="btn btn-small btn-info" onclick="updateStatus('${asset.id}')">🔄 Status</button>
                                <button class="btn btn-small btn-danger" onclick="deleteAsset('${asset.id}')">🗑️ Delete</button>
                            </div>
                            <h3>${asset.name} <span class="${statusClass}">(${asset.status.replace('_', ' ')})</span> ${statusIndicator}</h3>
                            <p><strong>ID:</strong> ${asset.id} | <strong>Asset ID:</strong> ${asset.asset_id} | <strong>Type:</strong> ${asset.type}</p>
                            <p><strong>Location:</strong> ${asset.location} | <strong>Manufacturer:</strong> ${asset.manufacturer}</p>
                            <p><strong>Cost:</strong> $${asset.cost.toFixed(2)} | <strong>Purchase Date:</strong> ${asset.purchase_date}</p>
                            <p><strong>Warranty:</strong> <span class="${warrantyClass}">${asset.warranty_expiry} (${warrantyStatus})</span> | <strong>Last Maintenance:</strong> ${asset.last_maintenance}</p>
                        </div>
                    `;
                }).join('');
            }

            function showCreateModal() {
                editingAssetId = null;
                document.getElementById('modal-title').textContent = 'Create New Asset';
                document.getElementById('asset-form').reset();
                document.getElementById('asset-modal').style.display = 'block';
            }

            async function showEditModal(assetId) {
                try {
                    const response = await fetch(`/assets-test/${assetId}`);
                    const data = await response.json();
                    
                    if (data.success) {
                        editingAssetId = assetId;
                        const asset = data.asset;
                        
                        document.getElementById('modal-title').textContent = 'Edit Asset';
                        document.getElementById('name').value = asset.name;
                        document.getElementById('asset_id').value = asset.asset_id;
                        document.getElementById('type').value = asset.type;
                        document.getElementById('location').value = asset.location;
                        document.getElementById('status').value = asset.status;
                        document.getElementById('purchase_date').value = asset.purchase_date;
                        document.getElementById('warranty_expiry').value = asset.warranty_expiry;
                        document.getElementById('cost').value = asset.cost;
                        document.getElementById('manufacturer').value = asset.manufacturer;
                        
                        document.getElementById('asset-modal').style.display = 'block';
                    } else {
                        showError('Failed to load asset details');
                    }
                } catch (error) {
                    showError('Error loading asset: ' + error.message);
                }
            }

            function showMaintenanceModal(assetId) {
                const asset = currentAssets.find(a => a.id === assetId);
                if (!asset) return;

                maintenanceAssetId = assetId;
                document.getElementById('maintenance-form').reset();
                document.getElementById('maintenance-modal').style.display = 'block';
            }

            async function updateStatus(assetId) {
                const newStatus = prompt('Enter new status (operational, maintenance_required, standby, out_of_service):');
                if (!newStatus) return;

                const validStatuses = ['operational', 'maintenance_required', 'standby', 'out_of_service'];
                if (!validStatuses.includes(newStatus)) {
                    showError('Invalid status. Must be one of: ' + validStatuses.join(', '));
                    return;
                }

                try {
                    const response = await fetch(`/assets-test/${assetId}/status`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ status: newStatus })
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadAssets();
                    } else {
                        showError(data.detail || 'Failed to update status');
                    }
                } catch (error) {
                    showError('Error updating status: ' + error.message);
                }
            }

            function closeModal() {
                document.getElementById('asset-modal').style.display = 'none';
            }

            function closeMaintenanceModal() {
                document.getElementById('maintenance-modal').style.display = 'none';
            }

            // Handle asset form submission
            document.getElementById('asset-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const assetData = Object.fromEntries(formData.entries());
                
                // Convert numeric fields
                assetData.cost = parseFloat(assetData.cost) || 0.0;

                try {
                    let response;
                    if (editingAssetId) {
                        response = await fetch(`/assets-test/${editingAssetId}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(assetData)
                        });
                    } else {
                        response = await fetch('/assets-test/', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(assetData)
                        });
                    }

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeModal();
                        loadAssets();
                    } else {
                        showError('Failed to save asset');
                    }
                } catch (error) {
                    showError('Error saving asset: ' + error.message);
                }
            });

            // Handle maintenance form submission
            document.getElementById('maintenance-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const maintenanceData = Object.fromEntries(formData.entries());

                try {
                    const response = await fetch(`/assets-test/${maintenanceAssetId}/maintenance`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(maintenanceData)
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeMaintenanceModal();
                        loadAssets();
                    } else {
                        showError(data.detail || 'Failed to schedule maintenance');
                    }
                } catch (error) {
                    showError('Error scheduling maintenance: ' + error.message);
                }
            });

            async function deleteAsset(assetId) {
                if (!confirm('Are you sure you want to delete this asset? This action cannot be undone.')) {
                    return;
                }

                try {
                    const response = await fetch(`/assets-test/${assetId}`, {
                        method: 'DELETE'
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadAssets();
                    } else {
                        showError('Failed to delete asset');
                    }
                } catch (error) {
                    showError('Error deleting asset: ' + error.message);
                }
            }

            function showSuccess(message) {
                alert('✅ ' + message);
            }

            function showError(message) {
                alert('❌ ' + message);
            }

            // Close modals when clicking outside
            window.onclick = function(event) {
                const assetModal = document.getElementById('asset-modal');
                const maintenanceModal = document.getElementById('maintenance-modal');
                
                if (event.target === assetModal) {
                    assetModal.style.display = 'none';
                }
                if (event.target === maintenanceModal) {
                    maintenanceModal.style.display = 'none';
                }
            }
        </script>
    </body>
    </html>
    ''')

@router.get("/")
async def list_assets():
    """Get all assets as JSON"""
    return {"assets": ASSETS, "count": len(ASSETS)}

@router.get("/{asset_id}")
async def get_asset(asset_id: str):
    """Get specific asset"""
    asset = next((a for a in ASSETS if a["id"] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    return asset

@router.get("/status/operational")
async def get_operational_assets():
    """Get operational assets"""
    operational = [a for a in ASSETS if a['status'] == 'operational']
    return {"operational_assets": operational, "count": len(operational)}

@router.get("/maintenance/required")
async def get_maintenance_required_assets():
    """Get assets requiring maintenance"""
    maintenance_required = [a for a in ASSETS if a['status'] == 'maintenance_required']
    return {"maintenance_required": maintenance_required, "count": len(maintenance_required)}

print("✅ Simple Assets module loaded")