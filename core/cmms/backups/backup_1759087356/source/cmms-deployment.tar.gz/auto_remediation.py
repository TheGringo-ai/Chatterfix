#!/usr/bin/env python3
"""
ChatterFix CMMS - Auto-Remediation System
Automated incident response and system healing
"""

import os
import sys
import time
import json
import shutil
import logging
import asyncio
import subprocess
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
from dataclasses import dataclass
import psutil

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class RemediationAction:
    """Definition of a remediation action"""
    name: str
    description: str
    command: str
    timeout_seconds: int = 30
    requires_sudo: bool = False
    prerequisites: List[str] = None
    success_indicators: List[str] = None
    
    def __post_init__(self):
        if self.prerequisites is None:
            self.prerequisites = []
        if self.success_indicators is None:
            self.success_indicators = []

@dataclass
class RemediationPlaybook:
    """A playbook containing multiple remediation steps"""
    name: str
    description: str
    triggers: List[str]  # Conditions that trigger this playbook
    actions: List[RemediationAction]
    max_attempts: int = 3
    cooldown_minutes: int = 5

class AutoRemediationEngine:
    """Main auto-remediation engine"""
    
    def __init__(self, ai_memory_dir: str = "ai-memory"):
        self.ai_memory_dir = Path(ai_memory_dir)
        self.sessions_dir = self.ai_memory_dir / "sessions"
        self.lessons_dir = self.ai_memory_dir / "lessons"
        
        # Ensure directories exist
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.lessons_dir.mkdir(parents=True, exist_ok=True)
        
        # Load playbooks
        self.playbooks = self._load_playbooks()
        
        # Track remediation history
        self.remediation_history = []
        
        logger.info("🔧 Auto-Remediation Engine initialized")
    
    def _load_playbooks(self) -> Dict[str, RemediationPlaybook]:
        """Load all remediation playbooks"""
        playbooks = {}
        
        # Service restart playbook
        playbooks['service_restart'] = RemediationPlaybook(
            name="Service Restart",
            description="Restart failed services automatically",
            triggers=[
                "process_not_running",
                "service_unhealthy",
                "port_not_listening"
            ],
            actions=[
                RemediationAction(
                    name="restart_chatterfix",
                    description="Restart ChatterFix CMMS service",
                    command="systemctl restart chatterfix-cmms.service",
                    timeout_seconds=60,
                    requires_sudo=True,
                    success_indicators=["service active", "port 3000 listening"]
                ),
                RemediationAction(
                    name="restart_nginx",
                    description="Restart Nginx web server",
                    command="systemctl restart nginx",
                    timeout_seconds=30,
                    requires_sudo=True,
                    success_indicators=["nginx process running", "port 80/443 listening"]
                )
            ],
            max_attempts=3,
            cooldown_minutes=5
        )
        
        # Disk cleanup playbook
        playbooks['disk_cleanup'] = RemediationPlaybook(
            name="Disk Space Cleanup",
            description="Free up disk space when running low",
            triggers=[
                "disk_usage_critical",
                "disk_usage_warning"
            ],
            actions=[
                RemediationAction(
                    name="clean_tmp",
                    description="Clean temporary files",
                    command="find /tmp -type f -atime +7 -delete",
                    timeout_seconds=60,
                    requires_sudo=True
                ),
                RemediationAction(
                    name="clean_logs",
                    description="Rotate and compress old logs",
                    command="journalctl --vacuum-time=7d",
                    timeout_seconds=120,
                    requires_sudo=True
                ),
                RemediationAction(
                    name="clean_cache",
                    description="Clean application caches",
                    command="rm -rf /tmp/chatterfix-cache/*",
                    timeout_seconds=30
                )
            ]
        )
        
        # Certificate renewal playbook
        playbooks['cert_renewal'] = RemediationPlaybook(
            name="SSL Certificate Renewal",
            description="Handle SSL certificate renewal and reload",
            triggers=[
                "cert_expiring_soon",
                "cert_expired",
                "ssl_error"
            ],
            actions=[
                RemediationAction(
                    name="renew_cert",
                    description="Renew SSL certificate using certbot",
                    command="certbot renew --quiet",
                    timeout_seconds=180,
                    requires_sudo=True,
                    success_indicators=["certificate valid", "no renewal errors"]
                ),
                RemediationAction(
                    name="reload_nginx",
                    description="Reload Nginx to use new certificate",
                    command="systemctl reload nginx",
                    timeout_seconds=30,
                    requires_sudo=True,
                    prerequisites=["renew_cert"]
                )
            ]
        )
        
        # Memory cleanup playbook
        playbooks['memory_cleanup'] = RemediationPlaybook(
            name="Memory Cleanup",
            description="Free up memory when usage is high",
            triggers=[
                "memory_usage_critical",
                "swap_usage_high"
            ],
            actions=[
                RemediationAction(
                    name="clear_page_cache",
                    description="Clear system page cache",
                    command="sync && echo 1 > /proc/sys/vm/drop_caches",
                    timeout_seconds=30,
                    requires_sudo=True
                ),
                RemediationAction(
                    name="restart_high_memory_processes",
                    description="Restart processes using excessive memory",
                    command="python3 /usr/local/bin/restart-memory-hogs.py",
                    timeout_seconds=60
                )
            ]
        )
        
        # Database maintenance playbook
        playbooks['database_maintenance'] = RemediationPlaybook(
            name="Database Maintenance",
            description="Maintain database health and performance",
            triggers=[
                "database_slow",
                "database_errors",
                "database_locks"
            ],
            actions=[
                RemediationAction(
                    name="analyze_tables",
                    description="Analyze and optimize database tables",
                    command="python3 -c \"import sqlite3; conn=sqlite3.connect('/tmp/chatterfix-health/health_metrics.db'); conn.execute('ANALYZE'); conn.close()\"",
                    timeout_seconds=60
                ),
                RemediationAction(
                    name="vacuum_database",
                    description="Vacuum database to reclaim space",
                    command="python3 -c \"import sqlite3; conn=sqlite3.connect('/tmp/chatterfix-health/health_metrics.db'); conn.execute('VACUUM'); conn.close()\"",
                    timeout_seconds=120
                )
            ]
        )
        
        return playbooks
    
    async def execute_remediation(self, trigger: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute appropriate remediation for a trigger"""
        if context is None:
            context = {}
        
        # Find matching playbooks
        matching_playbooks = [
            playbook for playbook in self.playbooks.values()
            if trigger in playbook.triggers
        ]
        
        if not matching_playbooks:
            logger.warning(f"No remediation playbook found for trigger: {trigger}")
            return {
                'success': False,
                'message': f'No remediation available for {trigger}',
                'trigger': trigger
            }
        
        results = []
        
        for playbook in matching_playbooks:
            logger.info(f"🔧 Executing remediation playbook: {playbook.name}")
            
            # Check cooldown
            if self._is_in_cooldown(playbook.name):
                logger.info(f"Playbook {playbook.name} is in cooldown, skipping")
                continue
            
            result = await self._execute_playbook(playbook, context)
            results.append(result)
            
            # Record execution
            await self._record_remediation(playbook.name, trigger, result, context)
        
        # Return summary
        successful_playbooks = [r for r in results if r['success']]
        
        return {
            'success': len(successful_playbooks) > 0,
            'trigger': trigger,
            'playbooks_executed': len(results),
            'successful_playbooks': len(successful_playbooks),
            'results': results,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
    
    async def _execute_playbook(self, playbook: RemediationPlaybook, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single remediation playbook"""
        playbook_result = {
            'playbook': playbook.name,
            'success': False,
            'actions_executed': 0,
            'actions_successful': 0,
            'actions': [],
            'start_time': datetime.now(timezone.utc).isoformat()
        }
        
        for attempt in range(playbook.max_attempts):
            if attempt > 0:
                logger.info(f"Retrying playbook {playbook.name}, attempt {attempt + 1}/{playbook.max_attempts}")
                await asyncio.sleep(10)  # Brief delay between attempts
            
            actions_successful = 0
            
            for action in playbook.actions:
                # Check prerequisites
                if not await self._check_prerequisites(action, playbook_result['actions']):
                    logger.warning(f"Prerequisites not met for action {action.name}")
                    continue
                
                logger.info(f"Executing action: {action.name}")
                action_result = await self._execute_action(action, context)
                playbook_result['actions'].append(action_result)
                playbook_result['actions_executed'] += 1
                
                if action_result['success']:
                    actions_successful += 1
                    logger.info(f"✅ Action {action.name} succeeded")
                else:
                    logger.error(f"❌ Action {action.name} failed: {action_result.get('error', 'Unknown error')}")
            
            playbook_result['actions_successful'] = actions_successful
            
            # Check if playbook succeeded
            if actions_successful == len(playbook.actions):
                playbook_result['success'] = True
                break
            elif actions_successful > 0:
                # Partial success - may retry
                logger.warning(f"Partial success for playbook {playbook.name}: {actions_successful}/{len(playbook.actions)} actions succeeded")
        
        playbook_result['end_time'] = datetime.now(timezone.utc).isoformat()
        return playbook_result
    
    async def _execute_action(self, action: RemediationAction, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single remediation action"""
        action_result = {
            'action': action.name,
            'success': False,
            'start_time': datetime.now(timezone.utc).isoformat()
        }
        
        try:
            # Prepare command
            cmd = action.command
            if context:
                # Simple template substitution
                for key, value in context.items():
                    cmd = cmd.replace(f"{{{key}}}", str(value))
            
            # Add sudo if required
            if action.requires_sudo:
                cmd = f"sudo {cmd}"
            
            logger.info(f"Executing command: {cmd}")
            
            # Execute command with interactive sudo for testing
            if action.requires_sudo and os.isatty(sys.stdin.fileno()):
                # Interactive mode - allow password prompt
                process = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    stdin=sys.stdin
                )
            else:
                # Non-interactive mode
                process = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=action.timeout_seconds
                )
                
                action_result.update({
                    'success': process.returncode == 0,
                    'return_code': process.returncode,
                    'stdout': stdout.decode('utf-8') if stdout else '',
                    'stderr': stderr.decode('utf-8') if stderr else ''
                })
                
                # Check success indicators if provided
                if action.success_indicators and action_result['success']:
                    indicators_met = await self._check_success_indicators(action.success_indicators)
                    action_result['success'] = indicators_met
                    action_result['indicators_checked'] = True
                
            except asyncio.TimeoutError:
                process.kill()
                action_result.update({
                    'success': False,
                    'error': f'Command timed out after {action.timeout_seconds} seconds',
                    'timeout': True
                })
                
        except Exception as e:
            action_result.update({
                'success': False,
                'error': str(e),
                'exception': True
            })
        
        action_result['end_time'] = datetime.now(timezone.utc).isoformat()
        return action_result
    
    async def _check_prerequisites(self, action: RemediationAction, completed_actions: List[Dict]) -> bool:
        """Check if action prerequisites are met"""
        if not action.prerequisites:
            return True
        
        completed_action_names = [a['action'] for a in completed_actions if a['success']]
        
        for prereq in action.prerequisites:
            if prereq not in completed_action_names:
                return False
        
        return True
    
    async def _check_success_indicators(self, indicators: List[str]) -> bool:
        """Check if success indicators are met"""
        for indicator in indicators:
            if "process running" in indicator:
                # Check if specific process is running
                process_name = indicator.split()[0]
                if not any(process_name in p.name() for p in psutil.process_iter()):
                    return False
            elif "port" in indicator and "listening" in indicator:
                # Check if port is listening
                import re
                port_match = re.search(r'port (\d+)', indicator)
                if port_match:
                    port = int(port_match.group(1))
                    connections = psutil.net_connections()
                    if not any(conn.laddr.port == port and conn.status == 'LISTEN' for conn in connections):
                        return False
            elif "service active" in indicator:
                # Check systemd service status
                try:
                    result = subprocess.run(['systemctl', 'is-active', 'chatterfix-cmms'], 
                                          capture_output=True, text=True)
                    if result.stdout.strip() != 'active':
                        return False
                except:
                    return False
        
        return True
    
    def _is_in_cooldown(self, playbook_name: str) -> bool:
        """Check if playbook is in cooldown period"""
        # This would check against remediation history
        # For now, implement simple time-based cooldown
        return False
    
    async def _record_remediation(self, playbook_name: str, trigger: str, result: Dict[str, Any], context: Dict[str, Any]):
        """Record remediation execution for learning"""
        timestamp = datetime.now(timezone.utc)
        
        session_record = {
            'timestamp': timestamp.isoformat(),
            'type': 'auto_remediation',
            'playbook': playbook_name,
            'trigger': trigger,
            'context': context,
            'result': result,
            'success': result['success'],
            'actions_executed': result['actions_executed'],
            'actions_successful': result['actions_successful']
        }
        
        # Store in ai-memory/sessions/
        session_file = self.sessions_dir / f"remediation_{timestamp.strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(session_file, 'w') as f:
                json.dump(session_record, f, indent=2, default=str)
            
            logger.info(f"📝 Remediation session recorded: {session_file}")
            
        except Exception as e:
            logger.error(f"Failed to record remediation session: {e}")
        
        # Add to in-memory history
        self.remediation_history.append(session_record)
        
        # Keep only recent history in memory
        if len(self.remediation_history) > 100:
            self.remediation_history = self.remediation_history[-100:]

# Specific remediation functions for common issues
class CommonRemediations:
    """Common remediation actions as standalone functions"""
    
    @staticmethod
    async def restart_service(service_name: str) -> Dict[str, Any]:
        """Restart a systemd service"""
        engine = AutoRemediationEngine()
        return await engine.execute_remediation(
            'process_not_running',
            {'service_name': service_name}
        )
    
    @staticmethod
    async def cleanup_disk_space() -> Dict[str, Any]:
        """Execute disk cleanup procedures"""
        engine = AutoRemediationEngine()
        return await engine.execute_remediation('disk_usage_critical')
    
    @staticmethod
    async def renew_ssl_certificates() -> Dict[str, Any]:
        """Renew SSL certificates and reload web server"""
        engine = AutoRemediationEngine()
        return await engine.execute_remediation('cert_expiring_soon')
    
    @staticmethod
    async def clear_memory() -> Dict[str, Any]:
        """Free up system memory"""
        engine = AutoRemediationEngine()
        return await engine.execute_remediation('memory_usage_critical')

# Global remediation engine instance
remediation_engine = AutoRemediationEngine()

async def handle_incident(incident_type: str, severity: str, details: Dict[str, Any] = None) -> Dict[str, Any]:
    """Main entry point for incident handling"""
    if details is None:
        details = {}
    
    logger.info(f"🚨 Handling incident: {incident_type} (severity: {severity})")
    
    # Map incident types to remediation triggers
    trigger_map = {
        'service_down': 'process_not_running',
        'high_cpu': 'cpu_usage_critical',
        'high_memory': 'memory_usage_critical', 
        'disk_full': 'disk_usage_critical',
        'cert_expiring': 'cert_expiring_soon',
        'database_error': 'database_errors'
    }
    
    trigger = trigger_map.get(incident_type, incident_type)
    
    # Execute remediation
    result = await remediation_engine.execute_remediation(trigger, details)
    
    # Log result
    if result['success']:
        logger.info(f"✅ Incident {incident_type} automatically resolved")
    else:
        logger.error(f"❌ Failed to automatically resolve incident {incident_type}")
    
    return result

if __name__ == "__main__":
    async def main():
        print("🔧 ChatterFix Auto-Remediation Engine Test")
        
        # Test service restart
        print("\n🔄 Testing service restart...")
        result = await CommonRemediations.restart_service('chatterfix-cmms')
        print(f"Result: {result['success']}")
        
        # Test disk cleanup
        print("\n🧹 Testing disk cleanup...")
        result = await CommonRemediations.cleanup_disk_space()
        print(f"Result: {result['success']}")
        
        print("\n✅ Auto-remediation tests complete")
    
    asyncio.run(main())