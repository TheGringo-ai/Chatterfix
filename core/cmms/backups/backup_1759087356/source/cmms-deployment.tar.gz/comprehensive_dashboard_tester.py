#!/usr/bin/env python3
"""
ChatterFix CMMS Dashboard Endpoint Comprehensive Tester
Tests all endpoints visible in the dashboard UI with realistic payloads.
"""

import os
import sys
import json
import time
import requests
from datetime import datetime
from typing import Dict, Any, List
import base64
import io

class DashboardEndpointTester:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.results = []
        self.test_data = self._create_test_data()
        self.discovered_routes = []
        
    def _create_test_data(self) -> Dict[str, Any]:
        """Create realistic test data for POST requests"""
        
        # Create a simple test image (basic JPEG header)
        jpeg_header = b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xdb'
        img_data = jpeg_header + b'\x00' * 1000  # Simple test image data
        
        # Create test audio data (simple WAV header)
        wav_header = b'RIFF\x24\x08\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00\x44\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x08\x00\x00'
        audio_data = wav_header + b'\x00' * 2048  # Simple silent audio
        
        return {
            'image_data': img_data,
            'audio_data': audio_data,
            'work_order': {
                'title': 'Test Work Order',
                'description': 'Maintenance required on conveyor belt',
                'priority': 'high',
                'asset_id': 'CONV-001',
                'location': 'Plant A'
            },
            'asset': {
                'name': 'Test Asset',
                'asset_id': 'TEST-001',
                'location': 'Test Location',
                'type': 'conveyor'
            },
            'part': {
                'name': 'Test Part',
                'part_number': 'P-TEST-001',
                'quantity': 10,
                'cost': 25.50
            }
        }

    def test_endpoint(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Test a single endpoint and return results"""
        url = f"{self.base_url}{endpoint}"
        start_time = time.time()
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(url, timeout=30, **kwargs)
            elif method.upper() == 'POST':
                response = self.session.post(url, timeout=30, **kwargs)
            elif method.upper() == 'PUT':
                response = self.session.put(url, timeout=30, **kwargs)
            elif method.upper() == 'DELETE':
                response = self.session.delete(url, timeout=30, **kwargs)
            else:
                raise ValueError(f"Unsupported method: {method}")
                
            response_time = time.time() - start_time
            
            # Try to parse JSON response
            try:
                response_data = response.json() if response.text else {}
            except:
                response_data = {"raw_response": response.text[:500]}
            
            result = {
                'endpoint': endpoint,
                'method': method.upper(),
                'url': url,
                'status_code': response.status_code,
                'response_time': round(response_time, 3),
                'success': 200 <= response.status_code < 300,
                'response_size': len(response.content),
                'headers': dict(response.headers),
                'data': response_data
            }
            
            if result['success']:
                print(f"✅ {method.upper()} {endpoint} - {response.status_code} ({response_time:.3f}s)")
            else:
                print(f"❌ {method.upper()} {endpoint} - {response.status_code} ({response_time:.3f}s)")
                print(f"   Error: {response.text[:200]}")
                
        except Exception as e:
            response_time = time.time() - start_time
            result = {
                'endpoint': endpoint,
                'method': method.upper(),
                'url': url,
                'status_code': 0,
                'response_time': round(response_time, 3),
                'success': False,
                'error': str(e),
                'response_size': 0,
                'headers': {},
                'data': {}
            }
            print(f"❌ {method.upper()} {endpoint} - ERROR: {str(e)}")
            
        self.results.append(result)
        return result

    def discover_routes(self) -> bool:
        """Discover available routes from the /api endpoint"""
        try:
            response = self.session.get(f"{self.base_url}/api", timeout=10)
            if response.status_code == 200:
                data = response.json()
                print(f"🔍 Discovered {data.get('total_routes', 0)} routes from API endpoint")
                return True
        except Exception as e:
            print(f"❌ Could not discover routes: {e}")
            
        # Fallback: try direct connection to see if service is running
        try:
            response = self.session.get(f"{self.base_url}/", timeout=10)
            print(f"📡 Service status: {response.status_code}")
            return response.status_code < 500
        except Exception as e:
            print(f"❌ Service not reachable: {e}")
            return False

    def run_dashboard_tests(self):
        """Run all dashboard endpoint tests"""
        print("🔍 Starting ChatterFix CMMS Dashboard Endpoint Tests")
        print("=" * 60)
        
        # First, check if service is running and discover routes
        if not self.discover_routes():
            print("❌ Service is not running locally. Starting local server...")
            return False
        
        # Core Dashboard Endpoints
        print("\n📊 Dashboard & KPIs")
        self.test_endpoint('GET', '/')
        self.test_endpoint('GET', '/cmms')
        self.test_endpoint('GET', '/cmms/')
        self.test_endpoint('GET', '/cmms/dashboard')
        self.test_endpoint('GET', '/cmms/dashboard/main')
        self.test_endpoint('GET', '/cmms/kpis')
        
        # Work Orders Module
        print("\n🔧 Work Orders")
        self.test_endpoint('GET', '/cmms/workorders')
        self.test_endpoint('GET', '/cmms/workorders/view')
        self.test_endpoint('POST', '/cmms/workorders', json=self.test_data['work_order'])
        self.test_endpoint('GET', '/cmms/workorders/active')
        self.test_endpoint('GET', '/cmms/workorders/completed')
        
        # Assets Module
        print("\n🏭 Assets")
        self.test_endpoint('GET', '/cmms/assets')
        self.test_endpoint('GET', '/cmms/assets/manage')
        self.test_endpoint('POST', '/cmms/assets', json=self.test_data['asset'])
        self.test_endpoint('GET', '/cmms/assets/critical')
        
        # Parts & Inventory
        print("\n📦 Parts & Inventory")
        self.test_endpoint('GET', '/cmms/parts')
        self.test_endpoint('GET', '/cmms/parts/inventory')
        self.test_endpoint('POST', '/cmms/parts', json=self.test_data['part'])
        self.test_endpoint('GET', '/cmms/parts/low-stock')
        
        # Preventive Maintenance
        print("\n🛠️ Preventive Maintenance")
        self.test_endpoint('GET', '/cmms/preventive')
        self.test_endpoint('GET', '/cmms/preventive/scheduled')
        self.test_endpoint('GET', '/cmms/preventive/overdue')
        
        # Technicians
        print("\n👥 Technicians")
        self.test_endpoint('GET', '/cmms/technicians')
        self.test_endpoint('GET', '/cmms/technicians/active')
        self.test_endpoint('GET', '/cmms/technicians/assignments')
        
        # AI Assistant Features
        print("\n🤖 AI Assistant")
        # Voice command with audio data
        files = {'audio': ('test.wav', self.test_data['audio_data'], 'audio/wav')}
        self.test_endpoint('POST', '/cmms/ai/voice-command', files=files)
        
        # Text-based AI commands
        self.test_endpoint('POST', '/cmms/ai/chat', json={'message': 'Create work order for pump maintenance'})
        self.test_endpoint('POST', '/cmms/ai/analyze', json={'description': 'Motor vibrating at high RPM'})
        
        # Quality Analysis (viral demo feature)
        print("\n🧪 Quality Analysis")
        self.test_endpoint('POST', '/erp/quality/analyze', json={'description': 'nasty cheese'})
        
        # OCR Analysis with image
        files = {'photo': ('test.jpg', self.test_data['image_data'], 'image/jpeg')}
        self.test_endpoint('POST', '/erp/quality/ocr', files=files)
        
        # Admin Features
        print("\n⚙️ Admin")
        self.test_endpoint('GET', '/cmms/admin')
        self.test_endpoint('GET', '/cmms/admin/users')
        self.test_endpoint('GET', '/cmms/admin/settings')
        
        # Photo Attachments
        print("\n📸 Photo Attachments")
        files = {'photo': ('test.jpg', self.test_data['image_data'], 'image/jpeg')}
        self.test_endpoint('POST', '/cmms/workorders/WO-123/attach-photo', files=files)
        self.test_endpoint('POST', '/cmms/assets/A-456/attach-photo', files=files)
        self.test_endpoint('POST', '/cmms/parts/P-789/attach-photo', files=files)
        
        # Export Features
        print("\n📤 Export & Reports")
        self.test_endpoint('GET', '/cmms/export')
        self.test_endpoint('GET', '/cmms/export/workorders')
        self.test_endpoint('GET', '/cmms/export/assets')
        self.test_endpoint('GET', '/cmms/export/parts')
        self.test_endpoint('GET', '/cmms/reports/dashboard')
        
        # Health & Monitoring
        print("\n❤️ Health & Monitoring")
        self.test_endpoint('GET', '/health')
        self.test_endpoint('GET', '/cmms/health')
        self.test_endpoint('GET', '/metrics')
        
        # API Documentation
        print("\n📚 API Documentation")
        self.test_endpoint('GET', '/docs')
        self.test_endpoint('GET', '/openapi.json')
        
    def generate_report(self) -> str:
        """Generate a comprehensive test report"""
        if not self.results:
            return "No tests were run."
            
        total_tests = len(self.results)
        successful_tests = sum(1 for r in self.results if r['success'])
        failed_tests = total_tests - successful_tests
        
        # Calculate response time statistics
        response_times = [r['response_time'] for r in self.results if r['success']]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        report = []
        report.append("ChatterFix CMMS Dashboard Endpoint Test Report")
        report.append("=" * 50)
        report.append(f"Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"Base URL: {self.base_url}")
        report.append(f"Total Endpoints Tested: {total_tests}")
        report.append(f"Successful: {successful_tests} ✅")
        report.append(f"Failed: {failed_tests} ❌")
        report.append(f"Success Rate: {(successful_tests/total_tests)*100:.1f}%")
        report.append(f"Average Response Time: {avg_response_time:.3f}s")
        report.append("")
        
        # Group results by status
        successful = [r for r in self.results if r['success']]
        failed = [r for r in self.results if not r['success']]
        
        if successful:
            report.append("✅ SUCCESSFUL ENDPOINTS:")
            for result in successful:
                report.append(f"  {result['method']} {result['endpoint']} - {result['status_code']} ({result['response_time']}s)")
        
        if failed:
            report.append("\n❌ FAILED ENDPOINTS:")
            for result in failed:
                error_msg = result.get('error', f"HTTP {result['status_code']}")
                report.append(f"  {result['method']} {result['endpoint']} - {error_msg}")
        
        # Response time analysis
        if response_times:
            report.append(f"\n⏱️ RESPONSE TIME ANALYSIS:")
            report.append(f"  Fastest: {min(response_times):.3f}s")
            report.append(f"  Slowest: {max(response_times):.3f}s")
            report.append(f"  Average: {avg_response_time:.3f}s")
            
            # Identify slow endpoints (>2s)
            slow_endpoints = [r for r in self.results if r['success'] and r['response_time'] > 2.0]
            if slow_endpoints:
                report.append(f"\n🐌 SLOW ENDPOINTS (>2s):")
                for result in slow_endpoints:
                    report.append(f"  {result['method']} {result['endpoint']} - {result['response_time']}s")
        
        return "\n".join(report)
    
    def save_detailed_results(self, filename: str = None):
        """Save detailed JSON results"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"dashboard_test_results_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump({
                'test_metadata': {
                    'timestamp': datetime.now().isoformat(),
                    'base_url': self.base_url,
                    'total_tests': len(self.results),
                    'successful_tests': sum(1 for r in self.results if r['success']),
                    'failed_tests': sum(1 for r in self.results if not r['success'])
                },
                'results': self.results
            }, f, indent=2)
        
        print(f"📄 Detailed results saved to: {filename}")


def main():
    """Main test runner"""
    # Use environment variable or default to localhost
    base_url = os.getenv('CMMS_BASE_URL', 'http://localhost:8000')
    
    print(f"🚀 Testing ChatterFix CMMS Dashboard")
    print(f"🌐 Base URL: {base_url}")
    print("=" * 60)
    
    tester = DashboardEndpointTester(base_url)
    
    # Try to run tests, start server if needed
    success = tester.run_dashboard_tests()
    
    if not success:
        print("\n🚀 Starting local CMMS server...")
        import subprocess
        import threading
        import time
        
        # Start the server in a separate process
        def run_server():
            os.chdir('/Users/fredtaylor/Desktop/Projects/ai-tools/core/cmms')
            subprocess.run(['python3', 'app.py'], capture_output=True)
        
        server_thread = threading.Thread(target=run_server, daemon=True)
        server_thread.start()
        
        # Wait a bit for server to start
        print("⏳ Waiting for server to start...")
        time.sleep(5)
        
        # Try again
        tester.run_dashboard_tests()
    
    # Generate and display report
    if tester.results:
        print("\n" + "=" * 60)
        report = tester.generate_report()
        print(report)
        
        # Save detailed results
        tester.save_detailed_results()
        
        # Exit with appropriate code
        failed_tests = sum(1 for r in tester.results if not r['success'])
        sys.exit(1 if failed_tests > 0 else 0)
    else:
        print("\n❌ No tests were run. Please start the CMMS server manually:")
        print("cd /Users/fredtaylor/Desktop/Projects/ai-tools/core/cmms")
        print("python3 app.py")
        sys.exit(1)


if __name__ == '__main__':
    main()