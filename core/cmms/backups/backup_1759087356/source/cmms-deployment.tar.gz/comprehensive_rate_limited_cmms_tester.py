#!/usr/bin/env python3
"""
Comprehensive Rate-Limited CMMS Tester
Advanced testing suite with proper rate limiting, circuit breaker patterns, and detailed validation
Designed to prevent service crashes while providing thorough system validation
"""

import os
import sys
import json
import requests
import time
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import statistics
import traceback
from collections import defaultdict, deque
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class EndpointStatus(Enum):
    """Circuit breaker states for endpoints"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    FAILED = "failed"
    CIRCUIT_OPEN = "circuit_open"

class TestResult(Enum):
    """Test result states"""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    TIMEOUT = "timeout"
    RATE_LIMITED = "rate_limited"

@dataclass
class RateLimit:
    """Rate limiting configuration"""
    requests_per_second: float
    burst_limit: int
    window_seconds: int = 60

@dataclass
class CircuitBreaker:
    """Circuit breaker for endpoint protection"""
    failure_threshold: int = 3
    reset_timeout: int = 30
    failure_count: int = 0
    last_failure: Optional[datetime] = None
    status: EndpointStatus = EndpointStatus.HEALTHY

@dataclass
class TestMetrics:
    """Individual test metrics"""
    endpoint: str
    method: str
    status_code: Optional[int]
    response_time: float
    result: TestResult
    error_message: Optional[str] = None
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

class RateLimitedCMMSTester:
    """Comprehensive CMMS tester with advanced rate limiting and circuit breaker patterns"""
    
    def __init__(self, base_url: str = "http://localhost:8888"):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.timeout = 30  # 30 second timeout
        
        # Rate limiting configuration
        self.rate_limits = {
            # AI endpoints - most conservative (every 2 seconds)
            "ai": RateLimit(requests_per_second=0.5, burst_limit=2, window_seconds=60),
            # Admin endpoints - moderate (every 1 second)
            "admin": RateLimit(requests_per_second=1.0, burst_limit=5, window_seconds=60),
            # Basic endpoints - more permissive (2 requests per second)
            "basic": RateLimit(requests_per_second=2.0, burst_limit=10, window_seconds=60)
        }
        
        # Circuit breakers for each endpoint
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}
        
        # Request tracking for rate limiting
        self.request_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        
        # Test results
        self.test_results = {
            "timestamp": datetime.now().isoformat(),
            "base_url": base_url,
            "application_type": "ChatterFix CMMS v3.0.0",
            "test_summary": {},
            "endpoint_tests": {},
            "performance_metrics": {},
            "rate_limiting_stats": {},
            "circuit_breaker_status": {},
            "recommendations": [],
            "overall_health": "unknown"
        }
        
        # Define comprehensive test endpoints
        self.endpoints = {
            # Basic endpoints
            "root": {"path": "/", "method": "GET", "category": "basic", "expected": 200, "timeout": 10},
            "health": {"path": "/health", "method": "GET", "category": "basic", "expected": 200, "timeout": 5},
            "docs": {"path": "/docs", "method": "GET", "category": "basic", "expected": 200, "timeout": 10},
            
            # Admin endpoints
            "admin_dashboard": {"path": "/admin/dashboard", "method": "GET", "category": "admin", "expected": 200, "timeout": 15},
            "admin_users": {"path": "/admin/users", "method": "GET", "category": "admin", "expected": 200, "timeout": 10},
            "admin_stats": {"path": "/admin/stats", "method": "GET", "category": "admin", "expected": 200, "timeout": 10},
            "admin_config": {"path": "/admin/config", "method": "GET", "category": "admin", "expected": 200, "timeout": 10},
            "admin_backup": {"path": "/admin/backup", "method": "POST", "category": "admin", "expected": 200, "timeout": 30},
            "admin_logs": {"path": "/admin/logs", "method": "GET", "category": "admin", "expected": 200, "timeout": 15},
            
            # AI endpoints
            "ai_health": {"path": "/ai/health", "method": "GET", "category": "ai", "expected": 200, "timeout": 10},
            "ai_dashboard": {"path": "/ai/dashboard", "method": "GET", "category": "ai", "expected": 200, "timeout": 15},
            "ai_chat": {"path": "/ai/chat", "method": "POST", "category": "ai", "expected": 200, "timeout": 30,
                       "payload": {"message": "Test maintenance query", "context": "general"}}
        }
        
        print(f"🚀 Initialized Comprehensive CMMS Tester")
        print(f"📍 Target: {base_url}")
        print(f"⚖️ Rate Limits: AI=0.5/s, Admin=1/s, Basic=2/s")
        print(f"🔄 Circuit Breakers: 3 failures trigger 30s timeout")
        print(f"📊 Testing {len(self.endpoints)} endpoints")
    
    def get_circuit_breaker(self, endpoint: str) -> CircuitBreaker:
        """Get or create circuit breaker for endpoint"""
        if endpoint not in self.circuit_breakers:
            self.circuit_breakers[endpoint] = CircuitBreaker()
        return self.circuit_breakers[endpoint]
    
    def should_allow_request(self, endpoint: str, category: str) -> Tuple[bool, str]:
        """Check if request should be allowed based on rate limits and circuit breaker"""
        # Check circuit breaker
        cb = self.get_circuit_breaker(endpoint)
        
        if cb.status == EndpointStatus.CIRCUIT_OPEN:
            if cb.last_failure and (datetime.now() - cb.last_failure).total_seconds() > cb.reset_timeout:
                cb.status = EndpointStatus.HEALTHY
                cb.failure_count = 0
                logger.info(f"🔄 Circuit breaker reset for {endpoint}")
            else:
                return False, f"Circuit breaker open for {endpoint}"
        
        # Check rate limiting
        rate_limit = self.rate_limits[category]
        now = time.time()
        history = self.request_history[category]
        
        # Remove old requests outside window
        while history and (now - history[0]) > rate_limit.window_seconds:
            history.popleft()
        
        # Check if we can make request
        if len(history) >= rate_limit.burst_limit:
            return False, f"Rate limit exceeded for {category} category"
        
        # Check requests per second
        recent_requests = sum(1 for t in history if (now - t) <= 1.0)
        if recent_requests >= rate_limit.requests_per_second:
            return False, f"Rate limit: {recent_requests}/s exceeds {rate_limit.requests_per_second}/s"
        
        return True, "OK"
    
    def record_request(self, category: str):
        """Record request timestamp for rate limiting"""
        self.request_history[category].append(time.time())
    
    def record_success(self, endpoint: str):
        """Record successful request"""
        cb = self.get_circuit_breaker(endpoint)
        if cb.status in [EndpointStatus.DEGRADED, EndpointStatus.HEALTHY]:
            cb.status = EndpointStatus.HEALTHY
            cb.failure_count = max(0, cb.failure_count - 1)
    
    def record_failure(self, endpoint: str, error: str):
        """Record failed request"""
        cb = self.get_circuit_breaker(endpoint)
        cb.failure_count += 1
        cb.last_failure = datetime.now()
        
        if cb.failure_count >= cb.failure_threshold:
            cb.status = EndpointStatus.CIRCUIT_OPEN
            logger.warning(f"⚠️ Circuit breaker opened for {endpoint} after {cb.failure_count} failures")
        elif cb.failure_count >= 2:
            cb.status = EndpointStatus.DEGRADED
            logger.warning(f"⚠️ Endpoint {endpoint} degraded ({cb.failure_count} failures)")
    
    def wait_for_rate_limit(self, category: str):
        """Wait appropriate time for rate limiting"""
        rate_limit = self.rate_limits[category]
        wait_time = 1.0 / rate_limit.requests_per_second
        
        # Add small jitter to prevent thundering herd
        jitter = (time.time() % 1.0) * 0.1
        actual_wait = wait_time + jitter
        
        logger.debug(f"⏳ Waiting {actual_wait:.2f}s for {category} rate limit")
        time.sleep(actual_wait)
    
    def test_endpoint(self, name: str, config: Dict[str, Any]) -> TestMetrics:
        """Test individual endpoint with rate limiting and circuit breaker"""
        start_time = time.time()
        
        # Check if request is allowed
        allowed, reason = self.should_allow_request(name, config["category"])
        if not allowed:
            logger.warning(f"🚫 Request blocked for {name}: {reason}")
            return TestMetrics(
                endpoint=config["path"],
                method=config["method"],
                status_code=None,
                response_time=0,
                result=TestResult.RATE_LIMITED,
                error_message=reason
            )
        
        # Record request
        self.record_request(config["category"])
        
        try:
            # Make request
            url = f"{self.base_url}{config['path']}"
            timeout = config.get("timeout", 30)
            
            if config["method"] == "GET":
                response = self.session.get(url, timeout=timeout)
            elif config["method"] == "POST":
                payload = config.get("payload", {})
                response = self.session.post(url, json=payload, timeout=timeout)
            else:
                raise ValueError(f"Unsupported method: {config['method']}")
            
            response_time = time.time() - start_time
            
            # Determine result
            expected_status = config.get("expected", 200)
            if response.status_code == expected_status:
                result = TestResult.SUCCESS
                self.record_success(name)
                logger.info(f"✅ {name}: {response.status_code} in {response_time:.2f}s")
            else:
                result = TestResult.PARTIAL
                self.record_failure(name, f"Unexpected status: {response.status_code}")
                logger.warning(f"⚠️ {name}: {response.status_code} (expected {expected_status}) in {response_time:.2f}s")
            
            return TestMetrics(
                endpoint=config["path"],
                method=config["method"],
                status_code=response.status_code,
                response_time=response_time,
                result=result
            )
            
        except requests.exceptions.Timeout:
            response_time = time.time() - start_time
            self.record_failure(name, "Timeout")
            logger.error(f"⏰ {name}: Timeout after {response_time:.2f}s")
            return TestMetrics(
                endpoint=config["path"],
                method=config["method"],
                status_code=None,
                response_time=response_time,
                result=TestResult.TIMEOUT,
                error_message="Request timeout"
            )
            
        except Exception as e:
            response_time = time.time() - start_time
            error_msg = str(e)
            self.record_failure(name, error_msg)
            logger.error(f"❌ {name}: {error_msg} in {response_time:.2f}s")
            return TestMetrics(
                endpoint=config["path"],
                method=config["method"],
                status_code=None,
                response_time=response_time,
                result=TestResult.FAILED,
                error_message=error_msg
            )
    
    def run_comprehensive_tests(self) -> Dict[str, Any]:
        """Run all endpoint tests with proper rate limiting"""
        print("\n" + "="*80)
        print("🧪 STARTING COMPREHENSIVE CMMS TESTING")
        print("="*80)
        
        all_metrics = []
        test_start = time.time()
        
        # Group endpoints by category for better rate limiting
        categories = defaultdict(list)
        for name, config in self.endpoints.items():
            categories[config["category"]].append((name, config))
        
        # Test each category with appropriate pacing
        for category, endpoints in categories.items():
            print(f"\n📂 Testing {category.upper()} endpoints ({len(endpoints)} tests)")
            print("-" * 50)
            
            for name, config in endpoints:
                # Wait for rate limit
                self.wait_for_rate_limit(category)
                
                # Run test
                metrics = self.test_endpoint(name, config)
                all_metrics.append(metrics)
                
                # Store in results
                self.test_results["endpoint_tests"][name] = asdict(metrics)
        
        total_time = time.time() - test_start
        
        # Analyze results
        self.analyze_results(all_metrics, total_time)
        
        return self.test_results
    
    def analyze_results(self, metrics: List[TestMetrics], total_time: float):
        """Analyze test results and generate insights"""
        print(f"\n📊 ANALYSIS RESULTS")
        print("="*50)
        
        # Basic statistics
        total_tests = len(metrics)
        successful = sum(1 for m in metrics if m.result == TestResult.SUCCESS)
        partial = sum(1 for m in metrics if m.result == TestResult.PARTIAL)
        failed = sum(1 for m in metrics if m.result == TestResult.FAILED)
        timeouts = sum(1 for m in metrics if m.result == TestResult.TIMEOUT)
        rate_limited = sum(1 for m in metrics if m.result == TestResult.RATE_LIMITED)
        
        success_rate = (successful / total_tests) * 100 if total_tests > 0 else 0
        
        print(f"📈 Success Rate: {success_rate:.1f}% ({successful}/{total_tests})")
        print(f"⚡ Total Time: {total_time:.2f}s")
        print(f"⚖️ Rate Limited: {rate_limited}")
        print(f"⏰ Timeouts: {timeouts}")
        print(f"❌ Failures: {failed}")
        
        # Performance analysis
        successful_metrics = [m for m in metrics if m.result == TestResult.SUCCESS and m.response_time > 0]
        if successful_metrics:
            response_times = [m.response_time for m in successful_metrics]
            avg_response = statistics.mean(response_times)
            median_response = statistics.median(response_times)
            max_response = max(response_times)
            
            print(f"\n⏱️ Performance Metrics:")
            print(f"   Average Response: {avg_response:.3f}s")
            print(f"   Median Response: {median_response:.3f}s")
            print(f"   Max Response: {max_response:.3f}s")
            
            self.test_results["performance_metrics"] = {
                "average_response_time": avg_response,
                "median_response_time": median_response,
                "max_response_time": max_response,
                "total_successful_requests": len(successful_metrics)
            }
        
        # Circuit breaker status
        print(f"\n🔄 Circuit Breaker Status:")
        cb_healthy = 0
        cb_degraded = 0
        cb_failed = 0
        cb_open = 0
        
        for endpoint, cb in self.circuit_breakers.items():
            status_symbol = {
                EndpointStatus.HEALTHY: "✅",
                EndpointStatus.DEGRADED: "⚠️",
                EndpointStatus.FAILED: "❌",
                EndpointStatus.CIRCUIT_OPEN: "🔴"
            }.get(cb.status, "❓")
            
            print(f"   {status_symbol} {endpoint}: {cb.status.value} (failures: {cb.failure_count})")
            
            if cb.status == EndpointStatus.HEALTHY:
                cb_healthy += 1
            elif cb.status == EndpointStatus.DEGRADED:
                cb_degraded += 1
            elif cb.status == EndpointStatus.FAILED:
                cb_failed += 1
            elif cb.status == EndpointStatus.CIRCUIT_OPEN:
                cb_open += 1
        
        self.test_results["circuit_breaker_status"] = {
            "healthy": cb_healthy,
            "degraded": cb_degraded,
            "failed": cb_failed,
            "circuit_open": cb_open
        }
        
        # Rate limiting statistics
        print(f"\n⚖️ Rate Limiting Statistics:")
        for category, history in self.request_history.items():
            rate_limit = self.rate_limits[category]
            print(f"   {category.capitalize()}: {len(history)} requests (limit: {rate_limit.requests_per_second}/s)")
        
        self.test_results["rate_limiting_stats"] = {
            category: len(history) for category, history in self.request_history.items()
        }
        
        # Generate recommendations
        recommendations = []
        
        if success_rate < 80:
            recommendations.append("🚨 Low success rate - investigate failing endpoints")
        
        if timeouts > 0:
            recommendations.append(f"⏰ {timeouts} endpoints timed out - consider increasing timeout values")
        
        if cb_open > 0:
            recommendations.append(f"🔴 {cb_open} endpoints have circuit breakers open - investigate persistent failures")
        
        if cb_degraded > 0:
            recommendations.append(f"⚠️ {cb_degraded} endpoints degraded - monitor for stability")
        
        if rate_limited > total_tests * 0.1:
            recommendations.append("⚖️ High rate limiting - consider adjusting limits or request patterns")
        
        if successful_metrics:
            avg_response = statistics.mean([m.response_time for m in successful_metrics])
            if avg_response > 5.0:
                recommendations.append(f"🐌 Slow average response time ({avg_response:.2f}s) - optimize performance")
        
        if success_rate >= 90:
            recommendations.append("✅ Excellent system health - all systems operational")
        elif success_rate >= 80:
            recommendations.append("✅ Good system health - minor issues detected")
        elif success_rate >= 70:
            recommendations.append("⚠️ Moderate system health - several issues need attention")
        else:
            recommendations.append("🚨 Poor system health - immediate attention required")
        
        self.test_results["recommendations"] = recommendations
        
        # Overall health assessment
        if success_rate >= 90 and cb_open == 0:
            overall_health = "excellent"
        elif success_rate >= 80 and cb_open <= 1:
            overall_health = "good"
        elif success_rate >= 70:
            overall_health = "moderate"
        else:
            overall_health = "poor"
        
        self.test_results["overall_health"] = overall_health
        
        # Summary
        self.test_results["test_summary"] = {
            "total_tests": total_tests,
            "successful": successful,
            "partial": partial,
            "failed": failed,
            "timeouts": timeouts,
            "rate_limited": rate_limited,
            "success_rate": success_rate,
            "total_time": total_time
        }
        
        print(f"\n🏥 Overall Health: {overall_health.upper()}")
        print(f"\n💡 Recommendations:")
        for rec in recommendations:
            print(f"   {rec}")
    
    def save_results(self, filename: Optional[str] = None):
        """Save test results to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"cmms_test_results_{timestamp}.json"
        
        with open(filename, 'w') as f:
            # Convert datetime objects to strings for JSON serialization
            results_copy = json.loads(json.dumps(self.test_results, default=str))
            json.dump(results_copy, f, indent=2, default=str)
        
        print(f"\n💾 Results saved to: {filename}")
        return filename
    
    def generate_report(self, filename: Optional[str] = None):
        """Generate comprehensive markdown report"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"cmms_test_report_{timestamp}.md"
        
        summary = self.test_results["test_summary"]
        performance = self.test_results.get("performance_metrics", {})
        cb_status = self.test_results["circuit_breaker_status"]
        recommendations = self.test_results["recommendations"]
        
        report = f"""# ChatterFix CMMS Comprehensive Test Report
*Generated: {self.test_results["timestamp"]}*

## Executive Summary
- **Overall Health**: {self.test_results["overall_health"].upper()}
- **Success Rate**: {summary.get("success_rate", 0):.1f}% ({summary.get("successful", 0)}/{summary.get("total_tests", 0)} tests)
- **Total Test Time**: {summary.get("total_time", 0):.2f} seconds
- **Target System**: {self.test_results["base_url"]}

## Test Results Breakdown

### Success Metrics
- ✅ **Successful**: {summary.get("successful", 0)}
- ⚠️ **Partial Success**: {summary.get("partial", 0)}
- ❌ **Failed**: {summary.get("failed", 0)}
- ⏰ **Timeouts**: {summary.get("timeouts", 0)}
- ⚖️ **Rate Limited**: {summary.get("rate_limited", 0)}

### Performance Metrics
"""
        if performance:
            report += f"""- **Average Response Time**: {performance.get("average_response_time", 0):.3f}s
- **Median Response Time**: {performance.get("median_response_time", 0):.3f}s
- **Maximum Response Time**: {performance.get("max_response_time", 0):.3f}s
"""
        else:
            report += "- *No performance data available*\n"
        
        report += f"""
### Circuit Breaker Status
- 🟢 **Healthy Endpoints**: {cb_status.get("healthy", 0)}
- 🟡 **Degraded Endpoints**: {cb_status.get("degraded", 0)}
- 🔴 **Failed Endpoints**: {cb_status.get("failed", 0)}
- ⭕ **Circuit Open**: {cb_status.get("circuit_open", 0)}

### Endpoint Test Details
| Endpoint | Method | Status | Response Time | Result |
|----------|--------|--------|---------------|--------|
"""
        
        for name, result in self.test_results["endpoint_tests"].items():
            status_code = result.get("status_code", "N/A")
            response_time = result.get("response_time", 0)
            test_result = result.get("result", "unknown")
            
            result_icon = {
                "success": "✅",
                "partial": "⚠️",
                "failed": "❌",
                "timeout": "⏰",
                "rate_limited": "⚖️"
            }.get(test_result, "❓")
            
            report += f"| {result['endpoint']} | {result['method']} | {status_code} | {response_time:.3f}s | {result_icon} {test_result} |\n"
        
        report += f"""
## Recommendations
"""
        for rec in recommendations:
            report += f"- {rec}\n"
        
        report += f"""
## Rate Limiting Configuration
- **AI Endpoints**: 0.5 requests/second (every 2 seconds)
- **Admin Endpoints**: 1.0 requests/second (every 1 second)  
- **Basic Endpoints**: 2.0 requests/second (every 0.5 seconds)

## Circuit Breaker Configuration
- **Failure Threshold**: 3 failures trigger circuit open
- **Reset Timeout**: 30 seconds
- **States**: Healthy → Degraded → Failed → Circuit Open

---
*Report generated by ChatterFix CMMS Comprehensive Tester v1.0*
"""
        
        with open(filename, 'w') as f:
            f.write(report)
        
        print(f"📄 Report saved to: {filename}")
        return filename

def main():
    """Main execution function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Comprehensive CMMS Tester")
    parser.add_argument("--url", default="http://localhost:8888", 
                       help="Base URL for CMMS system (default: http://localhost:8888)")
    parser.add_argument("--output-dir", default=".", 
                       help="Output directory for results (default: current directory)")
    parser.add_argument("--verbose", action="store_true", 
                       help="Enable verbose logging")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Change to output directory
    if args.output_dir != ".":
        os.makedirs(args.output_dir, exist_ok=True)
        os.chdir(args.output_dir)
    
    try:
        # Create and run tester
        tester = RateLimitedCMMSTester(args.url)
        results = tester.run_comprehensive_tests()
        
        # Save results and generate reports
        json_file = tester.save_results()
        report_file = tester.generate_report()
        
        print(f"\n🎉 Testing completed successfully!")
        print(f"📊 Results: {json_file}")
        print(f"📄 Report: {report_file}")
        
        # Exit with appropriate code
        overall_health = results["overall_health"]
        if overall_health in ["excellent", "good"]:
            sys.exit(0)
        elif overall_health == "moderate":
            sys.exit(1)
        else:
            sys.exit(2)
    
    except KeyboardInterrupt:
        print("\n🛑 Testing interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n💥 Testing failed with error: {e}")
        if args.verbose:
            traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()