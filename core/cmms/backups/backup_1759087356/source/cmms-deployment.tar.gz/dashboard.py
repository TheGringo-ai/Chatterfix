#!/usr/bin/env python3
"""
CMMS Dashboard Module
Provides main dashboard functionality and overview statistics
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse
from datetime import datetime
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Dashboard router
dashboard_router = APIRouter(prefix="/dashboard", tags=["dashboard"])

from fastapi import Request

@dashboard_router.get("/main")
async def main_dashboard(request: Request):
    """Main system dashboard (HTML) or JSON stats when format=json."""
    fmt = request.query_params.get("format")
    if fmt == "json":
        # Placeholder dynamic stats - later wire to real data sources
        return {
            "stats": {
                "work_orders": 24,
                "assets": 47,
                "health": 98
            },
            "timestamp": datetime.utcnow().isoformat()
        }

    nav_html = get_navigation_html("dashboard")
    nav_styles = get_navigation_styles()
    nav_js = get_navigation_javascript()
    base_styles = get_base_styles()
    return HTMLResponse(f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - Main Dashboard</title>
        <link rel="stylesheet" href="/static/css/cmms-professional.css">
        <link rel="stylesheet" href="/static/css/enhanced-ui.css">
        <style>
            {base_styles}
            {nav_styles}
            
            /* Dashboard Content */
            .header {{ 
                padding: 3rem 2rem 2rem;
                text-align: center;
            }}
            .header h1 {{ 
                font-size: 3rem; 
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }}
            .stats-grid {{ 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                gap: 2rem; 
                margin-bottom: 3rem;
            }}
            .stat-card {{ 
                background: rgba(255,255,255,0.15); 
                border-radius: 15px; 
                padding: 2rem; 
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                text-align: center;
                transition: transform 0.3s ease;
            }}
            .stat-card:hover {{
                transform: translateY(-5px);
            }}
            .stat-value {{
                font-size: 3rem;
                font-weight: bold;
                color: #38ef7d;
                display: block;
                margin-bottom: 0.5rem;
            }}
            .stat-label {{
                color: rgba(255,255,255,0.8);
                font-size: 1.1rem;
            }}
            
            .charts-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 2rem;
                margin-top: 2rem;
            }}
            .chart-card {{
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }}
            .chart-title {{
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            }}
            
            /* Interactive Elements */
            .action-btn {{
                background: rgba(56,239,125,0.2);
                border: 1px solid rgba(56,239,125,0.4);
                color: white;
                padding: 0.8rem 1.2rem;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease;
                font-size: 0.9rem;
                font-weight: 500;
            }}
            .action-btn:hover {{
                background: rgba(56,239,125,0.4);
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(56,239,125,0.3);
            }}
            .clickable-stat {{
                cursor: pointer;
                transition: all 0.3s ease;
            }}
            .clickable-stat:hover {{
                background: rgba(255,255,255,0.25);
                transform: scale(1.02);
            }}
            .loading {{
                animation: pulse 1.5s infinite;
            }}
        </style>
    </head>
    <body>
        {nav_html}
        
        <!-- Header -->
        <div class="header">
            <h1>📊 System Dashboard</h1>
            <p>Comprehensive CMMS Overview & Key Performance Indicators</p>
        </div>
        
        <!-- Main Content -->
        <div class="container">
            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value">24</span>
                    <span class="stat-label">Active Work Orders</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">47</span>
                    <span class="stat-label">Assets Monitored</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">3</span>
                    <span class="stat-label">Critical Alerts</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">95%</span>
                    <span class="stat-label">System Health</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">12</span>
                    <span class="stat-label">Technicians Online</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">$2.4K</span>
                    <span class="stat-label">Parts Inventory</span>
                </div>
            </div>
            
            <!-- Interactive Action Cards -->
            <div class="charts-grid">
                <div class="chart-card">
                    <h3 class="chart-title">🚀 Quick Actions</h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; padding: 1rem;">
                        <button class="action-btn" onclick="window.location.href='/cmms/workorders/dashboard'">
                            📋 View Work Orders
                        </button>
                        <button class="action-btn" onclick="window.location.href='/cmms/assets/dashboard'">
                            ⚙️ Manage Assets
                        </button>
                        <button class="action-btn" onclick="window.location.href='/cmms/parts/dashboard'">
                            🔧 Parts Inventory
                        </button>
                        <button class="action-btn" onclick="exportDashboard()">
                            📊 Export Data
                        </button>
                    </div>
                </div>
                <div class="chart-card">
                    <h3 class="chart-title">🤖 AI Assistant</h3>
                    <div style="padding: 1rem;">
                        <input type="text" id="ai-input" placeholder="Ask AI: 'What's the system health?' or 'Generate pump maintenance'" 
                               style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.3); 
                                      background: rgba(255,255,255,0.1); color: white; margin-bottom: 1rem;">
                        <button class="action-btn" onclick="queryAI()" style="width: 100%;">
                            💬 Ask AI (2.29s response)
                        </button>
                        <div id="ai-response" style="margin-top: 1rem; padding: 1rem; background: rgba(56,239,125,0.1); 
                                                  border-radius: 8px; min-height: 80px; display: none;">
                            <div class="loading" id="ai-loading" style="display: none;">🤖 Thinking...</div>
                            <div id="ai-content"></div>
                        </div>
                    </div>
                </div>
                <div class="chart-card">
                    <h3 class="chart-title">📊 Work Order Trends</h3>
                    <div style="padding: 1rem;">
                        <canvas id="workOrderChart" width="400" height="200"></canvas>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
                            <button class="action-btn" onclick="updateChart('weekly')">
                                📅 Weekly View
                            </button>
                            <button class="action-btn" onclick="updateChart('monthly')">
                                📊 Monthly View
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            {nav_js}
            
            // AI Chat functionality
            async function queryAI() {{
                const input = document.getElementById('ai-input');
                const response = document.getElementById('ai-response');
                const loading = document.getElementById('ai-loading');
                const content = document.getElementById('ai-content');
                
                if (!input.value.trim()) {{
                    alert('Please enter a question for the AI');
                    return;
                }}
                
                // Show loading
                response.style.display = 'block';
                loading.style.display = 'block';
                content.innerHTML = '';
                
                try {{
                    const res = await fetch('/api/ai/generate', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{
                            message: input.value,
                            context: 'diagnostic',
                            max_tokens: 100
                        }})
                    }});
                    
                    if (res.ok) {{
                        const data = await res.json();
                        content.innerHTML = `<strong>🤖 AI Response:</strong><br>${{data.response || data.content || 'AI response received'}}`;
                    }} else {{
                        throw new Error('AI service unavailable');
                    }}
                }} catch (error) {{
                    content.innerHTML = `<strong>⚠️ Demo Mode:</strong><br>AI Analysis: Your query "${{input.value}}" would typically trigger our 2.29s LLaMA response for diagnostic insights, maintenance recommendations, and safety protocols.`;
                }}
                
                loading.style.display = 'none';
                input.value = '';
            }}
            
            // Export functionality
            function exportDashboard() {{
                const data = {{
                    timestamp: new Date().toISOString(),
                    kpis: {{
                        work_orders: 24,
                        assets: 47,
                        alerts: 3,
                        health: 95,
                        technicians: 12,
                        inventory_value: 2400
                    }},
                    export_type: 'dashboard_summary'
                }};
                
                const blob = new Blob([JSON.stringify(data, null, 2)], {{type: 'application/json'}});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `cmms-dashboard-${{new Date().toISOString().split('T')[0]}}.json`;
                a.click();
                URL.revokeObjectURL(url);
                
                // Show success notification
                showNotification('📊 Dashboard data exported successfully!');
            }}
            
            // Make stats clickable
            document.addEventListener('DOMContentLoaded', function() {{
                const statCards = document.querySelectorAll('.stat-card');
                statCards.forEach(card => {{
                    card.classList.add('clickable-stat');
                    card.addEventListener('click', function() {{
                        const label = this.querySelector('.stat-label').textContent;
                        if (label.includes('Work Orders')) {{
                            window.location.href = '/cmms/workorders/dashboard';
                        }} else if (label.includes('Assets')) {{
                            window.location.href = '/cmms/assets/dashboard';
                        }} else if (label.includes('Alerts')) {{
                            showNotification('🚨 Critical alerts: Pump-003 vibration, Conveyor-001 alignment, Quality batch #456');
                        }} else if (label.includes('Health')) {{
                            showNotification('✅ System Health: 95% - All major systems operational');
                        }} else if (label.includes('Technicians')) {{
                            window.location.href = '/cmms/technicians/portal';
                        }} else if (label.includes('Parts')) {{
                            window.location.href = '/cmms/parts/dashboard';
                        }}
                    }});
                }});
                
                // Enter key support for AI input
                document.getElementById('ai-input').addEventListener('keypress', function(e) {{
                    if (e.key === 'Enter') {{
                        queryAI();
                    }}
                }});
                
                // Initialize Work Order Trends Chart
                initWorkOrderChart();
            }});
            
            // Work Order Chart functionality
            let workOrderChart = null;
            
            function initWorkOrderChart() {{
                const ctx = document.getElementById('workOrderChart').getContext('2d');
                
                workOrderChart = new Chart(ctx, {{
                    type: 'line',
                    data: {{
                        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                        datasets: [{{
                            label: 'Work Orders Created',
                            data: [12, 8, 15, 6, 9, 3, 2],
                            borderColor: '#3498db',
                            backgroundColor: 'rgba(52, 152, 219, 0.1)',
                            tension: 0.4,
                            fill: true
                        }}, {{
                            label: 'Work Orders Completed',
                            data: [10, 12, 8, 11, 7, 5, 4],
                            borderColor: '#38ef7d',
                            backgroundColor: 'rgba(56, 239, 125, 0.1)',
                            tension: 0.4,
                            fill: true
                        }}]
                    }},
                    options: {{
                        responsive: true,
                        plugins: {{
                            title: {{
                                display: true,
                                text: 'This Week - Work Order Activity'
                            }},
                            legend: {{
                                labels: {{
                                    color: 'white'
                                }}
                            }}
                        }},
                        scales: {{
                            y: {{
                                beginAtZero: true,
                                ticks: {{
                                    color: 'rgba(255,255,255,0.8)'
                                }},
                                grid: {{
                                    color: 'rgba(255,255,255,0.1)'
                                }}
                            }},
                            x: {{
                                ticks: {{
                                    color: 'rgba(255,255,255,0.8)'
                                }},
                                grid: {{
                                    color: 'rgba(255,255,255,0.1)'
                                }}
                            }}
                        }}
                    }}
                }});
            }}
            
            function updateChart(period) {{
                if (!workOrderChart) return;
                
                if (period === 'weekly') {{
                    workOrderChart.data.labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    workOrderChart.data.datasets[0].data = [12, 8, 15, 6, 9, 3, 2];
                    workOrderChart.data.datasets[1].data = [10, 12, 8, 11, 7, 5, 4];
                    workOrderChart.options.plugins.title.text = 'This Week - Work Order Activity';
                }} else if (period === 'monthly') {{
                    workOrderChart.data.labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
                    workOrderChart.data.datasets[0].data = [45, 52, 38, 29];
                    workOrderChart.data.datasets[1].data = [42, 48, 41, 35];
                    workOrderChart.options.plugins.title.text = 'This Month - Work Order Activity';
                }}
                
                workOrderChart.update();
                showNotification(`📊 Chart updated to ${{period}} view`);
            }});
            
            // Notification system
            function showNotification(message) {{
                const notification = document.createElement('div');
                notification.innerHTML = message;
                notification.style.cssText = `
                    position: fixed; top: 20px; right: 20px; z-index: 10000;
                    background: rgba(56,239,125,0.9); color: white; padding: 1rem 1.5rem;
                    border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                    animation: slideIn 0.3s ease-out;
                `;
                document.body.appendChild(notification);
                setTimeout(() => notification.remove(), 4000);
            }}
            
            // CSS animation for notifications
            const style = document.createElement('style');
            style.innerHTML = `
                @keyframes slideIn {{
                    from {{ transform: translateX(100%); opacity: 0; }}
                    to {{ transform: translateX(0); opacity: 1; }}
                }}
            `;
            document.head.appendChild(style);
        </script>
    </body>
    </html>
    """)