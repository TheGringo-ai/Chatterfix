"""Asset repository abstraction"""
from __future__ import annotations
from typing import List, Optional, Literal
from contextlib import contextmanager
from sqlalchemy import select
from ..database import get_session
from ..models import AssetORM

@contextmanager
def session_scope():
    s = get_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()

def list_assets(
    category: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    order_by: Literal["name", "category", "location"] = "name"
) -> List[AssetORM]:
    """Return assets with optional filtering, pagination, and sorting.
    
    Args:
        category: Filter by asset category
        limit: Maximum number of results (default 100)
        offset: Number of results to skip (default 0)
        order_by: Sort field (default "name")
    
    Returns:
        List of AssetORM objects matching criteria
    """
    with session_scope() as s:
        stmt = select(AssetORM)
        
        # Apply filters
        if category:
            stmt = stmt.where(AssetORM.category == category)
        
        # Apply sorting
        if order_by == "name":
            stmt = stmt.order_by(AssetORM.name.asc())
        elif order_by == "category":
            stmt = stmt.order_by(AssetORM.category.asc(), AssetORM.name.asc())
        elif order_by == "location":
            stmt = stmt.order_by(AssetORM.location.asc(), AssetORM.name.asc())
        
        # Apply pagination
        stmt = stmt.limit(limit).offset(offset)
        
        return list(s.execute(stmt).scalars())
