"""Parts repository abstraction"""
from __future__ import annotations
from typing import List, Optional, Literal
from contextlib import contextmanager
from sqlalchemy import select, and_, func
from ..database import get_session
from ..models import PartORM

@contextmanager
def session_scope():
    s = get_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()

def list_parts(
    category: Optional[str] = None, 
    low_stock: bool = False,
    limit: int = 100,
    offset: int = 0,
    order_by: Literal["name", "category", "quantity_on_hand", "reorder_point"] = "name"
) -> List[PartORM]:
    """Return parts with optional filtering, pagination, and sorting.

    Args:
        category: Filter by part category
        low_stock: Only return parts where quantity_on_hand <= reorder_point 
                  (excludes parts with NULL reorder_point)
        limit: Maximum number of results (default 100)
        offset: Number of results to skip (default 0)
        order_by: Sort field (default "name")
    
    Returns:
        List of PartORM objects matching criteria
    """
    with session_scope() as s:
        base = select(PartORM)
        
        # Apply filters
        if category:
            base = base.where(PartORM.category == category)
        
        if low_stock:
            # Only consider parts with defined reorder points for low-stock calculation
            # Treat NULL quantity_on_hand as 0
            base = base.where(
                and_(
                    PartORM.reorder_point.isnot(None),
                    func.coalesce(PartORM.quantity_on_hand, 0) <= PartORM.reorder_point
                )
            )
        
        # Apply sorting
        if order_by == "name":
            base = base.order_by(P small businessesby(PartORM.category.asc(), PartORM.name.asc())
        elif order_by == "quantity_on_hand":
            base = base.order_by(PartORM.quantity_on_hand.desc().nulls_last())
        elif order_by == "reorder_point":
            base = base.order_by(PartORM.reorder_point.desc().nulls_last())
        
        # Apply pagination
        base = base.limit(limit).offset(offset)
        
        result = s.execute(base)
        return list(result.scalars())

def list_low_stock_parts(category: Optional[str]=None) -> List[PartORM]:
    """Explicit helper for low stock parts (quantity_on_hand <= reorder_point)."""
    return list_parts(cat\egory=category, low_stock=True)

