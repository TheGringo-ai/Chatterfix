"""Repository layer for Work Orders with Postgres/SQLite backend.
Provides CRUD and query helpers plus event hooks for Firestore sync.
"""
from __future__ import annotations
from typing import List, Optional, Dict, Any, Literal
from contextlib import contextmanager
from sqlalchemy import select
from ..database import get_session
from ..models import WorkOrderORM

@contextmanager
def session_scope():
    s = get_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()

def list_work_orders(
    status: Optional[str] = None, 
    priority: Optional[str] = None, 
    assigned_to: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    order_by: Literal["created_at", "due_date", "priority", "status"] = "created_at"
) -> List[WorkOrderORM]:
    """Return work orders with optional filtering, pagination, and sorting.
    
    Args:
        status: Filter by work order status
        priority: Filter by priority level
        assigned_to: Filter by assigned technician
        limit: Maximum number of results (default 100)
        offset: Number of results to skip (default 0)
        order_by: Sort field (default "created_at")
    
    Returns:
        List of WorkOrderORM objects matching criteria
    """
    with session_scope() as s:
        stmt = select(WorkOrderORM)
        
        # Apply filters
        if status:
            stmt = stmt.where(WorkOrderORM.status == status)
        if priority:
            stmt = stmt.where(WorkOrderORM.priority == priority)
        if assigned_to:
            stmt = stmt.where(WorkOrderORM.assigned_to == assigned_to)
        
        # Apply sorting
        if order_by == "created_at":
            stmt = stmt.order_by(WorkOrderORM.created_at.desc())
        elif order_by == "due_date":
            stmt = stmt.order_by(WorkOrderORM.due_date.asc().nulls_last())
        elif order_by == "priority":
            # Assuming priority is text with High > Medium > Low ordering
            stmt = stmt.order_by(WorkOrderORM.priority.desc())
        elif order_by == "status":
            stmt = stmt.order_by(WorkOrderORM.status.asc())
        
        # Apply pagination
        stmt = stmt.limit(limit).offset(offset)
        
        return list(s.execute(stmt).scalars())

def get_work_order(wo_id: str) -> Optional[WorkOrderORM]:
    with session_scope() as s:
        return s.get(WorkOrderORM, wo_id)

def create_work_order(data: Dict[str, Any]) -> WorkOrderORM:
    with session_scope() as s:
        obj = WorkOrderORM(**data)
        s.add(obj)
        return obj

def update_work_order(wo_id: str, changes: Dict[str, Any]) -> Optional[WorkOrderORM]:
    with session_scope() as s:
        obj = s.get(WorkOrderORM, wo_id)
        if not obj:
            return None
        for k,v in changes.items():
            if hasattr(obj, k):
                setattr(obj, k, v)
        return obj

# Firestore sync hook (placeholder)
SYNC_QUEUE: List[Dict[str, Any]] = []

def enqueue_sync(action: str, entity: str, payload: Dict[str, Any]):
    SYNC_QUEUE.append({"action": action, "entity": entity, "payload": payload})
