#!/usr/bin/env python3
"""
ChatterFix Enterprise Integration Hub
Advanced ERP, CRM, and third-party system integrations with real-time sync
"""

import os
import json
import logging
import asyncio
import hashlib
import secrets
from typing import Dict, List, Optional, Any, Tuple, Union
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass
import aiohttp
import xml.etree.ElementTree as ET

from fastapi import APIRouter, HTTPException, BackgroundTasks, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, validator
import jwt

logger = logging.getLogger(__name__)

# Enterprise integrations router
integrations_router = APIRouter(prefix="/enterprise/integrations", tags=["enterprise-integrations"])

class IntegrationType(str, Enum):
    ERP = "erp"
    CRM = "crm"
    ACCOUNTING = "accounting"
    HR = "hr"
    INVENTORY = "inventory"
    ASSET_MANAGEMENT = "asset_management"
    IOT = "iot"
    BUSINESS_INTELLIGENCE = "business_intelligence"
    WORKFLOW = "workflow"
    NOTIFICATION = "notification"

class IntegrationStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    SYNCING = "syncing"
    PENDING = "pending"

class SyncDirection(str, Enum):
    BIDIRECTIONAL = "bidirectional"
    INBOUND = "inbound"
    OUTBOUND = "outbound"

@dataclass
class IntegrationConfig:
    integration_id: str
    tenant_id: str
    system_name: str
    system_type: IntegrationType
    status: IntegrationStatus
    sync_direction: SyncDirection
    endpoint_url: str
    auth_config: Dict[str, Any]
    sync_schedule: str  # cron format
    field_mappings: Dict[str, str]
    filters: Dict[str, Any]
    last_sync: Optional[str]
    next_sync: Optional[str]
    error_count: int
    created_at: str
    updated_at: str

class SyncRecord(BaseModel):
    sync_id: str
    integration_id: str
    started_at: str
    completed_at: Optional[str]
    status: str  # success, error, in_progress
    direction: SyncDirection
    records_processed: int
    records_created: int
    records_updated: int
    records_failed: int
    error_details: Optional[List[str]]
    performance_metrics: Dict[str, Any]

class IntegrationAdapter:
    """Base class for system integrations"""
    
    def __init__(self, config: IntegrationConfig):
        self.config = config
        self.session = None
    
    async def initialize_connection(self):
        """Initialize connection to external system"""
        raise NotImplementedError
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test connection to external system"""
        raise NotImplementedError
    
    async def sync_data(self, direction: SyncDirection) -> SyncRecord:
        """Sync data with external system"""
        raise NotImplementedError
    
    async def transform_data(self, data: Dict[str, Any], direction: str) -> Dict[str, Any]:
        """Transform data between ChatterFix and external system formats"""
        raise NotImplementedError

class SAPAdapter(IntegrationAdapter):
    """SAP ERP integration adapter"""
    
    async def initialize_connection(self):
        """Initialize SAP connection"""
        self.session = aiohttp.ClientSession()
        # In production, this would use SAP RFC or REST APIs
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test SAP connection"""
        try:
            # Mock SAP connection test
            await asyncio.sleep(0.5)  # Simulate network call
            return True, "SAP connection successful"
        except Exception as e:
            return False, f"SAP connection failed: {str(e)}"
    
    async def sync_data(self, direction: SyncDirection) -> SyncRecord:
        """Sync data with SAP"""
        sync_id = f"sync_sap_{int(datetime.now().timestamp())}"
        start_time = datetime.now()
        
        try:
            # Mock SAP data sync
            await asyncio.sleep(2)  # Simulate processing time
            
            if direction in [SyncDirection.INBOUND, SyncDirection.BIDIRECTIONAL]:
                # Sync assets from SAP to ChatterFix
                sap_assets = await self.fetch_sap_assets()
                await self.import_assets_to_chatterfix(sap_assets)
            
            if direction in [SyncDirection.OUTBOUND, SyncDirection.BIDIRECTIONAL]:
                # Sync work orders from ChatterFix to SAP
                chatterfix_work_orders = await self.fetch_chatterfix_work_orders()
                await self.export_work_orders_to_sap(chatterfix_work_orders)
            
            return SyncRecord(
                sync_id=sync_id,
                integration_id=self.config.integration_id,
                started_at=start_time.isoformat(),
                completed_at=datetime.now().isoformat(),
                status="success",
                direction=direction,
                records_processed=25,
                records_created=3,
                records_updated=20,
                records_failed=2,
                error_details=None,
                performance_metrics={
                    "duration_seconds": 2.1,
                    "throughput_records_per_second": 11.9,
                    "memory_usage_mb": 45.2
                }
            )
            
        except Exception as e:
            return SyncRecord(
                sync_id=sync_id,
                integration_id=self.config.integration_id,
                started_at=start_time.isoformat(),
                completed_at=datetime.now().isoformat(),
                status="error",
                direction=direction,
                records_processed=0,
                records_created=0,
                records_updated=0,
                records_failed=0,
                error_details=[str(e)],
                performance_metrics={}
            )
    
    async def fetch_sap_assets(self) -> List[Dict[str, Any]]:
        """Fetch assets from SAP"""
        # Mock SAP asset data
        return [
            {
                "EQUNR": "10000001",
                "EQKTX": "Centrifugal Pump Unit 1",
                "EQART": "PUMP",
                "ANLNR": "AST001",
                "KOSTL": "1000",
                "WERKS": "1000",
                "MSGRP": "PM-EQ"
            },
            {
                "EQUNR": "10000002", 
                "EQKTX": "Emergency Generator Building A",
                "EQART": "GENR",
                "ANLNR": "AST002",
                "KOSTL": "1000",
                "WERKS": "1000",
                "MSGRP": "PM-EQ"
            }
        ]
    
    async def import_assets_to_chatterfix(self, sap_assets: List[Dict[str, Any]]):
        """Import SAP assets into ChatterFix"""
        for asset in sap_assets:
            # Transform SAP data to ChatterFix format
            chatterfix_asset = {
                "asset_id": f"SAP_{asset['EQUNR']}",
                "name": asset["EQKTX"],
                "type": asset["EQART"].lower(),
                "cost_center": asset["KOSTL"],
                "plant": asset["WERKS"],
                "external_id": asset["EQUNR"],
                "sync_source": "sap"
            }
            
            # In production, this would update the ChatterFix database
            logger.info(f"Imported SAP asset: {chatterfix_asset['name']}")
    
    async def fetch_chatterfix_work_orders(self) -> List[Dict[str, Any]]:
        """Fetch work orders from ChatterFix"""
        # Mock ChatterFix work order data
        return [
            {
                "id": "WO-001",
                "title": "Pump Maintenance",
                "asset_id": "SAP_10000001",
                "status": "complete",
                "cost": 450.00
            }
        ]
    
    async def export_work_orders_to_sap(self, work_orders: List[Dict[str, Any]]):
        """Export work orders to SAP"""
        for wo in work_orders:
            # Transform to SAP format
            sap_order = {
                "AUFNR": wo["id"].replace("WO-", ""),
                "KTEXT": wo["title"],
                "EQUNR": wo["asset_id"].replace("SAP_", ""),
                "STAT": "COMP" if wo["status"] == "complete" else "OPEN",
                "ISTKOSTEN": wo.get("cost", 0)
            }
            
            logger.info(f"Exported work order to SAP: {sap_order['KTEXT']}")

class MicrosoftAdapter(IntegrationAdapter):
    """Microsoft 365 integration adapter"""
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test Microsoft 365 connection"""
        try:
            # Mock Office 365 connection test
            await asyncio.sleep(0.3)
            return True, "Microsoft 365 connection successful"
        except Exception as e:
            return False, f"Microsoft 365 connection failed: {str(e)}"
    
    async def sync_data(self, direction: SyncDirection) -> SyncRecord:
        """Sync data with Microsoft 365"""
        sync_id = f"sync_ms365_{int(datetime.now().timestamp())}"
        start_time = datetime.now()
        
        try:
            # Mock Microsoft 365 sync (Teams, SharePoint, Outlook)
            if direction in [SyncDirection.OUTBOUND, SyncDirection.BIDIRECTIONAL]:
                # Create Teams notifications for high-priority work orders
                await self.send_teams_notifications()
                
                # Sync documents to SharePoint
                await self.sync_documents_to_sharepoint()
                
                # Create Outlook calendar events for scheduled maintenance
                await self.create_outlook_events()
            
            return SyncRecord(
                sync_id=sync_id,
                integration_id=self.config.integration_id,
                started_at=start_time.isoformat(),
                completed_at=datetime.now().isoformat(),
                status="success",
                direction=direction,
                records_processed=15,
                records_created=12,
                records_updated=3,
                records_failed=0,
                error_details=None,
                performance_metrics={
                    "duration_seconds": 1.5,
                    "api_calls_made": 8,
                    "data_transferred_mb": 2.3
                }
            )
            
        except Exception as e:
            return SyncRecord(
                sync_id=sync_id,
                integration_id=self.config.integration_id,
                started_at=start_time.isoformat(),
                completed_at=datetime.now().isoformat(),
                status="error",
                direction=direction,
                records_processed=0,
                records_created=0,
                records_updated=0,
                records_failed=0,
                error_details=[str(e)],
                performance_metrics={}
            )
    
    async def send_teams_notifications(self):
        """Send Teams notifications for critical work orders"""
        # Mock Teams notification
        notifications = [
            {
                "channel": "Maintenance Team",
                "message": "🚨 Critical work order WO-001 requires immediate attention",
                "type": "critical_alert"
            }
        ]
        
        for notification in notifications:
            logger.info(f"Teams notification sent: {notification['message']}")
    
    async def sync_documents_to_sharepoint(self):
        """Sync maintenance documents to SharePoint"""
        documents = [
            {"name": "Pump_Maintenance_Checklist.pdf", "folder": "Procedures"},
            {"name": "Safety_Guidelines.docx", "folder": "Safety"}
        ]
        
        for doc in documents:
            logger.info(f"Document synced to SharePoint: {doc['name']}")
    
    async def create_outlook_events(self):
        """Create Outlook calendar events for scheduled maintenance"""
        events = [
            {
                "subject": "Scheduled Maintenance - Generator #1",
                "start": "2025-01-15T09:00:00Z",
                "duration": 120,  # minutes
                "attendees": ["tech1@company.com", "manager@company.com"]
            }
        ]
        
        for event in events:
            logger.info(f"Outlook event created: {event['subject']}")

class QuickBooksAdapter(IntegrationAdapter):
    """QuickBooks accounting integration adapter"""
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test QuickBooks connection"""
        try:
            await asyncio.sleep(0.4)
            return True, "QuickBooks Online connection successful"
        except Exception as e:
            return False, f"QuickBooks connection failed: {str(e)}"
    
    async def sync_data(self, direction: SyncDirection) -> SyncRecord:
        """Sync financial data with QuickBooks"""
        sync_id = f"sync_qb_{int(datetime.now().timestamp())}"
        start_time = datetime.now()
        
        try:
            if direction in [SyncDirection.OUTBOUND, SyncDirection.BIDIRECTIONAL]:
                # Export work order costs as expenses
                await self.export_maintenance_expenses()
                
                # Create purchase orders for parts
                await self.create_purchase_orders()
            
            if direction in [SyncDirection.INBOUND, SyncDirection.BIDIRECTIONAL]:
                # Import vendor data
                await self.import_vendor_data()
                
                # Import budget information
                await self.import_budget_data()
            
            return SyncRecord(
                sync_id=sync_id,
                integration_id=self.config.integration_id,
                started_at=start_time.isoformat(),
                completed_at=datetime.now().isoformat(),
                status="success",
                direction=direction,
                records_processed=18,
                records_created=8,
                records_updated=10,
                records_failed=0,
                error_details=None,
                performance_metrics={
                    "duration_seconds": 3.2,
                    "expense_records": 12,
                    "po_records": 6
                }
            )
            
        except Exception as e:
            return SyncRecord(
                sync_id=sync_id,
                integration_id=self.config.integration_id,
                started_at=start_time.isoformat(),
                completed_at=datetime.now().isoformat(),
                status="error",
                direction=direction,
                records_processed=0,
                records_created=0,
                records_updated=0,
                records_failed=0,
                error_details=[str(e)],
                performance_metrics={}
            )
    
    async def export_maintenance_expenses(self):
        """Export maintenance costs as QuickBooks expenses"""
        expenses = [
            {
                "amount": 450.00,
                "description": "Pump repair - Emergency maintenance",
                "category": "Maintenance & Repairs",
                "work_order": "WO-001"
            },
            {
                "amount": 125.50,
                "description": "HVAC filter replacement",
                "category": "Maintenance & Repairs",
                "work_order": "WO-002"
            }
        ]
        
        for expense in expenses:
            logger.info(f"Expense exported to QuickBooks: ${expense['amount']} - {expense['description']}")
    
    async def create_purchase_orders(self):
        """Create purchase orders for maintenance parts"""
        pos = [
            {
                "vendor": "Industrial Parts Supply",
                "items": [
                    {"description": "Pump Impeller - 6 inch", "qty": 2, "cost": 425.00}
                ],
                "total": 850.00
            }
        ]
        
        for po in pos:
            logger.info(f"Purchase order created: {po['vendor']} - ${po['total']}")
    
    async def import_vendor_data(self):
        """Import vendor information from QuickBooks"""
        vendors = [
            {"name": "Industrial Parts Supply", "contact": "parts@ips.com"},
            {"name": "Electrical Supplies Inc", "contact": "orders@esi.com"}
        ]
        
        for vendor in vendors:
            logger.info(f"Vendor imported: {vendor['name']}")
    
    async def import_budget_data(self):
        """Import budget information from QuickBooks"""
        budgets = [
            {"category": "Maintenance & Repairs", "annual_budget": 50000.00, "spent_ytd": 23450.00},
            {"category": "Parts & Inventory", "annual_budget": 25000.00, "spent_ytd": 12800.00}
        ]
        
        for budget in budgets:
            logger.info(f"Budget imported: {budget['category']} - ${budget['annual_budget']}")

class EnterpriseIntegrationHub:
    def __init__(self):
        self.integrations: Dict[str, IntegrationConfig] = {}
        self.adapters: Dict[str, IntegrationAdapter] = {}
        self.sync_history: List[SyncRecord] = []
        self.integration_templates: Dict[str, Dict] = {}
        
        # Initialize integration hub
        asyncio.create_task(self.initialize_integration_hub())
    
    async def initialize_integration_hub(self):
        """Initialize integration hub with templates and demo integrations"""
        try:
            logger.info("🔗 Initializing enterprise integration hub...")
            
            # Initialize integration templates
            self.integration_templates = {
                "sap_erp": {
                    "system_name": "SAP ERP",
                    "system_type": IntegrationType.ERP,
                    "description": "Enterprise Resource Planning integration",
                    "endpoints": {
                        "assets": "/sap/bc/rest/zpm_assets",
                        "work_orders": "/sap/bc/rest/zpm_orders",
                        "costs": "/sap/bc/rest/zco_costs"
                    },
                    "auth_methods": ["oauth2", "basic", "api_key"],
                    "sync_frequencies": ["real_time", "hourly", "daily", "weekly"],
                    "data_mappings": {
                        "asset_id": "EQUNR",
                        "asset_name": "EQKTX",
                        "asset_type": "EQART",
                        "cost_center": "KOSTL"
                    }
                },
                "microsoft_365": {
                    "system_name": "Microsoft 365",
                    "system_type": IntegrationType.WORKFLOW,
                    "description": "Office 365 productivity suite integration",
                    "endpoints": {
                        "teams": "https://graph.microsoft.com/v1.0/teams",
                        "sharepoint": "https://graph.microsoft.com/v1.0/sites",
                        "outlook": "https://graph.microsoft.com/v1.0/calendar"
                    },
                    "auth_methods": ["oauth2"],
                    "sync_frequencies": ["real_time", "hourly", "daily"],
                    "features": ["teams_notifications", "document_sync", "calendar_events"]
                },
                "quickbooks": {
                    "system_name": "QuickBooks Online",
                    "system_type": IntegrationType.ACCOUNTING,
                    "description": "Financial management integration",
                    "endpoints": {
                        "expenses": "/v3/company/{companyId}/expenses",
                        "vendors": "/v3/company/{companyId}/vendors",
                        "purchase_orders": "/v3/company/{companyId}/purchaseorder"
                    },
                    "auth_methods": ["oauth2"],
                    "sync_frequencies": ["daily", "weekly"],
                    "data_mappings": {
                        "work_order_cost": "expense_amount",
                        "vendor_name": "vendor_display_name",
                        "cost_category": "expense_account"
                    }
                },
                "oracle_erp": {
                    "system_name": "Oracle ERP Cloud",
                    "system_type": IntegrationType.ERP,
                    "description": "Oracle Enterprise Resource Planning",
                    "endpoints": {
                        "assets": "/fscmRestApi/resources/11.13.18.05/maintenanceAssets",
                        "work_requests": "/fscmRestApi/resources/11.13.18.05/workRequests"
                    },
                    "auth_methods": ["oauth2", "basic"],
                    "sync_frequencies": ["real_time", "hourly", "daily"]
                },
                "power_bi": {
                    "system_name": "Microsoft Power BI",
                    "system_type": IntegrationType.BUSINESS_INTELLIGENCE,
                    "description": "Business intelligence and analytics",
                    "endpoints": {
                        "datasets": "https://api.powerbi.com/v1.0/myorg/datasets",
                        "reports": "https://api.powerbi.com/v1.0/myorg/reports"
                    },
                    "auth_methods": ["oauth2"],
                    "sync_frequencies": ["hourly", "daily"],
                    "features": ["dashboard_embedding", "automated_reports"]
                },
                "slack": {
                    "system_name": "Slack",
                    "system_type": IntegrationType.NOTIFICATION,
                    "description": "Team communication and notifications",
                    "endpoints": {
                        "messages": "https://slack.com/api/chat.postMessage",
                        "channels": "https://slack.com/api/conversations.list"
                    },
                    "auth_methods": ["oauth2", "webhook"],
                    "sync_frequencies": ["real_time"],
                    "features": ["work_order_notifications", "maintenance_alerts"]
                }
            }
            
            # Create demo integrations
            await self.create_demo_integrations()
            
            logger.info("✅ Enterprise integration hub initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize integration hub: {e}")
    
    async def create_demo_integrations(self):
        """Create demo integrations for different tenants"""
        try:
            demo_integrations = [
                {
                    "tenant_id": "tenant_acme_corp",
                    "integrations": [
                        {
                            "system_name": "SAP ERP Production",
                            "system_type": IntegrationType.ERP,
                            "endpoint_url": "https://sap.acme.com/sap/bc/rest",
                            "sync_direction": SyncDirection.BIDIRECTIONAL,
                            "sync_schedule": "0 */6 * * *"  # Every 6 hours
                        },
                        {
                            "system_name": "Microsoft Teams",
                            "system_type": IntegrationType.NOTIFICATION,
                            "endpoint_url": "https://graph.microsoft.com/v1.0",
                            "sync_direction": SyncDirection.OUTBOUND,
                            "sync_schedule": "* * * * *"  # Real-time
                        },
                        {
                            "system_name": "Power BI Analytics",
                            "system_type": IntegrationType.BUSINESS_INTELLIGENCE,
                            "endpoint_url": "https://api.powerbi.com/v1.0",
                            "sync_direction": SyncDirection.OUTBOUND,
                            "sync_schedule": "0 */1 * * *"  # Every hour
                        }
                    ]
                },
                {
                    "tenant_id": "tenant_global_mfg",
                    "integrations": [
                        {
                            "system_name": "Oracle ERP Cloud",
                            "system_type": IntegrationType.ERP,
                            "endpoint_url": "https://erp.globalmfg.com/fscmRestApi",
                            "sync_direction": SyncDirection.BIDIRECTIONAL,
                            "sync_schedule": "0 */4 * * *"  # Every 4 hours
                        },
                        {
                            "system_name": "Google Workspace",
                            "system_type": IntegrationType.WORKFLOW,
                            "endpoint_url": "https://www.googleapis.com",
                            "sync_direction": SyncDirection.BIDIRECTIONAL,
                            "sync_schedule": "0 */2 * * *"  # Every 2 hours
                        },
                        {
                            "system_name": "Tableau Server",
                            "system_type": IntegrationType.BUSINESS_INTELLIGENCE,
                            "endpoint_url": "https://tableau.globalmfg.com/api",
                            "sync_direction": SyncDirection.OUTBOUND,
                            "sync_schedule": "0 6 * * *"  # Daily at 6 AM
                        }
                    ]
                },
                {
                    "tenant_id": "tenant_startup_demo",
                    "integrations": [
                        {
                            "system_name": "QuickBooks Online",
                            "system_type": IntegrationType.ACCOUNTING,
                            "endpoint_url": "https://sandbox-quickbooks.api.intuit.com",
                            "sync_direction": SyncDirection.OUTBOUND,
                            "sync_schedule": "0 18 * * *"  # Daily at 6 PM
                        },
                        {
                            "system_name": "Slack Workspace",
                            "system_type": IntegrationType.NOTIFICATION,
                            "endpoint_url": "https://slack.com/api",
                            "sync_direction": SyncDirection.OUTBOUND,
                            "sync_schedule": "* * * * *"  # Real-time
                        }
                    ]
                }
            ]
            
            for tenant_demo in demo_integrations:
                tenant_id = tenant_demo["tenant_id"]
                
                for integration_data in tenant_demo["integrations"]:
                    integration_id = f"int_{tenant_id}_{integration_data['system_type'].value}_{len(self.integrations)}"
                    
                    config = IntegrationConfig(
                        integration_id=integration_id,
                        tenant_id=tenant_id,
                        system_name=integration_data["system_name"],
                        system_type=integration_data["system_type"],
                        status=IntegrationStatus.ACTIVE,
                        sync_direction=integration_data["sync_direction"],
                        endpoint_url=integration_data["endpoint_url"],
                        auth_config={
                            "auth_type": "oauth2",
                            "client_id": f"client_{secrets.token_hex(8)}",
                            "encrypted": True
                        },
                        sync_schedule=integration_data["sync_schedule"],
                        field_mappings={
                            "asset_id": "external_asset_id",
                            "work_order_id": "external_wo_id",
                            "cost": "external_cost"
                        },
                        filters={"status": "active"},
                        last_sync=None,
                        next_sync=None,
                        error_count=0,
                        created_at=datetime.now().isoformat(),
                        updated_at=datetime.now().isoformat()
                    )
                    
                    self.integrations[integration_id] = config
                    
                    # Create appropriate adapter
                    if "sap" in integration_data["system_name"].lower():
                        self.adapters[integration_id] = SAPAdapter(config)
                    elif "microsoft" in integration_data["system_name"].lower():
                        self.adapters[integration_id] = MicrosoftAdapter(config)
                    elif "quickbooks" in integration_data["system_name"].lower():
                        self.adapters[integration_id] = QuickBooksAdapter(config)
            
            logger.info(f"✅ Created {len(self.integrations)} demo integrations")
            
        except Exception as e:
            logger.error(f"❌ Failed to create demo integrations: {e}")
    
    async def create_integration(self, integration_data: Dict[str, Any]) -> str:
        """Create new integration"""
        try:
            integration_id = f"int_{integration_data['tenant_id']}_{int(datetime.now().timestamp())}"
            
            config = IntegrationConfig(
                integration_id=integration_id,
                tenant_id=integration_data["tenant_id"],
                system_name=integration_data["system_name"],
                system_type=IntegrationType(integration_data["system_type"]),
                status=IntegrationStatus.PENDING,
                sync_direction=SyncDirection(integration_data.get("sync_direction", "bidirectional")),
                endpoint_url=integration_data["endpoint_url"],
                auth_config=integration_data.get("auth_config", {}),
                sync_schedule=integration_data.get("sync_schedule", "0 */1 * * *"),
                field_mappings=integration_data.get("field_mappings", {}),
                filters=integration_data.get("filters", {}),
                last_sync=None,
                next_sync=None,
                error_count=0,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat()
            )
            
            self.integrations[integration_id] = config
            
            # Create adapter based on system type
            adapter = await self.create_adapter(config)
            if adapter:
                self.adapters[integration_id] = adapter
                
                # Test connection
                success, message = await adapter.test_connection()
                if success:
                    config.status = IntegrationStatus.ACTIVE
                else:
                    config.status = IntegrationStatus.ERROR
                    config.error_count += 1
            
            logger.info(f"✅ Created integration: {config.system_name} ({integration_id})")
            
            return integration_id
            
        except Exception as e:
            logger.error(f"❌ Failed to create integration: {e}")
            raise HTTPException(status_code=500, detail=f"Integration creation failed: {str(e)}")
    
    async def create_adapter(self, config: IntegrationConfig) -> Optional[IntegrationAdapter]:
        """Create appropriate adapter for integration"""
        try:
            system_name = config.system_name.lower()
            
            if "sap" in system_name:
                return SAPAdapter(config)
            elif "microsoft" in system_name or "office" in system_name:
                return MicrosoftAdapter(config)
            elif "quickbooks" in system_name:
                return QuickBooksAdapter(config)
            else:
                # Generic adapter for unknown systems
                return IntegrationAdapter(config)
                
        except Exception as e:
            logger.error(f"❌ Failed to create adapter: {e}")
            return None
    
    async def sync_integration(self, integration_id: str, direction: Optional[SyncDirection] = None) -> SyncRecord:
        """Manually trigger integration sync"""
        try:
            if integration_id not in self.integrations:
                raise HTTPException(status_code=404, detail="Integration not found")
            
            config = self.integrations[integration_id]
            adapter = self.adapters.get(integration_id)
            
            if not adapter:
                raise HTTPException(status_code=500, detail="Integration adapter not found")
            
            # Use configured direction if not specified
            sync_direction = direction or config.sync_direction
            
            # Update status
            config.status = IntegrationStatus.SYNCING
            config.updated_at = datetime.now().isoformat()
            
            # Perform sync
            sync_record = await adapter.sync_data(sync_direction)
            
            # Update integration status based on sync result
            if sync_record.status == "success":
                config.status = IntegrationStatus.ACTIVE
                config.last_sync = sync_record.completed_at
                config.error_count = 0
            else:
                config.status = IntegrationStatus.ERROR
                config.error_count += 1
            
            # Store sync record
            self.sync_history.append(sync_record)
            
            # Keep only last 1000 sync records
            if len(self.sync_history) > 1000:
                self.sync_history = self.sync_history[-1000:]
            
            logger.info(f"✅ Sync completed for {config.system_name}: {sync_record.status}")
            
            return sync_record
            
        except Exception as e:
            logger.error(f"❌ Integration sync failed: {e}")
            raise HTTPException(status_code=500, detail=f"Sync failed: {str(e)}")
    
    async def test_integration_connection(self, integration_id: str) -> Tuple[bool, str]:
        """Test integration connection"""
        try:
            if integration_id not in self.integrations:
                return False, "Integration not found"
            
            adapter = self.adapters.get(integration_id)
            if not adapter:
                return False, "Integration adapter not found"
            
            return await adapter.test_connection()
            
        except Exception as e:
            logger.error(f"❌ Connection test failed: {e}")
            return False, f"Connection test failed: {str(e)}"
    
    async def get_integration_analytics(self, tenant_id: Optional[str] = None) -> Dict[str, Any]:
        """Get integration analytics and metrics"""
        try:
            # Filter integrations by tenant if specified
            integrations = list(self.integrations.values())
            if tenant_id:
                integrations = [i for i in integrations if i.tenant_id == tenant_id]
            
            # Filter sync history
            sync_records = self.sync_history
            if tenant_id:
                integration_ids = [i.integration_id for i in integrations]
                sync_records = [s for s in sync_records if s.integration_id in integration_ids]
            
            # Calculate metrics
            total_integrations = len(integrations)
            active_integrations = len([i for i in integrations if i.status == IntegrationStatus.ACTIVE])
            error_integrations = len([i for i in integrations if i.status == IntegrationStatus.ERROR])
            
            # Sync statistics
            total_syncs = len(sync_records)
            successful_syncs = len([s for s in sync_records if s.status == "success"])
            failed_syncs = len([s for s in sync_records if s.status == "error"])
            
            success_rate = (successful_syncs / total_syncs * 100) if total_syncs > 0 else 0
            
            # System type distribution
            system_types = {}
            for integration in integrations:
                sys_type = integration.system_type.value
                system_types[sys_type] = system_types.get(sys_type, 0) + 1
            
            # Recent activity (last 24 hours)
            recent_time = datetime.now() - timedelta(hours=24)
            recent_syncs = [
                s for s in sync_records
                if datetime.fromisoformat(s.started_at) > recent_time
            ]
            
            # Performance metrics
            avg_sync_duration = 0
            if recent_syncs:
                durations = [s.performance_metrics.get("duration_seconds", 0) for s in recent_syncs]
                avg_sync_duration = sum(durations) / len(durations)
            
            return {
                "overview": {
                    "total_integrations": total_integrations,
                    "active_integrations": active_integrations,
                    "error_integrations": error_integrations,
                    "health_percentage": round((active_integrations / total_integrations * 100) if total_integrations > 0 else 0, 1)
                },
                "sync_metrics": {
                    "total_syncs_24h": len(recent_syncs),
                    "successful_syncs": successful_syncs,
                    "failed_syncs": failed_syncs,
                    "success_rate": round(success_rate, 1),
                    "avg_sync_duration_seconds": round(avg_sync_duration, 2)
                },
                "system_distribution": system_types,
                "recent_activity": [
                    {
                        "sync_id": s.sync_id,
                        "integration_id": s.integration_id,
                        "status": s.status,
                        "records_processed": s.records_processed,
                        "duration": s.performance_metrics.get("duration_seconds", 0),
                        "started_at": s.started_at
                    }
                    for s in sorted(recent_syncs, key=lambda x: x.started_at, reverse=True)[:10]
                ],
                "top_performers": [
                    {
                        "integration_id": i.integration_id,
                        "system_name": i.system_name,
                        "success_count": len([s for s in sync_records if s.integration_id == i.integration_id and s.status == "success"]),
                        "last_sync": i.last_sync
                    }
                    for i in sorted(integrations, key=lambda x: x.error_count)[:5]
                ]
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to get integration analytics: {e}")
            raise HTTPException(status_code=500, detail="Analytics generation failed")

# Initialize global integration hub
integration_hub = EnterpriseIntegrationHub()

# API Endpoints
@integrations_router.get("/templates")
async def get_integration_templates():
    """Get available integration templates"""
    return JSONResponse({
        "templates": integration_hub.integration_templates,
        "total_templates": len(integration_hub.integration_templates)
    })

@integrations_router.post("/create")
async def create_integration_endpoint(integration_data: Dict[str, Any]):
    """Create new integration"""
    integration_id = await integration_hub.create_integration(integration_data)
    
    return JSONResponse({
        "success": True,
        "integration_id": integration_id,
        "message": f"Integration '{integration_data['system_name']}' created successfully"
    })

@integrations_router.get("/list")
async def list_integrations(tenant_id: Optional[str] = None):
    """List all integrations"""
    integrations = list(integration_hub.integrations.values())
    
    if tenant_id:
        integrations = [i for i in integrations if i.tenant_id == tenant_id]
    
    return JSONResponse({
        "integrations": [
            {
                "integration_id": i.integration_id,
                "tenant_id": i.tenant_id,
                "system_name": i.system_name,
                "system_type": i.system_type.value,
                "status": i.status.value,
                "sync_direction": i.sync_direction.value,
                "last_sync": i.last_sync,
                "error_count": i.error_count,
                "created_at": i.created_at
            }
            for i in integrations
        ],
        "total_count": len(integrations)
    })

@integrations_router.get("/{integration_id}")
async def get_integration_details(integration_id: str):
    """Get detailed integration information"""
    if integration_id not in integration_hub.integrations:
        raise HTTPException(status_code=404, detail="Integration not found")
    
    config = integration_hub.integrations[integration_id]
    
    # Get recent sync history
    recent_syncs = [
        s for s in integration_hub.sync_history
        if s.integration_id == integration_id
    ][-10:]  # Last 10 syncs
    
    return JSONResponse({
        "integration": {
            "integration_id": config.integration_id,
            "tenant_id": config.tenant_id,
            "system_name": config.system_name,
            "system_type": config.system_type.value,
            "status": config.status.value,
            "sync_direction": config.sync_direction.value,
            "endpoint_url": config.endpoint_url,
            "sync_schedule": config.sync_schedule,
            "field_mappings": config.field_mappings,
            "filters": config.filters,
            "last_sync": config.last_sync,
            "next_sync": config.next_sync,
            "error_count": config.error_count,
            "created_at": config.created_at,
            "updated_at": config.updated_at
        },
        "recent_syncs": [sync.dict() for sync in recent_syncs]
    })

@integrations_router.post("/{integration_id}/sync")
async def trigger_integration_sync(
    integration_id: str,
    sync_data: Optional[Dict[str, Any]] = None
):
    """Manually trigger integration sync"""
    direction = None
    if sync_data and "direction" in sync_data:
        direction = SyncDirection(sync_data["direction"])
    
    sync_record = await integration_hub.sync_integration(integration_id, direction)
    
    return sync_record.dict()

@integrations_router.get("/{integration_id}/test")
async def test_integration_connection_endpoint(integration_id: str):
    """Test integration connection"""
    success, message = await integration_hub.test_integration_connection(integration_id)
    
    return JSONResponse({
        "success": success,
        "message": message,
        "tested_at": datetime.now().isoformat()
    })

@integrations_router.get("/analytics/overview")
async def get_integration_analytics_endpoint(tenant_id: Optional[str] = None):
    """Get integration analytics and metrics"""
    analytics = await integration_hub.get_integration_analytics(tenant_id)
    return JSONResponse(analytics)

@integrations_router.get("/sync-history")
async def get_sync_history(
    integration_id: Optional[str] = None,
    limit: int = 50
):
    """Get sync history"""
    sync_records = integration_hub.sync_history
    
    if integration_id:
        sync_records = [s for s in sync_records if s.integration_id == integration_id]
    
    # Sort by start time (newest first)
    sync_records = sorted(sync_records, key=lambda x: x.started_at, reverse=True)
    
    # Limit results
    sync_records = sync_records[:limit]
    
    return JSONResponse({
        "sync_history": [record.dict() for record in sync_records],
        "total_count": len(sync_records)
    })