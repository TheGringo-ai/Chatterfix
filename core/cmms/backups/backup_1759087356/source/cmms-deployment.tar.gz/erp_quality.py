#!/usr/bin/env python3
"""
ChatterFix ERP - Quality Module
AR-powered quality control with vision + voice processing
"""

from fastapi import APIRouter, HTTPException, File, UploadFile, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import cv2
import numpy as np
import speech_recognition as sr
import tempfile
import os
import asyncio
import logging
from datetime import datetime, timedelta
import json
try:
    from ai_model_provider import CentralizedAIProvider
except ImportError:
    # Fallback for when import fails
    class CentralizedAIProvider:
        async def generate_response(self, prompt, context=None, temperature=0.3):
            return {"response": "AI provider not available"}

logger = logging.getLogger(__name__)

# ERP Quality router
erp_quality_router = APIRouter(prefix="/erp/quality", tags=["erp-quality"])

# Data models
class QualityAlert(BaseModel):
    alert_id: str
    severity: str
    product_batch: str
    defect_type: str
    location: str
    timestamp: str
    notifications_sent: List[str]
    actions_required: List[str]
    confidence: float

class QualityAnalysis(BaseModel):
    defects_detected: int
    quality_score: float
    batch_status: str
    recommended_actions: List[str]
    compliance_status: str

# Mock quality database
quality_alerts_db = []
batch_records_db = {}

# AI provider for quality analysis
ai_provider = CentralizedAIProvider()

def analyze_video_quality(video_path: str) -> Dict[str, Any]:
    """Analyze video for quality defects using OpenCV"""
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.error(f"Cannot open video file: {video_path}")
            return {"defects": 0, "quality_score": 1.0, "analysis": "Video analysis failed"}
        
        total_frames = 0
        defect_frames = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            total_frames += 1
            
            # Convert to grayscale for analysis
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            # Simple defect detection (looking for unusual patterns)
            # In production, this would use trained ML models
            edges = cv2.Canny(gray, 50, 150)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Mock defect detection - large irregular shapes could indicate problems
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > 5000:  # Arbitrary threshold for demo
                    defect_frames += 1
                    break
        
        cap.release()
        
        if total_frames == 0:
            return {"defects": 0, "quality_score": 1.0, "analysis": "No frames to analyze"}
        
        defect_ratio = defect_frames / total_frames
        quality_score = max(0.0, 1.0 - (defect_ratio * 2))  # Convert to quality score
        
        return {
            "defects": defect_frames,
            "total_frames": total_frames,
            "quality_score": quality_score,
            "analysis": f"Analyzed {total_frames} frames, detected {defect_frames} potential defects"
        }
        
    except Exception as e:
        logger.error(f"Video analysis error: {e}")
        return {"defects": 0, "quality_score": 0.5, "analysis": f"Analysis error: {str(e)}"}

def analyze_audio_quality(audio_path: str) -> Dict[str, Any]:
    """Analyze audio for quality issues using speech recognition"""
    try:
        recognizer = sr.Recognizer()
        
        with sr.AudioFile(audio_path) as source:
            # Adjust for ambient noise
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio_data = recognizer.record(source)
        
        # Convert speech to text
        transcript = recognizer.recognize_google(audio_data).lower()
        
        # Analyze transcript for quality keywords
        quality_keywords = {
            "defect": ["defect", "bad", "nasty", "spoiled", "contaminated", "moldy", "rotten"],
            "severity": ["critical", "urgent", "emergency", "serious", "major", "minor"],
            "location": ["batch", "line", "section", "area", "zone", "floor"],
            "product": ["cheese", "milk", "product", "food", "item", "material"]
        }
        
        detected_issues = {}
        severity_level = "normal"
        
        for category, keywords in quality_keywords.items():
            for keyword in keywords:
                if keyword in transcript:
                    if category not in detected_issues:
                        detected_issues[category] = []
                    detected_issues[category].append(keyword)
                    
                    if keyword in ["critical", "urgent", "emergency", "nasty", "contaminated"]:
                        severity_level = "high"
                    elif keyword in ["serious", "major", "bad", "defect"]:
                        severity_level = "medium"
        
        return {
            "transcript": transcript,
            "detected_issues": detected_issues,
            "severity": severity_level,
            "confidence": 0.95 if detected_issues else 0.8
        }
        
    except sr.UnknownValueError:
        return {
            "transcript": "",
            "detected_issues": {},
            "severity": "normal",
            "confidence": 0.0,
            "error": "Could not understand audio"
        }
    except Exception as e:
        logger.error(f"Audio analysis error: {e}")
        return {
            "transcript": "",
            "detected_issues": {},
            "severity": "normal", 
            "confidence": 0.0,
            "error": str(e)
        }

async def generate_quality_actions(defects: int, audio_analysis: Dict, ai_context: str) -> List[str]:
    """Generate recommended actions using AI"""
    try:
        prompt = f"""
        Quality Control Analysis:
        - Defects detected in video: {defects}
        - Audio transcript: {audio_analysis.get('transcript', 'N/A')}
        - Detected issues: {json.dumps(audio_analysis.get('detected_issues', {}))}
        - Severity: {audio_analysis.get('severity', 'normal')}
        - Context: {ai_context}
        
        Generate 3-5 specific, actionable quality control recommendations for this situation.
        Focus on immediate safety, containment, and corrective actions.
        """
        
        response = await ai_provider.generate_response(
            prompt, 
            context="quality_control",
            temperature=0.3
        )
        
        # Parse AI response into action items
        actions = []
        if response and isinstance(response, dict) and 'response' in response:
            lines = response['response'].split('\n')
            for line in lines:
                line = line.strip()
                if line and (line.startswith('-') or line.startswith('•') or line[0].isdigit()):
                    actions.append(line.lstrip('-• 0123456789.'))
        
        # Fallback actions if AI fails
        if not actions:
            if defects > 0 or audio_analysis.get('severity') in ['high', 'medium']:
                actions = [
                    "Immediately quarantine affected batch",
                    "Notify quality control team and supervisor",
                    "Document incident in quality management system", 
                    "Initiate root cause analysis",
                    "Review and test adjacent batches"
                ]
            else:
                actions = [
                    "Continue monitoring",
                    "Document observation in quality log"
                ]
        
        return actions[:5]  # Limit to 5 actions
        
    except Exception as e:
        logger.error(f"AI action generation error: {e}")
        return [
            "Document quality observation",
            "Notify supervisor if issues persist",
            "Follow standard quality protocols"
        ]

@erp_quality_router.post("/analyze", response_model=Dict[str, Any])
async def analyze_quality_issue(
    video: Optional[UploadFile] = File(None),
    audio: Optional[UploadFile] = File(None),
    batch_id: str = Form(...),
    location: str = Form("Unknown"),
    context: str = Form("routine_inspection")
):
    """
    Analyze quality issues from video and audio inputs
    Core AR quality control endpoint
    """
    try:
        analysis_start = datetime.now()
        
        # Initialize results
        video_analysis = {"defects": 0, "quality_score": 1.0, "analysis": "No video provided"}
        audio_analysis = {"transcript": "", "detected_issues": {}, "severity": "normal", "confidence": 0.0}
        
        # Process video if provided
        if video:
            with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as temp_video:
                content = await video.read()
                temp_video.write(content)
                temp_video_path = temp_video.name
            
            video_analysis = analyze_video_quality(temp_video_path)
            os.unlink(temp_video_path)  # Clean up temp file
        
        # Process audio if provided
        if audio:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_audio:
                content = await audio.read()
                temp_audio.write(content)
                temp_audio_path = temp_audio.name
            
            audio_analysis = analyze_audio_quality(temp_audio_path)
            os.unlink(temp_audio_path)  # Clean up temp file
        
        # Generate AI-powered recommendations
        recommended_actions = await generate_quality_actions(
            video_analysis.get("defects", 0),
            audio_analysis,
            context
        )
        
        # Determine overall severity and status
        overall_severity = "normal"
        if video_analysis.get("defects", 0) > 0 or audio_analysis.get("severity") in ["high", "medium"]:
            overall_severity = audio_analysis.get("severity", "medium")
        
        batch_status = "pass"
        if overall_severity in ["high", "medium"] or video_analysis.get("quality_score", 1.0) < 0.7:
            batch_status = "hold"
        if overall_severity == "high" or video_analysis.get("quality_score", 1.0) < 0.3:
            batch_status = "reject"
        
        # Generate notifications list
        notifications = ["qc@company.com"]
        if overall_severity in ["high", "medium"]:
            notifications.extend(["supervisor@company.com", "operations@company.com"])
        if overall_severity == "high":
            notifications.extend(["safety@company.com", "compliance@company.com"])
        
        # Create quality alert if needed
        alert_id = None
        if batch_status != "pass":
            alert_id = f"QA-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            alert = {
                "alert_id": alert_id,
                "severity": overall_severity,
                "product_batch": batch_id,
                "defect_type": list(audio_analysis.get("detected_issues", {}).keys()),
                "location": location,
                "timestamp": datetime.now().isoformat(),
                "notifications_sent": notifications,
                "actions_required": recommended_actions,
                "confidence": max(video_analysis.get("confidence", 0.8), audio_analysis.get("confidence", 0.8)),
                "video_analysis": video_analysis,
                "audio_analysis": audio_analysis
            }
            quality_alerts_db.append(alert)
        
        # Update batch records
        batch_records_db[batch_id] = {
            "last_inspection": datetime.now().isoformat(),
            "status": batch_status,
            "quality_score": video_analysis.get("quality_score", 1.0),
            "alert_id": alert_id
        }
        
        analysis_time = (datetime.now() - analysis_start).total_seconds()
        
        # Return comprehensive analysis
        return {
            "success": True,
            "batch_id": batch_id,
            "batch_status": batch_status,
            "alert_id": alert_id,
            "severity": overall_severity,
            "quality_score": video_analysis.get("quality_score", 1.0),
            "defects_detected": video_analysis.get("defects", 0),
            "audio_transcript": audio_analysis.get("transcript", ""),
            "detected_issues": audio_analysis.get("detected_issues", {}),
            "recommended_actions": recommended_actions,
            "notifications_sent": notifications,
            "confidence": max(video_analysis.get("confidence", 0.8), audio_analysis.get("confidence", 0.8)),
            "analysis_time_seconds": round(analysis_time, 2),
            "timestamp": datetime.now().isoformat(),
            "compliance_status": "requires_review" if batch_status != "pass" else "compliant",
            "video_analysis": video_analysis,
            "audio_analysis": audio_analysis
        }
        
    except Exception as e:
        logger.error(f"Quality analysis error: {e}")
        raise HTTPException(status_code=500, detail=f"Quality analysis failed: {str(e)}")

@erp_quality_router.get("/alerts")
async def get_quality_alerts(limit: int = 50):
    """Get recent quality alerts"""
    return {
        "alerts": quality_alerts_db[-limit:],
        "total_count": len(quality_alerts_db),
        "timestamp": datetime.now().isoformat()
    }

@erp_quality_router.get("/batch/{batch_id}")
async def get_batch_status(batch_id: str):
    """Get quality status for a specific batch"""
    if batch_id not in batch_records_db:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    return {
        "batch_id": batch_id,
        **batch_records_db[batch_id],
        "timestamp": datetime.now().isoformat()
    }

@erp_quality_router.get("/dashboard")
async def quality_dashboard():
    """Quality control dashboard data"""
    now = datetime.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Calculate today's metrics
    today_alerts = [
        alert for alert in quality_alerts_db
        if datetime.fromisoformat(alert["timestamp"]) >= today_start
    ]
    
    total_batches = len(batch_records_db)
    passed_batches = len([b for b in batch_records_db.values() if b["status"] == "pass"])
    
    return {
        "summary": {
            "total_alerts_today": len(today_alerts),
            "critical_alerts": len([a for a in today_alerts if a["severity"] == "high"]),
            "total_batches": total_batches,
            "pass_rate": round((passed_batches / total_batches * 100) if total_batches > 0 else 100, 1),
            "avg_quality_score": round(
                sum(b["quality_score"] for b in batch_records_db.values()) / total_batches if total_batches > 0 else 0, 2
            )
        },
        "recent_alerts": today_alerts[-10:],
        "batch_status_counts": {
            "pass": len([b for b in batch_records_db.values() if b["status"] == "pass"]),
            "hold": len([b for b in batch_records_db.values() if b["status"] == "hold"]),
            "reject": len([b for b in batch_records_db.values() if b["status"] == "reject"])
        },
        "timestamp": now.isoformat()
    }

# Demo endpoint for testing
@erp_quality_router.post("/demo/cheese-scenario")
async def demo_cheese_scenario():
    """Demo the famous 'nasty cheese' scenario"""
    
    # Simulate the cheese defect detection
    mock_analysis = {
        "batch_id": "CHEESE-20250912-456",
        "batch_status": "reject",
        "alert_id": "QA-20250912175500",
        "severity": "high",
        "quality_score": 0.15,
        "defects_detected": 12,
        "audio_transcript": "nasty cheese in batch four five six looks contaminated",
        "detected_issues": {
            "defect": ["nasty", "contaminated"],
            "product": ["cheese"],
            "location": ["batch"]
        },
        "recommended_actions": [
            "Immediately quarantine entire batch CHEESE-20250912-456",
            "Notify FDA compliance team and initiate contamination protocol",
            "Test adjacent batches for cross-contamination",
            "Review temperature logs for cold chain integrity",
            "Conduct full sanitation of production line"
        ],
        "notifications_sent": [
            "qc@company.com",
            "supervisor@company.com", 
            "operations@company.com",
            "safety@company.com",
            "compliance@company.com",
            "fda-liaison@company.com"
        ],
        "confidence": 0.98,
        "analysis_time_seconds": 7.7,
        "compliance_status": "critical_violation"
    }
    
    # Add to alerts database
    alert_id = mock_analysis["alert_id"]
    alert = {
        "alert_id": alert_id,
        "severity": "high",
        "product_batch": mock_analysis["batch_id"],
        "defect_type": ["contamination", "spoilage"],
        "location": "Production Line 3",
        "timestamp": datetime.now().isoformat(),
        "notifications_sent": mock_analysis["notifications_sent"],
        "actions_required": mock_analysis["recommended_actions"],
        "confidence": 0.98
    }
    quality_alerts_db.append(alert)
    
    return {
        "demo_scenario": "Nasty Cheese Detection",
        "description": "AR camera detected visual contamination + voice confirmed 'nasty cheese'",
        "result": "CRITICAL QUALITY ALERT - Batch quarantined in 7.7 seconds",
        **mock_analysis,
        "productivity_gain": "95% faster than manual SAP entry (7.7s vs 5 minutes)",
        "cost_savings": "$50,000 prevented contamination spread",
        "timestamp": datetime.now().isoformat()
    }

__all__ = ["erp_quality_router"]