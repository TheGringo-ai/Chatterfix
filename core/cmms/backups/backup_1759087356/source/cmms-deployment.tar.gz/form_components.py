#!/usr/bin/env python3
"""
CMMS Standardized Form Components
Provides consistent form patterns with validation, error handling, and success feedback
"""

from typing import Dict, List, Optional, Any
import json

class FormComponents:
    """Standardized form components for CMMS modules"""
    
    @staticmethod
    def get_base_styles() -> str:
        """Base CSS styles for all forms"""
        return """
        <style>
        /* Form Container */
        .cmms-form {
            max-width: 600px;
            margin: 0 auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        /* Modal Forms */
        .cmms-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .cmms-modal-content {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
        }
        
        /* Form Fields */
        .cmms-field-group {
            margin-bottom: 1.5rem;
        }
        
        .cmms-field-group.cmms-field-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .cmms-label {
            display: block;
            font-weight: 600;
            color: #333;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }
        
        .cmms-label.required::after {
            content: ' *';
            color: #e74c3c;
        }
        
        .cmms-input,
        .cmms-select,
        .cmms-textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.875rem;
            transition: border-color 0.2s, box-shadow 0.2s;
            background: white;
            font-family: inherit;
        }
        
        .cmms-input:focus,
        .cmms-select:focus,
        .cmms-textarea:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        
        .cmms-textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        /* Validation States */
        .cmms-field-group.error .cmms-input,
        .cmms-field-group.error .cmms-select,
        .cmms-field-group.error .cmms-textarea {
            border-color: #e74c3c;
            box-shadow: 0 0 0 3px rgba(231, 76, 60, 0.1);
        }
        
        .cmms-field-group.success .cmms-input,
        .cmms-field-group.success .cmms-select,
        .cmms-field-group.success .cmms-textarea {
            border-color: #27ae60;
            box-shadow: 0 0 0 3px rgba(39, 174, 96, 0.1);
        }
        
        .cmms-error-message {
            color: #e74c3c;
            font-size: 0.75rem;
            margin-top: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .cmms-success-message {
            color: #27ae60;
            font-size: 0.75rem;
            margin-top: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .cmms-help-text {
            color: #666;
            font-size: 0.75rem;
            margin-top: 0.25rem;
        }
        
        /* Buttons */
        .cmms-button-group {
            display: flex;
            gap: 0.75rem;
            justify-content: flex-end;
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid #eee;
        }
        
        .cmms-btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.875rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s;
            min-width: 100px;
            justify-content: center;
        }
        
        .cmms-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .cmms-btn-primary {
            background: #3498db;
            color: white;
        }
        
        .cmms-btn-primary:hover:not(:disabled) {
            background: #2980b9;
            transform: translateY(-1px);
        }
        
        .cmms-btn-secondary {
            background: white;
            color: #333;
            border: 1px solid #ddd;
        }
        
        .cmms-btn-secondary:hover:not(:disabled) {
            background: #f8f9fa;
            border-color: #bbb;
        }
        
        .cmms-btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .cmms-btn-danger:hover:not(:disabled) {
            background: #c0392b;
        }
        
        /* Loading States */
        .cmms-btn.loading {
            position: relative;
            color: transparent;
        }
        
        .cmms-btn.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 16px;
            height: 16px;
            border: 2px solid currentColor;
            border-radius: 50%;
            border-top-color: transparent;
            animation: cmms-spin 0.8s linear infinite;
        }
        
        @keyframes cmms-spin {
            to { transform: translate(-50%, -50%) rotate(360deg); }
        }
        
        /* Form Alerts */
        .cmms-alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
        }
        
        .cmms-alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .cmms-alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .cmms-alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        
        .cmms-alert-info {
            background: #cce7f0;
            color: #055160;
            border: 1px solid #b6d4fe;
        }
        
        /* Close Button */
        .cmms-close-btn {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
        }
        
        .cmms-close-btn:hover {
            background: #f8f9fa;
            color: #333;
        }
        
        /* Mobile Responsive */
        @media (max-width: 768px) {
            .cmms-modal-content {
                width: 95%;
                padding: 1.5rem;
                margin: 1rem;
            }
            
            .cmms-field-group.cmms-field-row {
                grid-template-columns: 1fr;
            }
            
            .cmms-button-group {
                flex-direction: column-reverse;
            }
            
            .cmms-btn {
                width: 100%;
            }
        }
        </style>
        """
    
    @staticmethod
    def get_form_javascript() -> str:
        """JavaScript functions for form handling"""
        return """
        <script>
        // CMMS Form Handler Class
        class CMMSForm {
            constructor(formElement) {
                this.form = formElement;
                this.submitBtn = formElement.querySelector('.cmms-btn-primary');
                this.init();
            }
            
            init() {
                // Add event listeners
                this.form.addEventListener('submit', (e) => this.handleSubmit(e));
                
                // Add real-time validation
                const inputs = this.form.querySelectorAll('.cmms-input, .cmms-select, .cmms-textarea');
                inputs.forEach(input => {
                    input.addEventListener('blur', () => this.validateField(input));
                    input.addEventListener('input', () => this.clearFieldError(input));
                });
            }
            
            async handleSubmit(e) {
                e.preventDefault();
                
                // Validate all fields
                const isValid = this.validateForm();
                if (!isValid) return;
                
                // Show loading state
                this.setLoading(true);
                this.clearAlerts();
                
                try {
                    const formData = new FormData(this.form);
                    const data = Object.fromEntries(formData);
                    
                    // Get endpoint from form action or data attribute
                    const endpoint = this.form.action || this.form.dataset.endpoint;
                    const method = this.form.method || 'POST';
                    
                    const response = await fetch(endpoint, {
                        method: method,
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(data)
                    });
                    
                    const result = await response.json();
                    
                    if (response.ok) {
                        this.showSuccess(result.message || 'Operation completed successfully');
                        
                        // Close modal after delay if it's a modal form
                        if (this.form.closest('.cmms-modal')) {
                            setTimeout(() => {
                                this.closeModal();
                                if (typeof window.refreshData === 'function') {
                                    window.refreshData();
                                } else {
                                    location.reload();
                                }
                            }, 1500);
                        } else {
                            // Redirect or refresh for non-modal forms
                            setTimeout(() => {
                                if (result.redirect) {
                                    window.location.href = result.redirect;
                                } else {
                                    location.reload();
                                }
                            }, 1500);
                        }
                    } else {
                        throw new Error(result.detail || 'An error occurred');
                    }
                } catch (error) {
                    console.error('Form submission error:', error);
                    this.showError(error.message || 'An error occurred while processing your request');
                } finally {
                    this.setLoading(false);
                }
            }
            
            validateForm() {
                const inputs = this.form.querySelectorAll('.cmms-input, .cmms-select, .cmms-textarea');
                let isValid = true;
                
                inputs.forEach(input => {
                    if (!this.validateField(input)) {
                        isValid = false;
                    }
                });
                
                return isValid;
            }
            
            validateField(input) {
                const fieldGroup = input.closest('.cmms-field-group');
                const isRequired = input.hasAttribute('required');
                const value = input.value.trim();
                
                // Clear previous states
                fieldGroup.classList.remove('error', 'success');
                this.removeFieldMessage(fieldGroup);
                
                // Required field validation
                if (isRequired && !value) {
                    this.setFieldError(fieldGroup, 'This field is required');
                    return false;
                }
                
                // Email validation
                if (input.type === 'email' && value) {
                    const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
                    if (!emailRegex.test(value)) {
                        this.setFieldError(fieldGroup, 'Please enter a valid email address');
                        return false;
                    }
                }
                
                // Number validation
                if (input.type === 'number' && value) {
                    const min = input.getAttribute('min');
                    const max = input.getAttribute('max');
                    const numValue = parseFloat(value);
                    
                    if (min && numValue < parseFloat(min)) {
                        this.setFieldError(fieldGroup, `Value must be at least ${min}`);
                        return false;
                    }
                    
                    if (max && numValue > parseFloat(max)) {
                        this.setFieldError(fieldGroup, `Value must be no more than ${max}`);
                        return false;
                    }
                }
                
                // Custom validation patterns
                const pattern = input.getAttribute('pattern');
                if (pattern && value && !new RegExp(pattern).test(value)) {
                    const errorMsg = input.getAttribute('data-error-message') || 'Invalid format';
                    this.setFieldError(fieldGroup, errorMsg);
                    return false;
                }
                
                // Show success state for valid required fields
                if (isRequired && value) {
                    fieldGroup.classList.add('success');
                }
                
                return true;
            }
            
            setFieldError(fieldGroup, message) {
                fieldGroup.classList.add('error');
                const errorEl = document.createElement('div');
                errorEl.className = 'cmms-error-message';
                errorEl.innerHTML = `<span>⚠️</span> ${message}`;
                fieldGroup.appendChild(errorEl);
            }
            
            clearFieldError(input) {
                const fieldGroup = input.closest('.cmms-field-group');
                fieldGroup.classList.remove('error');
                this.removeFieldMessage(fieldGroup);
            }
            
            removeFieldMessage(fieldGroup) {
                const existing = fieldGroup.querySelector('.cmms-error-message, .cmms-success-message');
                if (existing) existing.remove();
            }
            
            setLoading(loading) {
                if (this.submitBtn) {
                    this.submitBtn.disabled = loading;
                    if (loading) {
                        this.submitBtn.classList.add('loading');
                    } else {
                        this.submitBtn.classList.remove('loading');
                    }
                }
            }
            
            showSuccess(message) {
                this.showAlert('success', message);
            }
            
            showError(message) {
                this.showAlert('error', message);
            }
            
            showAlert(type, message) {
                this.clearAlerts();
                const alert = document.createElement('div');
                alert.className = `cmms-alert cmms-alert-${type}`;
                
                const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
                alert.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
                
                this.form.insertBefore(alert, this.form.firstChild);
            }
            
            clearAlerts() {
                const alerts = this.form.querySelectorAll('.cmms-alert');
                alerts.forEach(alert => alert.remove());
            }
            
            closeModal() {
                const modal = this.form.closest('.cmms-modal');
                if (modal) {
                    modal.remove();
                }
            }
        }
        
        // Auto-initialize forms
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('.cmms-form');
            forms.forEach(form => new CMMSForm(form));
        });
        
        // Modal utilities
        window.CMMSModal = {
            show: function(content, options = {}) {
                const modal = document.createElement('div');
                modal.className = 'cmms-modal';
                modal.innerHTML = `
                    <div class="cmms-modal-content">
                        ${options.closable !== false ? '<button class="cmms-close-btn" onclick="CMMSModal.close(this)">×</button>' : ''}
                        ${content}
                    </div>
                `;
                
                // Close on background click
                if (options.closable !== false) {
                    modal.addEventListener('click', function(e) {
                        if (e.target === modal) {
                            CMMSModal.close(modal.querySelector('.cmms-close-btn'));
                        }
                    });
                }
                
                document.body.appendChild(modal);
                
                // Initialize forms in the modal
                const forms = modal.querySelectorAll('.cmms-form');
                forms.forEach(form => new CMMSForm(form));
                
                return modal;
            },
            
            close: function(btnElement) {
                const modal = btnElement.closest('.cmms-modal');
                if (modal) {
                    modal.remove();
                }
            }
        };
        </script>
        """
    
    @staticmethod
    def create_field(field_type: str, name: str, label: str, **kwargs) -> str:
        """Create a standardized form field"""
        required = kwargs.get('required', False)
        value = kwargs.get('value', '')
        placeholder = kwargs.get('placeholder', '')
        help_text = kwargs.get('help_text', '')
        options = kwargs.get('options', [])
        field_class = kwargs.get('field_class', '')
        
        required_class = 'required' if required else ''
        required_attr = 'required' if required else ''
        
        field_html = f'<div class="cmms-field-group {field_class}">'
        field_html += f'<label class="cmms-label {required_class}" for="{name}">{label}</label>'
        
        if field_type == 'text':
            extra_attrs = " ".join(f'{k}="{v}"' for k, v in kwargs.items() if k not in ["required", "value", "placeholder", "help_text", "options", "field_class"])
            field_html += f'<input type="text" id="{name}" name="{name}" class="cmms-input" value="{value}" placeholder="{placeholder}" {required_attr} {extra_attrs}/>'
        elif field_type == 'email':
            field_html += f'<input type="email" id="{name}" name="{name}" class="cmms-input" value="{value}" placeholder="{placeholder}" {required_attr}/>'
        elif field_type == 'number':
            extra_attrs = " ".join(f'{k}="{v}"' for k, v in kwargs.items() if k not in ["required", "value", "placeholder", "help_text", "options", "field_class"])
            field_html += f'<input type="number" id="{name}" name="{name}" class="cmms-input" value="{value}" placeholder="{placeholder}" {required_attr} {extra_attrs}/>'
        elif field_type == 'date':
            field_html += f'<input type="date" id="{name}" name="{name}" class="cmms-input" value="{value}" {required_attr}/>'
        elif field_type == 'textarea':
            field_html += f'<textarea id="{name}" name="{name}" class="cmms-textarea" placeholder="{placeholder}" {required_attr}>{value}</textarea>'
        elif field_type == 'select':
            field_html += f'<select id="{name}" name="{name}" class="cmms-select" {required_attr}>'
            if not required:
                field_html += '<option value="">Select an option</option>'
            for option in options:
                if isinstance(option, dict):
                    opt_value = option.get('value', '')
                    opt_label = option.get('label', opt_value)
                    selected = 'selected' if str(opt_value) == str(value) else ''
                else:
                    opt_value = option
                    opt_label = option
                    selected = 'selected' if str(opt_value) == str(value) else ''
                field_html += f'<option value="{opt_value}" {selected}>{opt_label}</option>'
            field_html += '</select>'
        
        if help_text:
            field_html += f'<div class="cmms-help-text">{help_text}</div>'
        
        field_html += '</div>'
        return field_html
    
    @staticmethod
    def create_form(title: str, fields: List[Dict], action: str, method: str = "POST", modal: bool = False) -> str:
        """Create a complete standardized form"""
        form_content = f"""
        <h2 style="margin: 0 0 1.5rem 0; color: #333; font-size: 1.25rem;">{title}</h2>
        <form class="cmms-form" data-endpoint="{action}" method="{method}">
        """
        
        for field in fields:
            form_content += FormComponents.create_field(**field)
        
        form_content += """
        <div class="cmms-button-group">
            <button type="button" class="cmms-btn cmms-btn-secondary" onclick="CMMSModal.close(this)">Cancel</button>
            <button type="submit" class="cmms-btn cmms-btn-primary">Submit</button>
        </div>
        </form>
        """
        
        if modal:
            return form_content
        else:
            return f"""
            {FormComponents.get_base_styles()}
            <div class="cmms-modal-content" style="max-width: 600px; margin: 2rem auto;">
                {form_content}
            </div>
            {FormComponents.get_form_javascript()}
            """

# Example usage functions for common CMMS forms
class CMMSForms:
    """Pre-built forms for common CMMS operations"""
    
    @staticmethod
    def work_order_form() -> str:
        """Create Work Order form"""
        fields = [
            {"field_type": "text", "name": "title", "label": "Work Order Title", "required": True, "placeholder": "Brief description of work needed"},
            {"field_type": "textarea", "name": "description", "label": "Description", "required": True, "help_text": "Detailed description of the work to be performed"},
            {"field_type": "select", "name": "asset_id", "label": "Asset", "required": True, "options": [
                {"value": "PUMP-001", "label": "Main Water Pump (PUMP-001)"},
                {"value": "MOTOR-002", "label": "Conveyor Motor (MOTOR-002)"},
                {"value": "HVAC-003", "label": "HVAC Unit A (HVAC-003)"}
            ]},
            {"field_type": "select", "name": "priority", "label": "Priority", "required": True, "options": [
                {"value": "critical", "label": "Critical"},
                {"value": "high", "label": "High"},
                {"value": "medium", "label": "Medium"},
                {"value": "low", "label": "Low"}
            ]},
            {"field_type": "select", "name": "type", "label": "Work Order Type", "required": True, "options": [
                {"value": "reactive", "label": "Reactive (Repair)"},
                {"value": "preventive", "label": "Preventive Maintenance"},
                {"value": "predictive", "label": "Predictive Maintenance"}
            ]},
            {"field_type": "select", "name": "assigned_to", "label": "Assign To", "options": [
                {"value": "TECH-001", "label": "John Smith"},
                {"value": "TECH-002", "label": "Mike Johnson"},
                {"value": "TECH-003", "label": "Sarah Davis"}
            ]},
            {"field_type": "date", "name": "due_date", "label": "Due Date"},
            {"field_type": "number", "name": "estimated_hours", "label": "Estimated Hours", "min": "0", "step": "0.5", "help_text": "Estimated time to complete this work order"}
        ]
        
        return FormComponents.create_form("Create Work Order", fields, "/workorders", modal=True)
    
    @staticmethod
    def asset_form() -> str:
        """Create Asset form"""
        fields = [
            {"field_type": "text", "name": "name", "label": "Asset Name", "required": True, "placeholder": "e.g., Main Water Pump"},
            {"field_type": "text", "name": "asset_id", "label": "Asset ID", "required": True, "placeholder": "e.g., PUMP-001", "pattern": "^[A-Z]+-[0-9]+$", "data-error-message": "Asset ID must be in format ABC-123"},
            {"field_type": "textarea", "name": "description", "label": "Description", "help_text": "Detailed description of the asset"},
            {"field_type": "select", "name": "category", "label": "Category", "required": True, "options": [
                {"value": "mechanical", "label": "Mechanical"},
                {"value": "electrical", "label": "Electrical"},
                {"value": "hvac", "label": "HVAC"},
                {"value": "plumbing", "label": "Plumbing"},
                {"value": "it", "label": "IT Equipment"}
            ]},
            {"field_type": "text", "name": "location", "label": "Location", "required": True, "placeholder": "Building/Room/Area"},
            {"field_type": "select", "name": "status", "label": "Status", "required": True, "value": "operational", "options": [
                {"value": "operational", "label": "Operational"},
                {"value": "maintenance", "label": "Under Maintenance"},
                {"value": "down", "label": "Down/Broken"},
                {"value": "retired", "label": "Retired"}
            ]},
            {"field_type": "select", "name": "criticality", "label": "Criticality", "required": True, "options": [
                {"value": "critical", "label": "Critical"},
                {"value": "high", "label": "High"},
                {"value": "medium", "label": "Medium"},
                {"value": "low", "label": "Low"}
            ]},
            {"field_type": "number", "name": "maintenance_frequency", "label": "Maintenance Frequency (days)", "value": "30", "min": "1", "max": "365", "help_text": "How often this asset requires maintenance"}
        ]
        
        return FormComponents.create_form("Create Asset", fields, "/assets", modal=True)
    
    @staticmethod
    def part_form() -> str:
        """Create Parts form"""
        fields = [
            {"field_type": "text", "name": "name", "label": "Part Name", "required": True, "placeholder": "e.g., Water Pump Bearing"},
            {"field_type": "text", "name": "part_number", "label": "Part Number", "required": True, "placeholder": "e.g., WPB-001"},
            {"field_type": "textarea", "name": "description", "label": "Description"},
            {"field_type": "select", "name": "category", "label": "Category", "required": True, "options": [
                {"value": "bearings", "label": "Bearings"},
                {"value": "belts", "label": "Belts"},
                {"value": "filters", "label": "Filters"},
                {"value": "gaskets", "label": "Gaskets"},
                {"value": "electrical", "label": "Electrical"},
                {"value": "hydraulic", "label": "Hydraulic"},
                {"value": "other", "label": "Other"}
            ]},
            {"field_type": "number", "name": "quantity", "label": "Current Quantity", "required": True, "min": "0", "value": "1"},
            {"field_type": "number", "name": "min_stock", "label": "Minimum Stock Level", "required": True, "min": "0", "value": "1", "help_text": "Reorder when quantity falls below this level"},
            {"field_type": "number", "name": "unit_cost", "label": "Unit Cost ($)", "required": True, "min": "0", "step": "0.01"},
            {"field_type": "text", "name": "supplier", "label": "Supplier", "placeholder": "Primary supplier name"},
            {"field_type": "text", "name": "location", "label": "Storage Location", "placeholder": "Warehouse/Shelf/Bin location"}
        ]
        
        return FormComponents.create_form("Add Part", fields, "/parts", modal=True)