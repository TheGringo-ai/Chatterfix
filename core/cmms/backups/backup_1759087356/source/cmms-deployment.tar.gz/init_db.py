#!/usr/bin/env python3
"""
Database Initialization Script
Creates database tables and initial data for ChatterFix CMMS
"""

import os
import sqlite3
import logging
from datetime import datetime, timedelta

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def init_database():
    """Initialize SQLite database with basic schema"""
    
    db_path = "cmms.db"
    
    # Create database and tables
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            role TEXT DEFAULT 'technician',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1
        )
    """)
    
    # Assets table (comprehensive schema to match application expectations)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            location TEXT NOT NULL,
            status TEXT DEFAULT 'operational',
            condition TEXT DEFAULT 'good',
            manufacturer TEXT,
            model TEXT,
            serial_number TEXT,
            installation_date TIMESTAMP,
            last_maintenance TIMESTAMP,
            next_maintenance TIMESTAMP,
            maintenance_frequency INTEGER DEFAULT 30,
            criticality TEXT DEFAULT 'medium',
            cost_center TEXT,
            specifications TEXT,
            parent_asset_id INTEGER,
            health_score REAL DEFAULT 8.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (parent_asset_id) REFERENCES assets (id)
        )
    """)
    
    # Work Orders table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS workorders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            asset_id INTEGER,
            status TEXT DEFAULT 'open',
            priority TEXT DEFAULT 'medium',
            assigned_to INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            due_date TIMESTAMP,
            FOREIGN KEY (asset_id) REFERENCES assets (id),
            FOREIGN KEY (assigned_to) REFERENCES users (id)
        )
    """)
    
    # Parts table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            part_number TEXT UNIQUE,
            category TEXT,
            quantity INTEGER DEFAULT 0,
            min_quantity INTEGER DEFAULT 5,
            unit_cost REAL DEFAULT 0.0,
            supplier TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Maintenance History table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS maintenance_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            work_order_id INTEGER,
            maintenance_type TEXT NOT NULL,
            description TEXT,
            technician_id INTEGER,
            cost REAL DEFAULT 0.0,
            duration_hours REAL DEFAULT 0.0,
            completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (asset_id) REFERENCES assets (id),
            FOREIGN KEY (work_order_id) REFERENCES workorders (id),
            FOREIGN KEY (technician_id) REFERENCES users (id)
        )
    """)
    
    logger.info("✅ Database tables created successfully")
    
    # Insert sample data
    insert_sample_data(cursor)
    
    conn.commit()
    conn.close()
    
    logger.info(f"✅ Database initialized: {db_path}")
    return db_path

def insert_sample_data(cursor):
    """Insert sample data for demonstration"""
    
    # Sample users
    users = [
        ('admin', 'admin@chatterfix.com', 'admin'),
        ('john_tech', 'john@chatterfix.com', 'technician'), 
        ('mary_manager', 'mary@chatterfix.com', 'manager'),
        ('bob_tech', 'bob@chatterfix.com', 'technician')
    ]
    
    cursor.executemany(
        "INSERT OR IGNORE INTO users (username, email, role) VALUES (?, ?, ?)",
        users
    )
    
    # Sample assets with comprehensive data
    assets = [
        ('HVAC Unit 1', 'HVAC', 'Building A - Floor 1', 'operational', 'good', 'Carrier', 'Model-AC100', 'SN001234', 'critical', 'CC-001', '{"capacity": "100 tons", "efficiency": "15 SEER"}', 9.2),
        ('Compressor 2A', 'Compressor', 'Production Floor', 'operational', 'good', 'Atlas Copco', 'GA-75', 'SN002345', 'high', 'CC-002', '{"pressure": "125 PSI", "flow": "415 CFM"}', 8.7),
        ('Generator Backup', 'Generator', 'Basement', 'operational', 'excellent', 'Caterpillar', 'C15-500kW', 'SN003456', 'critical', 'CC-003', '{"power": "500kW", "fuel": "diesel"}', 9.5),
        ('Conveyor Belt 1', 'Conveyor', 'Production Line 1', 'maintenance_due', 'fair', 'FlexLink', 'X85-2000', 'SN004567', 'medium', 'CC-004', '{"length": "20m", "speed": "0.5 m/s"}', 7.3),
        ('Pump Station 3', 'Pump', 'Utility Room', 'operational', 'good', 'Grundfos', 'CR15-3', 'SN005678', 'medium', 'CC-005', '{"flow": "15 m3/h", "head": "45m"}', 8.1),
        ('Elevator Main', 'Elevator', 'Main Building', 'operational', 'good', 'Otis', 'Gen2-Premier', 'SN006789', 'high', 'CC-006', '{"capacity": "2500 lbs", "floors": "8"}', 8.9),
        ('Fire Suppression', 'Safety', 'Building Wide', 'operational', 'excellent', 'Tyco', 'CPVC-Sprinkler', 'SN007890', 'critical', 'CC-007', '{"coverage": "full building", "type": "wet system"}', 9.8),
        ('Boiler Room 1', 'Boiler', 'Basement', 'inspection_due', 'good', 'Cleaver Brooks', 'CB-200', 'SN008901', 'high', 'CC-008', '{"capacity": "200 HP", "fuel": "natural gas"}', 7.8)
    ]
    
    cursor.executemany(
        "INSERT OR IGNORE INTO assets (name, category, location, status, condition, manufacturer, model, serial_number, criticality, cost_center, specifications, health_score) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        assets
    )
    
    # Sample parts
    parts = [
        ('Air Filter', 'AF-001', 'Filters', 15, 5, 12.50, 'FilterCorp'),
        ('Compressor Oil', 'CO-002', 'Lubricants', 8, 3, 45.00, 'OilTech'),
        ('Drive Belt', 'DB-003', 'Belts', 12, 4, 23.75, 'BeltSupply'),
        ('Bearing Set', 'BS-004', 'Bearings', 6, 2, 67.50, 'BearingPro'),
        ('Gasket Kit', 'GK-005', 'Seals', 20, 8, 15.25, 'SealTech')
    ]
    
    cursor.executemany(
        "INSERT OR IGNORE INTO parts (name, part_number, category, quantity, min_quantity, unit_cost, supplier) VALUES (?, ?, ?, ?, ?, ?, ?)",
        parts
    )
    
    # Sample work orders
    now = datetime.now()
    future_date = now + timedelta(days=7)
    
    workorders = [
        ('HVAC Filter Replacement', 'Replace air filters in HVAC Unit 1', 1, 'open', 'medium', 2, future_date),
        ('Compressor Maintenance', 'Scheduled quarterly maintenance for Compressor 2A', 2, 'in_progress', 'high', 4, future_date),
        ('Conveyor Belt Inspection', 'Monthly safety inspection of conveyor system', 4, 'open', 'medium', 2, future_date),
        ('Pump Station Service', 'Annual service and calibration', 5, 'scheduled', 'low', 4, future_date)
    ]
    
    cursor.executemany(
        "INSERT OR IGNORE INTO workorders (title, description, asset_id, status, priority, assigned_to, due_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
        workorders
    )
    
    # Sample maintenance history
    history = [
        (1, 1, 'preventive', 'Filter replacement completed successfully', 2, 45.50, 2.0),
        (2, 2, 'repair', 'Fixed oil leak and replaced seals', 4, 134.75, 4.5),
        (3, None, 'inspection', 'Monthly safety inspection passed', 2, 0.0, 1.0),
        (5, 4, 'preventive', 'Pump calibration and service completed', 4, 89.25, 3.5)
    ]
    
    cursor.executemany(
        "INSERT OR IGNORE INTO maintenance_history (asset_id, work_order_id, maintenance_type, description, technician_id, cost, duration_hours) VALUES (?, ?, ?, ?, ?, ?, ?)",
        history
    )
    
    logger.info("✅ Sample data inserted successfully")

if __name__ == "__main__":
    print("🗄️  Initializing ChatterFix CMMS Database...")
    db_path = init_database()
    print(f"✅ Database ready: {db_path}")
    print("🚀 You can now start the CMMS application with: python3 main.py")