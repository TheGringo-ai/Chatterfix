"""
Intent Router API Endpoints for ChatterFix CMMS
FastAPI endpoints for processing voice commands and natural language requests.
"""

from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import logging
import asyncio
from datetime import datetime

try:
    from nl_router import NaturalLanguageRouter, IntentType, EntityType
    NL_AVAILABLE = True
except ImportError:
    NL_AVAILABLE = False
    logging.warning("Natural Language Router not available")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/ai", tags=["voice", "natural-language", "intent"])

# Global NL router instance
nl_router = None

def get_nl_router():
    """Dependency to get NL router instance"""
    global nl_router
    if nl_router is None and NL_AVAILABLE:
        nl_router = NaturalLanguageRouter()
    return nl_router

# =============================================================================
# Request/Response Models
# =============================================================================

class VoiceCommandRequest(BaseModel):
    """Request model for voice commands"""
    command: str = Field(..., description="Voice command or natural language text")
    user_id: Optional[str] = Field(None, description="User ID for context")
    session_id: Optional[str] = Field(None, description="Session ID for conversation tracking")
    voice_enabled: bool = Field(True, description="Enable TTS response")

class IntentParseResponse(BaseModel):
    """Response model for intent parsing only"""
    intent: str
    entities: List[Dict[str, Any]]
    confidence: float
    original_text: str
    processing_time_ms: int

class VoiceCommandResponse(BaseModel):
    """Response model for voice command execution"""
    success: bool
    intent_processed: bool
    action_taken: str
    confirmation_message: str
    tts_confirmation: Optional[Dict[str, Any]]
    result_data: Optional[Dict[str, Any]]
    error_message: Optional[str]
    processing_time_ms: int
    timestamp: str

class CapabilitiesResponse(BaseModel):
    """Response model for system capabilities"""
    supported_intents: List[str]
    supported_entities: List[str] 
    sample_commands: List[str]
    voice_enabled: bool
    tts_enabled: bool

# =============================================================================
# API Endpoints
# =============================================================================

@router.post("/intent", response_model=VoiceCommandResponse)
async def process_voice_command(
    request: VoiceCommandRequest
):
    """
    Process voice command or natural language text into CMMS actions.
    
    This is the main endpoint for voice/NL processing. It:
    1. Parses the natural language command
    2. Extracts intent and entities
    3. Routes to appropriate CMMS action
    4. Returns confirmation with optional TTS
    """
    if not NL_AVAILABLE:
        raise HTTPException(
            status_code=503,
            detail="Natural Language processing is not available"
        )
    
    try:
        logger.info(f"Processing command: {request.command}")
        
        router_instance = get_nl_router()
        if not router_instance:
            raise HTTPException(status_code=503, detail="NL Router not initialized")
        
        # Process the voice command
        result = await router_instance.process_voice_command(request.command)
        
        # Disable TTS if requested
        if not request.voice_enabled:
            result["tts_confirmation"] = {"tts_enabled": False}
        
        return VoiceCommandResponse(**result)
        
    except Exception as e:
        logger.error(f"Error processing voice command: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Voice command processing failed: {str(e)}"
        )

@router.get("/intent/parse", response_model=IntentParseResponse)
async def parse_intent_only(
    q: str = Query(..., description="Text to parse for intent")
):
    """
    Parse intent and entities from text without executing actions.
    Useful for testing and command preview.
    """
    if not NL_AVAILABLE:
        raise HTTPException(
            status_code=503,
            detail="Natural Language processing is not available"
        )
    
    try:
        start_time = datetime.now()
        
        router_instance = get_nl_router()
        if not router_instance:
            raise HTTPException(status_code=503, detail="NL Router not initialized")
        
        # Just parse, don't execute
        intent = router_instance.action_router.intent_classifier.classify_intent(q)
        
        processing_time = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return IntentParseResponse(
            intent=intent.intent.value,
            entities=[{
                "type": e.type.value,
                "value": e.value,
                "confidence": e.confidence,
                "start_pos": e.start_pos,
                "end_pos": e.end_pos,
                "normalized_value": str(e.normalized_value) if e.normalized_value else None
            } for e in intent.entities],
            confidence=intent.confidence,
            original_text=intent.original_text,
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.error(f"Error parsing intent: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Intent parsing failed: {str(e)}"
        )

@router.get("/capabilities", response_model=CapabilitiesResponse)
async def get_voice_capabilities():
    """
    Get system capabilities and sample commands for UI.
    Used by frontend to show available voice commands.
    """
    if not NL_AVAILABLE:
        return CapabilitiesResponse(
            supported_intents=[],
            supported_entities=[],
            sample_commands=["Natural Language processing not available"],
            voice_enabled=False,
            tts_enabled=False
        )
    
    try:
        router_instance = get_nl_router()
        if not router_instance:
            raise HTTPException(status_code=503, detail="NL Router not initialized")
        
        capabilities = router_instance.get_capabilities()
        return CapabilitiesResponse(**capabilities)
        
    except Exception as e:
        logger.error(f"Error getting capabilities: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get capabilities: {str(e)}"
        )

# =============================================================================
# Testing and Demo Endpoints
# =============================================================================

@router.post("/intent/test")
async def test_voice_commands():
    """Test endpoint with sample commands for demo"""
    if not NL_AVAILABLE:
        return {
            "error": "Natural Language processing not available",
            "test_results": [],
            "total_commands": 0,
            "successful": 0
        }
    
    test_commands = [
        "Create a high-priority work order for Pump-12 tomorrow",
        "What parts need reordering this week?",
        "Export last month's completed PMs to PDF",
        "List all open work orders",
        "Show me Motor-X maintenance history"
    ]
    
    results = []
    router_instance = get_nl_router()
    
    if not router_instance:
        return {
            "error": "NL Router not initialized",
            "test_results": [],
            "total_commands": len(test_commands),
            "successful": 0
        }
    
    for command in test_commands:
        try:
            result = await router_instance.process_voice_command(command)
            results.append({
                "command": command,
                "success": result["success"],
                "action": result["action_taken"],
                "confirmation": result["confirmation_message"]
            })
        except Exception as e:
            results.append({
                "command": command,
                "success": False,
                "error": str(e)
            })
    
    return {
        "test_results": results,
        "total_commands": len(test_commands),
        "successful": sum(1 for r in results if r.get("success", False))
    }

@router.get("/tts/{text}")
async def text_to_speech(text: str):
    """Mock TTS endpoint - returns audio metadata"""
    return {
        "text": text,
        "audio_url": f"/api/audio/tts/{hash(text) % 10000}.mp3",
        "duration_ms": len(text) * 80,
        "voice": "en-US-Standard-A",
        "format": "mp3"
    }

# =============================================================================
# Health and Status
# =============================================================================

@router.get("/intent/health")
async def voice_system_health():
    """Health check for voice/NL system"""
    if not NL_AVAILABLE:
        return {
            "status": "unavailable",
            "error": "Natural Language processing not available",
            "timestamp": datetime.now().isoformat()
        }
    
    try:
        router_instance = get_nl_router()
        
        if not router_instance:
            return {
                "status": "unhealthy",
                "error": "NL Router not initialized",
                "timestamp": datetime.now().isoformat()
            }
        
        # Quick test of core functionality
        test_result = await router_instance.process_voice_command("test command")
        
        return {
            "status": "healthy",
            "nlp_model_loaded": True,
            "intent_classifier_ready": True,
            "tts_enabled": router_instance.tts.enabled,
            "test_processing_ms": test_result.get("processing_time_ms", 0),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

# Export router
__all__ = ["router"]