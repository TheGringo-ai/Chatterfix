#!/usr/bin/env python3
"""
Rate-limited Llama Runner
Safely executes llama operations with built-in rate limiting and crash prevention
"""

import asyncio
import time
import subprocess
import sys
import os
import json
from typing import Optional, Dict, Any
from dataclasses import dataclass
import signal
import threading
from pathlib import Path

@dataclass
class LlamaConfig:
    """Configuration for llama operations"""
    max_requests_per_minute: int = 10
    max_concurrent_requests: int = 2
    timeout_seconds: int = 60
    retry_attempts: int = 3
    retry_delay: int = 5
    model: str = "llama3.2"

class RateLimitedLlamaRunner:
    """Rate-limited llama runner with crash prevention"""
    
    def __init__(self, config: Optional[LlamaConfig] = None):
        self.config = config or LlamaConfig()
        self.request_times = []
        self.active_requests = 0
        self.lock = threading.Lock()
        self.shutdown_requested = False
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        print(f"\nReceived signal {signum}, shutting down gracefully...")
        self.shutdown_requested = True
    
    def _cleanup_old_requests(self):
        """Remove request timestamps older than 1 minute"""
        now = time.time()
        self.request_times = [t for t in self.request_times if now - t < 60]
    
    def _can_make_request(self) -> bool:
        """Check if we can make a new request based on rate limits"""
        with self.lock:
            self._cleanup_old_requests()
            
            # Check concurrent request limit
            if self.active_requests >= self.config.max_concurrent_requests:
                return False
            
            # Check rate limit
            if len(self.request_times) >= self.config.max_requests_per_minute:
                return False
            
            return True
    
    def _record_request(self):
        """Record a new request timestamp"""
        with self.lock:
            self.request_times.append(time.time())
            self.active_requests += 1
    
    def _finish_request(self):
        """Mark a request as finished"""
        with self.lock:
            self.active_requests = max(0, self.active_requests - 1)
    
    def _wait_for_rate_limit(self):
        """Wait until we can make a request"""
        while not self._can_make_request() and not self.shutdown_requested:
            time.sleep(1)
            
            # Calculate wait time
            with self.lock:
                self._cleanup_old_requests()
                if self.request_times:
                    oldest_request = min(self.request_times)
                    wait_time = 60 - (time.time() - oldest_request)
                    if wait_time > 0:
                        print(f"Rate limit reached. Waiting {wait_time:.1f}s...")
    
    def run_llama_command(self, prompt: str, additional_args: list = None) -> Dict[str, Any]:
        """
        Run llama command with rate limiting and error handling
        
        Args:
            prompt: The prompt to send to llama
            additional_args: Additional command line arguments
            
        Returns:
            Dict with status, output, error, and metadata
        """
        if self.shutdown_requested:
            return {"status": "cancelled", "error": "Shutdown requested"}
        
        # Wait for rate limit
        self._wait_for_rate_limit()
        
        if self.shutdown_requested:
            return {"status": "cancelled", "error": "Shutdown requested"}
        
        # Record request
        self._record_request()
        
        try:
            return self._execute_llama_with_retry(prompt, additional_args)
        finally:
            self._finish_request()
    
    def _execute_llama_with_retry(self, prompt: str, additional_args: list = None) -> Dict[str, Any]:
        """Execute llama command with retry logic"""
        additional_args = additional_args or []
        
        for attempt in range(self.config.retry_attempts):
            if self.shutdown_requested:
                return {"status": "cancelled", "error": "Shutdown requested"}
            
            try:
                result = self._execute_llama_once(prompt, additional_args)
                
                if result["status"] == "success":
                    return result
                
                # If it's a rate limit or timeout error, wait before retry
                if attempt < self.config.retry_attempts - 1:
                    wait_time = self.config.retry_delay * (attempt + 1)
                    print(f"Attempt {attempt + 1} failed, retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    return result
                    
            except Exception as e:
                if attempt < self.config.retry_attempts - 1:
                    wait_time = self.config.retry_delay * (attempt + 1)
                    print(f"Attempt {attempt + 1} failed with error: {e}, retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    return {
                        "status": "error",
                        "error": f"All retry attempts failed. Last error: {str(e)}",
                        "output": "",
                        "attempt": attempt + 1
                    }
        
        return {"status": "error", "error": "Maximum retry attempts exceeded"}
    
    def _execute_llama_once(self, prompt: str, additional_args: list = None) -> Dict[str, Any]:
        """Execute llama command once with timeout"""
        additional_args = additional_args or []
        
        # Build command
        cmd = ["ollama", "run", self.config.model] + additional_args + [prompt]
        
        start_time = time.time()
        
        try:
            # Run with timeout
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.config.timeout_seconds,
                check=False
            )
            
            end_time = time.time()
            execution_time = end_time - start_time
            
            if result.returncode == 0:
                return {
                    "status": "success",
                    "output": result.stdout.strip(),
                    "error": result.stderr.strip() if result.stderr else "",
                    "execution_time": execution_time,
                    "command": " ".join(cmd)
                }
            else:
                return {
                    "status": "error",
                    "output": result.stdout.strip() if result.stdout else "",
                    "error": result.stderr.strip() if result.stderr else f"Command failed with return code {result.returncode}",
                    "execution_time": execution_time,
                    "return_code": result.returncode,
                    "command": " ".join(cmd)
                }
                
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "error": f"Command timed out after {self.config.timeout_seconds} seconds",
                "output": "",
                "execution_time": self.config.timeout_seconds,
                "command": " ".join(cmd)
            }
        except Exception as e:
            return {
                "status": "error",
                "error": f"Execution failed: {str(e)}",
                "output": "",
                "execution_time": time.time() - start_time,
                "command": " ".join(cmd)
            }
    
    def analyze_middleware_files(self, cmms_path: str) -> Dict[str, Any]:
        """Analyze middleware files in the CMMS directory"""
        middleware_prompt = f"""
        Analyze the middleware-related Python files in {cmms_path} and provide specific recommendations for:
        
        1. Rate limiting improvements
        2. Error handling enhancements  
        3. Security hardening
        4. Performance optimizations
        5. Memory management
        
        Focus on files that handle HTTP requests, authentication, and API endpoints.
        Provide specific code suggestions and identify potential crash points.
        Keep the response concise and actionable.
        """
        
        return self.run_llama_command(middleware_prompt)
    
    def fix_specific_middleware_issue(self, file_path: str, issue_description: str) -> Dict[str, Any]:
        """Get specific fix recommendations for a middleware issue"""
        fix_prompt = f"""
        For the file {file_path}, analyze this specific issue: {issue_description}
        
        Provide:
        1. Root cause analysis
        2. Specific code fix
        3. Testing recommendations
        4. Prevention strategies
        
        Be concise and provide implementable solutions.
        """
        
        return self.run_llama_command(fix_prompt)

def main():
    """Main entry point for the rate-limited llama runner"""
    if len(sys.argv) < 2:
        print("Usage: python llama_rate_limited_runner.py <prompt> [additional_args...]")
        sys.exit(1)
    
    prompt = sys.argv[1]
    additional_args = sys.argv[2:] if len(sys.argv) > 2 else []
    
    # Create runner with custom config
    config = LlamaConfig(
        max_requests_per_minute=5,  # Conservative limit
        max_concurrent_requests=1,   # Only one at a time
        timeout_seconds=30,          # Shorter timeout
        retry_attempts=2             # Fewer retries
    )
    
    runner = RateLimitedLlamaRunner(config)
    
    print(f"Running llama with rate limiting: {prompt[:50]}...")
    result = runner.run_llama_command(prompt, additional_args)
    
    # Print results
    print(f"\nStatus: {result['status']}")
    if result.get('output'):
        print(f"Output:\n{result['output']}")
    if result.get('error'):
        print(f"Error: {result['error']}")
    if result.get('execution_time'):
        print(f"Execution time: {result['execution_time']:.2f}s")
    
    # Return appropriate exit code
    if result['status'] == 'success':
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()