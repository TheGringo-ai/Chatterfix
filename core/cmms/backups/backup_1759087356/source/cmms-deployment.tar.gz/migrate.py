#!/usr/bin/env python3
"""
Database migration runner for CMMS deployment.
Runs Alembic migrations to ensure database schema is up to date.
"""

import os
import sys
import logging
from alembic.config import Config
from alembic import command
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("migrate")

def run_migrations():
    """Run database migrations to head."""
    try:
        # Ensure we're in the right directory
        script_dir = Path(__file__).parent.absolute()
        os.chdir(script_dir)
        
        # Load Alembic configuration
        alembic_cfg = Config("alembic.ini")
        
        # Set database URL if provided via environment
        database_url = os.getenv("DATABASE_URL", "sqlite:///./cmms.db")
        alembic_cfg.set_main_option("sqlalchemy.url", database_url)
        
        logger.info(f"Starting database migration to head...")
        logger.info(f"Database URL: {database_url}")
        
        # Check current revision
        try:
            from alembic.runtime.migration import MigrationContext
            from sqlalchemy import create_engine
            
            engine = create_engine(database_url)
            with engine.connect() as connection:
                context = MigrationContext.configure(connection)
                current_rev = context.get_current_revision()
                logger.info(f"Current database revision: {current_rev}")
        except Exception as e:
            logger.info(f"Could not determine current revision (new database?): {e}")
        
        # Run migration to head
        command.upgrade(alembic_cfg, "head")
        
        # Check new revision
        try:
            with engine.connect() as connection:
                context = MigrationContext.configure(connection)
                new_rev = context.get_current_revision()
                logger.info(f"New database revision: {new_rev}")
        except Exception as e:
            logger.warning(f"Could not determine new revision: {e}")
        
        logger.info("✅ Database migration completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"❌ Database migration failed: {e}")
        return False

def check_current_revision():
    """Check current database revision."""
    try:
        script_dir = Path(__file__).parent.absolute()
        os.chdir(script_dir)
        
        alembic_cfg = Config("alembic.ini")
        database_url = os.getenv("DATABASE_URL", "sqlite:///./cmms.db")
        alembic_cfg.set_main_option("sqlalchemy.url", database_url)
        
        from alembic.runtime.migration import MigrationContext
        from sqlalchemy import create_engine
        
        engine = create_engine(database_url)
        with engine.connect() as connection:
            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()
            
            # Get head revision
            from alembic.script import ScriptDirectory
            script = ScriptDirectory.from_config(alembic_cfg)
            head_rev = script.get_current_head()
            
            print(f"Current revision: {current_rev}")
            print(f"Head revision: {head_rev}")
            print(f"Up to date: {'Yes' if current_rev == head_rev else 'No'}")
            
            return current_rev == head_rev
            
    except Exception as e:
        logger.error(f"Error checking revision: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        success = check_current_revision()
        sys.exit(0 if success else 1)
    else:
        success = run_migrations()
        sys.exit(0 if success else 1)