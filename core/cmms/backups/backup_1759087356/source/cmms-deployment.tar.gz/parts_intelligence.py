#!/usr/bin/env python3
"""
Advanced Parts Intelligence and Inventory Management System
AI-powered parts lookup, inventory optimization, and predictive ordering
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import re
from ai_model_provider import CentralizedAIProvider, AIResponse, AIProvider

logger = logging.getLogger(__name__)

# Parts router
parts_router = APIRouter(prefix="/parts", tags=["parts"])

class StockStatus(Enum):
    """Stock status enumeration"""
    IN_STOCK = "in_stock"
    LOW_STOCK = "low_stock"
    OUT_OF_STOCK = "out_of_stock"
    OVERSTOCKED = "overstocked"
    REORDER_NEEDED = "reorder_needed"

class PartCategory(Enum):
    """Part category enumeration"""
    MECHANICAL = "mechanical"
    ELECTRICAL = "electrical"
    HYDRAULIC = "hydraulic"
    PNEUMATIC = "pneumatic"
    STRUCTURAL = "structural"
    CONSUMABLE = "consumable"
    SAFETY = "safety"
    TOOL = "tool"

@dataclass
class PartRecord:
    """Enhanced part record with AI insights"""
    part_number: str
    description: str
    category: PartCategory
    stock_quantity: int
    reorder_point: int
    max_stock_level: int
    unit_cost: float
    supplier: str
    lead_time_days: int
    compatible_assets: List[str]
    alternative_parts: List[str] = field(default_factory=list)
    usage_frequency: float = 0.0  # Parts used per month
    criticality_score: float = 0.5  # 0-1 scale
    last_ordered_date: Optional[str] = None
    last_used_date: Optional[str] = None
    shelf_life_days: Optional[int] = None
    storage_location: Optional[str] = None
    manufacturer: Optional[str] = None
    specifications: Dict[str, str] = field(default_factory=dict)
    maintenance_notes: List[str] = field(default_factory=list)

class PartsSearchRequest(BaseModel):
    """Parts search request model"""
    query: str
    asset_id: Optional[str] = None
    category: Optional[str] = None
    max_results: int = 10
    include_alternatives: bool = True

class InventoryAnalysisRequest(BaseModel):
    """Inventory analysis request"""
    analysis_type: str = "full"  # full, low_stock, reorder, optimization
    asset_filter: Optional[List[str]] = None
    category_filter: Optional[List[str]] = None
    time_horizon_days: int = 30

class PartsIntelligenceSystem:
    """Advanced AI-powered parts intelligence system"""
    
    def __init__(self, ai_provider: Optional[CentralizedAIProvider] = None):
        self.ai_provider = ai_provider or CentralizedAIProvider()
        self.parts_database = self._initialize_parts_database()
        self.usage_patterns = self._load_usage_patterns()
        self.supplier_catalog = self._load_supplier_catalog()
        self.cross_reference_db = self._load_cross_references()
        
    def _initialize_parts_database(self) -> Dict[str, PartRecord]:
        """Initialize comprehensive parts database"""
        return {
            "ms_fm150_01": PartRecord(
                part_number="MS-FM150-01",
                description="Mechanical Seal for FlowMax FM-150 Centrifugal Pump",
                category=PartCategory.MECHANICAL,
                stock_quantity=5,
                reorder_point=2,
                max_stock_level=10,
                unit_cost=125.50,
                supplier="SealCorp Industries",
                lead_time_days=7,
                compatible_assets=["pump_3", "pump_4", "pump_7"],
                alternative_parts=["MS-GENERIC-150", "MS-FLOWMAX-ALT"],
                usage_frequency=2.5,  # 2.5 seals per month
                criticality_score=0.9,  # High criticality
                last_ordered_date="2025-08-15",
                last_used_date="2025-09-01",
                storage_location="A-3-15",
                manufacturer="FlowMax/SealCorp",
                specifications={
                    "shaft_diameter": "50mm",
                    "operating_pressure": "16 bar",
                    "temperature_range": "-20°C to +120°C",
                    "material": "Carbon/Silicon Carbide"
                },
                maintenance_notes=[
                    "Check seal faces for wear during installation",
                    "Use proper seal installation tool",
                    "Apply thin layer of compatible lubricant"
                ]
            ),
            
            "belt_bc2000_02": PartRecord(
                part_number="BELT-BC2000-02",
                description="Drive Belt for BeltCorp BC-2000 Conveyor System",
                category=PartCategory.MECHANICAL,
                stock_quantity=2,
                reorder_point=1,
                max_stock_level=4,
                unit_cost=450.00,
                supplier="BeltCorp Manufacturing",
                lead_time_days=14,
                compatible_assets=["conveyor_belt_1", "conveyor_belt_2"],
                alternative_parts=["BELT-GENERIC-2000", "BELT-Continental-2K"],
                usage_frequency=0.8,  # 0.8 belts per month
                criticality_score=0.95,  # Critical for production
                last_ordered_date="2025-07-20",
                storage_location="B-2-08",
                manufacturer="BeltCorp",
                specifications={
                    "width": "1200mm",
                    "thickness": "15mm",
                    "tensile_strength": "2000 N/mm",
                    "material": "Multi-ply fabric with rubber coating"
                },
                maintenance_notes=[
                    "Check belt tension after installation",
                    "Verify proper tracking alignment",
                    "Inspect splice joint integrity"
                ]
            ),
            
            "valve_pv_st500": PartRecord(
                part_number="PV-ST500-03",
                description="Safety Pressure Relief Valve for SteamTech ST-500 Boiler",
                category=PartCategory.SAFETY,
                stock_quantity=1,
                reorder_point=1,
                max_stock_level=2,
                unit_cost=275.00,
                supplier="SteamTech Components",
                lead_time_days=10,
                compatible_assets=["boiler_2"],
                usage_frequency=0.2,  # 0.2 valves per month (rare replacement)
                criticality_score=1.0,  # Maximum criticality - safety device
                last_ordered_date="2025-06-10",
                storage_location="C-1-03",
                manufacturer="SteamTech",
                specifications={
                    "set_pressure": "15 bar",
                    "inlet_size": "DN50",
                    "capacity": "5000 kg/hr steam",
                    "material": "Stainless Steel 316"
                },
                maintenance_notes=[
                    "Annual calibration required",
                    "Do not disassemble - return to manufacturer",
                    "Test lift function quarterly"
                ]
            ),
            
            "bearing_skf_6308": PartRecord(
                part_number="SKF-6308-2RS",
                description="Deep Groove Ball Bearing SKF 6308-2RS",
                category=PartCategory.MECHANICAL,
                stock_quantity=12,
                reorder_point=5,
                max_stock_level=20,
                unit_cost=45.75,
                supplier="SKF Bearings",
                lead_time_days=5,
                compatible_assets=["motor_1", "motor_2", "motor_3", "fan_1", "fan_2"],
                alternative_parts=["FAG-6308-2RS", "TIMKEN-6308-2RS"],
                usage_frequency=4.2,  # 4.2 bearings per month
                criticality_score=0.8,
                last_ordered_date="2025-09-05",
                last_used_date="2025-09-10",
                storage_location="A-1-22",
                manufacturer="SKF",
                specifications={
                    "inner_diameter": "40mm",
                    "outer_diameter": "90mm",
                    "width": "23mm",
                    "seal_type": "2RS (double rubber seal)",
                    "dynamic_load_rating": "41000 N"
                }
            ),
            
            # Consumables
            "oil_mobil_dte24": PartRecord(
                part_number="MOBIL-DTE24-208L",
                description="Mobil DTE 24 Hydraulic Oil - 208L Drum",
                category=PartCategory.CONSUMABLE,
                stock_quantity=8,
                reorder_point=3,
                max_stock_level=15,
                unit_cost=325.00,
                supplier="Mobil Industrial",
                lead_time_days=3,
                compatible_assets=["hydraulic_system_1", "hydraulic_system_2", "press_1"],
                usage_frequency=2.1,  # 2.1 drums per month
                criticality_score=0.7,
                shelf_life_days=1825,  # 5 years
                storage_location="D-1-BULK",
                manufacturer="ExxonMobil",
                specifications={
                    "viscosity_40c": "46 cSt",
                    "viscosity_index": "98",
                    "flash_point": "230°C",
                    "pour_point": "-30°C"
                },
                maintenance_notes=[
                    "Store in dry, cool location",
                    "Check for water contamination",
                    "Use proper transfer equipment"
                ]
            )
        }
    
    def _load_usage_patterns(self) -> Dict[str, Dict]:
        """Load historical usage patterns for predictive analysis"""
        return {
            "seasonal_patterns": {
                "summer": {"motors": 1.3, "pumps": 1.5, "belts": 1.2},
                "winter": {"motors": 0.8, "pumps": 0.9, "belts": 1.1},
                "spring": {"motors": 1.1, "pumps": 1.2, "belts": 1.4},
                "fall": {"motors": 1.0, "pumps": 1.0, "belts": 1.0}
            },
            "maintenance_cycles": {
                "quarterly": ["filters", "oils", "seals"],
                "semi_annual": ["bearings", "belts"],
                "annual": ["major_overhauls", "safety_valves"]
            },
            "failure_rates": {
                "mechanical_seals": {"mtbf_days": 180, "std_dev": 45},
                "bearings": {"mtbf_days": 365, "std_dev": 90},
                "belts": {"mtbf_days": 450, "std_dev": 120}
            }
        }
    
    def _load_supplier_catalog(self) -> Dict[str, Dict]:
        """Load supplier information and capabilities"""
        return {
            "SealCorp Industries": {
                "lead_time_days": 7,
                "minimum_order": 1,
                "discount_tiers": {100: 0.05, 500: 0.10, 1000: 0.15},
                "reliability_score": 0.95,
                "emergency_service": True,
                "specialties": ["mechanical_seals", "gaskets", "o_rings"]
            },
            "BeltCorp Manufacturing": {
                "lead_time_days": 14,
                "minimum_order": 1,
                "discount_tiers": {5: 0.03, 10: 0.07, 20: 0.12},
                "reliability_score": 0.90,
                "emergency_service": False,
                "specialties": ["conveyor_belts", "timing_belts", "v_belts"]
            },
            "SKF Bearings": {
                "lead_time_days": 5,
                "minimum_order": 1,
                "discount_tiers": {50: 0.08, 100: 0.15, 500: 0.25},
                "reliability_score": 0.98,
                "emergency_service": True,
                "specialties": ["bearings", "seals", "lubrication_systems"]
            }
        }
    
    def _load_cross_references(self) -> Dict[str, List[str]]:
        """Load cross-reference database for alternative parts"""
        return {
            "MS-FM150-01": ["MS-GENERIC-150", "JOHN-CRANE-150", "BURGMANN-M150"],
            "SKF-6308-2RS": ["FAG-6308-2RS", "TIMKEN-6308-2RS", "NSK-6308-2RS"],
            "BELT-BC2000-02": ["CONTINENTAL-CB2000", "GATES-CB2K", "OPTIBELT-2000"]
        }

    async def intelligent_parts_search(self, request: PartsSearchRequest) -> Dict[str, Any]:
        """AI-powered intelligent parts search"""
        
        # Use AI to understand the search query
        search_prompt = f"""You are ChatterFix's expert industrial parts specialist with comprehensive knowledge of maintenance components and cross-equipment compatibility.

Query: "{request.query}"
Asset ID: {request.asset_id}
Category: {request.category}

Analyze this parts search and extract detailed information as JSON:

{{
    "search_terms": ["primary", "secondary", "terms"],
    "part_type": "bearing|motor|pump|valve|seal|belt|filter|gasket|coupling|sensor|switch|fuse|contactor|relay",
    "equipment_context": "conveyor|compressor|generator|hvac|packaging|injection_molding|cnc|robot|plc",
    "specifications": ["size", "model", "voltage", "pressure_rating", "material", "other_specs"],
    "urgency_level": "routine|urgent|critical|emergency",
    "search_intent": "replacement|preventive_maintenance|emergency_repair|upgrade|cross_reference|compatibility_check",
    "failure_mode": "wear|leak|overheat|electrical_fault|mechanical_damage|contamination|misalignment",
    "compatibility_requirements": ["oem_equivalent", "aftermarket_acceptable", "must_match_exact"],
    "technical_constraints": ["temperature_range", "pressure_limits", "electrical_specs", "dimensional_requirements"],
    "suggested_alternatives": ["compatible_part_numbers", "oem_alternatives", "improved_versions"],
    "maintenance_context": "scheduled|breakdown|upgrade|optimization",
    "cost_considerations": "budget_sensitive|quality_priority|oem_preferred|cost_effective_alternative"
}}

Include deep technical knowledge of industrial equipment, part interchangeability, and maintenance best practices. Consider OEM vs aftermarket options, compatibility matrices, and failure analysis."""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=search_prompt,
                system_context="You are a maintenance parts expert with deep knowledge of industrial components.",
                provider_type=AIProvider.LLAMA
            )
            
            # Parse AI response
            search_analysis = self._parse_ai_search_response(ai_response.content if ai_response else "")
            
        except Exception as e:
            logger.error(f"AI search analysis failed: {e}")
            search_analysis = self._fallback_search_analysis(request.query)
        
        # Perform intelligent search
        matching_parts = self._search_parts_database(request, search_analysis)
        
        # Enhance results with AI insights
        enhanced_results = []
        for part in matching_parts[:request.max_results]:
            enhanced_part = await self._enhance_part_result(part, request, search_analysis)
            enhanced_results.append(enhanced_part)
        
        return {
            "query": request.query,
            "search_analysis": search_analysis,
            "total_matches": len(matching_parts),
            "results": enhanced_results,
            "suggestions": self._generate_search_suggestions(request, search_analysis),
            "alternatives": self._get_alternative_searches(request) if request.include_alternatives else []
        }

    def _parse_ai_search_response(self, ai_response: str) -> Dict[str, Any]:
        """Parse AI response for search analysis"""
        try:
            # Try to extract JSON from AI response
            import json
            json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except:
            pass
        
        # Fallback parsing
        return self._fallback_search_analysis(ai_response)
    
    def _fallback_search_analysis(self, query: str) -> Dict[str, Any]:
        """Fallback search analysis when AI fails"""
        query_lower = query.lower()
        
        # Extract search terms
        search_terms = [term.strip() for term in query_lower.split() if len(term.strip()) > 2]
        
        # Determine part type
        part_type = "unknown"
        part_keywords = {
            "seal": "mechanical_seal",
            "bearing": "bearing", 
            "belt": "belt",
            "valve": "valve",
            "pump": "pump",
            "motor": "motor"
        }
        
        for keyword, part_category in part_keywords.items():
            if keyword in query_lower:
                part_type = part_category
                break
        
        # Determine urgency
        urgency = "medium"
        if any(word in query_lower for word in ["emergency", "urgent", "critical", "broken", "failed"]):
            urgency = "critical"
        elif any(word in query_lower for word in ["routine", "scheduled", "planned"]):
            urgency = "low"
        
        return {
            "search_terms": search_terms,
            "part_type": part_type,
            "specifications": [],
            "urgency_level": urgency,
            "search_intent": "replacement"
        }
    
    def _search_parts_database(self, request: PartsSearchRequest, search_analysis: Dict) -> List[PartRecord]:
        """Search parts database with intelligent matching"""
        matching_parts = []
        query_lower = request.query.lower()
        search_terms = search_analysis.get("search_terms", [query_lower])
        
        for part_key, part in self.parts_database.items():
            score = 0.0
            
            # Exact part number match (highest score)
            if any(term in part.part_number.lower() for term in search_terms):
                score += 100
            
            # Description match
            description_lower = part.description.lower()
            for term in search_terms:
                if term in description_lower:
                    score += 10
            
            # Asset compatibility
            if request.asset_id and request.asset_id in part.compatible_assets:
                score += 50
            
            # Category match
            if request.category and request.category.lower() == part.category.value.lower():
                score += 30
            
            # Manufacturer/supplier match
            if part.manufacturer and any(term in part.manufacturer.lower() for term in search_terms):
                score += 15
            
            # Specifications match
            for spec_key, spec_value in part.specifications.items():
                if any(term in spec_key.lower() or term in str(spec_value).lower() for term in search_terms):
                    score += 5
            
            if score > 0:
                matching_parts.append((part, score))
        
        # Sort by score (descending)
        matching_parts.sort(key=lambda x: x[1], reverse=True)
        
        return [part for part, score in matching_parts]
    
    async def _enhance_part_result(self, part: PartRecord, request: PartsSearchRequest, search_analysis: Dict) -> Dict[str, Any]:
        """Enhance part search result with AI insights"""
        
        # Calculate stock status
        stock_status = self._calculate_stock_status(part)
        
        # Predict reorder needs
        reorder_prediction = self._predict_reorder_needs(part)
        
        # Get alternative parts
        alternatives = []
        if request.include_alternatives:
            alternatives = self._get_alternative_parts(part)
        
        return {
            "part_number": part.part_number,
            "description": part.description,
            "category": part.category.value,
            "stock_info": {
                "quantity": part.stock_quantity,
                "status": stock_status.value,
                "reorder_point": part.reorder_point,
                "location": part.storage_location
            },
            "cost_info": {
                "unit_cost": part.unit_cost,
                "total_value": part.unit_cost * part.stock_quantity,
                "supplier": part.supplier
            },
            "availability": {
                "lead_time_days": part.lead_time_days,
                "supplier_reliability": self.supplier_catalog.get(part.supplier, {}).get("reliability_score", 0.8)
            },
            "compatibility": {
                "assets": part.compatible_assets,
                "alternatives": alternatives
            },
            "ai_insights": {
                "criticality_score": part.criticality_score,
                "usage_frequency": part.usage_frequency,
                "reorder_prediction": reorder_prediction,
                "maintenance_notes": part.maintenance_notes
            },
            "specifications": part.specifications
        }
    
    def _calculate_stock_status(self, part: PartRecord) -> StockStatus:
        """Calculate current stock status"""
        if part.stock_quantity == 0:
            return StockStatus.OUT_OF_STOCK
        elif part.stock_quantity <= part.reorder_point:
            return StockStatus.LOW_STOCK
        elif part.stock_quantity >= part.max_stock_level:
            return StockStatus.OVERSTOCKED
        else:
            return StockStatus.IN_STOCK
    
    def _predict_reorder_needs(self, part: PartRecord) -> Dict[str, Any]:
        """Predict when part will need to be reordered"""
        current_usage_rate = part.usage_frequency  # Parts per month
        
        if current_usage_rate <= 0:
            return {"days_until_reorder": 999, "confidence": 0.2, "recommendation": "Monitor usage"}
        
        days_until_reorder = (part.stock_quantity - part.reorder_point) / (current_usage_rate / 30)
        
        # Adjust for seasonal patterns (simplified)
        seasonal_adjustment = 1.0  # Could be enhanced with actual seasonal data
        days_until_reorder *= seasonal_adjustment
        
        confidence = min(0.9, 0.3 + (part.usage_frequency / 10))  # Higher usage = higher confidence
        
        recommendation = "Normal ordering"
        if days_until_reorder < 7:
            recommendation = "Order immediately"
        elif days_until_reorder < 14:
            recommendation = "Order soon"
        elif days_until_reorder < 30:
            recommendation = "Plan order"
        
        return {
            "days_until_reorder": max(0, round(days_until_reorder)),
            "confidence": confidence,
            "recommendation": recommendation,
            "suggested_order_quantity": max(part.reorder_point, int(current_usage_rate * 2))  # 2 months supply
        }
    
    def _get_alternative_parts(self, part: PartRecord) -> List[Dict[str, Any]]:
        """Get alternative parts information"""
        alternatives = []
        
        for alt_part_number in part.alternative_parts:
            # In a real system, this would look up actual alternative part data
            alternatives.append({
                "part_number": alt_part_number,
                "availability": "check_with_supplier",
                "cost_difference": "±10%",  # Estimated
                "compatibility": "verified"
            })
        
        return alternatives
    
    def _generate_search_suggestions(self, request: PartsSearchRequest, search_analysis: Dict) -> List[str]:
        """Generate helpful search suggestions"""
        suggestions = []
        
        if not request.asset_id:
            suggestions.append("Try including an asset ID for more specific results")
        
        if not request.category:
            suggestions.append("Specify a part category to narrow down results")
        
        if search_analysis.get("part_type") == "unknown":
            suggestions.append("Use more specific part type keywords (e.g., 'bearing', 'seal', 'belt')")
        
        suggestions.extend([
            "Search by manufacturer part number for exact matches",
            "Include size or model specifications for better results",
            "Try searching for compatible alternative parts"
        ])
        
        return suggestions[:3]
    
    def _get_alternative_searches(self, request: PartsSearchRequest) -> List[str]:
        """Get alternative search queries"""
        alternatives = []
        query_parts = request.query.lower().split()
        
        # Suggest broader searches
        if len(query_parts) > 1:
            alternatives.append(" ".join(query_parts[:-1]))  # Remove last word
        
        # Suggest category-based searches
        alternatives.extend([
            "mechanical parts",
            "electrical components", 
            "consumable items"
        ])
        
        return alternatives[:3]

    async def inventory_optimization_analysis(self, request: InventoryAnalysisRequest) -> Dict[str, Any]:
        """Comprehensive inventory optimization analysis"""
        
        analysis_results = {
            "analysis_type": request.analysis_type,
            "timestamp": datetime.now().isoformat(),
            "summary": {},
            "recommendations": [],
            "alerts": [],
            "optimizations": []
        }
        
        if request.analysis_type in ["full", "low_stock"]:
            low_stock_analysis = self._analyze_low_stock_items()
            analysis_results["low_stock"] = low_stock_analysis
            
        if request.analysis_type in ["full", "reorder"]:
            reorder_analysis = self._analyze_reorder_needs(request.time_horizon_days)
            analysis_results["reorder_analysis"] = reorder_analysis
            
        if request.analysis_type in ["full", "optimization"]:
            optimization_analysis = await self._analyze_inventory_optimization()
            analysis_results["optimization"] = optimization_analysis
            
        # Generate summary
        analysis_results["summary"] = self._generate_analysis_summary(analysis_results)
        
        return analysis_results
    
    def _analyze_low_stock_items(self) -> Dict[str, Any]:
        """Analyze low stock and out-of-stock items"""
        low_stock_items = []
        out_of_stock_items = []
        critical_low_stock = []
        
        for part_key, part in self.parts_database.items():
            stock_status = self._calculate_stock_status(part)
            
            if stock_status == StockStatus.OUT_OF_STOCK:
                out_of_stock_items.append({
                    "part_number": part.part_number,
                    "description": part.description,
                    "criticality": part.criticality_score,
                    "assets_affected": part.compatible_assets,
                    "supplier": part.supplier,
                    "lead_time": part.lead_time_days
                })
            elif stock_status == StockStatus.LOW_STOCK:
                item_info = {
                    "part_number": part.part_number,
                    "description": part.description,
                    "current_stock": part.stock_quantity,
                    "reorder_point": part.reorder_point,
                    "criticality": part.criticality_score
                }
                low_stock_items.append(item_info)
                
                if part.criticality_score >= 0.8:
                    critical_low_stock.append(item_info)
        
        return {
            "out_of_stock_count": len(out_of_stock_items),
            "low_stock_count": len(low_stock_items),
            "critical_low_stock_count": len(critical_low_stock),
            "out_of_stock_items": sorted(out_of_stock_items, key=lambda x: x["criticality"], reverse=True),
            "low_stock_items": sorted(low_stock_items, key=lambda x: x["criticality"], reverse=True),
            "critical_items": critical_low_stock
        }
    
    def _analyze_reorder_needs(self, time_horizon_days: int) -> Dict[str, Any]:
        """Analyze parts that need to be reordered within time horizon"""
        reorder_needed = []
        total_order_value = 0.0
        
        for part_key, part in self.parts_database.items():
            reorder_prediction = self._predict_reorder_needs(part)
            
            if reorder_prediction["days_until_reorder"] <= time_horizon_days:
                order_quantity = reorder_prediction["suggested_order_quantity"]
                order_value = order_quantity * part.unit_cost
                total_order_value += order_value
                
                reorder_needed.append({
                    "part_number": part.part_number,
                    "description": part.description,
                    "days_until_reorder": reorder_prediction["days_until_reorder"],
                    "suggested_quantity": order_quantity,
                    "order_value": order_value,
                    "supplier": part.supplier,
                    "lead_time": part.lead_time_days,
                    "priority": "high" if reorder_prediction["days_until_reorder"] <= 7 else "medium"
                })
        
        # Sort by urgency
        reorder_needed.sort(key=lambda x: x["days_until_reorder"])
        
        return {
            "total_items_to_reorder": len(reorder_needed),
            "total_order_value": round(total_order_value, 2),
            "high_priority_items": len([item for item in reorder_needed if item["priority"] == "high"]),
            "reorder_schedule": reorder_needed
        }
    
    async def _analyze_inventory_optimization(self) -> Dict[str, Any]:
        """AI-powered inventory optimization analysis"""
        
        optimization_prompt = """You are an inventory optimization expert. Analyze this parts inventory data and provide optimization recommendations.

Consider:
1. Stock levels vs. usage patterns
2. Carrying costs vs. stockout risks  
3. Supplier lead times and reliability
4. Seasonal demand variations
5. Equipment criticality

Provide specific, actionable recommendations for:
- Optimal stock levels
- Reorder points
- Safety stock levels
- Supplier diversification
- Cost reduction opportunities"""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=optimization_prompt,
                system_context="You are an expert in industrial inventory management and optimization.",
                provider_type=AIProvider.LLAMA
            )
            
            ai_recommendations = ai_response.content if ai_response else "AI optimization unavailable"
            
        except Exception as e:
            logger.error(f"AI optimization failed: {e}")
            ai_recommendations = "AI analysis unavailable"
        
        # Calculate optimization metrics
        overstocked_items = []
        underutilized_items = []
        high_value_items = []
        
        for part_key, part in self.parts_database.items():
            # Overstocked analysis
            if self._calculate_stock_status(part) == StockStatus.OVERSTOCKED:
                excess_value = (part.stock_quantity - part.max_stock_level) * part.unit_cost
                overstocked_items.append({
                    "part_number": part.part_number,
                    "excess_quantity": part.stock_quantity - part.max_stock_level,
                    "excess_value": excess_value
                })
            
            # Low usage analysis
            if part.usage_frequency < 0.5 and part.stock_quantity > 2:
                underutilized_items.append({
                    "part_number": part.part_number,
                    "usage_frequency": part.usage_frequency,
                    "stock_value": part.stock_quantity * part.unit_cost
                })
            
            # High value analysis
            part_value = part.stock_quantity * part.unit_cost
            if part_value > 1000:  # $1000+ inventory value
                high_value_items.append({
                    "part_number": part.part_number,
                    "total_value": part_value,
                    "criticality": part.criticality_score
                })
        
        return {
            "ai_recommendations": ai_recommendations,
            "overstocked_items": overstocked_items,
            "underutilized_items": underutilized_items,
            "high_value_items": sorted(high_value_items, key=lambda x: x["total_value"], reverse=True),
            "optimization_opportunities": {
                "excess_inventory_value": sum(item["excess_value"] for item in overstocked_items),
                "underutilized_value": sum(item["stock_value"] for item in underutilized_items)
            }
        }
    
    def _generate_analysis_summary(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate executive summary of inventory analysis"""
        summary = {
            "total_parts": len(self.parts_database),
            "total_inventory_value": sum(part.stock_quantity * part.unit_cost for part in self.parts_database.values()),
            "key_insights": [],
            "action_items": [],
            "risk_factors": []
        }
        
        if "low_stock" in analysis:
            low_stock = analysis["low_stock"]
            if low_stock["out_of_stock_count"] > 0:
                summary["risk_factors"].append(f"{low_stock['out_of_stock_count']} parts are out of stock")
            if low_stock["critical_low_stock_count"] > 0:
                summary["action_items"].append(f"Immediate reorder needed for {low_stock['critical_low_stock_count']} critical parts")
        
        if "reorder_analysis" in analysis:
            reorder = analysis["reorder_analysis"]
            if reorder["high_priority_items"] > 0:
                summary["action_items"].append(f"{reorder['high_priority_items']} parts need urgent reordering")
            summary["key_insights"].append(f"${reorder['total_order_value']:,.2f} in upcoming orders")
        
        return summary

# Global instance
parts_intelligence = PartsIntelligenceSystem()

# API Endpoints
@parts_router.post("/search")
async def search_parts(request: PartsSearchRequest):
    """Intelligent parts search endpoint"""
    return await parts_intelligence.intelligent_parts_search(request)

@parts_router.post("/inventory/analysis")
async def inventory_analysis(request: InventoryAnalysisRequest):
    """Comprehensive inventory analysis endpoint"""
    return await parts_intelligence.inventory_optimization_analysis(request)

@parts_router.get("/stock-status")
async def get_stock_status():
    """Get overall stock status overview"""
    status_counts = {"in_stock": 0, "low_stock": 0, "out_of_stock": 0, "overstocked": 0}
    
    for part in parts_intelligence.parts_database.values():
        status = parts_intelligence._calculate_stock_status(part)
        if status == StockStatus.IN_STOCK:
            status_counts["in_stock"] += 1
        elif status == StockStatus.LOW_STOCK:
            status_counts["low_stock"] += 1
        elif status == StockStatus.OUT_OF_STOCK:
            status_counts["out_of_stock"] += 1
        elif status == StockStatus.OVERSTOCKED:
            status_counts["overstocked"] += 1
    
    return {
        "timestamp": datetime.now().isoformat(),
        "total_parts": len(parts_intelligence.parts_database),
        "status_breakdown": status_counts,
        "alerts": {
            "critical": status_counts["out_of_stock"],
            "warning": status_counts["low_stock"]
        }
    }

@parts_router.get("/part/{part_number}")
async def get_part_details(part_number: str):
    """Get detailed information about a specific part"""
    # Find part by part number
    matching_part = None
    for part in parts_intelligence.parts_database.values():
        if part.part_number.upper() == part_number.upper():
            matching_part = part
            break
    
    if not matching_part:
        raise HTTPException(status_code=404, detail="Part not found")
    
    # Enhance with AI insights
    enhanced_result = await parts_intelligence._enhance_part_result(
        matching_part, 
        PartsSearchRequest(query=part_number),
        {"search_intent": "lookup"}
    )
    
    return enhanced_result

# Export main components
__all__ = ['parts_router', 'PartsIntelligenceSystem', 'parts_intelligence', 'PartRecord', 'StockStatus']