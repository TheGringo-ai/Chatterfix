#!/usr/bin/env python3
"""
Preventive Maintenance Edit Extension
Adds missing PM edit functionality to ChatterFix CMMS
"""

from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from typing import Optional
import json
from datetime import datetime

router = APIRouter()

# Sample PM data - in production this would come from database
PM_DATA = {
    "PM-001": {
        "id": "PM-001",
        "name": "Compressor Quarterly Service",
        "asset_id": "AST-001",
        "asset_name": "Primary Air Compressor",
        "frequency_days": 90,
        "estimated_duration": 6.0,
        "priority": "high",
        "description": "Complete quarterly maintenance for air compressor",
        "instructions": "1. Shutdown compressor\n2. Drain oil and replace\n3. Replace air filters\n4. Check belts and tension\n5. Inspect safety valves\n6. Performance test",
        "required_parts": [
            {"part_id": "PRT-002", "quantity": 1, "description": "Air filter"},
            {"part_id": "PRT-003", "quantity": 4, "description": "Compressor oil"}
        ],
        "required_skills": ["Mechanical", "Electrical", "Pneumatics"],
        "safety_requirements": ["Lockout/Tagout", "PPE", "Confined Space"],
        "last_completed": "2025-08-15",
        "next_due": "2025-11-15",
        "status": "scheduled"
    },
    "PM-002": {
        "id": "PM-002",
        "name": "HVAC Filter Replacement",
        "asset_id": "AST-003",
        "asset_name": "HVAC Unit 1",
        "frequency_days": 30,
        "estimated_duration": 2.0,
        "priority": "medium",
        "description": "Monthly HVAC filter replacement and system check",
        "instructions": "1. Turn off HVAC system\n2. Remove old filters\n3. Install new filters\n4. Check system operation",
        "required_parts": [
            {"part_id": "PRT-004", "quantity": 2, "description": "HVAC filter"}
        ],
        "required_skills": ["HVAC", "Mechanical"],
        "safety_requirements": ["PPE", "Ladder Safety"],
        "last_completed": "2025-08-01",
        "next_due": "2025-09-01",
        "status": "overdue"
    }
}

# Schedule data
SCHEDULE_DATA = {
    "SCH-001": {
        "id": "SCH-001",
        "pm_id": "PM-001",
        "scheduled_date": "2025-09-15",
        "assigned_technician": "TECH-001",
        "estimated_duration": 6.0,
        "priority": "high",
        "status": "scheduled",
        "notes": "Quarterly maintenance due"
    },
    "SCH-002": {
        "id": "SCH-002", 
        "pm_id": "PM-002",
        "scheduled_date": "2025-09-10",
        "assigned_technician": "TECH-003",
        "estimated_duration": 2.0,
        "priority": "medium",
        "status": "scheduled",
        "notes": "Monthly filter replacement"
    }
}

@router.get("/cmms/preventive/{pm_id}/edit", response_class=HTMLResponse)
async def edit_pm_form(pm_id: str):
    """Edit PM form"""
    if pm_id not in PM_DATA:
        raise HTTPException(status_code=404, detail="PM not found")
    
    pm = PM_DATA[pm_id]
    
    html_content = f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit PM: {pm["name"]}</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
                padding: 20px;
            }}
            .container {{ max-width: 800px; margin: 0 auto; }}
            .card {{ 
                background: rgba(255,255,255,0.1); 
                backdrop-filter: blur(10px);
                padding: 2rem; 
                border-radius: 15px; 
                border: 1px solid rgba(255,255,255,0.2);
                margin: 20px 0;
            }}
            .form-group {{ margin: 15px 0; }}
            label {{ display: block; margin-bottom: 5px; font-weight: 600; }}
            input, textarea, select {{ 
                width: 100%; 
                padding: 10px; 
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 5px; 
                background: rgba(255,255,255,0.1);
                color: white;
            }}
            input::placeholder, textarea::placeholder {{ color: rgba(255,255,255,0.7); }}
            .btn {{ 
                padding: 10px 20px; 
                margin: 5px; 
                background: linear-gradient(45deg, #007bff, #0056b3);
                color: white; 
                border: none; 
                border-radius: 8px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
            }}
            .btn:hover {{ background: linear-gradient(45deg, #0056b3, #003d82); }}
            .btn-success {{ background: linear-gradient(45deg, #28a745, #1e7e34); }}
            .btn-danger {{ background: linear-gradient(45deg, #dc3545, #c82333); }}
            .row {{ display: flex; gap: 20px; }}
            .col {{ flex: 1; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="card">
                <h1>🔧 Edit Preventive Maintenance</h1>
                <h2>{pm["name"]} ({pm_id})</h2>
            </div>
            
            <form id="editPMForm" class="card">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="name">PM Name:</label>
                            <input type="text" id="name" name="name" value="{pm['name']}" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="asset_id">Asset:</label>
                            <select id="asset_id" name="asset_id">
                                <option value="{pm['asset_id']}" selected>{pm['asset_name']}</option>
                                <option value="AST-001">Primary Air Compressor</option>
                                <option value="AST-002">Conveyor Belt System</option>
                                <option value="AST-003">HVAC Unit 1</option>
                                <option value="AST-004">Emergency Generator</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="frequency_days">Frequency (Days):</label>
                            <input type="number" id="frequency_days" name="frequency_days" value="{pm['frequency_days']}" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="estimated_duration">Estimated Duration (Hours):</label>
                            <input type="number" step="0.5" id="estimated_duration" name="estimated_duration" value="{pm['estimated_duration']}" required>
                        </div>
                    </div>
                    
                    <div class="col">
                        <div class="form-group">
                            <label for="priority">Priority:</label>
                            <select id="priority" name="priority">
                                <option value="low" {"selected" if pm['priority'] == 'low' else ""}>Low</option>
                                <option value="medium" {"selected" if pm['priority'] == 'medium' else ""}>Medium</option>
                                <option value="high" {"selected" if pm['priority'] == 'high' else ""}>High</option>
                                <option value="critical" {"selected" if pm['priority'] == 'critical' else ""}>Critical</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select id="status" name="status">
                                <option value="active" {"selected" if pm['status'] == 'active' else ""}>Active</option>
                                <option value="scheduled" {"selected" if pm['status'] == 'scheduled' else ""}>Scheduled</option>
                                <option value="overdue" {"selected" if pm['status'] == 'overdue' else ""}>Overdue</option>
                                <option value="inactive" {"selected" if pm['status'] == 'inactive' else ""}>Inactive</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="next_due">Next Due Date:</label>
                            <input type="date" id="next_due" name="next_due" value="{pm['next_due']}">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" rows="3">{pm['description']}</textarea>
                </div>
                
                <div class="form-group">
                    <label for="instructions">Instructions:</label>
                    <textarea id="instructions" name="instructions" rows="6">{pm['instructions']}</textarea>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="btn btn-success">💾 Save Changes</button>
                    <button type="button" class="btn" onclick="window.history.back()">↩️ Cancel</button>
                    <a href="/cmms/preventive/dashboard" class="btn">📋 Back to Dashboard</a>
                </div>
            </form>
        </div>
        
        <script>
            document.getElementById('editPMForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const pmData = Object.fromEntries(formData);
                
                fetch('/cmms/preventive/{pm_id}', {{
                    method: 'PUT',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(pmData)
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.success) {{
                        alert('PM updated successfully!');
                        window.location.href = '/cmms/preventive/dashboard';
                    }} else {{
                        alert('Error updating PM: ' + data.message);
                    }}
                }})
                .catch(error => {{
                    alert('Error: ' + error.message);
                }});
            }});
        </script>
    </body>
    </html>
    '''
    
    return html_content

@router.put("/cmms/preventive/{pm_id}")
async def update_pm(pm_id: str, request: Request):
    """Update PM"""
    if pm_id not in PM_DATA:
        raise HTTPException(status_code=404, detail="PM not found")
    
    data = await request.json()
    
    # Update PM data
    PM_DATA[pm_id].update({
        "name": data.get("name", PM_DATA[pm_id]["name"]),
        "asset_id": data.get("asset_id", PM_DATA[pm_id]["asset_id"]),
        "frequency_days": int(data.get("frequency_days", PM_DATA[pm_id]["frequency_days"])),
        "estimated_duration": float(data.get("estimated_duration", PM_DATA[pm_id]["estimated_duration"])),
        "priority": data.get("priority", PM_DATA[pm_id]["priority"]),
        "status": data.get("status", PM_DATA[pm_id]["status"]),
        "description": data.get("description", PM_DATA[pm_id]["description"]),
        "instructions": data.get("instructions", PM_DATA[pm_id]["instructions"]),
        "next_due": data.get("next_due", PM_DATA[pm_id]["next_due"]),
        "modified_date": datetime.now().isoformat()
    })
    
    return {"success": True, "message": f"PM {pm_id} updated successfully", "pm": PM_DATA[pm_id]}

@router.get("/cmms/preventive/schedule/{schedule_id}/edit", response_class=HTMLResponse)
async def edit_schedule_form(schedule_id: str):
    """Edit schedule form"""
    if schedule_id not in SCHEDULE_DATA:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    schedule = SCHEDULE_DATA[schedule_id]
    pm = PM_DATA.get(schedule["pm_id"], {})
    
    html_content = f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Schedule: {schedule_id}</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
                padding: 20px;
            }}
            .container {{ max-width: 600px; margin: 0 auto; }}
            .card {{ 
                background: rgba(255,255,255,0.1); 
                backdrop-filter: blur(10px);
                padding: 2rem; 
                border-radius: 15px; 
                border: 1px solid rgba(255,255,255,0.2);
                margin: 20px 0;
            }}
            .form-group {{ margin: 15px 0; }}
            label {{ display: block; margin-bottom: 5px; font-weight: 600; }}
            input, textarea, select {{ 
                width: 100%; 
                padding: 10px; 
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 5px; 
                background: rgba(255,255,255,0.1);
                color: white;
            }}
            .btn {{ 
                padding: 10px 20px; 
                margin: 5px; 
                background: linear-gradient(45deg, #007bff, #0056b3);
                color: white; 
                border: none; 
                border-radius: 8px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
            }}
            .btn:hover {{ background: linear-gradient(45deg, #0056b3, #003d82); }}
            .btn-success {{ background: linear-gradient(45deg, #28a745, #1e7e34); }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="card">
                <h1>📅 Edit Schedule</h1>
                <h2>{pm.get('name', 'PM Task')} ({schedule_id})</h2>
            </div>
            
            <form id="editScheduleForm" class="card">
                <div class="form-group">
                    <label for="scheduled_date">Scheduled Date:</label>
                    <input type="date" id="scheduled_date" name="scheduled_date" value="{schedule['scheduled_date']}" required>
                </div>
                
                <div class="form-group">
                    <label for="assigned_technician">Assigned Technician:</label>
                    <select id="assigned_technician" name="assigned_technician">
                        <option value="TECH-001" {"selected" if schedule['assigned_technician'] == 'TECH-001' else ""}>John Smith</option>
                        <option value="TECH-002" {"selected" if schedule['assigned_technician'] == 'TECH-002' else ""}>Mike Johnson</option>
                        <option value="TECH-003" {"selected" if schedule['assigned_technician'] == 'TECH-003' else ""}>Sarah Davis</option>
                        <option value="TECH-004" {"selected" if schedule['assigned_technician'] == 'TECH-004' else ""}>Carlos Rodriguez</option>
                        <option value="TECH-005" {"selected" if schedule['assigned_technician'] == 'TECH-005' else ""}>Lisa Wong</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="estimated_duration">Estimated Duration (Hours):</label>
                    <input type="number" step="0.5" id="estimated_duration" name="estimated_duration" value="{schedule['estimated_duration']}" required>
                </div>
                
                <div class="form-group">
                    <label for="priority">Priority:</label>
                    <select id="priority" name="priority">
                        <option value="low" {"selected" if schedule['priority'] == 'low' else ""}>Low</option>
                        <option value="medium" {"selected" if schedule['priority'] == 'medium' else ""}>Medium</option>
                        <option value="high" {"selected" if schedule['priority'] == 'high' else ""}>High</option>
                        <option value="critical" {"selected" if schedule['priority'] == 'critical' else ""}>Critical</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="status">Status:</label>
                    <select id="status" name="status">
                        <option value="scheduled" {"selected" if schedule['status'] == 'scheduled' else ""}>Scheduled</option>
                        <option value="in_progress" {"selected" if schedule['status'] == 'in_progress' else ""}>In Progress</option>
                        <option value="completed" {"selected" if schedule['status'] == 'completed' else ""}>Completed</option>
                        <option value="cancelled" {"selected" if schedule['status'] == 'cancelled' else ""}>Cancelled</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="notes">Notes:</label>
                    <textarea id="notes" name="notes" rows="3">{schedule.get('notes', '')}</textarea>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="btn btn-success">💾 Save Schedule</button>
                    <button type="button" class="btn" onclick="window.history.back()">↩️ Cancel</button>
                    <a href="/cmms/preventive/dashboard" class="btn">📋 Back to Dashboard</a>
                </div>
            </form>
        </div>
        
        <script>
            document.getElementById('editScheduleForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const scheduleData = Object.fromEntries(formData);
                
                fetch('/cmms/preventive/schedule/{schedule_id}', {{
                    method: 'PUT',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(scheduleData)
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.success) {{
                        alert('Schedule updated successfully!');
                        window.location.href = '/cmms/preventive/dashboard';
                    }} else {{
                        alert('Error updating schedule: ' + data.message);
                    }}
                }})
                .catch(error => {{
                    alert('Error: ' + error.message);
                }});
            }});
        </script>
    </body>
    </html>
    '''
    
    return html_content

@router.put("/cmms/preventive/schedule/{schedule_id}")
async def update_schedule(schedule_id: str, request: Request):
    """Update schedule"""
    if schedule_id not in SCHEDULE_DATA:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    data = await request.json()
    
    # Update schedule data
    SCHEDULE_DATA[schedule_id].update({
        "scheduled_date": data.get("scheduled_date", SCHEDULE_DATA[schedule_id]["scheduled_date"]),
        "assigned_technician": data.get("assigned_technician", SCHEDULE_DATA[schedule_id]["assigned_technician"]),
        "estimated_duration": float(data.get("estimated_duration", SCHEDULE_DATA[schedule_id]["estimated_duration"])),
        "priority": data.get("priority", SCHEDULE_DATA[schedule_id]["priority"]),
        "status": data.get("status", SCHEDULE_DATA[schedule_id]["status"]),
        "notes": data.get("notes", SCHEDULE_DATA[schedule_id].get("notes", "")),
        "modified_date": datetime.now().isoformat()
    })
    
    return {"success": True, "message": f"Schedule {schedule_id} updated successfully", "schedule": SCHEDULE_DATA[schedule_id]}

@router.get("/cmms/preventive/schedules")
async def get_all_schedules():
    """Get all schedules"""
    return {"schedules": list(SCHEDULE_DATA.values())}

@router.get("/cmms/preventive/schedule/{schedule_id}")
async def get_schedule(schedule_id: str):
    """Get specific schedule"""
    if schedule_id not in SCHEDULE_DATA:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    return {"schedule": SCHEDULE_DATA[schedule_id]}

# Test endpoints
@router.get("/test/pm-edit")
async def test_pm_edit():
    """Test endpoint to verify PM edit functionality"""
    return {
        "message": "PM Edit Extension loaded successfully!",
        "available_endpoints": [
            "GET /cmms/preventive/{pm_id}/edit - PM edit form",
            "PUT /cmms/preventive/{pm_id} - Update PM",
            "GET /cmms/preventive/schedule/{schedule_id}/edit - Schedule edit form", 
            "PUT /cmms/preventive/schedule/{schedule_id} - Update schedule"
        ],
        "sample_pm_ids": list(PM_DATA.keys()),
        "sample_schedule_ids": list(SCHEDULE_DATA.keys())
    }