#!/usr/bin/env python3
"""
ChatterFix CMMS - Simple Preventive Maintenance Module
Complete CRUD functionality for preventive maintenance management
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

router = APIRouter(prefix="/cmms/preventive", tags=["preventive"])

# Simple preventive maintenance data
PREVENTIVE_TASKS = [
    {
        "id": "PM-001",
        "name": "Monthly Pump Inspection",
        "asset_id": "AST-001",
        "frequency": "monthly",
        "next_due_date": "2025-10-15",
        "instructions": "Check seals, pressure readings, and lubrication levels",
        "estimated_duration": 2.0,
        "last_completed": "2025-09-15T10:00:00Z",
        "assigned_to": "John Smith",
        "status": "active"
    },
    {
        "id": "PM-002",
        "name": "Quarterly Belt Alignment Check",
        "asset_id": "AST-002",
        "frequency": "quarterly",
        "next_due_date": "2025-12-01",
        "instructions": "Inspect belt tension, alignment, and wear patterns",
        "estimated_duration": 1.5,
        "last_completed": "2025-09-01T14:30:00Z",
        "assigned_to": "Mike Johnson",
        "status": "active"
    },
    {
        "id": "PM-003",
        "name": "Weekly Motor Vibration Monitoring",
        "asset_id": "AST-003",
        "frequency": "weekly",
        "next_due_date": "2025-09-21",
        "instructions": "Use vibration meter to check for abnormal readings",
        "estimated_duration": 0.5,
        "last_completed": "2025-09-14T09:15:00Z",
        "assigned_to": "John Smith",
        "status": "overdue"
    },
    {
        "id": "PM-004",
        "name": "HVAC Filter Replacement",
        "asset_id": "AST-003",
        "frequency": "quarterly",
        "next_due_date": "2025-12-15",
        "instructions": "Replace all air filters and check airflow",
        "estimated_duration": 1.0,
        "last_completed": "2025-09-15T16:00:00Z",
        "assigned_to": "Sarah Wilson",
        "status": "active"
    },
    {
        "id": "PM-005",
        "name": "Generator Load Test",
        "asset_id": "AST-004",
        "frequency": "monthly",
        "next_due_date": "2025-10-20",
        "instructions": "Perform full load test and check fuel levels",
        "estimated_duration": 2.5,
        "last_completed": "2025-09-20T08:45:00Z",
        "assigned_to": "Mike Johnson",
        "status": "active"
    }
]

@router.get("/dashboard")
async def preventive_dashboard():
    """Live Preventive Maintenance management dashboard with full CRUD functionality"""
    return HTMLResponse('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Preventive Maintenance - ChatterFix CMMS</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #27ae60 0%, #2c3e50 100%);
                min-height: 100vh;
                color: white;
                padding: 2rem;
            }
            .card { 
                background: rgba(255,255,255,0.1);
                backdrop-filter: blur(15px);
                border-radius: 20px;
                padding: 2rem;
                margin: 1rem 0;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .active { color: #27ae60; }
            .overdue { color: #e74c3c; font-weight: bold; }
            .completed { color: #95a5a6; }
            .suspended { color: #f39c12; }
            .weekly { color: #e74c3c; font-weight: bold; }
            .monthly { color: #f39c12; }
            .quarterly { color: #3498db; }
            .annually { color: #9b59b6; }
            h1 { margin-bottom: 2rem; text-align: center; }
            .preventive-task { 
                background: rgba(255,255,255,0.05);
                border-radius: 15px;
                padding: 1.5rem;
                margin: 1rem 0;
                border-left: 4px solid #27ae60;
                position: relative;
            }
            .task-actions {
                position: absolute;
                top: 1rem;
                right: 1rem;
                display: flex;
                gap: 0.5rem;
            }
            .status-indicator {
                display: inline-block;
                padding: 0.3rem 0.8rem;
                border-radius: 15px;
                font-size: 0.8rem;
                font-weight: bold;
                margin-left: 1rem;
            }
            .frequency-indicator {
                display: inline-block;
                padding: 0.3rem 0.8rem;
                border-radius: 15px;
                font-size: 0.8rem;
                font-weight: bold;
                margin-left: 0.5rem;
            }
            .btn {
                background: linear-gradient(135deg, #27ae60, #229954);
                color: white;
                border: none;
                padding: 0.8rem 1.5rem;
                border-radius: 10px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 0.25rem;
                transition: all 0.3s ease;
                font-size: 0.9rem;
            }
            .btn:hover { transform: translateY(-2px); }
            .btn-small {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }
            .btn-warning {
                background: linear-gradient(135deg, #f39c12, #e67e22);
            }
            .btn-success {
                background: linear-gradient(135deg, #27ae60, #229954);
            }
            .btn-danger {
                background: linear-gradient(135deg, #e74c3c, #c0392b);
            }
            .btn-info {
                background: linear-gradient(135deg, #3498db, #2980b9);
            }
            .modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }
            .modal-content {
                background: rgba(44,62,80,0.95);
                backdrop-filter: blur(15px);
                margin: 5% auto;
                padding: 2rem;
                border-radius: 20px;
                width: 90%;
                max-width: 600px;
                border: 1px solid rgba(255,255,255,0.2);
            }
            .form-group {
                margin: 1rem 0;
            }
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: bold;
            }
            .form-group input, .form-group select, .form-group textarea {
                width: 100%;
                padding: 0.8rem;
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 10px;
                background: rgba(255,255,255,0.1);
                color: white;
                font-size: 1rem;
            }
            .form-group input::placeholder, .form-group textarea::placeholder {
                color: rgba(255,255,255,0.6);
            }
            .loading {
                text-align: center;
                padding: 2rem;
                font-size: 1.2rem;
            }
            .stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin: 2rem 0;
            }
            .stat-card {
                text-align: center;
                padding: 1rem;
                border-radius: 10px;
            }
            .calendar {
                display: grid;
                grid-template-columns: repeat(7, 1fr);
                gap: 0.5rem;
                margin: 2rem 0;
            }
            .calendar-header {
                background: rgba(255,255,255,0.2);
                padding: 1rem;
                text-align: center;
                font-weight: bold;
                border-radius: 5px;
            }
            .calendar-day {
                background: rgba(255,255,255,0.1);
                padding: 0.5rem;
                text-align: center;
                border-radius: 5px;
                min-height: 60px;
                position: relative;
            }
            .calendar-task {
                background: rgba(39,174,96,0.8);
                font-size: 0.7rem;
                padding: 0.2rem;
                margin: 0.1rem 0;
                border-radius: 3px;
                cursor: pointer;
            }
            .overdue-task {
                background: rgba(231,76,60,0.8);
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>🔧 Preventive Maintenance Dashboard</h1>
            
            <div style="text-align: center; margin-bottom: 2rem;">
                <button class="btn btn-success" onclick="showCreateModal()">➕ Create New PM Task</button>
                <button class="btn" onclick="loadTasks()">🔄 Refresh</button>
                <button class="btn btn-info" onclick="toggleCalendarView()">📅 Calendar View</button>
                <a href="/cmms/dashboard/main" class="btn">← Back to Dashboard</a>
            </div>

            <div id="stats-container" class="stats">
                <div class="stat-card" style="background: rgba(39,174,96,0.2);">
                    <h3 id="total-tasks">-</h3>
                    <p>Total PM Tasks</p>
                </div>
                <div class="stat-card" style="background: rgba(52,152,219,0.2);">
                    <h3 id="active-tasks">-</h3>
                    <p>Active Tasks</p>
                </div>
                <div class="stat-card" style="background: rgba(231,76,60,0.2);">
                    <h3 id="overdue-tasks">-</h3>
                    <p>Overdue Tasks</p>
                </div>
                <div class="stat-card" style="background: rgba(243,156,18,0.2);">
                    <h3 id="upcoming-tasks">-</h3>
                    <p>Due This Week</p>
                </div>
            </div>

            <div id="list-view" class="view-container">
                <div id="tasks-container">
                    <div class="loading">Loading preventive maintenance tasks...</div>
                </div>
            </div>

            <div id="calendar-view" class="view-container" style="display: none;">
                <div id="calendar-container">
                    <div class="calendar">
                        <div class="calendar-header">Sun</div>
                        <div class="calendar-header">Mon</div>
                        <div class="calendar-header">Tue</div>
                        <div class="calendar-header">Wed</div>
                        <div class="calendar-header">Thu</div>
                        <div class="calendar-header">Fri</div>
                        <div class="calendar-header">Sat</div>
                        <div id="calendar-days"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Create/Edit PM Task Modal -->
        <div id="task-modal" class="modal">
            <div class="modal-content">
                <h2 id="modal-title">Create New PM Task</h2>
                <form id="task-form">
                    <div class="form-group">
                        <label for="name">Task Name *</label>
                        <input type="text" id="name" name="name" required placeholder="Enter task name">
                    </div>
                    <div class="form-group">
                        <label for="asset_id">Asset ID</label>
                        <input type="text" id="asset_id" name="asset_id" placeholder="Asset ID (e.g. AST-001)">
                    </div>
                    <div class="form-group">
                        <label for="frequency">Frequency</label>
                        <select id="frequency" name="frequency">
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                            <option value="quarterly">Quarterly</option>
                            <option value="annually">Annually</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="next_due_date">Next Due Date</label>
                        <input type="date" id="next_due_date" name="next_due_date">
                    </div>
                    <div class="form-group">
                        <label for="instructions">Instructions *</label>
                        <textarea id="instructions" name="instructions" required placeholder="Detailed maintenance instructions" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="estimated_duration">Estimated Duration (hours)</label>
                        <input type="number" id="estimated_duration" name="estimated_duration" step="0.5" min="0" value="1.0">
                    </div>
                    <div class="form-group">
                        <label for="assigned_to">Assigned To</label>
                        <input type="text" id="assigned_to" name="assigned_to" placeholder="Technician name">
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="active">Active</option>
                            <option value="overdue">Overdue</option>
                            <option value="completed">Completed</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-success">💾 Save PM Task</button>
                        <button type="button" class="btn btn-danger" onclick="closeModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Complete Task Modal -->
        <div id="complete-modal" class="modal">
            <div class="modal-content">
                <h2>Complete PM Task</h2>
                <form id="complete-form">
                    <div class="form-group">
                        <label for="completion-notes">Completion Notes</label>
                        <textarea id="completion-notes" name="notes" placeholder="Notes about the completed maintenance" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="actual-duration">Actual Duration (hours)</label>
                        <input type="number" id="actual-duration" name="actual_duration" step="0.5" min="0">
                    </div>
                    <div class="form-group">
                        <label for="next-due-override">Override Next Due Date</label>
                        <input type="date" id="next-due-override" name="next_due_override">
                    </div>
                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-success">✅ Mark Complete</button>
                        <button type="button" class="btn btn-danger" onclick="closeCompleteModal()">❌ Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            let currentTasks = [];
            let editingTaskId = null;
            let completingTaskId = null;
            let currentView = 'list';

            // Load tasks on page load
            document.addEventListener('DOMContentLoaded', loadTasks);

            async function loadTasks() {
                try {
                    const response = await fetch('/preventive-test/');
                    const data = await response.json();
                    
                    if (data.success) {
                        currentTasks = data.tasks;
                        updateStats();
                        if (currentView === 'list') {
                            renderTasks();
                        } else {
                            renderCalendar();
                        }
                    } else {
                        showError('Failed to load PM tasks');
                    }
                } catch (error) {
                    showError('Error loading PM tasks: ' + error.message);
                }
            }

            function updateStats() {
                const totalTasks = currentTasks.length;
                const activeTasks = currentTasks.filter(t => t.status === 'active').length;
                const overdueTasks = currentTasks.filter(t => t.status === 'overdue').length;
                
                // Calculate upcoming tasks (due within 7 days)
                const today = new Date();
                const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
                const upcomingTasks = currentTasks.filter(t => {
                    const dueDate = new Date(t.next_due_date);
                    return dueDate >= today && dueDate <= weekFromNow && t.status === 'active';
                }).length;

                document.getElementById('total-tasks').textContent = totalTasks;
                document.getElementById('active-tasks').textContent = activeTasks;
                document.getElementById('overdue-tasks').textContent = overdueTasks;
                document.getElementById('upcoming-tasks').textContent = upcomingTasks;
            }

            function renderTasks() {
                const container = document.getElementById('tasks-container');
                
                if (currentTasks.length === 0) {
                    container.innerHTML = '<div class="loading">No PM tasks found. Create your first preventive maintenance task!</div>';
                    return;
                }

                container.innerHTML = currentTasks.map(task => {
                    let statusClass, statusIndicator;
                    let frequencyClass, frequencyIndicator;

                    // Status styling
                    if (task.status === 'active') {
                        statusClass = 'active';
                        statusIndicator = '<span class="status-indicator" style="background: #27ae60;">ACTIVE</span>';
                    } else if (task.status === 'overdue') {
                        statusClass = 'overdue';
                        statusIndicator = '<span class="status-indicator" style="background: #e74c3c;">OVERDUE</span>';
                    } else if (task.status === 'completed') {
                        statusClass = 'completed';
                        statusIndicator = '<span class="status-indicator" style="background: #95a5a6;">COMPLETED</span>';
                    } else {
                        statusClass = 'suspended';
                        statusIndicator = '<span class="status-indicator" style="background: #f39c12;">SUSPENDED</span>';
                    }

                    // Frequency styling
                    if (task.frequency === 'weekly') {
                        frequencyClass = 'weekly';
                        frequencyIndicator = '<span class="frequency-indicator" style="background: #e74c3c;">WEEKLY</span>';
                    } else if (task.frequency === 'monthly') {
                        frequencyClass = 'monthly';
                        frequencyIndicator = '<span class="frequency-indicator" style="background: #f39c12;">MONTHLY</span>';
                    } else if (task.frequency === 'quarterly') {
                        frequencyClass = 'quarterly';
                        frequencyIndicator = '<span class="frequency-indicator" style="background: #3498db;">QUARTERLY</span>';
                    } else {
                        frequencyClass = 'annually';
                        frequencyIndicator = '<span class="frequency-indicator" style="background: #9b59b6;">ANNUALLY</span>';
                    }

                    const daysUntilDue = Math.ceil((new Date(task.next_due_date) - new Date()) / (1000 * 60 * 60 * 24));
                    const dueStatus = daysUntilDue < 0 ? `${Math.abs(daysUntilDue)} days overdue` : `${daysUntilDue} days until due`;

                    return `
                        <div class="preventive-task">
                            <div class="task-actions">
                                <button class="btn btn-small btn-success" onclick="showEditModal('${task.id}')">✏️ Edit</button>
                                <button class="btn btn-small btn-warning" onclick="showCompleteModal('${task.id}')">✅ Complete</button>
                                <button class="btn btn-small btn-info" onclick="scheduleTask('${task.id}')">📅 Schedule</button>
                                <button class="btn btn-small btn-danger" onclick="deleteTask('${task.id}')">🗑️ Delete</button>
                            </div>
                            <h3>${task.name} <span class="${statusClass}">(${task.status})</span> ${statusIndicator} ${frequencyIndicator}</h3>
                            <p><strong>ID:</strong> ${task.id} | <strong>Asset:</strong> ${task.asset_id} | <strong>Assigned To:</strong> ${task.assigned_to}</p>
                            <p><strong>Instructions:</strong> ${task.instructions}</p>
                            <p><strong>Next Due:</strong> ${task.next_due_date} (${dueStatus}) | <strong>Est. Duration:</strong> ${task.estimated_duration}h</p>
                            <p><strong>Last Completed:</strong> ${task.last_completed}</p>
                        </div>
                    `;
                }).join('');
            }

            function renderCalendar() {
                // Simplified calendar view showing upcoming tasks
                const container = document.getElementById('calendar-days');
                const today = new Date();
                const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
                const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                
                let calendarHTML = '';
                for (let day = 1; day <= endOfMonth.getDate(); day++) {
                    const currentDate = new Date(today.getFullYear(), today.getMonth(), day);
                    const dateStr = currentDate.toISOString().split('T')[0];
                    
                    const tasksForDay = currentTasks.filter(t => t.next_due_date === dateStr);
                    
                    calendarHTML += `
                        <div class="calendar-day">
                            <div>${day}</div>
                            ${tasksForDay.map(t => `
                                <div class="calendar-task ${t.status === 'overdue' ? 'overdue-task' : ''}" onclick="showEditModal('${t.id}')">
                                    ${t.name}
                                </div>
                            `).join('')}
                        </div>
                    `;
                }
                
                container.innerHTML = calendarHTML;
            }

            function toggleCalendarView() {
                const listView = document.getElementById('list-view');
                const calendarView = document.getElementById('calendar-view');
                
                if (currentView === 'list') {
                    listView.style.display = 'none';
                    calendarView.style.display = 'block';
                    currentView = 'calendar';
                    renderCalendar();
                } else {
                    listView.style.display = 'block';
                    calendarView.style.display = 'none';
                    currentView = 'list';
                    renderTasks();
                }
            }

            function showCreateModal() {
                editingTaskId = null;
                document.getElementById('modal-title').textContent = 'Create New PM Task';
                document.getElementById('task-form').reset();
                document.getElementById('task-modal').style.display = 'block';
            }

            async function showEditModal(taskId) {
                try {
                    const response = await fetch(`/preventive-test/${taskId}`);
                    const data = await response.json();
                    
                    if (data.success) {
                        editingTaskId = taskId;
                        const task = data.task;
                        
                        document.getElementById('modal-title').textContent = 'Edit PM Task';
                        document.getElementById('name').value = task.name;
                        document.getElementById('asset_id').value = task.asset_id;
                        document.getElementById('frequency').value = task.frequency;
                        document.getElementById('next_due_date').value = task.next_due_date;
                        document.getElementById('instructions').value = task.instructions;
                        document.getElementById('estimated_duration').value = task.estimated_duration;
                        document.getElementById('assigned_to').value = task.assigned_to;
                        document.getElementById('status').value = task.status;
                        
                        document.getElementById('task-modal').style.display = 'block';
                    } else {
                        showError('Failed to load PM task details');
                    }
                } catch (error) {
                    showError('Error loading PM task: ' + error.message);
                }
            }

            function showCompleteModal(taskId) {
                const task = currentTasks.find(t => t.id === taskId);
                if (!task) return;

                completingTaskId = taskId;
                document.getElementById('actual-duration').value = task.estimated_duration;
                document.getElementById('complete-form').reset();
                document.getElementById('complete-modal').style.display = 'block';
            }

            async function scheduleTask(taskId) {
                const newDate = prompt('Enter new due date (YYYY-MM-DD):');
                if (!newDate) return;

                try {
                    const response = await fetch(`/preventive-test/${taskId}/schedule`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ next_due_date: newDate })
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadTasks();
                    } else {
                        showError(data.detail || 'Failed to schedule task');
                    }
                } catch (error) {
                    showError('Error scheduling task: ' + error.message);
                }
            }

            function closeModal() {
                document.getElementById('task-modal').style.display = 'none';
            }

            function closeCompleteModal() {
                document.getElementById('complete-modal').style.display = 'none';
            }

            // Handle task form submission
            document.getElementById('task-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const taskData = Object.fromEntries(formData.entries());
                
                // Convert numeric fields
                taskData.estimated_duration = parseFloat(taskData.estimated_duration) || 1.0;

                try {
                    let response;
                    if (editingTaskId) {
                        response = await fetch(`/preventive-test/${editingTaskId}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(taskData)
                        });
                    } else {
                        response = await fetch('/preventive-test/', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(taskData)
                        });
                    }

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeModal();
                        loadTasks();
                    } else {
                        showError('Failed to save PM task');
                    }
                } catch (error) {
                    showError('Error saving PM task: ' + error.message);
                }
            });

            // Handle completion form submission
            document.getElementById('complete-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const completionData = Object.fromEntries(formData.entries());
                completionData.actual_duration = parseFloat(completionData.actual_duration) || 0;

                try {
                    const response = await fetch(`/preventive-test/${completingTaskId}/complete`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(completionData)
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        closeCompleteModal();
                        loadTasks();
                    } else {
                        showError(data.detail || 'Failed to complete task');
                    }
                } catch (error) {
                    showError('Error completing task: ' + error.message);
                }
            });

            async function deleteTask(taskId) {
                if (!confirm('Are you sure you want to delete this PM task? This action cannot be undone.')) {
                    return;
                }

                try {
                    const response = await fetch(`/preventive-test/${taskId}`, {
                        method: 'DELETE'
                    });

                    const data = await response.json();
                    if (data.success) {
                        showSuccess(data.message);
                        loadTasks();
                    } else {
                        showError('Failed to delete PM task');
                    }
                } catch (error) {
                    showError('Error deleting PM task: ' + error.message);
                }
            }

            function showSuccess(message) {
                alert('✅ ' + message);
            }

            function showError(message) {
                alert('❌ ' + message);
            }

            // Close modals when clicking outside
            window.onclick = function(event) {
                const taskModal = document.getElementById('task-modal');
                const completeModal = document.getElementById('complete-modal');
                
                if (event.target === taskModal) {
                    taskModal.style.display = 'none';
                }
                if (event.target === completeModal) {
                    completeModal.style.display = 'none';
                }
            }
        </script>
    </body>
    </html>
    ''')

@router.get("/")
async def list_preventive_tasks():
    """Get all preventive maintenance tasks as JSON"""
    return {"tasks": PREVENTIVE_TASKS, "count": len(PREVENTIVE_TASKS)}

@router.get("/{task_id}")
async def get_preventive_task(task_id: str):
    """Get specific preventive maintenance task"""
    task = next((t for t in PREVENTIVE_TASKS if t["id"] == task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Preventive maintenance task not found")
    return task

@router.get("/status/active")
async def get_active_preventive_tasks():
    """Get active preventive maintenance tasks"""
    active_tasks = [t for t in PREVENTIVE_TASKS if t['status'] == 'active']
    return {"active_tasks": active_tasks, "count": len(active_tasks)}

@router.get("/status/overdue")
async def get_overdue_preventive_tasks():
    """Get overdue preventive maintenance tasks"""
    overdue_tasks = [t for t in PREVENTIVE_TASKS if t['status'] == 'overdue']
    return {"overdue_tasks": overdue_tasks, "count": len(overdue_tasks)}

print("✅ Simple Preventive Maintenance module loaded")