#!/usr/bin/env python3
"""
ChatterFix CMMS - RAG (Retrieval-Augmented Generation) System
Comprehensive document embedding, retrieval, and citation system for manuals, SOPs, and parts documentation
"""

import os
import json
import hashlib
import time
import asyncio
from typing import Dict, List, Optional, Tuple, Any, Union
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import dataclass, asdict
import io
import logging

#############################################
# Optional heavy dependency imports (guarded)
#############################################
try:
    import numpy as np  # type: ignore
    NUMPY_AVAILABLE = True
except Exception:
    NUMPY_AVAILABLE = False
    class _NPStub:
        class random:
            @staticmethod
            def randint(a,b):
                import random as _r; return _r.randint(a,b)
            @staticmethod
            def uniform(a,b):
                import random as _r; return _r.uniform(a,b)
        @staticmethod
        def array(x):
            return list(x)
        @staticmethod
        def linalg_norm(v, axis=None, keepdims=False):
            return 1.0
    np = _NPStub()  # type: ignore

try:
    import faiss  # type: ignore
    FAISS_AVAILABLE = True
except Exception:
    faiss = None  # type: ignore
    FAISS_AVAILABLE = False
    print("(optional) faiss-cpu not installed; vector search will degrade to keyword mode")

try:
    from sentence_transformers import SentenceTransformer  # type: ignore
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except Exception:
    SentenceTransformer = None  # type: ignore
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    print("(optional) sentence-transformers not installed; embeddings disabled")

try:
    import pytesseract  # type: ignore
    from PIL import Image  # type: ignore
    import cv2  # type: ignore
    OCR_AVAILABLE = True
except Exception:
    pytesseract = None  # type: ignore
    Image = None  # type: ignore
    cv2 = None  # type: ignore
    OCR_AVAILABLE = False

try:
    import PyPDF2  # type: ignore
    try:
        import fitz  # type: ignore
    except Exception:
        fitz = None  # type: ignore
    PDF_AVAILABLE = True
except Exception:
    PyPDF2 = None  # type: ignore
    fitz = None  # type: ignore
    PDF_AVAILABLE = False

# Text processing
import re
from collections import defaultdict

try:
    import spacy  # type: ignore
except Exception:
    spacy = None  # type: ignore

# Try to load spaCy model
try:
    if spacy:
        nlp = spacy.load("en_core_web_sm")
        SPACY_AVAILABLE = True
    else:
        SPACY_AVAILABLE = False
except Exception:
    SPACY_AVAILABLE = False
    print("spaCy model not available - install with: python -m spacy download en_core_web_sm")

# =============================================================================
# Configuration
# =============================================================================

DOCUMENTS_DIR = os.getenv("DOCUMENTS_DIR", "./documents")
UPLOADS_DIR = os.getenv("UPLOADS_DIR", "./uploads")
INDEX_DIR = os.getenv("INDEX_DIR", "./rag_index")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "512"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "50"))
MAX_SEARCH_RESULTS = int(os.getenv("MAX_SEARCH_RESULTS", "10"))

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============================================================================
# Data Models
# =============================================================================

@dataclass
class DocumentChunk:
    """A chunk of text from a document with metadata"""
    chunk_id: str
    document_id: str
    filename: str
    file_path: str
    chunk_index: int
    text: str
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    chunk_type: str = "text"  # text, table, image_caption, ocr
    metadata: Optional[Dict[str, Any]] = None
    embedding: Optional[Any] = None  # avoid strict numpy dependency
    created_at: Optional[datetime] = None

@dataclass
class DocumentMetadata:
    """Metadata for a processed document"""
    document_id: str
    filename: str
    file_path: str
    file_type: str
    file_size: int
    page_count: Optional[int] = None
    total_chunks: int = 0
    processed_at: Optional[datetime] = None
    checksum: str = ""
    tags: Optional[List[str]] = None
    category: str = "general"  # manual, sop, parts, maintenance

@dataclass
class SearchResult:
    """Search result with relevance scoring"""
    chunk: DocumentChunk
    score: float
    rank: int

@dataclass
class Citation:
    """Citation information for a search result"""
    document_id: str
    filename: str
    page_number: Optional[int]
    section_title: Optional[str]
    chunk_text: str
    relevance_score: float

@dataclass
class RAGResponse:
    """Response from RAG system with answer and citations"""
    query: str
    answer: str
    citations: List[Citation]
    search_results: List[SearchResult]
    processing_time_ms: int
    model_used: str

# =============================================================================
# Text Processing Utilities
# =============================================================================

class TextProcessor:
    """Advanced text processing for documents"""
    
    def __init__(self):
        self.chunk_size = CHUNK_SIZE
        self.chunk_overlap = CHUNK_OVERLAP
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep technical terms
        text = re.sub(r'[^\w\s\-\.\,\:\;\(\)\[\]\/\\]', ' ', text)
        
        # Normalize whitespace
        text = text.strip()
        
        return text
    
    def chunk_text(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> List[str]:
        """Split text into overlapping chunks"""
        if not text:
            return []
        
        # Split by sentences first
        sentences = self._split_sentences(text)
        
        chunks = []
        current_chunk = ""
        current_length = 0
        
        for sentence in sentences:
            sentence_length = len(sentence)
            
            # If adding this sentence would exceed chunk size
            if current_length + sentence_length > self.chunk_size and current_chunk:
                chunks.append(current_chunk.strip())
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk)
                current_chunk = overlap_text + " " + sentence
                current_length = len(current_chunk)
            else:
                current_chunk += " " + sentence if current_chunk else sentence
                current_length += sentence_length
        
        # Add the last chunk
        if current_chunk.strip():
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences using spaCy if available"""
        if SPACY_AVAILABLE:
            doc = nlp(text)
            return [sent.text.strip() for sent in doc.sents if sent.text.strip()]
        else:
            # Fallback to simple splitting
            sentences = re.split(r'[.!?]+', text)
            return [s.strip() for s in sentences if s.strip()]
    
    def _get_overlap_text(self, text: str) -> str:
        """Get overlap text for chunk continuity"""
        words = text.split()
        overlap_words = min(self.chunk_overlap, len(words))
        return " ".join(words[-overlap_words:]) if overlap_words > 0 else ""
    
    def extract_key_terms(self, text: str) -> List[str]:
        """Extract key technical terms from text"""
        key_terms = []
        
        # Technical patterns
        patterns = [
            r'\b\d+\.?\d*\s*(?:mm|cm|m|in|ft|kg|lbs|psi|rpm|°C|°F|V|A|W|Hz)\b',  # Measurements
            r'\b(?:Motor|Pump|Valve|Bearing|Seal|Gasket|Filter|Belt|Chain)\s*[-\w]*\b',  # Parts
            r'\b(?:SOP|Manual|Procedure|Step|Section)\s*\d+\b',  # Documentation refs
            r'\b[A-Z]{2,}\s*[-\d]+\b',  # Part numbers
            r'\b\d+:\d+\b',  # Time references
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            key_terms.extend(matches)
        
        # Remove duplicates and return
        return list(set([term.strip() for term in key_terms if term.strip()]))

# =============================================================================
# OCR Processing
# =============================================================================

class OCRProcessor:
    """OCR processing for images and scanned documents"""
    
    def __init__(self):
        self.available = OCR_AVAILABLE
    
    def extract_text_from_image(self, image_path: str) -> str:
        """Extract text from image using OCR (optional libs)."""
        if not self.available or not cv2 or not pytesseract:
            return ""
        try:
            image = cv2.imread(image_path)  # type: ignore
            if image is None:
                return ""
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # type: ignore
            denoised = cv2.fastNlMeansDenoising(gray)  # type: ignore
            text = pytesseract.image_to_string(denoised)  # type: ignore
            return text.strip()
        except Exception:
            return ""
    
    def extract_text_from_pdf_images(self, pdf_path: str) -> List[Tuple[int, str]]:
        """Extract text from images in PDF pages"""
        if not PDF_AVAILABLE:
            return []
        
        extracted_text = []
        
        try:
            if not fitz:
                return []
            doc = fitz.open(pdf_path)  # type: ignore
            
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                
                # Get images from page
                image_list = page.get_images()
                
                for img_index, img in enumerate(image_list):
                    # Extract image
                    xref = img[0]
                    if not fitz:
                        continue
                    pix = fitz.Pixmap(doc, xref)  # type: ignore
                    
                    if pix.n - pix.alpha < 4:  # GRAY or RGB
                        # Convert to PIL Image
                        img_data = pix.tobytes("ppm")
                        if not Image:
                            continue
                        img_pil = Image.open(io.BytesIO(img_data))  # type: ignore
                        
                        # Save temporarily for OCR
                        temp_path = f"/tmp/temp_img_{page_num}_{img_index}.png"
                        img_pil.save(temp_path)
                        
                        # Extract text
                        ocr_text = self.extract_text_from_image(temp_path)
                        if ocr_text:
                            extracted_text.append((page_num + 1, ocr_text))
                        
                        # Cleanup
                        os.unlink(temp_path)
                    
                    pix = None
            
            doc.close()
            
        except Exception as e:
            logger.error(f"PDF OCR failed for {pdf_path}: {e}")
        
        return extracted_text

# =============================================================================
# Document Processing
# =============================================================================

class DocumentProcessor:
    """Process various document types for RAG system"""
    
    def __init__(self):
        self.text_processor = TextProcessor()
        self.ocr_processor = OCRProcessor()
    
    def process_document(self, file_path: str, category: str = "general") -> Tuple[DocumentMetadata, List[DocumentChunk]]:
        """Process a document and return metadata and chunks"""
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"Document not found: {file_path}")
        
        # Generate document ID
        document_id = hashlib.md5(str(file_path).encode()).hexdigest()
        
        # Calculate checksum
        with open(file_path, 'rb') as f:
            checksum = hashlib.sha256(f.read()).hexdigest()
        
        # Create metadata
        metadata = DocumentMetadata(
            document_id=document_id,
            filename=file_path.name,
            file_path=str(file_path),
            file_type=file_path.suffix.lower(),
            file_size=file_path.stat().st_size,
            processed_at=datetime.now(timezone.utc),
            checksum=checksum,
            category=category
        )
        
        # Process based on file type
        if file_path.suffix.lower() == '.pdf':
            chunks = self._process_pdf(file_path, metadata)
        elif file_path.suffix.lower() in ['.txt', '.md']:
            chunks = self._process_text_file(file_path, metadata)
        elif file_path.suffix.lower() in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
            chunks = self._process_image(file_path, metadata)
        else:
            raise ValueError(f"Unsupported file type: {file_path.suffix}")
        
        metadata.total_chunks = len(chunks)
        
        return metadata, chunks
    
    def _process_pdf(self, file_path: Path, metadata: DocumentMetadata) -> List[DocumentChunk]:
        """Process PDF document"""
        if not PDF_AVAILABLE:
            raise ImportError("PDF processing libraries not available")
        
        chunks = []
        chunk_index = 0
        
        try:
            # Extract text using PyMuPDF if available, otherwise fallback to PyPDF2
            if fitz:
                doc = fitz.open(str(file_path))
                metadata.page_count = len(doc)
                
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    page_text = page.get_text()
                    
                    if page_text.strip():
                        # Extract section titles (simple heuristic)
                        lines = page_text.split('\n')
                        section_title = self._extract_section_title(lines)
                        
                        # Clean and chunk the text
                        clean_text = self.text_processor.clean_text(page_text)
                        text_chunks = self.text_processor.chunk_text(clean_text)
                        
                        for chunk_text in text_chunks:
                            if chunk_text.strip():
                                chunk_id = f"{metadata.document_id}_chunk_{chunk_index}"
                                
                                chunk = DocumentChunk(
                                    chunk_id=chunk_id,
                                    document_id=metadata.document_id,
                                    filename=metadata.filename,
                                    file_path=metadata.file_path,
                                    chunk_index=chunk_index,
                                    text=chunk_text,
                                    page_number=page_num + 1,
                                    section_title=section_title,
                                    chunk_type="text",
                                    metadata={"source": "pdf_text"},
                                    created_at=datetime.now(timezone.utc)
                                )
                                
                                chunks.append(chunk)
                                chunk_index += 1
                
                doc.close()
            else:
                # Fallback to PyPDF2
                import PyPDF2
                with open(file_path, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    metadata.page_count = len(reader.pages)
                    
                    for page_num, page in enumerate(reader.pages):
                        page_text = page.extract_text()
                        
                        if page_text and page_text.strip():
                            # Extract section titles (simple heuristic)
                            lines = page_text.split('\n')
                            section_title = self._extract_section_title(lines)
                            
                            # Clean and chunk the text
                            clean_text = self.text_processor.clean_text(page_text)
                            text_chunks = self.text_processor.chunk_text(clean_text)
                            
                            for chunk_text in text_chunks:
                                if chunk_text.strip():
                                    chunk_id = f"{metadata.document_id}_chunk_{chunk_index}"
                                    
                                    chunk = DocumentChunk(
                                        chunk_id=chunk_id,
                                        document_id=metadata.document_id,
                                        filename=metadata.filename,
                                        file_path=metadata.file_path,
                                        chunk_index=chunk_index,
                                        text=chunk_text,
                                        page_number=page_num + 1,
                                        section_title=section_title,
                                        chunk_type="text",
                                        metadata={"source": "pdf_text"},
                                        created_at=datetime.now(timezone.utc)
                                    )
                                    
                                    chunks.append(chunk)
                                    chunk_index += 1
            
            # Process images in PDF with OCR
            ocr_results = self.ocr_processor.extract_text_from_pdf_images(str(file_path))
            
            for page_num, ocr_text in ocr_results:
                if ocr_text.strip():
                    clean_text = self.text_processor.clean_text(ocr_text)
                    ocr_chunks = self.text_processor.chunk_text(clean_text)
                    
                    for chunk_text in ocr_chunks:
                        if chunk_text.strip():
                            chunk_id = f"{metadata.document_id}_ocr_chunk_{chunk_index}"
                            
                            chunk = DocumentChunk(
                                chunk_id=chunk_id,
                                document_id=metadata.document_id,
                                filename=metadata.filename,
                                file_path=metadata.file_path,
                                chunk_index=chunk_index,
                                text=chunk_text,
                                page_number=page_num,
                                section_title=None,
                                chunk_type="ocr",
                                metadata={"source": "pdf_ocr"},
                                created_at=datetime.now(timezone.utc)
                            )
                            
                            chunks.append(chunk)
                            chunk_index += 1
            
        except Exception as e:
            logger.error(f"PDF processing failed for {file_path}: {e}")
            raise
        
        return chunks
    
    def _process_text_file(self, file_path: Path, metadata: DocumentMetadata) -> List[DocumentChunk]:
        """Process text file"""
        chunks = []
        chunk_index = 0
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Clean and chunk the text
            clean_text = self.text_processor.clean_text(content)
            text_chunks = self.text_processor.chunk_text(clean_text)
            
            for chunk_text in text_chunks:
                if chunk_text.strip():
                    chunk_id = f"{metadata.document_id}_chunk_{chunk_index}"
                    
                    chunk = DocumentChunk(
                        chunk_id=chunk_id,
                        document_id=metadata.document_id,
                        filename=metadata.filename,
                        file_path=metadata.file_path,
                        chunk_index=chunk_index,
                        text=chunk_text,
                        page_number=None,
                        section_title=None,
                        chunk_type="text",
                        metadata={"source": "text_file"},
                        created_at=datetime.now(timezone.utc)
                    )
                    
                    chunks.append(chunk)
                    chunk_index += 1
                    
        except Exception as e:
            logger.error(f"Text file processing failed for {file_path}: {e}")
            raise
        
        return chunks
    
    def _process_image(self, file_path: Path, metadata: DocumentMetadata) -> List[DocumentChunk]:
        """Process image file with OCR"""
        chunks = []
        
        # Extract text using OCR
        ocr_text = self.ocr_processor.extract_text_from_image(str(file_path))
        
        if ocr_text.strip():
            clean_text = self.text_processor.clean_text(ocr_text)
            text_chunks = self.text_processor.chunk_text(clean_text)
            
            for chunk_index, chunk_text in enumerate(text_chunks):
                if chunk_text.strip():
                    chunk_id = f"{metadata.document_id}_ocr_chunk_{chunk_index}"
                    
                    chunk = DocumentChunk(
                        chunk_id=chunk_id,
                        document_id=metadata.document_id,
                        filename=metadata.filename,
                        file_path=metadata.file_path,
                        chunk_index=chunk_index,
                        text=chunk_text,
                        page_number=None,
                        section_title=None,
                        chunk_type="ocr",
                        metadata={"source": "image_ocr"},
                        created_at=datetime.now(timezone.utc)
                    )
                    
                    chunks.append(chunk)
        
        return chunks
    
    def _extract_section_title(self, lines: List[str]) -> Optional[str]:
        """Extract section title from text lines (simple heuristic)"""
        for line in lines[:5]:  # Check first 5 lines
            line = line.strip()
            if line and (
                line.isupper() or 
                line.startswith(('SECTION', 'CHAPTER', 'PART', 'SOP')) or
                re.match(r'^\d+\.?\s+[A-Z]', line)
            ):
                return line[:100]  # Limit title length
        return None

# =============================================================================
# Vector Store and Embedding
# =============================================================================

class VectorStore:
    """Vector storage and similarity search using FAISS"""
    
    def __init__(self, embedding_model: str = EMBEDDING_MODEL):
        self.embedding_model_name = embedding_model
        self.embedding_model = None
        self.index = None
        self.chunk_metadata = {}  # chunk_id -> DocumentChunk
        self.document_metadata = {}  # document_id -> DocumentMetadata
        self.embedding_dim = None
        
        # Initialize embedding model
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                self.embedding_model = SentenceTransformer(embedding_model)
                # Get embedding dimension
                test_embedding = self.embedding_model.encode(["test"])
                self.embedding_dim = test_embedding.shape[1]
                logger.info(f"Loaded embedding model: {embedding_model} (dim: {self.embedding_dim})")
            except Exception as e:
                logger.error(f"Failed to load embedding model: {e}")
                raise
        else:
            raise ImportError("SentenceTransformers not available")
        
        # Initialize FAISS index
        if FAISS_AVAILABLE and self.embedding_dim:
            self.index = faiss.IndexFlatIP(self.embedding_dim)  # Inner product for cosine similarity
            logger.info("FAISS index initialized")
        elif not FAISS_AVAILABLE:
            raise ImportError("FAISS not available")
        else:
            raise ValueError("Embedding dimension is not set, cannot initialize FAISS index")
    
    def add_documents(self, documents: List[DocumentMetadata], chunks: List[List[DocumentChunk]]):
        """Add documents and their chunks to the vector store"""
        all_chunks = []
        
        # Flatten chunks and store metadata
        for doc_metadata, doc_chunks in zip(documents, chunks):
            self.document_metadata[doc_metadata.document_id] = doc_metadata
            
            for chunk in doc_chunks:
                all_chunks.append(chunk)
                self.chunk_metadata[chunk.chunk_id] = chunk
        
        if not all_chunks:
            return
        
        # Generate embeddings
        logger.info(f"Generating embeddings for {len(all_chunks)} chunks...")
        texts = [chunk.text for chunk in all_chunks]
        embeddings = self.embedding_model.encode(texts, show_progress_bar=True)
        
        # Normalize embeddings for cosine similarity
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        
        # Add to FAISS index
        self.index.add(embeddings.astype('float32'))
        
        # Store embeddings in chunks
        for chunk, embedding in zip(all_chunks, embeddings):
            chunk.embedding = embedding
        
        logger.info(f"Added {len(all_chunks)} chunks to vector store")
    
    def search(self, query: str, k: int = MAX_SEARCH_RESULTS, score_threshold: float = 0.0) -> List[SearchResult]:
        """Search for similar chunks"""
        if not self.embedding_model or not self.index:
            return []
        
        # Generate query embedding
        query_embedding = self.embedding_model.encode([query])
        query_embedding = query_embedding / np.linalg.norm(query_embedding, axis=1, keepdims=True)
        
        # Search FAISS index
        scores, indices = self.index.search(query_embedding.astype('float32'), k)
        
        # Convert to SearchResult objects
        results = []
        chunk_list = list(self.chunk_metadata.values())
        
        for rank, (score, idx) in enumerate(zip(scores[0], indices[0])):
            if idx < len(chunk_list) and score >= score_threshold:
                chunk = chunk_list[idx]
                result = SearchResult(
                    chunk=chunk,
                    score=float(score),
                    rank=rank
                )
                results.append(result)
        
        return results
    
    def save_index(self, index_dir: str):
        """Save the vector index and metadata"""
        index_path = Path(index_dir)
        index_path.mkdir(parents=True, exist_ok=True)
        
        # Save FAISS index
        faiss.write_index(self.index, str(index_path / "faiss.index"))
        
        # Save metadata
        metadata = {
            'chunk_metadata': {k: asdict(v) for k, v in self.chunk_metadata.items()},
            'document_metadata': {k: asdict(v) for k, v in self.document_metadata.items()},
            'embedding_model': self.embedding_model_name,
            'embedding_dim': self.embedding_dim,
            'created_at': datetime.now(timezone.utc).isoformat()
        }
        
        with open(index_path / "metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2, default=str)
        
        logger.info(f"Index saved to {index_dir}")
    
    def load_index(self, index_dir: str) -> bool:
        """Load the vector index and metadata"""
        index_path = Path(index_dir)
        
        if not (index_path / "faiss.index").exists():
            return False
        
        try:
            # Load FAISS index
            self.index = faiss.read_index(str(index_path / "faiss.index"))
            
            # Load metadata
            with open(index_path / "metadata.json", 'r') as f:
                metadata = json.load(f)
            
            # Reconstruct objects
            self.chunk_metadata = {}
            for k, v in metadata['chunk_metadata'].items():
                # Convert datetime strings back to datetime objects
                v['created_at'] = datetime.fromisoformat(v['created_at'])
                self.chunk_metadata[k] = DocumentChunk(**v)
            
            self.document_metadata = {}
            for k, v in metadata['document_metadata'].items():
                v['processed_at'] = datetime.fromisoformat(v['processed_at'])
                self.document_metadata[k] = DocumentMetadata(**v)
            
            self.embedding_dim = metadata['embedding_dim']
            
            logger.info(f"Index loaded from {index_dir}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load index: {e}")
            return False

# =============================================================================
# RAG System Core
# =============================================================================

class RAGSystem:
    """Main RAG system coordinator"""
    
    def __init__(self, documents_dir: str = DOCUMENTS_DIR, index_dir: str = INDEX_DIR):
        self.documents_dir = Path(documents_dir)
        self.index_dir = Path(index_dir)
        self.document_processor = DocumentProcessor()
        self.vector_store = VectorStore()
        
        # Ensure directories exist
        self.documents_dir.mkdir(parents=True, exist_ok=True)
        self.index_dir.mkdir(parents=True, exist_ok=True)
        
        # Try to load existing index
        self.index_loaded = self.vector_store.load_index(str(self.index_dir))
    
    def build_index(self, force_rebuild: bool = False) -> Dict[str, Any]:
        """Build or rebuild the document index"""
        if self.index_loaded and not force_rebuild:
            logger.info("Index already loaded, skipping build")
            return {"status": "skipped", "reason": "index_already_loaded"}
        
        start_time = time.time()
        logger.info("Starting index build...")
        
        # Find all documents
        document_files = []
        for ext in ['*.pdf', '*.txt', '*.md', '*.png', '*.jpg', '*.jpeg', '*.tiff', '*.bmp']:
            document_files.extend(self.documents_dir.rglob(ext))
        
        if not document_files:
            logger.warning(f"No documents found in {self.documents_dir}")
            return {"status": "no_documents", "directory": str(self.documents_dir)}
        
        logger.info(f"Found {len(document_files)} documents to process")
        
        # Process documents
        documents = []
        all_chunks = []
        
        for file_path in document_files:
            try:
                # Determine category from directory structure
                category = self._determine_category(file_path)
                
                logger.info(f"Processing {file_path.name} (category: {category})")
                doc_metadata, doc_chunks = self.document_processor.process_document(str(file_path), category)
                
                documents.append(doc_metadata)
                all_chunks.append(doc_chunks)
                
            except Exception as e:
                logger.error(f"Failed to process {file_path}: {e}")
        
        if documents:
            # Add to vector store
            self.vector_store.add_documents(documents, all_chunks)
            
            # Save index
            self.vector_store.save_index(str(self.index_dir))
            self.index_loaded = True
        
        build_time = time.time() - start_time
        total_chunks = sum(len(chunks) for chunks in all_chunks)
        
        result = {
            "status": "completed",
            "documents_processed": len(documents),
            "total_chunks": total_chunks,
            "build_time_seconds": round(build_time, 2),
            "index_dir": str(self.index_dir)
        }
        
        logger.info(f"Index build completed in {build_time:.2f}s - {total_chunks} chunks from {len(documents)} documents")
        return result
    
    def search(self, query: str, k: int = MAX_SEARCH_RESULTS, category_filter: Optional[str] = None) -> List[SearchResult]:
        """Search for relevant document chunks"""
        if not self.index_loaded:
            logger.warning("Index not loaded, attempting to load...")
            self.index_loaded = self.vector_store.load_index(str(self.index_dir))
            
            if not self.index_loaded:
                logger.error("No index available - run build_index() first")
                return []
        
        # Perform vector search
        results = self.vector_store.search(query, k * 2)  # Get more results for filtering
        
        # Apply category filter if specified
        if category_filter:
            filtered_results = []
            for result in results:
                doc_metadata = self.vector_store.document_metadata.get(result.chunk.document_id)
                if doc_metadata and doc_metadata.category == category_filter:
                    filtered_results.append(result)
            results = filtered_results[:k]
        else:
            results = results[:k]
        
        return results
    
    def answer_question(self, query: str, max_context_chunks: int = 5) -> RAGResponse:
        """Generate an answer using retrieved context"""
        start_time = time.time()
        
        # Search for relevant chunks
        search_results = self.search(query, k=max_context_chunks)
        
        if not search_results:
            return RAGResponse(
                query=query,
                answer="I couldn't find any relevant information in the documents to answer your question.",
                citations=[],
                search_results=[],
                processing_time_ms=int((time.time() - start_time) * 1000),
                model_used="no_results"
            )
        
        # Create citations
        citations = []
        for result in search_results:
            citation = Citation(
                document_id=result.chunk.document_id,
                filename=result.chunk.filename,
                page_number=result.chunk.page_number,
                section_title=result.chunk.section_title,
                chunk_text=result.chunk.text[:200] + "..." if len(result.chunk.text) > 200 else result.chunk.text,
                relevance_score=result.score
            )
            citations.append(citation)
        
        # Generate answer using simple template (could be enhanced with LLM)
        answer = self._generate_answer_from_context(query, search_results)
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return RAGResponse(
            query=query,
            answer=answer,
            citations=citations,
            search_results=search_results,
            processing_time_ms=processing_time,
            model_used="template_based"
        )
    
    def _determine_category(self, file_path: Path) -> str:
        """Determine document category from file path and name"""
        path_str = str(file_path).lower()
        name_str = file_path.name.lower()
        
        if 'manual' in path_str or 'manual' in name_str:
            return 'manual'
        elif 'sop' in path_str or 'sop' in name_str or 'procedure' in name_str:
            return 'sop'
        elif 'part' in path_str or 'part' in name_str or 'component' in name_str:
            return 'parts'
        elif 'maintenance' in path_str or 'service' in name_str:
            return 'maintenance'
        else:
            return 'general'
    
    def _generate_answer_from_context(self, query: str, search_results: List[SearchResult]) -> str:
        """Generate answer from search results (template-based approach)"""
        if not search_results:
            return "No relevant information found."
        
        # Extract key information patterns
        query_lower = query.lower()
        
        # Check for specific question types
        if any(word in query_lower for word in ['torque', 'spec', 'specification']):
            return self._answer_torque_question(search_results)
        elif any(word in query_lower for word in ['sop', 'procedure', 'step', 'how to']):
            return self._answer_procedure_question(search_results)
        elif any(word in query_lower for word in ['part', 'component', 'replacement']):
            return self._answer_parts_question(search_results)
        else:
            return self._answer_general_question(search_results)
    
    def _answer_torque_question(self, search_results: List[SearchResult]) -> str:
        """Answer torque specification questions"""
        for result in search_results:
            text = result.chunk.text
            
            # Look for torque specifications
            torque_patterns = [
                r'(\d+\.?\d*)\s*(?:Nm|N·m|ft\.?lbs?|in\.?lbs?)',
                r'torque:?\s*(\d+\.?\d*)\s*(?:Nm|N·m|ft\.?lbs?|in\.?lbs?)',
                r'tighten to\s*(\d+\.?\d*)\s*(?:Nm|N·m|ft\.?lbs?|in\.?lbs?)'
            ]
            
            for pattern in torque_patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    context_start = max(0, match.start() - 50)
                    context_end = min(len(text), match.end() + 100)
                    context = text[context_start:context_end].strip()
                    
                    return f"Based on the documentation, the torque specification is: {match.group(0)}.\n\nContext: {context}"
        
        # Fallback to best matching content
        return f"Based on the available documentation:\n\n{search_results[0].chunk.text[:300]}..."
    
    def _answer_procedure_question(self, search_results: List[SearchResult]) -> str:
        """Answer SOP/procedure questions"""
        steps = []
        
        for result in search_results:
            text = result.chunk.text
            
            # Look for numbered steps
            step_patterns = [
                r'(?:Step\s*)?(\d+)[\.\:\-]\s*([^\n]+)',
                r'^\s*(\d+)[\.\:\-]\s*([^\n]+)',
                r'([A-Z][a-z]+(?:\s+[a-z]+)*)\s*:\s*([^\n]+)'
            ]
            
            for pattern in step_patterns:
                matches = re.finditer(pattern, text, re.MULTILINE)
                for match in matches:
                    if len(match.groups()) >= 2:
                        steps.append(f"{match.group(1)}. {match.group(2)}")
            
            if not steps:
                # If no structured steps found, return the content directly
                return f"Procedure information from the documentation:\n\n{text[:400]}..."
        
        if steps:
            return "Follow these steps:\n\n" + "\n".join(steps[:10])  # Limit to 10 steps
        
        return f"Procedure information:\n\n{search_results[0].chunk.text[:400]}..."
    
    def _answer_parts_question(self, search_results: List[SearchResult]) -> str:
        """Answer parts-related questions"""
        parts_info = []
        
        for result in search_results:
            text = result.chunk.text
            
            # Look for part numbers and specifications
            part_patterns = [
                r'Part(?:\s+(?:Number|No\.?|#))?\s*:?\s*([A-Z0-9\-]+)',
                r'Model\s*:?\s*([A-Z0-9\-]+)',
                r'Serial\s*(?:Number|No\.?)?\s*:?\s*([A-Z0-9\-]+)'
            ]
            
            for pattern in part_patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    parts_info.append(match.group(0))
        
        if parts_info:
            unique_parts = list(set(parts_info))
            return f"Relevant part information:\n\n{chr(10).join(unique_parts[:5])}\n\nAdditional details:\n{search_results[0].chunk.text[:200]}..."
        
        return f"Parts information from documentation:\n\n{search_results[0].chunk.text[:400]}..."
    
    def _answer_general_question(self, search_results: List[SearchResult]) -> str:
        """Answer general questions"""
        # Combine top results
        combined_text = ""
        for i, result in enumerate(search_results[:3]):
            combined_text += f"From {result.chunk.filename}:\n{result.chunk.text[:200]}...\n\n"
        
        return combined_text.strip()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get RAG system statistics"""
        if not self.index_loaded:
            return {"status": "index_not_loaded"}
        
        stats = {
            "total_documents": len(self.vector_store.document_metadata),
            "total_chunks": len(self.vector_store.chunk_metadata),
            "categories": defaultdict(int),
            "file_types": defaultdict(int),
            "embedding_model": self.vector_store.embedding_model_name,
            "embedding_dimension": self.vector_store.embedding_dim
        }
        
        for doc_metadata in self.vector_store.document_metadata.values():
            stats["categories"][doc_metadata.category] += 1
            stats["file_types"][doc_metadata.file_type] += 1
        
        return dict(stats)

# =============================================================================
# Asset-Specific RAG Enhancement
# =============================================================================

from typing import Union

class AssetRAGEnhancer:
    """Enhance RAG queries with asset-specific context"""
    
    def __init__(self, base_rag_system):
        self.rag_system = base_rag_system
        
    def enhance_query_with_asset_context(self, query: str, asset_id: str, asset_data: Optional[Dict] = None) -> str:
        """Enhance query with asset-specific context for better results"""
        if not asset_data:
            # Would normally fetch from database, using mock for now
            from assets import assets_db
            asset_data = next((a for a in assets_db if a['id'] == asset_id), {})
        
        if not asset_data:
            return query
        
        # Build asset context string
        context_parts = []
        context_parts.append(f"Asset: {asset_data.get('name', 'Unknown')}")
        context_parts.append(f"Manufacturer: {asset_data.get('manufacturer', 'Unknown')}")
        context_parts.append(f"Model: {asset_data.get('model', 'Unknown')}")
        context_parts.append(f"Category: {asset_data.get('category', 'Unknown')}")
        
        asset_context = " | ".join(context_parts)
        enhanced_query = f"[{asset_context}] {query}"
        
        return enhanced_query
    
    def search_manuals_for_asset(self, query: str, asset_id: str, max_results: int = 5) -> List[SearchResult]:
        """Search manuals with asset context"""
        # Get asset data for context
        from assets import assets_db
        asset_data = next((a for a in assets_db if a['id'] == asset_id), {})
        
        # Enhance query with asset context
        enhanced_query = self.enhance_query_with_asset_context(query, asset_id, asset_data)
        
        # Search with category filter for manuals
        results = self.rag_system.search(enhanced_query, k=max_results * 2, category_filter="manual")
        
        # Filter and rank results by relevance to asset
        filtered_results = self._filter_by_asset_relevance(results, asset_data, max_results)
        
        return filtered_results
    
    def search_parts_for_asset(self, query: str, asset_id: str, max_results: int = 5) -> List[SearchResult]:
        """Search parts documentation with asset context"""
        from assets import assets_db
        asset_data = next((a for a in assets_db if a['id'] == asset_id), {})
        
        enhanced_query = self.enhance_query_with_asset_context(query, asset_id, asset_data)
        
        # Search with category filter for parts
        results = self.rag_system.search(enhanced_query, k=max_results * 2, category_filter="parts")
        
        filtered_results = self._filter_by_asset_relevance(results, asset_data, max_results)
        
        return filtered_results
    
    def search_troubleshooting_for_asset(self, query: str, asset_id: str, max_results: int = 5) -> List[SearchResult]:
        """Search troubleshooting documentation with asset context"""
        from assets import assets_db
        asset_data = next((a for a in assets_db if a['id'] == asset_id), {})
        
        enhanced_query = self.enhance_query_with_asset_context(query, asset_id, asset_data)
        
        # Search maintenance and sop categories for troubleshooting
        results = self.rag_system.search(enhanced_query, k=max_results * 2, category_filter="maintenance")
        
        # If no maintenance results, try SOP category
        if not results:
            results = self.rag_system.search(enhanced_query, k=max_results * 2, category_filter="sop")
        
        filtered_results = self._filter_by_asset_relevance(results, asset_data, max_results)
        
        return filtered_results
    
    def _filter_by_asset_relevance(self, results: List[SearchResult], asset_data: Dict, max_results: int) -> List[SearchResult]:
        """Filter and rank results by asset relevance"""
        if not asset_data:
            return results[:max_results]
        
        # Keywords for relevance scoring
        asset_keywords = [
            asset_data.get('manufacturer', '').lower(),
            asset_data.get('model', '').lower(),
            asset_data.get('category', '').lower(),
            asset_data.get('name', '').lower()
        ]
        asset_keywords = [k for k in asset_keywords if k]
        
        # Score results by keyword relevance
        scored_results = []
        for result in results:
            relevance_boost = 0
            text_lower = result.chunk.text.lower()
            filename_lower = result.chunk.filename.lower()
            
            for keyword in asset_keywords:
                if keyword in text_lower:
                    relevance_boost += 0.2
                if keyword in filename_lower:
                    relevance_boost += 0.3
            
            # Create new score combining original similarity + relevance boost
            new_score = result.score + relevance_boost
            scored_results.append((result, new_score))
        
        # Sort by enhanced score and return top results
        scored_results.sort(key=lambda x: x[1], reverse=True)
        return [result for result, _ in scored_results[:max_results]]

# =============================================================================
# Global RAG System Instance
# =============================================================================

# Initialize global RAG system
rag_system = RAGSystem()
# Initialize asset-enhanced RAG system
asset_rag = AssetRAGEnhancer(rag_system)

# Convenience functions
async def build_document_index(force_rebuild: bool = False) -> Dict[str, Any]:
    """Build the document index"""
    return rag_system.build_index(force_rebuild)

async def search_documents(query: str, k: int = MAX_SEARCH_RESULTS, category: Optional[str] = None) -> List[SearchResult]:
    """Search documents"""
    return rag_system.search(query, k, category)

async def answer_question(query: str, max_context: int = 5) -> RAGResponse:
    """Answer question using RAG"""
    return rag_system.answer_question(query, max_context)

def get_rag_statistics() -> Dict[str, Any]:
    """Get RAG system statistics"""
    return rag_system.get_statistics()

# =============================================================================
# Asset-Enhanced RAG API Functions
# =============================================================================

async def search_asset_manuals(asset_id: str, query: str, max_results: int = 5) -> List[SearchResult]:
    """Search manuals for specific asset"""
    return asset_rag.search_manuals_for_asset(query, asset_id, max_results)

async def search_asset_parts(asset_id: str, query: str, max_results: int = 5) -> List[SearchResult]:
    """Search parts documentation for specific asset"""
    return asset_rag.search_parts_for_asset(query, asset_id, max_results)

async def search_asset_troubleshooting(asset_id: str, query: str, max_results: int = 5) -> List[SearchResult]:
    """Search troubleshooting documentation for specific asset"""
    return asset_rag.search_troubleshooting_for_asset(query, asset_id, max_results)

async def answer_asset_question(asset_id: str, query: str, context_type: str = "manual") -> RAGResponse:
    """Generate answer for asset-specific question with proper context"""
    start_time = time.time()
    
    # Choose search function based on context type
    if context_type == "parts":
        search_results = await search_asset_parts(asset_id, query)
    elif context_type == "troubleshooting":
        search_results = await search_asset_troubleshooting(asset_id, query)
    else:  # default to manual
        search_results = await search_asset_manuals(asset_id, query)
    
    if not search_results:
        return RAGResponse(
            query=query,
            answer=f"I couldn't find any relevant {context_type} information for this asset. Try checking if the asset manuals have been uploaded to the system.",
            citations=[],
            search_results=[],
            processing_time_ms=int((time.time() - start_time) * 1000),
            model_used="asset_enhanced_no_results"
        )
    
    # Create citations with asset context
    citations = []
    for result in search_results:
        citation = Citation(
            document_id=result.chunk.document_id,
            filename=result.chunk.filename,
            page_number=result.chunk.page_number,
            section_title=result.chunk.section_title,
            chunk_text=result.chunk.text[:200] + "..." if len(result.chunk.text) > 200 else result.chunk.text,
            relevance_score=result.score
        )
        citations.append(citation)
    
    # Generate enhanced answer with asset context
    answer = rag_system._generate_answer_from_context(query, search_results)
    
    # Add asset-specific context to answer if available
    from assets import assets_db
    asset_data = next((a for a in assets_db if a['id'] == asset_id), None)
    if asset_data:
        answer = f"For {asset_data['name']} ({asset_data['manufacturer']} {asset_data['model']}):\n\n{answer}"
    
    processing_time = int((time.time() - start_time) * 1000)
    
    return RAGResponse(
        query=query,
        answer=answer,
        citations=citations,
        search_results=search_results,
        processing_time_ms=processing_time,
        model_used="asset_enhanced_template"
    )

# =============================================================================
# Work Order Context RAG Enhancement
# =============================================================================

class WorkOrderRAGEnhancer:
    """Enhance RAG queries with work order specific context"""
    
    def __init__(self, base_rag_system):
        self.rag_system = base_rag_system
        
    def enhance_query_with_work_order_context(self, query: str, work_order_id: str, work_order_data: Optional[Dict] = None) -> str:
        """Enhance query with work order specific context for better results"""
        if not work_order_data:
            # Would normally fetch from database, using mock for now
            from workorders import work_orders_db
            work_order_data = next((wo for wo in work_orders_db if wo['id'] == work_order_id), {})
        
        if not work_order_data:
            return query
        
        # Build work order context string
        context_parts = []
        context_parts.append(f"Work Order: {work_order_data.get('title', 'Unknown')}")
        context_parts.append(f"Asset: {work_order_data.get('asset_id', 'Unknown')}")
        context_parts.append(f"Type: {work_order_data.get('type', 'Unknown')}")
        context_parts.append(f"Priority: {work_order_data.get('priority', 'Unknown')}")
        
        if work_order_data.get('description'):
            context_parts.append(f"Description: {work_order_data['description'][:100]}...")
        
        work_order_context = " | ".join(context_parts)
        enhanced_query = f"[{work_order_context}] {query}"
        
        return enhanced_query
    
    async def search_troubleshooting_knowledge(self, work_order_id: str, issue_description: str, max_results: int = 5) -> List[SearchResult]:
        """Search troubleshooting knowledge with work order context"""
        from workorders import work_orders_db
        work_order_data = next((wo for wo in work_orders_db if wo['id'] == work_order_id), {})
        
        # Enhance query with work order context
        enhanced_query = self.enhance_query_with_work_order_context(issue_description, work_order_id, work_order_data)
        
        # Search with category filter for troubleshooting
        results = self.rag_system.search(enhanced_query, k=max_results * 2, category_filter="maintenance")
        
        # If no maintenance results, try SOP and manual categories
        if not results:
            results = self.rag_system.search(enhanced_query, k=max_results * 2, category_filter="sop")
        if not results:
            results = self.rag_system.search(enhanced_query, k=max_results, category_filter="manual")
        
        # Filter and rank results by relevance to work order
        filtered_results = self._filter_by_work_order_relevance(results, work_order_data, max_results)
        
        return filtered_results
    
    async def search_similar_work_orders(self, work_order_id: str, issue_description: str, max_results: int = 3) -> List[Dict[str, Any]]:
        """Search for similar past work orders for troubleshooting insights"""
        from workorders import work_orders_db
        current_wo = next((wo for wo in work_orders_db if wo['id'] == work_order_id), {})
        
        if not current_wo:
            return []
        
        # Find work orders with similar descriptions or same asset
        similar_wos = []
        current_asset_id = current_wo.get('asset_id', '')
        
        for wo in work_orders_db:
            if wo['id'] == work_order_id or wo['status'] not in ['completed', 'closed']:
                continue
                
            similarity_score = 0.0
            
            # Same asset gets high similarity boost
            if wo.get('asset_id') == current_asset_id:
                similarity_score += 0.5
            
            # Similar description (simple keyword matching)
            current_desc = issue_description.lower().split()
            wo_desc = wo.get('description', '').lower().split()
            
            common_keywords = set(current_desc) & set(wo_desc)
            if common_keywords:
                similarity_score += len(common_keywords) / max(len(current_desc), len(wo_desc)) * 0.4
            
            # Same type gets slight boost
            if wo.get('type') == current_wo.get('type'):
                similarity_score += 0.1
            
            if similarity_score >= 0.3:
                similar_wos.append({
                    'work_order_id': wo['id'],
                    'asset_id': wo.get('asset_id', ''),
                    'issue_description': wo.get('description', ''),
                    'resolution': wo.get('completion_notes', 'Resolution not documented'),
                    'resolution_time_hours': wo.get('actual_hours'),
                    'similarity_score': similarity_score,
                    'completed_date': wo.get('closed_date', wo.get('created_date'))
                })
        
        # Sort by similarity score and return top results
        similar_wos.sort(key=lambda x: x['similarity_score'], reverse=True)
        return similar_wos[:max_results]
    
    def _filter_by_work_order_relevance(self, results: List[SearchResult], work_order_data: Dict, max_results: int) -> List[SearchResult]:
        """Filter and rank results by work order relevance"""
        if not work_order_data:
            return results[:max_results]
        
        # Keywords for relevance scoring
        wo_keywords = [
            work_order_data.get('title', '').lower(),
            work_order_data.get('type', '').lower(),
            work_order_data.get('priority', '').lower(),
        ]
        
        # Extract asset information if available
        asset_id = work_order_data.get('asset_id', '')
        if asset_id:
            from assets import assets_db
            asset_data = next((a for a in assets_db if a['id'] == asset_id), None)
            if asset_data:
                wo_keywords.extend([
                    asset_data.get('manufacturer', '').lower(),
                    asset_data.get('model', '').lower(),
                    asset_data.get('category', '').lower()
                ])
        
        wo_keywords = [k for k in wo_keywords if k]
        
        # Score results by keyword relevance
        scored_results = []
        for result in results:
            relevance_boost = 0
            text_lower = result.chunk.text.lower()
            filename_lower = result.chunk.filename.lower()
            
            for keyword in wo_keywords:
                if keyword in text_lower:
                    relevance_boost += 0.15
                if keyword in filename_lower:
                    relevance_boost += 0.25
            
            # Create new score combining original similarity + relevance boost
            new_score = result.score + relevance_boost
            scored_results.append((result, new_score))
        
        # Sort by enhanced score and return top results
        scored_results.sort(key=lambda x: x[1], reverse=True)
        return [result for result, _ in scored_results[:max_results]]

    async def generate_troubleshooting_steps(self, work_order_id: str, issue_description: str) -> List[Dict[str, Any]]:
        """Generate structured troubleshooting steps based on RAG results and similar cases"""
        # Get knowledge base results
        search_results = await self.search_troubleshooting_knowledge(work_order_id, issue_description, max_results=3)
        
        # Get similar work orders
        similar_cases = await self.search_similar_work_orders(work_order_id, issue_description, max_results=2)
        
        steps = []
        step_number = 1
        
        # Extract steps from search results
        for result in search_results:
            text = result.chunk.text
            confidence = result.score
            
            # Look for step-like patterns in the text
            step_patterns = [
                r'(?:step\s*)?(\d+)[\.\:\-]\s*([^\n]+)',
                r'^\s*(\d+)[\.\:\-]\s*([^\n]+)',
                r'([A-Z][a-z]+(?:\s+[a-z]+)*)\s*:\s*([^\n]+)'
            ]
            
            for pattern in step_patterns:
                matches = re.finditer(pattern, text, re.MULTILINE | re.IGNORECASE)
                for match in matches:
                    if len(match.groups()) >= 2:
                        title = match.group(1) if match.group(1).isdigit() else match.group(1)
                        description = match.group(2)
                        
                        steps.append({
                            'step_number': step_number,
                            'title': f"Step {step_number}: {title}" if title.isdigit() else title,
                            'description': description.strip(),
                            'estimated_time_minutes': self._estimate_step_time(description),
                            'required_tools': self._extract_tools(description),
                            'safety_notes': self._extract_safety_notes(description),
                            'confidence': confidence,
                            'source': result.chunk.filename
                        })
                        step_number += 1
        
        # If no structured steps found, generate generic ones
        if not steps:
            generic_steps = [
                {
                    'step_number': 1,
                    'title': 'Initial Assessment',
                    'description': 'Perform visual inspection and gather information about the issue',
                    'estimated_time_minutes': 15,
                    'required_tools': ['Flashlight', 'Multimeter', 'Safety equipment'],
                    'confidence': 0.7,
                    'source': 'Generated'
                },
                {
                    'step_number': 2,
                    'title': 'Consult Documentation',
                    'description': 'Review relevant manuals and troubleshooting guides',
                    'estimated_time_minutes': 10,
                    'required_tools': ['Manual', 'Tablet/smartphone'],
                    'confidence': 0.8,
                    'source': 'Generated'
                }
            ]
            steps.extend(generic_steps)
        
        return steps[:10]  # Limit to 10 steps for usability
    
    def _estimate_step_time(self, description: str) -> int:
        """Estimate time for a troubleshooting step based on keywords"""
        description_lower = description.lower()
        
        # Time-indicating keywords
        if any(word in description_lower for word in ['quick', 'check', 'verify', 'look']):
            return 5
        elif any(word in description_lower for word in ['test', 'measure', 'inspect']):
            return 15
        elif any(word in description_lower for word in ['replace', 'remove', 'install']):
            return 30
        elif any(word in description_lower for word in ['repair', 'rebuild', 'overhaul']):
            return 60
        else:
            return 20  # Default
    
    def _extract_tools(self, description: str) -> List[str]:
        """Extract required tools from step description"""
        tools = []
        description_lower = description.lower()
        
        tool_keywords = {
            'multimeter': ['multimeter', 'meter', 'electrical test'],
            'wrench': ['wrench', 'spanner', 'tighten', 'loosen'],
            'screwdriver': ['screwdriver', 'screw', 'bolt'],
            'flashlight': ['light', 'torch', 'illuminate', 'see'],
            'pressure gauge': ['pressure', 'psi', 'gauge'],
            'oil': ['oil', 'lubricate', 'grease'],
            'cleaning supplies': ['clean', 'wipe', 'debris', 'dirt']
        }
        
        for tool, keywords in tool_keywords.items():
            if any(keyword in description_lower for keyword in keywords):
                tools.append(tool.title())
        
        return tools
    
    def _extract_safety_notes(self, description: str) -> Optional[str]:
        """Extract safety considerations from step description"""
        description_lower = description.lower()
        
        safety_keywords = {
            'electrical': ['voltage', 'electrical', 'power', 'wire', 'circuit'],
            'mechanical': ['moving parts', 'rotation', 'pressure', 'hot', 'sharp'],
            'chemical': ['chemical', 'acid', 'solvent', 'toxic', 'fumes']
        }
        
        safety_notes = []
        
        if any(keyword in description_lower for keyword in safety_keywords['electrical']):
            safety_notes.append("Ensure power is disconnected and locked out")
        
        if any(keyword in description_lower for keyword in safety_keywords['mechanical']):
            safety_notes.append("Be aware of moving parts and hot surfaces")
        
        if any(keyword in description_lower for keyword in safety_keywords['chemical']):
            safety_notes.append("Use appropriate PPE and ensure proper ventilation")
        
        return "; ".join(safety_notes) if safety_notes else None

# Initialize work order RAG enhancer
work_order_rag = WorkOrderRAGEnhancer(rag_system)

# Work Order RAG API Functions
async def search_work_order_troubleshooting(work_order_id: str, issue_description: str, max_results: int = 5) -> List[SearchResult]:
    """Search troubleshooting knowledge for specific work order"""
    return await work_order_rag.search_troubleshooting_knowledge(work_order_id, issue_description, max_results)

async def get_similar_work_orders(work_order_id: str, issue_description: str, max_results: int = 3) -> List[Dict[str, Any]]:
    """Get similar past work orders for troubleshooting insights"""
    return await work_order_rag.search_similar_work_orders(work_order_id, issue_description, max_results)

async def generate_troubleshooting_response(work_order_id: str, issue_description: str) -> Dict[str, Any]:
    """Generate comprehensive troubleshooting response for work order"""
    start_time = time.time()
    
    # Get troubleshooting knowledge and similar cases
    search_results = await search_work_order_troubleshooting(work_order_id, issue_description)
    similar_cases = await get_similar_work_orders(work_order_id, issue_description)
    troubleshooting_steps = await work_order_rag.generate_troubleshooting_steps(work_order_id, issue_description)
    
    # Calculate confidence based on available information
    confidence = 0.5  # Base confidence
    if search_results:
        confidence += min(len(search_results) * 0.1, 0.3)
    if similar_cases:
        confidence += min(len(similar_cases) * 0.1, 0.2)
    
    confidence = min(confidence, 1.0)
    
    # Create citations
    citations = []
    for result in search_results:
        citation = {
            'document_id': result.chunk.document_id,
            'filename': result.chunk.filename,
            'page_number': result.chunk.page_number,
            'section_title': result.chunk.section_title,
            'chunk_text': result.chunk.text[:200] + "..." if len(result.chunk.text) > 200 else result.chunk.text,
            'relevance_score': result.score
        }
        citations.append(citation)
    
    # Generate analysis
    analysis_parts = []
    if search_results:
        analysis_parts.append("Based on available documentation and procedures:")
        best_result = search_results[0]
        analysis_parts.append(best_result.chunk.text[:300] + "...")
    
    if similar_cases:
        analysis_parts.append(f"\nSimilar issues have been resolved {len(similar_cases)} time(s) in the past.")
        top_case = similar_cases[0]
        analysis_parts.append(f"Most similar case: {top_case['issue_description'][:100]}...")
    
    if not analysis_parts:
        analysis_parts.append("Limited specific guidance available. Recommend following general troubleshooting procedures.")
    
    processing_time = int((time.time() - start_time) * 1000)
    
    return {
        'work_order_id': work_order_id,
        'issue_analysis': "\n".join(analysis_parts),
        'recommended_steps': troubleshooting_steps,
        'similar_cases': similar_cases,
        'confidence': confidence,
        'citations': citations,
        'estimated_resolution_time_hours': sum([s.get('estimated_time_minutes', 20) for s in troubleshooting_steps]) / 60.0,
        'required_parts': [],  # Would be extracted from steps in full implementation
        'required_skills': ['General maintenance', 'Troubleshooting'],
        'safety_warnings': [s.get('safety_notes') for s in troubleshooting_steps if s.get('safety_notes')],
        'processing_time_ms': processing_time
    }

# =============================================================================
# AI Copilot Vendor Catalog Search System
# =============================================================================

@dataclass
class PartSource:
    """Represents a part source from vendor catalogs or web search"""
    vendor_name: str
    part_number: str
    description: str
    price: Optional[float] = None
    availability: str = "Unknown"
    lead_time_days: Optional[int] = None
    source_url: Optional[str] = None
    confidence: float = 0.0
    last_updated: str = ""
    specifications: Optional[Dict[str, str]] = None

class VendorCatalogSearcher:
    """AI-powered vendor catalog search and web sourcing system"""
    
    def __init__(self):
        self.cache = {}
        self.cache_duration = 3600  # 1 hour cache
        self.vendor_apis = {
            "grainger": self._search_grainger_mock,
            "mcmaster": self._search_mcmaster_mock,
            "motion_industries": self._search_motion_mock
        }
        
        # Common vendor domains for web scraping
        self.vendor_domains = {
            "grainger.com": "Grainger",
            "mcmaster.com": "McMaster-Carr",
            "motionindustries.com": "Motion Industries",
            "bearingboys.co.uk": "Bearing Boys",
            "skf.com": "SKF",
            "timken.com": "Timken",
            "parker.com": "Parker Hannifin",
            "gates.com": "Gates Corporation"
        }
        
        self.logger = logging.getLogger(__name__)
        
    async def find_part_sources(self, part_info: Dict[str, Any], confidence_threshold: float = 0.7) -> List[PartSource]:
        """Find part sources with pricing and availability - NO HALLUCINATION policy"""
        start_time = time.time()
        sources = []
        
        # Extract search parameters
        part_number = part_info.get('part_number', '').strip()
        manufacturer = part_info.get('manufacturer', '').strip()
        description = part_info.get('description', '').strip()
        category = part_info.get('category', '').strip()
        
        # Create cache key
        cache_key = f"{part_number}_{manufacturer}_{category}".replace(' ', '_')
        
        # Check cache first
        if cache_key in self.cache:
            cached_data = self.cache[cache_key]
            if time.time() - cached_data['timestamp'] < self.cache_duration:
                self.logger.info(f"Returning cached results for {part_number}")
                return cached_data['sources']
        
        # Validate inputs - NO GUESSING
        if not any([part_number, manufacturer, description]):
            self.logger.warning("Insufficient part information for reliable sourcing")
            return []
        
        # Search known vendor APIs
        for vendor_name, search_func in self.vendor_apis.items():
            try:
                vendor_results = await search_func(part_info)
                for result in vendor_results:
                    if result.confidence >= confidence_threshold:
                        sources.append(result)
                    else:
                        self.logger.debug(f"Skipping {vendor_name} result - confidence {result.confidence} below threshold")
            except Exception as e:
                self.logger.warning(f"Vendor {vendor_name} search failed: {e}")
        
        # Web search for additional sources (controlled scraping)
        web_results = await self._intelligent_web_search(part_info, confidence_threshold)
        sources.extend(web_results)
        
        # Sort by confidence, then by price
        sources.sort(key=lambda x: (-x.confidence, x.price or float('inf')))
        
        # Cache results
        self.cache[cache_key] = {
            'sources': sources,
            'timestamp': time.time()
        }
        
        processing_time = int((time.time() - start_time) * 1000)
        self.logger.info(f"Found {len(sources)} sources for {part_number} in {processing_time}ms")
        
        return sources
        
    async def _search_grainger_mock(self, part_info: Dict[str, Any]) -> List[PartSource]:
        """Mock Grainger API search - replace with real API integration"""
        # This would integrate with Grainger's API in production
        part_number = part_info.get('part_number', '')
        
        # Simulate API results based on pattern matching
        mock_results = []
        if 'bearing' in part_info.get('category', '').lower():
            mock_results.append(PartSource(
                vendor_name="Grainger",
                part_number=f"GR-{part_number}" if part_number else "GR-BEARING-001",
                description=f"Industrial Bearing - {part_info.get('description', 'Generic Bearing')}",
                price=45.99,
                availability="In Stock",
                lead_time_days=1,
                source_url="https://www.grainger.com/category/bearings",
                confidence=0.85,
                last_updated=datetime.now(timezone.utc).isoformat(),
                specifications={"brand": "SKF", "material": "Steel"}
            ))
            
        return mock_results
        
    async def _search_mcmaster_mock(self, part_info: Dict[str, Any]) -> List[PartSource]:
        """Mock McMaster-Carr API search"""
        part_number = part_info.get('part_number', '')
        
        mock_results = []
        if 'fastener' in part_info.get('category', '').lower() or 'bolt' in part_info.get('description', '').lower():
            mock_results.append(PartSource(
                vendor_name="McMaster-Carr",
                part_number=f"MC-{part_number}" if part_number else "MC-FASTENER-001",
                description=f"Fastener Hardware - {part_info.get('description', 'Generic Fastener')}",
                price=12.50,
                availability="Ships Today",
                lead_time_days=1,
                source_url="https://www.mcmaster.com/fasteners",
                confidence=0.90,
                last_updated=datetime.now(timezone.utc).isoformat(),
                specifications={"grade": "Grade 8", "material": "Steel"}
            ))
            
        return mock_results
        
    async def _search_motion_mock(self, part_info: Dict[str, Any]) -> List[PartSource]:
        """Mock Motion Industries API search"""
        part_number = part_info.get('part_number', '')
        
        mock_results = []
        if 'hydraulic' in part_info.get('category', '').lower():
            mock_results.append(PartSource(
                vendor_name="Motion Industries",
                part_number=f"MI-{part_number}" if part_number else "MI-HYDRAULIC-001",
                description=f"Hydraulic Component - {part_info.get('description', 'Generic Hydraulic Part')}",
                price=125.00,
                availability="2-3 Days",
                lead_time_days=3,
                source_url="https://www.motionindustries.com/hydraulics",
                confidence=0.75,
                last_updated=datetime.now(timezone.utc).isoformat(),
                specifications={"pressure_rating": "3000 PSI", "material": "Steel"}
            ))
            
        return mock_results
        
    async def _intelligent_web_search(self, part_info: Dict[str, Any], confidence_threshold: float) -> List[PartSource]:
        """Intelligent web scraping with confidence scoring - NO HALLUCINATION"""
        # This is a mock implementation - real implementation would use controlled web scraping
        web_results = []
        
        part_number = part_info.get('part_number', '')
        manufacturer = part_info.get('manufacturer', '')
        
        # Only return results if we have high confidence data
        if part_number and manufacturer:
            # Simulate finding the part on a vendor website
            web_results.append(PartSource(
                vendor_name="Industrial Parts Supplier",
                part_number=part_number,
                description=f"OEM Part - {part_info.get('description', 'Industrial Component')}",
                price=None,  # Price requires quote
                availability="Contact for Availability",
                lead_time_days=7,
                source_url=f"https://example.com/parts/{part_number}",
                confidence=0.70,
                last_updated=datetime.now(timezone.utc).isoformat(),
                specifications={"manufacturer": manufacturer}
            ))
        
        # Filter by confidence threshold
        return [result for result in web_results if result.confidence >= confidence_threshold]
        
    async def get_substitute_parts(self, part_info: Dict[str, Any], safety_critical: bool = False) -> Dict[str, Any]:
        """Find substitute parts with safety checks - REQUIRES ENGINEERING APPROVAL for safety-critical parts"""
        substitutes = []
        safety_warnings = []
        
        # Import parts database
        try:
            from part import parts_db
        except ImportError:
            self.logger.error("Cannot import parts database")
            return {
                'substitutes': [],
                'safety_warnings': ["Cannot access parts database for substitute analysis"],
                'requires_approval': True,
                'confidence': 0.0
            }
        
        original_part = part_info.get('part_number', '')
        category = part_info.get('category', '').lower()
        
        # Find potential substitutes in database
        for part in parts_db:
            if part['category'].lower() == category and part['part_number'] != original_part:
                compatibility_score = self._calculate_compatibility_score(part_info, part)
                
                if compatibility_score >= 0.8:  # High compatibility threshold
                    substitutes.append({
                        'part_number': part['part_number'],
                        'name': part['name'],
                        'description': part['description'],
                        'manufacturer': part.get('manufacturer', 'Unknown'),
                        'unit_cost': part.get('unit_cost', 0),
                        'availability': part.get('quantity_on_hand', 0),
                        'compatibility_score': compatibility_score,
                        'substitute_type': 'OEM' if part.get('manufacturer') == part_info.get('manufacturer') else 'Aftermarket'
                    })
        
        # Add safety warnings and approval requirements
        if safety_critical:
            safety_warnings.extend([
                "⚠️ SAFETY-CRITICAL PART: Engineering approval required before substitution",
                "⚠️ Verify all specifications match exactly",
                "⚠️ Check compatibility with existing system",
                "⚠️ Review safety certifications and standards compliance"
            ])
        
        # Sort by compatibility score
        substitutes.sort(key=lambda x: x['compatibility_score'], reverse=True)
        
        overall_confidence = max([s['compatibility_score'] for s in substitutes]) if substitutes else 0.0
        
        return {
            'substitutes': substitutes[:5],  # Limit to top 5
            'safety_warnings': safety_warnings,
            'requires_approval': safety_critical or overall_confidence < 0.9,
            'confidence': overall_confidence,
            'original_part': original_part
        }
        
    def _calculate_compatibility_score(self, original_part: Dict, substitute_part: Dict) -> float:
        """Calculate compatibility score between parts"""
        score = 0.0
        
        # Category match (required)
        if original_part.get('category', '').lower() == substitute_part.get('category', '').lower():
            score += 0.4
        
        # Manufacturer match (preferred)
        if original_part.get('manufacturer', '').lower() == substitute_part.get('manufacturer', '').lower():
            score += 0.3
        
        # Description similarity
        orig_desc = original_part.get('description', '').lower()
        sub_desc = substitute_part.get('description', '').lower()
        
        common_words = set(orig_desc.split()) & set(sub_desc.split())
        if common_words:
            score += min(len(common_words) * 0.05, 0.3)
        
        return min(score, 1.0)

# Global vendor catalog searcher instance
vendor_catalog_searcher = VendorCatalogSearcher()