#!/usr/bin/env python3
"""
Safety Guidance and Compliance Management System
AI-powered safety protocols, risk assessment, and regulatory compliance
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from ai_model_provider import CentralizedAIProvider, AIResponse, AIProvider

logger = logging.getLogger(__name__)

# Safety router
safety_router = APIRouter(prefix="/safety", tags=["safety"])

class RiskLevel(Enum):
    """Risk level enumeration"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SafetyCategory(Enum):
    """Safety category enumeration"""
    ELECTRICAL = "electrical"
    MECHANICAL = "mechanical"
    CHEMICAL = "chemical"
    THERMAL = "thermal"
    PRESSURE = "pressure"
    FALL_PROTECTION = "fall_protection"
    CONFINED_SPACE = "confined_space"
    LOCKOUT_TAGOUT = "lockout_tagout"
    PPE = "ppe"
    ERGONOMIC = "ergonomic"

class ComplianceStandard(Enum):
    """Compliance standards enumeration"""
    OSHA = "osha"
    ANSI = "ansi"
    NFPA = "nfpa"
    API = "api"
    ASME = "asme"
    ISO = "iso"
    LOCAL_CODES = "local_codes"

@dataclass
class SafetyProtocol:
    """Safety protocol definition"""
    protocol_id: str
    title: str
    category: SafetyCategory
    risk_level: RiskLevel
    equipment_types: List[str]
    procedures: List[str]
    required_ppe: List[str]
    required_tools: List[str]
    warnings: List[str]
    emergency_contacts: List[str]
    compliance_standards: List[ComplianceStandard]
    last_updated: str
    review_frequency_days: int = 365
    training_required: bool = False
    permit_required: bool = False

class SafetyAssessmentRequest(BaseModel):
    """Safety assessment request model"""
    work_description: str
    asset_id: Optional[str] = None
    location: str
    equipment_involved: List[str] = []
    technician_level: str = "standard"  # apprentice, standard, senior, expert
    environmental_factors: List[str] = []  # weather, temperature, lighting, etc.

class SafetyResponse(BaseModel):
    """Safety guidance response model"""
    risk_assessment: Dict[str, Any]
    required_protocols: List[Dict[str, Any]]
    ppe_requirements: List[str]
    safety_checklist: List[str]
    warnings: List[str]
    emergency_procedures: List[str]
    compliance_notes: List[str]
    training_requirements: List[str]

class SafetyComplianceSystem:
    """Advanced AI-powered safety and compliance management"""
    
    def __init__(self, ai_provider: Optional[CentralizedAIProvider] = None):
        self.ai_provider = ai_provider or CentralizedAIProvider()
        self.safety_protocols = self._initialize_safety_protocols()
        self.hazard_database = self._load_hazard_database()
        self.compliance_requirements = self._load_compliance_requirements()
        self.emergency_contacts = self._load_emergency_contacts()
        
    def _initialize_safety_protocols(self) -> Dict[str, SafetyProtocol]:
        """Initialize comprehensive safety protocols"""
        return {
            "electrical_lockout": SafetyProtocol(
                protocol_id="ELEC_LOTO_001",
                title="Electrical Lockout/Tagout Procedures",
                category=SafetyCategory.ELECTRICAL,
                risk_level=RiskLevel.CRITICAL,
                equipment_types=["motors", "control_panels", "transformers", "switchgear"],
                procedures=[
                    "1. Notify affected personnel of shutdown",
                    "2. Identify all energy sources (electrical, stored energy)",
                    "3. Turn off equipment using normal operating controls",
                    "4. Isolate energy sources (disconnect switches, circuit breakers)",
                    "5. Apply lockout devices and personal locks",
                    "6. Apply danger tags with personal information",
                    "7. Verify zero energy state with calibrated meter",
                    "8. Test start controls to ensure isolation is effective"
                ],
                required_ppe=["arc_flash_suit", "dielectric_gloves", "safety_glasses", "hard_hat"],
                required_tools=["multimeter", "non_contact_voltage_tester", "lockout_devices"],
                warnings=[
                    "⚠️ DANGER: Electrical shock hazard - can cause death or serious injury",
                    "⚠️ Arc flash hazard - wear appropriate PPE rated for available fault current",
                    "⚠️ Only qualified electricians should perform electrical lockout procedures",
                    "⚠️ Test instruments before and after each use"
                ],
                emergency_contacts=["plant_electrician", "safety_supervisor", "emergency_services"],
                compliance_standards=[ComplianceStandard.OSHA, ComplianceStandard.NFPA],
                last_updated="2025-09-01",
                training_required=True,
                permit_required=True
            ),
            
            "confined_space": SafetyProtocol(
                protocol_id="CONF_SPACE_001",
                title="Confined Space Entry Procedures",
                category=SafetyCategory.CONFINED_SPACE,
                risk_level=RiskLevel.CRITICAL,
                equipment_types=["tanks", "vessels", "pits", "manholes", "silos"],
                procedures=[
                    "1. Obtain confined space entry permit",
                    "2. Test atmosphere for oxygen, combustible gases, toxic gases",
                    "3. Ventilate space with mechanical ventilation",
                    "4. Post attendant at entry point - never leave unattended",
                    "5. Establish communication procedures",
                    "6. Set up rescue equipment and procedures",
                    "7. Continuous atmospheric monitoring during entry",
                    "8. Emergency evacuation procedures ready"
                ],
                required_ppe=["full_body_harness", "respirator", "gas_monitor", "hard_hat", "safety_boots"],
                required_tools=["gas_detector", "ventilation_blower", "rescue_tripod", "communication_device"],
                warnings=[
                    "🚨 DANGER: Oxygen deficiency can cause unconsciousness and death",
                    "🚨 Toxic or combustible gases may be present",
                    "🚨 Never enter alone - always have trained attendant",
                    "🚨 Evacuate immediately if atmospheric conditions change"
                ],
                emergency_contacts=["confined_space_rescue_team", "safety_supervisor", "emergency_medical"],
                compliance_standards=[ComplianceStandard.OSHA],
                last_updated="2025-09-01",
                training_required=True,
                permit_required=True
            ),
            
            "pressure_vessel": SafetyProtocol(
                protocol_id="PRESS_VEST_001",
                title="Pressure Vessel and System Safety",
                category=SafetyCategory.PRESSURE,
                risk_level=RiskLevel.HIGH,
                equipment_types=["boilers", "pressure_vessels", "compressors", "steam_systems"],
                procedures=[
                    "1. Verify system is depressurized and cooled",
                    "2. Isolate and lock out energy sources",
                    "3. Install blank flanges or disconnect piping",
                    "4. Verify pressure gauges read zero",
                    "5. Open vents and drains where applicable",
                    "6. Use proper lifting equipment for heavy components",
                    "7. Follow hot work permit procedures if welding required"
                ],
                required_ppe=["safety_glasses", "hard_hat", "steel_toe_boots", "heat_resistant_gloves"],
                required_tools=["pressure_gauge", "thermometer", "proper_wrenches", "lifting_equipment"],
                warnings=[
                    "⚠️ HIGH PRESSURE: Can cause severe injury or death",
                    "⚠️ HIGH TEMPERATURE: Burn hazard from hot surfaces and fluids",
                    "⚠️ Verify complete depressurization before opening any connections",
                    "⚠️ Use proper torque specifications when reassembling"
                ],
                emergency_contacts=["boiler_inspector", "safety_supervisor", "emergency_services"],
                compliance_standards=[ComplianceStandard.ASME, ComplianceStandard.OSHA],
                last_updated="2025-09-01"
            ),
            
            "chemical_handling": SafetyProtocol(
                protocol_id="CHEM_HAND_001",
                title="Chemical Handling and Storage Safety",
                category=SafetyCategory.CHEMICAL,
                risk_level=RiskLevel.HIGH,
                equipment_types=["chemical_storage", "process_equipment", "transfer_pumps"],
                procedures=[
                    "1. Review Safety Data Sheet (SDS) before handling",
                    "2. Ensure proper ventilation in work area",
                    "3. Use appropriate chemical-resistant PPE",
                    "4. Have spill cleanup materials readily available",
                    "5. Use proper transfer equipment (pumps, containers)",
                    "6. Label all containers with contents and hazards",
                    "7. Follow proper disposal procedures for waste",
                    "8. Wash hands thoroughly after handling"
                ],
                required_ppe=["chemical_goggles", "face_shield", "chemical_gloves", "apron", "respirator"],
                required_tools=["spill_kit", "neutralizing_agents", "proper_containers", "labeling_supplies"],
                warnings=[
                    "☠️ TOXIC: May cause serious health effects",
                    "🔥 CORROSIVE: Can cause severe burns to skin and eyes",
                    "⚠️ REACTIVE: May react violently with other chemicals",
                    "🌬️ VAPORS: May be harmful if inhaled - ensure ventilation"
                ],
                emergency_contacts=["hazmat_team", "poison_control", "safety_supervisor", "emergency_medical"],
                compliance_standards=[ComplianceStandard.OSHA, ComplianceStandard.LOCAL_CODES],
                last_updated="2025-09-01",
                training_required=True
            ),
            
            "fall_protection": SafetyProtocol(
                protocol_id="FALL_PROT_001",
                title="Fall Protection and Working at Height",
                category=SafetyCategory.FALL_PROTECTION,
                risk_level=RiskLevel.HIGH,
                equipment_types=["ladders", "scaffolding", "elevated_platforms", "rooftops"],
                procedures=[
                    "1. Inspect all fall protection equipment before use",
                    "2. Use proper three-point contact on ladders",
                    "3. Secure ladder at proper angle (4:1 ratio)",
                    "4. Use fall arrest system for work above 6 feet",
                    "5. Establish controlled access zone",
                    "6. Maintain 100% tie-off when moving at height",
                    "7. Have rescue plan in case of fall arrest"
                ],
                required_ppe=["full_body_harness", "shock_absorbing_lanyard", "hard_hat", "safety_boots"],
                required_tools=["proper_ladder", "anchor_points", "rescue_equipment"],
                warnings=[
                    "⚠️ FALL HAZARD: Falls can cause serious injury or death",
                    "⚠️ Inspect equipment before each use - damaged equipment can fail",
                    "⚠️ Never work alone at height - maintain communication",
                    "⚠️ Weather conditions affect safety - avoid work during storms"
                ],
                emergency_contacts=["rescue_team", "safety_supervisor", "emergency_medical"],
                compliance_standards=[ComplianceStandard.OSHA],
                last_updated="2025-09-01",
                training_required=True
            )
        }
    
    def _load_hazard_database(self) -> Dict[str, Any]:
        """Load comprehensive hazard identification database"""
        return {
            "electrical_hazards": {
                "shock": {
                    "description": "Contact with energized conductors",
                    "severity": "critical",
                    "prevention": ["lockout_tagout", "ppe", "training"],
                    "indicators": ["exposed_wiring", "wet_conditions", "damaged_insulation"]
                },
                "arc_flash": {
                    "description": "Explosive release of energy during electrical fault",
                    "severity": "critical", 
                    "prevention": ["arc_flash_ppe", "proper_procedures", "equipment_maintenance"],
                    "indicators": ["high_fault_current", "old_equipment", "poor_maintenance"]
                }
            },
            "mechanical_hazards": {
                "crushing": {
                    "description": "Body parts caught in or struck by machinery",
                    "severity": "critical",
                    "prevention": ["machine_guarding", "lockout_tagout", "proper_procedures"],
                    "indicators": ["unguarded_machinery", "pinch_points", "rotating_equipment"]
                },
                "cuts_lacerations": {
                    "description": "Contact with sharp edges or tools",
                    "severity": "high",
                    "prevention": ["cut_resistant_gloves", "proper_tools", "good_housekeeping"],
                    "indicators": ["sharp_edges", "damaged_tools", "metal_shavings"]
                }
            },
            "chemical_hazards": {
                "toxic_exposure": {
                    "description": "Inhalation, ingestion, or skin contact with toxic substances",
                    "severity": "critical",
                    "prevention": ["ventilation", "ppe", "proper_handling", "training"],
                    "indicators": ["strong_odors", "vapor_generation", "skin_irritation"]
                },
                "corrosive_burns": {
                    "description": "Chemical burns from acids, bases, or other corrosives",
                    "severity": "high",
                    "prevention": ["chemical_ppe", "emergency_shower", "proper_procedures"],
                    "indicators": ["corrosive_chemicals", "leaking_containers", "damaged_ppe"]
                }
            },
            "environmental_hazards": {
                "extreme_temperature": {
                    "description": "Exposure to high or low temperatures",
                    "severity": "medium",
                    "prevention": ["thermal_ppe", "cooling_systems", "work_rest_cycles"],
                    "indicators": ["hot_surfaces", "steam_leaks", "cold_storage_areas"]
                },
                "noise_exposure": {
                    "description": "Prolonged exposure to high noise levels",
                    "severity": "medium",
                    "prevention": ["hearing_protection", "noise_control", "exposure_limits"],
                    "indicators": ["loud_machinery", "impact_noise", "communication_difficulty"]
                }
            }
        }
    
    def _load_compliance_requirements(self) -> Dict[str, Any]:
        """Load regulatory compliance requirements"""
        return {
            "osha_1910": {
                "section_147": "Control of Hazardous Energy (Lockout/Tagout)",
                "section_146": "Permit-Required Confined Spaces", 
                "section_132": "Personal Protective Equipment",
                "section_95": "Personal Protective Equipment for Eyes, Face, and Head"
            },
            "nfpa_70e": {
                "arc_flash_analysis": "Required for systems >240V",
                "electrical_ppe": "Arc flash protection based on incident energy",
                "qualified_person": "Training and certification requirements"
            },
            "asme_codes": {
                "boiler_code": "Section I - Power Boilers",
                "pressure_vessel": "Section VIII - Pressure Vessels"
            }
        }
    
    def _load_emergency_contacts(self) -> Dict[str, Dict[str, str]]:
        """Load emergency contact information"""
        return {
            "emergency_services": {"phone": "911", "description": "Fire, Medical, Police"},
            "safety_supervisor": {"phone": "ext. 2911", "description": "Plant Safety Manager"},
            "plant_electrician": {"phone": "ext. 3400", "description": "Licensed Electrician"},
            "hazmat_team": {"phone": "ext. 2922", "description": "Hazardous Materials Response"},
            "confined_space_rescue": {"phone": "ext. 2933", "description": "Confined Space Rescue Team"},
            "poison_control": {"phone": "1-800-222-1222", "description": "Poison Control Center"},
            "maintenance_supervisor": {"phone": "ext. 3100", "description": "Maintenance Manager"}
        }

    async def assess_work_safety(self, request: SafetyAssessmentRequest) -> SafetyResponse:
        """Comprehensive AI-powered safety assessment"""
        
        # Use AI to analyze the work description for hazards
        hazard_analysis = await self._analyze_hazards_with_ai(request)
        
        # Identify applicable safety protocols
        applicable_protocols = self._identify_safety_protocols(request, hazard_analysis)
        
        # Generate risk assessment
        risk_assessment = self._generate_risk_assessment(request, hazard_analysis, applicable_protocols)
        
        # Compile safety requirements
        ppe_requirements = self._compile_ppe_requirements(applicable_protocols)
        safety_checklist = self._generate_safety_checklist(applicable_protocols)
        warnings = self._compile_warnings(applicable_protocols)
        emergency_procedures = self._compile_emergency_procedures(applicable_protocols)
        compliance_notes = self._generate_compliance_notes(applicable_protocols)
        training_requirements = self._identify_training_requirements(applicable_protocols)
        
        return SafetyResponse(
            risk_assessment=risk_assessment,
            required_protocols=[
                {
                    "protocol_id": protocol.protocol_id,
                    "title": protocol.title,
                    "category": protocol.category.value,
                    "risk_level": protocol.risk_level.value,
                    "procedures": protocol.procedures,
                    "permit_required": protocol.permit_required,
                    "training_required": protocol.training_required
                }
                for protocol in applicable_protocols
            ],
            ppe_requirements=ppe_requirements,
            safety_checklist=safety_checklist,
            warnings=warnings,
            emergency_procedures=emergency_procedures,
            compliance_notes=compliance_notes,
            training_requirements=training_requirements
        )

    async def _analyze_hazards_with_ai(self, request: SafetyAssessmentRequest) -> Dict[str, Any]:
        """Use AI to analyze potential hazards in work description"""
        
        hazard_analysis_prompt = f"""You are an expert industrial safety analyst. Analyze this maintenance work for potential hazards:

Work Description: {request.work_description}
Asset: {request.asset_id}
Location: {request.location}
Equipment: {request.equipment_involved}
Environment: {request.environmental_factors}
Technician Level: {request.technician_level}

Identify and categorize all potential hazards. Return JSON format:
{{
    "primary_hazards": [
        {{
            "type": "electrical|mechanical|chemical|thermal|pressure|fall|confined_space",
            "severity": "low|medium|high|critical",
            "description": "specific hazard description",
            "likelihood": "low|medium|high",
            "affected_body_parts": ["head", "eyes", "hands", "feet", "respiratory"],
            "mitigation_required": true/false
        }}
    ],
    "secondary_hazards": [...],
    "environmental_factors": [...],
    "special_considerations": [...]
}}

Be thorough and consider both obvious and hidden hazards."""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=hazard_analysis_prompt,
                system_context="You are a certified safety professional with 20+ years in industrial safety.",
                provider_type=AIProvider.LLAMA
            )
            
            # Try to parse JSON response
            hazard_analysis = self._parse_ai_hazard_response(ai_response.content if ai_response else "")
            
        except Exception as e:
            logger.error(f"AI hazard analysis failed: {e}")
            hazard_analysis = self._fallback_hazard_analysis(request)
            
        return hazard_analysis
    
    def _parse_ai_hazard_response(self, ai_response: str) -> Dict[str, Any]:
        """Parse AI hazard analysis response"""
        try:
            import json
            import re
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except:
            pass
        
        # Fallback parsing
        return {
            "primary_hazards": [],
            "secondary_hazards": [],
            "environmental_factors": [],
            "special_considerations": ["AI analysis unavailable - manual review recommended"]
        }
    
    def _fallback_hazard_analysis(self, request: SafetyAssessmentRequest) -> Dict[str, Any]:
        """Fallback hazard analysis when AI is unavailable"""
        hazards = []
        work_lower = request.work_description.lower()
        
        # Basic hazard detection based on keywords
        if any(word in work_lower for word in ["electrical", "motor", "panel", "wire", "voltage"]):
            hazards.append({
                "type": "electrical",
                "severity": "critical",
                "description": "Electrical shock and arc flash hazards",
                "likelihood": "high",
                "affected_body_parts": ["hands", "eyes", "respiratory"],
                "mitigation_required": True
            })
        
        if any(word in work_lower for word in ["chemical", "oil", "solvent", "acid", "cleaning"]):
            hazards.append({
                "type": "chemical",
                "severity": "high", 
                "description": "Chemical exposure hazards",
                "likelihood": "medium",
                "affected_body_parts": ["skin", "eyes", "respiratory"],
                "mitigation_required": True
            })
            
        if any(word in work_lower for word in ["height", "ladder", "scaffold", "roof", "platform"]):
            hazards.append({
                "type": "fall",
                "severity": "critical",
                "description": "Fall from height hazards",
                "likelihood": "medium",
                "affected_body_parts": ["head", "back", "limbs"],
                "mitigation_required": True
            })
        
        return {
            "primary_hazards": hazards,
            "secondary_hazards": [],
            "environmental_factors": request.environmental_factors,
            "special_considerations": ["Manual hazard analysis - AI assistance recommended"]
        }
    
    def _identify_safety_protocols(self, request: SafetyAssessmentRequest, hazard_analysis: Dict) -> List[SafetyProtocol]:
        """Identify applicable safety protocols based on hazards"""
        applicable_protocols = []
        
        # Map hazard types to protocols
        hazard_protocol_map = {
            "electrical": ["electrical_lockout"],
            "confined_space": ["confined_space"],
            "pressure": ["pressure_vessel"],
            "chemical": ["chemical_handling"],
            "fall": ["fall_protection"]
        }
        
        # Check primary hazards
        for hazard in hazard_analysis.get("primary_hazards", []):
            hazard_type = hazard.get("type", "")
            if hazard_type in hazard_protocol_map:
                for protocol_id in hazard_protocol_map[hazard_type]:
                    if protocol_id in self.safety_protocols:
                        protocol = self.safety_protocols[protocol_id]
                        if protocol not in applicable_protocols:
                            applicable_protocols.append(protocol)
        
        # Check equipment types
        for equipment in request.equipment_involved:
            for protocol in self.safety_protocols.values():
                if any(eq_type in equipment.lower() for eq_type in protocol.equipment_types):
                    if protocol not in applicable_protocols:
                        applicable_protocols.append(protocol)
        
        # Sort by risk level (critical first)
        risk_order = {RiskLevel.CRITICAL: 0, RiskLevel.HIGH: 1, RiskLevel.MEDIUM: 2, RiskLevel.LOW: 3}
        applicable_protocols.sort(key=lambda p: risk_order.get(p.risk_level, 999))
        
        return applicable_protocols
    
    def _generate_risk_assessment(self, request: SafetyAssessmentRequest, hazard_analysis: Dict, protocols: List[SafetyProtocol]) -> Dict[str, Any]:
        """Generate comprehensive risk assessment"""
        
        # Calculate overall risk level
        hazard_severities = [hazard.get("severity", "low") for hazard in hazard_analysis.get("primary_hazards", [])]
        
        overall_risk = "low"
        if "critical" in hazard_severities:
            overall_risk = "critical"
        elif "high" in hazard_severities:
            overall_risk = "high"
        elif "medium" in hazard_severities:
            overall_risk = "medium"
        
        # Risk factors
        risk_factors = []
        if request.technician_level == "apprentice":
            risk_factors.append("Inexperienced technician - additional supervision required")
        
        if "poor_lighting" in request.environmental_factors:
            risk_factors.append("Poor lighting conditions increase accident risk")
            
        if "extreme_temperature" in request.environmental_factors:
            risk_factors.append("Extreme temperature affects PPE effectiveness and worker performance")
        
        # Required permits
        required_permits = []
        for protocol in protocols:
            if protocol.permit_required:
                required_permits.append(f"{protocol.title} - Permit Required")
        
        return {
            "overall_risk_level": overall_risk,
            "hazard_count": len(hazard_analysis.get("primary_hazards", [])),
            "critical_hazards": len([h for h in hazard_analysis.get("primary_hazards", []) if h.get("severity") == "critical"]),
            "risk_factors": risk_factors,
            "required_permits": required_permits,
            "estimated_risk_reduction": "85%" if protocols else "0%",
            "assessment_confidence": "high" if protocols else "medium"
        }
    
    def _compile_ppe_requirements(self, protocols: List[SafetyProtocol]) -> List[str]:
        """Compile all required PPE from applicable protocols"""
        all_ppe = set()
        for protocol in protocols:
            all_ppe.update(protocol.required_ppe)
        
        return sorted(list(all_ppe))
    
    def _generate_safety_checklist(self, protocols: List[SafetyProtocol]) -> List[str]:
        """Generate comprehensive safety checklist"""
        checklist = [
            "□ Review all applicable safety protocols",
            "□ Verify technician training and qualifications",
            "□ Inspect all required PPE before use",
            "□ Confirm emergency procedures and contacts",
            "□ Establish communication plan"
        ]
        
        # Add protocol-specific items
        for protocol in protocols:
            checklist.append(f"□ Follow {protocol.title} procedures")
            if protocol.permit_required:
                checklist.append(f"□ Obtain required permit for {protocol.title}")
            if protocol.training_required:
                checklist.append(f"□ Verify training certification for {protocol.title}")
        
        return checklist
    
    def _compile_warnings(self, protocols: List[SafetyProtocol]) -> List[str]:
        """Compile all safety warnings"""
        all_warnings = []
        for protocol in protocols:
            all_warnings.extend(protocol.warnings)
        
        return list(set(all_warnings))  # Remove duplicates
    
    def _compile_emergency_procedures(self, protocols: List[SafetyProtocol]) -> List[str]:
        """Compile emergency procedures and contacts"""
        procedures = [
            "In case of emergency:",
            "1. Ensure personal safety first",
            "2. Call 911 for life-threatening emergencies", 
            "3. Notify safety supervisor immediately",
            "4. Provide first aid if trained and safe to do so",
            "5. Preserve accident scene for investigation"
        ]
        
        # Add specific emergency contacts
        emergency_contacts = set()
        for protocol in protocols:
            emergency_contacts.update(protocol.emergency_contacts)
        
        for contact in emergency_contacts:
            if contact in self.emergency_contacts:
                contact_info = self.emergency_contacts[contact]
                procedures.append(f"{contact_info['description']}: {contact_info['phone']}")
        
        return procedures
    
    def _generate_compliance_notes(self, protocols: List[SafetyProtocol]) -> List[str]:
        """Generate regulatory compliance notes"""
        compliance_notes = []
        standards_mentioned = set()
        
        for protocol in protocols:
            for standard in protocol.compliance_standards:
                if standard not in standards_mentioned:
                    standards_mentioned.add(standard)
                    compliance_notes.append(f"{standard.value.upper()} compliance required for {protocol.title}")
        
        return compliance_notes
    
    def _identify_training_requirements(self, protocols: List[SafetyProtocol]) -> List[str]:
        """Identify required training and certifications"""
        training_requirements = []
        
        for protocol in protocols:
            if protocol.training_required:
                training_requirements.append(f"{protocol.title} - Certification Required")
        
        # Add general requirements
        training_requirements.extend([
            "General safety orientation",
            "Hazard recognition training",
            "Emergency response procedures"
        ])
        
        return list(set(training_requirements))  # Remove duplicates

    async def generate_safety_sop(self, work_description: str, protocols: List[str]) -> Dict[str, Any]:
        """Generate AI-powered Standard Operating Procedure for safety"""
        
        sop_prompt = f"""Generate a detailed Standard Operating Procedure (SOP) for this maintenance work:

Work Description: {work_description}
Safety Protocols Required: {', '.join(protocols)}

Create a step-by-step SOP that includes:
1. Pre-work safety preparation
2. Step-by-step procedures with safety checks
3. Post-work verification and cleanup
4. Emergency response procedures

Format as numbered steps with safety checkpoints integrated throughout."""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=sop_prompt,
                system_context="You are an expert safety engineer creating detailed maintenance SOPs.",
                provider_type=AIProvider.LLAMA
            )
            
            sop_content = ai_response.content if ai_response else "SOP generation unavailable"
            
            return {
                "work_description": work_description,
                "sop_content": sop_content,
                "protocols_referenced": protocols,
                "generated_timestamp": datetime.now().isoformat(),
                "review_required": True,
                "approval_needed": True
            }
            
        except Exception as e:
            logger.error(f"SOP generation failed: {e}")
            return {
                "error": "SOP generation unavailable",
                "fallback_message": "Please refer to existing safety protocols and create manual SOP"
            }

# Global instance
safety_system = SafetyComplianceSystem()

# API Endpoints
@safety_router.post("/assess", response_model=SafetyResponse)
async def assess_work_safety(request: SafetyAssessmentRequest):
    """Comprehensive safety assessment for maintenance work"""
    return await safety_system.assess_work_safety(request)

@safety_router.get("/protocols")
async def get_safety_protocols(category: Optional[str] = None):
    """Get available safety protocols, optionally filtered by category"""
    protocols = safety_system.safety_protocols
    
    if category:
        protocols = {
            k: v for k, v in protocols.items() 
            if v.category.value.lower() == category.lower()
        }
    
    return {
        "total_protocols": len(protocols),
        "protocols": [
            {
                "protocol_id": protocol.protocol_id,
                "title": protocol.title,
                "category": protocol.category.value,
                "risk_level": protocol.risk_level.value,
                "equipment_types": protocol.equipment_types,
                "training_required": protocol.training_required,
                "permit_required": protocol.permit_required
            }
            for protocol in protocols.values()
        ]
    }

@safety_router.get("/emergency-contacts")
async def get_emergency_contacts():
    """Get emergency contact information"""
    return {
        "emergency_contacts": safety_system.emergency_contacts,
        "last_updated": datetime.now().isoformat()
    }

@safety_router.post("/generate-sop")
async def generate_safety_sop(
    work_description: str,
    protocols: List[str] = Query(default=[])
):
    """Generate AI-powered Safety SOP"""
    return await safety_system.generate_safety_sop(work_description, protocols)

@safety_router.get("/compliance/{standard}")
async def get_compliance_requirements(standard: str):
    """Get compliance requirements for specific standard"""
    standard_lower = standard.lower()
    
    if standard_lower in safety_system.compliance_requirements:
        return {
            "standard": standard,
            "requirements": safety_system.compliance_requirements[standard_lower]
        }
    else:
        raise HTTPException(status_code=404, detail="Compliance standard not found")

# Export main components
__all__ = ['safety_router', 'SafetyComplianceSystem', 'safety_system', 'SafetyAssessmentRequest', 'SafetyResponse']