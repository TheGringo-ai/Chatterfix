#!/usr/bin/env python3
"""
ChatterFix CMMS - Enhanced Security Authentication Module
Provides secure auth endpoints with session management and revocation
"""

import secrets
from datetime import datetime, timezone
from typing import Dict, List, Optional
from fastapi import APIRouter, HTTPException, Depends, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from auth_rbac import (
    authenticate_user_with_security,
    refresh_access_token,
    logout_user,
    change_password_with_security,
    get_active_sessions,
    revoke_all_user_sessions,
    revoke_token,
    get_current_user,
    decode_token,
    Permission,
    require_permissions,
    AuthUser,
    LoginRequest,
    LoginResponse
)

# Initialize router and security
router = APIRouter(prefix="/auth", tags=["Authentication"])
security = HTTPBearer()

# =============================================================================
# Request/Response Models
# =============================================================================

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

class SessionInfo(BaseModel):
    jti: str
    created_at: str
    last_activity: str
    ip_address: Optional[str]
    user_agent: Optional[str]
    is_current: bool = False

class SessionsResponse(BaseModel):
    sessions: List[SessionInfo]
    total_sessions: int

class RevokeSessionRequest(BaseModel):
    session_jti: str

class SecurityStatusResponse(BaseModel):
    user_id: str
    username: str
    role: str
    active_sessions: int
    last_login: Optional[str]
    password_last_changed: Optional[str]
    account_locked: bool
    failed_attempts: int

# =============================================================================
# Authentication Endpoints
# =============================================================================

@router.post("/login", response_model=LoginResponse)
async def login(
    request: Request,
    login_data: LoginRequest
):
    """
    Enhanced secure login with session tracking
    """
    try:
        # Get client information
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        # Authenticate with enhanced security
        result = authenticate_user_with_security(
            username=login_data.username,
            password=login_data.password,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "Invalid credentials or account locked",
                    "request_id": secrets.token_urlsafe(8)
                }
            )
        
        # Create response with request ID for audit trail
        response_data = LoginResponse(
            access_token=result["access_token"],
            refresh_token=result["refresh_token"],
            token_type=result["token_type"],
            expires_in=result["expires_in"],
            refresh_expires_in=result["refresh_expires_in"],
            user=AuthUser(**result["user"]),
            request_id=secrets.token_urlsafe(8)
        )
        
        return response_data
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Authentication service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

@router.post("/refresh")
async def refresh_token(
    request: Request,
    refresh_data: RefreshTokenRequest
):
    """
    Refresh access token with security validation
    """
    try:
        # Get client information
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        # Refresh token with enhanced security
        result = refresh_access_token(
            refresh_token=refresh_data.refresh_token,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "Invalid or expired refresh token",
                    "request_id": secrets.token_urlsafe(8)
                }
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Token refresh service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

@router.post("/logout")
async def logout(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """
    Logout user by revoking current session
    """
    try:
        success = logout_user(credentials.credentials)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "Logout failed - invalid token",
                    "request_id": secrets.token_urlsafe(8)
                }
            )
        
        return {
            "message": "Successfully logged out",
            "request_id": secrets.token_urlsafe(8)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Logout service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

# =============================================================================
# Session Management Endpoints
# =============================================================================

@router.get("/sessions", response_model=SessionsResponse)
@require_permissions(Permission.ADMIN_VIEW)
async def get_user_sessions(
    current_user: AuthUser = Depends(get_current_user),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """
    Get all active sessions for current user
    """
    try:
        # Get current token JTI for marking current session
        current_token_data = decode_token(credentials.credentials)
        current_jti = current_token_data.jti if current_token_data else None
        
        # Get active sessions
        sessions = get_active_sessions(current_user.id)
        
        # Convert to response format
        session_infos = []
        for session in sessions:
            session_infos.append(SessionInfo(
                jti=session["jti"],
                created_at=session["created_at"],
                last_activity=session["last_activity"],
                ip_address=session["ip_address"],
                user_agent=session["user_agent"],
                is_current=(session["jti"] == current_jti)
            ))
        
        return SessionsResponse(
            sessions=session_infos,
            total_sessions=len(session_infos)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Session retrieval service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

@router.post("/sessions/revoke")
@require_permissions(Permission.ADMIN_VIEW)
async def revoke_session(
    revoke_data: RevokeSessionRequest,
    current_user: AuthUser = Depends(get_current_user),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """
    Revoke a specific session
    """
    try:
        # Prevent users from revoking their current session via this endpoint
        current_token_data = decode_token(credentials.credentials)
        if current_token_data and current_token_data.jti == revoke_data.session_jti:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "Cannot revoke current session. Use logout instead.",
                    "request_id": secrets.token_urlsafe(8)
                }
            )
        
        # Revoke the specified session
        revoke_token(revoke_data.session_jti)
        
        return {
            "message": "Session revoked successfully",
            "revoked_session": revoke_data.session_jti,
            "request_id": secrets.token_urlsafe(8)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Session revocation service temporarily unavailable", 
                "request_id": secrets.token_urlsafe(8)
            }
        )

@router.post("/sessions/revoke-all")
@require_permissions(Permission.ADMIN_VIEW)
async def revoke_all_sessions(
    current_user: AuthUser = Depends(get_current_user)
):
    """
    Revoke all sessions for current user (except current session)
    """
    try:
        # Revoke all user sessions
        revoke_all_user_sessions(current_user.id)
        
        return {
            "message": "All sessions revoked successfully",
            "user_id": current_user.id,
            "request_id": secrets.token_urlsafe(8)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Session revocation service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

# =============================================================================
# Security Management Endpoints
# =============================================================================

@router.post("/change-password")
async def change_password(
    password_data: ChangePasswordRequest,
    current_user: AuthUser = Depends(get_current_user)
):
    """
    Change user password with enhanced security
    """
    try:
        success = change_password_with_security(
            user_id=current_user.id,
            old_password=password_data.old_password,
            new_password=password_data.new_password
        )
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "Password change failed - invalid current password or weak new password",
                    "request_id": secrets.token_urlsafe(8)
                }
            )
        
        return {
            "message": "Password changed successfully. All sessions have been revoked.",
            "request_id": secrets.token_urlsafe(8)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Password change service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

@router.get("/security-status", response_model=SecurityStatusResponse)
async def get_security_status(
    current_user: AuthUser = Depends(get_current_user)
):
    """
    Get security status for current user
    """
    try:
        # Get active sessions
        sessions = get_active_sessions(current_user.id)
        
        # Create security status response
        return SecurityStatusResponse(
            user_id=current_user.id,
            username=current_user.username,
            role=current_user.role.value,
            active_sessions=len(sessions),
            last_login=sessions[0]["created_at"] if sessions else None,
            password_last_changed=None,  # Would be tracked in user profile
            account_locked=False,  # Would check lockout status
            failed_attempts=0  # Would get from failed attempts tracking
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Security status service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

# =============================================================================
# Admin Security Management
# =============================================================================

@router.post("/admin/revoke-user-sessions/{user_id}")
@require_permissions(Permission.ADMIN_USERS)
async def admin_revoke_user_sessions(
    user_id: str,
    current_user: AuthUser = Depends(get_current_user)
):
    """
    Admin endpoint to revoke all sessions for a specific user
    """
    try:
        # Prevent admin from revoking their own sessions via this endpoint
        if user_id == current_user.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "Cannot revoke your own sessions via admin endpoint",
                    "request_id": secrets.token_urlsafe(8)
                }
            )
        
        # Revoke all sessions for the specified user
        revoke_all_user_sessions(user_id)
        
        return {
            "message": f"All sessions revoked for user {user_id}",
            "revoked_user_id": user_id,
            "admin_user": current_user.username,
            "request_id": secrets.token_urlsafe(8)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Admin session revocation service temporarily unavailable",
                "request_id": secrets.token_urlsafe(8)
            }
        )

# =============================================================================
# Health Check
# =============================================================================

@router.get("/health")
async def auth_health_check():
    """
    Authentication service health check
    """
    return {
        "service": "authentication",
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "version": "2.0.0"
    }