#!/usr/bin/env python3
"""
Simple ChatterFix CMMS App with AIOps
Minimal deployment for testing AIOps functionality
"""

import logging
from datetime import datetime
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import AIOps components
try:
    from aiops_router import router as aiops_router
    AIOPS_AVAILABLE = True
    logger.info("🤖 AIOps Self-Healing System loaded successfully")
except ImportError as e:
    AIOPS_AVAILABLE = False
    logger.warning(f"⚠️ AIOps Self-Healing System not available: {e}")
    aiops_router = None

# Import Predictive Maintenance if available
try:
    from prediction_router import router as prediction_router
    PREDICTIVE_AVAILABLE = True
    logger.info("🔮 Predictive Maintenance Engine loaded successfully")
except ImportError as e:
    PREDICTIVE_AVAILABLE = False
    logger.warning(f"⚠️ Predictive Maintenance Engine not available: {e}")
    prediction_router = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info("🚀 ChatterFix CMMS (AIOps Demo) starting up...")
    logger.info("🤖 AIOps system ready")
    logger.info("🔮 Predictive maintenance ready")
    logger.info("✅ ChatterFix CMMS operational")
    yield
    logger.info("🛑 ChatterFix CMMS shutting down...")

# Create FastAPI app
app = FastAPI(
    title="ChatterFix CMMS - AIOps Demo",
    description="AIOps Self-Healing System Demo",
    version="1.0.0-aiops",
    lifespan=lifespan
)

# Include AIOps Router if available
if AIOPS_AVAILABLE and aiops_router:
    app.include_router(aiops_router)  # AIOps Self-Healing System

# Include Predictive Maintenance Router if available
if PREDICTIVE_AVAILABLE and prediction_router:
    app.include_router(prediction_router)  # Predictive Maintenance Engine

# Mount static files if directory exists
try:
    app.mount("/static", StaticFiles(directory="static"), name="static")
    logger.info("📁 Static files mounted")
except Exception as e:
    logger.warning(f"⚠️ Could not mount static files: {e}")

# Basic routes
@app.get("/", response_class=HTMLResponse)
async def root():
    """Main dashboard with AIOps features"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix CMMS - AIOps Demo</title>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; background: #f8f9fa; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }}
            .card {{ background: white; padding: 20px; border-radius: 8px; margin: 10px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
            .btn {{ padding: 8px 16px; margin: 4px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; display: inline-block; }}
            .btn:hover {{ background: #0056b3; }}
            .status {{ padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; }}
            .status.active {{ background: #d4edda; color: #155724; }}
            .status.inactive {{ background: #f8d7da; color: #721c24; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🤖 ChatterFix CMMS - AIOps Self-Healing System</h1>
                <p>Autonomous incident detection and remediation platform</p>
            </div>
            
            <div class="grid">
                <div class="card">
                    <h3>🚨 AIOps Monitoring</h3>
                    <p>Status: <span class="status {'active' if AIOPS_AVAILABLE else 'inactive'}">
                        {'Active' if AIOPS_AVAILABLE else 'Offline'}
                    </span></p>
                    <p>Real-time incident detection and automated remediation</p>
                    {'<a href="/ai/ops/summary/today" class="btn">View Today\'s Summary</a>' if AIOPS_AVAILABLE else ''}
                    {'<a href="/ai/ops/monitor/status" class="btn">System Status</a>' if AIOPS_AVAILABLE else ''}
                </div>
                
                <div class="card">
                    <h3>🔮 Predictive Maintenance</h3>
                    <p>Status: <span class="status {'active' if PREDICTIVE_AVAILABLE else 'inactive'}">
                        {'Active' if PREDICTIVE_AVAILABLE else 'Offline'}
                    </span></p>
                    <p>Asset risk prediction and maintenance scheduling</p>
                    {'<a href="/ai/predict/top-risk" class="btn">Top Risk Assets</a>' if PREDICTIVE_AVAILABLE else ''}
                    {'<a href="/ai/predict/health" class="btn">System Health</a>' if PREDICTIVE_AVAILABLE else ''}
                </div>
                
                <div class="card">
                    <h3>🔧 Self-Healing Playbooks</h3>
                    <p>Automated remediation workflows</p>
                    {'<a href="/ai/ops/actions/playbooks" class="btn">View Playbooks</a>' if AIOPS_AVAILABLE else ''}
                    {'<a href="/ai/ops/actions/executions" class="btn">Execution History</a>' if AIOPS_AVAILABLE else ''}
                </div>
                
                <div class="card">
                    <h3>📊 API Documentation</h3>
                    <p>Interactive API documentation and testing</p>
                    <a href="/docs" class="btn">OpenAPI Docs</a>
                    <a href="/redoc" class="btn">ReDoc</a>
                </div>
            </div>
            
            <div class="card">
                <h3>🧪 Quick Test AIOps Features</h3>
                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                    {'<button onclick="testRestartPlaybook()" class="btn">Test App Restart</button>' if AIOPS_AVAILABLE else ''}
                    {'<button onclick="testHealthCheck()" class="btn">Test Health Check</button>' if AIOPS_AVAILABLE else ''}
                    {'<button onclick="testLogScan()" class="btn">Test Log Scan</button>' if AIOPS_AVAILABLE else ''}
                    {'<button onclick="testPrediction()" class="btn">Test Risk Prediction</button>' if PREDICTIVE_AVAILABLE else ''}
                </div>
                <div id="testResults" style="margin-top: 10px; padding: 10px; background: #f8f9fa; border-radius: 4px; display: none;"></div>
            </div>
        </div>
        
        <script>
            async function testRestartPlaybook() {{
                showTestResult('Testing app restart playbook...', 'info');
                try {{
                    const response = await fetch('/ai/ops/actions/run/restart_app', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ context: {{ test: true }} }})
                    }});
                    const result = await response.json();
                    showTestResult(`Restart test: ${{result.status}} (${{result.steps_completed}}/${{result.total_steps}} steps)`, 'success');
                }} catch (e) {{
                    showTestResult(`Restart test failed: ${{e.message}}`, 'error');
                }}
            }}
            
            async function testHealthCheck() {{
                showTestResult('Running system health check...', 'info');
                try {{
                    const response = await fetch('/ai/ops/actions/run/system_health_check', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ context: {{ test: true }} }})
                    }});
                    const result = await response.json();
                    showTestResult(`Health check: ${{result.status}} (${{result.steps_completed}}/${{result.total_steps}} steps)`, 'success');
                }} catch (e) {{
                    showTestResult(`Health check failed: ${{e.message}}`, 'error');
                }}
            }}
            
            async function testLogScan() {{
                showTestResult('Triggering log scan...', 'info');
                try {{
                    const response = await fetch('/ai/ops/monitor/scan-logs', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }}
                    }});
                    const result = await response.json();
                    showTestResult(`Log scan: ${{result.status}} - ${{result.message}}`, 'success');
                }} catch (e) {{
                    showTestResult(`Log scan failed: ${{e.message}}`, 'error');
                }}
            }}
            
            async function testPrediction() {{
                showTestResult('Testing risk prediction...', 'info');
                try {{
                    const response = await fetch('/ai/predict/asset/PUMP-001');
                    const result = await response.json();
                    showTestResult(`Risk prediction: ${{result.asset_id}} - Risk: ${{(result.risk_score * 100).toFixed(0)}}%, Level: ${{result.risk_level}}`, 'success');
                }} catch (e) {{
                    showTestResult(`Prediction test failed: ${{e.message}}`, 'error');
                }}
            }}
            
            function showTestResult(message, type) {{
                const div = document.getElementById('testResults');
                div.style.display = 'block';
                div.innerHTML = `<strong>${{type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️'}}</strong> ${{message}}`;
                div.style.background = type === 'error' ? '#f8d7da' : type === 'success' ? '#d4edda' : '#d1ecf1';
                div.style.color = type === 'error' ? '#721c24' : type === 'success' ? '#155724' : '#0c5460';
            }}
        </script>
    </body>
    </html>
    """

@app.get("/health")
async def health_check():
    """Basic health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "aiops_available": AIOPS_AVAILABLE,
        "predictive_available": PREDICTIVE_AVAILABLE,
        "version": "1.0.0-aiops"
    }

if __name__ == "__main__":
    import uvicorn
    logger.info("🚀 Starting ChatterFix CMMS - AIOps Demo")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")