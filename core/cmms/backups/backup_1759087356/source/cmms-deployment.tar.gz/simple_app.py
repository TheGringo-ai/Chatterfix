#!/usr/bin/env python3
"""
ChatterFix CMMS - Simple Production Deploy
"""

import os
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from ai import ai_router
from workorders import workorders_router
from rate_limiter import RateLimitingMiddleware
from prometheus_fastapi_instrumentator import Instrumentator

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="ChatterFix CMMS",
    version="3.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add rate limiting middleware
app.add_middleware(RateLimitingMiddleware)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Include working routers only
app.include_router(ai_router)

# Include CMMS UI routers
app.include_router(workorders_router)

# Include advanced AI systems
try:
    from voice_command_processor import voice_router
    from parts_intelligence import parts_router  
    from safety_compliance_system import safety_router
    from document_ocr_processor import ocr_router
    
    app.include_router(voice_router)
    app.include_router(parts_router)
    app.include_router(safety_router)
    app.include_router(ocr_router)
    
    logger.info("✅ Advanced AI systems loaded successfully")
except ImportError as e:
    logger.warning(f"⚠️ Some advanced AI systems unavailable: {e}")
except Exception as e:
    logger.error(f"❌ Failed to load advanced AI systems: {e}")

# Add Prometheus monitoring with modest histogram buckets
Instrumentator().instrument(app).expose(app)

@app.on_event("startup")
async def startup_event():
    """Initialize database and AI provider on startup"""
    # Run database migrations
    try:
        import subprocess
        import sys
        
        logger.info("Running database migrations...")
        result = subprocess.run(
            [sys.executable, "migrate.py"],
            capture_output=True,
            text=True,
            cwd=os.path.dirname(__file__)
        )
        
        if result.returncode == 0:
            logger.info("✅ Database migrations completed successfully")
        else:
            logger.error(f"❌ Database migration failed: {result.stderr}")
            raise RuntimeError(f"Migration failed: {result.stderr}")
            
    except Exception as e:
        logger.error(f"❌ Database migration error: {e}")
        # Don't fail startup for migration errors in dev
        pass
    
    # Initialize AI provider
    try:
        from ai_model_provider import initialize_ai_provider
        
        logger.info("Initializing centralized AI provider...")
        success = await initialize_ai_provider()
        
        if success:
            logger.info("✅ AI provider initialized successfully")
        else:
            logger.warning("⚠️ AI provider initialization failed - using fallback mode")
            
    except Exception as e:
        logger.error(f"❌ AI provider startup error: {e}")
        logger.info("Continuing with fallback AI responses")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on application shutdown"""
    try:
        from ai_model_provider import ai_provider
        await ai_provider.shutdown()
        logger.info("✅ Application shutdown complete")
    except Exception as e:
        logger.error(f"❌ Shutdown error: {e}")

@app.get("/", response_class=HTMLResponse)
async def landing_page():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix - AI-Powered Maintenance Solutions</title>
        <style>
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
                margin: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
            }
            .container { max-width: 900px; padding: 2rem; }
            .hero { margin-bottom: 3rem; }
            h1 { font-size: 4.5rem; margin-bottom: 1rem; text-shadow: 2px 2px 4px rgba(0,0,0,0.3); }
            .tagline { 
                font-size: 1.5rem; 
                margin-bottom: 2rem; 
                opacity: 0.9;
                font-weight: 300;
            }
            .description {
                font-size: 1.1rem;
                margin-bottom: 3rem;
                opacity: 0.8;
                max-width: 600px;
                line-height: 1.6;
            }
            .cta-section {
                margin: 3rem 0;
            }
            .cta-btn { 
                background: linear-gradient(45deg, #11998e, #38ef7d);
                color: white;
                padding: 1rem 3rem;
                border-radius: 50px;
                text-decoration: none;
                font-size: 1.2rem;
                font-weight: 600;
                display: inline-block;
                transition: all 0.3s;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                border: none;
                cursor: pointer;
            }
            .cta-btn:hover { 
                transform: translateY(-3px); 
                box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            }
            .features {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 2rem;
                margin-top: 4rem;
            }
            .feature {
                background: rgba(255,255,255,0.1);
                padding: 2rem;
                border-radius: 15px;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                text-align: center;
            }
            .feature-icon {
                font-size: 3rem;
                margin-bottom: 1rem;
                display: block;
            }
            .feature h3 {
                font-size: 1.3rem;
                margin-bottom: 1rem;
            }
            .feature p {
                opacity: 0.9;
                line-height: 1.5;
            }
            .status { 
                position: fixed; 
                top: 20px; 
                right: 20px; 
                background: #38ef7d; 
                padding: 10px 15px; 
                border-radius: 10px; 
                font-size: 0.8rem;
            }
        </style>
    </head>
    <body>
        <div class="status">🟢 System Online</div>
        
        <div class="container">
            <div class="hero">
                <h1>🔧 ChatterFix</h1>
                <div class="tagline">AI-Powered Maintenance Solutions</div>
                <div class="description">
                    Transform your maintenance operations with intelligent work order management, 
                    predictive analytics, and AI-driven insights. Built for modern enterprises 
                    who demand efficiency and reliability.
                </div>
            </div>
            
            <div class="cta-section">
                <a href="/app" class="cta-btn">
                    🚀 Launch Application
                </a>
            </div>
            
            <div class="features">
                <div class="feature">
                    <span class="feature-icon">📋</span>
                    <h3>Work Order Management</h3>
                    <p>Streamline maintenance requests with intelligent routing, priority management, and real-time tracking</p>
                </div>
                
                <div class="feature">
                    <span class="feature-icon">🤖</span>
                    <h3>AI Assistant</h3>
                    <p>Get expert guidance powered by advanced AI models including Llama for maintenance decision making</p>
                </div>
                
                <div class="feature">
                    <span class="feature-icon">📊</span>
                    <h3>Analytics & Reporting</h3>
                    <p>Comprehensive insights into maintenance performance, costs, and predictive maintenance opportunities</p>
                </div>
                
                <div class="feature">
                    <span class="feature-icon">🔧</span>
                    <h3>Asset Management</h3>
                    <p>Complete lifecycle management of your equipment and facilities with maintenance history tracking</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    """

@app.get("/app", response_class=HTMLResponse)
async def app_dashboard():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix CMMS - Application Dashboard</title>
        <style>
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
                margin: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
            }
            .container { max-width: 800px; padding: 2rem; }
            .header { margin-bottom: 2rem; }
            h1 { font-size: 3rem; margin-bottom: 1rem; }
            .version { 
                background: linear-gradient(45deg, #11998e, #38ef7d);
                padding: 10px 20px;
                border-radius: 25px;
                font-size: 1rem;
                font-weight: bold;
                display: inline-block;
                margin: 1rem 0;
            }
            .nav-grid { 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
                gap: 1.5rem; 
                margin-top: 2rem;
            }
            .nav-btn { 
                background: rgba(255,255,255,0.1); 
                border: none;
                color: white;
                padding: 1.5rem;
                border-radius: 12px;
                cursor: pointer;
                text-decoration: none;
                display: block;
                transition: all 0.3s;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }
            .nav-btn:hover { 
                transform: translateY(-5px); 
                background: rgba(255,255,255,0.2);
            }
            .nav-btn h3 { margin: 0 0 0.5rem 0; font-size: 1.2rem; }
            .nav-btn p { margin: 0; opacity: 0.9; font-size: 0.9rem; }
            .back-btn {
                position: fixed;
                top: 20px;
                left: 20px;
                background: rgba(255,255,255,0.1);
                color: white;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 25px;
                font-size: 0.9rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                transition: all 0.3s;
            }
            .back-btn:hover {
                background: rgba(255,255,255,0.2);
            }
            .status { 
                position: fixed; 
                top: 20px; 
                right: 20px; 
                background: #38ef7d; 
                padding: 10px 15px; 
                border-radius: 10px; 
                font-size: 0.8rem;
            }
        </style>
    </head>
    <body>
        <a href="/" class="back-btn">← Back to Home</a>
        <div class="status">🟢 System Online</div>
        
        <div class="container">
            <div class="header">
                <h1>🔧 ChatterFix CMMS</h1>
                <div class="version">v3.0.0 - Application Dashboard</div>
                <p>Choose a module to get started with your maintenance management</p>
            </div>
            
            <div class="nav-grid">
                <a href="/cmms/workorders/dashboard" class="nav-btn">
                    <h3>📋 Work Orders</h3>
                    <p>Manage maintenance work orders and assignments</p>
                </a>
                
                <a href="/ai/dashboard" class="nav-btn">
                    <h3>🤖 AI Assistant</h3>
                    <p>Multi-model AI chat & predictive analytics</p>
                </a>
                
                <a href="/health" class="nav-btn">
                    <h3>🏥 System Health</h3>
                    <p>API status & health monitoring</p>
                </a>
                
                <a href="/cmms/assets/dashboard" class="nav-btn">
                    <h3>🏭 Asset Management</h3>
                    <p>Equipment and facility lifecycle management</p>
                </a>
                
                <a href="/cmms/parts/dashboard" class="nav-btn">
                    <h3>🔩 Parts Inventory</h3>
                    <p>Spare parts and inventory management</p>
                </a>
                
                <a href="/admin/dashboard" class="nav-btn">
                    <h3>⚙️ Admin Panel</h3>
                    <p>User management & system configuration</p>
                </a>
            </div>
        </div>
    </body>
    </html>
    """

@app.get("/cmms/dashboard/main", response_class=HTMLResponse)
async def cmms_main_dashboard():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>CMMS Main Dashboard - ChatterFix</title>
        <style>
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
                margin: 0;
                padding: 2rem;
            }
            .container { max-width: 1400px; margin: 0 auto; }
            .header { 
                text-align: center; 
                margin-bottom: 3rem;
                background: rgba(255,255,255,0.1);
                padding: 2rem;
                border-radius: 15px;
                backdrop-filter: blur(10px);
            }
            h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
            .subtitle { opacity: 0.9; font-size: 1.1rem; }
            .dashboard-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 2rem;
                margin-bottom: 2rem;
            }
            .module-card {
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                transition: all 0.3s;
                text-decoration: none;
                color: white;
                display: block;
            }
            .module-card:hover {
                transform: translateY(-5px);
                background: rgba(255,255,255,0.15);
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            }
            .module-header {
                display: flex;
                align-items: center;
                margin-bottom: 1rem;
            }
            .module-icon {
                font-size: 2rem;
                margin-right: 1rem;
            }
            .module-title {
                font-size: 1.3rem;
                font-weight: 600;
                margin: 0;
            }
            .module-description {
                opacity: 0.9;
                line-height: 1.5;
                margin-bottom: 1rem;
            }
            .module-stats {
                display: flex;
                justify-content: space-between;
                font-size: 0.9rem;
                opacity: 0.8;
            }
            .quick-stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-bottom: 3rem;
            }
            .stat-card {
                background: rgba(255,255,255,0.1);
                padding: 1.5rem;
                border-radius: 12px;
                text-align: center;
                backdrop-filter: blur(10px);
            }
            .stat-number {
                font-size: 2rem;
                font-weight: bold;
                color: #38ef7d;
            }
            .stat-label {
                opacity: 0.9;
                font-size: 0.9rem;
            }
            .breadcrumb {
                background: rgba(0,0,0,0.2);
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 2rem;
                font-size: 0.9rem;
            }
            .breadcrumb a {
                color: #38ef7d;
                text-decoration: none;
            }
            .breadcrumb a:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="breadcrumb">
                <a href="/">Home</a> > <a href="/app">App</a> > CMMS Dashboard
            </div>
            
            <div class="header">
                <h1>🔧 CMMS Main Dashboard</h1>
                <div class="subtitle">Comprehensive Maintenance Management System</div>
            </div>
            
            <div class="quick-stats">
                <div class="stat-card">
                    <div class="stat-number">5</div>
                    <div class="stat-label">Active Work Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">12</div>
                    <div class="stat-label">Assets Monitored</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">98%</div>
                    <div class="stat-label">System Uptime</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">2.1h</div>
                    <div class="stat-label">Avg Response Time</div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <a href="/cmms/workorders/dashboard" class="module-card">
                    <div class="module-header">
                        <span class="module-icon">📋</span>
                        <h3 class="module-title">Work Orders</h3>
                    </div>
                    <div class="module-description">
                        Manage maintenance work orders, assignments, and track progress across all assets
                    </div>
                    <div class="module-stats">
                        <span>5 Active</span>
                        <span>94% Completion Rate</span>
                    </div>
                </a>
                
                <a href="/cmms/assets/dashboard" class="module-card">
                    <div class="module-header">
                        <span class="module-icon">🏭</span>
                        <h3 class="module-title">Asset Management</h3>
                    </div>
                    <div class="module-description">
                        Equipment lifecycle management, maintenance schedules, and asset tracking
                    </div>
                    <div class="module-stats">
                        <span>12 Assets</span>
                        <span>8 Operational</span>
                    </div>
                </a>
                
                <a href="/cmms/parts/dashboard" class="module-card">
                    <div class="module-header">
                        <span class="module-icon">🔩</span>
                        <h3 class="module-title">Parts Inventory</h3>
                    </div>
                    <div class="module-description">
                        Spare parts management, inventory tracking, and procurement workflows
                    </div>
                    <div class="module-stats">
                        <span>156 Parts</span>
                        <span>12 Low Stock</span>
                    </div>
                </a>
                
                <a href="/cmms/preventive/dashboard" class="module-card">
                    <div class="module-header">
                        <span class="module-icon">🔄</span>
                        <h3 class="module-title">Preventive Maintenance</h3>
                    </div>
                    <div class="module-description">
                        Scheduled maintenance programs, recurring tasks, and compliance tracking
                    </div>
                    <div class="module-stats">
                        <span>8 Schedules</span>
                        <span>3 Due Soon</span>
                    </div>
                </a>
                
                <a href="/ai/dashboard" class="module-card">
                    <div class="module-header">
                        <span class="module-icon">🤖</span>
                        <h3 class="module-title">AI Assistant</h3>
                    </div>
                    <div class="module-description">
                        Intelligent maintenance guidance, predictive analytics, and automated insights
                    </div>
                    <div class="module-stats">
                        <span>Llama Ready</span>
                        <span>24/7 Available</span>
                    </div>
                </a>
                
                <a href="/admin/dashboard" class="module-card">
                    <div class="module-header">
                        <span class="module-icon">⚙️</span>
                        <h3 class="module-title">System Admin</h3>
                    </div>
                    <div class="module-description">
                        User management, system configuration, and administrative controls
                    </div>
                    <div class="module-stats">
                        <span>3 Users</span>
                        <span>All Systems OK</span>
                    </div>
                </a>
            </div>
        </div>
    </body>
    </html>
    """

@app.get("/admin/dashboard", response_class=HTMLResponse)
async def admin_dashboard():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - AI-Powered Admin Dashboard</title>
        <link rel="stylesheet" href="/static/css/cmms-professional.css">
        <link rel="stylesheet" href="/static/css/enhanced-ui.css">
        <style>
            .admin-header {
                background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
                padding: 2rem;
                margin-bottom: 2rem;
                border-radius: 16px;
                position: relative;
                overflow: hidden;
            }
            .ai-badge {
                position: absolute;
                top: 1rem;
                right: 1rem;
                background: rgba(56, 239, 125, 0.2);
                color: #38ef7d;
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 0.8rem;
                font-weight: 600;
                border: 1px solid rgba(56, 239, 125, 0.3);
            }
            .ai-feature-card {
                background: linear-gradient(135deg, rgba(56, 239, 125, 0.1), rgba(59, 130, 246, 0.1));
                border: 1px solid rgba(56, 239, 125, 0.2);
            }
            .voice-demo {
                display: flex;
                align-items: center;
                gap: 12px;
                margin: 16px 0;
            }
            .voice-btn {
                background: #ff4757;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 50%;
                cursor: pointer;
                font-size: 18px;
                transition: all 0.3s;
            }
            .voice-btn:hover {
                background: #ff3742;
                transform: scale(1.1);
            }
        </style>
    </head>
    <body>
        <div class="dashboard-container">
            <div class="admin-header">
                <div class="ai-badge">🤖 AI-POWERED</div>
                <h1 class="page-title">
                    <span class="page-icon">⚡</span>
                    ChatterFix CMMS Pro
                </h1>
                <p style="opacity: 0.9; margin: 1rem 0 0 0;">Next-generation AI-powered maintenance management system</p>
            </div>
            
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="kpi-value">🎯 98%</div>
                    <div class="kpi-label">AI Accuracy</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">⚡ 24</div>
                    <div class="kpi-label">Smart Work Orders</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">🔍 47</div>
                    <div class="kpi-label">AI-Monitored Assets</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">🗣️ 156</div>
                    <div class="kpi-label">Voice Commands</div>
                </div>
            </div>
            
            <!-- AI Features Section -->
            <div style="margin: 32px 0;">
                <h2 style="color: var(--primary-700); margin-bottom: 24px;">🚀 AI-Powered Features</h2>
                <div class="section-grid" style="grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 24px;">
                    
                    <div class="section-card ai-feature-card">
                        <h3>🎙️ Voice Commands</h3>
                        <p>Create work orders, diagnose issues, and control CMMS using natural language voice commands</p>
                        <div class="voice-demo">
                            <button class="voice-btn" onclick="testVoice()">🎤</button>
                            <span style="font-size: 0.9rem; opacity: 0.8;">Try: "Create work order for conveyor belt 1"</span>
                        </div>
                        <a href="/voice/demo" class="btn-primary" style="margin-top: 16px;">Voice Demo</a>
                    </div>
                    
                    <div class="section-card ai-feature-card">
                        <h3>🔍 Intelligent Parts Lookup</h3>
                        <p>AI-powered parts search with predictive inventory management and compatibility matching</p>
                        <div style="margin: 12px 0; font-size: 0.9rem; opacity: 0.8;">
                            💡 "Find seal for pump 3" → Instant results with alternatives
                        </div>
                        <a href="/parts/search" class="btn-primary" style="margin-top: 16px;">Smart Parts Search</a>
                    </div>
                    
                    <div class="section-card ai-feature-card">
                        <h3>🛡️ Safety AI Assistant</h3>
                        <p>Real-time safety guidance, compliance checking, and automatic hazard identification</p>
                        <div style="margin: 12px 0; font-size: 0.9rem; opacity: 0.8;">
                            🚨 Automatic PPE recommendations • OSHA compliance • Risk assessment
                        </div>
                        <a href="/safety/assess" class="btn-primary" style="margin-top: 16px;">Safety Assessment</a>
                    </div>
                    
                    <div class="section-card ai-feature-card">
                        <h3>📄 Document OCR</h3>
                        <p>Extract equipment data from nameplates, manuals, and schematics using advanced AI</p>
                        <div style="margin: 12px 0; font-size: 0.9rem; opacity: 0.8;">
                            📷 Photo → Instant equipment specs • Auto-populate asset database
                        </div>
                        <a href="/documents/upload" class="btn-primary" style="margin-top: 16px;">Process Documents</a>
                    </div>
                    
                    <div class="section-card ai-feature-card">
                        <h3>🔧 AI Diagnostics</h3>
                        <p>Expert-level troubleshooting assistance with predictive failure analysis</p>
                        <div style="margin: 12px 0; font-size: 0.9rem; opacity: 0.8;">
                            🎯 Root cause analysis • Repair recommendations • Parts prediction
                        </div>
                        <a href="/ai/diagnose" class="btn-primary" style="margin-top: 16px;">AI Diagnostics</a>
                    </div>
                    
                    <div class="section-card ai-feature-card">
                        <h3>📊 Predictive Analytics</h3>
                        <p>Machine learning insights for maintenance optimization and cost reduction</p>
                        <div style="margin: 12px 0; font-size: 0.9rem; opacity: 0.8;">
                            📈 Failure prediction • Maintenance scheduling • Cost optimization
                        </div>
                        <a href="/analytics/predictive" class="btn-primary" style="margin-top: 16px;">View Analytics</a>
                    </div>
                    
                </div>
            </div>
            
            <!-- Traditional Management -->
            <div style="margin: 32px 0;">
                <h2 style="color: var(--neutral-700); margin-bottom: 24px;">⚙️ System Management</h2>
                <div class="section-grid" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px;">
                    <div class="section-card">
                        <h3>👥 User Management</h3>
                        <p>Add, edit, and manage user accounts and permissions</p>
                        <button class="btn-secondary" style="margin-top: 16px;">Manage Users</button>
                    </div>
                    
                    <div class="section-card">
                        <h3>📊 Analytics & Reports</h3>
                        <p>View detailed analytics and generate system reports</p>
                        <button class="btn-secondary" style="margin-top: 16px;">View Reports</button>
                    </div>
                    
                    <div class="section-card">
                        <h3>🔐 Security & Audit</h3>
                        <p>Security settings, audit logs, and compliance management</p>
                        <button class="btn-secondary" style="margin-top: 16px;">Security Center</button>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div style="margin-top: 32px; padding: 24px; background: var(--surface-elevated); border-radius: 16px;">
                <h3 style="margin: 0 0 20px 0;">⚡ Quick AI Actions</h3>
                <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
                    <button class="btn-primary" onclick="quickCreateWO()">🎤 Voice Work Order</button>
                    <button class="btn-primary" onclick="quickPartSearch()">🔍 Smart Part Search</button>
                    <button class="btn-primary" onclick="quickSafety()">🛡️ Safety Check</button>
                    <button class="btn-outline" onclick="quickDiagnose()">🔧 AI Diagnose</button>
                    <span style="opacity: 0.7; margin-left: auto;">💡 Powered by LLaMA + Claude AI</span>
                </div>
            </div>
            
            <!-- Navigation -->
            <div style="margin-top: 32px; padding: 20px; background: var(--surface); border-radius: 16px;">
                <h3 style="margin: 0 0 16px 0;">🏠 Navigation</h3>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <a href="/app" class="btn-outline">← Back to App</a>
                    <a href="/cmms/dashboard/main" class="btn-outline">CMMS Dashboard</a>
                    <a href="/ai/dashboard" class="btn-outline">AI Chat</a>
                    <a href="/docs" class="btn-outline">API Docs</a>
                </div>
            </div>
        </div>
        
        <script>
            function testVoice() {
                alert('🎙️ Voice commands ready! Say: "Create work order for pump maintenance"');
                // In production, this would trigger actual voice recognition
            }
            
            function quickCreateWO() {
                alert('🎤 Voice work order creation activated!');
                // Would open voice interface
            }
            
            function quickPartSearch() {
                const query = prompt('🔍 Enter part description or number:');
                if (query) {
                    window.open(`/parts/search?query=${encodeURIComponent(query)}`, '_blank');
                }
            }
            
            function quickSafety() {
                const work = prompt('🛡️ Describe your work task:');
                if (work) {
                    window.open(`/safety/assess?work=${encodeURIComponent(work)}`, '_blank');
                }
            }
            
            function quickDiagnose() {
                const issue = prompt('🔧 Describe the equipment issue:');
                if (issue) {
                    window.open(`/ai/diagnose?issue=${encodeURIComponent(issue)}`, '_blank');
                }
            }
            
            // Add some visual flair
            document.addEventListener('DOMContentLoaded', function() {
                const badge = document.querySelector('.ai-badge');
                setInterval(() => {
                    badge.style.boxShadow = badge.style.boxShadow ? '' : '0 0 20px rgba(56, 239, 125, 0.4)';
                }, 2000);
            });
        </script>
    </body>
    </html>
    """

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "ChatterFix CMMS v3.0.0",
        "modules": {
            "ai": "operational",
            "workorders": "operational"
        },
        "ollama": "connected",
        "timestamp": "2025-09-09T20:15:00Z"
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 3000))
    uvicorn.run("simple_app:app", host="0.0.0.0", port=port, reload=False)