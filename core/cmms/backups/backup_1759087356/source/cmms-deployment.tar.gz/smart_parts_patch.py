#!/usr/bin/env python3
"""
Smart Parts Suggestions Feature
AI-powered parts recommendations based on work order descriptions
"""

# Smart parts suggestions function to add to parts module
SMART_PARTS_FUNCTION = '''

@parts_router.post("/suggest")
async def suggest_parts(request: Dict[str, str]) -> Dict:
    """AI-powered parts suggestions based on work description"""
    try:
        description = request.get("description", "")
        equipment_type = request.get("equipment_type", "")
        issue_type = request.get("issue_type", "")
        
        if not description.strip():
            raise HTTPException(status_code=400, detail="Description is required")
        
        # Use AI to analyze and suggest parts
        ai_prompt = f"""
Analyze this maintenance work and suggest required parts with quantities:

Work Description: "{description}"
Equipment Type: {equipment_type}
Issue Type: {issue_type}

Available parts in inventory:
- Air Filter (AF-001): Filters, $12.50 each, 15 in stock
- Compressor Oil (CO-002): Lubricants, $45.00 each, 8 in stock  
- Drive Belt (DB-003): Belts, $23.75 each, 12 in stock
- Bearing Set (BS-004): Bearings, $67.50 each, 6 in stock
- Gasket Kit (GK-005): Seals, $15.25 each, 20 in stock
- Motor Mount (MM-006): Mounts, $89.00 each, 4 in stock
- Coupling (CP-007): Couplings, $156.00 each, 3 in stock
- V-Belt (VB-008): Belts, $28.50 each, 8 in stock
- Oil Seal (OS-009): Seals, $22.75 each, 15 in stock
- Grease (GR-010): Lubricants, $18.90 each, 25 in stock

Respond with JSON array of suggested parts:
[{{"part_name": "Part Name", "part_number": "XX-000", "quantity": 1, "reason": "why needed"}}]

Only suggest parts that make sense for this specific work. JSON only:"""

        # Get AI suggestions
        from ai import query_llama
        ai_response = await query_llama(ai_prompt, "parts_suggestion", "parts_specialist")
        
        # Parse AI response
        import json
        import re
        
        suggested_parts = []
        
        # Try to extract JSON from AI response
        json_match = re.search(r'\\[.*\\]', ai_response, re.DOTALL)
        if json_match:
            try:
                suggested_parts = json.loads(json_match.group())
            except json.JSONDecodeError:
                suggested_parts = parse_parts_fallback(description, equipment_type, issue_type)
        else:
            suggested_parts = parse_parts_fallback(description, equipment_type, issue_type)
        
        # Validate and enrich suggestions with inventory data
        from part import parts_db
        enriched_suggestions = []
        
        for suggestion in suggested_parts:
            part_name = suggestion.get("part_name", "")
            part_number = suggestion.get("part_number", "")
            quantity = int(suggestion.get("quantity", 1))
            reason = suggestion.get("reason", "Required for maintenance")
            
            # Find matching part in inventory
            inventory_part = None
            for part in parts_db:
                if (part.get("part_number") == part_number or 
                    part_name.lower() in part.get("name", "").lower()):
                    inventory_part = part
                    break
            
            if inventory_part:
                available_qty = inventory_part.get("quantity", 0)
                unit_cost = inventory_part.get("unit_cost", 0.0)
                total_cost = unit_cost * quantity
                
                enriched_suggestions.append({
                    "part_name": inventory_part.get("name"),
                    "part_number": inventory_part.get("part_number"),
                    "category": inventory_part.get("category"),
                    "quantity_needed": quantity,
                    "quantity_available": available_qty,
                    "in_stock": available_qty >= quantity,
                    "unit_cost": unit_cost,
                    "total_cost": round(total_cost, 2),
                    "supplier": inventory_part.get("supplier"),
                    "reason": reason,
                    "ai_suggested": True
                })
        
        # Calculate totals
        total_cost = sum(part["total_cost"] for part in enriched_suggestions)
        parts_in_stock = len([p for p in enriched_suggestions if p["in_stock"]])
        parts_needed = len([p for p in enriched_suggestions if not p["in_stock"]])
        
        logger.info(f"Parts suggestions generated for: {description[:50]}... ({len(enriched_suggestions)} parts)")
        
        return {
            "description": description,
            "equipment_type": equipment_type,
            "issue_type": issue_type,
            "suggested_parts": enriched_suggestions,
            "summary": {
                "total_parts": len(enriched_suggestions),
                "total_cost": round(total_cost, 2),
                "parts_in_stock": parts_in_stock,
                "parts_needed": parts_needed,
                "procurement_required": parts_needed > 0
            },
            "ai_analysis": True,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Parts suggestion failed: {e}")
        raise HTTPException(status_code=500, detail=f"Parts suggestion failed: {str(e)}")

def parse_parts_fallback(description: str, equipment_type: str, issue_type: str) -> List[Dict]:
    """Fallback parts suggestions if AI parsing fails"""
    description_lower = description.lower()
    suggestions = []
    
    # Basic pattern matching for common repairs
    if any(word in description_lower for word in ["belt", "drive", "pulley"]):
        suggestions.append({
            "part_name": "Drive Belt", 
            "part_number": "DB-003", 
            "quantity": 1,
            "reason": "Belt replacement or adjustment"
        })
    
    if any(word in description_lower for word in ["oil", "lubricate", "grease"]):
        suggestions.append({
            "part_name": "Compressor Oil", 
            "part_number": "CO-002", 
            "quantity": 1,
            "reason": "Lubrication maintenance"
        })
    
    if any(word in description_lower for word in ["filter", "air", "dirty"]):
        suggestions.append({
            "part_name": "Air Filter", 
            "part_number": "AF-001", 
            "quantity": 1,
            "reason": "Filter replacement"
        })
    
    if any(word in description_lower for word in ["bearing", "noise", "vibrat"]):
        suggestions.append({
            "part_name": "Bearing Set", 
            "part_number": "BS-004", 
            "quantity": 1,
            "reason": "Bearing replacement for noise/vibration"
        })
    
    if any(word in description_lower for word in ["leak", "seal", "gasket"]):
        suggestions.append({
            "part_name": "Gasket Kit", 
            "part_number": "GK-005", 
            "quantity": 1,
            "reason": "Seal leak repair"
        })
    
    # Default suggestion if nothing matches
    if not suggestions:
        suggestions.append({
            "part_name": "Grease", 
            "part_number": "GR-010", 
            "quantity": 1,
            "reason": "General maintenance lubrication"
        })
    
    return suggestions

@parts_router.get("/suggest-demo")
async def parts_suggestion_demo():
    """Demo page for parts suggestions"""
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Parts Suggestions Demo</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; }
        .demo-card { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .suggest-btn { background: #3498db; color: white; border: none; padding: 12px 24px; 
                      border-radius: 6px; cursor: pointer; font-size: 16px; }
        .suggest-btn:hover { background: #2980b9; }
        textarea { width: 100%; height: 80px; margin: 10px 0; padding: 10px; border-radius: 4px; border: 1px solid #ddd; }
        input { padding: 8px; margin: 5px; border-radius: 4px; border: 1px solid #ddd; }
        .parts-list { margin-top: 20px; }
        .part-item { background: white; padding: 15px; margin: 10px 0; border-radius: 6px; border-left: 4px solid #3498db; }
        .part-item.out-of-stock { border-left-color: #e74c3c; }
        .cost { color: #27ae60; font-weight: bold; }
        .out-of-stock-badge { background: #e74c3c; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
        .in-stock-badge { background: #27ae60; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
    </style>
</head>
<body>
    <h1>🔧 Smart Parts Suggestions</h1>
    
    <div class="demo-card">
        <h3>Describe your maintenance work:</h3>
        <textarea id="description" placeholder="e.g., HVAC unit making noise, belt seems loose, needs oil change..."></textarea>
        <br>
        <input type="text" id="equipment" placeholder="Equipment Type (e.g., HVAC, Pump, Motor)" style="width: 200px;">
        <input type="text" id="issue" placeholder="Issue Type (e.g., noise, leak, wear)" style="width: 200px;">
        <br><br>
        <button class="suggest-btn" onclick="getSuggestions()">Get AI Parts Suggestions</button>
    </div>
    
    <div id="results"></div>
    
    <div class="demo-card">
        <h3>Try these examples:</h3>
        <button onclick="fillExample('Conveyor belt is slipping and making noise, needs replacement')" style="margin: 5px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; background: white; cursor: pointer;">Belt Issue</button>
        <button onclick="fillExample('Pump is leaking oil from gasket, need to seal repair')" style="margin: 5px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; background: white; cursor: pointer;">Leak Repair</button>
        <button onclick="fillExample('Motor bearings making grinding noise, vibration detected')" style="margin: 5px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; background: white; cursor: pointer;">Bearing Issue</button>
    </div>
    
    <script>
        function fillExample(text) {
            document.getElementById('description').value = text;
        }
        
        async function getSuggestions() {
            const description = document.getElementById('description').value;
            const equipment = document.getElementById('equipment').value;
            const issue = document.getElementById('issue').value;
            const results = document.getElementById('results');
            
            if (!description.trim()) {
                alert('Please enter a work description');
                return;
            }
            
            results.innerHTML = '<div class="demo-card">🔄 Analyzing work description and suggesting parts...</div>';
            
            try {
                const response = await fetch('/cmms/parts/suggest', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        description: description,
                        equipment_type: equipment,
                        issue_type: issue
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    displayResults(data);
                } else {
                    results.innerHTML = `<div class="demo-card" style="color: red;">Error: ${data.detail}</div>`;
                }
                
            } catch (error) {
                results.innerHTML = `<div class="demo-card" style="color: red;">Error: ${error.message}</div>`;
            }
        }
        
        function displayResults(data) {
            const parts = data.suggested_parts || [];
            const summary = data.summary || {};
            
            let html = `
                <div class="demo-card">
                    <h3>📋 Parts Suggestions</h3>
                    <p><strong>Work:</strong> ${data.description}</p>
                    <p><strong>Summary:</strong> ${summary.total_parts} parts suggested, $${summary.total_cost} total cost</p>
                    <p><strong>Stock Status:</strong> ${summary.parts_in_stock} in stock, ${summary.parts_needed} need ordering</p>
                </div>
                
                <div class="parts-list">
            `;
            
            parts.forEach(part => {
                const stockBadge = part.in_stock ? 
                    `<span class="in-stock-badge">✓ In Stock</span>` : 
                    `<span class="out-of-stock-badge">⚠ Order Needed</span>`;
                
                html += `
                    <div class="part-item ${part.in_stock ? '' : 'out-of-stock'}">
                        <div style="display: flex; justify-content: between; align-items: center;">
                            <div style="flex: 1;">
                                <strong>${part.part_name}</strong> (${part.part_number})
                                <br><small>${part.category} • ${part.supplier}</small>
                                <br><em>${part.reason}</em>
                            </div>
                            <div style="text-align: right;">
                                ${stockBadge}
                                <br>Qty: ${part.quantity_needed} (${part.quantity_available} available)
                                <br><span class="cost">$${part.total_cost}</span>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            html += '</div>';
            document.getElementById('results').innerHTML = html;
        }
    </script>
</body>
</html>""")
'''

def apply_patch():
    """Apply smart parts suggestions patch to parts module"""
    print("🔧 Adding Smart Parts Suggestions feature...")
    
    # Check if parts.py exists, if not create a basic one
    import os
    if not os.path.exists('/opt/chatterfix/part.py'):
        print("❌ part.py not found")
        return False
    
    # Read current part.py (note: it's part.py not parts.py based on earlier imports)
    with open('/opt/chatterfix/part.py', 'r') as f:
        content = f.read()
    
    # Check if our specific endpoint already exists
    if '@parts_router.post("/suggest")' in content:
        print("✅ Smart parts feature already exists")
        return True
    
    # Find insertion point
    import re
    router_matches = list(re.finditer(r'@.*_router\\.', content))
    
    if router_matches:
        last_router_pos = router_matches[-1].start()
        insertion_point = content.rfind('\\n', 0, last_router_pos)
        if insertion_point == -1:
            insertion_point = last_router_pos
    else:
        main_pos = content.find('if __name__ == "__main__"')
        if main_pos != -1:
            insertion_point = content.rfind('\\n', 0, main_pos)
        else:
            insertion_point = len(content)
    
    # Insert the smart parts functions
    new_content = (content[:insertion_point] + 
                   SMART_PARTS_FUNCTION + 
                   content[insertion_point:])
    
    # Write updated content
    with open('/opt/chatterfix/part.py', 'w') as f:
        f.write(new_content)
    
    print("✅ Smart Parts Suggestions feature added to part.py")
    return True

if __name__ == "__main__":
    apply_patch()