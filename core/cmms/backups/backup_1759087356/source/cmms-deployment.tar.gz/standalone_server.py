#!/usr/bin/env python3
"""
ChatterFix CMMS - Standalone Server
Simple HTTP server that works without dependencies
"""

import os
import sys
import json
import sqlite3
import logging
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CMSSRequestHandler(BaseHTTPRequestHandler):
    """Simple HTTP request handler for CMMS"""
    
    def do_GET(self):
        """Handle GET requests"""
        path = urlparse(self.path).path
        query = parse_qs(urlparse(self.path).query)
        
        if path == '/' or path == '/dashboard':
            self.serve_dashboard()
        elif path == '/health':
            self.serve_health()
        elif path == '/assets':
            self.serve_assets()
        elif path == '/api/assets':
            self.serve_api_assets()
        elif path == '/api/workorders':
            self.serve_api_workorders()
        else:
            self.serve_404()
    
    def do_POST(self):
        """Handle POST requests"""
        path = urlparse(self.path).path
        
        if path == '/api/workorders':
            self.create_workorder()
        else:
            self.serve_404()
    
    def serve_dashboard(self):
        """Serve main dashboard"""
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        
        # Get system status
        stats = self.get_system_stats()
        
        html = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>ChatterFix CMMS v3.1.0 - Standalone</title>
            <style>
                * {{ margin: 0; padding: 0; box-sizing: border-box; }}
                body {{ 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    color: white;
                }}
                .header {{ 
                    background: rgba(0,0,0,0.2); 
                    backdrop-filter: blur(10px);
                    padding: 2rem;
                    text-align: center;
                    border-bottom: 1px solid rgba(255,255,255,0.1);
                }}
                .container {{ max-width: 1200px; margin: 0 auto; padding: 2rem; }}
                .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }}
                .card {{ 
                    background: rgba(255,255,255,0.1); 
                    backdrop-filter: blur(10px);
                    padding: 2rem; 
                    border-radius: 15px; 
                    border: 1px solid rgba(255,255,255,0.2);
                    transition: transform 0.3s ease;
                }}
                .card:hover {{ transform: translateY(-5px); }}
                .status {{ 
                    display: inline-block; 
                    padding: 4px 12px; 
                    border-radius: 20px; 
                    font-size: 0.9rem; 
                    font-weight: 600;
                    background: #28a745;
                    color: white;
                }}
                .btn {{ 
                    display: inline-block;
                    padding: 12px 24px;
                    background: rgba(255,255,255,0.2);
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    margin: 4px;
                    border: 1px solid rgba(255,255,255,0.3);
                    transition: all 0.3s ease;
                }}
                .btn:hover {{
                    background: rgba(255,255,255,0.3);
                    transform: translateY(-2px);
                }}
                .stats {{ display: flex; gap: 1rem; margin: 1rem 0; }}
                .stat {{ background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 8px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🤖 ChatterFix CMMS v3.1.0</h1>
                <p>Standalone Server - No External Dependencies</p>
                <div style="margin-top: 1rem;">
                    <span class="status">✅ Operational</span>
                    <span class="status">🗄️ Database: {stats['database_status']}</span>
                </div>
            </div>
            
            <div class="container">
                <div class="grid">
                    <div class="card">
                        <h3>📊 System Overview</h3>
                        <div class="stats">
                            <div class="stat">Assets: {stats['total_assets']}</div>
                            <div class="stat">Work Orders: {stats['total_workorders']}</div>
                            <div class="stat">Users: {stats['total_users']}</div>
                        </div>
                        <div>
                            <a href="/assets" class="btn">View Assets</a>
                            <a href="/health" class="btn">Health Check</a>
                        </div>
                    </div>
                    
                    <div class="card">
                        <h3>🏭 Assets Management</h3>
                        <p>Equipment tracking and maintenance scheduling</p>
                        <div class="stats">
                            <div class="stat">Operational: {stats['operational_assets']}</div>
                            <div class="stat">Maintenance Due: {stats['maintenance_due']}</div>
                        </div>
                        <div>
                            <a href="/assets" class="btn">Manage Assets</a>
                            <a href="/api/assets" class="btn">API Data</a>
                        </div>
                    </div>
                    
                    <div class="card">
                        <h3>📋 Work Orders</h3>
                        <p>Work order management and tracking</p>
                        <div class="stats">
                            <div class="stat">Open: {stats['open_workorders']}</div>
                            <div class="stat">In Progress: {stats['in_progress_workorders']}</div>
                        </div>
                        <div>
                            <a href="/api/workorders" class="btn">View Work Orders</a>
                        </div>
                    </div>
                    
                    <div class="card">
                        <h3>🗄️ Database</h3>
                        <p>SQLite database with sample data</p>
                        <div class="stats">
                            <div class="stat">Status: {stats['database_status']}</div>
                            <div class="stat">Size: {stats['database_size']}</div>
                        </div>
                        <div>
                            <a href="/health" class="btn">Database Health</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.7);">
                <p>ChatterFix CMMS v3.1.0 - Standalone Server</p>
                <p>No external dependencies required | Pure Python implementation</p>
            </div>
        </body>
        </html>
        """
        
        self.wfile.write(html.encode())
    
    def serve_health(self):
        """Serve health check"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        
        stats = self.get_system_stats()
        health = {{
            "status": "healthy",
            "version": "3.1.0-standalone",
            "timestamp": datetime.now().isoformat(),
            "database": stats['database_status'],
            "server": "standalone-python",
            "dependencies": "none"
        }}
        
        self.wfile.write(json.dumps(health, indent=2).encode())
    
    def serve_assets(self):
        """Serve assets page"""
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        
        assets = self.get_assets_data()
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Assets - ChatterFix CMMS</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 2rem; background: #f5f5f5; }}
                .header {{ background: #4a90e2; color: white; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; }}
                .assets-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }}
                .asset-card {{ background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                .status {{ padding: 4px 12px; border-radius: 12px; font-size: 0.8rem; font-weight: bold; }}
                .operational {{ background: #d4edda; color: #155724; }}
                .maintenance_due {{ background: #fff3cd; color: #856404; }}
                .btn {{ display: inline-block; padding: 8px 16px; background: #4a90e2; color: white; text-decoration: none; border-radius: 4px; margin-top: 1rem; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🏭 Assets Management</h1>
                <p>Equipment tracking and maintenance scheduling</p>
                <a href="/" class="btn">← Back to Dashboard</a>
            </div>
            
            <div class="assets-grid">
        """
        
        for asset in assets:
            html += f"""
                <div class="asset-card">
                    <h3>{asset['name']}</h3>
                    <p><strong>Category:</strong> {asset['category']}</p>
                    <p><strong>Location:</strong> {asset['location']}</p>
                    <p><strong>Status:</strong> <span class="status {asset['status']}">{asset['status'].replace('_', ' ').title()}</span></p>
                    <p><strong>Health Score:</strong> {asset['health_score']}/10</p>
                    <p><strong>Criticality:</strong> {asset['criticality'].title()}</p>
                </div>
            """
        
        html += """
            </div>
        </body>
        </html>
        """
        
        self.wfile.write(html.encode())
    
    def serve_api_assets(self):
        """Serve assets API"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        
        assets = self.get_assets_data()
        self.wfile.write(json.dumps(assets, indent=2).encode())
    
    def serve_api_workorders(self):
        """Serve work orders API"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        
        workorders = self.get_workorders_data()
        self.wfile.write(json.dumps(workorders, indent=2).encode())
    
    def serve_404(self):
        """Serve 404 page"""
        self.send_response(404)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        
        html = """
        <!DOCTYPE html>
        <html>
        <head><title>404 - Not Found</title></head>
        <body>
            <h1>404 - Page Not Found</h1>
            <p><a href="/">Back to Dashboard</a></p>
        </body>
        </html>
        """
        
        self.wfile.write(html.encode())
    
    def get_system_stats(self):
        """Get system statistics"""
        try:
            conn = sqlite3.connect('cmms.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM assets")
            total_assets = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM assets WHERE status = 'operational'")
            operational_assets = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM assets WHERE status = 'maintenance_due'")
            maintenance_due = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM workorders")
            total_workorders = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM workorders WHERE status = 'open'")
            open_workorders = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM workorders WHERE status = 'in_progress'")
            in_progress_workorders = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM users")
            total_users = cursor.fetchone()[0]
            
            conn.close()
            
            # Get database file size
            db_size = "N/A"
            try:
                size = os.path.getsize('cmms.db')
                db_size = f"{size // 1024} KB"
            except:
                pass
            
            return {
                'total_assets': total_assets,
                'operational_assets': operational_assets,
                'maintenance_due': maintenance_due,
                'total_workorders': total_workorders,
                'open_workorders': open_workorders,
                'in_progress_workorders': in_progress_workorders,
                'total_users': total_users,
                'database_status': 'Connected',
                'database_size': db_size
            }
        except Exception as e:
            logger.error(f"Database error: {e}")
            return {
                'total_assets': 0,
                'operational_assets': 0,
                'maintenance_due': 0,
                'total_workorders': 0,
                'open_workorders': 0,
                'in_progress_workorders': 0,
                'total_users': 0,
                'database_status': 'Error',
                'database_size': 'N/A'
            }
    
    def get_assets_data(self):
        """Get assets data"""
        try:
            conn = sqlite3.connect('cmms.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM assets ORDER BY name")
            rows = cursor.fetchall()
            columns = [description[0] for description in cursor.description]
            
            assets = []
            for row in rows:
                asset = dict(zip(columns, row))
                assets.append(asset)
            
            conn.close()
            return assets
        except Exception as e:
            logger.error(f"Error getting assets: {e}")
            return []
    
    def get_workorders_data(self):
        """Get work orders data"""
        try:
            conn = sqlite3.connect('cmms.db')
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT w.*, a.name as asset_name, u.username as assigned_username
                FROM workorders w
                LEFT JOIN assets a ON w.asset_id = a.id
                LEFT JOIN users u ON w.assigned_to = u.id
                ORDER BY w.created_at DESC
            """)
            rows = cursor.fetchall()
            columns = [description[0] for description in cursor.description]
            
            workorders = []
            for row in rows:
                workorder = dict(zip(columns, row))
                workorders.append(workorder)
            
            conn.close()
            return workorders
        except Exception as e:
            logger.error(f"Error getting work orders: {e}")
            return []

def run_server(port=8000):
    """Run the standalone server"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, CMSSRequestHandler)
    
    logger.info(f"🚀 ChatterFix CMMS Standalone Server starting on port {port}")
    logger.info(f"📍 Access the application at: http://localhost:{port}")
    logger.info(f"💾 Health Check at: http://localhost:{port}/health")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("🛑 Server stopped")
        httpd.server_close()

if __name__ == "__main__":
    # Check if database exists
    if not os.path.exists('cmms.db'):
        print("⚠️  Database not found. Run 'python3 init_db.py' first.")
        sys.exit(1)
    
    run_server()