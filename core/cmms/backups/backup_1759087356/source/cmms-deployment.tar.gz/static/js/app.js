/**
 * ChatterFix CMMS - Enhanced Frontend Application
 * Modern JavaScript framework with reactive state management
 */

class CMmsApp {
    constructor() {
        this.state = {
            user: null,
            workOrders: [],
            assets: [],
            notifications: [],
            isOffline: !navigator.onLine,
            currentView: 'dashboard',
            loading: false,
            theme: localStorage.getItem('cmms-theme') || 'light'
        };
        
        this.components = new Map();
        this.eventBus = new EventTarget();
        this.router = new Router(this);
        this.voiceController = null;
        this.serviceWorker = null;
        
        this.init();
    }
    
    async init() {
        console.log('🚀 Initializing ChatterFix CMMS Frontend...');
        
        // Initialize core systems
        await this.initServiceWorker();
        await this.initVoiceController();
        this.initEventListeners();
        this.initComponents();
        
        // Set initial theme
        document.documentElement.setAttribute('data-theme', this.state.theme);
        
        // Start app
        await this.loadInitialData();
        this.router.start();
        
        console.log('✅ ChatterFix CMMS Frontend Ready');
    }
    
    async initServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                this.serviceWorker = await navigator.serviceWorker.register('/static/js/sw.js');
                console.log('✅ Service Worker registered');
            } catch (error) {
                console.warn('⚠️ Service Worker registration failed:', error);
            }
        }
    }
    
    async initVoiceController() {
        if (window.VoiceController) {
            this.voiceController = new VoiceController();
            console.log('✅ Voice Controller initialized');
        }
    }
    
    initEventListeners() {
        // Online/offline status
        window.addEventListener('online', () => this.updateState({ isOffline: false }));
        window.addEventListener('offline', () => this.updateState({ isOffline: true }));
        
        // Theme toggle
        this.eventBus.addEventListener('theme-change', (e) => {
            this.updateTheme(e.detail.theme);
        });
        
        // Navigation events
        this.eventBus.addEventListener('navigate', (e) => {
            this.navigate(e.detail.path);
        });
        
        // Data refresh events
        this.eventBus.addEventListener('data-refresh', () => {
            this.refreshData();
        });
    }
    
    initComponents() {
        // Register all components
        this.registerComponent('navbar', Navbar);
        this.registerComponent('dashboard', Dashboard);
        this.registerComponent('work-orders', WorkOrdersList);
        this.registerComponent('assets', AssetsList);
        this.registerComponent('notifications', NotificationCenter);
        this.registerComponent('voice-assistant', VoiceAssistant);
        this.registerComponent('offline-banner', OfflineBanner);
    }
    
    registerComponent(name, ComponentClass) {
        this.components.set(name, ComponentClass);
    }
    
    async loadInitialData() {
        this.updateState({ loading: true });
        
        try {
            const [workOrders, assets, user] = await Promise.all([
                this.api.getWorkOrders(),
                this.api.getAssets(),
                this.api.getCurrentUser()
            ]);
            
            this.updateState({
                workOrders,
                assets,
                user,
                loading: false
            });
        } catch (error) {
            console.error('Failed to load initial data:', error);
            this.showNotification('Failed to load data. Working in offline mode.', 'warning');
            this.updateState({ loading: false });
        }
    }
    
    updateState(updates) {
        const oldState = { ...this.state };
        this.state = { ...this.state, ...updates };
        
        // Notify components of state change
        this.eventBus.dispatchEvent(new CustomEvent('state-change', {
            detail: { oldState, newState: this.state }
        }));
        
        // Update UI
        this.render();
    }
    
    render() {
        // Update all active components
        this.components.forEach((ComponentClass, name) => {
            const element = document.querySelector(`[data-component="${name}"]`);
            if (element && element._instance) {
                element._instance.update(this.state);
            }
        });
    }
    
    navigate(path) {
        this.updateState({ currentView: path });
        this.router.navigate(path);
    }
    
    updateTheme(theme) {
        this.state.theme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('cmms-theme', theme);
    }
    
    showNotification(message, type = 'info', duration = 5000) {
        const notification = {
            id: Date.now(),
            message,
            type,
            timestamp: new Date()
        };
        
        this.updateState({
            notifications: [...this.state.notifications, notification]
        });
        
        // Auto-remove after duration
        if (duration > 0) {
            setTimeout(() => {
                this.removeNotification(notification.id);
            }, duration);
        }
    }
    
    removeNotification(id) {
        this.updateState({
            notifications: this.state.notifications.filter(n => n.id !== id)
        });
    }
    
    async refreshData() {
        if (this.state.isOffline) {
            this.showNotification('Cannot refresh data while offline', 'warning');
            return;
        }
        
        this.updateState({ loading: true });
        await this.loadInitialData();
    }
    
    // API interface
    get api() {
        return {
            async getWorkOrders() {
                const response = await fetch('/api/work-orders');
                if (!response.ok) throw new Error('Failed to fetch work orders');
                return response.json();
            },
            
            async getAssets() {
                const response = await fetch('/api/assets');
                if (!response.ok) throw new Error('Failed to fetch assets');
                return response.json();
            },
            
            async getCurrentUser() {
                const response = await fetch('/api/user/current');
                if (!response.ok) throw new Error('Failed to fetch user');
                return response.json();
            },
            
            async createWorkOrder(data) {
                const response = await fetch('/api/work-orders', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                if (!response.ok) throw new Error('Failed to create work order');
                return response.json();
            }
        };
    }
}

/**
 * Modern Router with History API
 */
class Router {
    constructor(app) {
        this.app = app;
        this.routes = new Map();
        this.currentPath = '';
        
        this.setupRoutes();
    }
    
    setupRoutes() {
        this.addRoute('/', () => this.renderView('dashboard'));
        this.addRoute('/dashboard', () => this.renderView('dashboard'));
        this.addRoute('/work-orders', () => this.renderView('work-orders'));
        this.addRoute('/assets', () => this.renderView('assets'));
        this.addRoute('/technician', () => this.renderView('technician'));
        this.addRoute('/ai-assistant', () => this.renderView('ai-assistant'));
    }
    
    addRoute(path, handler) {
        this.routes.set(path, handler);
    }
    
    start() {
        window.addEventListener('popstate', () => this.handleRoute());
        this.handleRoute();
    }
    
    navigate(path) {
        if (this.currentPath !== path) {
            history.pushState(null, '', path);
            this.currentPath = path;
            this.handleRoute();
        }
    }
    
    handleRoute() {
        const path = window.location.pathname;
        const handler = this.routes.get(path) || this.routes.get('/');
        
        if (handler) {
            handler();
        }
    }
    
    renderView(viewName) {
        const mainContent = document.getElementById('main-content');
        if (mainContent) {
            const ComponentClass = this.app.components.get(viewName);
            if (ComponentClass) {
                mainContent.innerHTML = '';
                const component = new ComponentClass(this.app.state, this.app.eventBus);
                mainContent.appendChild(component.render());
            }
        }
    }
}

/**
 * Base Component Class
 */
class BaseComponent {
    constructor(initialState = {}, eventBus = null) {
        this.state = initialState;
        this.eventBus = eventBus;
        this.element = null;
        this.mounted = false;
    }
    
    render() {
        this.element = this.createElement();
        this.mounted = true;
        this.onMount();
        return this.element;
    }
    
    createElement() {
        // Override in child classes
        return document.createElement('div');
    }
    
    update(newState) {
        if (!this.mounted) return;
        
        const oldState = this.state;
        this.state = newState;
        this.onUpdate(oldState, newState);
    }
    
    onMount() {
        // Override in child classes
    }
    
    onUpdate(oldState, newState) {
        // Override in child classes
    }
    
    emit(eventName, data) {
        if (this.eventBus) {
            this.eventBus.dispatchEvent(new CustomEvent(eventName, { detail: data }));
        }
    }
    
    destroy() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.mounted = false;
    }
}

/**
 * Enhanced Dashboard Component
 */
class Dashboard extends BaseComponent {
    createElement() {
        const element = document.createElement('div');
        element.className = 'dashboard-container';
        element.innerHTML = `
            <div class="dashboard-header">
                <h1 class="dashboard-title">
                    <span class="dashboard-icon">📊</span>
                    System Overview
                </h1>
                <div class="dashboard-actions">
                    <button class="btn btn-primary" id="refresh-btn">
                        <span>🔄</span> Refresh
                    </button>
                    <button class="btn btn-secondary" id="voice-btn">
                        <span>🎤</span> Voice Commands
                    </button>
                </div>
            </div>
            
            <div class="kpi-grid">
                <div class="kpi-card" data-kpi="work-orders">
                    <div class="kpi-icon">📋</div>
                    <div class="kpi-content">
                        <div class="kpi-value" id="wo-count">--</div>
                        <div class="kpi-label">Active Work Orders</div>
                    </div>
                    <div class="kpi-trend">
                        <span class="trend-icon">↗️</span>
                        <span class="trend-value">+12%</span>
                    </div>
                </div>
                
                <div class="kpi-card" data-kpi="assets">
                    <div class="kpi-icon">⚙️</div>
                    <div class="kpi-content">
                        <div class="kpi-value" id="asset-count">--</div>
                        <div class="kpi-label">Monitored Assets</div>
                    </div>
                    <div class="kpi-trend">
                        <span class="trend-icon">➡️</span>
                        <span class="trend-value">0%</span>
                    </div>
                </div>
                
                <div class="kpi-card" data-kpi="efficiency">
                    <div class="kpi-icon">📈</div>
                    <div class="kpi-content">
                        <div class="kpi-value">94.2%</div>
                        <div class="kpi-label">Overall Efficiency</div>
                    </div>
                    <div class="kpi-trend">
                        <span class="trend-icon">↗️</span>
                        <span class="trend-value">+2.1%</span>
                    </div>
                </div>
                
                <div class="kpi-card" data-kpi="cost-savings">
                    <div class="kpi-icon">💰</div>
                    <div class="kpi-content">
                        <div class="kpi-value">$24.7K</div>
                        <div class="kpi-label">Cost Savings</div>
                    </div>
                    <div class="kpi-trend">
                        <span class="trend-icon">↗️</span>
                        <span class="trend-value">+8.3%</span>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <div class="dashboard-section">
                    <div class="section-header">
                        <h3>Recent Activity</h3>
                        <button class="btn-icon" title="View All">📄</button>
                    </div>
                    <div class="activity-list" id="recent-activity">
                        <!-- Activity items will be populated here -->
                    </div>
                </div>
                
                <div class="dashboard-section">
                    <div class="section-header">
                        <h3>Critical Assets</h3>
                        <button class="btn-icon" title="View All">⚙️</button>
                    </div>
                    <div class="assets-list" id="critical-assets">
                        <!-- Critical assets will be populated here -->
                    </div>
                </div>
                
                <div class="dashboard-section">
                    <div class="section-header">
                        <h3>Performance Chart</h3>
                        <div class="chart-controls">
                            <select id="chart-period">
                                <option value="7d">7 Days</option>
                                <option value="30d" selected>30 Days</option>
                                <option value="90d">90 Days</option>
                            </select>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="performance-chart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        `;
        
        return element;
    }
    
    onMount() {
        // Bind event listeners
        this.element.querySelector('#refresh-btn').addEventListener('click', () => {
            this.emit('data-refresh');
        });
        
        this.element.querySelector('#voice-btn').addEventListener('click', () => {
            this.emit('voice-activate');
        });
        
        // Initialize chart
        this.initPerformanceChart();
        
        // Update with current data
        this.updateKPIs();
    }
    
    onUpdate(oldState, newState) {
        if (newState.workOrders !== oldState.workOrders) {
            this.updateKPIs();
            this.updateRecentActivity();
        }
        
        if (newState.assets !== oldState.assets) {
            this.updateCriticalAssets();
        }
    }
    
    updateKPIs() {
        const woCount = this.element.querySelector('#wo-count');
        const assetCount = this.element.querySelector('#asset-count');
        
        if (woCount && this.state.workOrders) {
            woCount.textContent = this.state.workOrders.length;
        }
        
        if (assetCount && this.state.assets) {
            assetCount.textContent = this.state.assets.length;
        }
    }
    
    updateRecentActivity() {
        const activityList = this.element.querySelector('#recent-activity');
        if (!activityList || !this.state.workOrders) return;
        
        const recentWOs = this.state.workOrders
            .slice(0, 5)
            .map(wo => `
                <div class="activity-item">
                    <div class="activity-icon">📋</div>
                    <div class="activity-content">
                        <div class="activity-title">${wo.title || 'Work Order ' + wo.id}</div>
                        <div class="activity-meta">${wo.status} • ${wo.assigned_to || 'Unassigned'}</div>
                    </div>
                    <div class="activity-time">${this.formatTimeAgo(wo.created_at)}</div>
                </div>
            `).join('');
        
        activityList.innerHTML = recentWOs;
    }
    
    updateCriticalAssets() {
        const assetsList = this.element.querySelector('#critical-assets');
        if (!assetsList || !this.state.assets) return;
        
        const criticalAssets = this.state.assets
            .filter(asset => asset.status === 'critical' || asset.priority === 'high')
            .slice(0, 5)
            .map(asset => `
                <div class="asset-item">
                    <div class="asset-status ${asset.status}"></div>
                    <div class="asset-content">
                        <div class="asset-name">${asset.name}</div>
                        <div class="asset-location">${asset.location}</div>
                    </div>
                    <div class="asset-priority priority-${asset.priority}">${asset.priority}</div>
                </div>
            `).join('');
        
        assetsList.innerHTML = criticalAssets;
    }
    
    initPerformanceChart() {
        const canvas = this.element.querySelector('#performance-chart');
        const ctx = canvas.getContext('2d');
        
        // Simple line chart implementation
        const data = [85, 89, 92, 88, 94, 91, 96, 93, 97, 94];
        const max = Math.max(...data);
        const min = Math.min(...data);
        const range = max - min;
        
        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 3;
        ctx.beginPath();
        
        data.forEach((value, index) => {
            const x = (index / (data.length - 1)) * canvas.width;
            const y = canvas.height - ((value - min) / range) * (canvas.height - 40) - 20;
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        
        ctx.stroke();
        
        // Add data points
        ctx.fillStyle = '#667eea';
        data.forEach((value, index) => {
            const x = (index / (data.length - 1)) * canvas.width;
            const y = canvas.height - ((value - min) / range) * (canvas.height - 40) - 20;
            
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, 2 * Math.PI);
            ctx.fill();
        });
    }
    
    formatTimeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const seconds = Math.floor((now - date) / 1000);
        
        if (seconds < 60) return 'Just now';
        if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
        if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
        return Math.floor(seconds / 86400) + 'd ago';
    }
}

/**
 * Enhanced Navigation Component
 */
class Navbar extends BaseComponent {
    createElement() {
        const element = document.createElement('nav');
        element.className = 'navbar';
        element.innerHTML = `
            <div class="navbar-container">
                <div class="navbar-brand">
                    <span class="brand-icon">⚡</span>
                    <span class="brand-text">ChatterFix CMMS</span>
                    <span class="brand-version">v3.0</span>
                </div>
                
                <div class="navbar-nav">
                    <a href="/dashboard" class="nav-link" data-route="dashboard">
                        <span class="nav-icon">📊</span>
                        <span class="nav-text">Dashboard</span>
                    </a>
                    <a href="/work-orders" class="nav-link" data-route="work-orders">
                        <span class="nav-icon">📋</span>
                        <span class="nav-text">Work Orders</span>
                    </a>
                    <a href="/assets" class="nav-link" data-route="assets">
                        <span class="nav-icon">⚙️</span>
                        <span class="nav-text">Assets</span>
                    </a>
                    <a href="/ai-assistant" class="nav-link" data-route="ai-assistant">
                        <span class="nav-icon">🤖</span>
                        <span class="nav-text">AI Assistant</span>
                    </a>
                </div>
                
                <div class="navbar-actions">
                    <button class="btn-icon" id="theme-toggle" title="Toggle Theme">
                        <span class="theme-icon">🌙</span>
                    </button>
                    <button class="btn-icon" id="notifications-btn" title="Notifications">
                        <span class="notification-icon">🔔</span>
                        <span class="notification-badge" id="notification-count" style="display: none;"></span>
                    </button>
                    <div class="user-menu">
                        <button class="user-avatar" id="user-menu-btn">
                            <span class="avatar-icon">👤</span>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        return element;
    }
    
    onMount() {
        // Theme toggle
        this.element.querySelector('#theme-toggle').addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            this.emit('theme-change', { theme: newTheme });
        });
        
        // Navigation links
        this.element.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const route = link.getAttribute('data-route');
                this.emit('navigate', { path: '/' + route });
            });
        });
        
        // Update active state
        this.updateActiveNav();
    }
    
    onUpdate(oldState, newState) {
        // Update notification count
        const notificationCount = this.element.querySelector('#notification-count');
        if (newState.notifications.length > 0) {
            notificationCount.textContent = newState.notifications.length;
            notificationCount.style.display = 'block';
        } else {
            notificationCount.style.display = 'none';
        }
        
        // Update theme icon
        const themeIcon = this.element.querySelector('.theme-icon');
        themeIcon.textContent = newState.theme === 'dark' ? '☀️' : '🌙';
        
        // Update user info if available
        if (newState.user && newState.user !== oldState.user) {
            const userAvatar = this.element.querySelector('.avatar-icon');
            userAvatar.textContent = newState.user.avatar || '👤';
        }
    }
    
    updateActiveNav() {
        const currentPath = window.location.pathname.replace('/', '') || 'dashboard';
        this.element.querySelectorAll('.nav-link').forEach(link => {
            const route = link.getAttribute('data-route');
            link.classList.toggle('active', route === currentPath);
        });
    }
}

// Initialize the application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.cmmsApp = new CMmsApp();
});

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CMmsApp, Router, BaseComponent, Dashboard, Navbar };
}