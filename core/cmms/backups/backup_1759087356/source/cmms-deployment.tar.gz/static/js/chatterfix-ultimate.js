/**
 * ChatterFix CMMS - Ultimate Interactive Features Framework v2.0
 * Production-Grade JavaScript for All 9 Modules with AI Integration
 * Matches Parts dashboard interactivity (search, export, real-time updates, AI commands)
 */

class ChatterFixApp {
    constructor() {
        this.modules = [
            'assets', 'workorders', 'parts', 'preventive', 
            'ai', 'admin', 'quality', 'technician', 'dashboard'
        ];
        this.apiBase = '/cmms';
        this.aiEnabled = true;
        this.voiceEnabled = false;
        this.cache = new Map();
        this.notifications = [];
        
        this.init();
    }

    init() {
        console.log('🚀 ChatterFix CMMS Ultimate v2.0 Loading...');
        
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeApp());
        } else {
            this.initializeApp();
        }
    }

    initializeApp() {
        this.setupEventListeners();
        this.initializeSearch();
        this.initializeAlerts();
        this.initializeExport();
        this.initializeAI();
        this.initializeVoice();
        this.initializeRealTimeUpdates();
        this.initializeNavigation();
        this.initializeMobile();
        
        // Hide loading screen
        setTimeout(() => this.hideLoadingScreen(), 1000);
        
        console.log('✅ ChatterFix CMMS Ultimate Ready!');
    }

    hideLoadingScreen() {
        const loadingElement = document.getElementById('app-loading');
        if (loadingElement && loadingElement.parentNode) {
            loadingElement.style.opacity = '0';
            loadingElement.style.transition = 'opacity 0.3s ease-out';
            setTimeout(() => {
                if (loadingElement.parentNode) {
                    loadingElement.remove();
                }
            }, 300);
        }
    }

    setupEventListeners() {
        // Global click handler for interactive elements
        document.addEventListener('click', this.handleGlobalClick.bind(this));
        
        // Global form submission
        document.addEventListener('submit', this.handleFormSubmit.bind(this));
        
        // Keyboard shortcuts
        document.addEventListener('keydown', this.handleKeyboardShortcuts.bind(this));
        
        // Window resize for responsive features
        window.addEventListener('resize', this.debounce(this.handleResize.bind(this), 250));
    }

    handleGlobalClick(event) {
        const target = event.target;
        
        // Handle alert dismissal
        if (target.classList.contains('alert-dismiss')) {
            event.preventDefault();
            this.dismissAlert(target.closest('.alert'));
        }
        
        // Handle export buttons
        if (target.classList.contains('export-btn')) {
            event.preventDefault();
            this.handleExport(target.dataset.type || 'csv');
        }
        
        // Handle status badge clicks for filtering
        if (target.classList.contains('status-badge')) {
            this.filterByStatus(target.textContent.trim());
        }
        
        // Handle card clicks for details
        if (target.closest('.chatterfix-card[data-item-id]')) {
            const card = target.closest('.chatterfix-card');
            this.showItemDetails(card.dataset.itemId, card.dataset.itemType);
        }
    }

    handleFormSubmit(event) {
        const form = event.target;
        
        // Handle AI chat form
        if (form.classList.contains('ai-chat-form')) {
            event.preventDefault();
            this.handleAIChat(form);
        }
        
        // Handle search forms
        if (form.classList.contains('search-form')) {
            event.preventDefault();
            this.handleSearch(form);
        }
    }

    handleKeyboardShortcuts(event) {
        // Ctrl/Cmd + K for search
        if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
            event.preventDefault();
            this.focusSearch();
        }
        
        // Ctrl/Cmd + E for export
        if ((event.ctrlKey || event.metaKey) && event.key === 'e') {
            event.preventDefault();
            this.handleExport('csv');
        }
        
        // Escape to close modals/alerts
        if (event.key === 'Escape') {
            this.closeModals();
        }
    }

    handleResize() {
        // Adjust layouts for mobile
        this.adjustMobileLayout();
        
        // Recalculate grid layouts
        this.recalculateGrids();
    }

    // ==================== SEARCH FUNCTIONALITY ====================
    initializeSearch() {
        const searchInputs = document.querySelectorAll('.search-input');
        
        searchInputs.forEach(input => {
            input.addEventListener('input', this.debounce((e) => {
                this.performSearch(e.target.value, e.target.dataset.searchType);
            }, 300));
            
            // Add search icon if not present
            if (!input.nextElementSibling?.classList.contains('search-icon')) {
                const icon = document.createElement('span');
                icon.className = 'search-icon';
                icon.innerHTML = '🔍';
                input.parentNode.insertBefore(icon, input.nextSibling);
            }
        });
    }

    performSearch(query, searchType = 'all') {
        const normalizedQuery = query.toLowerCase().trim();
        
        if (!normalizedQuery) {
            this.showAllItems();
            return;
        }
        
        const searchableElements = document.querySelectorAll('.chatterfix-card, .chatterfix-table tbody tr');
        let visibleCount = 0;
        
        searchableElements.forEach(element => {
            const text = element.textContent.toLowerCase();
            const matches = text.includes(normalizedQuery);
            
            element.style.display = matches ? '' : 'none';
            if (matches) visibleCount++;
        });
        
        this.updateSearchResults(visibleCount, query);
    }

    showAllItems() {
        const searchableElements = document.querySelectorAll('.chatterfix-card, .chatterfix-table tbody tr');
        searchableElements.forEach(element => {
            element.style.display = '';
        });
    }

    updateSearchResults(count, query) {
        let resultsDiv = document.querySelector('.search-results');
        if (!resultsDiv) {
            resultsDiv = document.createElement('div');
            resultsDiv.className = 'search-results alert alert-info';
            const searchContainer = document.querySelector('.search-container');
            if (searchContainer) {
                searchContainer.appendChild(resultsDiv);
            }
        }
        
        if (query) {
            resultsDiv.innerHTML = `Found ${count} result${count !== 1 ? 's' : ''} for "${query}"`;
            resultsDiv.style.display = 'block';
        } else {
            resultsDiv.style.display = 'none';
        }
    }

    focusSearch() {
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }

    filterByStatus(status) {
        const normalizedStatus = status.toLowerCase();
        const cards = document.querySelectorAll('.chatterfix-card');
        
        cards.forEach(card => {
            const statusBadge = card.querySelector('.status-badge');
            if (statusBadge) {
                const cardStatus = statusBadge.textContent.toLowerCase();
                card.style.display = cardStatus.includes(normalizedStatus) ? '' : 'none';
            }
        });
        
        this.showNotification(`Filtered by status: ${status}`, 'info');
    }

    // ==================== EXPORT FUNCTIONALITY ====================
    initializeExport() {
        // Add export buttons to modules if not present
        this.addExportButtons();
    }

    addExportButtons() {
        const containers = document.querySelectorAll('.chatterfix-container');
        
        containers.forEach(container => {
            if (!container.querySelector('.export-btn')) {
                const exportBtn = document.createElement('button');
                exportBtn.className = 'btn btn-primary export-btn';
                exportBtn.innerHTML = '📊 Export CSV';
                exportBtn.dataset.type = 'csv';
                
                const headerDiv = container.querySelector('.summary-grid') || container.firstElementChild;
                if (headerDiv) {
                    const buttonContainer = document.createElement('div');
                    buttonContainer.className = 'text-right mb-2';
                    buttonContainer.appendChild(exportBtn);
                    headerDiv.parentNode.insertBefore(buttonContainer, headerDiv.nextSibling);
                }
            }
        });
    }

    async handleExport(type = 'csv') {
        try {
            this.showNotification('Generating export...', 'info');
            
            const currentModule = this.getCurrentModule();
            const endpoint = `${this.apiBase}/${currentModule}/export/${type}`;
            
            const response = await fetch(endpoint, {
                method: 'GET',
                headers: {
                    'Accept': type === 'csv' ? 'text/csv' : 'application/json',
                }
            });
            
            if (!response.ok) {
                throw new Error(`Export failed: ${response.statusText}`);
            }
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `chatterfix-${currentModule}-${new Date().toISOString().split('T')[0]}.${type}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            this.showNotification('Export completed successfully!', 'success');
        } catch (error) {
            console.error('Export error:', error);
            this.showNotification('Export failed. Please try again.', 'danger');
        }
    }

    getCurrentModule() {
        const path = window.location.pathname;
        for (const module of this.modules) {
            if (path.includes(module)) {
                return module;
            }
        }
        return 'dashboard';
    }

    // ==================== AI FUNCTIONALITY ====================
    initializeAI() {
        if (!this.aiEnabled) return;
        
        this.setupAIChat();
        this.setupAIInsights();
        this.setupAIPredictions();
    }

    setupAIChat() {
        const aiInputs = document.querySelectorAll('.ai-input');
        
        aiInputs.forEach(input => {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendAIMessage(input);
                }
            });
        });
    }

    async sendAIMessage(input) {
        const message = input.value.trim();
        if (!message) return;
        
        const responseContainer = input.parentNode.querySelector('.ai-response') || 
                                 this.createAIResponseContainer(input.parentNode);
        
        try {
            this.showAITyping(responseContainer);
            
            const response = await fetch(`${this.apiBase}/ai/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    context: this.getCurrentModule(),
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`AI request failed: ${response.statusText}`);
            }
            
            const data = await response.json();
            this.displayAIResponse(responseContainer, data, message);
            
            input.value = '';
        } catch (error) {
            console.error('AI chat error:', error);
            this.displayAIError(responseContainer, error.message);
        }
    }

    createAIResponseContainer(parent) {
        const container = document.createElement('div');
        container.className = 'ai-response mt-1';
        parent.appendChild(container);
        return container;
    }

    showAITyping(container) {
        container.innerHTML = `
            <div class="ai-typing">
                <span class="typing-indicator">🤖 AI is thinking</span>
                <div class="typing-dots">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
    }

    displayAIResponse(container, data, originalMessage) {
        const timestamp = new Date().toLocaleTimeString();
        const confidence = data.confidence || 95;
        const response = data.response || data.message || 'No response from AI';
        
        container.innerHTML = `
            <div class="ai-message-pair">
                <div class="user-message">
                    <strong>You:</strong> ${this.escapeHtml(originalMessage)}
                    <span class="message-time">${timestamp}</span>
                </div>
                <div class="ai-message">
                    <strong>🤖 AI:</strong> ${this.escapeHtml(response)}
                    <div class="ai-metadata">
                        <span class="confidence">Confidence: ${confidence}%</span>
                        <span class="response-time">${timestamp}</span>
                    </div>
                </div>
            </div>
        `;
        
        // Add suggested actions if provided
        if (data.actions && data.actions.length > 0) {
            this.addAISuggestedActions(container, data.actions);
        }
    }

    displayAIError(container, errorMessage) {
        container.innerHTML = `
            <div class="ai-error alert alert-danger">
                <strong>❌ AI Error:</strong> ${this.escapeHtml(errorMessage)}
                <button class="btn btn-primary mt-1" onclick="location.reload()">Retry</button>
            </div>
        `;
    }

    addAISuggestedActions(container, actions) {
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'ai-suggested-actions mt-1';
        actionsDiv.innerHTML = '<strong>Suggested Actions:</strong>';
        
        actions.forEach(action => {
            const actionBtn = document.createElement('button');
            actionBtn.className = 'btn btn-sm btn-outline-primary ml-1';
            actionBtn.textContent = action.label;
            actionBtn.onclick = () => this.executeAIAction(action);
            actionsDiv.appendChild(actionBtn);
        });
        
        container.appendChild(actionsDiv);
    }

    executeAIAction(action) {
        switch (action.type) {
            case 'create_workorder':
                this.createWorkOrder(action.data);
                break;
            case 'search':
                this.performSearch(action.data.query);
                break;
            case 'navigate':
                window.location.href = action.data.url;
                break;
            default:
                console.log('Unknown AI action:', action);
        }
    }

    setupAIInsights() {
        // Add AI insights to summary cards
        this.addAIInsights();
    }

    async addAIInsights() {
        const summaryCards = document.querySelectorAll('.summary-card');
        
        summaryCards.forEach(async (card, index) => {
            try {
                const insight = await this.getAIInsight(card, index);
                if (insight) {
                    this.displayAIInsight(card, insight);
                }
            } catch (error) {
                console.warn('AI insight error:', error);
            }
        });
    }

    async getAIInsight(card, index) {
        // Simulate AI insight generation
        const insights = [
            "📈 15% increase from last month",
            "⚠️ Trending upward - attention needed",
            "✅ Within normal parameters",
            "🔍 Requires investigation",
            "🎯 Meeting target goals"
        ];
        
        return insights[index % insights.length];
    }

    displayAIInsight(card, insight) {
        let insightDiv = card.querySelector('.ai-insight');
        if (!insightDiv) {
            insightDiv = document.createElement('div');
            insightDiv.className = 'ai-insight opacity-80';
            insightDiv.style.fontSize = '0.75rem';
            insightDiv.style.marginTop = '0.5rem';
            card.appendChild(insightDiv);
        }
        
        insightDiv.innerHTML = `🤖 ${insight}`;
    }

    setupAIPredictions() {
        // Add predictive analytics to relevant modules
        this.addPredictiveAnalytics();
    }

    addPredictiveAnalytics() {
        const currentModule = this.getCurrentModule();
        
        if (['assets', 'workorders', 'preventive'].includes(currentModule)) {
            this.displayPredictiveInsights(currentModule);
        }
    }

    displayPredictiveInsights(module) {
        const predictions = {
            assets: "🔮 Predicted failure risk for Pump #3: 15% (Next 30 days)",
            workorders: "📊 Expected completion: 2 days ahead of schedule",
            preventive: "⏰ Optimal maintenance window: Thursday 2-4 PM"
        };
        
        const prediction = predictions[module];
        if (prediction) {
            this.showNotification(prediction, 'info', 10000);
        }
    }

    // ==================== VOICE FUNCTIONALITY ====================
    initializeVoice() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.warn('Speech recognition not supported');
            return;
        }
        
        this.setupVoiceRecognition();
        this.addVoiceButtons();
    }

    setupVoiceRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'en-US';
        
        this.recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            this.processVoiceCommand(transcript);
        };
        
        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.showNotification('Voice command failed. Please try again.', 'warning');
        };
    }

    addVoiceButtons() {
        const aiInputs = document.querySelectorAll('.ai-input');
        
        aiInputs.forEach(input => {
            if (!input.parentNode.querySelector('.voice-btn')) {
                const voiceBtn = document.createElement('button');
                voiceBtn.className = 'btn btn-sm btn-primary voice-btn';
                voiceBtn.innerHTML = '🎤';
                voiceBtn.type = 'button';
                voiceBtn.title = 'Voice Command';
                voiceBtn.onclick = () => this.startVoiceRecognition(input);
                
                input.parentNode.appendChild(voiceBtn);
            }
        });
    }

    startVoiceRecognition(targetInput) {
        if (!this.recognition) return;
        
        this.currentVoiceInput = targetInput;
        this.recognition.start();
        
        const voiceBtn = targetInput.parentNode.querySelector('.voice-btn');
        if (voiceBtn) {
            voiceBtn.innerHTML = '🔴';
            voiceBtn.disabled = true;
            setTimeout(() => {
                voiceBtn.innerHTML = '🎤';
                voiceBtn.disabled = false;
            }, 5000);
        }
        
        this.showNotification('🎤 Listening for voice command...', 'info', 3000);
    }

    processVoiceCommand(transcript) {
        if (this.currentVoiceInput) {
            this.currentVoiceInput.value = transcript;
            this.sendAIMessage(this.currentVoiceInput);
        }
        
        this.showNotification(`Voice command received: "${transcript}"`, 'success');
    }

    // ==================== REAL-TIME UPDATES ====================
    initializeRealTimeUpdates() {
        // Set up periodic updates for live data
        this.setupPeriodicUpdates();
        
        // Set up WebSocket if available
        this.setupWebSocket();
    }

    setupPeriodicUpdates() {
        // Update summary stats every 30 seconds
        setInterval(() => {
            this.updateSummaryStats();
        }, 30000);
        
        // Update status indicators every 10 seconds
        setInterval(() => {
            this.updateStatusIndicators();
        }, 10000);
    }

    async updateSummaryStats() {
        try {
            const currentModule = this.getCurrentModule();
            const response = await fetch(`${this.apiBase}/${currentModule}/stats`);
            
            if (response.ok) {
                const stats = await response.json();
                this.renderUpdatedStats(stats);
            }
        } catch (error) {
            console.warn('Stats update failed:', error);
        }
    }

    renderUpdatedStats(stats) {
        const summaryCards = document.querySelectorAll('.summary-card');
        
        Object.entries(stats).forEach(([key, value], index) => {
            const card = summaryCards[index];
            if (card) {
                const valueElement = card.querySelector('.value');
                if (valueElement && valueElement.textContent !== String(value)) {
                    // Animate value change
                    valueElement.style.transform = 'scale(1.1)';
                    valueElement.style.color = 'var(--accent-gold)';
                    setTimeout(() => {
                        valueElement.textContent = value;
                        valueElement.style.transform = 'scale(1)';
                        valueElement.style.color = 'var(--success-green)';
                    }, 200);
                }
            }
        });
    }

    updateStatusIndicators() {
        // Simulate random status updates for demo
        const statusBadges = document.querySelectorAll('.status-badge');
        
        statusBadges.forEach(badge => {
            // Add subtle pulse animation to active statuses
            if (badge.classList.contains('status-in-progress')) {
                badge.style.animation = 'pulse 2s infinite';
            }
        });
    }

    setupWebSocket() {
        // WebSocket implementation for real-time updates
        // This would connect to your backend WebSocket endpoint
        if (typeof WebSocket !== 'undefined') {
            try {
                const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
                const wsUrl = `${protocol}//${window.location.host}/ws/updates`;
                
                this.websocket = new WebSocket(wsUrl);
                
                this.websocket.onmessage = (event) => {
                    const data = JSON.parse(event.data);
                    this.handleWebSocketMessage(data);
                };
                
                this.websocket.onclose = () => {
                    console.log('WebSocket connection closed');
                    // Attempt reconnection after 5 seconds
                    setTimeout(() => this.setupWebSocket(), 5000);
                };
            } catch (error) {
                console.warn('WebSocket not available:', error);
            }
        }
    }

    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'status_update':
                this.updateStatusBadge(data.id, data.status);
                break;
            case 'new_alert':
                this.showNotification(data.message, data.level);
                break;
            case 'data_refresh':
                this.refreshModuleData(data.module);
                break;
        }
    }

    // ==================== NAVIGATION ====================
    initializeNavigation() {
        this.setupActiveNavigation();
        this.setupBreadcrumbs();
    }

    setupActiveNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        const currentPath = window.location.pathname;
        
        navLinks.forEach(link => {
            if (currentPath.includes(link.getAttribute('href'))) {
                link.classList.add('active');
            }
        });
    }

    setupBreadcrumbs() {
        const breadcrumbContainer = document.querySelector('.breadcrumbs');
        if (breadcrumbContainer) {
            const breadcrumbs = this.generateBreadcrumbs();
            breadcrumbContainer.innerHTML = breadcrumbs;
        }
    }

    generateBreadcrumbs() {
        const pathSegments = window.location.pathname.split('/').filter(Boolean);
        const breadcrumbs = ['<a href="/cmms">Dashboard</a>'];
        
        let currentPath = '';
        pathSegments.forEach((segment, index) => {
            currentPath += `/${segment}`;
            const isLast = index === pathSegments.length - 1;
            const label = segment.charAt(0).toUpperCase() + segment.slice(1);
            
            if (isLast) {
                breadcrumbs.push(`<span class="current">${label}</span>`);
            } else {
                breadcrumbs.push(`<a href="${currentPath}">${label}</a>`);
            }
        });
        
        return breadcrumbs.join(' <span class="separator">›</span> ');
    }

    // ==================== MOBILE OPTIMIZATION ====================
    initializeMobile() {
        this.setupMobileDetection();
        this.setupTouchGestures();
        this.setupMobileNavigation();
    }

    setupMobileDetection() {
        this.isMobile = window.innerWidth <= 768;
        
        if (this.isMobile) {
            document.body.classList.add('mobile-device');
            this.optimizeForMobile();
        }
    }

    optimizeForMobile() {
        // Reduce animation complexity on mobile
        const cards = document.querySelectorAll('.chatterfix-card');
        cards.forEach(card => {
            card.style.transition = 'transform 0.2s ease';
        });
        
        // Increase touch targets
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(btn => {
            btn.style.minHeight = '44px';
            btn.style.minWidth = '44px';
        });
    }

    setupTouchGestures() {
        if (!this.isMobile) return;
        
        let startX, startY;
        
        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        }, { passive: true });
        
        document.addEventListener('touchend', (e) => {
            if (!startX || !startY) return;
            
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            
            const deltaX = endX - startX;
            const deltaY = endY - startY;
            
            // Swipe right to go back
            if (deltaX > 100 && Math.abs(deltaY) < 50) {
                this.handleSwipeRight();
            }
            
            // Swipe left for menu (if implemented)
            if (deltaX < -100 && Math.abs(deltaY) < 50) {
                this.handleSwipeLeft();
            }
        }, { passive: true });
    }

    handleSwipeRight() {
        // Navigate back if possible
        if (window.history.length > 1) {
            window.history.back();
        }
    }

    handleSwipeLeft() {
        // Toggle mobile menu if exists
        const mobileMenu = document.querySelector('.mobile-menu');
        if (mobileMenu) {
            mobileMenu.classList.toggle('show');
        }
    }

    setupMobileNavigation() {
        // Create mobile hamburger menu if not exists
        if (this.isMobile && !document.querySelector('.mobile-menu-toggle')) {
            this.createMobileMenu();
        }
    }

    createMobileMenu() {
        const nav = document.querySelector('.chatterfix-nav');
        if (!nav) return;
        
        const toggle = document.createElement('button');
        toggle.className = 'mobile-menu-toggle btn btn-primary';
        toggle.innerHTML = '☰';
        toggle.onclick = () => this.toggleMobileMenu();
        
        nav.appendChild(toggle);
    }

    toggleMobileMenu() {
        const menu = document.querySelector('.nav-menu');
        if (menu) {
            menu.classList.toggle('mobile-show');
        }
    }

    // ==================== ALERTS & NOTIFICATIONS ====================
    initializeAlerts() {
        this.setupNotificationContainer();
        this.setupAlertDismissal();
    }

    setupNotificationContainer() {
        if (!document.querySelector('.notification-container')) {
            const container = document.createElement('div');
            container.className = 'notification-container';
            container.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
                max-width: 400px;
                pointer-events: none;
            `;
            document.body.appendChild(container);
        }
    }

    setupAlertDismissal() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('alert-dismiss')) {
                this.dismissAlert(e.target.closest('.alert'));
            }
        });
    }

    showNotification(message, type = 'info', duration = 5000) {
        const container = document.querySelector('.notification-container');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} notification`;
        notification.style.cssText = `
            margin-bottom: 10px;
            pointer-events: auto;
            animation: slideInRight 0.3s ease-out;
        `;
        
        notification.innerHTML = `
            ${message}
            <button class="alert-dismiss" style="float: right; background: none; border: none; color: currentColor; font-size: 1.2rem; cursor: pointer;">&times;</button>
        `;
        
        container.appendChild(notification);
        
        // Auto-dismiss after duration
        if (duration > 0) {
            setTimeout(() => {
                this.dismissAlert(notification);
            }, duration);
        }
        
        return notification;
    }

    dismissAlert(alertElement) {
        if (!alertElement) return;
        
        alertElement.style.animation = 'slideOutRight 0.3s ease-in forwards';
        setTimeout(() => {
            if (alertElement.parentNode) {
                alertElement.parentNode.removeChild(alertElement);
            }
        }, 300);
    }

    closeModals() {
        const modals = document.querySelectorAll('.modal.show');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
    }

    // ==================== FILE UPLOAD FUNCTIONS ====================
    showFileUploadModal(moduleType, itemId = null) {
        const title = itemId ? `Upload Files for ${moduleType} ${itemId}` : `Upload Files to ${moduleType}`;
        const modal = this.createModal(title, this.getFileUploadForm(moduleType, itemId));
        modal.style.display = 'block';
    }

    getFileUploadForm(moduleType, itemId) {
        return `
            <div style="margin-bottom: 2rem;">
                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📁 Select Files:</label>
                    <input type="file" id="file-upload" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.gif,.mp4,.mov" 
                           style="width: 100%; padding: 0.75rem; border: 2px dashed rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.05); color: white;">
                    <div style="font-size: 0.8rem; opacity: 0.7; margin-top: 0.5rem;">
                        Supports: PDF, Word, Excel, Images, Videos
                    </div>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📋 File Type:</label>
                    <select id="file-type" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        <option value="manual">📖 Machine Manual</option>
                        <option value="photo">📷 Photo/Image</option>
                        <option value="document">📄 General Document</option>
                        <option value="data">📊 Data/Excel File</option>
                        <option value="video">🎥 Training Video</option>
                        <option value="certification">🏆 Certification</option>
                    </select>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📝 Description (Optional):</label>
                    <textarea id="file-description" placeholder="Describe the file contents..." 
                              style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white; height: 80px;"></textarea>
                </div>

                <!-- Upload Progress -->
                <div id="upload-progress" style="display: none; margin-bottom: 1rem;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                        <span>Uploading...</span>
                        <span id="progress-percent">0%</span>
                    </div>
                    <div style="width: 100%; height: 8px; background: rgba(255,255,255,0.1); border-radius: 4px; overflow: hidden;">
                        <div id="progress-bar" style="height: 100%; background: var(--success-green); width: 0%; transition: width 0.3s ease;"></div>
                    </div>
                </div>

                <!-- File Preview Area -->
                <div id="file-preview" style="margin-bottom: 1.5rem;"></div>

                <div style="text-align: center;">
                    <button type="button" class="btn btn-success" onclick="ChatterFix.uploadFiles('${moduleType}', '${itemId}')" style="margin-right: 1rem;">
                        📤 Upload Files
                    </button>
                    <button type="button" class="btn btn-primary" onclick="ChatterFix.showImportModal('${moduleType}')" style="margin-right: 1rem;">
                        📥 Import Data
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('chatterfix-modal').remove()">
                        Cancel
                    </button>
                </div>
            </div>

            <script>
                // File preview functionality
                document.getElementById('file-upload').addEventListener('change', function(e) {
                    ChatterFix.previewFiles(e.target.files);
                });
            </script>
        `;
    }

    previewFiles(files) {
        const preview = document.getElementById('file-preview');
        preview.innerHTML = '';
        
        if (files.length === 0) return;

        preview.innerHTML = '<h4 style="margin-bottom: 1rem;">📋 Selected Files:</h4>';
        
        Array.from(files).forEach((file, index) => {
            const fileItem = document.createElement('div');
            fileItem.style.cssText = 'display: flex; align-items: center; padding: 0.75rem; background: rgba(255,255,255,0.05); border-radius: 8px; margin-bottom: 0.5rem;';
            
            const fileIcon = this.getFileIcon(file.type);
            const fileSize = this.formatFileSize(file.size);
            
            fileItem.innerHTML = `
                <span style="font-size: 1.5rem; margin-right: 1rem;">${fileIcon}</span>
                <div style="flex: 1;">
                    <div style="font-weight: 600;">${file.name}</div>
                    <div style="font-size: 0.8rem; opacity: 0.7;">${fileSize} • ${file.type || 'Unknown type'}</div>
                </div>
                <button onclick="this.parentElement.remove()" style="background: none; border: none; color: #ff6b6b; cursor: pointer; font-size: 1.2rem;">✖</button>
            `;
            
            // Add image preview for images
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.cssText = 'width: 50px; height: 50px; object-fit: cover; border-radius: 4px; margin-left: 1rem;';
                    fileItem.appendChild(img);
                };
                reader.readAsDataURL(file);
            }
            
            preview.appendChild(fileItem);
        });
    }

    getFileIcon(fileType) {
        if (fileType.startsWith('image/')) return '🖼️';
        if (fileType.startsWith('video/')) return '🎥';
        if (fileType.includes('pdf')) return '📄';
        if (fileType.includes('word') || fileType.includes('document')) return '📝';
        if (fileType.includes('excel') || fileType.includes('spreadsheet')) return '📊';
        if (fileType.includes('powerpoint') || fileType.includes('presentation')) return '📑';
        if (fileType.startsWith('audio/')) return '🎵';
        return '📎';
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    async uploadFiles(moduleType, itemId) {
        const fileInput = document.getElementById('file-upload');
        const fileType = document.getElementById('file-type').value;
        const description = document.getElementById('file-description').value;
        const progressDiv = document.getElementById('upload-progress');
        const progressBar = document.getElementById('progress-bar');
        const progressPercent = document.getElementById('progress-percent');

        if (!fileInput.files.length) {
            this.showNotification('Please select files to upload', 'warning');
            return;
        }

        progressDiv.style.display = 'block';
        
        const formData = new FormData();
        Array.from(fileInput.files).forEach(file => {
            formData.append('files', file);
        });
        formData.append('file_type', fileType);
        formData.append('description', description);
        if (itemId && itemId !== 'null') formData.append('item_id', itemId);

        try {
            const response = await fetch(`/cmms/${this.normalizeModuleName(moduleType)}/upload`, {
                method: 'POST',
                body: formData,
                onUploadProgress: (progressEvent) => {
                    const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                    progressBar.style.width = percentCompleted + '%';
                    progressPercent.textContent = percentCompleted + '%';
                }
            });

            if (response.ok) {
                const result = await response.json();
                this.showNotification(`✅ Successfully uploaded ${fileInput.files.length} file(s)!`, 'success');
                document.getElementById('chatterfix-modal').remove();
                // Refresh the page to show new files
                setTimeout(() => window.location.reload(), 1500);
            } else {
                const error = await response.text();
                this.showNotification(`❌ Upload failed: ${error}`, 'error');
            }
        } catch (error) {
            this.showNotification(`❌ Network error: ${error.message}`, 'error');
        } finally {
            progressDiv.style.display = 'none';
        }
    }

    // ==================== EXPORT/IMPORT FUNCTIONS ====================
    showExportModal(moduleType) {
        const modal = this.createModal(`📤 Export ${moduleType} Data`, this.getExportForm(moduleType));
        modal.style.display = 'block';
    }

    getExportForm(moduleType) {
        return `
            <div style="margin-bottom: 2rem;">
                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📊 Export Format:</label>
                    <select id="export-format" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        <option value="excel">📊 Excel (.xlsx)</option>
                        <option value="csv">📄 CSV (.csv)</option>
                        <option value="pdf">📄 PDF Report</option>
                        <option value="json">⚙️ JSON Data</option>
                    </select>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📅 Date Range:</label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <input type="date" id="export-start-date" style="padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        <input type="date" id="export-end-date" style="padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                    </div>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">🔧 Include Fields:</label>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem;">
                        <label><input type="checkbox" checked> Basic Info</label>
                        <label><input type="checkbox" checked> Status</label>
                        <label><input type="checkbox" checked> Dates</label>
                        <label><input type="checkbox"> Photos</label>
                        <label><input type="checkbox"> History</label>
                        <label><input type="checkbox"> Comments</label>
                    </div>
                </div>

                <div style="text-align: center;">
                    <button type="button" class="btn btn-success" onclick="ChatterFix.exportData('${moduleType}')" style="margin-right: 1rem;">
                        📤 Export Data
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('chatterfix-modal').remove()">
                        Cancel
                    </button>
                </div>
            </div>
        `;
    }

    showImportModal(moduleType) {
        const modal = this.createModal(`📥 Import ${moduleType} Data`, this.getImportForm(moduleType));
        modal.style.display = 'block';
    }

    getImportForm(moduleType) {
        return `
            <div style="margin-bottom: 2rem;">
                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">📁 Select Import File:</label>
                    <input type="file" id="import-file" accept=".xlsx,.xls,.csv,.json" 
                           style="width: 100%; padding: 0.75rem; border: 2px dashed rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.05); color: white;">
                    <div style="font-size: 0.8rem; opacity: 0.7; margin-top: 0.5rem;">
                        Supports: Excel (.xlsx, .xls), CSV (.csv), JSON (.json)
                    </div>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">⚙️ Import Options:</label>
                    <div style="display: grid; gap: 0.5rem;">
                        <label><input type="checkbox" id="update-existing" checked> Update existing records</label>
                        <label><input type="checkbox" id="skip-duplicates"> Skip duplicates</label>
                        <label><input type="checkbox" id="validate-data" checked> Validate data before import</label>
                    </div>
                </div>

                <div style="background: rgba(255,193,7,0.1); border: 1px solid rgba(255,193,7,0.3); border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem;">
                    <div style="font-weight: 600; margin-bottom: 0.5rem;">📋 Template Download:</div>
                    <div style="font-size: 0.9rem; opacity: 0.8; margin-bottom: 1rem;">Download the template to ensure proper formatting</div>
                    <button type="button" class="btn btn-warning" onclick="ChatterFix.downloadTemplate('${moduleType}')" style="font-size: 0.9rem;">
                        📥 Download ${moduleType} Template
                    </button>
                </div>

                <div style="text-align: center;">
                    <button type="button" class="btn btn-success" onclick="ChatterFix.importData('${moduleType}')" style="margin-right: 1rem;">
                        📥 Import Data
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('chatterfix-modal').remove()">
                        Cancel
                    </button>
                </div>
            </div>
        `;
    }

    async exportData(moduleType) {
        const format = document.getElementById('export-format').value;
        const startDate = document.getElementById('export-start-date').value;
        const endDate = document.getElementById('export-end-date').value;
        
        const params = new URLSearchParams({
            format: format,
            start_date: startDate,
            end_date: endDate
        });

        try {
            this.showNotification('🔄 Generating export...', 'info');
            const response = await fetch(`/cmms/${this.normalizeModuleName(moduleType)}/export?${params}`);
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${moduleType}_export_${new Date().toISOString().split('T')[0]}.${format}`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                this.showNotification('✅ Export completed successfully!', 'success');
                document.getElementById('chatterfix-modal').remove();
            } else {
                this.showNotification('❌ Export failed', 'error');
            }
        } catch (error) {
            this.showNotification(`❌ Export error: ${error.message}`, 'error');
        }
    }

    async importData(moduleType) {
        const fileInput = document.getElementById('import-file');
        const updateExisting = document.getElementById('update-existing').checked;
        const skipDuplicates = document.getElementById('skip-duplicates').checked;
        const validateData = document.getElementById('validate-data').checked;

        if (!fileInput.files.length) {
            this.showNotification('Please select a file to import', 'warning');
            return;
        }

        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('update_existing', updateExisting);
        formData.append('skip_duplicates', skipDuplicates);
        formData.append('validate_data', validateData);

        try {
            this.showNotification('🔄 Importing data...', 'info');
            const response = await fetch(`/cmms/${this.normalizeModuleName(moduleType)}/import`, {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                const result = await response.json();
                this.showNotification(`✅ Import completed! ${result.imported_count || 0} records imported`, 'success');
                document.getElementById('chatterfix-modal').remove();
                setTimeout(() => window.location.reload(), 1500);
            } else {
                const error = await response.text();
                this.showNotification(`❌ Import failed: ${error}`, 'error');
            }
        } catch (error) {
            this.showNotification(`❌ Import error: ${error.message}`, 'error');
        }
    }

    async downloadTemplate(moduleType) {
        try {
            const response = await fetch(`/cmms/${this.normalizeModuleName(moduleType)}/template`);
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${moduleType}_import_template.xlsx`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                this.showNotification('📥 Template downloaded successfully!', 'success');
            } else {
                this.showNotification('❌ Template download failed', 'error');
            }
        } catch (error) {
            this.showNotification(`❌ Download error: ${error.message}`, 'error');
        }
    }

    // ==================== WORK ORDER FUNCTIONS ====================
    showCreateModal(moduleType) {
        const modal = this.createModal('Create New ' + moduleType.replace('_', ' ').toUpperCase(), this.getCreateForm(moduleType));
        modal.style.display = 'block';
    }

    showEditModal(itemId, moduleType) {
        const modal = this.createModal('Edit ' + moduleType.replace('_', ' ').toUpperCase(), this.getEditForm(itemId, moduleType));
        modal.style.display = 'block';
    }

    showItemDetails(itemId, moduleType) {
        this.showNotification(`Loading details for ${moduleType} ${itemId}...`, 'info');
        // Redirect to detail view
        window.location.href = `/cmms/${moduleType}/${itemId}`;
    }

    createModal(title, content) {
        // Remove existing modal
        const existingModal = document.getElementById('chatterfix-modal');
        if (existingModal) {
            existingModal.remove();
        }

        const modal = document.createElement('div');
        modal.id = 'chatterfix-modal';
        modal.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;">
                <div class="chatterfix-card" style="max-width: 600px; max-height: 80vh; overflow-y: auto; margin: 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <h3>${title}</h3>
                        <button onclick="document.getElementById('chatterfix-modal').remove()" style="background: none; border: none; color: white; font-size: 1.5rem; cursor: pointer;">&times;</button>
                    </div>
                    <div>${content}</div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        return modal;
    }

    getCreateForm(moduleType) {
        // Normalize module names to match API endpoints
        const normalizedType = this.normalizeModuleName(moduleType);
        
        switch(normalizedType) {
            case 'workorders':
                return `
                    <form onsubmit="ChatterFix.submitCreateForm(event, 'workorders')">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Title:</label>
                            <input type="text" name="title" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Description:</label>
                            <textarea name="description" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white; height: 100px;"></textarea>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Type:</label>
                            <select name="type" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                                <option value="maintenance">Maintenance</option>
                                <option value="repair">Repair</option>
                                <option value="inspection">Inspection</option>
                                <option value="emergency">Emergency</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Priority:</label>
                            <select name="priority" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                                <option value="Low">Low</option>
                                <option value="Medium" selected>Medium</option>
                                <option value="High">High</option>
                                <option value="Critical">Critical</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Asset ID:</label>
                            <input type="text" name="asset_id" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;" placeholder="ASSET-001">
                        </div>
                        <div style="text-align: center; margin-top: 1.5rem;">
                            <button type="submit" class="btn btn-success" style="margin-right: 1rem;">Create Work Order</button>
                            <button type="button" class="btn btn-secondary" onclick="document.getElementById('chatterfix-modal').remove()">Cancel</button>
                        </div>
                    </form>
                `;
            case 'assets':
                return `
                    <form onsubmit="ChatterFix.submitCreateForm(event, 'assets')">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Asset Name:</label>
                            <input type="text" name="name" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Asset ID:</label>
                            <input type="text" name="id" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;" placeholder="ASSET-001">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Location:</label>
                            <input type="text" name="location" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Status:</label>
                            <select name="status" style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                                <option value="operational" selected>Operational</option>
                                <option value="maintenance_due">Maintenance Due</option>
                                <option value="down">Down</option>
                            </select>
                        </div>
                        <div style="text-align: center; margin-top: 1.5rem;">
                            <button type="submit" class="btn btn-success" style="margin-right: 1rem;">Create Asset</button>
                            <button type="button" class="btn btn-secondary" onclick="document.getElementById('chatterfix-modal').remove()">Cancel</button>
                        </div>
                    </form>
                `;
            case 'parts':
                return `
                    <form onsubmit="ChatterFix.submitCreateForm(event, 'parts')">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Part Number:</label>
                            <input type="text" name="part_number" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Description:</label>
                            <input type="text" name="description" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Unit Cost:</label>
                            <input type="number" name="unit_cost" step="0.01" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Quantity on Hand:</label>
                            <input type="number" name="quantity_on_hand" required style="width: 100%; padding: 0.75rem; border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; background: rgba(255,255,255,0.1); color: white;">
                        </div>
                        <div style="text-align: center; margin-top: 1.5rem;">
                            <button type="submit" class="btn btn-success" style="margin-right: 1rem;">Create Part</button>
                            <button type="button" class="btn btn-secondary" onclick="document.getElementById('chatterfix-modal').remove()">Cancel</button>
                        </div>
                    </form>
                `;
            default:
                return `
                    <div style="text-align: center; padding: 2rem;">
                        <h4>✨ Create New ${moduleType}</h4>
                        <p style="margin: 1rem 0; opacity: 0.8;">Create functionality for ${moduleType} is coming soon!</p>
                        <button type="button" class="btn btn-primary" onclick="document.getElementById('chatterfix-modal').remove()">Close</button>
                    </div>
                `;
        }
    }

    normalizeModuleName(moduleType) {
        // Convert display names to API endpoint names
        const mapping = {
            'Work Orders Management': 'workorders',
            'Assets Management': 'assets', 
            'Parts Inventory Management': 'parts',
            'AI Command Center': 'ai',
            'Preventive Maintenance': 'preventive',
            'Administration Dashboard': 'admin'
        };
        return mapping[moduleType] || moduleType.toLowerCase().replace(/\s+/g, '');
    }

    getEditForm(itemId, moduleType) {
        return `<p>Edit form for ${moduleType} item ${itemId} not yet implemented.</p>`;
    }

    async submitCreateForm(event, moduleType) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const data = Object.fromEntries(formData.entries());
        
        try {
            const response = await fetch(`/cmms/${moduleType}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            if (response.ok) {
                this.showNotification(`${moduleType.slice(0, -1)} created successfully!`, 'success');
                document.getElementById('chatterfix-modal').remove();
                setTimeout(() => window.location.reload(), 1500);
            } else {
                const error = await response.text();
                this.showNotification(`Error creating ${moduleType.slice(0, -1)}: ${error}`, 'error');
            }
        } catch (error) {
            this.showNotification(`Network error: ${error.message}`, 'error');
        }
    }

    // ==================== UTILITY FUNCTIONS ====================
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    formatDate(date) {
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        }).format(new Date(date));
    }

    // ==================== MODULE-SPECIFIC HELPERS ====================
    async createWorkOrder(data) {
        try {
            const response = await fetch(`${this.apiBase}/workorders`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            if (response.ok) {
                const workOrder = await response.json();
                this.showNotification(`Work Order ${workOrder.id} created successfully!`, 'success');
                return workOrder;
            } else {
                throw new Error('Failed to create work order');
            }
        } catch (error) {
            this.showNotification('Failed to create work order', 'danger');
            throw error;
        }
    }

    showItemDetails(itemId, itemType) {
        // Navigate to detail view
        window.location.href = `${this.apiBase}/${itemType}/${itemId}`;
    }

    updateStatusBadge(itemId, newStatus) {
        const badge = document.querySelector(`[data-item-id="${itemId}"] .status-badge`);
        if (badge) {
            badge.className = `status-badge status-${newStatus.toLowerCase().replace(/\s+/g, '-')}`;
            badge.textContent = newStatus;
        }
    }

    async refreshModuleData(module) {
        if (this.getCurrentModule() === module) {
            window.location.reload();
        }
    }

    adjustMobileLayout() {
        const grids = document.querySelectorAll('.chatterfix-grid');
        grids.forEach(grid => {
            if (window.innerWidth <= 768) {
                grid.style.gridTemplateColumns = '1fr';
            } else {
                grid.style.gridTemplateColumns = '';
            }
        });
    }

    recalculateGrids() {
        // Trigger CSS grid recalculation
        const grids = document.querySelectorAll('.chatterfix-grid');
        grids.forEach(grid => {
            grid.style.display = 'none';
            grid.offsetHeight; // Trigger reflow
            grid.style.display = 'grid';
        });
    }
}

// Initialize the app when DOM is ready
const chatterFixApp = new ChatterFixApp();

// Export for global access
window.ChatterFix = chatterFixApp;

// Add styles for animations not in CSS
const additionalStyles = `
    <style>
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .notification-container .notification {
        animation: slideInRight 0.3s ease-out;
    }
    
    .typing-dots {
        display: inline-block;
        margin-left: 10px;
    }
    
    .typing-dots span {
        display: inline-block;
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: currentColor;
        margin: 0 1px;
        animation: typing 1.4s infinite ease-in-out;
    }
    
    .typing-dots span:nth-child(1) { animation-delay: -0.32s; }
    .typing-dots span:nth-child(2) { animation-delay: -0.16s; }
    
    @keyframes typing {
        0%, 80%, 100% { transform: scale(0); opacity: 0.5; }
        40% { transform: scale(1); opacity: 1; }
    }
    
    .mobile-device .chatterfix-card:hover {
        transform: none;
    }
    
    .mobile-show {
        display: flex !important;
        flex-direction: column;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: var(--glass-bg);
        backdrop-filter: blur(var(--glass-blur));
        border: 1px solid var(--glass-border);
        padding: 1rem;
    }
    </style>
`;

document.head.insertAdjacentHTML('beforeend', additionalStyles);