/**
 * ChatterFix CMMS - Unified JavaScript Framework
 * Rich interactivity for all modules matching Parts dashboard features
 */

class ChatterFixUI {
    constructor() {
        this.initializeEventListeners();
        this.initializeAIFeatures();
        this.initializeRichComponents();
    }

    // Initialize all event listeners
    initializeEventListeners() {
        document.addEventListener('DOMContentLoaded', () => {
            this.setupSearch();
            this.setupFilters();
            this.setupExport();
            this.setupAlerts();
            this.setupTables();
            this.setupCards();
            this.setupVoiceInput();
        });
    }

    // Search functionality (like Parts dashboard)
    setupSearch() {
        const searchInputs = document.querySelectorAll('.search-input, input[placeholder*="Search"]');
        
        searchInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                const term = e.target.value.toLowerCase();
                const containers = [
                    '.chatterfix-card', 
                    '.part-card', 
                    '.asset-card', 
                    '.wo-card',
                    'tr'
                ];
                
                containers.forEach(selector => {
                    document.querySelectorAll(selector).forEach(element => {
                        const text = element.textContent.toLowerCase();
                        element.style.display = text.includes(term) ? '' : 'none';
                    });
                });
            });
        });
    }

    // Filter system for all modules
    setupFilters() {
        const filterSelects = document.querySelectorAll('select[id*="Filter"]');
        
        filterSelects.forEach(select => {
            select.addEventListener('change', (e) => {
                this.applyFilters();
            });
        });
    }

    applyFilters() {
        const cards = document.querySelectorAll('.chatterfix-card, .part-card, .asset-card, .wo-card');
        const statusFilter = document.getElementById('statusFilter')?.value;
        const categoryFilter = document.getElementById('categoryFilter')?.value;
        const priorityFilter = document.getElementById('priorityFilter')?.value;
        const supplierFilter = document.getElementById('supplierFilter')?.value;

        cards.forEach(card => {
            let show = true;
            
            if (statusFilter && !card.dataset.status?.includes(statusFilter) && 
                !card.querySelector('.status-badge')?.textContent.toLowerCase().includes(statusFilter.toLowerCase())) {
                show = false;
            }
            
            if (categoryFilter && !card.dataset.category?.includes(categoryFilter)) {
                show = false;
            }
            
            if (priorityFilter && !card.dataset.priority?.includes(priorityFilter)) {
                show = false;
            }
            
            if (supplierFilter && !card.dataset.supplier?.includes(supplierFilter)) {
                show = false;
            }
            
            card.style.display = show ? '' : 'none';
        });
    }

    // CSV Export functionality
    setupExport() {
        const exportButtons = document.querySelectorAll('.export-btn, .chatterfix-btn[onclick*="export"]');
        
        exportButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.exportData(button.dataset.type || 'csv');
            });
        });
    }

    async exportData(type = 'csv') {
        try {
            const currentPath = window.location.pathname;
            const exportPath = currentPath.replace('/dashboard', `/export/${type}`);
            
            const response = await fetch(exportPath, {
                method: 'GET',
                headers: {
                    'Accept': 'text/csv,application/json'
                }
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `chatterfix-data-${Date.now()}.${type}`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.showAlert('Data exported successfully!', 'success');
            } else {
                this.showAlert('Export failed. Please try again.', 'danger');
            }
        } catch (error) {
            console.error('Export error:', error);
            this.showAlert('Export error occurred.', 'danger');
        }
    }

    // Alert system
    setupAlerts() {
        const alerts = document.querySelectorAll('.chatterfix-alert, .alert');
        
        alerts.forEach(alert => {
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            }, 5000);
            
            // Click to dismiss
            alert.addEventListener('click', () => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            });
        });
    }

    showAlert(message, type = 'success') {
        const alertContainer = document.querySelector('.alert-container') || document.body;
        const alert = document.createElement('div');
        alert.className = `chatterfix-alert chatterfix-alert-${type}`;
        alert.innerHTML = `
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}:</strong> ${message}
            <button style="float: right; background: none; border: none; color: inherit; font-size: 1.2rem; cursor: pointer;">&times;</button>
        `;
        
        alertContainer.appendChild(alert);
        
        // Auto-dismiss
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
        
        // Click to dismiss
        alert.addEventListener('click', () => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        });
    }

    // Enhanced table features
    setupTables() {
        const tables = document.querySelectorAll('.chatterfix-table, .table');
        
        tables.forEach(table => {
            // Sort functionality
            const headers = table.querySelectorAll('th');
            headers.forEach((header, index) => {
                header.style.cursor = 'pointer';
                header.addEventListener('click', () => {
                    this.sortTable(table, index);
                });
            });
            
            // Row highlighting
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                row.addEventListener('mouseenter', () => {
                    row.style.backgroundColor = 'rgba(56, 239, 125, 0.1)';
                });
                
                row.addEventListener('mouseleave', () => {
                    row.style.backgroundColor = '';
                });
            });
        });
    }

    sortTable(table, column) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        
        rows.sort((a, b) => {
            const aText = a.cells[column].textContent.trim();
            const bText = b.cells[column].textContent.trim();
            
            // Try numeric sort first
            const aNum = parseFloat(aText);
            const bNum = parseFloat(bText);
            
            if (!isNaN(aNum) && !isNaN(bNum)) {
                return aNum - bNum;
            }
            
            // Fallback to text sort
            return aText.localeCompare(bText);
        });
        
        rows.forEach(row => tbody.appendChild(row));
    }

    // Enhanced card interactions
    setupCards() {
        const cards = document.querySelectorAll('.chatterfix-card, .part-card, .asset-card, .wo-card');
        
        cards.forEach(card => {
            // Click to expand/focus
            card.addEventListener('click', (e) => {
                if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
                    return; // Don't interfere with button clicks
                }
                
                card.classList.toggle('expanded');
                
                // Show additional details if available
                const details = card.querySelector('.details, .additional-info');
                if (details) {
                    details.style.display = card.classList.contains('expanded') ? 'block' : 'none';
                }
            });
        });
    }

    // Voice input for AI features
    setupVoiceInput() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const voiceButtons = document.querySelectorAll('.voice-input-btn');
            
            voiceButtons.forEach(button => {
                button.addEventListener('click', () => {
                    this.startVoiceRecognition(button);
                });
            });
        }
    }

    startVoiceRecognition(button) {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        const targetInput = button.dataset.target ? 
            document.getElementById(button.dataset.target) : 
            button.parentElement.querySelector('input, textarea');

        recognition.start();
        
        button.textContent = '🎤 Listening...';
        button.disabled = true;

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            if (targetInput) {
                targetInput.value = transcript;
                targetInput.dispatchEvent(new Event('input', { bubbles: true }));
            }
        };

        recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.showAlert('Voice recognition error. Please try again.', 'warning');
        };

        recognition.onend = () => {
            button.textContent = '🎤';
            button.disabled = false;
        };
    }

    // AI Features Integration
    initializeAIFeatures() {
        this.setupAIChat();
        this.setupSmartSuggestions();
        this.setupPredictiveAlerts();
    }

    setupAIChat() {
        const aiInputs = document.querySelectorAll('.ai-input, input[placeholder*="AI"]');
        
        aiInputs.forEach(input => {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendAIMessage(input.value, input);
                    input.value = '';
                }
            });
        });

        const aiButtons = document.querySelectorAll('.ai-send-btn');
        aiButtons.forEach(button => {
            button.addEventListener('click', () => {
                const input = button.parentElement.querySelector('.ai-input');
                if (input && input.value.trim()) {
                    this.sendAIMessage(input.value, input);
                    input.value = '';
                }
            });
        });
    }

    async sendAIMessage(message, inputElement) {
        try {
            const responseContainer = inputElement.parentElement.querySelector('.ai-response') || 
                                    this.createAIResponseContainer(inputElement);
            
            // Show loading state
            responseContainer.innerHTML = '<div class="loading">AI is thinking...</div>';
            
            const response = await fetch('/api/ai/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    context: window.location.pathname
                })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                responseContainer.innerHTML = `
                    <div class="ai-message">
                        <strong>AI:</strong> ${data.response}
                        ${data.confidence ? `<span class="confidence">Confidence: ${Math.round(data.confidence * 100)}%</span>` : ''}
                        ${data.actions ? this.renderAIActions(data.actions) : ''}
                    </div>
                `;
            } else {
                responseContainer.innerHTML = `<div class="ai-error">AI Error: ${data.error || 'Unknown error'}</div>`;
            }
        } catch (error) {
            console.error('AI chat error:', error);
            this.showAlert('AI communication failed. Please try again.', 'danger');
        }
    }

    createAIResponseContainer(inputElement) {
        const container = document.createElement('div');
        container.className = 'ai-response';
        inputElement.parentElement.appendChild(container);
        return container;
    }

    renderAIActions(actions) {
        return `
            <div class="ai-actions">
                ${actions.map(action => `
                    <button class="chatterfix-btn chatterfix-btn-sm" onclick="chatterFixUI.executeAIAction('${action.type}', ${JSON.stringify(action.params).replace(/"/g, '&quot;')})">
                        ${action.label}
                    </button>
                `).join('')}
            </div>
        `;
    }

    executeAIAction(type, params) {
        switch (type) {
            case 'create_work_order':
                window.location.href = `/cmms/workorders/create?${new URLSearchParams(params)}`;
                break;
            case 'schedule_maintenance':
                window.location.href = `/cmms/preventive/schedule?${new URLSearchParams(params)}`;
                break;
            case 'order_parts':
                window.location.href = `/cmms/parts/order?${new URLSearchParams(params)}`;
                break;
            case 'analyze_quality':
                window.location.href = `/erp/quality/analyze?${new URLSearchParams(params)}`;
                break;
            default:
                this.showAlert(`Executing ${type}...`, 'success');
        }
    }

    // Smart suggestions based on user behavior
    setupSmartSuggestions() {
        // Track user interactions for AI suggestions
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('chatterfix-btn') || e.target.classList.contains('btn')) {
                this.trackAction(e.target.textContent, e.target.getAttribute('onclick') || e.target.dataset.action);
            }
        });
    }

    trackAction(action, context) {
        // Store in localStorage for AI learning
        const actions = JSON.parse(localStorage.getItem('chatterfix-actions') || '[]');
        actions.push({
            action,
            context,
            timestamp: new Date().toISOString(),
            page: window.location.pathname
        });
        
        // Keep only last 100 actions
        if (actions.length > 100) {
            actions.splice(0, actions.length - 100);
        }
        
        localStorage.setItem('chatterfix-actions', JSON.stringify(actions));
    }

    // Predictive alerts and insights
    setupPredictiveAlerts() {
        // Check for potential issues every 30 seconds
        setInterval(() => {
            this.checkPredictiveAlerts();
        }, 30000);
    }

    checkPredictiveAlerts() {
        // Look for patterns that might need attention
        const cards = document.querySelectorAll('.chatterfix-card, .part-card, .asset-card');
        
        cards.forEach(card => {
            const statusElement = card.querySelector('.status-badge, [class*="status-"]');
            const status = statusElement?.textContent.toLowerCase();
            
            // Predictive maintenance alerts
            if (status?.includes('maintenance') || status?.includes('low') || status?.includes('warning')) {
                this.addPredictiveInsight(card);
            }
        });
    }

    addPredictiveInsight(card) {
        if (card.querySelector('.ai-insight')) return; // Already has insight
        
        const insight = document.createElement('div');
        insight.className = 'ai-insight';
        insight.innerHTML = `
            <div style="background: rgba(52, 152, 219, 0.1); border-left: 3px solid #3498db; padding: 0.5rem; margin-top: 1rem; border-radius: 4px;">
                <small><strong>🤖 AI Insight:</strong> Based on patterns, consider scheduling maintenance within 7 days.</small>
            </div>
        `;
        
        card.appendChild(insight);
    }

    // Rich component features
    initializeRichComponents() {
        this.setupRealtimeUpdates();
        this.setupKeyboardShortcuts();
        this.setupProgressBars();
    }

    setupRealtimeUpdates() {
        // Update timestamps and status indicators
        setInterval(() => {
            this.updateTimestamps();
            this.updateStatusIndicators();
        }, 60000); // Every minute
    }

    updateTimestamps() {
        const timestamps = document.querySelectorAll('[data-timestamp]');
        timestamps.forEach(el => {
            const timestamp = new Date(el.dataset.timestamp);
            el.textContent = this.formatRelativeTime(timestamp);
        });
    }

    formatRelativeTime(date) {
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        
        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
        return `${Math.floor(diffMins / 1440)}d ago`;
    }

    updateStatusIndicators() {
        // Simulate real-time status updates (in production, this would come from WebSocket/SSE)
        const indicators = document.querySelectorAll('.status-badge');
        indicators.forEach(indicator => {
            // Add pulse animation for critical statuses
            if (indicator.textContent.toLowerCase().includes('critical') || 
                indicator.textContent.toLowerCase().includes('urgent')) {
                indicator.classList.add('pulse-animation');
            }
        });
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Global shortcuts
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 'k':
                        e.preventDefault();
                        this.focusSearch();
                        break;
                    case 'n':
                        e.preventDefault();
                        this.createNew();
                        break;
                    case 'e':
                        e.preventDefault();
                        this.exportData();
                        break;
                }
            }
        });
    }

    focusSearch() {
        const searchInput = document.querySelector('.search-input, input[placeholder*="Search"]');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }

    createNew() {
        const createButton = document.querySelector('.chatterfix-btn[onclick*="create"], .chatterfix-btn[onclick*="add"]');
        if (createButton) {
            createButton.click();
        }
    }

    setupProgressBars() {
        const progressBars = document.querySelectorAll('[data-progress]');
        progressBars.forEach(bar => {
            const progress = parseInt(bar.dataset.progress);
            bar.style.background = `linear-gradient(to right, #38ef7d ${progress}%, rgba(255,255,255,0.1) ${progress}%)`;
        });
    }
}

// Initialize the ChatterFix UI when the page loads
const chatterFixUI = new ChatterFixUI();

// Global utility functions
window.chatterFixUI = chatterFixUI;

// Auto-refresh data every 5 minutes
setInterval(() => {
    if (document.querySelector('.auto-refresh')) {
        location.reload();
    }
}, 300000);