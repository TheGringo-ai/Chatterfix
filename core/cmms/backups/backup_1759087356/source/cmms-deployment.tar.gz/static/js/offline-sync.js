/**
 * ChatterFix Offline Sync Manager
 * Handles offline form submissions and data synchronization
 */

class OfflineSyncManager {
    constructor() {
        this.dbName = 'ChatterFixDB';
        this.dbVersion = 1;
        this.db = null;
        this.syncInProgress = false;
        this.syncQueue = [];
        
        this.init();
        this.setupServiceWorkerMessages();
        this.setupConnectionMonitoring();
        this.startPeriodicSync();
    }
    
    async init() {
        await this.initIndexedDB();
        await this.loadPendingSubmissions();
        this.updateSyncStatus();
    }
    
    /**
     * Initialize IndexedDB for offline storage
     */
    initIndexedDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve();
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create object stores
                if (!db.objectStoreNames.contains('offlineSubmissions')) {
                    const store = db.createObjectStore('offlineSubmissions', { keyPath: 'id' });
                    store.createIndex('timestamp', 'timestamp', { unique: false });
                    store.createIndex('url', 'url', { unique: false });
                }
                
                if (!db.objectStoreNames.contains('cachedData')) {
                    const cacheStore = db.createObjectStore('cachedData', { keyPath: 'key' });
                    cacheStore.createIndex('timestamp', 'timestamp', { unique: false });
                }
            };
        });
    }
    
    /**
     * Store offline form submission
     */
    async storeOfflineSubmission(submission) {
        if (!this.db) {
            console.error('❌ ChatterFix Sync: Database not initialized');
            return false;
        }
        
        try {
            const transaction = this.db.transaction(['offlineSubmissions'], 'readwrite');
            const store = transaction.objectStore('offlineSubmissions');
            
            await store.add(submission);
            
            this.syncQueue.push(submission);
            this.updateSyncStatus();
            
            console.log('📱 ChatterFix Sync: Stored offline submission:', submission.id);
            
            // Show user feedback
            this.showOfflineToast(submission);
            
            return true;
        } catch (error) {
            console.error('❌ ChatterFix Sync: Failed to store submission:', error);
            return false;
        }
    }
    
    /**
     * Load pending submissions from IndexedDB
     */
    async loadPendingSubmissions() {
        if (!this.db) return;
        
        try {
            const transaction = this.db.transaction(['offlineSubmissions'], 'readonly');
            const store = transaction.objectStore('offlineSubmissions');
            const request = store.getAll();
            
            return new Promise((resolve) => {
                request.onsuccess = () => {
                    this.syncQueue = request.result;
                    console.log(`📦 ChatterFix Sync: Loaded ${this.syncQueue.length} pending submissions`);
                    resolve();
                };
            });
        } catch (error) {
            console.error('❌ ChatterFix Sync: Failed to load pending submissions:', error);
        }
    }
    
    /**
     * Sync pending submissions when online
     */
    async syncPendingSubmissions() {
        if (this.syncInProgress || !navigator.onLine || this.syncQueue.length === 0) {
            return;
        }
        
        console.log(`🔄 ChatterFix Sync: Starting sync of ${this.syncQueue.length} submissions`);
        this.syncInProgress = true;
        this.updateSyncStatus();
        
        const successfulSyncs = [];
        const failedSyncs = [];
        
        for (const submission of this.syncQueue) {
            try {
                const success = await this.syncSingleSubmission(submission);
                if (success) {
                    successfulSyncs.push(submission);
                } else {
                    failedSyncs.push(submission);
                }
            } catch (error) {
                console.error('❌ ChatterFix Sync: Submission failed:', submission.id, error);
                failedSyncs.push(submission);
            }
        }
        
        // Remove successful syncs from queue and IndexedDB
        if (successfulSyncs.length > 0) {
            await this.removeSuccessfulSubmissions(successfulSyncs);
            this.syncQueue = this.syncQueue.filter(
                sub => !successfulSyncs.some(success => success.id === sub.id)
            );
        }
        
        this.syncInProgress = false;
        this.updateSyncStatus();
        
        console.log(`✅ ChatterFix Sync: Completed. ${successfulSyncs.length} synced, ${failedSyncs.length} failed`);
        
        if (successfulSyncs.length > 0) {
            this.showSyncSuccessToast(successfulSyncs.length);
        }
    }
    
    /**
     * Sync individual submission to server
     */
    async syncSingleSubmission(submission) {
        try {
            const formData = new FormData();
            Object.keys(submission.data).forEach(key => {
                formData.append(key, submission.data[key]);
            });
            
            // Add metadata to indicate this is a synced offline submission
            formData.append('_offline_sync', 'true');
            formData.append('_offline_timestamp', submission.timestamp);
            
            const response = await fetch(submission.url, {
                method: submission.method,
                body: formData,
                headers: {
                    // Don't include Content-Type for FormData
                    ...submission.headers,
                    'X-Offline-Sync': 'true'
                }
            });
            
            if (response.ok) {
                console.log('✅ ChatterFix Sync: Successfully synced:', submission.id);
                return true;
            } else {
                console.error('❌ ChatterFix Sync: Server error for:', submission.id, response.status);
                return false;
            }
        } catch (error) {
            console.error('❌ ChatterFix Sync: Network error for:', submission.id, error);
            return false;
        }
    }
    
    /**
     * Remove successfully synced submissions from IndexedDB
     */
    async removeSuccessfulSubmissions(submissions) {
        if (!this.db) return;
        
        try {
            const transaction = this.db.transaction(['offlineSubmissions'], 'readwrite');
            const store = transaction.objectStore('offlineSubmissions');
            
            for (const submission of submissions) {
                await store.delete(submission.id);
            }
            
            console.log(`🗑️ ChatterFix Sync: Removed ${submissions.length} synced submissions from storage`);
        } catch (error) {
            console.error('❌ ChatterFix Sync: Failed to remove synced submissions:', error);
        }
    }
    
    /**
     * Setup service worker message handling
     */
    setupServiceWorkerMessages() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.addEventListener('message', async (event) => {
                const { type, submission, submissionId } = event.data;
                
                switch (type) {
                    case 'STORE_OFFLINE_SUBMISSION':
                        await this.storeOfflineSubmission(submission);
                        break;
                        
                    case 'SYNC_OFFLINE_SUBMISSIONS':
                        await this.syncPendingSubmissions();
                        break;
                        
                    case 'FORM_SUBMITTED_ONLINE':
                        // Remove any pending offline submission for this form
                        this.syncQueue = this.syncQueue.filter(sub => sub.url !== event.data.url);
                        this.updateSyncStatus();
                        break;
                }
            });
        }
    }
    
    /**
     * Monitor connection status and sync when online
     */
    setupConnectionMonitoring() {
        window.addEventListener('online', () => {
            console.log('🌐 ChatterFix Sync: Connection restored');
            setTimeout(() => this.syncPendingSubmissions(), 1000);
        });
        
        window.addEventListener('offline', () => {
            console.log('📱 ChatterFix Sync: Connection lost - entering offline mode');
            this.updateSyncStatus();
        });
    }
    
    /**
     * Start periodic sync attempts
     */
    startPeriodicSync() {
        setInterval(async () => {
            if (navigator.onLine && this.syncQueue.length > 0) {
                await this.syncPendingSubmissions();
            }
        }, 30000); // Try sync every 30 seconds
    }
    
    /**
     * Update sync status UI
     */
    updateSyncStatus() {
        const statusBar = document.getElementById('syncStatus');
        if (!statusBar) return;
        
        const onlineStatus = statusBar.querySelector('.sync-status.online');
        const syncingStatus = statusBar.querySelector('.sync-status.syncing');
        const offlineStatus = statusBar.querySelector('.sync-status.offline');
        
        // Hide all status indicators first
        [onlineStatus, syncingStatus, offlineStatus].forEach(el => {
            if (el) el.style.display = 'none';
        });
        
        if (this.syncInProgress) {
            if (syncingStatus) {
                syncingStatus.style.display = 'flex';
                syncingStatus.querySelector('span').textContent = `Syncing ${this.syncQueue.length} changes...`;
            }
        } else if (!navigator.onLine) {
            if (offlineStatus) {
                offlineStatus.style.display = 'flex';
                const count = this.syncQueue.length;
                offlineStatus.querySelector('span').textContent = 
                    count > 0 ? `Offline - ${count} changes pending` : 'Offline';
            }
        } else {
            if (onlineStatus) {
                onlineStatus.style.display = 'flex';
                const count = this.syncQueue.length;
                onlineStatus.querySelector('span').textContent = 
                    count === 0 ? 'Online - All changes synced' : `Online - ${count} changes pending`;
            }
        }
    }
    
    /**
     * Show toast notification for offline submission
     */
    showOfflineToast(submission) {
        const toast = document.createElement('div');
        toast.className = 'toast toast-offline';
        toast.innerHTML = `
            <div class="toast-icon">📱</div>
            <div class="toast-content">
                <strong>Saved locally</strong>
                <p>Will sync when online</p>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">×</button>
        `;
        
        document.body.appendChild(toast);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
        
        // Animate in
        setTimeout(() => toast.classList.add('show'), 100);
    }
    
    /**
     * Show success toast for completed sync
     */
    showSyncSuccessToast(count) {
        const toast = document.createElement('div');
        toast.className = 'toast toast-success';
        toast.innerHTML = `
            <div class="toast-icon">✅</div>
            <div class="toast-content">
                <strong>Sync complete</strong>
                <p>${count} change${count > 1 ? 's' : ''} uploaded</p>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">×</button>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 4000);
        
        setTimeout(() => toast.classList.add('show'), 100);
    }
    
    /**
     * Force sync attempt (called from UI)
     */
    async forceSync() {
        if (navigator.onLine) {
            await this.syncPendingSubmissions();
        }
    }
    
    /**
     * Get current sync status for debugging
     */
    getStatus() {
        return {
            online: navigator.onLine,
            syncing: this.syncInProgress,
            pendingCount: this.syncQueue.length,
            queue: this.syncQueue
        };
    }
}

// Initialize offline sync manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.offlineSyncManager = new OfflineSyncManager();
    console.log('🎯 ChatterFix Offline Sync Manager initialized');
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = OfflineSyncManager;
}