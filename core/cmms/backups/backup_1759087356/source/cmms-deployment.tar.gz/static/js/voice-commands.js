/**
 * ChatterFix Voice Command System
 * Enables voice-controlled work order creation and navigation
 */

class VoiceCommandManager {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.voiceOverlay = null;
        this.currentTranscript = '';
        this.commands = new Map();
        
        this.initSpeechRecognition();
        this.initVoiceOverlay();
        this.registerCommands();
        this.setupEventListeners();
    }
    
    /**
     * Initialize Web Speech API
     */
    initSpeechRecognition() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.warn('🎤 Voice commands not supported in this browser');
            this.showUnsupportedMessage();
            return;
        }
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        // Configuration
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';
        this.recognition.maxAlternatives = 1;
        
        // Event handlers
        this.recognition.onstart = () => this.onListeningStart();
        this.recognition.onresult = (event) => this.onSpeechResult(event);
        this.recognition.onerror = (event) => this.onSpeechError(event);
        this.recognition.onend = () => this.onListeningEnd();
        
        console.log('🎤 Voice recognition initialized');
    }
    
    /**
     * Create voice command overlay UI
     */
    initVoiceOverlay() {
        this.voiceOverlay = document.createElement('div');
        this.voiceOverlay.className = 'voice-overlay';
        this.voiceOverlay.innerHTML = `
            <div class="voice-content">
                <div class="voice-animation">
                    <div class="wave wave-1"></div>
                    <div class="wave wave-2"></div>
                    <div class="wave wave-3"></div>
                </div>
                
                <h3 class="voice-title" id="voiceTitle">Listening...</h3>
                <p class="voice-subtitle" id="voiceSubtitle">Try saying "Create work order for pump repair"</p>
                
                <div class="voice-transcript" id="voiceTranscript"></div>
                
                <div class="voice-actions">
                    <button class="btn btn-secondary" onclick="voiceManager.cancelVoiceCommand()">
                        Cancel
                    </button>
                    <button class="btn btn-primary" id="voiceProcessBtn" onclick="voiceManager.processVoiceCommand()" 
                            style="display: none;">
                        <span>✓</span> Process
                    </button>
                </div>
                
                <div class="voice-commands-help">
                    <h4>Voice Commands:</h4>
                    <ul>
                        <li>"Create work order for [description]"</li>
                        <li>"Show me work orders"</li>
                        <li>"Open dashboard"</li>
                        <li>"Search for [asset name]"</li>
                        <li>"Mark work order [number] as complete"</li>
                    </ul>
                </div>
            </div>
        `;
        
        document.body.appendChild(this.voiceOverlay);
    }
    
    /**
     * Register voice command patterns
     */
    registerCommands() {
        // Work order creation
        this.commands.set(/create work order for (.+)/i, (match) => ({
            action: 'create_work_order',
            description: match[1],
            confidence: 0.9
        }));
        
        this.commands.set(/new work order (.+)/i, (match) => ({
            action: 'create_work_order', 
            description: match[1],
            confidence: 0.8
        }));
        
        // Navigation commands
        this.commands.set(/show me work orders|view work orders|open work orders/i, () => ({
            action: 'navigate_work_orders',
            confidence: 0.95
        }));
        
        this.commands.set(/open dashboard|show dashboard|go to dashboard/i, () => ({
            action: 'navigate_dashboard',
            confidence: 0.95
        }));
        
        this.commands.set(/show assets|view assets|open assets/i, () => ({
            action: 'navigate_assets',
            confidence: 0.9
        }));
        
        // Work order status updates
        this.commands.set(/mark work order (\\w+-\\d+) as (complete|finished|done)/i, (match) => ({
            action: 'update_work_order_status',
            workOrderId: match[1],
            status: 'complete',
            confidence: 0.85
        }));
        
        this.commands.set(/update work order (\\w+-\\d+) to (in progress|assigned|open)/i, (match) => ({
            action: 'update_work_order_status',
            workOrderId: match[1],
            status: match[2].replace(' ', '_'),
            confidence: 0.8
        }));
        
        // Search commands
        this.commands.set(/search for (.+)|find (.+)/i, (match) => ({
            action: 'search',
            query: match[1] || match[2],
            confidence: 0.7
        }));
        
        // Asset-specific commands
        this.commands.set(/show me (.+) maintenance history/i, (match) => ({
            action: 'show_asset_history',
            assetName: match[1],
            confidence: 0.8
        }));
    }
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Voice FAB click
        document.addEventListener('click', (event) => {
            if (event.target.classList.contains('voice-fab')) {
                this.startVoiceCommand();
            }
        });
        
        // Keyboard shortcut (Alt+V)
        document.addEventListener('keydown', (event) => {
            if (event.altKey && event.key === 'v') {
                event.preventDefault();
                this.startVoiceCommand();
            }
        });
        
        // Close overlay on outside click
        this.voiceOverlay.addEventListener('click', (event) => {
            if (event.target === this.voiceOverlay) {
                this.cancelVoiceCommand();
            }
        });
    }
    
    /**
     * Start voice command recognition
     */
    startVoiceCommand() {
        if (!this.recognition) {
            this.showUnsupportedMessage();
            return;
        }
        
        if (this.isListening) {
            this.stopListening();
            return;
        }
        
        console.log('🎤 Starting voice command...');
        
        this.showVoiceOverlay();
        this.isListening = true;
        
        try {
            this.recognition.start();
        } catch (error) {
            console.error('❌ Failed to start voice recognition:', error);
            this.onSpeechError({ error: 'not-allowed' });
        }
    }
    
    /**
     * Stop listening
     */
    stopListening() {
        if (this.recognition && this.isListening) {
            this.recognition.stop();
        }
    }
    
    /**
     * Cancel voice command
     */
    cancelVoiceCommand() {
        this.stopListening();
        this.hideVoiceOverlay();
        this.currentTranscript = '';
    }
    
    /**
     * Process the voice command
     */
    processVoiceCommand() {
        if (!this.currentTranscript.trim()) {
            this.showError('No voice input detected');
            return;
        }
        
        console.log('🎤 Processing voice command:', this.currentTranscript);
        
        // Find matching command
        const command = this.parseVoiceCommand(this.currentTranscript);
        
        if (command && command.confidence > 0.6) {
            this.executeCommand(command);
        } else {
            this.showError('Command not recognized. Please try again.');
        }
    }
    
    /**
     * Parse voice input into command
     */
    parseVoiceCommand(transcript) {
        const cleanTranscript = transcript.trim().toLowerCase();
        
        for (const [pattern, handler] of this.commands) {
            const match = cleanTranscript.match(pattern);
            if (match) {
                return handler(match);
            }
        }
        
        return null;
    }
    
    /**
     * Execute recognized command
     */
    async executeCommand(command) {
        console.log('🎤 Executing command:', command);
        
        this.showProcessing();
        
        try {
            switch (command.action) {
                case 'create_work_order':
                    await this.createWorkOrderFromVoice(command);
                    break;
                    
                case 'navigate_work_orders':
                    this.navigateTo('/cmms/workorders/mobile/list');
                    break;
                    
                case 'navigate_dashboard':
                    this.navigateTo('/cmms/dashboard/main');
                    break;
                    
                case 'navigate_assets':
                    this.navigateTo('/cmms/assets/list');
                    break;
                    
                case 'update_work_order_status':
                    await this.updateWorkOrderStatusFromVoice(command);
                    break;
                    
                case 'search':
                    this.performSearch(command.query);
                    break;
                    
                case 'show_asset_history':
                    this.showAssetHistory(command.assetName);
                    break;
                    
                default:
                    this.showError(`Command "${command.action}" not implemented yet`);
            }
        } catch (error) {
            console.error('❌ Command execution failed:', error);
            this.showError('Failed to execute command');
        }
    }
    
    /**
     * Create work order from voice command
     */
    async createWorkOrderFromVoice(command) {
        const workOrderData = {
            title: this.extractWorkOrderTitle(command.description),
            description: command.description,
            priority: this.extractPriority(command.description),
            voice_created: true
        };
        
        console.log('🎤 Creating work order from voice:', workOrderData);
        
        // Simulate work order creation
        setTimeout(() => {
            this.showSuccess(`Work order created: "${workOrderData.title}"`);
            
            // Navigate to work orders list after creation
            setTimeout(() => {
                this.navigateTo('/cmms/workorders/mobile/list');
            }, 2000);
        }, 1000);
    }
    
    /**
     * Update work order status from voice
     */
    async updateWorkOrderStatusFromVoice(command) {
        console.log('🎤 Updating work order status:', command);
        
        // Simulate status update
        setTimeout(() => {
            this.showSuccess(`Work order ${command.workOrderId} marked as ${command.status}`);
        }, 1000);
    }
    
    /**
     * Extract work order title from description
     */
    extractWorkOrderTitle(description) {
        // Simple title extraction - first few words
        const words = description.split(' ');
        return words.slice(0, 6).join(' ');
    }
    
    /**
     * Extract priority from description
     */
    extractPriority(description) {
        const desc = description.toLowerCase();
        if (desc.includes('urgent') || desc.includes('emergency') || desc.includes('critical')) {
            return 'critical';
        } else if (desc.includes('high') || desc.includes('important')) {
            return 'high';
        } else if (desc.includes('low') || desc.includes('whenever')) {
            return 'low';
        }
        return 'medium';
    }
    
    /**
     * Navigate to URL
     */
    navigateTo(url) {
        this.showSuccess(`Navigating to ${url.split('/').pop()}`);
        setTimeout(() => {
            window.location.href = url;
        }, 1000);
    }
    
    /**
     * Perform search
     */
    performSearch(query) {
        console.log('🎤 Searching for:', query);
        this.showSuccess(`Searching for: "${query}"`);
        
        // Simulate search
        setTimeout(() => {
            alert(`Search results for "${query}" would appear here`);
            this.hideVoiceOverlay();
        }, 2000);
    }
    
    /**
     * Show asset history
     */
    showAssetHistory(assetName) {
        console.log('🎤 Showing asset history for:', assetName);
        this.showSuccess(`Loading history for: "${assetName}"`);
        
        setTimeout(() => {
            alert(`Maintenance history for "${assetName}" would appear here`);
            this.hideVoiceOverlay();
        }, 2000);
    }
    
    // Event handlers
    onListeningStart() {
        console.log('🎤 Voice recognition started');
        const voiceFab = document.querySelector('.voice-fab');
        if (voiceFab) {
            voiceFab.classList.add('listening');
        }
        
        this.updateVoiceUI('listening');
    }
    
    onSpeechResult(event) {
        let transcript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
                transcript += event.results[i][0].transcript;
            } else {
                transcript += event.results[i][0].transcript;
            }
        }
        
        this.currentTranscript = transcript;
        this.updateTranscriptDisplay(transcript);
        
        // Show process button if we have text
        if (transcript.trim()) {
            document.getElementById('voiceProcessBtn').style.display = 'inline-flex';
        }
    }
    
    onSpeechError(event) {
        console.error('🎤 Speech recognition error:', event.error);
        
        let errorMessage = 'Voice recognition failed';
        
        switch (event.error) {
            case 'not-allowed':
                errorMessage = 'Microphone access denied. Please enable microphone permissions.';
                break;
            case 'no-speech':
                errorMessage = 'No speech detected. Please try again.';
                break;
            case 'audio-capture':
                errorMessage = 'No microphone found. Please check your microphone.';
                break;
            case 'network':
                errorMessage = 'Network error. Please check your connection.';
                break;
        }
        
        this.showError(errorMessage);
    }
    
    onListeningEnd() {
        console.log('🎤 Voice recognition ended');
        this.isListening = false;
        
        const voiceFab = document.querySelector('.voice-fab');
        if (voiceFab) {
            voiceFab.classList.remove('listening');
        }
        
        // Auto-process if we have a clear transcript
        if (this.currentTranscript.trim() && this.currentTranscript.split(' ').length > 3) {
            setTimeout(() => {
                this.processVoiceCommand();
            }, 500);
        }
    }
    
    // UI Updates
    showVoiceOverlay() {
        this.voiceOverlay.classList.add('active');
        this.resetVoiceUI();
    }
    
    hideVoiceOverlay() {
        this.voiceOverlay.classList.remove('active');
        this.currentTranscript = '';
    }
    
    resetVoiceUI() {
        document.getElementById('voiceTitle').textContent = 'Listening...';
        document.getElementById('voiceSubtitle').textContent = 'Try saying "Create work order for pump repair"';
        document.getElementById('voiceTranscript').innerHTML = '';
        document.getElementById('voiceProcessBtn').style.display = 'none';
    }
    
    updateVoiceUI(state) {
        const title = document.getElementById('voiceTitle');
        const subtitle = document.getElementById('voiceSubtitle');
        
        switch (state) {
            case 'listening':
                title.textContent = 'Listening...';
                subtitle.textContent = 'Speak now';
                break;
            case 'processing':
                title.textContent = 'Processing...';
                subtitle.textContent = 'Analyzing your command';
                break;
            case 'success':
                title.textContent = 'Success!';
                break;
            case 'error':
                title.textContent = 'Error';
                break;
        }
    }
    
    updateTranscriptDisplay(transcript) {
        const transcriptEl = document.getElementById('voiceTranscript');
        transcriptEl.innerHTML = `
            <div class="transcript-text">
                <strong>You said:</strong> "${transcript}"
            </div>
        `;
    }
    
    showProcessing() {
        this.updateVoiceUI('processing');
        document.getElementById('voiceTranscript').innerHTML = `
            <div class="processing">
                <div class="spinner"></div>
                <p>Processing your command...</p>
            </div>
        `;
    }
    
    showSuccess(message) {
        this.updateVoiceUI('success');
        document.getElementById('voiceTranscript').innerHTML = `
            <div class="success">
                <div class="success-icon">✅</div>
                <p>${message}</p>
            </div>
        `;
        
        setTimeout(() => {
            this.hideVoiceOverlay();
        }, 3000);
    }
    
    showError(message) {
        this.updateVoiceUI('error');
        document.getElementById('voiceTranscript').innerHTML = `
            <div class="error">
                <div class="error-icon">❌</div>
                <p>${message}</p>
            </div>
        `;
        
        setTimeout(() => {
            this.hideVoiceOverlay();
        }, 4000);
    }
    
    showUnsupportedMessage() {
        alert('🎤 Voice commands are not supported in this browser. Please use Chrome, Edge, or Safari for voice features.');
    }
}

// Initialize voice command manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.voiceManager = new VoiceCommandManager();
    console.log('🎤 Voice Command Manager initialized');
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VoiceCommandManager;
}