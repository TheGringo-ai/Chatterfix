/**
 * Voice Controller for ChatterFix CMMS
 * Implements hands-free voice operations with Web Speech API
 */

class VoiceController {
    constructor() {
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.isListening = false;
        this.isEnabled = false;
        this.currentMode = 'idle'; // idle, listening, processing, feedback
        this.hotkeys = ['hey cmms', 'chatter fix', 'maintenance system'];
        this.confidenceThreshold = 0.7;
        this.maxRetries = 3;
        this.currentRetries = 0;
        
        // Voice command intents and patterns
        this.intentPatterns = {
            create_work_order: [
                /create (work order|wo) for (.+)/i,
                /new (work order|wo) (.+)/i,
                /add maintenance for (.+)/i
            ],
            list_assets: [
                /list (critical|all|high priority) assets/i,
                /show me (critical|important) equipment/i,
                /what assets need attention/i
            ],
            reorder_parts: [
                /what parts need reordering/i,
                /check inventory levels/i,
                /show low stock items/i
            ],
            generate_report: [
                /generate (.+) report/i,
                /create report for (.+)/i,
                /show me (.+) analytics/i
            ],
            search_asset: [
                /find asset (.+)/i,
                /search for (.+)/i,
                /show me (.+)/i
            ],
            help: [
                /help/i,
                /what can you do/i,
                /available commands/i
            ]
        };
        
        this.init();
    }
    
    init() {
        this.checkSupport();
        this.setupRecognition();
        this.createUI();
        this.bindEvents();
        console.log('🎤 Voice Controller initialized');
    }
    
    checkSupport() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.warn('❌ Speech Recognition not supported');
            this.showNotification('Voice recognition not supported in this browser', 'warning');
            return false;
        }
        
        if (!('speechSynthesis' in window)) {
            console.warn('❌ Speech Synthesis not supported');
            this.showNotification('Text-to-speech not supported in this browser', 'warning');
        }
        
        this.isEnabled = true;
        return true;
    }
    
    setupRecognition() {
        if (!this.isEnabled) return;
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        // Configuration for optimal accuracy
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'en-US';
        this.recognition.maxAlternatives = 3;
        
        // Event handlers
        this.recognition.onstart = () => {
            this.isListening = true;
            this.currentMode = 'listening';
            this.updateUI();
            console.log('🎤 Voice recognition started');
        };
        
        this.recognition.onend = () => {
            this.isListening = false;
            this.currentMode = 'idle';
            this.updateUI();
            console.log('🎤 Voice recognition ended');
        };
        
        this.recognition.onresult = (event) => {
            this.handleSpeechResult(event);
        };
        
        this.recognition.onerror = (event) => {
            this.handleSpeechError(event);
        };
        
        this.recognition.onnomatch = () => {
            this.speak('I didn\'t understand that command. Please try again.');
            this.currentRetries++;
            if (this.currentRetries < this.maxRetries) {
                setTimeout(() => this.startListening(), 1000);
            }
        };
    }
    
    createUI() {
        // Create voice control panel
        const voicePanel = document.createElement('div');
        voicePanel.id = 'voice-control-panel';
        voicePanel.className = 'voice-panel';
        voicePanel.innerHTML = `
            <div class="voice-header">
                <h3>🎤 Voice Assistant</h3>
                <button id="voice-settings" class="btn-icon">⚙️</button>
            </div>
            <div class="voice-status">
                <div id="voice-indicator" class="voice-indicator idle">
                    <div class="voice-pulse"></div>
                </div>
                <div id="voice-status-text">Ready</div>
            </div>
            <div class="voice-controls">
                <button id="mic-button" class="btn-primary mic-btn" disabled>
                    <span class="mic-icon">🎤</span>
                    <span class="mic-text">Press to Talk</span>
                </button>
                <button id="hotkey-toggle" class="btn-secondary">
                    Hotwords: <span id="hotkey-status">OFF</span>
                </button>
            </div>
            <div class="voice-feedback">
                <div id="voice-transcript"></div>
                <div id="voice-response"></div>
            </div>
            <div class="voice-help collapsed" id="voice-help">
                <h4>Voice Commands:</h4>
                <ul>
                    <li>"Create work order for PUMP-001 high priority"</li>
                    <li>"List critical assets"</li>
                    <li>"What parts need reordering?"</li>
                    <li>"Generate maintenance report"</li>
                    <li>"Search for MOTOR-045"</li>
                    <li>"Help" - Show all commands</li>
                </ul>
            </div>
        `;
        
        // Add to page
        document.body.appendChild(voicePanel);
        
        // Add floating mic button for mobile/AR
        const floatingMic = document.createElement('button');
        floatingMic.id = 'floating-mic';
        floatingMic.className = 'floating-mic';
        floatingMic.innerHTML = '🎤';
        floatingMic.title = 'Voice Command (Press and hold)';
        document.body.appendChild(floatingMic);
        
        // Enable controls when recognition is ready
        if (this.isEnabled) {
            document.getElementById('mic-button').disabled = false;
        }
    }
    
    bindEvents() {
        // Mic button events
        const micButton = document.getElementById('mic-button');
        const floatingMic = document.getElementById('floating-mic');
        
        // Mouse events
        micButton.addEventListener('mousedown', () => this.startListening());
        micButton.addEventListener('mouseup', () => this.stopListening());
        floatingMic.addEventListener('mousedown', () => this.startListening());
        floatingMic.addEventListener('mouseup', () => this.stopListening());
        
        // Touch events for mobile
        micButton.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.startListening();
        });
        micButton.addEventListener('touchend', (e) => {
            e.preventDefault();
            this.stopListening();
        });
        
        floatingMic.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.startListening();
        });
        floatingMic.addEventListener('touchend', (e) => {
            e.preventDefault();
            this.stopListening();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Space bar for voice (when not in input field)
            if (e.code === 'Space' && !this.isInputFocused() && !e.repeat) {
                e.preventDefault();
                this.startListening();
            }
            
            // Ctrl+Shift+V for voice
            if (e.ctrlKey && e.shiftKey && e.code === 'KeyV') {
                e.preventDefault();
                this.toggleListening();
            }
        });
        
        document.addEventListener('keyup', (e) => {
            if (e.code === 'Space' && !this.isInputFocused()) {
                e.preventDefault();
                this.stopListening();
            }
        });
        
        // Settings and help
        document.getElementById('voice-settings').addEventListener('click', () => {
            this.showSettings();
        });
        
        document.getElementById('hotkey-toggle').addEventListener('click', () => {
            this.toggleHotkeys();
        });
        
        // Click voice panel header to toggle help
        document.querySelector('.voice-header h3').addEventListener('click', () => {
            document.getElementById('voice-help').classList.toggle('collapsed');
        });
    }
    
    isInputFocused() {
        const activeElement = document.activeElement;
        return activeElement && (
            activeElement.tagName === 'INPUT' ||
            activeElement.tagName === 'TEXTAREA' ||
            activeElement.contentEditable === 'true'
        );
    }
    
    startListening() {
        if (!this.isEnabled || this.isListening) return;
        
        this.currentRetries = 0;
        this.recognition.start();
    }
    
    stopListening() {
        if (!this.isListening) return;
        this.recognition.stop();
    }
    
    toggleListening() {
        if (this.isListening) {
            this.stopListening();
        } else {
            this.startListening();
        }
    }
    
    handleSpeechResult(event) {
        const results = event.results;
        let bestResult = null;
        let highestConfidence = 0;
        
        // Find result with highest confidence
        for (let i = 0; i < results.length; i++) {
            for (let j = 0; j < results[i].length; j++) {
                const result = results[i][j];
                if (result.confidence > highestConfidence) {
                    highestConfidence = result.confidence;
                    bestResult = result;
                }
            }
        }
        
        if (bestResult && highestConfidence >= this.confidenceThreshold) {
            this.processCommand(bestResult.transcript, highestConfidence);
        } else {
            this.speak('I didn\'t catch that clearly. Please try again.');
            this.showNotification('Low confidence speech recognition', 'warning');
        }
    }
    
    handleSpeechError(event) {
        console.error('Speech recognition error:', event.error);
        this.currentMode = 'idle';
        this.updateUI();
        
        let message = 'Voice recognition error: ';
        switch(event.error) {
            case 'no-speech':
                message += 'No speech detected. Please try again.';
                break;
            case 'audio-capture':
                message += 'Microphone not accessible.';
                break;
            case 'not-allowed':
                message += 'Microphone permission denied.';
                break;
            case 'network':
                message += 'Network error occurred.';
                break;
            default:
                message += event.error;
        }
        
        this.showNotification(message, 'error');
    }
    
    async processCommand(transcript, confidence) {
        this.currentMode = 'processing';
        this.updateUI();
        
        // Update UI with transcript
        document.getElementById('voice-transcript').textContent = transcript;
        
        console.log(`🗣️ Processing: "${transcript}" (confidence: ${confidence})`);
        
        try {
            // Match intent
            const intent = this.matchIntent(transcript);
            
            if (!intent) {
                this.speak('I don\'t understand that command. Say "help" for available commands.');
                return;
            }
            
            // Send to voice command processor
            const response = await this.sendVoiceCommand(transcript, intent);
            
            if (response && response.success) {
                this.handleCommandSuccess(response);
            } else {
                this.handleCommandError(response);
            }
            
        } catch (error) {
            console.error('Command processing error:', error);
            this.speak('Sorry, there was an error processing your command.');
            this.showNotification('Command processing failed', 'error');
        } finally {
            this.currentMode = 'idle';
            this.updateUI();
        }
    }
    
    matchIntent(transcript) {
        const text = transcript.toLowerCase();
        
        for (const [intent, patterns] of Object.entries(this.intentPatterns)) {
            for (const pattern of patterns) {
                if (pattern.test(text)) {
                    return intent;
                }
            }
        }
        
        return null;
    }
    
    async sendVoiceCommand(transcript, intent) {
        try {
            const response = await fetch('/cmms/ai/voice/command', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    command: transcript,
                    intent: intent,
                    confidence: this.confidenceThreshold,
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Voice command API error:', error);
            
            // Fallback to local processing if API is unavailable
            return this.fallbackCommandProcessing(transcript, intent);
        }
    }
    
    fallbackCommandProcessing(transcript, intent) {
        // Basic local command processing for offline functionality
        const responses = {
            help: {
                success: true,
                message: "Available commands: Create work order, List assets, Check inventory, Generate report, Search asset",
                intent: "help"
            },
            list_assets: {
                success: true,
                message: "Displaying asset list. This feature requires network connection for live data.",
                intent: "list_assets"
            },
            create_work_order: {
                success: true,
                message: "Work order creation requires network connection. Please try again when online.",
                intent: "create_work_order"
            }
        };
        
        return responses[intent] || {
            success: false,
            message: "Command not recognized. Say 'help' for available commands.",
            intent: "unknown"
        };
    }
    
    handleCommandSuccess(response) {
        const message = response.message || 'Command executed successfully';
        this.speak(message);
        
        // Update response UI
        document.getElementById('voice-response').innerHTML = `
            <div class="success">✅ ${message}</div>
        `;
        
        // Handle specific response types
        if (response.data) {
            this.handleResponseData(response.data, response.intent);
        }
    }
    
    handleCommandError(response) {
        const message = response?.message || 'Command failed';
        this.speak(`Error: ${message}`);
        
        document.getElementById('voice-response').innerHTML = `
            <div class="error">❌ ${message}</div>
        `;
    }
    
    handleResponseData(data, intent) {
        // Handle different response types based on intent
        switch (intent) {
            case 'list_assets':
                if (data.assets && data.assets.length > 0) {
                    const count = data.assets.length;
                    this.speak(`Found ${count} assets. Check the screen for details.`);
                    this.displayAssetsList(data.assets);
                }
                break;
                
            case 'reorder_parts':
                if (data.parts && data.parts.length > 0) {
                    const count = data.parts.length;
                    this.speak(`${count} parts need reordering. Check the screen for details.`);
                    this.displayPartsList(data.parts);
                }
                break;
                
            case 'create_work_order':
                if (data.work_order_id) {
                    this.speak(`Work order ${data.work_order_id} created successfully.`);
                    this.highlightWorkOrder(data.work_order_id);
                }
                break;
        }
    }
    
    displayAssetsList(assets) {
        // Create compact overlay for AR/mobile viewing
        const overlay = this.createCompactOverlay('Critical Assets', assets.map(asset => 
            `${asset.id}: ${asset.status} (${asset.priority || 'Normal'})`
        ));
        
        document.body.appendChild(overlay);
        setTimeout(() => overlay.remove(), 10000); // Auto-remove after 10s
    }
    
    displayPartsList(parts) {
        const overlay = this.createCompactOverlay('Parts to Reorder', parts.map(part =>
            `${part.name}: ${part.current_stock}/${part.min_stock} (${part.location})`
        ));
        
        document.body.appendChild(overlay);
        setTimeout(() => overlay.remove(), 10000);
    }
    
    createCompactOverlay(title, items) {
        const overlay = document.createElement('div');
        overlay.className = 'ar-overlay compact-list';
        overlay.innerHTML = `
            <div class="ar-header">
                <h4>${title}</h4>
                <button class="ar-close">×</button>
            </div>
            <div class="ar-content">
                ${items.map(item => `<div class="ar-item">${item}</div>`).join('')}
            </div>
        `;
        
        overlay.querySelector('.ar-close').addEventListener('click', () => {
            overlay.remove();
        });
        
        return overlay;
    }
    
    highlightWorkOrder(workOrderId) {
        // Highlight the work order if visible on screen
        const woElement = document.querySelector(`[data-wo-id="${workOrderId}"]`);
        if (woElement) {
            woElement.classList.add('highlight-new');
            setTimeout(() => woElement.classList.remove('highlight-new'), 3000);
        }
    }
    
    speak(text) {
        if (!this.synthesis) return;
        
        // Cancel any ongoing speech
        this.synthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 0.8;
        
        // Try to use a clear voice
        const voices = this.synthesis.getVoices();
        const preferredVoice = voices.find(voice => 
            voice.name.includes('Google') || 
            voice.name.includes('Microsoft') ||
            voice.lang.startsWith('en-')
        );
        
        if (preferredVoice) {
            utterance.voice = preferredVoice;
        }
        
        this.synthesis.speak(utterance);
    }
    
    updateUI() {
        const indicator = document.getElementById('voice-indicator');
        const statusText = document.getElementById('voice-status-text');
        const micButton = document.getElementById('mic-button');
        const floatingMic = document.getElementById('floating-mic');
        
        // Update indicator
        indicator.className = `voice-indicator ${this.currentMode}`;
        
        // Update status text
        const statusMessages = {
            idle: 'Ready',
            listening: 'Listening...',
            processing: 'Processing...',
            feedback: 'Speaking...'
        };
        
        statusText.textContent = statusMessages[this.currentMode] || 'Ready';
        
        // Update button states
        const isActive = this.currentMode === 'listening';
        micButton.classList.toggle('active', isActive);
        floatingMic.classList.toggle('active', isActive);
    }
    
    toggleHotkeys() {
        // TODO: Implement hotword detection
        const hotkeyStatus = document.getElementById('hotkey-status');
        const isEnabled = hotkeyStatus.textContent === 'ON';
        
        hotkeyStatus.textContent = isEnabled ? 'OFF' : 'ON';
        
        if (!isEnabled) {
            this.speak('Hotword detection enabled. Say "Hey CMMS" to activate.');
        } else {
            this.speak('Hotword detection disabled.');
        }
    }
    
    showSettings() {
        // Create settings modal
        const modal = document.createElement('div');
        modal.className = 'modal voice-settings-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Voice Settings</h3>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body">
                    <div class="setting-group">
                        <label>Confidence Threshold</label>
                        <input type="range" id="confidence-slider" min="0.1" max="1.0" step="0.1" 
                               value="${this.confidenceThreshold}">
                        <span id="confidence-value">${Math.round(this.confidenceThreshold * 100)}%</span>
                    </div>
                    <div class="setting-group">
                        <label>Speech Rate</label>
                        <input type="range" id="rate-slider" min="0.5" max="2.0" step="0.1" value="1.0">
                        <span id="rate-value">1.0x</span>
                    </div>
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" id="auto-submit"> 
                            Auto-submit commands
                        </label>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Bind modal events
        modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
        
        // Bind setting controls
        const confidenceSlider = modal.querySelector('#confidence-slider');
        const confidenceValue = modal.querySelector('#confidence-value');
        
        confidenceSlider.addEventListener('input', (e) => {
            this.confidenceThreshold = parseFloat(e.target.value);
            confidenceValue.textContent = Math.round(this.confidenceThreshold * 100) + '%';
        });
    }
    
    showNotification(message, type = 'info') {
        // Create notification
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">
                    ${type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️'}
                </span>
                <span class="notification-message">${message}</span>
            </div>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto-remove
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }
    
    // Public API methods
    startVoiceSession() {
        this.currentRetries = 0;
        this.startListening();
    }
    
    endVoiceSession() {
        this.stopListening();
    }
    
    getStatus() {
        return {
            isEnabled: this.isEnabled,
            isListening: this.isListening,
            currentMode: this.currentMode,
            confidenceThreshold: this.confidenceThreshold
        };
    }
}

// Initialize voice controller when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.voiceController = new VoiceController();
});

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VoiceController;
}