/**
 * Voice Command Palette for ChatterFix CMMS
 * Provides voice input interface with microphone button and command suggestions
 */

class VoiceCommandPalette {
    constructor(containerId = 'voice-command-container') {
        this.containerId = containerId;
        this.isListening = false;
        this.recognition = null;
        this.isSupported = false;
        this.commandHistory = [];
        this.suggestions = [];
        
        this.init();
    }
    
    init() {
        this.checkVoiceSupport();
        this.createUI();
        this.loadCapabilities();
        
        if (this.isSupported) {
            this.setupSpeechRecognition();
        }
        
        console.log('🎤 Voice Command Palette initialized');
    }
    
    checkVoiceSupport() {
        this.isSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
        console.log(`Voice support: ${this.isSupported ? 'Available' : 'Not available'}`);
    }
    
    createUI() {
        const container = document.getElementById(this.containerId) || this.createContainer();
        
        container.innerHTML = `
            <div class="voice-command-palette">
                <div class="voice-input-section">
                    <div class="voice-input-container">
                        <input type="text" 
                               id="voice-command-input" 
                               class="voice-command-input" 
                               placeholder="Say a command or type here..." 
                               autocomplete="off">
                        <button id="voice-mic-button" 
                                class="voice-mic-button ${this.isSupported ? '' : 'disabled'}"
                                ${!this.isSupported ? 'disabled' : ''}>
                            <span class="mic-icon">🎤</span>
                        </button>
                        <button id="voice-send-button" class="voice-send-button">
                            <span class="send-icon">📤</span>
                        </button>
                    </div>
                    <div class="voice-status" id="voice-status"></div>
                </div>
                
                <div class="voice-suggestions" id="voice-suggestions">
                    <div class="suggestions-header">Try these commands:</div>
                    <div class="suggestions-list" id="suggestions-list">
                        <div class="suggestion-item loading">Loading suggestions...</div>
                    </div>
                </div>
                
                <div class="voice-response" id="voice-response"></div>
            </div>
        `;
        
        this.setupEventListeners();
    }
    
    createContainer() {
        const container = document.createElement('div');
        container.id = this.containerId;
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            min-width: 350px;
            max-width: 500px;
        `;
        document.body.appendChild(container);
        return container;
    }
    
    setupEventListeners() {
        const micButton = document.getElementById('voice-mic-button');
        const sendButton = document.getElementById('voice-send-button');
        const input = document.getElementById('voice-command-input');
        
        if (micButton) {
            micButton.addEventListener('click', () => this.toggleVoiceRecognition());
        }
        
        if (sendButton) {
            sendButton.addEventListener('click', () => this.processCommand());
        }
        
        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.processCommand();
                }
            });
            
            input.addEventListener('input', (e) => {
                this.showRelevantSuggestions(e.target.value);
            });
        }
    }
    
    setupSpeechRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        
        if (!SpeechRecognition) {
            console.warn('Speech Recognition not supported');
            return;
        }
        
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';
        
        this.recognition.onstart = () => {
            this.isListening = true;
            this.updateVoiceStatus('Listening...', 'listening');
            this.updateMicButton(true);
        };
        
        this.recognition.onresult = (event) => {
            let transcript = '';
            for (let i = event.resultIndex; i < event.results.length; i++) {
                transcript += event.results[i][0].transcript;
            }
            
            document.getElementById('voice-command-input').value = transcript;
            
            if (event.results[event.resultIndex].isFinal) {
                this.processCommand(transcript);
            }
        };
        
        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.updateVoiceStatus(`Error: ${event.error}`, 'error');
            this.isListening = false;
            this.updateMicButton(false);
        };
        
        this.recognition.onend = () => {
            this.isListening = false;
            this.updateVoiceStatus('', '');
            this.updateMicButton(false);
        };
    }
    
    toggleVoiceRecognition() {
        if (!this.isSupported) {
            this.showError('Voice recognition is not supported in this browser');
            return;
        }
        
        if (this.isListening) {
            this.recognition.stop();
        } else {
            this.recognition.start();
        }
    }
    
    updateMicButton(isListening) {
        const micButton = document.getElementById('voice-mic-button');
        if (micButton) {
            micButton.classList.toggle('listening', isListening);
            micButton.querySelector('.mic-icon').textContent = isListening ? '🔴' : '🎤';
        }
    }
    
    updateVoiceStatus(message, type = '') {
        const statusElement = document.getElementById('voice-status');
        if (statusElement) {
            statusElement.textContent = message;
            statusElement.className = `voice-status ${type}`;
        }
    }
    
    async loadCapabilities() {
        try {
            const response = await fetch('/ai/capabilities');
            if (response.ok) {
                const capabilities = await response.json();
                this.suggestions = capabilities.sample_commands || [];
                this.renderSuggestions();
            }
        } catch (error) {
            console.error('Failed to load voice capabilities:', error);
            this.renderDefaultSuggestions();
        }
    }
    
    renderSuggestions(filterText = '') {
        const suggestionsList = document.getElementById('suggestions-list');
        if (!suggestionsList) return;
        
        let suggestionsToShow = this.suggestions;
        
        if (filterText) {
            suggestionsToShow = this.suggestions.filter(suggestion =>
                suggestion.toLowerCase().includes(filterText.toLowerCase())
            );
        }
        
        if (suggestionsToShow.length === 0) {
            suggestionsList.innerHTML = '<div class="suggestion-item">No matching suggestions</div>';
            return;
        }
        
        suggestionsList.innerHTML = suggestionsToShow.map(suggestion => `
            <div class="suggestion-item" onclick="voiceCommandPalette.selectSuggestion('${suggestion}')">
                ${suggestion}
            </div>
        `).join('');
    }
    
    renderDefaultSuggestions() {
        const defaultSuggestions = [
            "Create a high-priority work order for Pump-12 tomorrow",
            "What parts need reordering this week?",
            "Export last month's completed PMs to PDF",
            "List all open work orders",
            "Show me Motor-X maintenance history"
        ];
        
        this.suggestions = defaultSuggestions;
        this.renderSuggestions();
    }
    
    showRelevantSuggestions(text) {
        this.renderSuggestions(text);
    }
    
    selectSuggestion(suggestion) {
        document.getElementById('voice-command-input').value = suggestion;
        this.processCommand(suggestion);
    }
    
    async processCommand(command = null) {
        const input = document.getElementById('voice-command-input');
        const commandText = command || input.value.trim();
        
        if (!commandText) {
            this.showError('Please enter a command');
            return;
        }
        
        this.updateVoiceStatus('Processing command...', 'processing');
        
        try {
            const response = await fetch('/ai/intent', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    command: commandText,
                    voice_enabled: true
                })
            });
            
            if (response.ok) {
                const result = await response.json();
                this.displayResponse(result);
                this.addToHistory(commandText, result);
                
                // Play TTS if enabled
                if (result.tts_confirmation && result.tts_confirmation.tts_enabled) {
                    this.playTTSResponse(result.confirmation_message);
                }
                
                // Clear input
                input.value = '';
                
            } else {
                const error = await response.json();
                this.showError(`Error: ${error.detail || 'Unknown error'}`);
            }
            
        } catch (error) {
            console.error('Command processing error:', error);
            this.showError('Failed to process command. Please try again.');
        }
        
        this.updateVoiceStatus('', '');
    }
    
    displayResponse(result) {
        const responseContainer = document.getElementById('voice-response');
        if (!responseContainer) return;
        
        const timestamp = new Date().toLocaleTimeString();
        
        responseContainer.innerHTML = `
            <div class="voice-response-item ${result.success ? 'success' : 'error'}">
                <div class="response-header">
                    <span class="response-icon">${result.success ? '✅' : '❌'}</span>
                    <span class="response-time">${timestamp}</span>
                </div>
                <div class="response-message">${result.confirmation_message}</div>
                ${result.action_taken ? `<div class="response-action">Action: ${result.action_taken}</div>` : ''}
                ${result.result_data ? this.formatResultData(result.result_data) : ''}
            </div>
        `;
        
        // Auto-hide after 10 seconds
        setTimeout(() => {
            responseContainer.innerHTML = '';
        }, 10000);
    }
    
    formatResultData(data) {
        if (!data || typeof data !== 'object') return '';
        
        let html = '<div class="response-data">';
        
        if (data.work_order_id) {
            html += `<div class="data-item">Work Order: <strong>${data.work_order_id}</strong></div>`;
        }
        
        if (data.parts && Array.isArray(data.parts)) {
            html += `<div class="data-item">Parts found: ${data.parts.length}</div>`;
        }
        
        if (data.filename) {
            html += `<div class="data-item">File: <strong>${data.filename}</strong></div>`;
        }
        
        html += '</div>';
        return html;
    }
    
    playTTSResponse(message) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(message);
            utterance.rate = 0.9;
            utterance.pitch = 1;
            utterance.volume = 0.8;
            speechSynthesis.speak(utterance);
        }
    }
    
    addToHistory(command, result) {
        this.commandHistory.push({
            command,
            result,
            timestamp: new Date().toISOString()
        });
        
        // Keep only last 10 commands
        if (this.commandHistory.length > 10) {
            this.commandHistory = this.commandHistory.slice(-10);
        }
    }
    
    showError(message) {
        this.updateVoiceStatus(message, 'error');
        setTimeout(() => {
            this.updateVoiceStatus('', '');
        }, 3000);
    }
    
    // Public API methods
    show() {
        const container = document.getElementById(this.containerId);
        if (container) {
            container.style.display = 'block';
        }
    }
    
    hide() {
        const container = document.getElementById(this.containerId);
        if (container) {
            container.style.display = 'none';
        }
    }
    
    toggle() {
        const container = document.getElementById(this.containerId);
        if (container) {
            container.style.display = container.style.display === 'none' ? 'block' : 'none';
        }
    }
}

// Initialize voice command palette when DOM is ready
let voiceCommandPalette;

document.addEventListener('DOMContentLoaded', () => {
    // Create voice command palette
    voiceCommandPalette = new VoiceCommandPalette();
    
    // Make it globally accessible
    window.voiceCommandPalette = voiceCommandPalette;
    
    // Add keyboard shortcut (Ctrl/Cmd + K)
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            voiceCommandPalette.toggle();
            document.getElementById('voice-command-input')?.focus();
        }
    });
});

// Export for module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VoiceCommandPalette;
}