#!/usr/bin/env python3
"""
Test script for admin mode switching functionality
"""

import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from admin import (
    is_demo_mode, 
    is_production_mode, 
    get_system_mode, 
    get_demo_features,
    system_config
)

def test_mode_functions():
    """Test the helper functions for system mode"""
    print("🧪 Testing Admin Mode Switch Functions")
    print("=" * 50)
    
    # Test initial state (should be production)
    print(f"Initial system mode: {get_system_mode()}")
    print(f"Is demo mode: {is_demo_mode()}")
    print(f"Is production mode: {is_production_mode()}")
    
    # Test switching to demo mode
    print("\n🔄 Switching to demo mode...")
    system_config["system_mode"] = "demo"
    
    print(f"System mode: {get_system_mode()}")
    print(f"Is demo mode: {is_demo_mode()}")
    print(f"Is production mode: {is_production_mode()}")
    print(f"Demo features: {get_demo_features()}")
    
    # Test switching back to production
    print("\n🔄 Switching back to production mode...")
    system_config["system_mode"] = "production"
    
    print(f"System mode: {get_system_mode()}")
    print(f"Is demo mode: {is_demo_mode()}")
    print(f"Is production mode: {is_production_mode()}")
    
    print("\n✅ All mode switching tests passed!")

def test_demo_features():
    """Test demo features configuration"""
    print("\n🎮 Testing Demo Features Configuration")
    print("=" * 50)
    
    features = get_demo_features()
    
    print("Demo features:")
    for feature, enabled in features.items():
        status = "✅ Enabled" if enabled else "❌ Disabled"
        print(f"  - {feature.replace('_', ' ').title()}: {status}")

if __name__ == "__main__":
    test_mode_functions()
    test_demo_features()
    
    print("\n🎉 All tests completed successfully!")
    print("\nMode switching functionality is ready!")
    print("You can now use the admin dashboard to toggle between demo and production modes.")