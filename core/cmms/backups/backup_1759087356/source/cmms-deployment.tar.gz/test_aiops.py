#!/usr/bin/env python3
"""
Test script for AIOps Self-Healing System
Tests incident detection and auto-remediation capabilities.
"""

import asyncio
import json
import time
import subprocess
import requests
from datetime import datetime
from pathlib import Path

def test_app_process_monitoring():
    """Test app process monitoring and restart capability"""
    print("🧪 Testing app process monitoring and auto-restart...")
    
    try:
        # Check if we can find app processes
        result = subprocess.run(
            ["pgrep", "-f", "python.*app.py"],
            capture_output=True, text=True
        )
        
        if result.returncode == 0:
            pids = result.stdout.strip().split('\n')
            print(f"   ✅ Found app processes: {pids}")
            
            # Test killing process (simulate crash)
            if pids and pids[0]:
                print(f"   🔥 Simulating app crash - killing PID {pids[0]}")
                subprocess.run(["kill", "-TERM", pids[0]])
                time.sleep(2)
                
                # Check if process is gone
                result = subprocess.run(
                    ["pgrep", "-f", "python.*app.py"],
                    capture_output=True, text=True
                )
                
                if result.returncode != 0:
                    print("   ✅ App process terminated successfully")
                    return True
                else:
                    print("   ⚠️ App process still running after termination")
                    return False
        else:
            print("   ⚠️ No app processes found to test")
            return False
            
    except Exception as e:
        print(f"   ❌ App process test failed: {e}")
        return False

def test_playbook_execution():
    """Test playbook execution via API"""
    print("🧪 Testing playbook execution...")
    
    try:
        # Test getting playbook list
        response = requests.get("http://localhost:8000/ai/ops/actions/playbooks", timeout=10)
        if response.status_code == 200:
            playbooks = response.json()
            print(f"   ✅ Found {playbooks['total_count']} playbooks")
            
            # Test executing restart_app playbook
            response = requests.post(
                "http://localhost:8000/ai/ops/actions/run/restart_app",
                json={"context": {"test": True}},
                timeout=30
            )
            
            if response.status_code == 200:
                execution = response.json()
                print(f"   ✅ Restart playbook executed: {execution['status']}")
                print(f"   📝 Steps completed: {execution['steps_completed']}/{execution['total_steps']}")
                return True
            else:
                print(f"   ❌ Playbook execution failed: {response.status_code}")
                return False
        else:
            print(f"   ❌ Failed to get playbooks: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("   ⚠️ App not running - cannot test API endpoints")
        return False
    except Exception as e:
        print(f"   ❌ Playbook test failed: {e}")
        return False

def test_incident_summary():
    """Test incident summary generation"""
    print("🧪 Testing incident summary...")
    
    try:
        # Test getting today's summary
        response = requests.get("http://localhost:8000/ai/ops/summary/today", timeout=10)
        if response.status_code == 200:
            summary = response.json()
            print(f"   ✅ Today's summary: {summary['total_incidents']} incidents")
            print(f"   📊 Analysis: {summary['summary_analysis']}")
            return True
        else:
            print(f"   ❌ Failed to get summary: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("   ⚠️ App not running - cannot test API endpoints")
        return False
    except Exception as e:
        print(f"   ❌ Summary test failed: {e}")
        return False

def test_log_monitoring():
    """Test log monitoring and incident detection"""
    print("🧪 Testing log monitoring...")
    
    try:
        # Create test log entries
        test_log_dir = Path("/tmp")
        test_log_file = test_log_dir / "test_app.log"
        
        # Write test log entries that should trigger incidents
        test_entries = [
            f"{datetime.now().isoformat()} ERROR Application crashed with exception",
            f"{datetime.now().isoformat()} ERROR HTTP/1.1 500 Internal Server Error",
            f"{datetime.now().isoformat()} WARNING Response took 3500ms - slow query",
            f"{datetime.now().isoformat()} CRITICAL Process terminated unexpectedly"
        ]
        
        with open(test_log_file, "w") as f:
            f.write("\n".join(test_entries) + "\n")
        
        print(f"   ✅ Created test log file: {test_log_file}")
        
        # Test manual log scanning
        response = requests.post("http://localhost:8000/ai/ops/monitor/scan-logs", timeout=10)
        if response.status_code == 200:
            scan_result = response.json()
            print(f"   ✅ Log scan initiated: {scan_result['status']}")
            return True
        else:
            print(f"   ❌ Log scan failed: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("   ⚠️ App not running - cannot test API endpoints")
        return False
    except Exception as e:
        print(f"   ❌ Log monitoring test failed: {e}")
        return False

def test_system_health_playbook():
    """Test system health check playbook"""
    print("🧪 Testing system health check...")
    
    try:
        response = requests.post(
            "http://localhost:8000/ai/ops/actions/run/system_health_check",
            json={"context": {"triggered_by": "test"}},
            timeout=45
        )
        
        if response.status_code == 200:
            execution = response.json()
            print(f"   ✅ Health check executed: {execution['status']}")
            
            # Print some output log entries
            if execution['output_log']:
                print("   📝 Health check results:")
                for log_entry in execution['output_log'][:3]:  # First 3 entries
                    print(f"      {log_entry}")
            
            return execution['status'] == 'success'
        else:
            print(f"   ❌ Health check failed: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("   ⚠️ App not running - cannot test API endpoints")
        return False
    except Exception as e:
        print(f"   ❌ Health check test failed: {e}")
        return False

def test_disk_cleanup_playbook():
    """Test disk cleanup playbook"""
    print("🧪 Testing disk cleanup playbook...")
    
    try:
        response = requests.post(
            "http://localhost:8000/ai/ops/actions/run/rotate_logs",
            json={"context": {"triggered_by": "test"}},
            timeout=60
        )
        
        if response.status_code == 200:
            execution = response.json()
            print(f"   ✅ Disk cleanup executed: {execution['status']}")
            return execution['status'] == 'success'
        else:
            print(f"   ❌ Disk cleanup failed: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("   ⚠️ App not running - cannot test API endpoints")
        return False
    except Exception as e:
        print(f"   ❌ Disk cleanup test failed: {e}")
        return False

def main():
    """Run all AIOps tests"""
    print("🤖 AIOps Self-Healing System Test Suite")
    print("=" * 50)
    
    tests = [
        ("App Process Monitoring", test_app_process_monitoring),
        ("Playbook Execution", test_playbook_execution), 
        ("Incident Summary", test_incident_summary),
        ("Log Monitoring", test_log_monitoring),
        ("System Health Check", test_system_health_playbook),
        ("Disk Cleanup", test_disk_cleanup_playbook)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"   💥 Test crashed: {e}")
            results.append((test_name, False))
        
        time.sleep(1)  # Brief pause between tests
    
    # Print summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status} {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("🎉 All tests passed! AIOps system is functioning correctly.")
    elif passed >= total * 0.8:
        print("⚠️  Most tests passed. Minor issues may need attention.")
    else:
        print("🚨 Multiple test failures. System may need troubleshooting.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)