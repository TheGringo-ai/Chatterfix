#!/usr/bin/env python3
"""
Test specific AIOps scenarios: cert renewal and disk-full simulations
"""

import asyncio
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from aiops_monitor import aiops_monitor
from aiops_playbooks import playbook_registry

async def test_disk_full_simulation():
    """Test disk-full detection and remediation"""
    print("🧪 Testing disk-full simulation and remediation...")
    
    # Check current disk usage
    total, used, free = shutil.disk_usage("/")
    current_usage = used / total
    
    print(f"   📊 Current disk usage: {current_usage:.1%} ({free/(1024**3):.1f}GB free)")
    
    # Simulate disk full condition by temporarily lowering threshold
    original_threshold = aiops_monitor.thresholds['disk_usage']
    aiops_monitor.thresholds['disk_usage'] = current_usage - 0.01  # Set threshold below current usage
    
    try:
        # Trigger system metrics monitoring
        incidents = aiops_monitor.monitor_system_metrics()
        
        # Should detect disk full incident
        disk_incidents = [i for i in incidents if i.incident_type.value == "disk_full"]
        
        if disk_incidents:
            incident = disk_incidents[0]
            print(f"   ✅ Disk-full incident detected: {incident.title}")
            print(f"      Request ID: {incident.request_id}")
            
            # Test auto-remediation
            print(f"   🔧 Testing disk cleanup remediation...")
            
            execution = await playbook_registry.execute_playbook(
                "rotate_logs",
                {
                    "incident_id": incident.incident_id,
                    "trigger": "disk_full_detection"
                }
            )
            
            print(f"   📊 Cleanup execution: {execution.status.value}")
            print(f"   📝 Steps completed: {execution.steps_completed}/{execution.total_steps}")
            
            if execution.output_log:
                print(f"   📋 Cleanup actions:")
                for log_entry in execution.output_log:
                    if "disk" in log_entry.lower() or "cleaned" in log_entry.lower():
                        print(f"      {log_entry}")
            
            return True
        else:
            print("   ❌ No disk-full incident detected")
            return False
            
    finally:
        # Restore original threshold
        aiops_monitor.thresholds['disk_usage'] = original_threshold

async def test_cert_renewal_simulation():
    """Test certificate renewal scenario"""
    print("\n🧪 Testing certificate renewal simulation...")
    
    # Create a test scenario where cert needs reloading
    print("   📜 Simulating certificate renewal...")
    
    # Execute nginx reload playbook (cert renewal scenario)
    execution = await playbook_registry.execute_playbook(
        "reload_nginx",
        {
            "trigger": "cert_renewal",
            "cert_path": "/etc/ssl/certs/chatterfix.crt"
        }
    )
    
    print(f"   📊 Nginx reload execution: {execution.status.value}")
    print(f"   📝 Steps completed: {execution.steps_completed}/{execution.total_steps}")
    
    if execution.output_log:
        print(f"   📋 Reload actions:")
        for log_entry in execution.output_log:
            print(f"      {log_entry}")
    
    # Even if nginx isn't actually running, the playbook should complete its steps
    return execution.steps_completed >= 2

async def test_process_kill_and_restart():
    """Test process kill detection and auto-restart"""
    print("\n🧪 Testing process kill and auto-restart...")
    
    # Create a simple test process
    import subprocess
    import time
    
    # Start a dummy process we can kill
    test_script = """
import time
import signal
import sys

def signal_handler(sig, frame):
    print("Process terminating...")
    sys.exit(1)

signal.signal(signal.SIGTERM, signal_handler)

print("Test process started")
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("Process interrupted")
    sys.exit(0)
"""
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(test_script)
        test_script_path = f.name
    
    try:
        # Start test process
        process = subprocess.Popen([
            'python3', test_script_path
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        print(f"   ✅ Started test process with PID: {process.pid}")
        await asyncio.sleep(2)  # Let it run briefly
        
        # Kill the process (simulate crash)
        process.terminate()
        print(f"   🔥 Killed test process (simulated crash)")
        
        # Wait for process to die
        process.wait(timeout=5)
        print(f"   ✅ Process terminated with code: {process.returncode}")
        
        # Test restart playbook
        print(f"   🔧 Testing restart remediation...")
        
        execution = await playbook_registry.execute_playbook(
            "restart_app",
            {
                "incident_type": "app_crash", 
                "killed_pid": process.pid
            }
        )
        
        print(f"   📊 Restart execution: {execution.status.value}")
        print(f"   📝 Steps completed: {execution.steps_completed}/{execution.total_steps}")
        
        # Show restart attempt details
        restart_steps = [log for log in execution.output_log if any(word in log.lower() 
                        for word in ['start', 'stop', 'restart', 'process', 'app'])]
        if restart_steps:
            print(f"   📋 Restart steps:")
            for step in restart_steps[:3]:  # Show first 3 restart-related steps
                print(f"      {step}")
        
        return execution.steps_completed >= 4  # Should complete most steps
        
    finally:
        # Clean up
        if os.path.exists(test_script_path):
            os.unlink(test_script_path)

async def test_high_error_rate_detection():
    """Test high error rate detection and remediation"""
    print("\n🧪 Testing high error rate detection...")
    
    # Create log events with high error rate
    from aiops_monitor import LogEvent
    
    test_events = []
    
    # Generate 20 requests with 30% error rate (should trigger incident)
    for i in range(20):
        if i < 14:  # 70% success
            event = LogEvent(
                timestamp=datetime.now(),
                level="INFO",
                source="nginx",
                message=f'127.0.0.1 - - "GET /api/test{i} HTTP/1.1" 200 1024',
                response_code=200,
                response_time_ms=150 + (i * 10)
            )
        else:  # 30% errors
            event = LogEvent(
                timestamp=datetime.now(),
                level="ERROR",
                source="nginx", 
                message=f'127.0.0.1 - - "GET /api/test{i} HTTP/1.1" 500 256',
                response_code=500,
                response_time_ms=2000 + (i * 100)
            )
        test_events.append(event)
    
    # Analyze events
    incidents = aiops_monitor.analyze_log_events(test_events)
    
    # Should detect high error rate
    error_incidents = [i for i in incidents if i.incident_type.value == "high_error_rate"]
    
    if error_incidents:
        incident = error_incidents[0]
        print(f"   ✅ High error rate detected: {incident.title}")
        print(f"      Request ID: {incident.request_id}")
        print(f"      Root cause: {incident.root_cause}")
        
        # Test remediation with health check
        execution = await playbook_registry.execute_playbook(
            "system_health_check",
            {"incident_id": incident.incident_id}
        )
        
        print(f"   📊 Health check remediation: {execution.status.value}")
        return True
    else:
        print("   ❌ High error rate not detected")
        return False

async def test_cache_warming():
    """Test cache warming playbook"""
    print("\n🧪 Testing cache warming...")
    
    execution = await playbook_registry.execute_playbook(
        "warm_caches",
        {"trigger": "system_startup"}
    )
    
    print(f"   📊 Cache warming execution: {execution.status.value}")
    print(f"   📝 Steps completed: {execution.steps_completed}/{execution.total_steps}")
    
    cache_steps = [log for log in execution.output_log if 'cache' in log.lower()]
    if cache_steps:
        print(f"   📋 Cache warming actions:")
        for step in cache_steps:
            print(f"      {step}")
    
    return execution.steps_completed >= 3

async def main():
    """Run scenario-based tests"""
    print("🎭 AIOps Scenario Testing")
    print("=" * 40)
    
    tests = [
        ("Disk-Full Detection & Cleanup", test_disk_full_simulation),
        ("Certificate Renewal", test_cert_renewal_simulation),
        ("Process Kill & Auto-Restart", test_process_kill_and_restart),
        ("High Error Rate Detection", test_high_error_rate_detection),
        ("Cache Warming", test_cache_warming)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
            print(f"   {'✅ PASS' if result else '❌ FAIL'} {test_name}")
        except Exception as e:
            print(f"   💥 {test_name} crashed: {e}")
            results.append((test_name, False))
        
        await asyncio.sleep(1)  # Brief pause between tests
    
    # Print summary
    print("\n" + "=" * 40)
    print("📊 Scenario Test Results:")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status} {test_name}")
    
    print(f"\n🎯 Scenarios: {passed}/{total} passed ({passed/total*100:.1f}%)")
    
    # Check acceptance criteria
    print(f"\n📋 Acceptance Criteria Check:")
    
    disk_full_passed = any("Disk-Full" in name and result for name, result in results)
    cert_passed = any("Certificate" in name and result for name, result in results) 
    restart_passed = any("Restart" in name and result for name, result in results)
    
    print(f"   {'✅' if restart_passed else '❌'} Auto-restart on process kill")
    print(f"   {'✅' if cert_passed else '❌'} Certificate renewal playbook trigger")
    print(f"   {'✅' if disk_full_passed else '❌'} Disk-full simulation and remediation")
    
    all_criteria_met = disk_full_passed and cert_passed and restart_passed
    
    if all_criteria_met:
        print("\n🎉 All acceptance criteria met!")
    else:
        print("\n⚠️  Some acceptance criteria need attention.")
    
    return all_criteria_met

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)