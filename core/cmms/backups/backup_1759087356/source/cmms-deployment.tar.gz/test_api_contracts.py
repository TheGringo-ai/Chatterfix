#!/usr/bin/env python3
"""
CMMS API Contract Tests
Comprehensive test suite for all CMMS endpoints with RBAC validation
"""

import pytest
import httpx
import json
from datetime import datetime, date
from typing import Dict, Any
import os
import sys

# Add the cmms directory to Python path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi.testclient import TestClient
from api_schemas import UserRole, ExportFormat
from auth_rbac import create_access_token, create_user, USERS_DB

# Import the main app
from app import app

client = TestClient(app)

# =============================================================================
# Test Configuration and Fixtures
# =============================================================================

@pytest.fixture(scope="session")
def auth_tokens():
    """Create auth tokens for different user roles"""
    tokens = {}
    
    # Create test users for each role
    test_users = {
        "admin": {
            "username": "test_admin",
            "email": "admin@test.com",
            "password": "AdminTest123!",
            "first_name": "Test",
            "last_name": "Admin",
            "role": UserRole.ADMIN
        },
        "manager": {
            "username": "test_manager",
            "email": "manager@test.com",
            "password": "ManagerTest123!",
            "first_name": "Test",
            "last_name": "Manager",
            "role": UserRole.MANAGER
        },
        "technician": {
            "username": "test_technician",
            "email": "technician@test.com",
            "password": "TechTest123!",
            "first_name": "Test",
            "last_name": "Technician",
            "role": UserRole.TECHNICIAN
        },
        "viewer": {
            "username": "test_viewer",
            "email": "viewer@test.com",
            "password": "ViewerTest123!",
            "first_name": "Test",
            "last_name": "Viewer",
            "role": UserRole.VIEWER
        }
    }
    
    for role, user_data in test_users.items():
        try:
            user = create_user(**user_data)
            token = create_access_token(user)
            tokens[role] = token
        except ValueError:
            # User already exists, get existing
            user = USERS_DB.get(user_data["username"])
            if user:
                token = create_access_token(user)
                tokens[role] = token
    
    return tokens

@pytest.fixture
def sample_work_order():
    """Sample work order data for testing"""
    return {
        "title": "Test Work Order",
        "description": "This is a test work order for API testing",
        "asset_id": "AST-001",
        "type": "reactive",
        "priority": "medium",
        "assigned_to": "TECH-001",
        "due_date": "2025-09-15",
        "estimated_hours": 4.0
    }

@pytest.fixture
def sample_asset():
    """Sample asset data for testing"""
    return {
        "name": "Test Pump",
        "asset_id": "PUMP-999",
        "description": "Test pump for API testing",
        "category": "mechanical",
        "location": "Test Building",
        "status": "operational",
        "criticality": "medium",
        "maintenance_frequency": 30
    }

@pytest.fixture
def sample_part():
    """Sample part data for testing"""
    return {
        "name": "Test Bearing",
        "part_number": "BEAR-999",
        "description": "Test bearing for API testing",
        "category": "bearings",
        "unit_cost": 25.50,
        "quantity": 10,
        "min_stock": 5,
        "supplier": "Test Supplier",
        "location": "Warehouse A"
    }

@pytest.fixture
def sample_pm_task():
    """Sample PM task data for testing"""
    return {
        "title": "Test PM Task",
        "description": "Test preventive maintenance task",
        "asset_id": "AST-001",
        "frequency": "monthly",
        "priority": "medium",
        "estimated_hours": 2.0,
        "instructions": "Test instructions"
    }

@pytest.fixture
def sample_technician():
    """Sample technician data for testing"""
    return {
        "employee_id": "EMP-999",
        "first_name": "Test",
        "last_name": "Technician",
        "email": "test.tech@example.com",
        "hire_date": "2024-01-01",
        "shift": "first",
        "skills": ["electrical", "mechanical"]
    }

# =============================================================================
# Authentication and Authorization Tests
# =============================================================================

class TestAuthentication:
    """Test authentication and authorization"""
    
    def test_login_valid_credentials(self):
        """Test login with valid credentials"""
        response = client.post("/auth/login", json={
            "username": "admin",
            "password": "admin123!"
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
        assert data["user"]["role"] == "admin"
    
    def test_login_invalid_credentials(self):
        """Test login with invalid credentials"""
        response = client.post("/auth/login", json={
            "username": "admin",
            "password": "wrongpassword"
        })
        assert response.status_code == 401
    
    def test_protected_endpoint_without_token(self):
        """Test accessing protected endpoint without token"""
        response = client.get("/parts/")
        assert response.status_code == 401
    
    def test_protected_endpoint_with_invalid_token(self):
        """Test accessing protected endpoint with invalid token"""
        response = client.get(
            "/parts/",
            headers={"Authorization": "Bearer invalid_token"}
        )
        assert response.status_code == 401

# =============================================================================
# Work Orders API Tests
# =============================================================================

class TestWorkOrdersAPI:
    """Test Work Orders API endpoints"""
    
    def test_get_work_orders_admin(self, auth_tokens):
        """Test getting work orders as admin"""
        response = client.get(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200
        assert isinstance(response.json(), list)
    
    def test_get_work_orders_viewer(self, auth_tokens):
        """Test getting work orders as viewer"""
        response = client.get(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"}
        )
        assert response.status_code == 200
    
    def test_create_work_order_admin(self, auth_tokens, sample_work_order):
        """Test creating work order as admin"""
        response = client.post(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_work_order
        )
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == sample_work_order["title"]
        assert "id" in data
        return data["id"]
    
    def test_create_work_order_viewer_forbidden(self, auth_tokens, sample_work_order):
        """Test creating work order as viewer (should fail)"""
        response = client.post(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"},
            json=sample_work_order
        )
        assert response.status_code == 403
    
    def test_update_work_order_manager(self, auth_tokens, sample_work_order):
        """Test updating work order as manager"""
        # First create a work order
        create_response = client.post(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_work_order
        )
        work_order_id = create_response.json()["id"]
        
        # Then update it
        update_data = {"priority": "high"}
        response = client.put(
            f"/workorders/{work_order_id}",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"},
            json=update_data
        )
        assert response.status_code == 200
        assert response.json()["priority"] == "high"
    
    def test_delete_work_order_admin_only(self, auth_tokens, sample_work_order):
        """Test deleting work order (admin only)"""
        # Create work order
        create_response = client.post(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_work_order
        )
        work_order_id = create_response.json()["id"]
        
        # Try to delete as manager (should fail)
        response = client.delete(
            f"/workorders/{work_order_id}",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"}
        )
        assert response.status_code == 403
        
        # Delete as admin (should succeed)
        response = client.delete(
            f"/workorders/{work_order_id}",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200
    
    def test_bulk_assign_work_orders(self, auth_tokens):
        """Test bulk assigning work orders"""
        # Create multiple work orders first
        work_order_ids = []
        for i in range(3):
            wo_data = {
                "title": f"Bulk Test WO {i}",
                "description": "Test work order",
                "asset_id": "AST-001",
                "type": "reactive",
                "priority": "medium"
            }
            response = client.post(
                "/workorders/",
                headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
                json=wo_data
            )
            work_order_ids.append(response.json()["id"])
        
        # Bulk assign
        assign_data = {
            "work_order_ids": work_order_ids,
            "assigned_to": "TECH-001"
        }
        response = client.post(
            "/workorders/bulk-assign",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"},
            json=assign_data
        )
        assert response.status_code == 200
        result = response.json()
        assert result["successful"] == 3

# =============================================================================
# Assets API Tests
# =============================================================================

class TestAssetsAPI:
    """Test Assets API endpoints"""
    
    def test_get_assets_list(self, auth_tokens):
        """Test getting assets list"""
        response = client.get(
            "/assets/",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"}
        )
        assert response.status_code == 200
    
    def test_create_asset_admin(self, auth_tokens, sample_asset):
        """Test creating asset as admin"""
        response = client.post(
            "/assets/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_asset
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == sample_asset["name"]
        assert data["asset_id"] == sample_asset["asset_id"]
    
    def test_create_asset_technician_forbidden(self, auth_tokens, sample_asset):
        """Test creating asset as technician (should fail)"""
        response = client.post(
            "/assets/",
            headers={"Authorization": f"Bearer {auth_tokens['technician']}"},
            json=sample_asset
        )
        assert response.status_code == 403
    
    def test_get_asset_by_id(self, auth_tokens, sample_asset):
        """Test getting specific asset"""
        # Create asset first
        create_response = client.post(
            "/assets/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_asset
        )
        asset_id = create_response.json()["id"]
        
        # Get asset
        response = client.get(
            f"/assets/{asset_id}",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"}
        )
        assert response.status_code == 200
        assert response.json()["id"] == asset_id
    
    def test_export_assets_csv(self, auth_tokens):
        """Test exporting assets as CSV"""
        response = client.get(
            "/assets/export/csv",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200

# =============================================================================
# Parts API Tests
# =============================================================================

class TestPartsAPI:
    """Test Parts API endpoints"""
    
    def test_get_parts_paginated(self, auth_tokens):
        """Test getting paginated parts list"""
        response = client.get(
            "/parts/list/paginated?page=1&limit=10",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "items" in data
        assert "total" in data
        assert "page" in data
        assert "limit" in data
    
    def test_create_part_manager(self, auth_tokens, sample_part):
        """Test creating part as manager"""
        response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"},
            json=sample_part
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == sample_part["name"]
        assert data["part_number"] == sample_part["part_number"]
    
    def test_create_part_viewer_forbidden(self, auth_tokens, sample_part):
        """Test creating part as viewer (should fail)"""
        response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"},
            json=sample_part
        )
        assert response.status_code == 403
    
    def test_adjust_stock_manager(self, auth_tokens, sample_part):
        """Test adjusting stock as manager"""
        # Create part first
        create_response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_part
        )
        part_id = create_response.json()["id"]
        
        # Adjust stock
        adjustment_data = {
            "part_id": part_id,
            "adjustment_type": "receive",
            "quantity": 5,
            "reason": "Test stock adjustment",
            "performed_by": "test_manager"
        }
        response = client.post(
            f"/parts/{part_id}/adjust-stock",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"},
            json=adjustment_data
        )
        assert response.status_code == 200
        assert response.json()["quantity"] == 5
    
    def test_adjust_stock_viewer_forbidden(self, auth_tokens, sample_part):
        """Test adjusting stock as viewer (should fail)"""
        # Create part first
        create_response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_part
        )
        part_id = create_response.json()["id"]
        
        # Try to adjust stock
        adjustment_data = {
            "part_id": part_id,
            "adjustment_type": "receive",
            "quantity": 5,
            "reason": "Test stock adjustment",
            "performed_by": "test_viewer"
        }
        response = client.post(
            f"/parts/{part_id}/adjust-stock",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"},
            json=adjustment_data
        )
        assert response.status_code == 403
    
    def test_bulk_delete_parts_admin(self, auth_tokens):
        """Test bulk deleting parts as admin"""
        # Create multiple parts
        part_ids = []
        for i in range(3):
            part_data = {
                "name": f"Bulk Test Part {i}",
                "part_number": f"BULK-{i:03d}",
                "category": "other",
                "unit_cost": 10.0,
                "quantity": 1,
                "min_stock": 0
            }
            response = client.post(
                "/parts/",
                headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
                json=part_data
            )
            part_ids.append(response.json()["id"])
        
        # Bulk delete
        delete_data = {"ids": part_ids}
        response = client.post(
            "/parts/bulk-delete",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=delete_data
        )
        assert response.status_code == 200
        result = response.json()
        assert result["successful"] == 3
    
    def test_export_parts_json(self, auth_tokens):
        """Test exporting parts as JSON"""
        response = client.get(
            "/parts/export/json",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200

# =============================================================================
# Preventive Maintenance API Tests
# =============================================================================

class TestPMAPI:
    """Test Preventive Maintenance API endpoints"""
    
    def test_get_pm_tasks(self, auth_tokens):
        """Test getting PM tasks"""
        response = client.get(
            "/preventive/",
            headers={"Authorization": f"Bearer {auth_tokens['viewer']}"}
        )
        assert response.status_code == 200
    
    def test_create_pm_task_manager(self, auth_tokens, sample_pm_task):
        """Test creating PM task as manager"""
        response = client.post(
            "/preventive/",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"},
            json=sample_pm_task
        )
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == sample_pm_task["title"]
    
    def test_complete_pm_task_technician(self, auth_tokens, sample_pm_task):
        """Test completing PM task as technician"""
        # Create PM task first
        create_response = client.post(
            "/preventive/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_pm_task
        )
        pm_id = create_response.json()["id"]
        
        # Complete task
        completion_data = {
            "pm_task_id": pm_id,
            "completed_by": "test_technician",
            "completion_notes": "Task completed successfully"
        }
        response = client.post(
            f"/preventive/{pm_id}/complete",
            headers={"Authorization": f"Bearer {auth_tokens['technician']}"},
            json=completion_data
        )
        assert response.status_code == 200

# =============================================================================
# Technician API Tests
# =============================================================================

class TestTechniciansAPI:
    """Test Technicians API endpoints"""
    
    def test_get_technicians_manager(self, auth_tokens):
        """Test getting technicians as manager"""
        response = client.get(
            "/technicians/",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"}
        )
        assert response.status_code == 200
    
    def test_create_technician_admin(self, auth_tokens, sample_technician):
        """Test creating technician as admin"""
        response = client.post(
            "/technicians/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_technician
        )
        assert response.status_code == 200
        data = response.json()
        assert data["employee_id"] == sample_technician["employee_id"]
    
    def test_create_technician_technician_forbidden(self, auth_tokens, sample_technician):
        """Test creating technician as technician (should fail)"""
        response = client.post(
            "/technicians/",
            headers={"Authorization": f"Bearer {auth_tokens['technician']}"},
            json=sample_technician
        )
        assert response.status_code == 403

# =============================================================================
# Admin API Tests
# =============================================================================

class TestAdminAPI:
    """Test Admin API endpoints"""
    
    def test_get_system_stats_admin(self, auth_tokens):
        """Test getting system stats as admin"""
        response = client.get(
            "/admin/stats",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "total_work_orders" in data
    
    def test_get_system_stats_manager_forbidden(self, auth_tokens):
        """Test getting system stats as manager (should fail)"""
        response = client.get(
            "/admin/stats",
            headers={"Authorization": f"Bearer {auth_tokens['manager']}"}
        )
        assert response.status_code == 403
    
    def test_get_users_admin(self, auth_tokens):
        """Test getting users as admin"""
        response = client.get(
            "/admin/users",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200
        assert isinstance(response.json(), list)
    
    def test_create_user_admin(self, auth_tokens):
        """Test creating user as admin"""
        user_data = {
            "username": "test_new_user",
            "email": "newuser@test.com",
            "password": "NewUser123!",
            "first_name": "New",
            "last_name": "User",
            "role": "viewer"
        }
        response = client.post(
            "/admin/users",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=user_data
        )
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == user_data["username"]

# =============================================================================
# Data Validation Tests
# =============================================================================

class TestDataValidation:
    """Test data validation and schema compliance"""
    
    def test_invalid_work_order_data(self, auth_tokens):
        """Test creating work order with invalid data"""
        invalid_data = {
            "title": "A",  # Too short
            "description": "Short",  # Too short
            "asset_id": "invalid-format",  # Wrong format
            "type": "invalid_type",  # Invalid enum
            "priority": "invalid_priority"  # Invalid enum
        }
        response = client.post(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=invalid_data
        )
        assert response.status_code == 422  # Validation error
    
    def test_invalid_part_number_format(self, auth_tokens):
        """Test creating part with invalid part number"""
        invalid_part = {
            "name": "Test Part",
            "part_number": "invalid format!",  # Contains invalid characters
            "category": "other",
            "unit_cost": 10.0,
            "quantity": 1,
            "min_stock": 0
        }
        response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=invalid_part
        )
        assert response.status_code == 422
    
    def test_negative_stock_adjustment(self, auth_tokens, sample_part):
        """Test negative stock adjustment that would result in negative inventory"""
        # Create part with 5 quantity
        sample_part["quantity"] = 5
        create_response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_part
        )
        part_id = create_response.json()["id"]
        
        # Try to adjust by -10 (would make it negative)
        adjustment_data = {
            "part_id": part_id,
            "adjustment_type": "issue",
            "quantity": -10,
            "reason": "Test negative adjustment",
            "performed_by": "admin"
        }
        response = client.post(
            f"/parts/{part_id}/adjust-stock",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=adjustment_data
        )
        assert response.status_code == 400

# =============================================================================
# Performance and Rate Limiting Tests
# =============================================================================

class TestPerformance:
    """Test API performance and limits"""
    
    def test_pagination_performance(self, auth_tokens):
        """Test pagination with large datasets"""
        # Test large page size
        response = client.get(
            "/parts/list/paginated?page=1&limit=1000",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["limit"] == 1000
    
    def test_bulk_operation_limits(self, auth_tokens):
        """Test bulk operation limits"""
        # Try to bulk delete with too many IDs
        large_id_list = [f"PART-{i:04d}" for i in range(1001)]  # Over limit
        delete_data = {"ids": large_id_list}
        
        response = client.post(
            "/parts/bulk-delete",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=delete_data
        )
        assert response.status_code == 422  # Should reject due to size limit

# =============================================================================
# Integration Tests
# =============================================================================

class TestIntegration:
    """Test integration between modules"""
    
    def test_work_order_part_integration(self, auth_tokens, sample_work_order, sample_part):
        """Test work order and parts integration"""
        # Create part
        part_response = client.post(
            "/parts/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_part
        )
        part_id = part_response.json()["id"]
        
        # Create work order
        wo_response = client.post(
            "/workorders/",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=sample_work_order
        )
        wo_id = wo_response.json()["id"]
        
        # Issue part to work order
        adjustment_data = {
            "part_id": part_id,
            "adjustment_type": "issue",
            "quantity": -2,
            "reason": f"Issued to work order {wo_id}",
            "reference": wo_id,
            "performed_by": "admin"
        }
        issue_response = client.post(
            f"/parts/{part_id}/adjust-stock",
            headers={"Authorization": f"Bearer {auth_tokens['admin']}"},
            json=adjustment_data
        )
        assert issue_response.status_code == 200

# =============================================================================
# Test Runner and Reporting
# =============================================================================

def run_contract_tests():
    """Run all contract tests and generate report"""
    import subprocess
    import sys
    
    # Run pytest with detailed output
    cmd = [
        sys.executable, "-m", "pytest", 
        __file__, 
        "-v", 
        "--tb=short",
        "--json-report",
        "--json-report-file=test_results.json"
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    print("STDOUT:", result.stdout)
    print("STDERR:", result.stderr)
    print("Return code:", result.returncode)
    
    return result.returncode == 0

if __name__ == "__main__":
    success = run_contract_tests()
    sys.exit(0 if success else 1)