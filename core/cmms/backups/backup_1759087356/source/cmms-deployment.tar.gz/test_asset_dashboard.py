#!/usr/bin/env python3
"""
Test Asset Dashboard Implementation
Quick test to verify the dashboard endpoints and KPI calculations work correctly
"""

import sys
import os
import asyncio
import json
from datetime import datetime

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the assets module
try:
    from assets import (
        get_asset_dashboard, get_asset_dashboard_kpis, create_asset_pm,
        calculate_mtbf, calculate_mttr, calculate_pm_compliance,
        calculate_backlog_days, calculate_uptime_percentage,
        assets_db, maintenance_history_db
    )
    from api_schemas import PMCreate, PriorityLevel
    print("✅ Successfully imported assets module and functions")
except ImportError as e:
    print(f"❌ Failed to import assets module: {e}")
    sys.exit(1)

def test_kpi_calculations():
    """Test the KPI calculation functions with mock data"""
    print("\n🧮 Testing KPI Calculations...")
    
    test_asset_id = "AST-001"  # Primary Air Compressor
    
    try:
        # Test MTBF calculation
        mtbf = calculate_mtbf(test_asset_id, 90)
        print(f"  MTBF for {test_asset_id}: {mtbf:.2f} hours")
        assert mtbf > 0, "MTBF should be positive"
        
        # Test MTTR calculation
        mttr = calculate_mttr(test_asset_id, 90)
        print(f"  MTTR for {test_asset_id}: {mttr:.2f} hours")
        assert mttr > 0, "MTTR should be positive"
        
        # Test PM Compliance
        compliance = calculate_pm_compliance(test_asset_id, 90)
        print(f"  PM Compliance for {test_asset_id}: {compliance:.1f}%")
        assert 0 <= compliance <= 100, "PM Compliance should be between 0-100%"
        
        # Test Backlog calculation
        backlog = calculate_backlog_days(test_asset_id)
        print(f"  Backlog Days for {test_asset_id}: {backlog:.1f} days")
        assert backlog >= 0, "Backlog should be non-negative"
        
        # Test Uptime calculation
        uptime = calculate_uptime_percentage(test_asset_id, 90)
        print(f"  Uptime for {test_asset_id}: {uptime:.1f}%")
        assert 0 <= uptime <= 100, "Uptime should be between 0-100%"
        
        print("✅ All KPI calculations passed!")
        return True
        
    except Exception as e:
        print(f"❌ KPI calculation test failed: {e}")
        return False

async def test_dashboard_api():
    """Test the dashboard API endpoints"""
    print("\n🌐 Testing Dashboard API Endpoints...")
    
    test_asset_id = "AST-001"
    
    try:
        # Test get_asset_dashboard
        print(f"  Testing dashboard data for {test_asset_id}...")
        dashboard_data = await get_asset_dashboard(test_asset_id)
        
        assert dashboard_data is not None, "Dashboard data should not be None"
        assert hasattr(dashboard_data, 'asset'), "Dashboard should have asset data"
        assert hasattr(dashboard_data, 'kpis'), "Dashboard should have KPIs"
        assert hasattr(dashboard_data, 'history'), "Dashboard should have history"
        
        print(f"    Asset: {dashboard_data.asset}")
        print(f"    KPIs: MTBF={dashboard_data.kpis.mtbf_hours:.1f}h, MTTR={dashboard_data.kpis.mttr_hours:.1f}h")
        print(f"    History events: {len(dashboard_data.history)}")
        
        # Test get_asset_dashboard_kpis
        print(f"  Testing KPI endpoint for {test_asset_id}...")
        kpi_data = await get_asset_dashboard_kpis(test_asset_id, 90)
        
        assert kpi_data is not None, "KPI data should not be None"
        assert kpi_data.mtbf_hours > 0, "MTBF should be positive"
        assert kpi_data.mttr_hours > 0, "MTTR should be positive"
        
        print(f"    KPI Window: {kpi_data.window_start} to {kpi_data.window_end}")
        print(f"    YTD Cost: ${kpi_data.total_cost_ytd:,.2f}")
        
        print("✅ Dashboard API tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Dashboard API test failed: {e}")
        return False

async def test_pm_creation():
    """Test PM creation endpoint"""
    print("\n📅 Testing PM Creation...")
    
    test_asset_id = "AST-001"
    
    try:
        # Create test PM data
        pm_data = PMCreate(
            name="Test Quarterly Service",
            asset_id=test_asset_id,
            frequency_days=90,
            estimated_duration=4.0,
            priority=PriorityLevel.HIGH,
            description="Test preventive maintenance for dashboard validation",
            instructions="1. Test step 1\n2. Test step 2\n3. Test step 3"
        )
        
        print(f"  Creating PM for {test_asset_id}...")
        pm_response = await create_asset_pm(test_asset_id, pm_data)
        
        assert pm_response is not None, "PM response should not be None"
        assert pm_response.id is not None, "PM should have an ID"
        assert pm_response.asset_id == test_asset_id, "PM should be for correct asset"
        
        print(f"    Created PM: {pm_response.id}")
        print(f"    Name: {pm_response.name}")
        print(f"    Next Due: {pm_response.next_due}")
        
        print("✅ PM Creation test passed!")
        return True
        
    except Exception as e:
        print(f"❌ PM Creation test failed: {e}")
        return False

def test_mock_data_integrity():
    """Test that mock data is properly structured"""
    print("\n📊 Testing Mock Data Integrity...")
    
    try:
        # Test assets database
        assert len(assets_db) > 0, "Assets database should not be empty"
        print(f"  Assets in database: {len(assets_db)}")
        
        # Test maintenance history database
        assert len(maintenance_history_db) > 0, "Maintenance history should not be empty"
        print(f"  Maintenance records: {len(maintenance_history_db)}")
        
        # Test asset structure
        first_asset = assets_db[0]
        required_fields = ['id', 'name', 'category', 'location', 'status', 'criticality']
        for field in required_fields:
            assert field in first_asset, f"Asset should have {field} field"
        
        print(f"    Sample asset: {first_asset['id']} - {first_asset['name']}")
        
        # Test maintenance history structure
        first_history = maintenance_history_db[0]
        history_fields = ['id', 'asset_id', 'date', 'type', 'technician', 'description']
        for field in history_fields:
            assert field in first_history, f"History should have {field} field"
        
        print(f"    Sample history: {first_history['id']} - {first_history['type']}")
        
        print("✅ Mock data integrity test passed!")
        return True
        
    except Exception as e:
        print(f"❌ Mock data integrity test failed: {e}")
        return False

async def run_all_tests():
    """Run all tests and summarize results"""
    print("🚀 Starting Asset Dashboard Tests")
    print("=" * 50)
    
    test_results = []
    
    # Run synchronous tests
    test_results.append(("Mock Data Integrity", test_mock_data_integrity()))
    test_results.append(("KPI Calculations", test_kpi_calculations()))
    
    # Run asynchronous tests
    test_results.append(("Dashboard API", await test_dashboard_api()))
    test_results.append(("PM Creation", await test_pm_creation()))
    
    # Summarize results
    print("\n" + "=" * 50)
    print("📋 Test Summary:")
    print("=" * 50)
    
    passed = 0
    failed = 0
    
    for test_name, result in test_results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {test_name:<25} {status}")
        if result:
            passed += 1
        else:
            failed += 1
    
    print(f"\nTotal: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All tests passed! Asset Dashboard is ready for use.")
    else:
        print("⚠️  Some tests failed. Please review the implementation.")
    
    return failed == 0

if __name__ == "__main__":
    # Run the tests
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)