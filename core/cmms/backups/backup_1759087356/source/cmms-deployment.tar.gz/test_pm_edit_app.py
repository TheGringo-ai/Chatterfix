#!/usr/bin/env python3
"""
Test application to verify PM edit functionality
This is a minimal app to test the PM edit endpoints
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pm_edit_extension import router as pm_edit_router

app = FastAPI(
    title="ChatterFix CMMS - PM Edit Test",
    description="Test application for PM edit functionality",
    version="1.0.0"
)

# Include the PM edit router
app.include_router(pm_edit_router)

@app.get("/", response_class=HTMLResponse)
async def root():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>PM Edit Test</title>
        <style>
            body { font-family: sans-serif; margin: 40px; background: #f5f5f5; }
            .card { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; }
            .btn { padding: 8px 16px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; margin: 5px; }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>🔧 PM Edit Functionality Test</h1>
            <p>Test the new PM edit endpoints:</p>
            
            <h3>PM Edit Forms:</h3>
            <a href="/cmms/preventive/PM-001/edit" class="btn">Edit PM-001</a>
            <a href="/cmms/preventive/PM-002/edit" class="btn">Edit PM-002</a>
            
            <h3>Schedule Edit Forms:</h3>
            <a href="/cmms/preventive/schedule/SCH-001/edit" class="btn">Edit Schedule SCH-001</a>
            <a href="/cmms/preventive/schedule/SCH-002/edit" class="btn">Edit Schedule SCH-002</a>
            
            <h3>API Test:</h3>
            <a href="/test/pm-edit" class="btn">Test API Endpoints</a>
            
            <h3>Documentation:</h3>
            <a href="/docs" class="btn">API Documentation</a>
        </div>
    </body>
    </html>
    """

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "PM Edit Test", "pm_edit_loaded": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8003, log_level="info")