#!/usr/bin/env python3
"""
ChatterFix CMMS - Self-Healing System Test Suite
Comprehensive testing of auto-remediation, health monitoring, and AI Ops
"""

import os
import sys
import asyncio
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

# Add current directory to path for imports
sys.path.append('.')

def print_test_header(test_name):
    """Print formatted test header"""
    print(f"\n{'='*60}")
    print(f"🧪 {test_name}")
    print(f"{'='*60}")

def print_test_result(success, message):
    """Print formatted test result"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"{status}: {message}")

async def test_health_monitoring():
    """Test the health monitoring system"""
    print_test_header("Health Monitoring System")
    
    try:
        from health_monitor import get_detailed_health_status, get_liveness_probe, get_readiness_probe
        
        # Test liveness probe
        print("Testing liveness probe...")
        liveness = await get_liveness_probe()
        print_test_result(liveness.get('alive', False), f"Liveness probe: {liveness}")
        
        # Test readiness probe  
        print("\nTesting readiness probe...")
        readiness = await get_readiness_probe()
        print_test_result(readiness.get('ready', False), f"Readiness probe: {readiness}")
        
        # Test comprehensive health check
        print("\nTesting comprehensive health check...")
        health = await get_detailed_health_status()
        
        checks_count = len(health.get('checks', {}))
        duration = health.get('check_duration_ms', 0)
        
        print(f"📊 Health Summary:")
        print(f"   Overall Status: {health.get('overall_status', 'unknown')}")
        print(f"   Checks Run: {checks_count}")
        print(f"   Duration: {duration}ms")
        
        if health.get('slo_status'):
            print(f"   SLO Status: {len(health['slo_status'])} SLOs monitored")
        
        success = checks_count > 0 and duration > 0
        print_test_result(success, "Comprehensive health monitoring functional")
        
        return success
        
    except Exception as e:
        print_test_result(False, f"Health monitoring failed: {e}")
        return False

async def test_auto_remediation_interactive():
    """Test auto-remediation with interactive sudo"""
    print_test_header("Auto-Remediation System (Interactive)")
    
    try:
        from auto_remediation import AutoRemediationEngine, handle_incident
        
        engine = AutoRemediationEngine()
        
        print("📋 Available Playbooks:")
        for name, playbook in engine.playbooks.items():
            print(f"   - {name}: {playbook.description}")
        
        # Test non-sudo remediation first
        print("\n🧹 Testing cache cleanup (no sudo required)...")
        result = await handle_incident('disk_full', 'warning', {'test_mode': True})
        
        cache_success = result.get('success', False)
        print_test_result(cache_success, f"Cache cleanup result: {result.get('message', 'No message')}")
        
        # Ask user if they want to test sudo commands
        print(f"\n🔐 Interactive sudo testing:")
        print("   The next tests require sudo permissions and will prompt for your password.")
        print("   Available sudo tests:")
        print("   1. Service restart simulation")  
        print("   2. Log cleanup (journalctl)")
        print("   3. Temporary file cleanup")
        
        user_input = input("\nDo you want to test sudo remediation? (y/N): ").lower()
        
        sudo_success = True
        if user_input == 'y':
            print("\n🔧 Testing sudo remediation...")
            print("   Note: You may be prompted for your sudo password")
            
            # Test journalctl cleanup (safer than service restart)
            try:
                print("   Testing log cleanup with sudo...")
                proc = subprocess.run(['sudo', 'journalctl', '--vacuum-time=7d'], 
                                    capture_output=True, text=True, timeout=30)
                
                if proc.returncode == 0:
                    print_test_result(True, "Sudo log cleanup successful")
                else:
                    print_test_result(False, f"Sudo log cleanup failed: {proc.stderr}")
                    sudo_success = False
                    
            except subprocess.TimeoutExpired:
                print_test_result(False, "Sudo command timed out")
                sudo_success = False
            except Exception as e:
                print_test_result(False, f"Sudo test error: {e}")
                sudo_success = False
        else:
            print("   Skipping sudo tests (user choice)")
        
        return cache_success and sudo_success
        
    except Exception as e:
        print_test_result(False, f"Auto-remediation test failed: {e}")
        return False

async def test_incident_detection():
    """Test AI Ops incident detection"""
    print_test_header("AI Ops Incident Detection")
    
    try:
        from aiops_agent import LogAnalyzer
        
        analyzer = LogAnalyzer()
        
        print(f"📝 Loaded {len(analyzer.incident_signatures)} incident signatures:")
        for sig in analyzer.incident_signatures:
            print(f"   - {sig.name}: {sig.severity} ({sig.category})")
        
        # Test log parsing with various incident types
        test_cases = [
            {
                'log': '2024-12-01 15:30:00 - systemd: Failed to start chatterfix-cmms.service',
                'expected': 'service_crash'
            },
            {
                'log': '2024-12-01 15:31:00 - ERROR: Memory usage at 95% - critical level',
                'expected': 'high_memory_usage' 
            },
            {
                'log': '2024-12-01 15:32:00 - CRITICAL: Disk usage 98% full on /var/log',
                'expected': 'disk_space_low'
            },
            {
                'log': '2024-12-01 15:33:00 - SSL certificate expired for domain.com',
                'expected': 'ssl_certificate_error'
            },
            {
                'log': '2024-12-01 15:34:00 - INFO: System running normally',
                'expected': None
            }
        ]
        
        detected_count = 0
        total_expected = sum(1 for case in test_cases if case['expected'])
        
        print(f"\n🔍 Testing incident detection with {len(test_cases)} log entries...")
        
        for i, case in enumerate(test_cases, 1):
            log_entry = analyzer.parse_log_line(case['log'], 'test')
            incidents = analyzer.analyze_log_entry(log_entry) if log_entry else []
            
            detected_incidents = [inc.signature.name for inc in incidents]
            expected = case['expected']
            
            if expected:
                if expected in detected_incidents:
                    print(f"   ✅ Test {i}: Detected '{expected}' as expected")
                    detected_count += 1
                else:
                    print(f"   ❌ Test {i}: Expected '{expected}', got {detected_incidents}")
            else:
                if not incidents:
                    print(f"   ✅ Test {i}: No incident detected (correct)")
                    detected_count += 1
                else:
                    print(f"   ⚠️  Test {i}: Unexpected incidents: {detected_incidents}")
        
        detection_rate = (detected_count / len(test_cases)) * 100
        print(f"\n📊 Detection Results:")
        print(f"   Accuracy: {detection_rate:.1f}% ({detected_count}/{len(test_cases)})")
        print(f"   Expected incidents: {total_expected}")
        print(f"   Correctly detected: {min(detected_count, total_expected)}")
        
        success = detection_rate >= 80  # 80% accuracy threshold
        print_test_result(success, f"Incident detection accuracy: {detection_rate:.1f}%")
        
        return success
        
    except Exception as e:
        print_test_result(False, f"Incident detection test failed: {e}")
        return False

async def test_ai_memory_integration():
    """Test AI memory session recording"""
    print_test_header("AI Memory Integration")
    
    try:
        # Check if ai-memory directory exists
        memory_dir = Path("ai-memory")
        sessions_dir = memory_dir / "sessions"
        lessons_dir = memory_dir / "lessons"
        
        print("📁 Checking AI memory directory structure...")
        
        # Create directories if they don't exist
        sessions_dir.mkdir(parents=True, exist_ok=True)
        lessons_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"   Sessions dir: {sessions_dir} ({'exists' if sessions_dir.exists() else 'created'})")
        print(f"   Lessons dir: {lessons_dir} ({'exists' if lessons_dir.exists() else 'created'})")
        
        # Test session recording by running a remediation
        print("\n📝 Testing session recording...")
        
        from auto_remediation import handle_incident
        
        # This will create a session record
        result = await handle_incident('test_incident', 'warning', {'test': 'session_recording'})
        
        # Check if session was recorded
        session_files = list(sessions_dir.glob("*.json"))
        recent_sessions = [f for f in session_files 
                          if f.stat().st_mtime > (time.time() - 60)]  # Last minute
        
        print(f"   Total session files: {len(session_files)}")
        print(f"   Recent sessions: {len(recent_sessions)}")
        
        if recent_sessions:
            latest_session = max(recent_sessions, key=lambda f: f.stat().st_mtime)
            print(f"   Latest session: {latest_session.name}")
            
            # Read and validate session content
            import json
            with open(latest_session) as f:
                session_data = json.load(f)
            
            required_fields = ['timestamp', 'type', 'playbook', 'result']
            has_required = all(field in session_data for field in required_fields)
            
            print_test_result(has_required, f"Session data structure valid")
        
        # Test daily summary generation (simulation)
        print("\n📊 Testing daily summary generation...")
        
        from aiops_agent import AIOperationsAgent
        agent = AIOperationsAgent()
        
        from datetime import date, timedelta
        yesterday = date.today() - timedelta(days=1)
        
        summary = await agent._generate_daily_summary(yesterday)
        
        summary_valid = "Daily Operational Summary" in summary and len(summary) > 100
        print_test_result(summary_valid, f"Daily summary generated ({len(summary)} chars)")
        
        if summary_valid:
            # Save test summary
            test_summary_file = lessons_dir / f"test_summary_{yesterday.strftime('%Y%m%d')}.md"
            with open(test_summary_file, 'w') as f:
                f.write(summary)
            print(f"   Test summary saved: {test_summary_file.name}")
        
        return len(recent_sessions) > 0 and summary_valid
        
    except Exception as e:
        print_test_result(False, f"AI memory integration test failed: {e}")
        return False

def test_service_files():
    """Test systemd service files"""
    print_test_header("Service Files Validation")
    
    service_files = [
        'chatterfix-aiops.service',
        'chatterfix-health-monitor.service', 
        'chatterfix-health-check.service',
        'chatterfix-daily-summary.service'
    ]
    
    timer_files = [
        'chatterfix-health-monitor.timer',
        'chatterfix-daily-summary.timer'
    ]
    
    all_valid = True
    
    print("📄 Checking service files...")
    for service_file in service_files:
        if Path(service_file).exists():
            print(f"   ✅ {service_file} exists")
        else:
            print(f"   ❌ {service_file} missing")
            all_valid = False
    
    print("\n⏰ Checking timer files...")
    for timer_file in timer_files:
        if Path(timer_file).exists():
            print(f"   ✅ {timer_file} exists")
        else:
            print(f"   ❌ {timer_file} missing")
            all_valid = False
    
    # Check script files
    scripts_dir = Path("../scripts")
    script_files = ['health-check.sh', 'install-self-healing.sh']
    
    print(f"\n📜 Checking script files in {scripts_dir}...")
    for script_file in script_files:
        script_path = scripts_dir / script_file
        if script_path.exists():
            is_executable = os.access(script_path, os.X_OK)
            status = "✅" if is_executable else "⚠️ "
            exec_note = "executable" if is_executable else "not executable"
            print(f"   {status} {script_file} exists ({exec_note})")
        else:
            print(f"   ❌ {script_file} missing")
            all_valid = False
    
    print_test_result(all_valid, "All required files present")
    return all_valid

async def run_full_test_suite():
    """Run the complete self-healing test suite"""
    print("🚀 ChatterFix CMMS Self-Healing System Test Suite")
    print(f"Started at: {datetime.now().isoformat()}")
    
    test_results = {}
    
    # Run all tests
    test_results['health_monitoring'] = await test_health_monitoring()
    test_results['auto_remediation'] = await test_auto_remediation_interactive()
    test_results['incident_detection'] = await test_incident_detection()
    test_results['ai_memory'] = await test_ai_memory_integration()
    test_results['service_files'] = test_service_files()
    
    # Summary
    print_test_header("Test Suite Summary")
    
    passed = sum(test_results.values())
    total = len(test_results)
    success_rate = (passed / total) * 100
    
    print(f"📊 Results:")
    for test_name, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status} {test_name.replace('_', ' ').title()}")
    
    print(f"\n🎯 Overall Success Rate: {success_rate:.1f}% ({passed}/{total})")
    
    if success_rate >= 80:
        print("\n🎉 Self-healing system is ready for deployment!")
    else:
        print("\n⚠️  Some tests failed. Review issues before deployment.")
    
    # Next steps
    print(f"\n📋 Next Steps:")
    if test_results['service_files']:
        print("   1. Install systemd services: sudo scripts/install-self-healing.sh")
    if test_results['health_monitoring']:
        print("   2. Enable health monitoring: sudo systemctl enable --now chatterfix-health-monitor.timer")
    if test_results['auto_remediation']:
        print("   3. Start AI Ops agent: sudo systemctl enable --now chatterfix-aiops.service")
    
    return success_rate >= 80

if __name__ == "__main__":
    try:
        success = asyncio.run(run_full_test_suite())
        exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n🛑 Test suite interrupted by user")
        exit(130)
    except Exception as e:
        print(f"\n❌ Test suite failed: {e}")
        exit(1)