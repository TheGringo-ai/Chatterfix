#!/usr/bin/env python3
"""
Voice Recognition Performance Test Suite
Tests accuracy and latency requirements for ChatterFix CMMS voice interface
"""

import asyncio
import time
import statistics
import json
import logging
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict

from voice_router import VoiceCommandRequest, VoiceRouter
from auth_rbac import AuthUser

logger = logging.getLogger(__name__)

@dataclass
class TestCommand:
    text: str
    expected_intent: str
    expected_entities: Dict[str, Any]
    expected_success: bool = True

@dataclass
class TestResult:
    command: str
    expected_intent: str
    actual_intent: str
    expected_entities: Dict[str, Any]
    actual_entities: Dict[str, Any]
    expected_success: bool
    actual_success: bool
    response_time_ms: float
    confidence: float
    intent_match: bool
    entity_match: bool
    overall_success: bool

@dataclass
class PerformanceMetrics:
    total_commands: int
    successful_commands: int
    intent_accuracy: float
    entity_accuracy: float
    overall_accuracy: float
    avg_response_time_ms: float
    median_response_time_ms: float
    p95_response_time_ms: float
    max_response_time_ms: float
    min_response_time_ms: float
    accuracy_requirement_met: bool
    latency_requirement_met: bool
    test_passed: bool

class VoicePerformanceTest:
    """Comprehensive voice recognition performance test suite"""
    
    def __init__(self):
        self.voice_router = VoiceRouter()
        self.test_user = AuthUser(
            user_id="test_user",
            username="test_user",
            email="test@example.com",
            role="technician"
        )
        
        # Performance requirements
        self.accuracy_requirement = 0.95  # 95%
        self.latency_requirement = 1200   # 1.2 seconds in ms
        
        # Test command sets
        self.test_commands = self._create_test_commands()
        
    def _create_test_commands(self) -> List[TestCommand]:
        """Create comprehensive test command set"""
        
        return [
            # Work Order Creation Commands
            TestCommand(
                text="Create work order for PUMP-001 high priority",
                expected_intent="create_work_order",
                expected_entities={"asset_id": "PUMP-001", "priority": "high"}
            ),
            TestCommand(
                text="New work order for MOTOR-045 tomorrow medium priority",
                expected_intent="create_work_order", 
                expected_entities={"asset_id": "MOTOR-045", "priority": "medium", "date": "2025-09-08"}
            ),
            TestCommand(
                text="Add maintenance for VALVE-123 urgent",
                expected_intent="create_work_order",
                expected_entities={"asset_id": "VALVE-123", "priority": "urgent"}
            ),
            
            # Asset Listing Commands
            TestCommand(
                text="List critical assets",
                expected_intent="list_assets",
                expected_entities={}
            ),
            TestCommand(
                text="Show me high priority equipment",
                expected_intent="list_assets",
                expected_entities={}
            ),
            TestCommand(
                text="What assets need attention",
                expected_intent="list_assets",
                expected_entities={}
            ),
            
            # Parts Management Commands
            TestCommand(
                text="What parts need reordering",
                expected_intent="reorder_parts",
                expected_entities={}
            ),
            TestCommand(
                text="Check inventory levels",
                expected_intent="reorder_parts",
                expected_entities={}
            ),
            TestCommand(
                text="Show low stock items",
                expected_intent="reorder_parts",
                expected_entities={}
            ),
            
            # Asset Search Commands
            TestCommand(
                text="Find asset PUMP-001",
                expected_intent="search_asset",
                expected_entities={"asset_id": "PUMP-001"}
            ),
            TestCommand(
                text="Search for MOTOR-045",
                expected_intent="search_asset",
                expected_entities={"asset_id": "MOTOR-045"}
            ),
            TestCommand(
                text="Show me COMPRESSOR-007",
                expected_intent="search_asset",
                expected_entities={"asset_id": "COMPRESSOR-007"}
            ),
            
            # Report Generation Commands
            TestCommand(
                text="Generate maintenance report",
                expected_intent="generate_report",
                expected_entities={"report_type": "maintenance"}
            ),
            TestCommand(
                text="Create inventory report",
                expected_intent="generate_report",
                expected_entities={"report_type": "inventory"}
            ),
            TestCommand(
                text="Show me asset analytics",
                expected_intent="generate_report",
                expected_entities={}
            ),
            
            # Help and Status Commands
            TestCommand(
                text="Help",
                expected_intent="help",
                expected_entities={}
            ),
            TestCommand(
                text="What can you do",
                expected_intent="help",
                expected_entities={}
            ),
            TestCommand(
                text="Available commands",
                expected_intent="help",
                expected_entities={}
            ),
            
            # Edge Cases and Error Conditions
            TestCommand(
                text="Create work order",  # Missing asset
                expected_intent="create_work_order",
                expected_entities={},
                expected_success=True  # Should ask for more info
            ),
            TestCommand(
                text="Blah blah nonsense command",  # Unrecognizable
                expected_intent=None,
                expected_entities={},
                expected_success=False
            ),
            
            # Complex Commands with Multiple Entities
            TestCommand(
                text="Create work order for GENERATOR-019 tomorrow high priority with 4 hour estimate",
                expected_intent="create_work_order",
                expected_entities={
                    "asset_id": "GENERATOR-019", 
                    "priority": "high", 
                    "date": "2025-09-08"
                }
            ),
            
            # Natural Language Variations
            TestCommand(
                text="I need to create a maintenance task for pump one zero one with high priority",
                expected_intent="create_work_order",
                expected_entities={"asset_id": "PUMP-101", "priority": "high"}
            ),
            
            # Schedule Commands
            TestCommand(
                text="Schedule preventive maintenance for all pumps next week",
                expected_intent="schedule_maintenance",
                expected_entities={"date": "2025-09-14"}
            ),
            
            # Manual Search Commands
            TestCommand(
                text="What is the torque specification for coupling bolts",
                expected_intent="search_manual",
                expected_entities={}
            ),
        ]
    
    async def run_performance_test(self) -> PerformanceMetrics:
        """Run comprehensive performance test suite"""
        
        print("🧪 Starting Voice Recognition Performance Test")
        print(f"📊 Testing {len(self.test_commands)} commands")
        print(f"🎯 Accuracy requirement: {self.accuracy_requirement:.0%}")
        print(f"⏱️  Latency requirement: {self.latency_requirement}ms")
        print("-" * 60)
        
        results = []
        response_times = []
        
        for i, test_cmd in enumerate(self.test_commands, 1):
            print(f"\n[{i:2d}/{len(self.test_commands)}] Testing: \"{test_cmd.text}\"")
            
            result = await self._test_single_command(test_cmd)
            results.append(result)
            response_times.append(result.response_time_ms)
            
            # Print result
            status = "✅" if result.overall_success else "❌"
            print(f"    {status} Intent: {result.actual_intent} | "
                  f"Time: {result.response_time_ms:.0f}ms | "
                  f"Confidence: {result.confidence:.0%}")
            
            if not result.overall_success:
                print(f"    ⚠️  Expected: {result.expected_intent}, Got: {result.actual_intent}")
        
        # Calculate metrics
        metrics = self._calculate_metrics(results, response_times)
        
        # Print summary
        self._print_test_summary(metrics)
        
        return metrics
    
    async def _test_single_command(self, test_cmd: TestCommand) -> TestResult:
        """Test a single voice command"""
        
        start_time = time.time()
        
        try:
            # Create voice command request
            request = VoiceCommandRequest(
                command=test_cmd.text,
                confidence=0.8  # Simulate good recognition confidence
            )
            
            # Process command
            response = await self.voice_router.process_voice_command(request, self.test_user)
            
            end_time = time.time()
            response_time_ms = (end_time - start_time) * 1000
            
            # Evaluate results
            intent_match = response.intent == test_cmd.expected_intent
            entity_match = self._compare_entities(response.entities, test_cmd.expected_entities)
            overall_success = intent_match and entity_match and (response.success == test_cmd.expected_success)
            
            return TestResult(
                command=test_cmd.text,
                expected_intent=test_cmd.expected_intent,
                actual_intent=response.intent,
                expected_entities=test_cmd.expected_entities,
                actual_entities=response.entities,
                expected_success=test_cmd.expected_success,
                actual_success=response.success,
                response_time_ms=response_time_ms,
                confidence=response.confidence,
                intent_match=intent_match,
                entity_match=entity_match,
                overall_success=overall_success
            )
            
        except Exception as e:
            end_time = time.time()
            response_time_ms = (end_time - start_time) * 1000
            
            logger.error(f"Command test failed: {e}")
            
            return TestResult(
                command=test_cmd.text,
                expected_intent=test_cmd.expected_intent,
                actual_intent=None,
                expected_entities=test_cmd.expected_entities,
                actual_entities={},
                expected_success=test_cmd.expected_success,
                actual_success=False,
                response_time_ms=response_time_ms,
                confidence=0.0,
                intent_match=False,
                entity_match=False,
                overall_success=False
            )
    
    def _compare_entities(self, actual: Dict[str, Any], expected: Dict[str, Any]) -> bool:
        """Compare extracted entities with expected entities"""
        
        # If no entities expected, any result is acceptable
        if not expected:
            return True
        
        # Check that all expected entities are present and match
        for key, expected_value in expected.items():
            if key not in actual:
                return False
            
            actual_value = actual[key]
            
            # Handle different types of comparisons
            if isinstance(expected_value, str):
                if expected_value.lower() != str(actual_value).lower():
                    return False
            elif expected_value != actual_value:
                return False
        
        return True
    
    def _calculate_metrics(self, results: List[TestResult], response_times: List[float]) -> PerformanceMetrics:
        """Calculate comprehensive performance metrics"""
        
        total_commands = len(results)
        successful_commands = sum(1 for r in results if r.overall_success)
        
        intent_matches = sum(1 for r in results if r.intent_match)
        entity_matches = sum(1 for r in results if r.entity_match)
        
        intent_accuracy = intent_matches / total_commands if total_commands > 0 else 0
        entity_accuracy = entity_matches / total_commands if total_commands > 0 else 0
        overall_accuracy = successful_commands / total_commands if total_commands > 0 else 0
        
        avg_response_time = statistics.mean(response_times)
        median_response_time = statistics.median(response_times)
        
        sorted_times = sorted(response_times)
        p95_index = int(0.95 * len(sorted_times))
        p95_response_time = sorted_times[p95_index] if sorted_times else 0
        
        max_response_time = max(response_times) if response_times else 0
        min_response_time = min(response_times) if response_times else 0
        
        # Check requirements
        accuracy_requirement_met = overall_accuracy >= self.accuracy_requirement
        latency_requirement_met = p95_response_time <= self.latency_requirement
        test_passed = accuracy_requirement_met and latency_requirement_met
        
        return PerformanceMetrics(
            total_commands=total_commands,
            successful_commands=successful_commands,
            intent_accuracy=intent_accuracy,
            entity_accuracy=entity_accuracy,
            overall_accuracy=overall_accuracy,
            avg_response_time_ms=avg_response_time,
            median_response_time_ms=median_response_time,
            p95_response_time_ms=p95_response_time,
            max_response_time_ms=max_response_time,
            min_response_time_ms=min_response_time,
            accuracy_requirement_met=accuracy_requirement_met,
            latency_requirement_met=latency_requirement_met,
            test_passed=test_passed
        )
    
    def _print_test_summary(self, metrics: PerformanceMetrics):
        """Print comprehensive test summary"""
        
        print("\n" + "=" * 60)
        print("🎯 VOICE RECOGNITION PERFORMANCE TEST RESULTS")
        print("=" * 60)
        
        # Overall Status
        status_icon = "✅" if metrics.test_passed else "❌"
        print(f"{status_icon} OVERALL STATUS: {'PASSED' if metrics.test_passed else 'FAILED'}")
        print()
        
        # Accuracy Metrics
        print("📊 ACCURACY METRICS:")
        print(f"   Overall Accuracy:     {metrics.overall_accuracy:.1%} {'✅' if metrics.accuracy_requirement_met else '❌'} (req: {self.accuracy_requirement:.0%})")
        print(f"   Intent Recognition:   {metrics.intent_accuracy:.1%}")
        print(f"   Entity Extraction:    {metrics.entity_accuracy:.1%}")
        print(f"   Successful Commands:  {metrics.successful_commands}/{metrics.total_commands}")
        print()
        
        # Latency Metrics
        print("⏱️  LATENCY METRICS:")
        print(f"   Average Response:     {metrics.avg_response_time_ms:.0f}ms")
        print(f"   Median Response:      {metrics.median_response_time_ms:.0f}ms")
        print(f"   95th Percentile:      {metrics.p95_response_time_ms:.0f}ms {'✅' if metrics.latency_requirement_met else '❌'} (req: {self.latency_requirement}ms)")
        print(f"   Max Response:         {metrics.max_response_time_ms:.0f}ms")
        print(f"   Min Response:         {metrics.min_response_time_ms:.0f}ms")
        print()
        
        # Requirements Check
        print("✅ REQUIREMENTS CHECK:")
        print(f"   Accuracy ≥ {self.accuracy_requirement:.0%}:     {'✅ PASS' if metrics.accuracy_requirement_met else '❌ FAIL'}")
        print(f"   Latency ≤ {self.latency_requirement}ms:    {'✅ PASS' if metrics.latency_requirement_met else '❌ FAIL'}")
        print()
        
        if metrics.test_passed:
            print("🎉 All performance requirements met!")
        else:
            print("⚠️  Performance requirements not met. Review failed commands.")
        
        print("=" * 60)
    
    async def save_test_report(self, metrics: PerformanceMetrics, filename: str = None):
        """Save detailed test report to file"""
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"voice_performance_test_{timestamp}.json"
        
        report = {
            "test_info": {
                "timestamp": datetime.now().isoformat(),
                "total_commands": len(self.test_commands),
                "accuracy_requirement": self.accuracy_requirement,
                "latency_requirement": self.latency_requirement
            },
            "metrics": asdict(metrics),
            "test_commands": [asdict(cmd) for cmd in self.test_commands]
        }
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"📄 Test report saved to: {filename}")
    
    async def run_stress_test(self, iterations: int = 100) -> Dict[str, Any]:
        """Run stress test with repeated commands"""
        
        print(f"🔥 Starting stress test with {iterations} iterations")
        
        stress_times = []
        errors = 0
        
        # Use a subset of commands for stress testing
        stress_commands = self.test_commands[:5]  # First 5 commands
        
        for i in range(iterations):
            test_cmd = stress_commands[i % len(stress_commands)]
            
            try:
                result = await self._test_single_command(test_cmd)
                stress_times.append(result.response_time_ms)
                
                if i % 10 == 0:
                    print(f"   Progress: {i}/{iterations} commands processed")
                    
            except Exception as e:
                errors += 1
                logger.error(f"Stress test error: {e}")
        
        avg_stress_time = statistics.mean(stress_times) if stress_times else 0
        max_stress_time = max(stress_times) if stress_times else 0
        
        print(f"🔥 Stress test completed:")
        print(f"   Average response time: {avg_stress_time:.0f}ms")
        print(f"   Max response time: {max_stress_time:.0f}ms")
        print(f"   Errors: {errors}/{iterations}")
        
        return {
            "iterations": iterations,
            "avg_response_time_ms": avg_stress_time,
            "max_response_time_ms": max_stress_time,
            "errors": errors,
            "error_rate": errors / iterations if iterations > 0 else 0
        }

async def main():
    """Run the complete performance test suite"""
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Initialize test suite
    test_suite = VoicePerformanceTest()
    
    try:
        # Run main performance test
        metrics = await test_suite.run_performance_test()
        
        # Save report
        await test_suite.save_test_report(metrics)
        
        # Run stress test if main test passed
        if metrics.test_passed:
            print("\n" + "🔥" * 20)
            stress_results = await test_suite.run_stress_test(50)
            print("🔥" * 20)
        
        return metrics.test_passed
        
    except Exception as e:
        logger.error(f"Test suite failed: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)