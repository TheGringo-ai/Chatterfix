#!/usr/bin/env python3
"""
Voice Command Router for ChatterFix CMMS
Routes voice commands to appropriate endpoints with high accuracy
"""

import re
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from ai_pipeline import NLPProcessor
from auth_rbac import get_current_user, AuthUser, require_permissions, Permission
from audit_trail import audit_create, AuditContext

logger = logging.getLogger(__name__)

# Voice Command Models
class VoiceCommandRequest(BaseModel):
    command: str = Field(..., min_length=1, max_length=500, description="Spoken command text")
    intent: Optional[str] = Field(None, description="Pre-detected intent (optional)")
    confidence: float = Field(0.7, ge=0.0, le=1.0, description="Recognition confidence")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional context")

class VoiceCommandResponse(BaseModel):
    success: bool
    message: str
    intent: Optional[str] = None
    entities: Dict[str, Any] = Field(default_factory=dict)
    action_taken: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
    suggestions: List[str] = Field(default_factory=list)
    confidence: float = 0.0

class VoiceSession(BaseModel):
    session_id: str
    user_id: str
    start_time: datetime
    commands_processed: int = 0
    avg_confidence: float = 0.0
    success_rate: float = 0.0

class VoiceRouter:
    """Voice command router with intent-based routing"""
    
    def __init__(self):
        self.nlp_processor = NLPProcessor()
        self.sessions: Dict[str, VoiceSession] = {}
        self.command_history: List[Dict] = []
        
        # Command routing table
        self.route_table = {
            'create_work_order': self._handle_create_work_order,
            'list_assets': self._handle_list_assets,
            'list_parts': self._handle_list_parts,
            'reorder_parts': self._handle_reorder_parts,
            'search_asset': self._handle_search_asset,
            'generate_report': self._handle_generate_report,
            'check_asset': self._handle_check_asset,
            'schedule_maintenance': self._handle_schedule_maintenance,
            'search_manual': self._handle_search_manual,
            'help': self._handle_help,
            'status': self._handle_status
        }
        
        # Entity extractors
        self.entity_patterns = {
            'asset_id': [
                r'\b([A-Z]+-\d+)\b',  # PUMP-001, MOTOR-123
                r'\b(pump|motor|valve|compressor|generator)[-\s]*(\d+)\b',
                r'\basset\s+([A-Z0-9\-]+)\b'
            ],
            'priority': [
                r'\b(high|medium|low|urgent|critical|normal)\s*priority\b',
                r'\b(urgent|critical|high|medium|low)\b'
            ],
            'date': [
                r'\b(today|tomorrow|yesterday)\b',
                r'\bnext\s+(week|month|monday|tuesday|wednesday|thursday|friday)\b',
                r'\bin\s+(\d+)\s+(days?|weeks?|months?)\b',
                r'\b(\d{1,2}\/\d{1,2}\/\d{4})\b'  # MM/DD/YYYY
            ],
            'quantity': [
                r'\b(\d+)\s+(parts?|items?|units?)\b',
                r'\bquantity\s+(\d+)\b',
                r'\border\s+(\d+)\b'
            ],
            'report_type': [
                r'\b(maintenance|inventory|asset|work\s*order|downtime|cost)\s+report\b',
                r'\breport\s+(?:on|for|about)\s+(\w+)\b'
            ]
        }
    
    async def process_voice_command(self, request: VoiceCommandRequest, user: AuthUser) -> VoiceCommandResponse:
        """Process a voice command and route to appropriate handler"""
        
        try:
            # Log command for audit
            await audit_create(AuditContext(
                user_id=user.user_id,
                action="voice_command",
                resource_type="voice",
                resource_id="command",
                payload={"command": request.command, "confidence": request.confidence}
            ))
            
            # Process command with NLP
            nlp_result = self.nlp_processor.process_command(request.command)
            
            # Extract entities
            entities = self._extract_entities(request.command)
            entities.update(nlp_result.entities)
            
            # Determine intent
            intent = request.intent or nlp_result.intent
            if not intent:
                intent = self._classify_intent(request.command)
            
            confidence = max(request.confidence, nlp_result.confidence)
            
            # Route to appropriate handler
            if intent in self.route_table:
                handler = self.route_table[intent]
                response_data = await handler(request.command, entities, user)
                
                response = VoiceCommandResponse(
                    success=True,
                    message=response_data.get('message', 'Command executed successfully'),
                    intent=intent,
                    entities=entities,
                    action_taken=response_data.get('action'),
                    data=response_data.get('data'),
                    confidence=confidence
                )
            else:
                # Unknown command
                suggestions = self._get_suggestions(request.command)
                response = VoiceCommandResponse(
                    success=False,
                    message="I don't understand that command. Try saying 'help' for available commands.",
                    intent=None,
                    entities=entities,
                    suggestions=suggestions,
                    confidence=confidence
                )
            
            # Update command history
            self._update_history(request.command, intent, confidence, response.success, user.user_id)
            
            return response
            
        except Exception as e:
            logger.error(f"Voice command processing failed: {e}")
            return VoiceCommandResponse(
                success=False,
                message=f"Sorry, there was an error processing your command: {str(e)}",
                confidence=request.confidence
            )
    
    def _extract_entities(self, text: str) -> Dict[str, Any]:
        """Extract entities from command text using regex patterns"""
        entities = {}
        
        for entity_type, patterns in self.entity_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    if entity_type == 'asset_id':
                        if match.lastindex == 1:
                            entities[entity_type] = match.group(1).upper()
                        else:
                            # Construct asset ID from parts
                            prefix = match.group(1).upper()
                            number = match.group(2)
                            entities[entity_type] = f"{prefix}-{number.zfill(3)}"
                    
                    elif entity_type == 'priority':
                        priority = match.group(1).lower()
                        entities[entity_type] = priority
                    
                    elif entity_type == 'date':
                        date_str = match.group(1).lower()
                        entities[entity_type] = self._parse_relative_date(date_str)
                    
                    elif entity_type == 'quantity':
                        entities[entity_type] = int(match.group(1))
                    
                    elif entity_type == 'report_type':
                        entities[entity_type] = match.group(1).lower()
                    
                    break  # Take first match for each entity type
        
        return entities
    
    def _parse_relative_date(self, date_str: str) -> str:
        """Parse relative date strings to actual dates"""
        today = datetime.now().date()
        
        if date_str == 'today':
            return today.isoformat()
        elif date_str == 'tomorrow':
            return (today + timedelta(days=1)).isoformat()
        elif date_str == 'yesterday':
            return (today - timedelta(days=1)).isoformat()
        elif 'next week' in date_str:
            return (today + timedelta(weeks=1)).isoformat()
        elif 'next month' in date_str:
            return (today + timedelta(days=30)).isoformat()
        else:
            return date_str  # Return as-is if can't parse
    
    def _classify_intent(self, text: str) -> Optional[str]:
        """Classify intent using keyword matching as fallback"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['create', 'new', 'add']) and 'work order' in text_lower:
            return 'create_work_order'
        elif any(word in text_lower for word in ['list', 'show', 'display']) and 'asset' in text_lower:
            return 'list_assets'
        elif 'parts' in text_lower and any(word in text_lower for word in ['need', 'reorder', 'low']):
            return 'reorder_parts'
        elif 'report' in text_lower:
            return 'generate_report'
        elif any(word in text_lower for word in ['find', 'search', 'locate']):
            return 'search_asset'
        elif 'help' in text_lower:
            return 'help'
        elif 'status' in text_lower:
            return 'status'
        
        return None
    
    def _get_suggestions(self, text: str) -> List[str]:
        """Get command suggestions based on partial matches"""
        suggestions = [
            "Create work order for PUMP-001 high priority",
            "List critical assets",
            "What parts need reordering?",
            "Generate maintenance report",
            "Search for MOTOR-045",
            "Help"
        ]
        
        # Simple similarity matching could be improved
        text_lower = text.lower()
        filtered = []
        
        for suggestion in suggestions:
            if any(word in text_lower for word in suggestion.lower().split()[:3]):
                filtered.append(suggestion)
        
        return filtered[:3]  # Return top 3 suggestions
    
    async def _handle_create_work_order(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle work order creation commands"""
        
        # Extract required information
        asset_id = entities.get('asset_id')
        priority = entities.get('priority', 'medium')
        due_date = entities.get('date')
        
        if not asset_id:
            return {
                'message': 'I need an asset ID to create a work order. Please specify which equipment.',
                'action': 'request_asset_id'
            }
        
        # Mock work order creation (in production, integrate with actual work order system)
        work_order_data = {
            'id': f'WO-{datetime.now().strftime("%Y%m%d")}-001',
            'title': f'Maintenance for {asset_id}',
            'asset_id': asset_id,
            'priority': priority,
            'due_date': due_date,
            'created_by': user.user_id,
            'status': 'open'
        }
        
        return {
            'message': f'Work order {work_order_data["id"]} created for {asset_id} with {priority} priority.',
            'action': 'work_order_created',
            'data': {'work_order': work_order_data}
        }
    
    async def _handle_list_assets(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle asset listing commands"""
        
        # Mock asset data (in production, query actual asset database)
        critical_assets = [
            {'id': 'PUMP-001', 'status': 'needs_maintenance', 'priority': 'high'},
            {'id': 'MOTOR-045', 'status': 'operational', 'priority': 'medium'},
            {'id': 'VALVE-123', 'status': 'requires_inspection', 'priority': 'high'},
            {'id': 'COMPRESSOR-007', 'status': 'down', 'priority': 'critical'}
        ]
        
        # Filter based on command
        if 'critical' in command.lower():
            assets = [a for a in critical_assets if a['priority'] in ['high', 'critical']]
            message = f'Found {len(assets)} critical assets requiring attention.'
        else:
            assets = critical_assets
            message = f'Found {len(assets)} assets in the system.'
        
        return {
            'message': message,
            'action': 'assets_listed',
            'data': {'assets': assets}
        }
    
    async def _handle_list_parts(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle parts listing commands"""
        
        # Mock parts data
        all_parts = [
            {'name': 'Pump Seal Kit', 'current_stock': 2, 'min_stock': 5, 'location': 'A-1-3'},
            {'name': 'Motor Bearings', 'current_stock': 1, 'min_stock': 3, 'location': 'B-2-1'},
            {'name': 'Valve Actuator', 'current_stock': 0, 'min_stock': 2, 'location': 'C-1-5'}
        ]
        
        return {
            'message': f'Found {len(all_parts)} parts in inventory.',
            'action': 'parts_listed',
            'data': {'parts': all_parts}
        }
    
    async def _handle_reorder_parts(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle parts reordering commands"""
        
        # Mock low stock parts
        low_stock_parts = [
            {'name': 'Pump Seal Kit', 'current_stock': 2, 'min_stock': 5, 'location': 'A-1-3'},
            {'name': 'Motor Bearings', 'current_stock': 1, 'min_stock': 3, 'location': 'B-2-1'},
            {'name': 'Valve Actuator', 'current_stock': 0, 'min_stock': 2, 'location': 'C-1-5'}
        ]
        
        return {
            'message': f'{len(low_stock_parts)} parts need reordering. Check your screen for details.',
            'action': 'reorder_list_generated',
            'data': {'parts': low_stock_parts}
        }
    
    async def _handle_search_asset(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle asset search commands"""
        
        asset_id = entities.get('asset_id')
        
        if not asset_id:
            return {
                'message': 'Please specify which asset you want to search for.',
                'action': 'request_asset_id'
            }
        
        # Mock asset lookup
        asset_info = {
            'id': asset_id,
            'name': f'Equipment {asset_id}',
            'status': 'operational',
            'location': 'Building A, Room 101',
            'last_maintenance': '2024-08-15',
            'next_maintenance': '2024-12-15'
        }
        
        return {
            'message': f'Found asset {asset_id}. Status: {asset_info["status"]}. Location: {asset_info["location"]}.',
            'action': 'asset_found',
            'data': {'asset': asset_info}
        }
    
    async def _handle_generate_report(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle report generation commands"""
        
        report_type = entities.get('report_type', 'maintenance')
        
        # Mock report generation
        report_data = {
            'type': report_type,
            'generated_at': datetime.now().isoformat(),
            'total_items': 25,
            'summary': f'{report_type.title()} report generated successfully'
        }
        
        return {
            'message': f'{report_type.title()} report generated with {report_data["total_items"]} items.',
            'action': 'report_generated',
            'data': {'report': report_data}
        }
    
    async def _handle_check_asset(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle asset status check commands"""
        
        asset_id = entities.get('asset_id')
        
        if not asset_id:
            return {
                'message': 'Which asset would you like me to check?',
                'action': 'request_asset_id'
            }
        
        # Mock status check
        status_info = {
            'asset_id': asset_id,
            'status': 'operational',
            'health_score': 85,
            'last_check': datetime.now().isoformat()
        }
        
        return {
            'message': f'Asset {asset_id} is {status_info["status"]} with {status_info["health_score"]}% health score.',
            'action': 'status_checked',
            'data': {'status': status_info}
        }
    
    async def _handle_schedule_maintenance(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle maintenance scheduling commands"""
        
        asset_id = entities.get('asset_id')
        date = entities.get('date')
        
        # Mock scheduling
        schedule_info = {
            'asset_id': asset_id or 'multiple',
            'scheduled_date': date or 'next_available',
            'task_id': f'MAINT-{datetime.now().strftime("%Y%m%d")}-001'
        }
        
        message = f'Maintenance scheduled for {schedule_info["scheduled_date"]}'
        if asset_id:
            message += f' for asset {asset_id}'
        
        return {
            'message': message + f'. Task ID: {schedule_info["task_id"]}',
            'action': 'maintenance_scheduled',
            'data': {'schedule': schedule_info}
        }
    
    async def _handle_search_manual(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle manual search commands"""
        
        # Extract search query from command
        query = command.lower().replace('search manual', '').replace('search', '').strip()
        
        # Mock manual search results
        results = [
            {'title': 'Pump Maintenance Manual', 'section': 'Troubleshooting', 'relevance': 0.9},
            {'title': 'Motor Operations Guide', 'section': 'Safety Procedures', 'relevance': 0.7}
        ]
        
        return {
            'message': f'Found {len(results)} manual sections related to your query.',
            'action': 'manual_searched',
            'data': {'results': results, 'query': query}
        }
    
    async def _handle_help(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle help commands"""
        
        commands_list = [
            "Create work order for [asset] [priority]",
            "List critical assets",
            "What parts need reordering?",
            "Generate [type] report",
            "Search for [asset]",
            "Check status of [asset]",
            "Schedule maintenance for [asset]"
        ]
        
        return {
            'message': 'Here are the available voice commands. Say any of these to get started.',
            'action': 'help_shown',
            'data': {'commands': commands_list}
        }
    
    async def _handle_status(self, command: str, entities: Dict, user: AuthUser) -> Dict[str, Any]:
        """Handle system status commands"""
        
        status_info = {
            'system': 'operational',
            'voice_accuracy': self._calculate_accuracy(),
            'commands_today': len([c for c in self.command_history 
                                  if c['timestamp'].date() == datetime.now().date()]),
            'active_work_orders': 15,
            'critical_alerts': 3
        }
        
        return {
            'message': f'System is {status_info["system"]}. Voice recognition at {status_info["voice_accuracy"]:.0%} accuracy.',
            'action': 'status_reported',
            'data': {'status': status_info}
        }
    
    def _update_history(self, command: str, intent: str, confidence: float, success: bool, user_id: str):
        """Update command processing history"""
        
        entry = {
            'timestamp': datetime.now(),
            'user_id': user_id,
            'command': command,
            'intent': intent,
            'confidence': confidence,
            'success': success
        }
        
        self.command_history.append(entry)
        
        # Keep only last 1000 entries
        if len(self.command_history) > 1000:
            self.command_history = self.command_history[-1000:]
    
    def _calculate_accuracy(self) -> float:
        """Calculate overall voice recognition accuracy"""
        
        if not self.command_history:
            return 0.75  # Default assumption
        
        recent_commands = [c for c in self.command_history 
                          if c['timestamp'] > datetime.now() - timedelta(hours=24)]
        
        if not recent_commands:
            return 0.75
        
        successful = sum(1 for c in recent_commands if c['success'])
        return successful / len(recent_commands)
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get voice system performance metrics"""
        
        recent_commands = [c for c in self.command_history 
                          if c['timestamp'] > datetime.now() - timedelta(hours=24)]
        
        if not recent_commands:
            return {'total_commands': 0, 'accuracy': 0.0, 'avg_confidence': 0.0}
        
        success_rate = sum(1 for c in recent_commands if c['success']) / len(recent_commands)
        avg_confidence = sum(c['confidence'] for c in recent_commands) / len(recent_commands)
        
        intent_distribution = {}
        for cmd in recent_commands:
            intent = cmd['intent'] or 'unknown'
            intent_distribution[intent] = intent_distribution.get(intent, 0) + 1
        
        return {
            'total_commands': len(recent_commands),
            'accuracy': success_rate,
            'avg_confidence': avg_confidence,
            'intent_distribution': intent_distribution,
            'avg_response_time': 0.8  # Mock response time
        }

# Create router instance
voice_router = APIRouter(prefix="/voice", tags=["voice-commands"])
voice_processor = VoiceRouter()

@voice_router.post("/command", response_model=VoiceCommandResponse)
async def process_voice_command(
    request: VoiceCommandRequest,
    current_user: AuthUser = Depends(get_current_user)
):
    """Process a voice command and return appropriate response"""
    return await voice_processor.process_voice_command(request, current_user)

@voice_router.get("/status")
async def get_voice_system_status():
    """Get voice system performance metrics"""
    return voice_processor.get_performance_metrics()

@voice_router.get("/help")
async def get_voice_help():
    """Get available voice commands and help"""
    return {
        'available_intents': list(voice_processor.route_table.keys()),
        'sample_commands': [
            "Create work order for PUMP-001 high priority",
            "List critical assets",
            "What parts need reordering?",
            "Generate maintenance report",
            "Search for MOTOR-045",
            "Help"
        ],
        'entity_types': list(voice_processor.entity_patterns.keys())
    }