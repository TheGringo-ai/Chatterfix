#!/usr/bin/env python3
"""
Script to fix the f-string backslash issues in workorders.py
"""

# Read the current workorders.py file
with open('workorders.py', 'r', encoding='utf-8', errors='ignore') as f:
    lines = f.readlines()

# Fix line 366 and 367 (0-indexed: 365, 366)
for i, line in enumerate(lines):
    # Fix the startWork button line
    if 'onclick="startWork(' in line and 'f\'' in line:
        lines[i] = '                                {\'<button class="btn btn-sm btn-success" onclick="startWork(\\\'\' + wo[\'id\'] + \'\\\')">Start</button>\' if wo[\'status\'] == \'assigned\' else \'\'}\n'
        print(f"Fixed line {i+1}: startWork button")
    
    # Fix the completeWork button line
    elif 'onclick="completeWork(' in line and 'f\'' in line:
        lines[i] = '                                {\'<button class="btn btn-sm btn-success" onclick="completeWork(\\\'\' + wo[\'id\'] + \'\\\')">Complete</button>\' if wo[\'status\'] == \'in_progress\' else \'\'}\n'
        print(f"Fixed line {i+1}: completeWork button")
    
    # Fix the cancel button line
    elif 'closeModal(event)' in line and '\\\\' in line:
        lines[i] = '                                    <button type="button" onclick="closeModal(event)" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>\n'
        print(f"Fixed line {i+1}: Cancel button")

# Write the fixed file
with open('workorders.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("Successfully fixed workorders.py!")

# Test the syntax
try:
    import ast
    with open('workorders.py', 'r') as f:
        ast.parse(f.read())
    print("✅ Syntax check passed!")
except SyntaxError as e:
    print(f"❌ Syntax error still exists: {e}")
    print(f"Line {e.lineno}: {e.text}")