#!/usr/bin/env python3
"""
CMMS AI Module
Handles AI-powered features: chat, predictions, OCR, voice commands
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# AI router
ai_router = APIRouter(prefix="/ai", tags=["ai"])

# Data models
class AIRequest(BaseModel):
    message: str
    context: str = "general"
    user_type: str = "technician"

class VoiceCommand(BaseModel):
    text: str
    user_id: str
    timestamp: Optional[str] = None

class OCRRequest(BaseModel):
    ocr_data: Dict[str, Any]
    scan_type: str = "nameplate"

# Mock databases
voice_commands_db = []
predictions_cache = {}

@ai_router.get("/dashboard", response_class=HTMLResponse)
async def ai_dashboard():
    """AI features dashboard"""
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - AI Assistant</title>
        <style>
            {get_base_styles()}
            {get_navigation_styles()}
            
            .results {{ 
                background: rgba(0,0,0,0.3); 
                border-radius: 8px; 
                padding: 1rem; 
                margin-top: 1rem; 
                font-family: 'Courier New', monospace; 
                min-height: 200px; 
                white-space: pre-wrap;
                overflow-y: auto;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            .ai-indicator {{ 
                position: fixed; 
                top: 80px; 
                right: 20px; 
                background: #667eea; 
                padding: 10px 15px; 
                border-radius: 10px; 
                font-size: 0.8rem; 
                z-index: 999;
                box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            }}
            .button-group {{
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                margin-bottom: 1rem;
            }}
        </style>
    </head>
    <body>
        {get_navigation_html('ai')}
        
        <div class="ai-indicator" id="aiStatus">🤖 AI Ready</div>
        
        <div class="header">
            <h1>🤖 AI Assistant Dashboard</h1>
            <p>Multi-Model AI • Voice Commands • OCR • Predictive Analytics</p>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card">
                    <h3>💬 AI Chat Assistant</h3>
                    <p>Multi-model AI chat with intelligent routing</p>
                    <div class="button-group">
                        <button class="btn" onclick="startAIChat('technician')">Technician AI</button>
                        <button class="btn" onclick="startAIChat('manager')">Manager AI</button>
                        <button class="btn" onclick="startAIChat('supervisor')">Supervisor AI</button>
                    </div>
                    <div class="results" id="chatResults">Click a button above to start AI chat...</div>
                </div>
                
                <div class="card">
                    <h3>🎤 Voice Commands</h3>
                    <p>Voice-powered work order creation and system control</p>
                    <div class="button-group">
                        <button class="btn" onclick="startVoiceCommand()">🎙️ Voice Command</button>
                        <button class="btn" onclick="viewVoiceHistory()">📜 Voice History</button>
                    </div>
                    <div class="results" id="voiceResults">Voice system ready...</div>
                </div>
                
                <div class="card">
                    <h3>📷 OCR Scanner</h3>
                    <p>Optical character recognition for equipment nameplates</p>
                    <div class="button-group">
                        <button class="btn" onclick="scanEquipment()">📱 Scan Equipment</button>
                        <button class="btn" onclick="scanDocuments()">📄 Scan Documents</button>
                    </div>
                    <div class="results" id="ocrResults">OCR scanner ready...</div>
                </div>
                
                <div class="card">
                    <h3>📈 Predictive Analytics</h3>
                    <p>AI-powered equipment failure prediction</p>
                    <div class="button-group">
                        <button class="btn" onclick="runPredictions()">🔮 Generate Predictions</button>
                        <button class="btn" onclick="viewAnalytics()">📊 View Analytics</button>
                    </div>
                    <div class="results" id="predictResults">Predictive AI ready...</div>
                </div>
            </div>
        </div>
        
        <script>
            {get_navigation_javascript()}
            
            function updateAIStatus(status) {{
                document.getElementById('aiStatus').textContent = status;
            }}
            
            function updateResults(elementId, content) {{
                document.getElementById(elementId).textContent = content;
            }}
            
            async function startAIChat(userType) {{
                const message = prompt(`Ask AI (${{userType}} mode):`);
                if (!message) return;
                
                updateAIStatus('🤖 AI Thinking...');
                updateResults('chatResults', 'Processing your request...');
                
                try {{
                    const response = await fetch('/ai/chat', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ message, user_type: userType, context: 'AI Dashboard' }})
                    }});
                    const data = await response.json();
                    
                    const result = `[${{new Date().toLocaleTimeString()}}] ${{userType.toUpperCase()}} AI
                    
Your Question: "${{message}}"

AI Response:
${{data.response || 'AI processing complete. This is a demonstration interface.'}}

Technical Details:
• Model Used: ${{data.model_used || 'Demo Model'}}
• Confidence: ${{((data.confidence || 0.95) * 100).toFixed(1)}}%
• Response Time: ${{data.response_time || 'Fast'}}ms`;
                    
                    updateResults('chatResults', result);
                    updateAIStatus('🤖 AI Ready');
                }} catch (error) {{
                    updateResults('chatResults', 'Error: ' + error.message);
                    updateAIStatus('🤖 AI Error');
                }}
            }}
            
            async function startVoiceCommand() {{
                const command = prompt('Voice Command (or type):');
                if (!command) return;
                
                updateAIStatus('🎙️ Processing Voice...');
                updateResults('voiceResults', 'Processing voice command...');
                
                const result = `[${{new Date().toLocaleTimeString()}}] Voice Command
                
Command: "${{command}}"
Understood: Yes
Action: Voice command processed

AI Response: Voice command "${{command}}" has been processed successfully.

Next Steps:
• Command logged in system
• Appropriate actions will be taken
• Results will be updated in real-time`;
                
                updateResults('voiceResults', result);
                updateAIStatus('🤖 AI Ready');
            }}
            
            async function scanEquipment() {{
                updateAIStatus('📷 OCR Scanning...');
                updateResults('ocrResults', 'Scanning equipment nameplate...');
                
                setTimeout(() => {{
                    const result = `[${{new Date().toLocaleTimeString()}}] OCR Scan Complete
                    
Scan Type: Equipment Nameplate
OCR Confidence: 96.5%

Equipment Information:
• Manufacturer: SIEMENS
• Model: S7-1500  
• Serial: S7-2025-1234
• Voltage: 24V DC
• Power: 15W

Next Steps:
• Equipment record updated
• Maintenance schedule created
• Asset database synchronized`;
                    
                    updateResults('ocrResults', result);
                    updateAIStatus('🤖 AI Ready');
                }}, 2000);
            }}
            
            async function runPredictions() {{
                updateAIStatus('📈 Analyzing...');
                updateResults('predictResults', 'Running predictive analysis...');
                
                setTimeout(() => {{
                    const result = `[${{new Date().toLocaleTimeString()}}] Predictive Analysis
                    
Model Used: Advanced ML Model
Total Equipment Analyzed: 47

High Priority Equipment:
1. Conveyor Belt System
   Risk Level: MEDIUM
   Failure Prediction: 2 weeks
   Confidence: 87.3%
   
2. HVAC Unit 1
   Risk Level: LOW
   Failure Prediction: No immediate risk
   Confidence: 94.1%

Recommendations:
• Schedule preventive maintenance for Conveyor Belt
• Monitor HVAC performance trends
• Update maintenance schedules accordingly`;
                    
                    updateResults('predictResults', result);
                    updateAIStatus('🤖 AI Ready');
                }}, 1500);
            }}
            
            function viewVoiceHistory() {{
                const result = `[${{new Date().toLocaleTimeString()}}] Voice Command History

Recent Commands:
1. [VC-001] ${{new Date().toLocaleString()}}
   Command: "Create work order for pump maintenance"
   User: demo_user
   Executed: Yes
   Result: Work order WO-2025001 created

2. [VC-002] ${{new Date().toLocaleString()}}
   Command: "Check equipment status"
   User: demo_user
   Executed: Yes
   Result: Equipment status report generated

Total Commands: 12
Success Rate: 95.8%`;
                
                updateResults('voiceResults', result);
            }}
            
            function scanDocuments() {{
                updateAIStatus('📄 Document OCR...');
                updateResults('ocrResults', 'Scanning maintenance documents...');
                
                setTimeout(() => {{
                    const result = `[${{new Date().toLocaleTimeString()}}] Document Scan Complete
                    
Document Type: Maintenance Procedure
Pages Scanned: 2
OCR Confidence: 93.5%

Key Information Extracted:
• Equipment: Conveyor Belt System
• Procedure: Weekly Inspection  
• Safety: LOTO Required
• Duration: 45 minutes

Procedure Steps:
1. Power isolation and lockout
2. Visual inspection of belt
3. Tension measurement
4. Bearing lubrication check
5. Electrical connection test`;
                    
                    updateResults('ocrResults', result);
                    updateAIStatus('🤖 AI Ready');
                }}, 1500);
            }}
            
            function viewAnalytics() {{
                const result = `[${{new Date().toLocaleTimeString()}}] AI Analytics Dashboard
                
AI Performance Metrics:
• Total Predictions: 247
• Accuracy Rate: 94.2%
• False Positives: 3.1%
• Model Performance: Excellent

Equipment Health Trends:
• Overall Fleet Health: 8.7/10
• Equipment at Risk: 2 items
• Maintenance Efficiency: 91.5%
• Cost Savings: $12,450/month

Recent AI Actions:
• Work orders auto-created: 23
• Maintenance alerts sent: 67
• Equipment predictions: 145
• Voice commands processed: 89`;
                
                updateResults('predictResults', result);
            }}
        </script>
    </body>
    </html>
    """

@ai_router.post("/chat")
async def ai_chat(request: AIRequest) -> Dict:
    """AI chat endpoint"""
    return {{
        "response": f"AI response to: '{{request.message}}' for {{request.user_type}} in {{request.context}} context.",
        "model_used": "Demo Model",
        "confidence": 0.95,
        "user_type": request.user_type,
        "response_time": 150,
        "timestamp": datetime.now().isoformat()
    }}

@ai_router.post("/voice")
async def voice_command(command: VoiceCommand) -> Dict:
    """Process voice command"""
    return {{
        "understood": True,
        "action": "processed",
        "response": f"Voice command '{{command.text}}' processed successfully",
        "confidence": 0.92,
        "timestamp": datetime.now().isoformat()
    }}

@ai_router.post("/ocr")
async def process_ocr(request: OCRRequest) -> Dict:
    """Process OCR data"""
    return {{
        "scan_type": request.scan_type,
        "confidence": 0.96,
        "equipment_info": {{
            "manufacturer": "SIEMENS",
            "model": "S7-1500",
            "serial_number": "S7-2025-1234"
        }},
        "next_steps": ["Update asset database", "Schedule maintenance", "Create work order"],
        "timestamp": datetime.now().isoformat()
    }}

@ai_router.get("/predictions")
async def get_predictions() -> Dict:
    """Get AI predictions"""
    return {{
        "analysis_model": "Advanced ML Model",
        "predictions": [
            {{
                "equipment_name": "Conveyor Belt System",
                "risk_level": "medium",
                "predicted_failure_date": "2025-09-15",
                "confidence": 0.873,
                "recommendations": ["Schedule preventive maintenance", "Monitor belt tension", "Check lubrication"]
            }},
            {{
                "equipment_name": "HVAC Unit 1", 
                "risk_level": "low",
                "predicted_failure_date": None,
                "confidence": 0.941,
                "recommendations": ["Continue normal operations", "Monitor performance trends"]
            }}
        ],
        "timestamp": datetime.now().isoformat()
    }}

@ai_router.get("/voice-history")
async def get_voice_history() -> Dict:
    """Get voice command history"""
    return {{
        "commands": [
            {{
                "id": "VC-001",
                "text": "Create work order for pump maintenance",
                "user_id": "demo_user",
                "timestamp": datetime.now().isoformat(),
                "executed": True,
                "result": "Work order WO-2025001 created"
            }}
        ],
        "total_commands": len(voice_commands_db) + 1,
        "success_rate": 0.958
    }}

@ai_router.get("/models")
async def get_available_models() -> List[Dict]:
    """Get available AI models"""
    return [
        {{
            "name": "Technician Assistant", 
            "description": "Specialized for maintenance tasks",
            "capabilities": ["troubleshooting", "procedures", "safety"]
        }},
        {{
            "name": "Manager Assistant",
            "description": "Focused on operational oversight", 
            "capabilities": ["reporting", "scheduling", "resource_planning"]
        }},
        {{
            "name": "Supervisor Assistant",
            "description": "Advanced system management",
            "capabilities": ["predictive_analytics", "optimization", "compliance"]
        }}
    ]

@ai_router.get("/health")
async def ai_health_check() -> Dict:
    """AI system health check"""
    return {{
        "status": "healthy",
        "models_available": 3,
        "voice_system": "operational", 
        "ocr_system": "operational",
        "prediction_engine": "operational",
        "uptime": "99.9%",
        "last_update": datetime.now().isoformat()
    }}