#!/usr/bin/env python3
"""
CMMS Technician Module
Technician portal, task management, and mobile interface
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Technician router
technician_router = APIRouter(prefix="/technician", tags=["technician"])

# Data models
class Technician(BaseModel):
    id: str
    name: str
    email: str
    phone: str
    skills: List[str]
    certifications: List[str]
    status: str
    location: str
    shift: str

class TechnicianTask(BaseModel):
    id: str
    title: str
    description: str
    asset_id: str
    priority: str
    status: str
    assigned_date: str
    due_date: str
    estimated_hours: float
    technician_id: str

class TimeEntry(BaseModel):
    id: str
    technician_id: str
    task_id: str
    date: str
    hours: float
    description: str
    status: str

# Mock database
technicians_db = [
    {
        "id": "TECH-001",
        "name": "John Smith",
        "email": "john.smith@chatterfix.com",
        "phone": "(555) 123-4567",
        "skills": ["Mechanical", "Electrical", "Pneumatics", "Generator"],
        "certifications": ["OSHA 30", "Electrical License", "Arc Flash"],
        "status": "available",
        "location": "Building A",
        "shift": "day"
    },
    {
        "id": "TECH-002",
        "name": "Mike Johnson",
        "email": "mike.johnson@chatterfix.com", 
        "phone": "(555) 234-5678",
        "skills": ["Mechanical", "Belt Systems", "Conveyor", "Packaging"],
        "certifications": ["OSHA 10", "Mechanical Certification"],
        "status": "busy",
        "location": "Production Floor 1",
        "shift": "day"
    },
    {
        "id": "TECH-003",
        "name": "Sarah Davis",
        "email": "sarah.davis@chatterfix.com",
        "phone": "(555) 345-6789",
        "skills": ["HVAC", "Refrigeration", "Controls", "Electronics"],
        "certifications": ["EPA 608", "HVAC License", "Controls Certification"],
        "status": "available",
        "location": "Building A - Roof",
        "shift": "day"
    },
    {
        "id": "TECH-004",
        "name": "Carlos Rodriguez",
        "email": "carlos.rodriguez@chatterfix.com",
        "phone": "(555) 456-7890",
        "skills": ["Electrical", "Automation", "PLC", "Motor Control"],
        "certifications": ["Journeyman Electrician", "PLC Programming", "Safety Training"],
        "status": "busy",
        "location": "Production Floor 2",
        "shift": "night"
    },
    {
        "id": "TECH-005",
        "name": "Lisa Wong",
        "email": "lisa.wong@chatterfix.com",
        "phone": "(555) 567-8901",
        "skills": ["Mechanical", "Welding", "Fabrication", "Precision"],
        "certifications": ["AWS Welding", "Machinist Certificate", "Safety Training"],
        "status": "available",
        "location": "Maintenance Shop",
        "shift": "day"
    }
]

technician_tasks_db = [
    {
        "id": "TASK-001",
        "title": "Weekly Generator Test",
        "description": "Perform weekly function test on emergency generator",
        "asset_id": "AST-004",
        "priority": "high",
        "status": "in_progress",
        "assigned_date": "2025-09-01",
        "due_date": "2025-09-01",
        "estimated_hours": 1.0,
        "technician_id": "TECH-001"
    },
    {
        "id": "TASK-002",
        "title": "Conveyor Belt Maintenance",
        "description": "Monthly belt inspection and lubrication",
        "asset_id": "AST-002", 
        "priority": "medium",
        "status": "assigned",
        "assigned_date": "2025-09-01",
        "due_date": "2025-09-03",
        "estimated_hours": 2.0,
        "technician_id": "TECH-002"
    },
    {
        "id": "TASK-003",
        "title": "HVAC Filter Replacement",
        "description": "Replace filters and check system operation",
        "asset_id": "AST-003",
        "priority": "medium",
        "status": "assigned",
        "assigned_date": "2025-08-30",
        "due_date": "2025-09-05",
        "estimated_hours": 4.0,
        "technician_id": "TECH-003"
    },
    {
        "id": "TASK-004",
        "title": "Packaging Machine Repair",
        "description": "Diagnose and repair motor bearing issues",
        "asset_id": "AST-005",
        "priority": "urgent",
        "status": "assigned",
        "assigned_date": "2025-08-31",
        "due_date": "2025-09-02",
        "estimated_hours": 8.0,
        "technician_id": "TECH-004"
    },
    {
        "id": "TASK-005",
        "title": "Compressor Oil Analysis",
        "description": "Collect oil sample and perform analysis",
        "asset_id": "AST-001",
        "priority": "low",
        "status": "pending",
        "assigned_date": "2025-09-01",
        "due_date": "2025-09-10",
        "estimated_hours": 0.5,
        "technician_id": "TECH-001"
    }
]

time_entries_db = [
    {
        "id": "TIME-001",
        "technician_id": "TECH-001",
        "task_id": "TASK-001",
        "date": "2025-09-01",
        "hours": 0.5,
        "description": "Started generator test - checking fuel level",
        "status": "active"
    },
    {
        "id": "TIME-002",
        "technician_id": "TECH-002",
        "task_id": "TASK-002",
        "date": "2025-08-31",
        "hours": 1.0,
        "description": "Prepared tools and safety equipment",
        "status": "submitted"
    },
    {
        "id": "TIME-003",
        "technician_id": "TECH-004",
        "task_id": "TASK-004",
        "date": "2025-08-31",
        "hours": 2.5,
        "description": "Diagnosed bearing issue, ordered replacement parts",
        "status": "submitted"
    }
]

@technician_router.get("/dashboard/{technician_id}", response_class=HTMLResponse)
async def technician_dashboard(technician_id: str):
    """Technician personal dashboard"""
    technician = next((t for t in technicians_db if t['id'] == technician_id), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    
    # Get technician's tasks
    my_tasks = [t for t in technician_tasks_db if t['technician_id'] == technician_id]
    active_tasks = [t for t in my_tasks if t['status'] in ['assigned', 'in_progress']]
    overdue_tasks = [t for t in my_tasks if t['due_date'] < datetime.now().strftime("%Y-%m-%d") and t['status'] not in ['completed']]
    completed_today = len([t for t in my_tasks if t['status'] == 'completed'])
    
    # Time tracking
    today_hours = sum(te['hours'] for te in time_entries_db if te['technician_id'] == technician_id and te['date'] == datetime.now().strftime("%Y-%m-%d"))
    week_hours = sum(te['hours'] for te in time_entries_db if te['technician_id'] == technician_id)  # Simplified
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix Technician Portal - {technician['name']}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * {{ box-sizing: border-box; }}
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem; }}
            .header h1 {{ margin: 0; font-size: 1.5rem; }}
            .header p {{ margin: 0.5rem 0 0 0; opacity: 0.9; }}
            .container {{ max-width: 1200px; margin: 1rem auto; padding: 0 1rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-bottom: 1rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 0.5rem 0; }}
            .stat-value {{ font-size: 1.5rem; font-weight: bold; }}
            .status-good {{ color: #38a169; }}
            .status-warning {{ color: #d69e2e; }}
            .status-critical {{ color: #e53e3e; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; text-decoration: none; display: inline-block; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-success {{ background: #38a169; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .btn-sm {{ padding: 0.25rem 0.5rem; font-size: 0.875rem; }}
            .task-card {{ border-left: 4px solid #4299e1; margin-bottom: 1rem; }}
            .task-card.urgent {{ border-left-color: #e53e3e; }}
            .task-card.high {{ border-left-color: #d69e2e; }}
            .task-card.medium {{ border-left-color: #38a169; }}
            .task-card.low {{ border-left-color: #a0aec0; }}
            .badge {{ padding: 0.25rem 0.5rem; border-radius: 12px; font-size: 0.75rem; font-weight: 500; }}
            .badge-urgent {{ background: #fed7d7; color: #e53e3e; }}
            .badge-high {{ background: #fef5e7; color: #d69e2e; }}
            .badge-medium {{ background: #f0fff4; color: #38a169; }}
            .badge-low {{ background: #f7fafc; color: #4a5568; }}
            .time-tracker {{ position: sticky; top: 1rem; }}
            .active-timer {{ background: #38a169; color: white; }}
            .mobile-nav {{ display: none; position: fixed; bottom: 0; left: 0; right: 0; background: white; border-top: 1px solid #e2e8f0; padding: 0.5rem; }}
            .mobile-nav a {{ flex: 1; text-align: center; padding: 0.5rem; text-decoration: none; color: #4a5568; }}
            .mobile-nav a.active {{ color: #4299e1; }}
            
            @media (max-width: 768px) {{
                .container {{ padding: 0 0.5rem; margin-bottom: 4rem; }}
                .grid {{ grid-template-columns: 1fr; gap: 0.5rem; }}
                .mobile-nav {{ display: flex; }}
                .header {{ padding: 0.75rem; }}
                .card {{ padding: 0.75rem; }}
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>=' {technician['name']}</h1>
            <p>{technician['location']} " {technician['shift'].title()} Shift</p>
        </div>
        
        <div class="container">
            <!-- Stats Overview -->
            <div class="grid">
                <div class="card">
                    <h3>=Ê My Tasks Today</h3>
                    <div class="stat">
                        <span>Active Tasks</span>
                        <span class="stat-value status-good">{len(active_tasks)}</span>
                    </div>
                    <div class="stat">
                        <span>Overdue</span>
                        <span class="stat-value status-critical">{len(overdue_tasks)}</span>
                    </div>
                    <div class="stat">
                        <span>Completed Today</span>
                        <span class="stat-value status-good">{completed_today}</span>
                    </div>
                </div>
                
                <div class="card time-tracker">
                    <h3>ñ Time Tracking</h3>
                    <div class="stat">
                        <span>Today</span>
                        <span class="stat-value">{today_hours:.1f}h</span>
                    </div>
                    <div class="stat">
                        <span>This Week</span>
                        <span class="stat-value">{week_hours:.1f}h</span>
                    </div>
                    <button class="btn btn-success" onclick="startTimer()" id="timerBtn">Start Timer</button>
                    <button class="btn" onclick="viewTimesheet()">View Timesheet</button>
                </div>
                
                <div class="card">
                    <h3>=h=' My Skills</h3>
                    <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 1rem 0;">
                        {chr(10).join([f'<span class="badge badge-medium">{skill}</span>' for skill in technician['skills']])}
                    </div>
                    <div>
                        <strong>Certifications:</strong><br>
                        <small>{', '.join(technician['certifications'])}</small>
                    </div>
                </div>
            </div>
            
            <!-- Active Tasks -->
            <div class="card">
                <h3>=Ë My Active Tasks</h3>
                <div id="activeTasks">
                    {chr(10).join([f'''
                    <div class="card task-card {task['priority']}" data-task-id="{task['id']}">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">
                            <div>
                                <h4 style="margin: 0; font-size: 1rem;">{task['title']}</h4>
                                <p style="margin: 0.25rem 0; color: #718096; font-size: 0.9rem;">Asset: {task['asset_id']} " Due: {task['due_date']}</p>
                            </div>
                            <span class="badge badge-{task['priority']}">{task['priority'].upper()}</span>
                        </div>
                        
                        <p style="margin: 0.5rem 0; font-size: 0.9rem; color: #4a5568;">
                            {task['description'][:60]}{'...' if len(task['description']) > 60 else ''}
                        </p>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                            <div style="font-size: 0.85rem; color: #718096;">
                                Est. {task['estimated_hours']}h " Status: {task['status'].replace('_', ' ').title()}
                            </div>
                            <div>
                                <button class="btn btn-sm btn-success" onclick="startTask('{task['id']}')">
                                    {'Continue' if task['status'] == 'in_progress' else 'Start'}
                                </button>
                                <button class="btn btn-sm" onclick="viewTaskDetails('{task['id']}')">Details</button>
                            </div>
                        </div>
                    </div>''' for task in active_tasks])}
                </div>
                
                {f'<div style="text-align: center; color: #718096; padding: 2rem;">No active tasks assigned</div>' if not active_tasks else ''}
            </div>
            
            <!-- Quick Actions -->
            <div class="grid">
                <div class="card">
                    <h3>= Quick Actions</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 0.5rem;">
                        <button class="btn" onclick="scanQR()">Scan QR Code</button>
                        <button class="btn" onclick="reportIssue()">Report Issue</button>
                        <button class="btn" onclick="requestParts()">Request Parts</button>
                        <button class="btn" onclick="viewManuals()">View Manuals</button>
                        <button class="btn" onclick="safetyChecklist()">Safety Check</button>
                        <button class="btn" onclick="contactSupport()">Get Help</button>
                    </div>
                </div>
                
                <div class="card">
                    <h3>=ñ Mobile Tools</h3>
                    <button class="btn" onclick="openCamera()">=ø Take Photo</button>
                    <button class="btn" onclick="recordVoice()"><¤ Voice Note</button>
                    <button class="btn" onclick="useFlashlight()">=& Flashlight</button>
                    <button class="btn" onclick="measureTool()">=Ï Measure</button>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card">
                <h3>=Ý Recent Time Entries</h3>
                <div>
                    {chr(10).join([f'''
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; border-bottom: 1px solid #e2e8f0;">
                        <div>
                            <div style="font-weight: 500;">{next((t['title'] for t in technician_tasks_db if t['id'] == entry['task_id']), 'Unknown Task')}</div>
                            <div style="font-size: 0.85rem; color: #718096;">{entry['description']}</div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: bold;">{entry['hours']}h</div>
                            <div style="font-size: 0.75rem; color: #718096;">{entry['date']}</div>
                        </div>
                    </div>''' for entry in time_entries_db if entry['technician_id'] == technician_id][-5:])}
                </div>
            </div>
        </div>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav">
            <a href="/technician/dashboard/{technician_id}" class="active"><à Home</a>
            <a href="/technician/{technician_id}/tasks">=Ë Tasks</a>
            <a href="/technician/{technician_id}/time">ñ Time</a>
            <a href="/technician/{technician_id}/tools">=à Tools</a>
            <a href="/technician/profile/{technician_id}">=d Profile</a>
        </div>
        
        <script>
            let timerRunning = false;
            let currentTaskId = null;
            let timerInterval = null;
            let elapsedSeconds = 0;
            
            function startTimer() {{
                const btn = document.getElementById('timerBtn');
                if (!timerRunning) {{
                    // Start timer
                    timerRunning = true;
                    btn.textContent = 'Stop Timer';
                    btn.className = 'btn btn-danger';
                    
                    // Get current task
                    const activeTasks = document.querySelectorAll('[data-task-id]');
                    if (activeTasks.length > 0) {{
                        currentTaskId = activeTasks[0].dataset.taskId;
                    }}
                    
                    // Start interval
                    timerInterval = setInterval(() => {{
                        elapsedSeconds++;
                        const hours = Math.floor(elapsedSeconds / 3600);
                        const minutes = Math.floor((elapsedSeconds % 3600) / 60);
                        const seconds = elapsedSeconds % 60;
                        btn.textContent = `Stop Timer (${{hours.toString().padStart(2, '0')}}:${{minutes.toString().padStart(2, '0')}}:${{seconds.toString().padStart(2, '0')}})`;
                    }}, 1000);
                }} else {{
                    // Stop timer
                    stopTimer();
                }}
            }}
            
            function stopTimer() {{
                if (timerRunning) {{
                    timerRunning = false;
                    clearInterval(timerInterval);
                    
                    const hours = elapsedSeconds / 3600;
                    const description = prompt('Enter work description:');
                    
                    if (description && currentTaskId) {{
                        // Submit time entry
                        fetch('/technician/time-entry', {{
                            method: 'POST',
                            headers: {{ 'Content-Type': 'application/json' }},
                            body: JSON.stringify({{
                                technician_id: '{technician_id}',
                                task_id: currentTaskId,
                                hours: hours,
                                description: description
                            }})
                        }})
                        .then(() => location.reload());
                    }}
                    
                    // Reset timer
                    elapsedSeconds = 0;
                    const btn = document.getElementById('timerBtn');
                    btn.textContent = 'Start Timer';
                    btn.className = 'btn btn-success';
                }}
            }}
            
            function startTask(taskId) {{
                // Update task status and start timer
                fetch(`/technician/tasks/${{taskId}}/start`, {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ technician_id: '{technician_id}' }})
                }})
                .then(() => {{
                    currentTaskId = taskId;
                    if (!timerRunning) startTimer();
                }});
            }}
            
            function viewTaskDetails(taskId) {{
                window.open(`/technician/tasks/${{taskId}}`, '_blank');
            }}
            
            function viewTimesheet() {{
                window.location.href = '/technician/{technician_id}/timesheet';
            }}
            
            function scanQR() {{
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {{
                    alert('QR Scanner would open here');
                }} else {{
                    alert('Camera not available');
                }}
            }}
            
            function reportIssue() {{
                window.location.href = '/workorders/create?technician_id={technician_id}';
            }}
            
            function requestParts() {{
                window.location.href = '/parts/request?technician_id={technician_id}';
            }}
            
            function viewManuals() {{
                window.location.href = '/technician/manuals';
            }}
            
            function safetyChecklist() {{
                window.location.href = '/technician/safety-checklist';
            }}
            
            function contactSupport() {{
                window.location.href = 'tel:+15551234567';
            }}
            
            function openCamera() {{
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {{
                    navigator.mediaDevices.getUserMedia({{ video: true }})
                        .then(stream => {{
                            alert('Camera would open here for photo capture');
                            stream.getTracks().forEach(track => track.stop());
                        }})
                        .catch(err => alert('Camera access denied'));
                }} else {{
                    alert('Camera not available');
                }}
            }}
            
            function recordVoice() {{
                alert('Voice recording would start here');
            }}
            
            function useFlashlight() {{
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {{
                    alert('Flashlight functionality would activate here');
                }} else {{
                    alert('Flashlight not available');
                }}
            }}
            
            function measureTool() {{
                alert('AR measurement tool would open here');
            }}
            
            // Auto-save work in progress
            setInterval(() => {{
                if (timerRunning && currentTaskId) {{
                    const hours = elapsedSeconds / 3600;
                    fetch('/technician/time-entry/autosave', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            technician_id: '{technician_id}',
                            task_id: currentTaskId,
                            hours: hours,
                            description: 'Work in progress'
                        }})
                    }});
                }}
            }}, 300000); // Every 5 minutes
        </script>
    </body>
    </html>
    """

@technician_router.get("/")
async def get_technicians(
    status: Optional[str] = Query(None),
    skill: Optional[str] = Query(None),
    shift: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all technicians with optional filtering"""
    filtered_technicians = technicians_db
    
    if status:
        filtered_technicians = [t for t in filtered_technicians if t['status'] == status]
    if skill:
        filtered_technicians = [t for t in filtered_technicians if skill in t['skills']]
    if shift:
        filtered_technicians = [t for t in filtered_technicians if t['shift'] == shift]
    
    return filtered_technicians

@technician_router.get("/{technician_id}")
async def get_technician_details(technician_id: str) -> Dict:
    """Get specific technician details"""
    technician = next((t for t in technicians_db if t['id'] == technician_id), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    
    # Get technician's tasks and time entries
    tasks = [t for t in technician_tasks_db if t['technician_id'] == technician_id]
    time_entries = [te for te in time_entries_db if te['technician_id'] == technician_id]
    
    # Calculate metrics
    total_hours_week = sum(te['hours'] for te in time_entries if te['date'] >= (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"))
    active_tasks = len([t for t in tasks if t['status'] in ['assigned', 'in_progress']])
    completed_tasks = len([t for t in tasks if t['status'] == 'completed'])
    
    return {
        "technician": technician,
        "tasks": tasks,
        "time_entries": time_entries,
        "metrics": {
            "active_tasks": active_tasks,
            "completed_tasks": completed_tasks,
            "hours_this_week": total_hours_week,
            "efficiency_rating": 4.2,
            "on_time_completion": 89.5
        }
    }

@technician_router.get("/{technician_id}/tasks")
async def get_technician_tasks(
    technician_id: str,
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None)
) -> List[Dict]:
    """Get technician's assigned tasks"""
    tasks = [t for t in technician_tasks_db if t['technician_id'] == technician_id]
    
    if status:
        tasks = [t for t in tasks if t['status'] == status]
    if priority:
        tasks = [t for t in tasks if t['priority'] == priority]
    
    return tasks

@technician_router.post("/tasks/{task_id}/start")
async def start_task(task_id: str, task_data: Dict[str, Any]) -> Dict:
    """Start working on a task"""
    task = next((t for t in technician_tasks_db if t['id'] == task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    if task['technician_id'] != task_data['technician_id']:
        raise HTTPException(status_code=403, detail="Task not assigned to this technician")
    
    task['status'] = 'in_progress'
    
    # Create time entry
    time_entry_id = f"TIME-{len(time_entries_db) + 1:03d}"
    time_entry = {
        "id": time_entry_id,
        "technician_id": task_data['technician_id'],
        "task_id": task_id,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "hours": 0,
        "description": "Task started",
        "status": "active"
    }
    
    time_entries_db.append(time_entry)
    
    logger.info(f"Task started: {task_id} by {task_data['technician_id']}")
    return {"task": task, "time_entry": time_entry}

@technician_router.post("/tasks/{task_id}/complete")
async def complete_task(task_id: str, completion_data: Dict[str, Any]) -> Dict:
    """Mark task as completed"""
    task = next((t for t in technician_tasks_db if t['id'] == task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    task['status'] = 'completed'
    completion_date = datetime.now().strftime("%Y-%m-%d")
    
    # Update any active time entries
    for time_entry in time_entries_db:
        if time_entry['task_id'] == task_id and time_entry['status'] == 'active':
            time_entry['status'] = 'completed'
            time_entry['description'] += f" - Completed on {completion_date}"
    
    logger.info(f"Task completed: {task_id}")
    return {
        "task_id": task_id,
        "status": "completed",
        "completion_date": completion_date,
        "notes": completion_data.get("notes", "")
    }

@technician_router.post("/time-entry")
async def create_time_entry(time_data: Dict[str, Any]) -> Dict:
    """Create time entry for technician"""
    time_entry_id = f"TIME-{len(time_entries_db) + 1:03d}"
    
    time_entry = {
        "id": time_entry_id,
        "technician_id": time_data["technician_id"],
        "task_id": time_data["task_id"],
        "date": datetime.now().strftime("%Y-%m-%d"),
        "hours": float(time_data["hours"]),
        "description": time_data["description"],
        "status": "submitted"
    }
    
    time_entries_db.append(time_entry)
    
    logger.info(f"Time entry created: {time_entry_id}")
    return time_entry

@technician_router.get("/{technician_id}/timesheet")
async def get_technician_timesheet(
    technician_id: str,
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None)
) -> Dict:
    """Get technician's timesheet"""
    timesheet_entries = [te for te in time_entries_db if te['technician_id'] == technician_id]
    
    if start_date:
        timesheet_entries = [te for te in timesheet_entries if te['date'] >= start_date]
    if end_date:
        timesheet_entries = [te for te in timesheet_entries if te['date'] <= end_date]
    
    total_hours = sum(te['hours'] for te in timesheet_entries)
    
    # Group by date
    by_date = {}
    for entry in timesheet_entries:
        date = entry['date']
        if date not in by_date:
            by_date[date] = {"entries": [], "total_hours": 0}
        by_date[date]["entries"].append(entry)
        by_date[date]["total_hours"] += entry['hours']
    
    return {
        "technician_id": technician_id,
        "total_hours": total_hours,
        "entries_count": len(timesheet_entries),
        "by_date": by_date,
        "entries": timesheet_entries
    }

@technician_router.get("/schedule")
async def get_technician_schedule(
    date: Optional[str] = Query(None),
    shift: Optional[str] = Query(None)
) -> List[Dict]:
    """Get technician schedule for planning"""
    schedule_data = []
    
    for technician in technicians_db:
        if shift and technician['shift'] != shift:
            continue
            
        # Get assigned tasks
        assigned_tasks = [t for t in technician_tasks_db if t['technician_id'] == technician['id']]
        if date:
            assigned_tasks = [t for t in assigned_tasks if t['due_date'] <= date]
        
        workload = sum(t['estimated_hours'] for t in assigned_tasks if t['status'] in ['assigned', 'in_progress'])
        
        schedule_data.append({
            "technician_id": technician['id'],
            "name": technician['name'],
            "status": technician['status'],
            "location": technician['location'],
            "shift": technician['shift'],
            "skills": technician['skills'],
            "assigned_tasks": len(assigned_tasks),
            "workload_hours": workload,
            "availability": "available" if workload < 8 else "busy"
        })
    
    return schedule_data

@technician_router.post("/assign-task")
async def assign_task_to_technician(assignment_data: Dict[str, Any]) -> Dict:
    """Assign a task to a technician"""
    technician = next((t for t in technicians_db if t['id'] == assignment_data['technician_id']), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    
    task_id = f"TASK-{len(technician_tasks_db) + 1:03d}"
    
    new_task = {
        "id": task_id,
        "title": assignment_data["title"],
        "description": assignment_data["description"],
        "asset_id": assignment_data["asset_id"],
        "priority": assignment_data["priority"],
        "status": "assigned",
        "assigned_date": datetime.now().strftime("%Y-%m-%d"),
        "due_date": assignment_data["due_date"],
        "estimated_hours": float(assignment_data["estimated_hours"]),
        "technician_id": assignment_data["technician_id"]
    }
    
    technician_tasks_db.append(new_task)
    
    # Update technician status
    current_workload = sum(
        t['estimated_hours'] for t in technician_tasks_db 
        if t['technician_id'] == assignment_data['technician_id'] 
        and t['status'] in ['assigned', 'in_progress']
    )
    
    technician['status'] = 'busy' if current_workload > 6 else 'available'
    
    logger.info(f"Task assigned: {task_id} to {assignment_data['technician_id']}")
    return new_task

@technician_router.get("/reports/productivity")
async def get_productivity_report() -> Dict:
    """Get technician productivity report"""
    productivity_data = {}
    
    for technician in technicians_db:
        tech_id = technician['id']
        
        # Get technician's data
        tasks = [t for t in technician_tasks_db if t['technician_id'] == tech_id]
        time_entries = [te for te in time_entries_db if te['technician_id'] == tech_id]
        
        completed_tasks = len([t for t in tasks if t['status'] == 'completed'])
        total_hours = sum(te['hours'] for te in time_entries)
        avg_task_time = total_hours / max(completed_tasks, 1)
        
        productivity_data[tech_id] = {
            "technician_name": technician['name'],
            "skills": technician['skills'],
            "location": technician['location'],
            "completed_tasks": completed_tasks,
            "total_hours": total_hours,
            "average_task_time": avg_task_time,
            "productivity_score": min(100, (completed_tasks / max(total_hours / 8, 1)) * 100),
            "utilization_rate": min(100, (total_hours / (5 * 8)) * 100)  # 5 days * 8 hours
        }
    
    return {
        "technicians": productivity_data,
        "overall_metrics": {
            "total_completed_tasks": sum(len([t for t in technician_tasks_db if t['technician_id'] == tech_id and t['status'] == 'completed']) for tech_id in [t['id'] for t in technicians_db]),
            "total_hours_logged": sum(te['hours'] for te in time_entries_db),
            "average_productivity": sum(data['productivity_score'] for data in productivity_data.values()) / len(productivity_data) if productivity_data else 0,
            "technicians_available": len([t for t in technicians_db if t['status'] == 'available'])
        },
        "generated_at": datetime.now().isoformat()
    }