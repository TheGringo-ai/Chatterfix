#!/usr/bin/env python3
"""
CMMS Admin Module
Handles administrative functions, user management, system configuration
"""

from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Admin router
admin_router = APIRouter(prefix="/admin", tags=["admin"])

# Data models
class User(BaseModel):
    id: str
    username: str
    email: str
    role: str
    active: bool
    created_date: str
    last_login: Optional[str] = None

class SystemConfig(BaseModel):
    maintenance_schedule_days: int
    auto_assign_technicians: bool
    email_notifications: bool
    backup_frequency: str
    ai_model_preference: str

# Mock database
users_db = [
    {
        "id": "USR-001",
        "username": "admin",
        "email": "admin@chatterfix.com",
        "role": "administrator",
        "active": True,
        "created_date": "2025-08-01",
        "last_login": "2025-09-01T15:30:00"
    },
    {
        "id": "USR-002", 
        "username": "tech1",
        "email": "tech1@chatterfix.com",
        "role": "technician",
        "active": True,
        "created_date": "2025-08-15",
        "last_login": "2025-09-01T14:20:00"
    },
    {
        "id": "USR-003",
        "username": "manager1", 
        "email": "manager@chatterfix.com",
        "role": "manager",
        "active": True,
        "created_date": "2025-08-20",
        "last_login": "2025-09-01T16:45:00"
    },
    {
        "id": "USR-004",
        "username": "tech2",
        "email": "tech2@chatterfix.com", 
        "role": "technician",
        "active": False,
        "created_date": "2025-08-25",
        "last_login": "2025-08-28T10:30:00"
    }
]

# System configuration
system_config = {
    "maintenance_schedule_days": 30,
    "auto_assign_technicians": True,
    "email_notifications": True,
    "backup_frequency": "daily",
    "ai_model_preference": "balanced"
}

@admin_router.get("/dashboard", response_class=HTMLResponse)
async def admin_dashboard():
    """Admin dashboard with user management and system controls"""
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - Admin Dashboard</title>
        <style>
            {get_base_styles()}
            {get_navigation_styles()}
            
            .stat {{ 
                display: flex; 
                justify-content: space-between; 
                align-items: center; 
                margin: 1rem 0; 
                padding: 0.5rem 0;
                border-bottom: 1px solid rgba(255,255,255,0.1);
            }}
            .action-buttons {{
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                margin-top: 1rem;
            }}
        </style>
    </head>
    <body>
        {get_navigation_html('admin')}
        
        <div class="header">
            <h1>⚖️ Administration Dashboard</h1>
            <p>System Administration & User Management</p>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card">
                    <h3>📊 System Overview</h3>
                    <div class="stat">
                        <span>Total Users</span>
                        <span class="stat-value">{len(users_db)}</span>
                    </div>
                    <div class="stat">
                        <span>Active Users</span>
                        <span class="stat-value">{len([u for u in users_db if u['active']])}</span>
                    </div>
                    <div class="stat">
                        <span>System Uptime</span>
                        <span class="stat-value">99.8%</span>
                    </div>
                    <button class="btn" onclick="refreshStats()">Refresh Stats</button>
                </div>
                
                <div class="card">
                    <h3>⚙️ System Configuration</h3>
                    <div class="stat">
                        <span>Maintenance Cycle</span>
                        <span>{system_config['maintenance_schedule_days']} days</span>
                    </div>
                    <div class="stat">
                        <span>Auto Assignment</span>
                        <span>{'✅ Enabled' if system_config['auto_assign_technicians'] else '❌ Disabled'}</span>
                    </div>
                    <div class="stat">
                        <span>AI Model</span>
                        <span>{system_config['ai_model_preference'].title()}</span>
                    </div>
                    <button class="btn" onclick="configureSystem()">Configure</button>
                </div>
                
                <div class="card">
                    <h3>⚡ Quick Actions</h3>
                    <div class="action-buttons">
                        <button class="btn" onclick="createUser()">Add New User</button>
                        <button class="btn" onclick="systemBackup()">System Backup</button>
                        <button class="btn" onclick="viewLogs()">View System Logs</button>
                        <button class="btn" onclick="exportData()">Export Data</button>
                        <button class="btn btn-danger" onclick="systemRestart()">Restart System</button>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <h3>👥 User Management</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTable">
                        {chr(10).join([f'''
                        <tr>
                            <td>{user['id']}</td>
                            <td>{user['username']}</td>
                            <td>{user['email']}</td>
                            <td>{user['role'].title()}</td>
                            <td class="{'status-active' if user['active'] else 'status-inactive'}">
                                {'Active' if user['active'] else 'Inactive'}
                            </td>
                            <td>{user.get('last_login', 'Never')}</td>
                            <td>
                                <button class="btn" onclick="editUser('{user['id']}')">Edit</button>
                                <button class="btn btn-danger" onclick="toggleUser('{user['id']}')">
                                    {'Deactivate' if user['active'] else 'Activate'}
                                </button>
                            </td>
                        </tr>''' for user in users_db])}
                    </tbody>
                </table>
            </div>
        </div>
        
        <script>
            {get_navigation_javascript()}
            
            function refreshStats() {{
                fetch('/admin/stats')
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Stats refreshed:', data);
                        location.reload();
                    }});
            }}
            
            function createUser() {{
                const username = prompt('Username:');
                if (!username) return;
                const email = prompt('Email:');
                if (!email) return;
                const role = prompt('Role (technician/manager/administrator):');
                if (!role) return;
                
                fetch('/admin/users', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ username, email, role }})
                }})
                .then(response => response.json())
                .then(data => {{
                    alert('User created: ' + data.id);
                    location.reload();
                }});
            }}
            
            function editUser(userId) {{
                fetch(`/admin/users/${{userId}}`)
                    .then(response => response.json())
                    .then(user => {{
                        const newEmail = prompt('New email:', user.email);
                        if (newEmail && newEmail !== user.email) {{
                            fetch(`/admin/users/${{userId}}`, {{
                                method: 'PUT',
                                headers: {{ 'Content-Type': 'application/json' }},
                                body: JSON.stringify({{ email: newEmail }})
                            }})
                            .then(() => location.reload());
                        }}
                    }});
            }}
            
            function toggleUser(userId) {{
                if (confirm('Toggle user status?')) {{
                    fetch(`/admin/users/${{userId}}/toggle`, {{ method: 'POST' }})
                        .then(() => location.reload());
                }}
            }}
            
            function systemBackup() {{
                fetch('/admin/backup', {{ method: 'POST' }})
                    .then(response => response.json())
                    .then(data => alert('Backup initiated: ' + data.backup_id));
            }}
            
            function systemRestart() {{
                if (confirm('Restart the entire system? This will cause downtime.')) {{
                    fetch('/admin/restart', {{ method: 'POST' }})
                        .then(() => alert('System restart initiated...'));
                }}
            }}
            
            function configureSystem() {{
                alert('System configuration panel would open here');
            }}
            
            function viewLogs() {{
                window.open('/admin/logs', '_blank');
            }}
            
            function exportData() {{
                window.open('/admin/export', '_blank');
            }}
        </script>
    </body>
    </html>
    """

@admin_router.get("/users")
async def get_users() -> List[Dict]:
    """Get all users"""
    return users_db

@admin_router.get("/users/{user_id}")
async def get_user(user_id: str) -> Dict:
    """Get specific user"""
    user = next((u for u in users_db if u['id'] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@admin_router.post("/users")
async def create_user(user_data: Dict[str, str]) -> Dict:
    """Create new user"""
    user_id = f"USR-{len(users_db) + 1:03d}"
    new_user = {
        "id": user_id,
        "username": user_data["username"],
        "email": user_data["email"],
        "role": user_data["role"],
        "active": True,
        "created_date": datetime.now().strftime("%Y-%m-%d"),
        "last_login": None
    }
    users_db.append(new_user)
    logger.info(f"User created: {user_id}")
    return new_user

@admin_router.put("/users/{user_id}")
async def update_user(user_id: str, user_data: Dict[str, Any]) -> Dict:
    """Update user"""
    user = next((u for u in users_db if u['id'] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.update(user_data)
    logger.info(f"User updated: {user_id}")
    return user

@admin_router.post("/users/{user_id}/toggle")
async def toggle_user(user_id: str) -> Dict:
    """Toggle user active status"""
    user = next((u for u in users_db if u['id'] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user['active'] = not user['active']
    logger.info(f"User {'activated' if user['active'] else 'deactivated'}: {user_id}")
    return user

@admin_router.get("/stats")
async def get_system_stats() -> Dict:
    """Get system statistics"""
    return {
        "total_users": len(users_db),
        "active_users": len([u for u in users_db if u['active']]),
        "system_uptime": "99.8%",
        "last_backup": "2025-09-01T02:00:00",
        "disk_usage": "45%",
        "memory_usage": "67%",
        "timestamp": datetime.now().isoformat()
    }

@admin_router.post("/backup")
async def create_backup() -> Dict:
    """Create system backup"""
    backup_id = f"BKP-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    logger.info(f"Backup initiated: {backup_id}")
    return {
        "backup_id": backup_id,
        "status": "initiated",
        "timestamp": datetime.now().isoformat()
    }

@admin_router.post("/restart")
async def restart_system() -> Dict:
    """Restart system (admin only)"""
    logger.warning("System restart requested by admin")
    return {
        "status": "restart_initiated",
        "timestamp": datetime.now().isoformat(),
        "estimated_downtime": "2-3 minutes"
    }

@admin_router.get("/config")
async def get_config() -> Dict:
    """Get system configuration"""
    return system_config

@admin_router.put("/config")
async def update_config(config_data: SystemConfig) -> Dict:
    """Update system configuration"""
    system_config.update(config_data.model_dump())
    logger.info("System configuration updated")
    return system_config

@admin_router.get("/logs")
async def get_system_logs():
    """Get system logs (HTML page)"""
    return HTMLResponse(f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - System Logs</title>
        <style>
            {get_base_styles()}
            {get_navigation_styles()}
            .log-container {{
                background: rgba(0,0,0,0.5);
                border-radius: 8px;
                padding: 1rem;
                max-height: 600px;
                overflow-y: auto;
                font-family: 'Courier New', monospace;
                font-size: 0.9rem;
                line-height: 1.4;
            }}
            .log-entry {{
                margin-bottom: 0.5rem;
                padding: 0.25rem;
            }}
            .log-info {{ color: #68d391; }}
            .log-warn {{ color: #fbb6ce; }}
            .log-error {{ color: #fc8181; }}
        </style>
    </head>
    <body>
        {get_navigation_html('admin')}
        
        <div class="header">
            <h1>📋 System Logs</h1>
            <p>ChatterFix CMMS Activity Monitor</p>
        </div>
        
        <div class="container">
            <div class="card">
                <div class="log-container">
                    <div class="log-entry log-info">[2025-09-01 15:30:15] INFO - System started</div>
                    <div class="log-entry log-info">[2025-09-01 15:30:16] INFO - Database connected</div>
                    <div class="log-entry log-info">[2025-09-01 15:30:17] INFO - AI models initialized</div>
                    <div class="log-entry log-info">[2025-09-01 15:45:23] INFO - User USR-001 logged in</div>
                    <div class="log-entry log-info">[2025-09-01 16:12:45] INFO - Work order WO-001 created</div>
                    <div class="log-entry log-info">[2025-09-01 16:34:12] INFO - Equipment EQ-001 health check completed</div>
                    <div class="log-entry log-info">[2025-09-01 17:21:33] INFO - Backup completed successfully</div>
                    <div class="log-entry log-warn">[2025-09-01 18:45:21] WARN - High memory usage detected</div>
                    <div class="log-entry log-error">[2025-09-01 19:02:15] ERROR - Failed to connect to sensor EQ-003</div>
                    <div class="log-entry log-info">[2025-09-01 19:15:44] INFO - Sensor connection restored</div>
                </div>
                <button class="btn" onclick="location.reload()">Refresh Logs</button>
            </div>
        </div>
        
        <script>
            {get_navigation_javascript()}
        </script>
    </body>
    </html>
    """)

@admin_router.get("/export")
async def export_data():
    """Export system data"""
    return {
        "export_url": "/admin/download/chatterfix-export-20250901.json",
        "timestamp": datetime.now().isoformat(),
        "includes": ["users", "work_orders", "equipment", "configurations"]
    }