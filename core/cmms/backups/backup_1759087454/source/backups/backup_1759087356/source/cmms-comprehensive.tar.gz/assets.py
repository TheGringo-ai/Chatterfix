#!/usr/bin/env python3
"""
CMMS Assets Module
Equipment/asset management with tracking, maintenance schedules, and monitoring
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging
from workorders import work_orders_db

logger = logging.getLogger(__name__)

# Assets router
assets_router = APIRouter(prefix="/assets", tags=["assets"])

# Data models
class Asset(BaseModel):
    id: str
    name: str
    category: str
    location: str
    status: str
    condition: str
    manufacturer: str
    model: str
    serial_number: str
    installation_date: str
    last_maintenance: Optional[str] = None
    
    next_maintenance: Optional[str] = None
    maintenance_frequency: int  # days
    criticality: str
    cost_center: str
    specifications: Dict[str, Any]

class MaintenanceHistory(BaseModel):
    id: str
    asset_id: str
    date: str
    type: str
    technician: str
    description: str
    cost: float
    downtime_hours: float

class AssetMetrics(BaseModel):
    uptime_percentage: float
    mtbf: float  # Mean Time Between Failures
    mttr: float  # Mean Time To Repair
    maintenance_cost_ytd: float
    failure_count: int

# Mock database
assets_db = [
    {
        "id": "AST-001",
        "name": "Primary Air Compressor",
        "category": "Compressor",
        "location": "Building A - Mechanical Room",
        "status": "operational",
        "condition": "good",
        "manufacturer": "Atlas Copco",
        "model": "GA37VSD+",
        "serial_number": "AC2024001",
        "installation_date": "2024-01-15",
        "last_maintenance": "2025-08-15",
        "next_maintenance": "2025-11-15",
        "maintenance_frequency": 90,
        "criticality": "critical",
        "cost_center": "PROD-001",
        "specifications": {
            "power": "37kW",
            "pressure": "8 bar",
            "flow_rate": "6.2 m³/min",
            "voltage": "400V"
        }
    },
    {
        "id": "AST-002", 
        "name": "Conveyor Belt System",
        "category": "Conveyor",
        "location": "Production Floor 1",
        "status": "operational",
        "condition": "fair",
        "manufacturer": "FlexLink",
        "model": "X45-2000",
        "serial_number": "FL2023045",
        "installation_date": "2023-06-10",
        "last_maintenance": "2025-08-20",
        "next_maintenance": "2025-09-20",
        "maintenance_frequency": 30,
        "criticality": "high",
        "cost_center": "PROD-001",
        "specifications": {
            "length": "50m",
            "width": "300mm",
            "speed": "0.5-2.0 m/s",
            "load_capacity": "25kg/m"
        }
    },
    {
        "id": "AST-003",
        "name": "HVAC Unit 1",
        "category": "HVAC",
        "location": "Building A - Roof",
        "status": "maintenance_due",
        "condition": "good",
        "manufacturer": "Carrier",
        "model": "50TC024",
        "serial_number": "CR2023112",
        "installation_date": "2023-03-20",
        "last_maintenance": "2025-06-01",
        "next_maintenance": "2025-09-01",
        "maintenance_frequency": 90,
        "criticality": "medium",
        "cost_center": "FAC-001",
        "specifications": {
            "cooling_capacity": "24 tons",
            "heating_capacity": "80kW",
            "airflow": "4000 CFM",
            "efficiency": "16 SEER"
        }
    },
    {
        "id": "AST-004",
        "name": "Emergency Generator",
        "category": "Generator",
        "location": "Building A - Generator Room", 
        "status": "operational",
        "condition": "excellent",
        "manufacturer": "Caterpillar",
        "model": "DE150",
        "serial_number": "CT2024022",
        "installation_date": "2024-02-10",
        "last_maintenance": "2025-08-01",
        "next_maintenance": "2025-11-01",
        "maintenance_frequency": 90,
        "criticality": "critical",
        "cost_center": "FAC-001",
        "specifications": {
            "power": "150kW",
            "fuel_type": "Diesel",
            "fuel_capacity": "500L",
            "runtime": "24hrs at full load"
        }
    },
    {
        "id": "AST-005",
        "name": "Packaging Machine Alpha",
        "category": "Packaging",
        "location": "Production Floor 2",
        "status": "down",
        "condition": "poor",
        "manufacturer": "Bosch",
        "model": "HorizontalPacker-300",
        "serial_number": "BS2022078",
        "installation_date": "2022-11-05",
        "last_maintenance": "2025-07-10",
        "next_maintenance": "2025-08-10",
        "maintenance_frequency": 30,
        "criticality": "high",
        "cost_center": "PROD-002",
        "specifications": {
            "speed": "300 packages/min",
            "package_size": "50-500g",
            "sealing_type": "Heat seal",
            "power": "5kW"
        }
    }
]

maintenance_history_db = [
    {
        "id": "MH-001",
        "asset_id": "AST-001",
        "date": "2025-08-15",
        "type": "scheduled",
        "technician": "John Smith",
        "description": "Quarterly maintenance - oil change, filter replacement, performance check",
        "cost": 450.00,
        "downtime_hours": 4.0
    },
    {
        "id": "MH-002",
        "asset_id": "AST-002",
        "date": "2025-08-20",
        "type": "scheduled",
        "technician": "Mike Johnson",
        "description": "Monthly belt inspection and lubrication",
        "cost": 125.00,
        "downtime_hours": 1.5
    },
    {
        "id": "MH-003",
        "asset_id": "AST-005",
        "date": "2025-08-25",
        "type": "emergency",
        "technician": "Sarah Davis",
        "description": "Emergency repair - motor replacement due to bearing failure",
        "cost": 1250.00,
        "downtime_hours": 12.0
    }
]

# Mock work orders database
work_orders_db = [
    {
        "id": "WO-001",
        "asset_id": "AST-001",
        "title": "Air Filter Replacement",
        "description": "Replace the air filter in the compressor.",
        "status": "completed",
        "priority": "high",
        "scheduled_date": "2025-08-10",
        "completion_date": "2025-08-12",
        "technician": "John Doe"
    },
    {
        "id": "WO-002",
        "asset_id": "AST-001",
        "title": "Belt Tension Adjustment",
        "description": "Adjust the tension of the main drive belt.",
        "status": "in_progress",
        "priority": "medium",
        "scheduled_date": "2025-08-15",
        "technician": "Jane Smith"
    },
    {
        "id": "WO-003",
        "asset_id": "AST-002",
        "title": "Monthly Inspection",
        "description": "Conduct monthly inspection and maintenance.",
        "status": "scheduled",
        "priority": "low",
        "scheduled_date": "2025-09-01",
        "technician": "Emily Johnson"
    }
]

@assets_router.get("/dashboard", response_class=HTMLResponse)
async def assets_dashboard():
    """Assets dashboard with equipment overview and monitoring"""
    total_assets = len(assets_db)
    operational_assets = len([a for a in assets_db if a['status'] == 'operational'])
    maintenance_due = len([a for a in assets_db if a['status'] == 'maintenance_due'])
    down_assets = len([a for a in assets_db if a['status'] == 'down'])
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix Assets Management</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 1rem 0; }}
            .stat-value {{ font-size: 2rem; font-weight: bold; }}
            .status-operational {{ color: #38a169; }}
            .status-maintenance {{ color: #d69e2e; }}
            .status-down {{ color: #e53e3e; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-success {{ background: #38a169; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
            .table th, .table td {{ padding: 0.75rem; text-align: left; border-bottom: 1px solid #e2e8f0; }}
            .table th {{ background: #edf2f7; font-weight: 600; }}
            .filter-bar {{ background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; align-items: center; }}
            .filter-bar select, .filter-bar input {{ padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .asset-card {{ border-left: 4px solid #4299e1; }}
            .asset-card.critical {{ border-left-color: #e53e3e; }}
            .asset-card.high {{ border-left-color: #d69e2e; }}
            .asset-card.medium {{ border-left-color: #38a169; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>ChatterFix Assets Management</h1>
            <p>Equipment Tracking, Maintenance Scheduling & Asset Monitoring</p>
        </div>
        
        <div class="container">
            <!-- Stats Overview -->
            <div class="grid">
                <div class="card">
                    <h3>Asset Overview</h3>
                    <div class="stat">
                        <span>Total Assets</span>
                        <span class="stat-value">{total_assets}</span>
                    </div>
                    <div class="stat">
                        <span>Operational</span>
                        <span class="stat-value status-operational">{operational_assets}</span>
                    </div>
                    <div class="stat">
                        <span>Maintenance Due</span>
                        <span class="stat-value status-maintenance">{maintenance_due}</span>
                    </div>
                    <div class="stat">
                        <span>Down</span>
                        <span class="stat-value status-down">{down_assets}</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>Quick Actions</h3>
                    <button class="btn" onclick="addAsset()">Add New Asset</button>
                    <button class="btn btn-warning" onclick="scheduleMaintenanceReview()">Schedule Maintenance</button>
                    <button class="btn btn-success" onclick="generateReport()">Generate Report</button>
                    <button class="btn" onclick="importAssets()">Import Assets</button>
                    <button class="btn" onclick="exportData()">Export Data</button>
                </div>
                
                <div class="card">
                    <h3>Key Metrics</h3>
                    <div class="stat">
                        <span>Overall Equipment Effectiveness</span>
                        <span class="stat-value status-operational">87%</span>
                    </div>
                    <div class="stat">
                        <span>Average Uptime</span>
                        <span class="stat-value status-operational">94.2%</span>
                    </div>
                    <div class="stat">
                        <span>Maintenance Cost (MTD)</span>
                        <span class="stat-value">$4,250</span>
                    </div>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <label>Filter by:</label>
                <select id="statusFilter" onchange="filterAssets()">
                    <option value="">All Status</option>
                    <option value="operational">Operational</option>
                    <option value="maintenance_due">Maintenance Due</option>
                    <option value="down">Down</option>
                </select>
                <select id="categoryFilter" onchange="filterAssets()">
                    <option value="">All Categories</option>
                    <option value="Compressor">Compressor</option>
                    <option value="Conveyor">Conveyor</option>
                    <option value="HVAC">HVAC</option>
                    <option value="Generator">Generator</option>
                    <option value="Packaging">Packaging</option>
                </select>
                <select id="criticalityFilter" onchange="filterAssets()">
                    <option value="">All Criticality</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                </select>
                <input type="text" id="searchFilter" placeholder="Search assets..." onkeyup="filterAssets()">
            </div>
            
            <!-- Assets Grid -->
            <div class="grid" id="assetsGrid">
                {"".join([f'''
                <div class="card asset-card {asset['criticality']}" data-status="{asset['status']}" data-category="{asset['category']}" data-criticality="{asset['criticality']}" data-name="{asset['name']}">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                        <div>
                            <h4 style="margin: 0; color: #2d3748;">{asset['name']}</h4>
                            <p style="margin: 0.25rem 0; color: #718096;">{asset['category']} — {asset['location']}</p>
                        </div>
                        <span class="btn btn-sm status-{asset['status']}">{asset['status'].replace('_', ' ').title()}</span>
                    </div>
                    
                    <div style="margin-bottom: 1rem;">
                        <div><strong>Manufacturer:</strong> {asset['manufacturer']} {asset['model']}</div>
                        <div><strong>Serial:</strong> {asset['serial_number']}</div>
                        <div><strong>Condition:</strong> {asset['condition'].title()}</div>
                        <div><strong>Criticality:</strong> {asset['criticality'].title()}</div>
                    </div>
                    
                    <div style="margin-bottom: 1rem; padding: 0.75rem; background: #f7fafc; border-radius: 4px;">
                        <div><strong>Last Maintenance:</strong> {asset.get('last_maintenance', 'Never')}</div>
                        <div><strong>Next Maintenance:</strong> {asset.get('next_maintenance', 'Not scheduled')}</div>
                        <div><strong>Frequency:</strong> Every {asset['maintenance_frequency']} days</div>
                    </div>
                    
                    <div>
                        <button class="btn btn-sm" onclick="viewAssetDetails('{asset['id']}')">View Details</button>
                        <button class="btn btn-sm btn-warning" onclick="scheduleMaintenance('{asset['id']}')">Schedule</button>
                        <button class="btn btn-sm" onclick="editAsset('{asset['id']}')">Edit</button>
                        {f'<button class="btn btn-sm btn-danger" onclick="reportIssue(\'{asset["id"]}\')">Report Issue</button>' if asset['status'] == 'operational' else ''}
                    </div>
                </div>''' for asset in assets_db])}
            </div>
            
            <!-- Recent Maintenance History -->
            <div class="card" style="margin-top: 2rem;">
                <h3>Recent Maintenance History</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Asset</th>
                            <th>Type</th>
                            <th>Technician</th>
                            <th>Description</th>
                            <th>Cost</th>
                            <th>Downtime</th>
                        </tr>
                    </thead>
                    <tbody>
                        {chr(10).join([f'''
                        <tr>
                            <td>{history['date']}</td>
                            <td>{next((a['name'] for a in assets_db if a['id'] == history['asset_id']), 'Unknown')}</td>
                            <td><span class="btn btn-sm {'btn-warning' if history['type'] == 'emergency' else ''}">{history['type'].title()}</span></td>
                            <td>{history['technician']}</td>
                            <td>{history['description'][:50]}{'...' if len(history['description']) > 50 else ''}</td>
                            <td>${history['cost']:,.2f}</td>
                            <td>{history['downtime_hours']}h</td>
                        </tr>''' for history in maintenance_history_db[-10:]])}
                    </tbody>
                </table>
            </div>
        </div>
        
        <script>
            function filterAssets() {{
                const statusFilter = document.getElementById('statusFilter').value;
                const categoryFilter = document.getElementById('categoryFilter').value;
                const criticalityFilter = document.getElementById('criticalityFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const assetCards = document.querySelectorAll('.asset-card');
                assetCards.forEach(card => {{
                    const status = card.dataset.status;
                    const category = card.dataset.category;
                    const criticality = card.dataset.criticality;
                    const name = card.dataset.name.toLowerCase();
                    
                    const statusMatch = !statusFilter || status === statusFilter;
                    const categoryMatch = !categoryFilter || category === categoryFilter;
                    const criticalityMatch = !criticalityFilter || criticality === criticalityFilter;
                    const searchMatch = !searchFilter || name.includes(searchFilter);
                    
                    card.style.display = (statusMatch && categoryMatch && criticalityMatch && searchMatch) ? 'block' : 'none';
                }});
            }}
            
            function addAsset() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; max-height: 90%; overflow-y: auto;" onclick="event.stopPropagation()">
                            <h3>Add New Asset</h3>
                            <form id="addAssetForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Asset Name:</label><br>
                                    <input type="text" name="name" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Category:</label><br>
                                    <select name="category" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="">Select Category</option>
                                        <option value="Compressor">Compressor</option>
                                        <option value="Conveyor">Conveyor</option>
                                        <option value="HVAC">HVAC</option>
                                        <option value="Generator">Generator</option>
                                        <option value="Packaging">Packaging</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Location:</label><br>
                                    <input type="text" name="location" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Manufacturer:</label><br>
                                    <input type="text" name="manufacturer" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Model:</label><br>
                                    <input type="text" name="model" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Serial Number:</label><br>
                                    <input type="text" name="serial_number" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Criticality:</label><br>
                                    <select name="criticality" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="">Select Criticality</option>
                                        <option value="critical">Critical</option>
                                        <option value="high">High</option>
                                        <option value="medium">Medium</option>
                                        <option value="low">Low</option>
                                    </select>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Maintenance Frequency (days):</label><br>
                                    <input type="number" name="maintenance_frequency" value="30" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" class="btn">Create Asset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('addAssetForm').addEventListener('submit', function(e) {{
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const assetData = Object.fromEntries(formData);
                    
                    fetch('/assets', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(assetData)
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Asset created:', data);
                        location.reload();
                    }});
                }});
            }}
            
            function closeModal(event) {{
                if (event.target === event.currentTarget) {{
                    document.body.removeChild(event.currentTarget);
                }}
            }}
            
            function viewAssetDetails(assetId) {{
                window.open(`/cmms/assets/${{assetId}}/view`, '_blank');
            }}
            
            function scheduleMaintenance(assetId) {{
                window.location.href = `/prevenative/schedule?asset_id=${{assetId}}`;
            }}
            
            function editAsset(assetId) {{
                window.location.href = `/assets/${{assetId}}/edit`;
            }}
            
            function reportIssue(assetId) {{
                window.location.href = `/workorders/create?asset_id=${{assetId}}&type=reactive`;
            }}
            
            function scheduleMaintenanceReview() {{
                window.location.href = '/prevenative/dashboard';
            }}
            
            function generateReport() {{
                window.open('/assets/reports', '_blank');
            }}
            
            function importAssets() {{
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.csv,.xlsx';
                input.onchange = function(e) {{
                    const file = e.target.files[0];
                    if (file) {{
                        console.log('Importing assets from:', file.name);
                        // Would implement actual import logic
                        alert('Import functionality would be implemented here');
                    }}
                }};
                input.click();
            }}
            
            function exportData() {{
                window.open('/assets/export', '_blank');
            }}
        </script>
    </body>
    </html>
    """

@assets_router.get("/")
async def get_assets(
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    criticality: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all assets with optional filtering"""
    filtered_assets = assets_db
    
    if status:
        filtered_assets = [a for a in filtered_assets if a['status'] == status]
    if category:
        filtered_assets = [a for a in filtered_assets if a['category'] == category]
    if criticality:
        filtered_assets = [a for a in filtered_assets if a['criticality'] == criticality]
    
    return filtered_assets

@assets_router.get("/{asset_id}")
async def get_asset(asset_id: str) -> Dict:
    """Get specific asset details"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    # Get maintenance history for this asset
    history = [h for h in maintenance_history_db if h['asset_id'] == asset_id]
    
    return {
        "asset": asset,
        "maintenance_history": history,
        "metrics": {
            "uptime_percentage": 94.2,
            "mtbf": 720.0,  # hours
            "mttr": 4.5,    # hours
            "maintenance_cost_ytd": sum(h['cost'] for h in history),
            "failure_count": len([h for h in history if h['type'] == 'emergency'])
        }
    }

@assets_router.post("/")
async def create_asset(asset_data: Dict[str, Any]) -> Dict:
    """Create new asset"""
    asset_id = f"AST-{len(assets_db) + 1:03d}"
    
    new_asset = {
        "id": asset_id,
        "name": asset_data["name"],
        "category": asset_data["category"],
        "location": asset_data["location"],
        "status": "operational",
        "condition": "good",
        "manufacturer": asset_data["manufacturer"],
        "model": asset_data["model"],
        "serial_number": asset_data["serial_number"],
        "installation_date": datetime.now().strftime("%Y-%m-%d"),
        "last_maintenance": None,
        "next_maintenance": (datetime.now() + timedelta(days=asset_data.get("maintenance_frequency", 30))).strftime("%Y-%m-%d"),
        "maintenance_frequency": asset_data.get("maintenance_frequency", 30),
        "criticality": asset_data["criticality"],
        "cost_center": asset_data.get("cost_center", "GENERAL"),
        "specifications": asset_data.get("specifications", {})
    }
    
    assets_db.append(new_asset)
    logger.info(f"Asset created: {asset_id}")
    return new_asset

@assets_router.put("/{asset_id}")
async def update_asset(asset_id: str, asset_data: Dict[str, Any]) -> Dict:
    """Update asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    asset.update(asset_data)
    logger.info(f"Asset updated: {asset_id}")
    return asset

@assets_router.post("/{asset_id}/maintenance")
async def record_maintenance(asset_id: str, maintenance_data: Dict[str, Any]) -> Dict:
    """Record maintenance activity"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    maintenance_id = f"MH-{len(maintenance_history_db) + 1:03d}"
    
    maintenance_record = {
        "id": maintenance_id,
        "asset_id": asset_id,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "type": maintenance_data["type"],
        "technician": maintenance_data["technician"],
        "description": maintenance_data["description"],
        "cost": maintenance_data.get("cost", 0.0),
        "downtime_hours": maintenance_data.get("downtime_hours", 0.0)
    }
    
    maintenance_history_db.append(maintenance_record)
    
    # Update asset maintenance dates
    asset["last_maintenance"] = maintenance_record["date"]
    if maintenance_data["type"] == "scheduled":
        next_date = datetime.now() + timedelta(days=asset["maintenance_frequency"])
        asset["next_maintenance"] = next_date.strftime("%Y-%m-%d")
        asset["status"] = "operational"
    
    logger.info(f"Maintenance recorded: {maintenance_id} for asset {asset_id}")
    return maintenance_record

@assets_router.get("/{asset_id}/history")
async def get_asset_history(asset_id: str) -> List[Dict]:
    """Get maintenance history for specific asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    return [h for h in maintenance_history_db if h['asset_id'] == asset_id]

@assets_router.get("/reports/summary")
async def get_assets_summary() -> Dict:
    """Get asset summary report"""
    total_assets = len(assets_db)
    by_status = {}
    by_category = {}
    by_criticality = {}
    
    for asset in assets_db:
        by_status[asset['status']] = by_status.get(asset['status'], 0) + 1
        by_category[asset['category']] = by_category.get(asset['category'], 0) + 1
        by_criticality[asset['criticality']] = by_criticality.get(asset['criticality'], 0) + 1
    
    total_maintenance_cost = sum(h['cost'] for h in maintenance_history_db)
    avg_uptime = 94.2  # Would calculate from actual data
    
    return {
        "total_assets": total_assets,
        "breakdown_by_status": by_status,
        "breakdown_by_category": by_category,
        "breakdown_by_criticality": by_criticality,
        "total_maintenance_cost_ytd": total_maintenance_cost,
        "average_uptime": avg_uptime,
        "assets_requiring_attention": len([a for a in assets_db if a['status'] in ['maintenance_due', 'down']]),
        "generated_at": datetime.now().isoformat()
    }

@assets_router.get("/export/csv")
async def export_assets_csv():
    """Export assets to CSV"""
    import io
    import csv
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=assets_db[0].keys() if assets_db else [])
    writer.writeheader()
    for asset in assets_db:
        # Flatten specifications dict for CSV
        row = asset.copy()
        row['specifications'] = str(asset['specifications'])
        writer.writerow(row)
    
    return {
        "filename": f"chatterfix_assets_{datetime.now().strftime('%Y%m%d')}.csv",
        "content": output.getvalue(),
        "content_type": "text/csv"
    }

@assets_router.get("/{asset_id}/view", response_class=HTMLResponse)
async def view_asset_page(asset_id: str):
    """Display a single asset in a full HTML page."""
    try:
        asset_details = await get_asset(asset_id)
        asset = asset_details['asset']
        history = asset_details['maintenance_history']
        metrics = asset_details['metrics']
        
        # Find related work orders
        related_work_orders = [wo for wo in work_orders_db if wo['asset_id'] == asset_id]

        def generate_history_html(history):
            if not history:
                return "<p>No maintenance history recorded.</p>"
            html = ""
            for item in sorted(history, key=lambda x: x['date'], reverse=True):
                html += f"""
                <div class="history-item">
                    <div class="history-header">
                        <strong>{item['type'].title()} Maintenance</strong>
                        <span class="timestamp">{item['date']}</span>
                    </div>
                    <p>{item['description']}</p>
                    <div class="history-footer">
                        <span>Technician: {item['technician']}</span>
                        <span>Cost: ${item['cost']:.2f}</span>
                        <span>Downtime: {item['downtime_hours']}h</span>
                    </div>
                </div>
                """
            return html

        def generate_work_orders_html(work_orders):
            if not work_orders:
                return "<p>No work orders for this asset.</p>"
            html = ""
            for wo in work_orders:
                html += f"""
                <div class="wo-item">
                    <a href="/cmms/workorders/{wo['id']}/view">{wo['id']}: {wo['title']}</a>
                    <span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span>
                </div>
                """
            return html

        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Asset Details: {asset['name']}</title>
            <style>
                body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; color: #2d3748; }}
                .header {{ background: #2d3748; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }}
                .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
                .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 2rem; }}
                .grid {{ display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; }}
                h1, h2, h3 {{ color: #1a202c; }}
                .asset-title {{ font-size: 2.5rem; margin-bottom: 0.5rem; }}
                .status-badge {{ padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 1rem; font-weight: 600; display: inline-block; }}
                .status-operational {{ background: #c6f6d5; color: #276749; }}
                .status-maintenance_due {{ background: #fefcbf; color: #975a16; }}
                .status-down {{ background: #fed7d7; color: #9b2c2c; }}
                .details-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-top: 1.5rem; }}
                .detail-item {{ background: #edf2f7; padding: 1rem; border-radius: 4px; }}
                .detail-item strong {{ display: block; font-size: 0.8rem; color: #718096; margin-bottom: 0.25rem; text-transform: uppercase; }}
                .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }}
                .btn-warning {{ background: #d69e2e; }}
                .btn-danger {{ background: #e53e3e; }}
                .history-item, .wo-item {{ border: 1px solid #e2e8f0; border-radius: 4px; padding: 1rem; margin-bottom: 1rem; }}
                .history-header, .wo-item {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }}
                .timestamp {{ font-size: 0.8rem; color: #718096; }}
                .history-footer {{ font-size: 0.9rem; color: #4a5568; display: flex; gap: 1.5rem; margin-top: 1rem; border-top: 1px solid #e2e8f0; padding-top: 0.75rem; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>ChatterFix CMMS</h1>
                <a href="/cmms/assets/dashboard" class="btn">Back to Assets</a>
            </div>
            <div class="container">
                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h1 class="asset-title">{asset['name']}</h1>
                            <p style="margin:0; color: #718096;">{asset['category']} / {asset['location']}</p>
                        </div>
                        <span class="status-badge status-{asset['status']}">{asset['status'].replace('_', ' ').title()}</span>
                    </div>
                </div>

                <div class="grid">
                    <div class="main-content">
                        <div class="card">
                            <h2>Asset Details</h2>
                            <div class="details-grid">
                                <div class="detail-item"><strong>Asset ID</strong> {asset['id']}</div>
                                <div class="detail-item"><strong>Manufacturer</strong> {asset['manufacturer']}</div>
                                <div class="detail-item"><strong>Model</strong> {asset['model']}</div>
                                <div class="detail-item"><strong>Serial Number</strong> {asset['serial_number']}</div>
                                <div class="detail-item"><strong>Installation Date</strong> {asset['installation_date']}</div>
                                <div class="detail-item"><strong>Criticality</strong> <span style="font-weight:bold; color: {'critical': '#e53e3e', 'high': '#d69e2e'}.get(asset['criticality'], '#38a169');">{asset['criticality'].title()}</span></div>
                                <div class="detail-item"><strong>Condition</strong> {asset['condition'].title()}</div>
                                <div class="detail-item"><strong>Cost Center</strong> {asset['cost_center']}</div>
                            </div>
                            <h3>Specifications</h3>
                            <ul>
                                {"".join(f"<li><strong>{key.replace('_', ' ').title()}:</strong> {value}</li>" for key, value in asset['specifications'].items())}
                            </ul>
                        </div>

                        <div class="card">
                            <h2>Maintenance History</h2>
                            {generate_history_html(history)}
                        </div>
                    </div>
                    <div class="sidebar">
                        <div class="card">
                            <h2>Actions</h2>
                            <a href="/cmms/workorders/create?asset_id={asset['id']}&type=reactive" class="btn btn-danger" style="display: block; margin-bottom: 1rem; text-align: center;">Create Work Order</a>
                            <a href="/cmms/assets/{asset['id']}/edit" class="btn btn-warning" style="display: block; text-align: center;">Edit Asset</a>
                        </div>
                        <div class="card">
                            <h2>Maintenance Schedule</h2>
                            <div class="detail-item"><strong>Last Maintenance</strong> {asset.get('last_maintenance', 'N/A')}</div>
                            <div class="detail-item" style="margin-top:1rem;"><strong>Next Maintenance</strong> {asset.get('next_maintenance', 'N/A')}</div>
                            <div class="detail-item" style="margin-top:1rem;"><strong>Frequency</strong> Every {asset['maintenance_frequency']} days</div>
                        </div>
                        <div class="card">
                            <h2>Related Work Orders</h2>
                            {generate_work_orders_html(related_work_orders)}
                        </div>
                        <div class="card">
                            <h2>Performance Metrics</h2>
                            <p><strong>Uptime:</strong> {metrics['uptime_percentage']}%</p>
                            <p><strong>MTBF:</strong> {metrics['mtbf']} hours</p>
                            <p><strong>MTTR:</strong> {metrics['mttr']} hours</p>
                            <p><strong>YTD Cost:</strong> ${metrics['maintenance_cost_ytd']:.2f}</p>
                            <p><strong>Failures:</strong> {metrics['failure_count']}</p>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
    except HTTPException as e:
        return f"<h1>Error</h1><p>Could not find asset with ID {asset_id}.</p><p>{e.detail}</p>"
    except Exception as e:
        logger.error(f"Error rendering asset page for {asset_id}: {e}")
        return f"<h1>Server Error</h1><p>An unexpected error occurred.</p>"