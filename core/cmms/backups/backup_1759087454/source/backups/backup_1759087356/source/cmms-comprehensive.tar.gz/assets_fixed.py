#!/usr/bin/env python3
"""
CMMS Assets Module - Fixed Version
Equipment/asset management with tracking, maintenance schedules
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, date
import logging
from unified_cmms_system import create_unified_page

logger = logging.getLogger(__name__)

# Assets router
assets_router = APIRouter(prefix="/assets", tags=["assets"])

# Data models
class Asset(BaseModel):
    id: str
    name: str
    category: str
    location: str
    status: str
    condition: str
    manufacturer: str
    model: Optional[str] = None
    serial_number: Optional[str] = None
    criticality: str
    maintenance_frequency: int

# Mock database - Comprehensive production equipment
assets_db = [
    {
        "id": "AST-001",
        "name": "Primary Air Compressor",
        "category": "Compressor",
        "location": "Building A - Mechanical Room",
        "status": "operational",
        "condition": "good",
        "manufacturer": "Atlas Copco",
        "model": "GA37VSD+",
        "serial_number": "AC2024001",
        "criticality": "critical",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-08-15",
        "next_maintenance": "2025-11-15",
        "health_score": 8.9
    },
    {
        "id": "AST-002", 
        "name": "Conveyor Belt System A",
        "category": "Conveyor",
        "location": "Production Floor 1 - Line A",
        "status": "operational",
        "condition": "fair",
        "manufacturer": "FlexLink",
        "model": "X45-2000",
        "serial_number": "FL2023045",
        "criticality": "high",
        "maintenance_frequency": 30,
        "last_maintenance": "2025-08-20",
        "next_maintenance": "2025-09-20",
        "health_score": 7.2
    },
    {
        "id": "AST-003",
        "name": "HVAC Unit 1 - Main Building",
        "category": "HVAC",
        "location": "Building A - Roof",
        "status": "maintenance_due",
        "condition": "good",
        "manufacturer": "Carrier",
        "model": "50TC024",
        "serial_number": "CR2023112",
        "criticality": "medium",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-06-01",
        "next_maintenance": "2025-09-01",
        "health_score": 8.5
    },
    {
        "id": "AST-004",
        "name": "Emergency Generator",
        "category": "Generator",
        "location": "Building A - Generator Room", 
        "status": "operational",
        "condition": "excellent",
        "manufacturer": "Caterpillar",
        "model": "DE150",
        "serial_number": "CT2024022",
        "criticality": "critical",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-08-01",
        "next_maintenance": "2025-11-01",
        "health_score": 9.4
    },
    {
        "id": "AST-005",
        "name": "Packaging Machine Alpha",
        "category": "Packaging",
        "location": "Production Floor 2 - Line Alpha",
        "status": "down",
        "condition": "poor",
        "manufacturer": "Bosch",
        "model": "HorizontalPacker-300",
        "serial_number": "BS2022078",
        "criticality": "high",
        "maintenance_frequency": 30,
        "last_maintenance": "2025-07-10",
        "next_maintenance": "2025-08-10",
        "health_score": 4.1
    },
    {
        "id": "AST-006",
        "name": "CNC Milling Machine 1",
        "category": "Machining",
        "location": "Machine Shop - Bay 1",
        "status": "operational",
        "condition": "good",
        "manufacturer": "Haas",
        "model": "VF-2SS",
        "serial_number": "HS2023034",
        "criticality": "high",
        "maintenance_frequency": 30,
        "last_maintenance": "2025-08-10",
        "next_maintenance": "2025-09-10",
        "health_score": 8.7
    },
    {
        "id": "AST-007",
        "name": "Robotic Welding Cell",
        "category": "Robotics",
        "location": "Fabrication Shop - Cell 3",
        "status": "operational",
        "condition": "excellent",
        "manufacturer": "ABB",
        "model": "IRB 1600-10/1.45",
        "serial_number": "ABB2024056",
        "criticality": "critical",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-08-25",
        "next_maintenance": "2025-11-25",
        "health_score": 9.2
    },
    {
        "id": "AST-008",
        "name": "Industrial Oven - Heat Treatment",
        "category": "Oven",
        "location": "Heat Treatment Area",
        "status": "operational",
        "condition": "good",
        "manufacturer": "Despatch",
        "model": "LFD-1-42",
        "serial_number": "DP2023089",
        "criticality": "medium",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-07-20",
        "next_maintenance": "2025-10-20",
        "health_score": 8.3
    },
    {
        "id": "AST-009",
        "name": "Overhead Crane 5-Ton",
        "category": "Crane",
        "location": "Main Production Hall",
        "status": "maintenance_due",
        "condition": "fair",
        "manufacturer": "Konecranes",
        "model": "CXT-5000",
        "serial_number": "KC2022145",
        "criticality": "high",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-05-15",
        "next_maintenance": "2025-08-15",
        "health_score": 6.9
    },
    {
        "id": "AST-010",
        "name": "Hydraulic Press 100-Ton",
        "category": "Press",
        "location": "Forming Department",
        "status": "operational",
        "condition": "good",
        "manufacturer": "Greenerd",
        "model": "GHP-100",
        "serial_number": "GR2023167",
        "criticality": "high",
        "maintenance_frequency": 90,
        "last_maintenance": "2025-08-05",
        "next_maintenance": "2025-11-05",
        "health_score": 8.6
    }
]

@assets_router.get("/dashboard", response_class=HTMLResponse)
async def assets_dashboard():
    """Assets management dashboard"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Assets - ChatterFix CMMS</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 2rem; }}
            .container {{ max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }}
            .stat-card {{ background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat-number {{ font-size: 2rem; font-weight: bold; color: #667eea; }}
            .stat-label {{ opacity: 0.7; margin-top: 0.5rem; }}
            .filters {{ background: white; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; }}
            .assets-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); gap: 1.5rem; }}
            .asset-card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .asset-card.critical {{ border-left: 4px solid #e53e3e; }}
            .asset-card.high {{ border-left: 4px solid #ff8c00; }}
            .asset-card.medium {{ border-left: 4px solid #fbbf24; }}
            .asset-card.low {{ border-left: 4px solid #10b981; }}
            .btn {{ background: #667eea; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn:hover {{ background: #5a6fd8; }}
            .btn-sm {{ padding: 0.25rem 0.75rem; font-size: 0.875rem; }}
            .btn-warning {{ background: #fbbf24; }}
            .btn-danger {{ background: #e53e3e; }}
            .status-operational {{ background: #10b981; }}
            .status-maintenance_due {{ background: #fbbf24; }}
            .status-offline {{ background: #e53e3e; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>⚙️ Asset Management</h1>
            <p>Equipment tracking, maintenance scheduling, and performance monitoring</p>
        </div>
        
        <div class="container">
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-number">{len(assets_db)}</div>
                    <div class="stat-label">Total Assets</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{len([a for a in assets_db if a['status'] == 'operational'])}</div>
                    <div class="stat-label">Operational</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{len([a for a in assets_db if a['status'] == 'maintenance_due'])}</div>
                    <div class="stat-label">Maintenance Due</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{sum(a.get('health_score', 0) for a in assets_db) / len(assets_db):.1f}</div>
                    <div class="stat-label">Avg Health Score</div>
                </div>
            </div>
            
            <div class="filters">
                <h3>Filter Assets</h3>
                <button class="btn" onclick="filterAssets('all')">All Assets</button>
                <button class="btn" onclick="filterAssets('operational')">Operational</button>
                <button class="btn" onclick="filterAssets('maintenance_due')">Maintenance Due</button>
                <button class="btn" onclick="filterAssets('critical')">Critical</button>
                <button class="btn btn-warning" onclick="addAsset()">Add New Asset</button>
            </div>
            
            <div class="assets-grid" id="assetsGrid">
    """
    
    # Add each asset card
    for asset in assets_db:
        asset_card = f"""
                <div class="asset-card {asset['criticality']}" data-status="{asset['status']}" data-criticality="{asset['criticality']}">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                        <div>
                            <h4 style="margin: 0; color: #2d3748;">{asset['name']}</h4>
                            <p style="margin: 0.25rem 0; color: #718096;">{asset['category']} • {asset['location']}</p>
                        </div>
                        <span class="btn btn-sm status-{asset['status']}">{asset['status'].replace('_', ' ').title()}</span>
                    </div>
                    
                    <div style="margin-bottom: 1rem;">
                        <div><strong>Manufacturer:</strong> {asset['manufacturer']} {asset.get('model', '')}</div>
                        <div><strong>Serial:</strong> {asset.get('serial_number', 'N/A')}</div>
                        <div><strong>Condition:</strong> {asset['condition'].title()}</div>
                        <div><strong>Health Score:</strong> {asset.get('health_score', 0)}/10</div>
                    </div>
                    
                    <div style="margin-bottom: 1rem; padding: 0.75rem; background: #f7fafc; border-radius: 4px;">
                        <div><strong>Last Maintenance:</strong> {asset.get('last_maintenance', 'Never')}</div>
                        <div><strong>Next Maintenance:</strong> {asset.get('next_maintenance', 'Not scheduled')}</div>
                        <div><strong>Frequency:</strong> Every {asset['maintenance_frequency']} days</div>
                    </div>
                    
                    <div>
                        <button class="btn btn-sm" onclick="viewAssetDetails('{asset['id']}')">View Details</button>
                        <button class="btn btn-sm btn-warning" onclick="scheduleMaintenance('{asset['id']}')">Schedule</button>
                        <button class="btn btn-sm" onclick="editAsset('{asset['id']}')">Edit</button>"""
        
        if asset['status'] == 'operational':
            asset_card += f"""
                        <button class="btn btn-sm btn-danger" onclick="reportIssue('{asset['id']}')">Report Issue</button>"""
        
        asset_card += """
                    </div>
                </div>"""
        
        asset_card += asset_card
    
    return asset_card + f"""
            </div>
        </div>
        
        <script>
            function filterAssets(filter) {{
                const cards = document.querySelectorAll('.asset-card');
                cards.forEach(card => {{
                    if (filter === 'all') {{
                        card.style.display = 'block';
                    }} else if (filter === 'critical') {{
                        card.style.display = card.classList.contains('critical') ? 'block' : 'none';
                    }} else {{
                        card.style.display = card.dataset.status === filter ? 'block' : 'none';
                    }}
                }});
            }}
            
            function viewAssetDetails(assetId) {{
                alert('Asset Details: ' + assetId);
            }}
            
            function scheduleMaintenance(assetId) {{
                alert('Schedule Maintenance for: ' + assetId);
            }}
            
            function editAsset(assetId) {{
                alert('Edit Asset: ' + assetId);
            }}
            
            function reportIssue(assetId) {{
                alert('Report Issue for: ' + assetId);
            }}
            
            function addAsset() {{
                alert('Add New Asset functionality would open here');
            }}
        </script>
    </body>
    </html>
    """

@assets_router.get("/")
async def get_assets() -> List[Dict]:
    """Get all assets"""
    return assets_db

@assets_router.get("/{asset_id}")
async def get_asset(asset_id: str) -> Dict:
    """Get specific asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    return asset

@assets_router.post("/")
async def create_asset(asset_data: Asset) -> Dict:
    """Create new asset"""
    asset_dict = asset_data.dict()
    asset_dict["id"] = f"ASSET-{len(assets_db) + 1:03d}"
    assets_db.append(asset_dict)
    logger.info(f"Asset created: {asset_dict['id']}")
    return asset_dict

@assets_router.put("/{asset_id}")
async def update_asset(asset_id: str, asset_data: Dict[str, Any]) -> Dict:
    """Update asset"""
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    
    asset.update(asset_data)
    logger.info(f"Asset updated: {asset_id}")
    return asset

@assets_router.get("/health")
async def assets_health_check() -> Dict:
    """Assets system health check"""
    return {
        "status": "operational",
        "total_assets": len(assets_db),
        "operational_assets": len([a for a in assets_db if a['status'] == 'operational']),
        "maintenance_due": len([a for a in assets_db if a['status'] == 'maintenance_due']),
        "average_health_score": sum(a.get('health_score', 0) for a in assets_db) / len(assets_db),
        "timestamp": datetime.now().isoformat()
    }