#!/usr/bin/env python3
"""
CMMS Technician Module - Working Version
Technician portal, task management, and mobile interface
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Technician router
technician_router = APIRouter(prefix="/technicians", tags=["technicians"])

# Data models
class Technician(BaseModel):
    id: str
    name: str
    email: str
    phone: str
    skills: List[str]
    certifications: List[str]
    status: str
    location: str
    shift: str

# Mock database (same as before)
technicians_db = [
    {
        "id": "TECH-001",
        "name": "John Smith",
        "email": "john.smith@chatterfix.com",
        "phone": "(555) 123-4567",
        "skills": ["Mechanical", "Electrical", "Pneumatics", "Generator"],
        "certifications": ["OSHA 30", "Electrical License", "Arc Flash"],
        "status": "available",
        "location": "Building A",
        "shift": "day"
    },
    {
        "id": "TECH-002", 
        "name": "Mike Johnson",
        "email": "mike.johnson@chatterfix.com",
        "phone": "(555) 234-5678",
        "skills": ["Mechanical", "Belt Systems", "Conveyor", "Packaging"],
        "certifications": ["OSHA 10", "Mechanical Certification"],
        "status": "busy",
        "location": "Production Floor 1",
        "shift": "day"
    },
    {
        "id": "TECH-003",
        "name": "Sarah Davis", 
        "email": "sarah.davis@chatterfix.com",
        "phone": "(555) 345-6789",
        "skills": ["HVAC", "Refrigeration", "Controls", "Electronics"],
        "certifications": ["EPA 608", "HVAC License", "Controls Certification"],
        "status": "available",
        "location": "Building A - Roof",
        "shift": "day"
    },
    {
        "id": "TECH-004",
        "name": "Carlos Rodriguez",
        "email": "carlos.rodriguez@chatterfix.com",
        "phone": "(555) 456-7890", 
        "skills": ["Electrical", "Automation", "PLC", "Motor Control"],
        "certifications": ["Journeyman Electrician", "PLC Programming", "Safety Training"],
        "status": "busy",
        "location": "Production Floor 2",
        "shift": "night"
    },
    {
        "id": "TECH-005",
        "name": "Lisa Wong",
        "email": "lisa.wong@chatterfix.com",
        "phone": "(555) 567-8901",
        "skills": ["Mechanical", "Welding", "Fabrication", "Precision"],
        "certifications": ["AWS Welding", "Machinist Certificate", "Safety Training"],
        "status": "available",
        "location": "Maintenance Shop", 
        "shift": "day"
    }
]

@technician_router.get("/portal", response_class=HTMLResponse)
async def technician_portal():
    """Main technician portal dashboard with fixed navigation and AI assistant"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - Technician Portal</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
            }
            
            /* Navigation */
            .navbar {
                background: rgba(0,0,0,0.3);
                backdrop-filter: blur(10px);
                border-bottom: 1px solid rgba(255,255,255,0.1);
                padding: 0;
                position: sticky;
                top: 0;
                z-index: 1000;
            }
            .navbar-brand {
                color: white;
                font-size: 1.5rem;
                font-weight: bold;
                text-decoration: none;
                padding: 1rem;
                display: inline-block;
            }
            .navbar-nav {
                list-style: none;
                display: flex;
                margin: 0;
                padding: 0;
                flex-wrap: wrap;
            }
            .nav-item {
                position: relative;
            }
            .nav-link {
                color: rgba(255,255,255,0.8);
                text-decoration: none;
                padding: 1rem 1.5rem;
                display: block;
                transition: all 0.3s ease;
                border-bottom: 2px solid transparent;
            }
            .nav-link:hover {
                color: white;
                background: rgba(255,255,255,0.1);
                border-bottom-color: #38ef7d;
            }
            .nav-link.active {
                color: white;
                background: rgba(255,255,255,0.15);
                border-bottom-color: #38ef7d;
            }
            
            .header { 
                background: rgba(0,0,0,0.3); 
                backdrop-filter: blur(15px);
                padding: 2rem;
                text-align: center;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                margin-bottom: 2rem;
            }
            .header h1 { 
                font-size: 2.5rem; 
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            .header p {
                opacity: 0.9;
                font-size: 1.1rem;
            }
            
            .container { 
                max-width: 1200px; 
                margin: 0 auto; 
                padding: 2rem;
            }
            .grid { 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
                gap: 2rem; 
                margin-bottom: 2rem;
            }
            .card { 
                background: rgba(255,255,255,0.15); 
                border-radius: 15px; 
                padding: 2rem; 
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .card:hover { 
                transform: translateY(-5px); 
                background: rgba(255,255,255,0.2);
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            }
            .btn { 
                background: linear-gradient(135deg, #38ef7d, #11998e); 
                color: white; 
                border: none; 
                padding: 0.75rem 1.5rem; 
                border-radius: 8px; 
                cursor: pointer; 
                font-size: 1rem;
                font-weight: 500;
                transition: all 0.3s ease;
                text-decoration: none;
                display: inline-block;
                margin: 0.5rem 0.25rem;
                text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
                box-shadow: 0 4px 15px rgba(56,239,125,0.3);
            }
            .btn:hover { 
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(56,239,125,0.4);
            }
            .btn-success { background: linear-gradient(135deg, #38ef7d, #11998e); }
            .btn-warning { 
                background: linear-gradient(135deg, #fbbf24, #f59e0b);
                box-shadow: 0 4px 15px rgba(251,191,36,0.3);
            }
            .btn-warning:hover {
                box-shadow: 0 6px 20px rgba(251,191,36,0.4);
            }
            
            @media (max-width: 768px) {
                .header {
                    padding: 1.5rem;
                }
                .header h1 {
                    font-size: 2rem;
                }
                .grid {
                    grid-template-columns: 1fr;
                    gap: 1rem;
                }
                .card {
                    padding: 1.5rem;
                }
            }
        </style>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar">
            <a href="/cmms/" class="navbar-brand">⚡ ChatterFix CMMS</a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="/cmms/dashboard/main" class="nav-link">📊 Dashboard</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/workorders/dashboard" class="nav-link">📋 Work Orders</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/assets/dashboard" class="nav-link">⚙️ Assets</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/parts/dashboard" class="nav-link">📦 Parts</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/preventive/dashboard" class="nav-link">🔄 Preventive</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/technicians/portal" class="nav-link active">👷 Technicians</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/ai-enhanced/dashboard/universal" class="nav-link">🤖 AI Assistant</a>
                </li>
                <li class="nav-item">
                    <a href="/cmms/admin/dashboard" class="nav-link">⚖️ Admin</a>
                </li>
            </ul>
        </nav>
        
        <div class="header">
            <h1>👷 Technician Portal</h1>
            <p>Mobile-optimized task management and field operations</p>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card" onclick="window.location.href='/cmms/workorders/dashboard'">
                    <h3>📋 My Work Orders</h3>
                    <p>View assigned tasks and update status</p>
                    <button class="btn">View Tasks</button>
                </div>
                
                <div class="card" onclick="window.location.href='/cmms/technicians/schedule'">
                    <h3>📅 Schedule</h3>
                    <p>Today's assignments and calendar</p>
                    <button class="btn">View Schedule</button>
                </div>
                
                <div class="card" onclick="window.location.href='/cmms/assets/dashboard'">
                    <h3>⚙️ Equipment</h3>
                    <p>Asset information and history</p>
                    <button class="btn">Browse Assets</button>
                </div>
                
                <div class="card" onclick="window.location.href='/cmms/parts/dashboard'">
                    <h3>📦 Parts Lookup</h3>
                    <p>Find spare parts and inventory</p>
                    <button class="btn">Search Parts</button>
                </div>
                
                <div class="card" onclick="window.location.href='/cmms/ai-enhanced/dashboard/universal'">
                    <h3>🤖 AI Assistant</h3>
                    <p>Get help with troubleshooting and repairs</p>
                    <button class="btn">Ask AI</button>
                </div>
                
                <div class="card" onclick="window.location.href='/cmms/technicians/reports/productivity'">
                    <h3>📊 My Reports</h3>
                    <p>Productivity and performance metrics</p>
                    <button class="btn">View Reports</button>
                </div>
            </div>
            
            <div class="card">
                <h3>🔧 Quick Actions</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
                    <button class="btn" onclick="createWorkOrder()">🆕 Create Work Order</button>
                    <button class="btn" onclick="scanBarcode()">📷 Scan Barcode</button>
                    <button class="btn" onclick="logTime()">⏱️ Log Time</button>
                    <button class="btn" onclick="requestParts()">📦 Request Parts</button>
                    <button class="btn" onclick="uploadPhoto()">📸 Upload Photo</button>
                    <button class="btn" onclick="voiceCommand()">🎤 Voice Command</button>
                </div>
            </div>
            
            <div class="card">
                <h3>📱 Mobile Tools</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
                    <button class="btn btn-success" onclick="openCamera()">📸 Take Photo</button>
                    <button class="btn btn-success" onclick="recordVoice()">🎤 Voice Note</button>
                    <button class="btn btn-success" onclick="useFlashlight()">🔦 Flashlight</button>
                    <button class="btn btn-success" onclick="measureTool()">📏 Measure</button>
                    <button class="btn btn-success" onclick="ocrScan()">📄 OCR Scan</button>
                    <button class="btn btn-success" onclick="manualLookup()">📚 View Manuals</button>
                </div>
            </div>
        </div>
        
        <script>
            // AI Assistant Integration
            window.addEventListener('DOMContentLoaded', function() {
                injectChatterFixAI();
            });
            
            function injectChatterFixAI() {
                if (window.chatterFixAIInjected) return;
                window.chatterFixAIInjected = true;
                
                // Create AI button
                const aiBtn = document.createElement('div');
                aiBtn.id = 'cfAIBtn';
                aiBtn.innerHTML = '🤖';
                aiBtn.style.cssText = `
                    position: fixed; bottom: 30px; right: 30px;
                    width: 65px; height: 65px; border-radius: 50%;
                    background: linear-gradient(135deg, #38ef7d, #11998e);
                    display: flex; align-items: center; justify-content: center;
                    cursor: pointer; z-index: 10000; font-size: 32px;
                    box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                    border: 3px solid rgba(255,255,255,0.3);
                    transition: all 0.3s ease;
                    animation: pulse-glow 3s infinite;
                `;
                
                // Add pulsing animation
                const style = document.createElement('style');
                style.textContent = `
                    @keyframes pulse-glow {
                        0%, 100% { 
                            transform: scale(1); 
                            box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                        }
                        50% { 
                            transform: scale(1.05); 
                            box-shadow: 0 8px 30px rgba(56,239,125,0.8);
                        }
                    }
                    #cfAIBtn:hover {
                        transform: scale(1.1) !important;
                        box-shadow: 0 8px 35px rgba(56,239,125,0.9) !important;
                    }
                `;
                document.head.appendChild(style);
                
                // Create AI panel
                const aiPanel = document.createElement('iframe');
                aiPanel.id = 'cfAIPanel';
                aiPanel.src = '/cmms/ai-enhanced/dashboard/universal';
                aiPanel.style.cssText = `
                    position: fixed; bottom: 100px; right: 30px;
                    width: 400px; height: 600px; max-width: 90vw; max-height: 70vh;
                    border: none; border-radius: 20px; display: none; z-index: 9999;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
                `;
                
                document.body.appendChild(aiBtn);
                document.body.appendChild(aiPanel);
                
                // Toggle panel
                aiBtn.onclick = () => {
                    const visible = aiPanel.style.display === 'block';
                    aiPanel.style.display = visible ? 'none' : 'block';
                    aiBtn.style.transform = visible ? 'scale(1)' : 'scale(0.9)';
                };
                
                aiBtn.onmouseover = () => aiBtn.style.transform = 'scale(1.1)';
                aiBtn.onmouseout = () => {
                    if (aiPanel.style.display !== 'block') {
                        aiBtn.style.transform = 'scale(1)';
                    }
                };
                
                console.log('✅ ChatterFix AI Assistant loaded');
            }
            
            function createWorkOrder() { 
                alert('✅ Work Order creation with voice input and photo capture available');
            }
            function scanBarcode() { 
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    alert('📷 Barcode scanner ready - QR/Barcode scanning for assets and parts');
                } else {
                    alert('Camera not available on this device');
                }
            }
            function logTime() { 
                alert('⏱️ Time logging - Track work hours and task completion');
            }
            function requestParts() { 
                window.location.href = '/cmms/parts/request';
            }
            function uploadPhoto() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.capture = 'environment';
                input.onchange = function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        alert(`📸 Photo captured: ${file.name} - Ready for upload`);
                    }
                };
                input.click();
            }
            function voiceCommand() {
                if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
                    alert('🎤 Voice recognition activated - Say "Create work order", "Log time", or ask questions');
                } else {
                    alert('Voice recognition not supported on this browser');
                }
            }
            function openCamera() {
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    alert('📸 Camera ready for photo capture and documentation');
                } else {
                    alert('Camera not available');
                }
            }
            function recordVoice() {
                alert('🎤 Voice recording for work notes and documentation');
            }
            function useFlashlight() {
                alert('🔦 Flashlight functionality for equipment inspection');
            }
            function measureTool() {
                alert('📏 AR measurement tool for equipment dimensions');
            }
            function ocrScan() {
                alert('📄 OCR scanning for equipment identification and part numbers');
            }
            function manualLookup() {
                window.location.href = '/cmms/assets/manuals';
            }
        </script>
    </body>
    </html>
    """

# Add remaining endpoints...
@technician_router.get("/")
async def get_technicians() -> List[Dict]:
    """Get all technicians"""
    return technicians_db

@technician_router.get("/{technician_id}")
async def get_technician_details(technician_id: str) -> Dict:
    """Get specific technician details"""
    technician = next((t for t in technicians_db if t['id'] == technician_id), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    return technician