#!/usr/bin/env python3
"""
Script to add admin router to app.py on the VM
"""

def patch_app_py():
    """Add admin router to app.py"""
    
    # Read the current app.py
    with open('app.py', 'r') as f:
        content = f.read()
    
    # Find the insertion point (after API Key Management routes)
    insertion_point = 'except ImportError as e:\n    logger.warning(f"API Key Management routes not available: {e}")'
    
    if insertion_point in content:
        # Create the admin router addition
        admin_router_code = '''

# Add Admin Dashboard routes
try:
    from admin import admin_router
    app.include_router(admin_router, prefix="/cmms", tags=["admin"])
    logger.info("✅ Admin Dashboard routes loaded")
except ImportError as e:
    logger.warning(f"Admin Dashboard routes not available: {e}")'''
        
        # Insert the admin router code
        content = content.replace(insertion_point, insertion_point + admin_router_code)
        
        # Write the updated content
        with open('app.py', 'w') as f:
            f.write(content)
        
        print("✅ Admin router successfully added to app.py")
        return True
    else:
        print("❌ Could not find insertion point in app.py")
        return False

if __name__ == "__main__":
    patch_app_py()