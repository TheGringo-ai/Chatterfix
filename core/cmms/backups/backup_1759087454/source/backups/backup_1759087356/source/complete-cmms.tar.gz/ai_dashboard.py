#!/usr/bin/env python3
"""
ChatterFix AI-Powered Real-Time Dashboard
Advanced analytics, health scoring, and predictive insights visualization
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# AI dashboard router
ai_dashboard_router = APIRouter(prefix="/ai/dashboard", tags=["ai-dashboard"])

class DashboardMetrics(BaseModel):
    total_assets: int
    average_health_score: float
    assets_at_risk: int
    critical_alerts: int
    maintenance_backlog: int
    completion_rate: float
    cost_savings: float
    efficiency_improvement: float

class AssetHealthWidget(BaseModel):
    asset_id: str
    asset_name: str
    health_score: float
    risk_level: str
    trend: str  # improving, stable, declining
    last_maintenance: str
    next_maintenance_due: str
    alerts_count: int

class PredictiveAlert(BaseModel):
    alert_id: str
    asset_id: str
    asset_name: str
    alert_type: str  # failure_risk, maintenance_due, performance_degradation
    severity: str  # low, medium, high, critical
    probability: float
    estimated_impact: str
    recommended_action: str
    created_at: str

class AIInsight(BaseModel):
    insight_id: str
    title: str
    description: str
    category: str  # cost_optimization, efficiency, reliability, safety
    impact_score: float
    confidence: float
    data_sources: List[str]
    recommended_actions: List[str]
    created_at: str

class ConnectionManager:
    """Manage WebSocket connections for real-time updates"""
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")
    
    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        if not self.active_connections:
            return
            
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.warning(f"Failed to send message to WebSocket: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)

class AIDashboard:
    def __init__(self):
        self.connection_manager = ConnectionManager()
        self.dashboard_data = {}
        self.health_scores = {}
        self.alerts = []
        self.insights = []
        
        # Start background tasks
        asyncio.create_task(self.initialize_dashboard_data())
        asyncio.create_task(self.update_dashboard_periodically())
    
    async def initialize_dashboard_data(self):
        """Initialize dashboard with sample data"""
        try:
            logger.info("🚀 Initializing AI dashboard data...")
            
            # Initialize asset health data
            self.health_scores = {
                "AST-001": {
                    "asset_id": "AST-001",
                    "asset_name": "Centrifugal Pump #1",
                    "health_score": 0.78,
                    "risk_level": "medium",
                    "trend": "stable",
                    "last_maintenance": "2025-01-15",
                    "next_maintenance_due": "2025-02-15",
                    "alerts_count": 1
                },
                "AST-002": {
                    "asset_id": "AST-002",
                    "asset_name": "Emergency Generator",
                    "health_score": 0.92,
                    "risk_level": "low",
                    "trend": "improving",
                    "last_maintenance": "2025-01-20",
                    "next_maintenance_due": "2025-03-20",
                    "alerts_count": 0
                },
                "AST-003": {
                    "asset_id": "AST-003",
                    "asset_name": "HVAC Unit - Main",
                    "health_score": 0.45,
                    "risk_level": "high",
                    "trend": "declining",
                    "last_maintenance": "2024-12-01",
                    "next_maintenance_due": "2025-01-10",
                    "alerts_count": 3
                },
                "AST-004": {
                    "asset_id": "AST-004",
                    "asset_name": "Conveyor Belt Line 1",
                    "health_score": 0.67,
                    "risk_level": "medium",
                    "trend": "stable",
                    "last_maintenance": "2025-01-10",
                    "next_maintenance_due": "2025-02-10",
                    "alerts_count": 2
                },
                "AST-005": {
                    "asset_id": "AST-005",
                    "asset_name": "Air Compressor #2",
                    "health_score": 0.23,
                    "risk_level": "critical",
                    "trend": "declining",
                    "last_maintenance": "2024-11-15",
                    "next_maintenance_due": "2025-01-08",
                    "alerts_count": 5
                }
            }
            
            # Initialize alerts
            self.alerts = [
                PredictiveAlert(
                    alert_id="ALT-001",
                    asset_id="AST-005",
                    asset_name="Air Compressor #2",
                    alert_type="failure_risk",
                    severity="critical",
                    probability=0.85,
                    estimated_impact="Production downtime, $15,000 repair cost",
                    recommended_action="Schedule immediate inspection and replacement of worn components",
                    created_at=datetime.now().isoformat()
                ),
                PredictiveAlert(
                    alert_id="ALT-002",
                    asset_id="AST-003",
                    asset_name="HVAC Unit - Main",
                    alert_type="maintenance_due",
                    severity="high",
                    probability=0.95,
                    estimated_impact="Reduced cooling efficiency, higher energy costs",
                    recommended_action="Replace air filters and clean condenser coils within 3 days",
                    created_at=(datetime.now() - timedelta(hours=2)).isoformat()
                ),
                PredictiveAlert(
                    alert_id="ALT-003",
                    asset_id="AST-001",
                    asset_name="Centrifugal Pump #1",
                    alert_type="performance_degradation",
                    severity="medium",
                    probability=0.72,
                    estimated_impact="10% reduction in pump efficiency",
                    recommended_action="Check impeller wear and seal condition",
                    created_at=(datetime.now() - timedelta(hours=6)).isoformat()
                )
            ]
            
            # Initialize AI insights
            self.insights = [
                AIInsight(
                    insight_id="INS-001",
                    title="Preventive Maintenance Cost Optimization",
                    description="Analysis shows 23% cost reduction possible by optimizing PM schedules based on actual usage patterns rather than fixed intervals.",
                    category="cost_optimization",
                    impact_score=0.87,
                    confidence=0.82,
                    data_sources=["maintenance_history", "usage_patterns", "cost_analysis"],
                    recommended_actions=[
                        "Implement usage-based maintenance scheduling",
                        "Review current PM intervals for low-usage assets",
                        "Pilot dynamic scheduling for 5 high-cost assets"
                    ],
                    created_at=(datetime.now() - timedelta(days=1)).isoformat()
                ),
                AIInsight(
                    insight_id="INS-002",
                    title="Asset Reliability Pattern Identified",
                    description="HVAC systems show 40% higher failure rate during summer months. Proactive maintenance in spring can reduce emergency repairs by 60%.",
                    category="reliability",
                    impact_score=0.75,
                    confidence=0.88,
                    data_sources=["seasonal_analysis", "failure_data", "weather_correlation"],
                    recommended_actions=[
                        "Schedule comprehensive HVAC maintenance in April-May",
                        "Increase monitoring frequency during peak summer",
                        "Stock critical HVAC parts before summer season"
                    ],
                    created_at=(datetime.now() - timedelta(days=2)).isoformat()
                ),
                AIInsight(
                    insight_id="INS-003",
                    title="Technician Skill Optimization Opportunity",
                    description="Matching technician skills to work orders more effectively could reduce average completion time by 18% and improve first-time fix rate to 94%.",
                    category="efficiency",
                    impact_score=0.68,
                    confidence=0.79,
                    data_sources=["technician_performance", "skill_matching", "completion_metrics"],
                    recommended_actions=[
                        "Implement AI-powered technician assignment",
                        "Provide cross-training for high-demand skills",
                        "Create skill-based work order routing"
                    ],
                    created_at=(datetime.now() - timedelta(days=3)).isoformat()
                )
            ]
            
            logger.info("✅ AI dashboard data initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize dashboard data: {e}")
    
    async def get_dashboard_metrics(self) -> DashboardMetrics:
        """Calculate current dashboard metrics"""
        try:
            total_assets = len(self.health_scores)
            avg_health = sum(asset["health_score"] for asset in self.health_scores.values()) / total_assets if total_assets > 0 else 0
            
            assets_at_risk = len([asset for asset in self.health_scores.values() 
                                if asset["risk_level"] in ["high", "critical"]])
            
            critical_alerts = len([alert for alert in self.alerts if alert.severity == "critical"])
            
            # Calculate maintenance backlog (assets with overdue maintenance)
            current_date = datetime.now().date()
            maintenance_backlog = 0
            for asset in self.health_scores.values():
                try:
                    due_date = datetime.fromisoformat(asset["next_maintenance_due"]).date()
                    if due_date < current_date:
                        maintenance_backlog += 1
                except:
                    pass
            
            return DashboardMetrics(
                total_assets=total_assets,
                average_health_score=round(avg_health, 2),
                assets_at_risk=assets_at_risk,
                critical_alerts=critical_alerts,
                maintenance_backlog=maintenance_backlog,
                completion_rate=0.89,  # Mock data
                cost_savings=47500.0,  # Mock data - annual savings from AI optimization
                efficiency_improvement=0.23  # Mock data - 23% improvement
            )
            
        except Exception as e:
            logger.error(f"❌ Failed to calculate dashboard metrics: {e}")
            return DashboardMetrics(
                total_assets=0,
                average_health_score=0.0,
                assets_at_risk=0,
                critical_alerts=0,
                maintenance_backlog=0,
                completion_rate=0.0,
                cost_savings=0.0,
                efficiency_improvement=0.0
            )
    
    async def get_asset_health_widgets(self) -> List[AssetHealthWidget]:
        """Get asset health widgets data"""
        widgets = []
        for asset_data in self.health_scores.values():
            widget = AssetHealthWidget(**asset_data)
            widgets.append(widget)
        
        # Sort by health score (worst first)
        widgets.sort(key=lambda x: x.health_score)
        return widgets
    
    async def get_recent_alerts(self, limit: int = 10) -> List[PredictiveAlert]:
        """Get recent predictive alerts"""
        # Sort by creation time (newest first)
        sorted_alerts = sorted(self.alerts, key=lambda x: x.created_at, reverse=True)
        return sorted_alerts[:limit]
    
    async def get_ai_insights(self, limit: int = 5) -> List[AIInsight]:
        """Get AI insights"""
        # Sort by impact score (highest first)
        sorted_insights = sorted(self.insights, key=lambda x: x.impact_score, reverse=True)
        return sorted_insights[:limit]
    
    async def update_dashboard_periodically(self):
        """Update dashboard data periodically and broadcast to clients"""
        while True:
            try:
                await asyncio.sleep(30)  # Update every 30 seconds
                
                # Simulate real-time updates
                await self.simulate_data_updates()
                
                # Get updated dashboard data
                metrics = await self.get_dashboard_metrics()
                
                # Broadcast update to connected clients
                update_message = {
                    "type": "dashboard_update",
                    "timestamp": datetime.now().isoformat(),
                    "metrics": metrics.dict(),
                    "health_scores_updated": len(self.health_scores),
                    "alerts_count": len(self.alerts)
                }
                
                await self.connection_manager.broadcast(update_message)
                
            except Exception as e:
                logger.error(f"❌ Dashboard update failed: {e}")
                await asyncio.sleep(60)  # Wait longer on error
    
    async def simulate_data_updates(self):
        """Simulate real-time data updates for demonstration"""
        try:
            import random
            
            # Randomly update health scores slightly
            for asset_id, asset_data in self.health_scores.items():
                # Small random change in health score
                change = random.uniform(-0.02, 0.01)  # Slight bias towards degradation
                new_score = max(0.0, min(1.0, asset_data["health_score"] + change))
                asset_data["health_score"] = round(new_score, 3)
                
                # Update risk level based on health score
                if new_score >= 0.8:
                    risk_level = "low"
                elif new_score >= 0.6:
                    risk_level = "medium"
                elif new_score >= 0.3:
                    risk_level = "high"
                else:
                    risk_level = "critical"
                
                asset_data["risk_level"] = risk_level
                
                # Update trend
                if change > 0.005:
                    trend = "improving"
                elif change < -0.005:
                    trend = "declining"
                else:
                    trend = "stable"
                
                asset_data["trend"] = trend
            
            # Occasionally add new alerts
            if random.random() < 0.1:  # 10% chance
                await self.generate_new_alert()
            
        except Exception as e:
            logger.error(f"❌ Data simulation failed: {e}")
    
    async def generate_new_alert(self):
        """Generate a new predictive alert"""
        try:
            import random
            
            # Select random asset
            asset_ids = list(self.health_scores.keys())
            asset_id = random.choice(asset_ids)
            asset_data = self.health_scores[asset_id]
            
            alert_types = ["failure_risk", "maintenance_due", "performance_degradation"]
            severities = ["low", "medium", "high", "critical"]
            
            # Higher chance of severe alerts for assets with low health scores
            if asset_data["health_score"] < 0.3:
                severity_weights = [0.1, 0.2, 0.3, 0.4]
            elif asset_data["health_score"] < 0.6:
                severity_weights = [0.2, 0.4, 0.3, 0.1]
            else:
                severity_weights = [0.4, 0.4, 0.15, 0.05]
            
            alert_type = random.choice(alert_types)
            severity = random.choices(severities, weights=severity_weights)[0]
            probability = random.uniform(0.6, 0.95)
            
            new_alert = PredictiveAlert(
                alert_id=f"ALT-{len(self.alerts) + 1:03d}",
                asset_id=asset_id,
                asset_name=asset_data["asset_name"],
                alert_type=alert_type,
                severity=severity,
                probability=probability,
                estimated_impact="System performance degradation detected",
                recommended_action=f"Inspect {asset_data['asset_name']} for potential issues",
                created_at=datetime.now().isoformat()
            )
            
            self.alerts.append(new_alert)
            
            # Broadcast new alert
            alert_message = {
                "type": "new_alert",
                "alert": new_alert.dict(),
                "timestamp": datetime.now().isoformat()
            }
            
            await self.connection_manager.broadcast(alert_message)
            
            logger.info(f"🚨 Generated new {severity} alert for {asset_data['asset_name']}")
            
        except Exception as e:
            logger.error(f"❌ Failed to generate new alert: {e}")

# Initialize global dashboard
ai_dashboard = AIDashboard()

@ai_dashboard_router.get("/main", response_class=HTMLResponse)
async def ai_dashboard_main():
    """Main AI dashboard interface"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix AI Dashboard</title>
        <link rel="stylesheet" href="/static/css/mobile.css">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            .dashboard-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: var(--spacing-lg);
                margin-bottom: var(--spacing-xl);
            }
            
            .metric-card {
                background: var(--surface);
                border-radius: var(--radius-lg);
                padding: var(--spacing-lg);
                box-shadow: var(--shadow-sm);
                text-align: center;
            }
            
            .metric-value {
                font-size: var(--font-3xl);
                font-weight: 700;
                margin-bottom: var(--spacing-sm);
            }
            
            .metric-label {
                color: var(--text-secondary);
                font-size: var(--font-sm);
            }
            
            .health-widget {
                background: var(--surface);
                border-radius: var(--radius-lg);
                padding: var(--spacing-md);
                margin-bottom: var(--spacing-md);
                border-left: 4px solid var(--primary);
            }
            
            .health-score {
                font-size: var(--font-xl);
                font-weight: 600;
            }
            
            .risk-critical { border-left-color: var(--danger); }
            .risk-high { border-left-color: var(--warning); }
            .risk-medium { border-left-color: var(--info); }
            .risk-low { border-left-color: var(--success); }
            
            .alert-item {
                background: var(--surface);
                border-radius: var(--radius-md);
                padding: var(--spacing-md);
                margin-bottom: var(--spacing-sm);
                border-left: 4px solid var(--warning);
            }
            
            .alert-critical { border-left-color: var(--danger); }
            .alert-high { border-left-color: var(--warning); }
            .alert-medium { border-left-color: var(--info); }
            .alert-low { border-left-color: var(--success); }
            
            .insight-card {
                background: linear-gradient(135deg, var(--primary), var(--secondary));
                color: white;
                border-radius: var(--radius-lg);
                padding: var(--spacing-lg);
                margin-bottom: var(--spacing-md);
            }
            
            .chart-container {
                position: relative;
                height: 300px;
                margin: var(--spacing-md) 0;
            }
            
            .realtime-indicator {
                display: inline-flex;
                align-items: center;
                gap: var(--spacing-sm);
                color: var(--success);
                font-size: var(--font-sm);
            }
            
            .status-dot {
                width: 8px;
                height: 8px;
                border-radius: 50%;
                background: var(--success);
                animation: pulse 2s infinite;
            }
            
            @keyframes pulse {
                0% { opacity: 1; }
                50% { opacity: 0.5; }
                100% { opacity: 1; }
            }
        </style>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar">
            <div class="container d-flex justify-between align-center">
                <a href="/" class="navbar-brand">ChatterFix AI</a>
                <div class="realtime-indicator">
                    <div class="status-dot"></div>
                    <span>Real-time Updates</span>
                </div>
            </div>
        </nav>
        
        <!-- Main Dashboard -->
        <div class="container">
            <div class="d-flex justify-between align-center mb-lg">
                <h1>🤖 AI-Powered Dashboard</h1>
                <div class="d-flex gap-sm">
                    <button class="btn btn-primary" onclick="refreshDashboard()">🔄 Refresh</button>
                    <button class="btn btn-secondary" onclick="exportData()">📊 Export</button>
                </div>
            </div>
            
            <!-- Key Metrics -->
            <div class="dashboard-grid" id="metricsGrid">
                <!-- Metrics will be loaded here -->
            </div>
            
            <!-- Main Content Grid -->
            <div class="row">
                <div class="col-md-8">
                    <!-- Asset Health Overview -->
                    <div class="card">
                        <div class="card-header">
                            <h3>🏥 Asset Health Monitor</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="healthChart"></canvas>
                            </div>
                            <div id="assetHealthList">
                                <!-- Asset health widgets will be loaded here -->
                            </div>
                        </div>
                    </div>
                    
                    <!-- Predictive Alerts -->
                    <div class="card mt-lg">
                        <div class="card-header">
                            <h3>🚨 Predictive Alerts</h3>
                            <span class="badge" id="alertsCount">0</span>
                        </div>
                        <div class="card-body">
                            <div id="alertsList">
                                <!-- Alerts will be loaded here -->
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <!-- AI Insights -->
                    <div class="card">
                        <div class="card-header">
                            <h3>💡 AI Insights</h3>
                        </div>
                        <div class="card-body">
                            <div id="insightsList">
                                <!-- AI insights will be loaded here -->
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="card mt-lg">
                        <div class="card-header">
                            <h3>⚡ Quick Actions</h3>
                        </div>
                        <div class="card-body">
                            <div class="d-flex flex-column gap-sm">
                                <button class="btn btn-primary" onclick="createWorkOrder()">
                                    ➕ Create Work Order
                                </button>
                                <button class="btn btn-secondary" onclick="scheduleMainenance()">
                                    📅 Schedule Maintenance
                                </button>
                                <button class="btn btn-secondary" onclick="generateReport()">
                                    📈 Generate Report
                                </button>
                                <button class="btn btn-secondary" onclick="openAIChat()">
                                    💬 Ask AI Assistant
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- WebSocket Status -->
        <div id="wsStatus" style="position: fixed; bottom: 10px; right: 10px; padding: 8px; border-radius: 4px; font-size: 12px; display: none;">
        </div>
        
        <script>
            // Global variables
            let websocket = null;
            let healthChart = null;
            let dashboardData = {};
            
            // Initialize dashboard
            document.addEventListener('DOMContentLoaded', function() {
                initializeDashboard();
                setupWebSocket();
            });
            
            async function initializeDashboard() {
                try {
                    await loadDashboardData();
                    renderMetrics();
                    renderAssetHealth();
                    renderAlerts();
                    renderInsights();
                    createHealthChart();
                } catch (error) {
                    console.error('Dashboard initialization failed:', error);
                }
            }
            
            async function loadDashboardData() {
                try {
                    const [metricsResponse, assetsResponse, alertsResponse, insightsResponse] = await Promise.all([
                        fetch('/ai/dashboard/api/metrics'),
                        fetch('/ai/dashboard/api/assets'),
                        fetch('/ai/dashboard/api/alerts'),
                        fetch('/ai/dashboard/api/insights')
                    ]);
                    
                    dashboardData = {
                        metrics: await metricsResponse.json(),
                        assets: await assetsResponse.json(),
                        alerts: await alertsResponse.json(),
                        insights: await insightsResponse.json()
                    };
                    
                } catch (error) {
                    console.error('Failed to load dashboard data:', error);
                }
            }
            
            function renderMetrics() {
                const metrics = dashboardData.metrics;
                const grid = document.getElementById('metricsGrid');
                
                grid.innerHTML = `
                    <div class="metric-card">
                        <div class="metric-value" style="color: var(--primary);">${metrics.total_assets}</div>
                        <div class="metric-label">Total Assets</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" style="color: var(--success);">${(metrics.average_health_score * 100).toFixed(1)}%</div>
                        <div class="metric-label">Avg Health Score</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" style="color: var(--warning);">${metrics.assets_at_risk}</div>
                        <div class="metric-label">Assets at Risk</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" style="color: var(--danger);">${metrics.critical_alerts}</div>
                        <div class="metric-label">Critical Alerts</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" style="color: var(--info);">${metrics.maintenance_backlog}</div>
                        <div class="metric-label">Maintenance Backlog</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-value" style="color: var(--success);">$${metrics.cost_savings.toLocaleString()}</div>
                        <div class="metric-label">Annual Cost Savings</div>
                    </div>
                `;
            }
            
            function renderAssetHealth() {
                const assets = dashboardData.assets;
                const container = document.getElementById('assetHealthList');
                
                const assetsHtml = assets.map(asset => `
                    <div class="health-widget risk-${asset.risk_level}">
                        <div class="d-flex justify-between align-center mb-sm">
                            <h4>${asset.asset_name}</h4>
                            <div class="health-score" style="color: ${getHealthColor(asset.health_score)}">
                                ${(asset.health_score * 100).toFixed(1)}%
                            </div>
                        </div>
                        <div class="d-flex justify-between text-sm text-secondary">
                            <span>Risk: ${asset.risk_level.toUpperCase()}</span>
                            <span>Trend: ${getTrendIcon(asset.trend)} ${asset.trend}</span>
                            <span>Alerts: ${asset.alerts_count}</span>
                        </div>
                        <div class="text-sm text-secondary mt-sm">
                            Next maintenance: ${formatDate(asset.next_maintenance_due)}
                        </div>
                    </div>
                `).join('');
                
                container.innerHTML = assetsHtml;
            }
            
            function renderAlerts() {
                const alerts = dashboardData.alerts;
                const container = document.getElementById('alertsList');
                const countBadge = document.getElementById('alertsCount');
                
                countBadge.textContent = alerts.length;
                
                const alertsHtml = alerts.map(alert => `
                    <div class="alert-item alert-${alert.severity}">
                        <div class="d-flex justify-between align-center mb-sm">
                            <h5>${alert.asset_name}</h5>
                            <span class="badge priority-badge ${alert.severity}">${alert.severity}</span>
                        </div>
                        <div class="mb-sm">
                            <strong>${alert.alert_type.replace('_', ' ').toUpperCase()}</strong>
                            <span class="text-sm text-secondary">(${(alert.probability * 100).toFixed(1)}% probability)</span>
                        </div>
                        <p class="text-sm mb-sm">${alert.estimated_impact}</p>
                        <p class="text-sm"><strong>Action:</strong> ${alert.recommended_action}</p>
                        <div class="text-xs text-secondary mt-sm">
                            ${formatDateTime(alert.created_at)}
                        </div>
                    </div>
                `).join('');
                
                container.innerHTML = alertsHtml || '<p class="text-center text-secondary">No active alerts</p>';
            }
            
            function renderInsights() {
                const insights = dashboardData.insights;
                const container = document.getElementById('insightsList');
                
                const insightsHtml = insights.map(insight => `
                    <div class="insight-card">
                        <h4>${insight.title}</h4>
                        <p class="mb-sm">${insight.description}</p>
                        <div class="d-flex justify-between text-sm mb-sm">
                            <span>Impact: ${(insight.impact_score * 100).toFixed(1)}%</span>
                            <span>Confidence: ${(insight.confidence * 100).toFixed(1)}%</span>
                        </div>
                        <div class="text-sm">
                            <strong>Actions:</strong>
                            <ul class="mt-sm" style="margin-left: 1rem;">
                                ${insight.recommended_actions.slice(0, 2).map(action => `<li>${action}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                `).join('');
                
                container.innerHTML = insightsHtml || '<p class="text-center text-secondary">No insights available</p>';
            }
            
            function createHealthChart() {
                const assets = dashboardData.assets;
                const ctx = document.getElementById('healthChart').getContext('2d');
                
                healthChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Critical', 'High Risk', 'Medium Risk', 'Low Risk'],
                        datasets: [{
                            data: [
                                assets.filter(a => a.risk_level === 'critical').length,
                                assets.filter(a => a.risk_level === 'high').length,
                                assets.filter(a => a.risk_level === 'medium').length,
                                assets.filter(a => a.risk_level === 'low').length
                            ],
                            backgroundColor: ['#e74c3c', '#f39c12', '#3498db', '#27ae60'],
                            borderWidth: 2,
                            borderColor: '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            }
            
            // WebSocket connection for real-time updates
            function setupWebSocket() {
                const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
                const wsUrl = `${protocol}//${window.location.host}/ai/dashboard/ws`;
                
                websocket = new WebSocket(wsUrl);
                
                websocket.onopen = function() {
                    console.log('WebSocket connected');
                    showWSStatus('Connected', 'success');
                };
                
                websocket.onmessage = function(event) {
                    const data = JSON.parse(event.data);
                    handleWebSocketMessage(data);
                };
                
                websocket.onclose = function() {
                    console.log('WebSocket disconnected');
                    showWSStatus('Disconnected', 'error');
                    // Attempt to reconnect after 5 seconds
                    setTimeout(setupWebSocket, 5000);
                };
                
                websocket.onerror = function(error) {
                    console.error('WebSocket error:', error);
                    showWSStatus('Error', 'error');
                };
            }
            
            function handleWebSocketMessage(data) {
                if (data.type === 'dashboard_update') {
                    // Update metrics without full page reload
                    dashboardData.metrics = data.metrics;
                    renderMetrics();
                } else if (data.type === 'new_alert') {
                    // Add new alert to the list
                    dashboardData.alerts.unshift(data.alert);
                    renderAlerts();
                    
                    // Show notification
                    showNotification(`New ${data.alert.severity} alert for ${data.alert.asset_name}`, 'warning');
                }
            }
            
            // Utility functions
            function getHealthColor(score) {
                if (score >= 0.8) return 'var(--success)';
                if (score >= 0.6) return 'var(--info)';
                if (score >= 0.3) return 'var(--warning)';
                return 'var(--danger)';
            }
            
            function getTrendIcon(trend) {
                if (trend === 'improving') return '📈';
                if (trend === 'declining') return '📉';
                return '➡️';
            }
            
            function formatDate(dateStr) {
                return new Date(dateStr).toLocaleDateString();
            }
            
            function formatDateTime(dateStr) {
                return new Date(dateStr).toLocaleString();
            }
            
            function showWSStatus(message, type) {
                const status = document.getElementById('wsStatus');
                status.textContent = `WebSocket: ${message}`;
                status.className = type === 'success' ? 'bg-success text-white' : 'bg-danger text-white';
                status.style.display = 'block';
                
                if (type === 'success') {
                    setTimeout(() => {
                        status.style.display = 'none';
                    }, 3000);
                }
            }
            
            function showNotification(message, type) {
                const notification = document.createElement('div');
                notification.className = `toast toast-${type} show`;
                notification.innerHTML = `
                    <div class="toast-content">
                        <strong>${message}</strong>
                    </div>
                    <button class="toast-close" onclick="this.parentElement.remove()">×</button>
                `;
                
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    if (notification.parentElement) {
                        notification.remove();
                    }
                }, 5000);
            }
            
            // Action handlers
            async function refreshDashboard() {
                await loadDashboardData();
                renderMetrics();
                renderAssetHealth();
                renderAlerts();
                renderInsights();
                
                if (healthChart) {
                    healthChart.destroy();
                    createHealthChart();
                }
                
                showNotification('Dashboard refreshed', 'success');
            }
            
            function createWorkOrder() {
                window.location.href = '/cmms/workorders/mobile/new';
            }
            
            function scheduleMainenance() {
                alert('Maintenance scheduling interface would open here');
            }
            
            function generateReport() {
                alert('Report generation would start here');
            }
            
            function openAIChat() {
                window.location.href = '/cmms/ai/dashboard';
            }
            
            function exportData() {
                const data = JSON.stringify(dashboardData, null, 2);
                const blob = new Blob([data], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `chatterfix_dashboard_${new Date().toISOString().split('T')[0]}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }
        </script>
    </body>
    </html>
    """

# WebSocket endpoint for real-time updates
@ai_dashboard_router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ai_dashboard.connection_manager.connect(websocket)
    try:
        while True:
            # Keep connection alive
            await websocket.receive_text()
    except WebSocketDisconnect:
        ai_dashboard.connection_manager.disconnect(websocket)

# API endpoints for dashboard data
@ai_dashboard_router.get("/api/metrics")
async def get_dashboard_metrics():
    """Get current dashboard metrics"""
    metrics = await ai_dashboard.get_dashboard_metrics()
    return metrics

@ai_dashboard_router.get("/api/assets")
async def get_asset_health():
    """Get asset health widgets data"""
    widgets = await ai_dashboard.get_asset_health_widgets()
    return [widget.dict() for widget in widgets]

@ai_dashboard_router.get("/api/alerts")
async def get_recent_alerts(limit: int = 10):
    """Get recent predictive alerts"""
    alerts = await ai_dashboard.get_recent_alerts(limit)
    return [alert.dict() for alert in alerts]

@ai_dashboard_router.get("/api/insights")
async def get_ai_insights(limit: int = 5):
    """Get AI insights"""
    insights = await ai_dashboard.get_ai_insights(limit)
    return [insight.dict() for insight in insights]

@ai_dashboard_router.get("/api/status")
async def get_dashboard_status():
    """Get dashboard system status"""
    return JSONResponse({
        "status": "operational",
        "connected_clients": len(ai_dashboard.connection_manager.active_connections),
        "total_assets": len(ai_dashboard.health_scores),
        "active_alerts": len(ai_dashboard.alerts),
        "ai_insights": len(ai_dashboard.insights),
        "last_updated": datetime.now().isoformat()
    })