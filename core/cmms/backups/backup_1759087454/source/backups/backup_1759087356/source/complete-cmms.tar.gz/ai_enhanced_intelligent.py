 #!/usr/bin/env python3
"""
Enhanced Intelligent AI Module for ChatterFix CMMS
This file originally contained numerous placeholder / incomplete regions.
Refactored to:
 - Provide safe defaults (no hard failures on import)
 - Guard external calls (LLaMA server) with timeouts
 - Replace empty code blocks with minimal functional logic
 - Avoid mutable default arguments in dataclasses
"""

from __future__ import annotations

import re
import json
import asyncio
import aiohttp
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# LLaMA Configuration
LLAMA_SERVER = "http://localhost:11434"
LLAMA_MODEL = "llama3.2:1b"

@dataclass
class MaintenanceContext:
    """Enhanced maintenance context for better AI responses"""
    equipment_type: str = "general"
    issue_category: str = "general"
    urgency_level: str = "normal"
    user_expertise: str = "technician"
    facility_type: str = "industrial"
    maintenance_history: List[str] = field(default_factory=list)

class IntelligentMaintenanceAI:
    """Advanced AI system with maintenance expertise"""
    
    def __init__(self):
        self.equipment_database = self.load_equipment_database()
        self.troubleshooting_procedures = self.load_troubleshooting_procedures()
        self.safety_protocols = self.load_safety_protocols()
        
    def load_equipment_database(self) -> Dict[str, Any]:
        """Load comprehensive equipment knowledge base"""
        return {
            "conveyors": {
                "common_issues": ["belt_slippage", "motor_overheating", "bearing_failure", "alignment_issues", "debris_buildup"],
                "vibration_causes": ["belt_misalignment", "worn_bearings", "motor_imbalance", "loose_connections", "damaged_pulleys"],
                "maintenance_intervals": {"daily": ["visual_inspection", "lubrication_check"], "weekly": ["belt_tension", "alignment_check"], "monthly": ["bearing_inspection", "motor_analysis"]},
                "safety_considerations": ["lockout_tagout", "confined_space", "pinch_points", "rotating_machinery"]
            },
            "pumps": {
                "common_issues": ["cavitation", "seal_leakage", "impeller_wear", "motor_failure", "pipe_blockage"],
                "vibration_causes": ["impeller_imbalance", "misalignment", "cavitation", "bearing_wear", "pipe_strain"],
                "maintenance_intervals": {"daily": ["pressure_check", "temperature_monitoring"], "weekly": ["seal_inspection", "vibration_analysis"], "monthly": ["impeller_inspection", "bearing_replacement"]},
                "safety_considerations": ["pressure_systems", "chemical_exposure", "hot_surfaces", "electrical_hazards"]
            },
            "motors": {
                "common_issues": ["overheating", "bearing_failure", "winding_damage", "vibration", "electrical_faults"],
                "overheating_causes": ["overload", "poor_ventilation", "bearing_failure", "voltage_imbalance", "blocked_cooling"],
                "maintenance_intervals": {"daily": ["temperature_check", "sound_analysis"], "weekly": ["vibration_monitoring", "electrical_readings"], "monthly": ["bearing_lubrication", "winding_inspection"]},
                "safety_considerations": ["electrical_safety", "rotating_parts", "high_temperature", "arc_flash"]
            },
            "hvac": {
                "common_issues": ["refrigerant_leaks", "compressor_failure", "fan_motor_issues", "control_problems", "duct_blockage"],
                "maintenance_intervals": {"daily": ["temperature_monitoring", "system_operation"], "weekly": ["filter_check", "belt_inspection"], "monthly": ["coil_cleaning", "refrigerant_check"]},
                "safety_considerations": ["refrigerant_handling", "electrical_systems", "confined_spaces", "chemical_exposure"]
            }
        }
    
    def load_troubleshooting_procedures(self) -> Dict[str, Any]:
        """Load detailed troubleshooting procedures"""
        return {
            "conveyor_vibration": {
                "immediate_steps": [
                    "Stop equipment immediately and lockout/tagout",
                    "Check for obvious loose components",
                    "Inspect belt alignment visually",
                    "Check motor mounting bolts"
                ],
                "diagnostic_steps": [
                    "Measure vibration levels at motor and drive points",
                    "Check belt tension with tension gauge",
                    "Inspect bearings for play and noise",
                    "Verify motor electrical connections",
                    "Check coupling alignment"
                ],
                "repair_procedures": [
                    "Replace worn bearings if detected",
                    "Realign belt and adjust tension to specification",
                    "Balance motor shaft if imbalance detected",
                    "Tighten all mounting hardware to torque spec",
                    "Lubricate bearings per maintenance schedule"
                ]
            },
            "motor_overheating": {
                "immediate_steps": [
                    "Reduce load immediately",
                    "Check ventilation and cooling",
                    "Monitor temperature continuously",
                    "Check electrical supply voltage"
                ],
                "diagnostic_steps": [
                    "Measure actual operating temperature",
                    "Check current draw against nameplate",
                    "Verify proper ventilation clearances",
                    "Test bearing condition",
                    "Check for voltage imbalance"
                ],
                "repair_procedures": [
                    "Clean cooling passages and fans",
                    "Replace bearings if worn",
                    "Correct electrical supply issues",
                    "Adjust load to nameplate capacity",
                    "Improve ventilation if inadequate"
                ]
            }
        }
    
    def load_safety_protocols(self) -> Dict[str, List[str]]:
        """Load safety protocols for different equipment types"""
        return {
            "general": [
                "Always follow lockout/tagout procedures",
                "Wear appropriate PPE",
                "Verify zero energy state before work",
                "Use proper tools and equipment",
                "Follow confined space procedures if applicable"
            ],
            "electrical": [
                "Test circuits with proper meters",
                "Use arc-flash rated PPE",
                "Follow electrical safety procedures",
                "Verify de-energized state",
                "Use proper grounding techniques"
            ],
            "mechanical": [
                "Guard against rotating machinery",
                "Use proper lifting techniques",
                "Secure heavy components",
                "Check for pinch points",
                "Use fall protection if required"
            ]
        }
    
    def analyze_user_query(self, message: str) -> MaintenanceContext:
        """Analyze user query to extract context"""
        message_lower = message.lower()
        
        # Equipment type detection
        equipment_type = "general"
        for equip_type in self.equipment_database.keys():
            if equip_type.rstrip('s') in message_lower or equip_type in message_lower:
                equipment_type = equip_type
                break
        
        # Issue category detection
        issue_category = "general"
        issue_keywords = {
            "vibration": ["vibrat", "shak", "oscillat"],
            "overheating": ["hot", "overheat", "temperature", "thermal"],
            "noise": ["noise", "sound", "loud", "squeal", "grind"],
            "leakage": ["leak", "drip", "seep", "spill"],
            "electrical": ["electrical", "power", "voltage", "current", "motor"],
            "wear": ["wear", "worn", "damage", "deteriorat"]
        }
        
        for category, keywords in issue_keywords.items():
            if any(keyword in message_lower for keyword in keywords):
                issue_category = category
                break
        
        # Urgency detection
        urgency_level = "normal"
        urgent_keywords = ["emergency", "urgent", "critical", "immediate", "danger", "safety"]
        if any(keyword in message_lower for keyword in urgent_keywords):
            urgency_level = "high"
        
        return MaintenanceContext(
            equipment_type=equipment_type,
            issue_category=issue_category,
            urgency_level=urgency_level,
            user_expertise="technician",
            facility_type="industrial"
        )
    
    def get_specific_knowledge(self, context: MaintenanceContext, message: str) -> Dict[str, Any]:
        """Retrieve specific knowledge based on context"""
        knowledge = {
            "equipment_info": {},
            "procedures": {},
            "safety_info": [],
            "maintenance_schedule": {}
        }
        
        # Get equipment-specific information
        if context.equipment_type in self.equipment_database:
            equipment_data = self.equipment_database[context.equipment_type]
            knowledge["equipment_info"] = equipment_data
            
            # Get specific troubleshooting if available
            troubleshoot_key = f"{context.equipment_type}_{context.issue_category}"
            if troubleshoot_key in self.troubleshooting_procedures:
                knowledge["procedures"] = self.troubleshooting_procedures[troubleshoot_key]
        
        # Get safety protocols
        if context.equipment_type in self.safety_protocols:
            knowledge["safety_info"] = self.safety_protocols[context.equipment_type]
        else:
            knowledge["safety_info"] = self.safety_protocols["general"]
        
        return knowledge
    
    async def generate_intelligent_response(self, message: str, context_str: str = "general") -> str:
        """Generate intelligent, context-aware maintenance response"""
        try:
            # Analyze the user query
            maintenance_context = self.analyze_user_query(message)
            
            # Get specific knowledge
            knowledge = self.get_specific_knowledge(maintenance_context, message)
            
            # Create enhanced system prompt with specific knowledge
            system_prompt = self.create_enhanced_system_prompt(maintenance_context, knowledge)
            
            # Create enhanced user message with context
            enhanced_message = self.enhance_user_message(message, maintenance_context, knowledge)
            
            payload = {
                "model": LLAMA_MODEL,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": enhanced_message}
                ],
                "stream": False,
                "options": {
                    "temperature": 0.3,  # Lower for more consistent technical responses
                    "top_p": 0.85,
                    "max_tokens": 800,
                    "num_predict": 800
                }
            }
            
            timeout = aiohttp.ClientTimeout(total=25)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(f"{LLAMA_SERVER}/api/chat", json=payload) as response:
                    if response.status == 200:
                        result = await response.json()
                        if "message" in result and "content" in result["message"]:
                            ai_response = result["message"]["content"]
                            # Post-process the response for better formatting
                            return self.post_process_response(ai_response, maintenance_context)
                    
                    # Fallback to knowledge-based response if LLaMA fails
                    return self.generate_fallback_response(maintenance_context, knowledge, message)
        
        except Exception as e:
            logger.error(f"Intelligent AI error: {e}")
            # Generate knowledge-based fallback
            maintenance_context = self.analyze_user_query(message)
            knowledge = self.get_specific_knowledge(maintenance_context, message)
            return self.generate_fallback_response(maintenance_context, knowledge, message)
    
    def create_enhanced_system_prompt(self, context: MaintenanceContext, knowledge: Dict[str, Any]) -> str:
        """Create enhanced system prompt with specific knowledge"""
        prompt = f"""You are ChatterFix AI, an expert maintenance technician with 20+ years of experience in {context.facility_type} facilities.

EXPERTISE AREAS:
- {context.equipment_type.title()} systems and troubleshooting
- {context.issue_category.title()} diagnosis and repair
- Safety protocols and OSHA compliance
- Preventive maintenance scheduling
- Root cause analysis

CURRENT SITUATION:
- Equipment Type: {context.equipment_type}
- Issue Category: {context.issue_category}
- Urgency Level: {context.urgency_level}
- User Level: {context.user_expertise}

SPECIFIC KNOWLEDGE BASE:
{json.dumps(knowledge, indent=2)}

RESPONSE REQUIREMENTS:
1. Provide specific, actionable technical advice
2. Include safety considerations FIRST
3. Give step-by-step procedures when applicable
4. Reference specific tools, measurements, and specifications
5. Explain the "why" behind recommendations
6. Consider urgency level in response prioritization
7. Use proper maintenance terminology
8. Provide realistic timeframes for repairs

Always prioritize safety and give practical solutions that a {context.user_expertise} can implement."""
        
        return prompt
    
    def enhance_user_message(self, message: str, context: MaintenanceContext, knowledge: Dict[str, Any]) -> str:
        """Enhance user message with additional context"""
        enhanced = f"""MAINTENANCE REQUEST: {message}

ADDITIONAL CONTEXT:
- This involves {context.equipment_type} equipment
- Primary concern appears to be {context.issue_category}
- Urgency level: {context.urgency_level}

Please provide specific technical guidance including safety procedures, diagnostic steps, and repair recommendations."""
        
        return enhanced
    
    def post_process_response(self, response: str, context: MaintenanceContext) -> str:
        """Post-process AI response for better formatting and safety emphasis"""
        # Ensure safety information is prominent
        if "safety" not in response.lower() and context.urgency_level == "high":
            safety_note = "⚠️ SAFETY FIRST: Ensure proper lockout/tagout procedures before beginning work. "
            response = safety_note + response
        
        # Add structured formatting
        response = response.replace("1.", "\n1.")
        response = response.replace("2.", "\n2.")
        response = response.replace("3.", "\n3.")
        response = response.replace("•", "\n•")
        
        return response.strip()
    
    def generate_fallback_response(self, context: MaintenanceContext, knowledge: Dict[str, Any], message: str) -> str:
        """Generate knowledge-based fallback response when AI fails"""
        response_parts = []
        
        # Safety first
        response_parts.append("⚠️ SAFETY PROTOCOL:")
        if knowledge.get("safety_info"):
            for safety_item in knowledge["safety_info"][:3]:
                response_parts.append(f"• {safety_item}")
        
        response_parts.append(f"\n🔧 {context.equipment_type.upper()} {context.issue_category.upper()} PROCEDURE:")
        
        # Equipment-specific procedures
        if knowledge.get("procedures"):
            if "immediate_steps" in knowledge["procedures"]:
                response_parts.append("IMMEDIATE ACTIONS:")
                for step in knowledge["procedures"]["immediate_steps"]:
                    response_parts.append(f"1. {step}")
            
            if "diagnostic_steps" in knowledge["procedures"]:
                response_parts.append("\nDIAGNOSTIC STEPS:")
                for step in knowledge["procedures"]["diagnostic_steps"]:
                    response_parts.append(f"• {step}")
        else:
            # Generic but specific advice based on issue category
            if context.issue_category == "vibration":
                response_parts.extend([
                    "1. Stop equipment and perform lockout/tagout",
                    "2. Check mounting bolts and foundations",
                    "3. Inspect bearings for wear or damage",
                    "4. Verify proper alignment of coupled components",
                    "5. Check for loose or damaged parts"
                ])
            elif context.issue_category == "overheating":
                response_parts.extend([
                    "1. Reduce load and monitor temperature",
                    "2. Check ventilation and cooling systems",
                    "3. Inspect for blocked air passages",
                    "4. Verify proper lubrication",
                    "5. Check electrical connections and voltage"
                ])
        
        response_parts.append(f"\n📋 Recommended follow-up: Schedule detailed inspection within 24-48 hours.")
        response_parts.append(f"🔍 For complex issues, consult equipment manual or contact manufacturer support.")
        
        return "\n".join(response_parts)

intelligent_ai = IntelligentMaintenanceAI()

async def query_llama_intelligent(message: str, context: str = "general") -> str:  # type: ignore[override]
    """Enhanced LLaMA query with intelligent maintenance knowledge"""
    return await intelligent_ai.generate_intelligent_response(message, context)

__all__ = [
    "MaintenanceContext",
    "IntelligentMaintenanceAI",
    "intelligent_ai",
    "query_llama_intelligent"
]
async def query_llama_intelligent(message: str, context: str = "general") -> str:
    """Enhanced LLaMA query with intelligent maintenance knowledge"""
    return await intelligent_ai.generate_intelligent_response(message, context)