#!/usr/bin/env python3
"""
Centralized AI Model Provider - Robust Llama Integration
Handles all AI model interactions with graceful degradation, retry logic, and proper error handling
"""

import os
import logging
import asyncio
import aiohttp
import json
import time
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass, field
from enum import Enum
import hashlib

# Import the API keys manager
try:
    from api_keys_manager import get_user_api_key
except ImportError:
    # Fallback function if API keys manager is not available
    def get_user_api_key(provider: str, user_id: str = "default") -> Optional[str]:
        return None

logger = logging.getLogger(__name__)

class AIProvider(Enum):
    LLAMA = "llama"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GROQ = "groq"
    GROK = "grok"
    GOOGLE = "google"
    COHERE = "cohere"
    HUGGINGFACE = "huggingface"
    CUSTOM = "custom"
    FALLBACK = "fallback"

@dataclass
class AIConfig:
    """AI Configuration with environment variable defaults"""
    llama_server: str = os.getenv("LLAMA_SERVER", "http://localhost:11434")
    llama_model: str = os.getenv("LLAMA_MODEL", "llama3.1:8b")
    llama_max_tokens: int = int(os.getenv("LLAMA_MAX_TOKENS", "1000"))
    llama_context: int = int(os.getenv("LLAMA_CONTEXT", "4096"))
    
    # Multi-Provider API configurations
    # OpenAI
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_base_url: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4")
    
    # Anthropic
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    anthropic_base_url: str = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
    anthropic_model: str = os.getenv("ANTHROPIC_MODEL", "claude-3-sonnet-20240229")
    
    # Groq
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    groq_base_url: str = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1")
    groq_model: str = os.getenv("GROQ_MODEL", "llama3-70b-8192")
    
    # Grok (X.AI)
    grok_api_key: str = os.getenv("XAI_API_KEY", os.getenv("GROK_API_KEY", ""))
    grok_base_url: str = os.getenv("GROK_BASE_URL", "https://api.x.ai/v1")
    grok_model: str = os.getenv("GROK_MODEL", "grok-2-1212")
    grok_max_tokens: int = int(os.getenv("GROK_MAX_TOKENS", "4096"))
    
    # Google (Gemini)
    google_api_key: str = os.getenv("GOOGLE_API_KEY", "")
    google_base_url: str = os.getenv("GOOGLE_BASE_URL", "https://generativelanguage.googleapis.com/v1beta")
    google_model: str = os.getenv("GOOGLE_MODEL", "gemini-pro")
    
    # Cohere
    cohere_api_key: str = os.getenv("COHERE_API_KEY", "")
    cohere_base_url: str = os.getenv("COHERE_BASE_URL", "https://api.cohere.ai/v1")
    cohere_model: str = os.getenv("COHERE_MODEL", "command-r-plus")
    
    # Custom provider
    custom_api_key: str = os.getenv("CUSTOM_API_KEY", "")
    custom_base_url: str = os.getenv("CUSTOM_BASE_URL", "")
    custom_model: str = os.getenv("CUSTOM_MODEL", "")
    custom_headers: Dict[str, str] = field(default_factory=lambda: {})
    
    # Default token limits for all providers
    max_tokens: int = int(os.getenv("AI_MAX_TOKENS", "4096"))
    
    provider_priority: List[str] = field(default_factory=lambda: os.getenv("AI_PROVIDER_PRIORITY", "llama,grok,groq,openai,anthropic,google,cohere,fallback").split(","))
    request_timeout: int = int(os.getenv("AI_REQUEST_TIMEOUT", "60"))
    max_retries: int = int(os.getenv("AI_MAX_RETRIES", "2"))
    retry_delay: float = float(os.getenv("AI_RETRY_DELAY", "1.0"))

@dataclass
class AIResponse:
    """Standardized AI response format"""
    content: str
    provider: AIProvider
    model: str
    tokens_used: Optional[int] = None
    response_time_ms: int = 0
    confidence: float = 1.0
    metadata: Dict[str, Any] = None
    error: Optional[str] = None

class CentralizedAIProvider:
    """Centralized AI provider with robust error handling and fallbacks"""
    
    def __init__(self, config: Optional[AIConfig] = None):
        self.config = config or AIConfig()
        self.providers_status = {provider: True for provider in AIProvider}
        self.request_cache = {}  # Simple cache for repeated requests
        self.warm_loaded = False
        self._session_pool = None  # Async HTTP session pool
        self._pool_lock = asyncio.Lock()
        
        # Ensure LLaMA is prioritized when no custom API keys are available
        self._optimize_provider_priority()
        
        logger.info(f"Initialized AI Provider with priority: {self.config.provider_priority}")
    
    def _optimize_provider_priority(self):
        """
        Optimize provider priority to ensure LLaMA is default when no custom API keys are provided.
        This ensures customers get free LLaMA by default, but can supercharge with their own API keys.
        """
        available_providers = []
        unavailable_providers = []
        
        # Check which providers have API keys configured
        api_key_mapping = {
            "openai": self.config.openai_api_key,
            "anthropic": self.config.anthropic_api_key,
            "groq": self.config.groq_api_key,
            "grok": self.config.grok_api_key,
            "google": self.config.google_api_key,
            "cohere": self.config.cohere_api_key,
            "custom": self.config.custom_api_key
        }
        
        # LLaMA is always available (local/ollama) - prioritize it first
        optimized_priority = ["llama"]
        
        # Add providers with API keys in order of preference for "supercharged" experience
        supercharged_order = ["grok", "groq", "openai", "anthropic", "google", "cohere", "custom"]
        
        for provider in supercharged_order:
            if api_key_mapping.get(provider, "").strip():
                optimized_priority.append(provider)
                available_providers.append(provider)
                logger.info(f"✅ {provider.upper()} API key configured - adding to priority list")
            else:
                unavailable_providers.append(provider)
        
        # Always include fallback at the end
        optimized_priority.append("fallback")
        
        # Update the configuration
        self.config.provider_priority = optimized_priority
        
        if available_providers:
            logger.info(f"🚀 SUPERCHARGED MODE: LLaMA + {len(available_providers)} premium providers: {', '.join(available_providers)}")
        else:
            logger.info("🦙 DEFAULT MODE: Using LLaMA as primary AI provider (free & capable)")
            
        if unavailable_providers:
            logger.debug(f"💡 TIP: Add API keys for {', '.join(unavailable_providers)} to unlock premium features")
    
    def _get_effective_provider_priority(self, user_id: str = "default") -> List[str]:
        """
        Get effective provider priority considering user-specific API keys.
        Users with custom API keys get supercharged experience with those providers prioritized.
        """
        # Start with LLaMA as the foundation (always available)
        effective_priority = ["llama"]
        
        # Check for user-specific API keys and add them to priority
        user_providers = []
        provider_checks = [
            ("grok", "grok"),
            ("groq", "groq"), 
            ("openai", "openai"),
            ("anthropic", "anthropic"),
            ("google", "google"),
            ("cohere", "cohere")
        ]
        
        for provider_name, api_key_name in provider_checks:
            user_api_key = get_user_api_key(api_key_name, user_id)
            if user_api_key and user_api_key.strip():
                effective_priority.append(provider_name)
                user_providers.append(provider_name)
                logger.debug(f"🚀 User {user_id} has {provider_name.upper()} API key - prioritizing")
        
        # Add system-level providers that aren't user-specific
        for provider in self.config.provider_priority:
            if provider not in effective_priority and provider != "fallback":
                effective_priority.append(provider)
        
        # Always end with fallback
        effective_priority.append("fallback")
        
        if user_providers:
            logger.info(f"👤 User {user_id} SUPERCHARGED: LLaMA + {', '.join(user_providers)}")
        else:
            logger.debug(f"👤 User {user_id} using default LLaMA provider")
            
        return effective_priority
    
    async def _get_session_pool(self) -> aiohttp.ClientSession:
        """Get or create the async HTTP session pool"""
        async with self._pool_lock:
            if self._session_pool is None or self._session_pool.closed:
                connector = aiohttp.TCPConnector(
                    limit=10,  # Total connection limit
                    limit_per_host=5,  # Connections per host
                    ttl_dns_cache=300,  # DNS cache TTL
                    use_dns_cache=True,
                    keepalive_timeout=30,
                    enable_cleanup_closed=True
                )
                
                timeout = aiohttp.ClientTimeout(
                    total=self.config.request_timeout,
                    connect=15,
                    sock_read=self.config.request_timeout - 5
                )
                
                self._session_pool = aiohttp.ClientSession(
                    connector=connector,
                    timeout=timeout,
                    headers={
                        "User-Agent": "ChatterFix-CMMS/3.0.0",
                        "Accept": "application/json",
                        "Content-Type": "application/json"
                    }
                )
                logger.info("Created new HTTP session pool for AI requests")
            
            return self._session_pool
    
    async def _cleanup_session_pool(self):
        """Cleanup the session pool"""
        if self._session_pool and not self._session_pool.closed:
            await self._session_pool.close()
            logger.info("Cleaned up HTTP session pool")
    
    async def shutdown(self):
        """Shutdown the AI provider and cleanup resources"""
        await self._cleanup_session_pool()
        logger.info("AI Provider shutdown complete")
    
    def __del__(self):
        """Cleanup on garbage collection"""
        try:
            if self._session_pool and not self._session_pool.closed:
                # Schedule cleanup if event loop is still running
                import asyncio
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        loop.create_task(self._cleanup_session_pool())
                except RuntimeError:
                    pass  # Event loop is not running
        except Exception:
            pass  # Ignore errors during cleanup
    
    async def initialize(self) -> bool:
        """Initialize and warm-load the AI provider"""
        try:
            # Warm load with a simple test
            test_response = await self.generate(
                "System test", 
                context="initialization",
                max_tokens=10,
                cache_key="warmup"
            )
            
            if test_response.content and not test_response.error:
                self.warm_loaded = True
                logger.info(f"AI Provider warm-loaded successfully with {test_response.provider.value}")
                return True
            else:
                logger.warning(f"AI Provider warm-load failed: {test_response.error}")
                return False
                
        except Exception as e:
            logger.error(f"AI Provider initialization failed: {e}")
            return False
    
    async def generate(
        self,
        message: str,
        context: str = "general",
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: float = 0.1,
        stream: bool = False,
        cache_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        user_id: str = "default"
    ) -> AIResponse:
        """
        Generate AI response with centralized routing and fallback logic
        
        Args:
            message: User message/prompt
            context: Context for the request (maintenance, diagnostic, etc.)
            system_prompt: Optional system prompt override
            max_tokens: Maximum tokens to generate
            temperature: Response temperature (0.0-1.0)
            stream: Enable streaming response
            cache_key: Optional cache key for request caching
            metadata: Additional metadata to track
            
        Returns:
            AIResponse object with content and metadata
        """
        start_time = time.time()
        
        # Check cache first
        if cache_key:
            cached_response = self._get_cached_response(cache_key)
            if cached_response:
                logger.debug(f"Returning cached response for key: {cache_key}")
                return cached_response
        
        # Get dynamic provider priority based on user's API keys
        effective_priority = self._get_effective_provider_priority(user_id)
        
        # Try providers in priority order
        for provider_name in effective_priority:
            try:
                provider = AIProvider(provider_name)
                
                # Skip if provider is marked as down
                if not self.providers_status.get(provider, False):
                    logger.warning(f"Skipping provider {provider_name} - marked as down")
                    continue
                
                logger.info(f"Attempting to use provider: {provider_name}")
                
                response = await self._generate_with_provider(
                    provider=provider,
                    message=message,
                    context=context,
                    system_prompt=system_prompt,
                    max_tokens=max_tokens or self.config.llama_max_tokens,
                    temperature=temperature,
                    stream=stream,
                    metadata=metadata or {},
                    user_id=user_id
                )
                
                # Calculate response time
                response.response_time_ms = int((time.time() - start_time) * 1000)
                
                # Cache successful responses
                if cache_key and not response.error:
                    self._cache_response(cache_key, response)
                
                # Log successful generation
                logger.debug(f"Generated response via {provider.value} in {response.response_time_ms}ms")
                
                return response
                
            except Exception as e:
                logger.warning(f"Provider {provider_name} failed: {e}")
                # Mark provider as temporarily down
                self.providers_status[AIProvider(provider_name)] = False
                continue
        
        # All providers failed - return fallback response
        return self._generate_fallback_response(message, context, start_time)
    
    async def _generate_with_provider(
        self,
        provider: AIProvider,
        message: str,
        context: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
        stream: bool,
        metadata: Dict[str, Any],
        user_id: str = "default"
    ) -> AIResponse:
        """Generate response with specific provider"""
        
        if provider == AIProvider.LLAMA:
            return await self._generate_with_llama(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.OPENAI:
            return await self._generate_with_openai(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.ANTHROPIC:
            return await self._generate_with_anthropic(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.GROQ:
            return await self._generate_with_groq(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.GROK:
            return await self._generate_with_grok(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.GOOGLE:
            return await self._generate_with_google(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.COHERE:
            return await self._generate_with_cohere(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.CUSTOM:
            return await self._generate_with_custom(
                message, context, system_prompt, max_tokens, temperature, stream, metadata, user_id
            )
        elif provider == AIProvider.FALLBACK:
            return self._generate_fallback_response(message, context, time.time())
        else:
            raise NotImplementedError(f"Provider {provider.value} not implemented")
    
    async def _generate_with_llama(
        self,
        message: str,
        context: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
        stream: bool,
        metadata: Dict[str, Any],
        user_id: str = "default"
    ) -> AIResponse:
        """Enhanced LLaMA generation with advanced features"""
        
        # Create enhanced system prompt with context awareness
        if not system_prompt:
            system_prompt = self._create_enhanced_maintenance_prompt(context, metadata)
        
        # Enhanced payload with adaptive parameters
        payload = {
            "model": self.config.llama_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ],
            "stream": stream,
            "options": {
                "temperature": self._adaptive_temperature(context, temperature),
                "top_p": self._adaptive_top_p(context),
                "top_k": self._adaptive_top_k(context),
                "max_tokens": max_tokens,
                "num_predict": max_tokens,
                "stop": self._get_context_stop_tokens(context),
                "repeat_penalty": self._adaptive_repeat_penalty(context),
                "num_ctx": self.config.llama_context,
                "mirostat": 2 if context in ["diagnostic", "safety"] else 0,  # Better consistency for critical tasks
                "mirostat_eta": 0.1,
                "mirostat_tau": 5.0
            }
        }
        
        # Add metadata to options if provided
        if metadata:
            payload["options"].update(metadata.get("llama_options", {}))
        
        # Enhanced retry logic with exponential backoff
        for attempt in range(self.config.max_retries + 1):
            try:
                session = await self._get_session_pool()
                
                # Add request tracing for debugging
                request_start = time.time()
                
                async with session.post(
                    f"{self.config.llama_server}/api/chat",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.config.request_timeout + attempt * 10)
                    ) as response:
                        
                        if response.status == 200:
                            result = await response.json()
                            request_time = time.time() - request_start
                            
                            if "message" in result and "content" in result["message"]:
                                content = result["message"]["content"].strip()
                                
                                # Enhanced post-processing with context-awareness
                                content = self._enhanced_post_process_response(content, context, metadata)
                                
                                # Calculate quality metrics
                                quality_score = self._calculate_response_quality(content, message, context)
                                
                                return AIResponse(
                                    content=content,
                                    provider=AIProvider.LLAMA,
                                    model=self.config.llama_model,
                                    tokens_used=result.get("eval_count"),
                                    confidence=min(0.9 + quality_score * 0.1, 1.0),
                                    metadata={
                                        "attempt": attempt + 1,
                                        "context": context,
                                        "request_time": request_time,
                                        "quality_score": quality_score,
                                        "model_params": payload["options"],
                                        "llama_stats": {
                                            "total_duration": result.get("total_duration"),
                                            "load_duration": result.get("load_duration"),
                                            "prompt_eval_count": result.get("prompt_eval_count"),
                                            "prompt_eval_duration": result.get("prompt_eval_duration"),
                                            "eval_count": result.get("eval_count"),
                                            "eval_duration": result.get("eval_duration")
                                        },
                                        **metadata
                                    }
                                )
                            else:
                                raise ValueError(f"Invalid LLaMA response format: {result}")
                        else:
                            error_text = await response.text()
                            logger.warning(f"LLaMA HTTP {response.status}: {error_text}")
                            raise aiohttp.ClientResponseError(
                                request_info=response.request_info,
                                history=response.history,
                                status=response.status,
                                message=f"LLaMA API error: {error_text}"
                            )
            
            except Exception as e:
                if attempt < self.config.max_retries:
                    # Exponential backoff with jitter
                    delay = self.config.retry_delay * (2 ** attempt) + (attempt * 0.1)
                    logger.warning(f"LLaMA attempt {attempt + 1} failed: {e}, retrying in {delay:.1f}s")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"LLaMA generation failed after {self.config.max_retries + 1} attempts: {e}")
                    # Mark LLaMA as temporarily down
                    self.providers_status[AIProvider.LLAMA] = False
                    raise
        
        raise Exception("Maximum retries exceeded")
    
    def _create_maintenance_system_prompt(self, context: str) -> str:
        """Create context-aware system prompt for maintenance scenarios"""
        
        base_prompt = """You are ChatterFix AI, an expert industrial maintenance assistant with 30+ years of experience. You provide precise, actionable technical advice for industrial equipment maintenance and repair."""
        
        context_prompts = {
            "diagnostic": base_prompt + " Focus on systematic diagnostic procedures with specific measurements and test equipment.",
            "safety": base_prompt + " Emphasize OSHA safety protocols, lockout/tagout procedures, and proper PPE requirements.",
            "repair": base_prompt + " Provide detailed repair procedures with specific torque values, part numbers, and tool requirements.",
            "preventive": base_prompt + " Focus on preventive maintenance schedules, condition monitoring, and failure prevention.",
            "troubleshooting": base_prompt + " Provide systematic troubleshooting steps with root cause analysis.",
            "general": base_prompt + " Provide comprehensive maintenance guidance covering safety, diagnosis, and repair."
        }
        
        return context_prompts.get(context, context_prompts["general"])
    
    def _create_enhanced_maintenance_prompt(self, context: str, metadata: Dict[str, Any] = None) -> str:
        """Create enhanced system prompt with advanced context awareness"""
        
        base_prompt = self._create_maintenance_system_prompt(context)
        
        # Add context-specific enhancements
        enhancements = []
        
        if context == "diagnostic":
            enhancements.append("\n🔍 DIAGNOSTIC FOCUS:")
            enhancements.append("- Use systematic troubleshooting methodology")
            enhancements.append("- Reference OEM specifications and tolerances")
            enhancements.append("- Prioritize root cause analysis over symptoms")
            enhancements.append("- Include measurement procedures and acceptance criteria")
            
        elif context == "safety":
            enhancements.append("\n⚠️ SAFETY PRIORITY:")
            enhancements.append("- ALWAYS mention LOTO (Lockout/Tagout) procedures first")
            enhancements.append("- Specify required PPE for each task")
            enhancements.append("- Include hazard identification and risk assessment")
            enhancements.append("- Reference applicable OSHA standards")
            
        elif context == "repair":
            enhancements.append("\n🔧 REPAIR EXCELLENCE:")
            enhancements.append("- Provide specific torque values and tool requirements")
            enhancements.append("- Include part numbers and specifications")
            enhancements.append("- Detail proper installation and alignment procedures")
            enhancements.append("- Specify post-repair testing and validation steps")
            
        elif context == "preventive":
            enhancements.append("\n📅 PREVENTIVE OPTIMIZATION:")
            enhancements.append("- Focus on condition-based maintenance opportunities")
            enhancements.append("- Include early warning indicators and thresholds")
            enhancements.append("- Optimize maintenance intervals based on operating conditions")
            enhancements.append("- Consider predictive maintenance technology integration")
        
        # Add equipment-specific knowledge if available in metadata
        if metadata and "equipment_type" in metadata:
            equipment_type = metadata["equipment_type"]
            enhancements.append(f"\n🏭 EQUIPMENT EXPERTISE ({equipment_type.upper()}):")
            enhancements.append(f"- Apply specialized knowledge of {equipment_type} systems")
            enhancements.append("- Reference industry best practices and standards")
            enhancements.append("- Consider operational impact and production requirements")
        
        # Add urgency awareness
        if metadata and metadata.get("priority") in ["critical", "high"]:
            enhancements.append("\n🚨 URGENCY AWARENESS:")
            enhancements.append("- Prioritize immediate stabilization and safety")
            enhancements.append("- Provide rapid response troubleshooting steps")
            enhancements.append("- Include temporary mitigation measures if applicable")
        
        return base_prompt + "".join(enhancements)
    
    def _adaptive_temperature(self, context: str, base_temperature: float) -> float:
        """Adapt temperature based on context for optimal performance"""
        context_adjustments = {
            "safety": -0.05,      # More conservative for safety
            "diagnostic": -0.03,  # More focused for diagnostics
            "repair": -0.02,      # Slightly more focused for repairs
            "preventive": 0.01,   # Slightly more creative for PM planning
            "general": 0.0        # No adjustment
        }
        
        adjustment = context_adjustments.get(context, 0.0)
        return max(0.0, min(1.0, base_temperature + adjustment))
    
    def _adaptive_top_p(self, context: str) -> float:
        """Adapt top_p based on context"""
        context_values = {
            "safety": 0.85,      # More conservative
            "diagnostic": 0.87,  # Focused
            "repair": 0.88,      # Balanced
            "preventive": 0.92,  # More diverse
            "general": 0.9       # Default
        }
        
        return context_values.get(context, 0.9)
    
    def _adaptive_top_k(self, context: str) -> int:
        """Adapt top_k based on context"""
        context_values = {
            "safety": 30,        # More conservative
            "diagnostic": 35,    # Focused
            "repair": 40,        # Balanced
            "preventive": 50,    # More diverse
            "general": 40        # Default
        }
        
        return context_values.get(context, 40)
    
    def _adaptive_repeat_penalty(self, context: str) -> float:
        """Adapt repeat penalty based on context"""
        context_values = {
            "safety": 1.15,      # Avoid repetition in safety contexts
            "diagnostic": 1.12,  # Structured but not repetitive
            "repair": 1.1,       # Standard
            "preventive": 1.08,  # Allow some repetition for consistency
            "general": 1.1       # Default
        }
        
        return context_values.get(context, 1.1)
    
    def _get_context_stop_tokens(self, context: str) -> List[str]:
        """Get context-appropriate stop tokens"""
        base_tokens = ["<|end|>", "<|stop|>", "\n\n---", "\n\nUser:", "\n\nHuman:"]
        
        context_tokens = {
            "safety": ["UNSAFE", "DANGER:", "⚠️ WARNING:", "🚨 ALERT:"],
            "diagnostic": ["CONCLUSION:", "FINAL DIAGNOSIS:", "NEXT STEPS:"],
            "repair": ["PROCEDURE COMPLETE", "TASK FINISHED", "VALIDATION:"],
            "preventive": ["SCHEDULE:", "NEXT PM:", "FREQUENCY:"]
        }
        
        return base_tokens + context_tokens.get(context, [])
    
    def _enhanced_post_process_response(self, content: str, context: str, metadata: Dict[str, Any] = None) -> str:
        """Enhanced post-processing with context-awareness and quality improvements"""
        
        # Apply original post-processing
        content = self._post_process_response(content, context)
        
        # Context-specific enhancements
        if context == "safety":
            # Ensure safety content is prominently displayed
            if not any(indicator in content.upper() for indicator in ["SAFETY", "PPE", "LOCKOUT", "HAZARD"]):
                safety_reminder = "⚠️ SAFETY REMINDER: Always follow proper safety procedures and use appropriate PPE.\n\n"
                content = safety_reminder + content
                
        elif context == "diagnostic":
            # Improve diagnostic structure
            if "STEPS:" not in content.upper() and "PROCEDURE:" not in content.upper():
                # Look for numbered lists and enhance them
                import re
                if re.search(r'\d+\.', content):
                    content = "🔍 DIAGNOSTIC PROCEDURE:\n\n" + content
                    
        elif context == "repair":
            # Enhance repair instructions
            if "TOOLS:" not in content.upper() and "REQUIRED:" not in content.upper():
                if any(tool in content.lower() for tool in ["wrench", "screwdriver", "meter", "gauge"]):
                    content = "🔧 REPAIR PROCEDURE:\n\n" + content
        
        # Add professional formatting
        content = self._apply_professional_formatting(content)
        
        # Add metadata-based enhancements
        if metadata:
            if metadata.get("priority") == "critical":
                content = "🚨 CRITICAL PRIORITY TASK\n\n" + content
            elif metadata.get("equipment_type"):
                equipment_type = metadata["equipment_type"].replace("_", " ").title()
                content = f"🏭 Equipment Type: {equipment_type}\n\n" + content
        
        return content
    
    def _apply_professional_formatting(self, content: str) -> str:
        """Apply professional formatting to the response"""
        
        # Improve bullet points
        content = content.replace("- ", "• ")
        content = content.replace("* ", "• ")
        
        # Improve numbered lists
        import re
        content = re.sub(r'^(\d+)\.\s*', r'\1️⃣ ', content, flags=re.MULTILINE)
        
        # Add spacing around headers
        content = re.sub(r'^([A-Z][A-Z\s]{3,}):(.*)$', r'\1:\n\2', content, flags=re.MULTILINE)
        
        # Clean up excessive whitespace
        content = re.sub(r'\n\s*\n\s*\n', '\n\n', content)
        
        return content.strip()
    
    def _calculate_response_quality(self, content: str, original_message: str, context: str) -> float:
        """Calculate response quality score (0.0 to 1.0)"""
        
        quality_score = 0.0
        
        # Length appropriateness (not too short, not too long)
        length_score = min(1.0, len(content) / 500) * 0.2
        if len(content) > 2000:
            length_score *= 0.8  # Penalize overly long responses
        quality_score += length_score
        
        # Context relevance
        context_keywords = {
            "safety": ["safety", "ppe", "lockout", "hazard", "risk", "osha"],
            "diagnostic": ["check", "test", "measure", "inspect", "diagnose", "troubleshoot"],
            "repair": ["replace", "install", "tighten", "align", "torque", "procedure"],
            "preventive": ["schedule", "maintain", "lubricate", "monitor", "interval"]
        }
        
        if context in context_keywords:
            relevant_keywords = sum(1 for keyword in context_keywords[context] 
                                  if keyword.lower() in content.lower())
            context_score = min(1.0, relevant_keywords / len(context_keywords[context])) * 0.3
            quality_score += context_score
        
        # Structure and formatting
        structure_indicators = [
            "1." in content or "1️⃣" in content,  # Numbered lists
            "•" in content or "-" in content,     # Bullet points
            ":" in content,                       # Headers/sections
            "\n\n" in content                     # Proper spacing
        ]
        structure_score = sum(structure_indicators) / len(structure_indicators) * 0.2
        quality_score += structure_score
        
        # Technical completeness
        technical_indicators = [
            any(word in content.lower() for word in ["specification", "tolerance", "measurement"]),
            any(word in content.lower() for word in ["tool", "equipment", "instrument"]),
            any(word in content.lower() for word in ["step", "procedure", "method"]),
            len(content.split()) > 20  # Adequate detail
        ]
        technical_score = sum(technical_indicators) / len(technical_indicators) * 0.3
        quality_score += technical_score
        
        return min(1.0, quality_score)
    
    def _post_process_response(self, content: str, context: str) -> str:
        """Post-process AI response for better formatting and safety"""
        
        # Ensure safety information is prominent for maintenance contexts
        if context in ["repair", "diagnostic", "troubleshooting"] and "safety" not in content.lower():
            safety_note = "⚠️ SAFETY: Follow lockout/tagout procedures before beginning work.\n\n"
            content = safety_note + content
        
        # Improve formatting
        content = content.replace("1.", "\n1.")
        content = content.replace("2.", "\n2.")
        content = content.replace("3.", "\n3.")
        content = content.replace("4.", "\n4.")
        content = content.replace("5.", "\n5.")
        
        # Add emphasis markers
        content = content.replace("IMPORTANT:", "🔧 IMPORTANT:")
        content = content.replace("WARNING:", "⚠️ WARNING:")
        content = content.replace("NOTE:", "📋 NOTE:")
        
        return content.strip()
    
    async def _generate_with_grok(
        self,
        message: str,
        context: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
        stream: bool,
        metadata: Dict[str, Any],
        user_id: str = "default"
    ) -> AIResponse:
        """Generate response using Grok API"""
        
        start_time = time.time()
        
        # Create system prompt if not provided
        if not system_prompt:
            system_prompt = self._create_maintenance_system_prompt(context)
        
        # Use user-provided API key or fall back to config
        api_key = get_user_api_key("grok", user_id) or self.config.grok_api_key
        if not api_key:
            raise Exception("Grok API key not configured for this user")
        
        # Build Grok API request
        payload = {
            "model": self.config.grok_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ],
            "max_tokens": min(max_tokens, self.config.grok_max_tokens),
            "temperature": temperature,
            "stream": stream
        }
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            session = await self._get_session_pool()
            
            async with session.post(
                f"{self.config.grok_base_url}/chat/completions",
                json=payload,
                headers=headers
            ) as response:
                
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"Grok API error {response.status}: {error_text}")
                    raise Exception(f"Grok API error: {response.status}")
                
                result = await response.json()
                content = result["choices"][0]["message"]["content"]
                
                return AIResponse(
                    content=content,
                    provider=AIProvider.GROK,
                    model=self.config.grok_model,
                    tokens_used=result.get("usage", {}).get("total_tokens"),
                    response_time_ms=int((time.time() - start_time) * 1000),
                    confidence=0.95,  # Grok is highly capable
                    metadata={
                        "context": context,
                        "system_prompt_used": bool(system_prompt),
                        "api_response": result,
                        **metadata
                    }
                )
                
        except Exception as e:
            logger.error(f"Grok generation failed: {str(e)}")
            self.providers_status[AIProvider.GROK] = False
            raise e
    
    async def _generate_with_groq(
        self,
        message: str,
        context: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
        stream: bool,
        metadata: Dict[str, Any],
        user_id: str = "default"
    ) -> AIResponse:
        """Generate response using Groq API - Excellent for coding tasks"""
        
        start_time = time.time()
        
        # Create system prompt if not provided
        if not system_prompt:
            system_prompt = self._create_maintenance_system_prompt(context)
            
        # Groq is excellent for coding, so enhance the prompt for code-related tasks
        if any(keyword in message.lower() for keyword in ['code', 'function', 'script', 'programming', 'debug', 'refactor', 'implement']):
            system_prompt += "\n\nYou are an expert software engineer. Provide high-quality, production-ready code with proper error handling, documentation, and best practices."
        
        # Use user-provided API key or fall back to config
        api_key = get_user_api_key("groq", user_id) or self.config.groq_api_key
        if not api_key:
            raise Exception("Groq API key not configured for this user")
        
        # Build Groq API request (OpenAI-compatible format)
        payload = {
            "model": self.config.groq_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ],
            "max_tokens": min(max_tokens, self.config.max_tokens),
            "temperature": temperature,
            "stream": stream
        }
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            session = await self._get_session_pool()
            
            async with session.post(
                f"{self.config.groq_base_url}/chat/completions",
                json=payload,
                headers=headers
            ) as response:
                
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"Groq API error {response.status}: {error_text}")
                    raise Exception(f"Groq API error: {response.status}")
                
                result = await response.json()
                content = result["choices"][0]["message"]["content"]
                
                return AIResponse(
                    content=content,
                    provider=AIProvider.GROQ,
                    model=self.config.groq_model,
                    tokens_used=result.get("usage", {}).get("total_tokens"),
                    response_time_ms=int((time.time() - start_time) * 1000),
                    confidence=0.92,  # Groq is very fast and reliable
                    metadata={
                        "context": context,
                        "system_prompt_used": bool(system_prompt),
                        "is_coding_task": any(keyword in message.lower() for keyword in ['code', 'function', 'script']),
                        "api_response": result,
                        **metadata
                    }
                )
                
        except Exception as e:
            logger.error(f"Groq generation failed: {str(e)}")
            self.providers_status[AIProvider.GROQ] = False
            raise e
    
    async def _generate_with_openai(
        self,
        message: str,
        context: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
        stream: bool,
        metadata: Dict[str, Any],
        user_id: str = "default"
    ) -> AIResponse:
        """Generate response using OpenAI API"""
        
        start_time = time.time()
        
        if not system_prompt:
            system_prompt = self._create_maintenance_system_prompt(context)
        
        payload = {
            "model": self.config.openai_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ],
            "max_tokens": min(max_tokens, self.config.max_tokens),
            "temperature": temperature,
            "stream": stream
        }
        
        # Use user-provided API key or fall back to config
        api_key = get_user_api_key("openai", user_id) or self.config.openai_api_key
        if not api_key:
            raise Exception("OpenAI API key not configured for this user")
            
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            session = await self._get_session_pool()
            
            async with session.post(
                f"{self.config.openai_base_url}/chat/completions",
                json=payload,
                headers=headers
            ) as response:
                
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"OpenAI API error {response.status}: {error_text}")
                    raise Exception(f"OpenAI API error: {response.status}")
                
                result = await response.json()
                content = result["choices"][0]["message"]["content"]
                
                return AIResponse(
                    content=content,
                    provider=AIProvider.OPENAI,
                    model=self.config.openai_model,
                    tokens_used=result.get("usage", {}).get("total_tokens"),
                    response_time_ms=int((time.time() - start_time) * 1000),
                    confidence=0.94,
                    metadata={
                        "context": context,
                        "system_prompt_used": bool(system_prompt),
                        "api_response": result,
                        **metadata
                    }
                )
                
        except Exception as e:
            logger.error(f"OpenAI generation failed: {str(e)}")
            self.providers_status[AIProvider.OPENAI] = False
            raise e
    
    def _generate_fallback_response(self, message: str, context: str, start_time: float) -> AIResponse:
        """Generate fallback response when all AI providers fail"""
        
        message_lower = message.lower()
        
        # Analyze message for fallback content
        if any(word in message_lower for word in ["vibrat", "shak", "oscillat"]):
            content = """⚠️ SAFETY: Implement lockout/tagout before inspection.

🔧 VIBRATION ANALYSIS CHECKLIST:
1. Check belt tension and alignment
2. Inspect coupling for wear or misalignment  
3. Verify mounting bolt torque specifications
4. Measure vibration at motor bearings
5. Review lubrication schedule and condition

Acceptable vibration levels: <4.5 mm/s RMS overall
Contact maintenance supervisor if readings exceed limits."""
        
        elif any(word in message_lower for word in ["overheat", "hot", "temperature"]):
            content = """⚠️ SAFETY: Allow equipment to cool before inspection.

🔧 OVERHEATING TROUBLESHOOTING:
1. Check cooling air flow and clean filters
2. Verify electrical connections are tight
3. Measure operating current vs nameplate values
4. Inspect for blocked cooling passages
5. Check lubrication levels and condition

Normal operating temperature: <80°C above ambient
Monitor with thermal imaging if available."""
        
        elif any(word in message_lower for word in ["leak", "drip", "fluid"]):
            content = """⚠️ SAFETY: Use appropriate PPE for fluid contact.

🔧 LEAK ASSESSMENT PROTOCOL:
1. Identify leak source and fluid type
2. Check seal condition and proper installation
3. Verify system pressure within specifications
4. Inspect for proper torque on fittings
5. Plan repair during next scheduled shutdown

Document leak rate and monitor for changes
Replace seals with OEM or approved equivalent parts."""
        
        else:
            content = """🔧 MAINTENANCE GUIDANCE AVAILABLE

I'm currently experiencing connectivity issues with the advanced AI system, but I can still provide basic maintenance assistance.

GENERAL TROUBLESHOOTING STEPS:
1. Ensure proper safety lockout/tagout procedures
2. Document current symptoms and operating conditions
3. Check for obvious issues (loose connections, wear, leaks)
4. Consult equipment manual for specifications
5. Contact maintenance supervisor for complex issues

For immediate safety concerns, shut down equipment and contact supervision."""
        
        response_time_ms = int((time.time() - start_time) * 1000)
        
        return AIResponse(
            content=content,
            provider=AIProvider.FALLBACK,
            model="fallback_expert_system",
            response_time_ms=response_time_ms,
            confidence=0.6,
            metadata={
                "fallback_reason": "ai_providers_unavailable",
                "context": context
            }
        )
    
    def _get_cached_response(self, cache_key: str) -> Optional[AIResponse]:
        """Get response from cache if available and not expired"""
        if cache_key in self.request_cache:
            cached_data = self.request_cache[cache_key]
            # Simple 5-minute cache expiry
            if time.time() - cached_data["timestamp"] < 300:
                return cached_data["response"]
        return None
    
    def _cache_response(self, cache_key: str, response: AIResponse) -> None:
        """Cache response with timestamp"""
        self.request_cache[cache_key] = {
            "response": response,
            "timestamp": time.time()
        }
        
        # Simple cache cleanup - keep only last 100 entries
        if len(self.request_cache) > 100:
            oldest_key = min(self.request_cache.keys(), 
                           key=lambda k: self.request_cache[k]["timestamp"])
            del self.request_cache[oldest_key]
    
    async def health_check(self) -> Dict[str, Any]:
        """Check health of all AI providers"""
        health_status = {}
        
        for provider in AIProvider:
            try:
                if provider == AIProvider.LLAMA:
                    # Quick health check for LLaMA using session pool
                    session = await self._get_session_pool()
                    async with session.get(f"{self.config.llama_server}/api/tags") as response:
                            if response.status == 200:
                                models = await response.json()
                                health_status[provider.value] = {
                                    "status": "healthy",
                                    "models": [m.get("name") for m in models.get("models", [])],
                                    "current_model": self.config.llama_model
                                }
                            else:
                                health_status[provider.value] = {
                                    "status": "unhealthy", 
                                    "error": f"HTTP {response.status}"
                                }
                elif provider == AIProvider.FALLBACK:
                    health_status[provider.value] = {"status": "healthy", "note": "always_available"}
                else:
                    health_status[provider.value] = {"status": "not_implemented"}
                    
            except Exception as e:
                health_status[provider.value] = {
                    "status": "error",
                    "error": str(e)
                }
        
        return {
            "overall_status": "healthy" if any(
                status.get("status") == "healthy" 
                for status in health_status.values()
            ) else "degraded",
            "providers": health_status,
            "config": {
                "priority": self.config.provider_priority,
                "warm_loaded": self.warm_loaded,
                "cache_size": len(self.request_cache)
            }
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get current provider status"""
        return {
            "warm_loaded": self.warm_loaded,
            "providers_status": {p.value: status for p, status in self.providers_status.items()},
            "cache_entries": len(self.request_cache),
            "config": {
                "llama_server": self.config.llama_server,
                "llama_model": self.config.llama_model,
                "max_tokens": self.config.llama_max_tokens,
                "timeout": self.config.request_timeout,
                "retry_policy": f"{self.config.max_retries} retries, {self.config.retry_delay}s delay"
            }
        }

# Global AI provider instance
ai_provider = CentralizedAIProvider()

# Convenience functions for easy integration
async def generate_response(
    message: str,
    context: str = "general",
    **kwargs
) -> str:
    """Convenience function to get AI response content"""
    response = await ai_provider.generate(message, context, **kwargs)
    return response.content

async def generate_maintenance_advice(
    equipment_issue: str,
    equipment_type: str = "industrial equipment"
) -> str:
    """Generate maintenance-specific advice"""
    context_message = f"EQUIPMENT: {equipment_type}\nISSUE: {equipment_issue}"
    
    response = await ai_provider.generate(
        message=context_message,
        context="diagnostic",
        cache_key=hashlib.md5(context_message.encode()).hexdigest()
    )
    
    return response.content

async def initialize_ai_provider() -> bool:
    """Initialize the global AI provider"""
    return await ai_provider.initialize()

# Export the main provider and convenience functions
__all__ = [
    'CentralizedAIProvider', 
    'ai_provider', 
    'generate_response', 
    'generate_maintenance_advice',
    'initialize_ai_provider',
    'AIResponse',
    'AIConfig'
]