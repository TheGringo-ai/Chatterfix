"""
AIOps API Router for ChatterFix CMMS
Provides endpoints for incident summaries and self-healing actions.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks, Query
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import logging
from datetime import datetime, timedelta
import asyncio
import os
from pathlib import Path

from aiops_monitor import aiops_monitor, Incident, IncidentType, IncidentSeverity
from aiops_playbooks import playbook_registry, PlaybookExecution, PlaybookStatus, PlaybookTrigger

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/ai/ops", tags=["aiops", "monitoring", "self-healing"])

# =============================================================================
# Request/Response Models
# =============================================================================

class IncidentResponse(BaseModel):
    """Response model for incidents"""
    incident_id: str
    request_id: str
    type: str
    severity: str
    title: str
    description: str
    what: str
    why: str
    next: str
    first_seen: datetime
    last_seen: datetime
    count: int
    affected_components: List[str]
    status: str
    resolved_at: Optional[datetime] = None

class DailyIncidentSummaryResponse(BaseModel):
    """Response model for daily incident summary"""
    date: str
    total_incidents: int
    incidents_by_severity: Dict[str, int]
    incidents_by_type: Dict[str, int]
    incidents: List[IncidentResponse]
    summary_analysis: str

class PlaybookListResponse(BaseModel):
    """Response model for playbook list"""
    playbooks: List[Dict[str, Any]]
    total_count: int

class PlaybookExecutionResponse(BaseModel):
    """Response model for playbook execution"""
    execution_id: str
    playbook_name: str
    status: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    steps_completed: int
    total_steps: int
    output_log: List[str]
    error_message: Optional[str] = None

class TriggerPlaybookRequest(BaseModel):
    """Request model for triggering playbooks"""
    incident_id: Optional[str] = Field(None, description="Associated incident ID")
    context: Optional[Dict[str, Any]] = Field(None, description="Additional context for execution")

# =============================================================================
# Incident Summary Endpoints
# =============================================================================

@router.get("/summary/today", response_model=DailyIncidentSummaryResponse)
async def get_todays_incident_summary():
    """
    Get today's incident summary with what/why/next analysis.
    Returns comprehensive daily incident report.
    """
    try:
        logger.info("📊 Generating today's incident summary")
        
        # Get today's incidents from monitor
        summary = aiops_monitor.get_daily_summary()
        
        if "error" in summary:
            raise HTTPException(status_code=500, detail=summary["error"])
        
        # Convert incidents to response format
        incidents = []
        for incident_data in summary.get("incidents", []):
            incidents.append(IncidentResponse(
                incident_id=incident_data["incident_id"],
                request_id=incident_data["request_id"],
                type=incident_data["type"],
                severity=incident_data["severity"],
                title=incident_data["title"],
                description=incident_data["description"],
                what=incident_data["what"],
                why=incident_data["why"],
                next=incident_data["next"],
                first_seen=datetime.fromisoformat(incident_data["first_seen"]),
                last_seen=datetime.fromisoformat(incident_data["last_seen"]),
                count=incident_data["count"],
                affected_components=incident_data["affected_components"],
                status=incident_data["status"],
                resolved_at=datetime.fromisoformat(incident_data["resolved_at"]) if incident_data.get("resolved_at") else None
            ))
        
        # Generate summary analysis
        total = summary["total_incidents"]
        critical_count = summary["incidents_by_severity"].get("critical", 0)
        high_count = summary["incidents_by_severity"].get("high", 0)
        
        if total == 0:
            analysis = "No incidents detected today. System operating normally."
        elif critical_count > 0:
            analysis = f"Critical day: {critical_count} critical incidents requiring immediate attention. Review system stability."
        elif high_count > 0:
            analysis = f"Elevated activity: {high_count} high-priority incidents detected. Monitor system closely."
        else:
            analysis = f"Normal operations: {total} minor incidents handled successfully."
        
        return DailyIncidentSummaryResponse(
            date=summary["date"],
            total_incidents=total,
            incidents_by_severity=summary["incidents_by_severity"],
            incidents_by_type=summary["incidents_by_type"],
            incidents=incidents,
            summary_analysis=analysis
        )
        
    except Exception as e:
        logger.error(f"Failed to get today's incident summary: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve incident summary: {str(e)}"
        )

@router.get("/summary/{date}", response_model=DailyIncidentSummaryResponse)
async def get_incident_summary_by_date(date: str):
    """
    Get incident summary for a specific date (YYYY-MM-DD format).
    """
    try:
        logger.info(f"📊 Getting incident summary for date: {date}")
        
        # Parse date
        try:
            summary_date = datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD")
        
        # Get summary for specific date
        summary = aiops_monitor.get_daily_summary(summary_date)
        
        if "error" in summary:
            raise HTTPException(status_code=404, detail=f"No summary found for {date}")
        
        # Convert incidents to response format (same as today's summary)
        incidents = []
        for incident_data in summary.get("incidents", []):
            incidents.append(IncidentResponse(
                incident_id=incident_data["incident_id"],
                request_id=incident_data["request_id"],
                type=incident_data["type"],
                severity=incident_data["severity"],
                title=incident_data["title"],
                description=incident_data["description"],
                what=incident_data["what"],
                why=incident_data["why"],
                next=incident_data["next"],
                first_seen=datetime.fromisoformat(incident_data["first_seen"]),
                last_seen=datetime.fromisoformat(incident_data["last_seen"]),
                count=incident_data["count"],
                affected_components=incident_data["affected_components"],
                status=incident_data["status"],
                resolved_at=datetime.fromisoformat(incident_data["resolved_at"]) if incident_data.get("resolved_at") else None
            ))
        
        # Generate analysis for historical date
        total = summary["total_incidents"]
        analysis = f"Historical summary for {date}: {total} incidents recorded."
        
        return DailyIncidentSummaryResponse(
            date=summary["date"],
            total_incidents=total,
            incidents_by_severity=summary["incidents_by_severity"],
            incidents_by_type=summary["incidents_by_type"],
            incidents=incidents,
            summary_analysis=analysis
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get incident summary for {date}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve incident summary: {str(e)}"
        )

# =============================================================================
# Self-Healing Action Endpoints
# =============================================================================

@router.get("/actions/playbooks", response_model=PlaybookListResponse)
async def list_available_playbooks():
    """
    Get list of all available self-healing playbooks.
    """
    try:
        logger.info("📋 Listing available playbooks")
        
        playbooks = playbook_registry.get_playbook_list()
        
        return PlaybookListResponse(
            playbooks=playbooks,
            total_count=len(playbooks)
        )
        
    except Exception as e:
        logger.error(f"Failed to list playbooks: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve playbook list: {str(e)}"
        )

@router.post("/actions/run/{playbook_name}", response_model=PlaybookExecutionResponse)
async def execute_playbook(
    playbook_name: str,
    background_tasks: BackgroundTasks,
    request: Optional[TriggerPlaybookRequest] = None
):
    """
    Execute a self-healing playbook by name.
    Supports background execution for long-running playbooks.
    """
    try:
        logger.info(f"🔧 Executing playbook: {playbook_name}")
        
        # Prepare execution context
        context = {
            'trigger': PlaybookTrigger.MANUAL,
            'incident_id': request.incident_id if request else None,
            'triggered_at': datetime.now().isoformat()
        }
        
        if request and request.context:
            context.update(request.context)
        
        # Execute playbook
        execution = await playbook_registry.execute_playbook(playbook_name, context)
        
        # Convert to response format
        return PlaybookExecutionResponse(
            execution_id=execution.execution_id,
            playbook_name=execution.playbook_name,
            status=execution.status.value,
            started_at=execution.started_at,
            completed_at=execution.completed_at,
            steps_completed=execution.steps_completed,
            total_steps=execution.total_steps,
            output_log=execution.output_log,
            error_message=execution.error_message
        )
        
    except ValueError as e:
        logger.error(f"Invalid playbook name: {playbook_name}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to execute playbook {playbook_name}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Playbook execution failed: {str(e)}"
        )

@router.get("/actions/executions", response_model=List[PlaybookExecutionResponse])
async def get_playbook_execution_history(limit: int = Query(50, ge=1, le=200)):
    """
    Get recent playbook execution history.
    """
    try:
        logger.info(f"📜 Getting playbook execution history (limit: {limit})")
        
        executions = playbook_registry.get_execution_history(limit)
        
        # Convert to response format
        return [
            PlaybookExecutionResponse(
                execution_id=execution.execution_id,
                playbook_name=execution.playbook_name,
                status=execution.status.value,
                started_at=execution.started_at,
                completed_at=execution.completed_at,
                steps_completed=execution.steps_completed,
                total_steps=execution.total_steps,
                output_log=execution.output_log,
                error_message=execution.error_message
            )
            for execution in executions
        ]
        
    except Exception as e:
        logger.error(f"Failed to get execution history: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve execution history: {str(e)}"
        )

# =============================================================================
# Real-time Log Monitoring Endpoints
# =============================================================================

@router.post("/monitor/scan-logs")
async def trigger_log_scan(background_tasks: BackgroundTasks):
    """
    Trigger manual log scanning for incident detection.
    Useful for immediate analysis after suspected issues.
    """
    try:
        logger.info("🔍 Triggering manual log scan")
        
        # Add background task for log scanning
        background_tasks.add_task(scan_logs_for_incidents)
        
        return {
            "message": "Log scanning initiated",
            "status": "running",
            "estimated_completion": (datetime.now() + timedelta(minutes=2)).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to trigger log scan: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Log scan failed: {str(e)}"
        )

@router.get("/monitor/status")
async def get_monitoring_status():
    """
    Get current monitoring system status and metrics.
    """
    try:
        logger.info("📊 Getting monitoring status")
        
        # Get recent incidents
        recent_incidents = len([
            incident for incident in aiops_monitor.incidents.values()
            if incident.last_seen > datetime.now() - timedelta(hours=24)
        ])
        
        # Get buffer status
        buffer_size = len(aiops_monitor.log_buffer)
        buffer_capacity = aiops_monitor.log_buffer.maxlen
        
        # Get playbook execution stats
        recent_executions = playbook_registry.get_execution_history(20)
        successful_executions = len([e for e in recent_executions if e.status == PlaybookStatus.SUCCESS])
        
        return {
            "monitoring_active": True,
            "log_buffer_size": buffer_size,
            "log_buffer_capacity": buffer_capacity,
            "incidents_last_24h": recent_incidents,
            "playbooks_available": len(playbook_registry.playbooks),
            "recent_playbook_executions": len(recent_executions),
            "successful_playbook_rate": successful_executions / max(1, len(recent_executions)),
            "thresholds": aiops_monitor.thresholds,
            "last_update": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get monitoring status: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve monitoring status: {str(e)}"
        )

# =============================================================================
# Auto-remediation Endpoints
# =============================================================================

@router.post("/auto-remediate/{incident_id}")
async def auto_remediate_incident(incident_id: str, background_tasks: BackgroundTasks):
    """
    Automatically remediate a specific incident using appropriate playbooks.
    """
    try:
        logger.info(f"🤖 Auto-remediating incident: {incident_id}")
        
        # Find the incident
        incident = aiops_monitor.incidents.get(incident_id)
        if not incident:
            raise HTTPException(status_code=404, detail=f"Incident {incident_id} not found")
        
        # Determine appropriate playbook based on incident type
        playbook_map = {
            IncidentType.APP_CRASH: "restart_app",
            IncidentType.HIGH_ERROR_RATE: "system_health_check",
            IncidentType.HIGH_LATENCY: "warm_caches",
            IncidentType.DISK_FULL: "rotate_logs",
            IncidentType.CERT_EXPIRED: "reload_nginx",
            IncidentType.NGINX_DOWN: "reload_nginx"
        }
        
        playbook_name = playbook_map.get(incident.incident_type)
        if not playbook_name:
            return {
                "message": f"No auto-remediation playbook available for {incident.incident_type.value}",
                "incident_id": incident_id,
                "requires_manual_intervention": True
            }
        
        # Execute remediation playbook
        context = {
            'trigger': PlaybookTrigger.INCIDENT,
            'incident_id': incident_id,
            'incident_type': incident.incident_type.value,
            'severity': incident.severity.value
        }
        
        execution = await playbook_registry.execute_playbook(playbook_name, context)
        
        # Update incident with remediation info
        if execution.status == PlaybookStatus.SUCCESS:
            incident.remediation_taken.append(f"Auto-remediated with playbook: {playbook_name}")
            incident.status = "auto_remediated"
        else:
            incident.remediation_taken.append(f"Auto-remediation failed: {execution.error_message}")
        
        return {
            "message": f"Auto-remediation {'successful' if execution.status == PlaybookStatus.SUCCESS else 'failed'}",
            "incident_id": incident_id,
            "playbook_executed": playbook_name,
            "execution_id": execution.execution_id,
            "status": execution.status.value,
            "steps_completed": execution.steps_completed
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Auto-remediation failed for incident {incident_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Auto-remediation failed: {str(e)}"
        )

# =============================================================================
# Background Tasks
# =============================================================================

async def scan_logs_for_incidents():
    """Background task for scanning logs and detecting incidents"""
    try:
        logger.info("🔍 Starting background log scan")
        
        # Common log file locations
        log_files = [
            "/var/log/nginx/access.log",
            "/var/log/nginx/error.log", 
            "logs/app.log",
            "logs/chatterfix.log",
            "/tmp/app.log"
        ]
        
        all_incidents = []
        
        for log_file in log_files:
            if os.path.exists(log_file):
                logger.info(f"Scanning log file: {log_file}")
                source = "nginx" if "nginx" in log_file else "app"
                incidents = aiops_monitor.process_log_file(log_file, source)
                all_incidents.extend(incidents)
        
        # Also check system metrics
        system_incidents = aiops_monitor.monitor_system_metrics()
        all_incidents.extend(system_incidents)
        
        # Update incident registry
        for incident in all_incidents:
            aiops_monitor.incidents[incident.incident_id] = incident
        
        # Generate daily summary if we have incidents
        if all_incidents:
            summary_file = aiops_monitor.save_incident_summary(datetime.now(), all_incidents)
            logger.info(f"📄 Generated incident summary: {summary_file}")
        
        logger.info(f"✅ Background log scan completed: {len(all_incidents)} incidents detected")
        
    except Exception as e:
        logger.error(f"Background log scan failed: {e}")

# Export router
__all__ = ["router"]