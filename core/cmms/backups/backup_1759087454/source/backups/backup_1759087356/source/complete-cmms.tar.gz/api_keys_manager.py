#!/usr/bin/env python3
"""
API Keys Manager - Secure user-provided API key management
Handles storage, validation, and management of user API keys for various AI providers
"""

import os
import json
import logging
from typing import Dict, Any, Optional
from fastapi import APIRouter, Request, Form, HTTPException, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import sqlite3
from datetime import datetime
import hashlib
import base64
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

# API Keys router
api_keys_router = APIRouter(prefix="/api/keys", tags=["api-keys"])
settings_router = APIRouter(prefix="/settings", tags=["settings"])

class APIKeysManager:
    """Secure API keys management system"""
    
    def __init__(self, db_path: str = "cmms.db"):
        self.db_path = db_path
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher = Fernet(self.encryption_key)
        self._init_db()
    
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key for securing API keys"""
        key_file = "api_keys.key"
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            return key
    
    def _init_db(self):
        """Initialize API keys database table"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT DEFAULT 'default',
                provider TEXT NOT NULL,
                encrypted_key TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                UNIQUE(user_id, provider)
            )
        ''')
        conn.commit()
        conn.close()
    
    def store_api_key(self, provider: str, api_key: str, user_id: str = "default") -> bool:
        """Store encrypted API key for a provider"""
        try:
            encrypted_key = self.cipher.encrypt(api_key.encode()).decode()
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO api_keys 
                (user_id, provider, encrypted_key, updated_at) 
                VALUES (?, ?, ?, ?)
            ''', (user_id, provider, encrypted_key, datetime.utcnow().isoformat()))
            conn.commit()
            conn.close()
            
            logger.info(f"API key stored for provider: {provider}")
            return True
        except Exception as e:
            logger.error(f"Error storing API key for {provider}: {e}")
            return False
    
    def get_api_key(self, provider: str, user_id: str = "default") -> Optional[str]:
        """Retrieve decrypted API key for a provider"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT encrypted_key FROM api_keys 
                WHERE user_id = ? AND provider = ? AND is_active = 1
            ''', (user_id, provider))
            result = cursor.fetchone()
            conn.close()
            
            if result:
                encrypted_key = result[0].encode()
                decrypted_key = self.cipher.decrypt(encrypted_key).decode()
                return decrypted_key
            return None
        except Exception as e:
            logger.error(f"Error retrieving API key for {provider}: {e}")
            return None
    
    def list_providers(self, user_id: str = "default") -> Dict[str, bool]:
        """List all providers and their key status"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT provider, is_active FROM api_keys 
                WHERE user_id = ?
            ''', (user_id,))
            results = cursor.fetchall()
            conn.close()
            
            providers = {
                'openai': False,
                'anthropic': False,
                'groq': False,
                'grok': False,
                'google': False,
                'cohere': False,
                'huggingface': False,
                'custom': False
            }
            
            for provider, is_active in results:
                providers[provider] = bool(is_active)
            
            return providers
        except Exception as e:
            logger.error(f"Error listing providers: {e}")
            return {}
    
    def delete_api_key(self, provider: str, user_id: str = "default") -> bool:
        """Delete API key for a provider"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE api_keys SET is_active = 0 
                WHERE user_id = ? AND provider = ?
            ''', (user_id, provider))
            conn.commit()
            conn.close()
            
            logger.info(f"API key deleted for provider: {provider}")
            return True
        except Exception as e:
            logger.error(f"Error deleting API key for {provider}: {e}")
            return False

# Global instance
keys_manager = APIKeysManager()

@settings_router.get("/ai-providers")
async def ai_providers_settings(request: Request):
    """AI Providers settings page - Comprehensive AI platform management"""
    providers_status = keys_manager.list_providers()
    
    # Define all major AI providers with enhanced details
    major_providers = [
        {"id": "openai", "name": "🔮 OpenAI", "description": "GPT-4, GPT-4o, GPT-3.5-Turbo", "placeholder": "sk-proj-..."},
        {"id": "anthropic", "name": "🧠 Anthropic Claude", "description": "Claude 3.5 Sonnet, Claude 3 Opus, Claude 3 Haiku", "placeholder": "sk-ant-..."},
        {"id": "google", "name": "🌟 Google Gemini", "description": "Gemini Pro, Gemini Flash, Gemini Ultra", "placeholder": "AI..."},
        {"id": "grok", "name": "🚀 Grok (X.AI)", "description": "Grok-1, Grok-1.5, Real-time data", "placeholder": "xai-..."},
        {"id": "groq", "name": "⚡ Groq", "description": "LLaMA 3.1, Mixtral 8x7B, Ultra-fast inference", "placeholder": "gsk_..."},
        {"id": "cohere", "name": "🎯 Cohere", "description": "Command R+, Command, Enterprise AI", "placeholder": "co-..."},
        {"id": "mistral", "name": "🌊 Mistral AI", "description": "Mistral Large, Mixtral 8x22B, Code", "placeholder": "..."},
        {"id": "meta", "name": "🦙 Meta LLaMA", "description": "LLaMA 3.1 405B, 70B, 8B models", "placeholder": "llama-..."},
        {"id": "perplexity", "name": "🔍 Perplexity", "description": "pplx-7b-online, pplx-70b-online", "placeholder": "pplx-..."},
        {"id": "huggingface", "name": "🤗 HuggingFace", "description": "Inference API, Transformers, Open models", "placeholder": "hf_..."},
        {"id": "together", "name": "🤝 Together AI", "description": "LLaMA, Mistral, Code Llama hosting", "placeholder": "..."},
        {"id": "replicate", "name": "🔄 Replicate", "description": "Open source models, Fine-tuning", "placeholder": "r8_..."},
        {"id": "ollama", "name": "🏠 Ollama (Local)", "description": "Local model serving, No API key needed", "placeholder": "http://localhost:11434"}
    ]
    
    # Build the complete HTML content
    html_content = """
    <!DOCTYPE html>
    <html lang="en" data-theme="dark">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - AI Provider Management</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
                min-height: 100vh;
                color: white;
                padding: 2rem;
            }
            .settings-container { max-width: 1400px; margin: 0 auto; }
            .header { text-align: center; margin-bottom: 3rem; }
            .header h1 { font-size: 2.8rem; margin-bottom: 1rem; color: #00d4ff; text-shadow: 0 0 20px rgba(0,212,255,0.3); }
            .header p { font-size: 1.2rem; opacity: 0.8; margin-bottom: 2rem; }
            
            .tabs-container { margin-bottom: 2rem; }
            .tabs { display: flex; gap: 1rem; margin-bottom: 2rem; justify-content: center; }
            .tab { 
                padding: 1rem 2rem; 
                border-radius: 12px; 
                background: rgba(255,255,255,0.1); 
                border: 1px solid rgba(255,255,255,0.2);
                cursor: pointer; 
                transition: all 0.3s ease;
                backdrop-filter: blur(10px);
            }
            .tab.active { background: rgba(0,212,255,0.2); border-color: #00d4ff; }
            .tab:hover { background: rgba(255,255,255,0.15); }
            
            .tab-content { display: none; }
            .tab-content.active { display: block; }
            
            .providers-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 1.5rem; }
            .provider-card { 
                background: rgba(255,255,255,0.08);
                backdrop-filter: blur(15px);
                border-radius: 20px;
                padding: 2rem;
                border: 1px solid rgba(255,255,255,0.15);
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }
            .provider-card:hover { 
                transform: translateY(-5px); 
                border-color: #00d4ff; 
                box-shadow: 0 10px 30px rgba(0,212,255,0.2);
            }
            .provider-card::before { 
                content: ''; 
                position: absolute; 
                top: 0; left: 0; right: 0; 
                height: 4px; 
                background: linear-gradient(90deg, #00d4ff, #0099cc);
                opacity: 0; transition: opacity 0.3s ease;
            }
            .provider-card.active::before { opacity: 1; }
            
            .provider-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem; }
            .provider-info h3 { font-size: 1.4rem; margin-bottom: 0.5rem; }
            .provider-info .description { font-size: 0.9rem; opacity: 0.7; line-height: 1.4; }
            
            .provider-status { 
                padding: 0.5rem 1rem; border-radius: 25px; font-size: 0.8rem; font-weight: bold;
                display: flex; align-items: center; gap: 0.5rem;
            }
            .status-active { background: rgba(56,239,125,0.2); color: #38ef7d; border: 1px solid #38ef7d; }
            .status-inactive { background: rgba(231,76,60,0.2); color: #e74c3c; border: 1px solid #e74c3c; }
            
            .api-key-input { 
                width: 100%; padding: 1rem; margin: 0.8rem 0; border-radius: 12px;
                border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05);
                color: white; font-family: 'SF Mono', Monaco, monospace; font-size: 0.9rem;
                transition: all 0.3s ease;
            }
            .api-key-input:focus { 
                border-color: #00d4ff; outline: none; 
                box-shadow: 0 0 0 3px rgba(0,212,255,0.1);
            }
            
            .provider-actions { display: flex; gap: 0.8rem; margin-top: 1.5rem; flex-wrap: wrap; }
            .action-btn { 
                padding: 0.8rem 1.2rem; border-radius: 10px; border: none; cursor: pointer;
                font-size: 0.9rem; font-weight: 600; transition: all 0.3s ease;
                display: flex; align-items: center; gap: 0.5rem;
            }
            .btn-save { background: rgba(56,239,125,0.2); color: #38ef7d; border: 1px solid #38ef7d; }
            .btn-save:hover { background: rgba(56,239,125,0.3); transform: translateY(-2px); }
            .btn-delete { background: rgba(231,76,60,0.2); color: #e74c3c; border: 1px solid #e74c3c; }
            .btn-delete:hover { background: rgba(231,76,60,0.3); transform: translateY(-2px); }
            .btn-test { background: rgba(52,152,219,0.2); color: #3498db; border: 1px solid #3498db; }
            .btn-test:hover { background: rgba(52,152,219,0.3); transform: translateY(-2px); }
            
            .connectors-section { margin-top: 3rem; }
            .connector-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 1.5rem; }
            .connector-card { 
                background: rgba(156,39,176,0.1); border: 1px solid rgba(156,39,176,0.3);
                border-radius: 15px; padding: 2rem;
            }
            
            .settings-section { margin-top: 3rem; }
            .settings-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; }
            .setting-card { 
                background: rgba(255,193,7,0.1); border: 1px solid rgba(255,193,7,0.3);
                border-radius: 15px; padding: 2rem;
            }
            
            .back-btn { 
                margin-top: 3rem; text-align: center;
                background: rgba(52,152,219,0.2); color: #3498db; border: 1px solid #3498db;
                padding: 1rem 2rem; border-radius: 12px; text-decoration: none;
                display: inline-flex; align-items: center; gap: 0.5rem;
                transition: all 0.3s ease;
            }
            .back-btn:hover { background: rgba(52,152,219,0.3); transform: translateY(-2px); }
        </style>
    </head>
    <body>
        <div class="settings-container">
            <div class="header">
                <h1>🤖 AI Provider Management</h1>
                <p>Configure AI models, API keys, custom connectors, and advanced settings. All keys are encrypted and stored securely.</p>
            </div>
            
            <div class="tabs-container">
                <div class="tabs">
                    <div class="tab active" onclick="switchTab('providers')">🔮 AI Providers</div>
                    <div class="tab" onclick="switchTab('connectors')">🔌 Custom Connectors</div>
                    <div class="tab" onclick="switchTab('settings')">⚙️ Advanced Settings</div>
                </div>
            </div>
            
            <!-- AI Providers Tab -->
            <div id="providers-tab" class="tab-content active">
                <div class="providers-grid">
    """
    
    # Generate provider cards
    for provider in major_providers:
        is_active = providers_status.get(provider['id'], False)
        status_class = 'status-active' if is_active else 'status-inactive'
        status_text = '✅ Active' if is_active else '❌ Inactive'
        card_class = 'provider-card active' if is_active else 'provider-card'
        masked_value = '••••••••••••••••••••••••••••••••' if is_active else ''
        
        html_content += f"""
                    <div class="{card_class}">
                        <div class="provider-header">
                            <div class="provider-info">
                                <h3>{provider['name']}</h3>
                                <div class="description">{provider['description']}</div>
                            </div>
                            <span class="provider-status {status_class}">{status_text}</span>
                        </div>
                        <input type="password" class="api-key-input" id="{provider['id']}-key" 
                               placeholder="{provider['placeholder']}" value="{masked_value}">
                        <div class="provider-actions">
                            <button class="action-btn btn-save" onclick="saveApiKey('{provider['id']}')">💾 Save</button>
                            <button class="action-btn btn-test" onclick="testProvider('{provider['id']}')">🧪 Test</button>
                            <button class="action-btn btn-delete" onclick="deleteApiKey('{provider['id']}')">🗑️ Delete</button>
                        </div>
                    </div>"""
    
    html_content += """
                </div>
            </div>
            
            <!-- Custom Connectors Tab -->
            <div id="connectors-tab" class="tab-content">
                <div class="connectors-section">
                    <h2 style="margin-bottom: 2rem; color: #9c27b0;">🔌 Custom Connectors</h2>
                    <div class="connector-grid">
                        
                        <div class="connector-card">
                            <h3>🌐 Webhook Connector</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Connect to external APIs via webhooks</p>
                            <input type="url" class="api-key-input" id="webhook-url" placeholder="https://api.yourservice.com/webhook">
                            <input type="password" class="api-key-input" id="webhook-secret" placeholder="Webhook secret">
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveConnector('webhook')">💾 Save</button>
                                <button class="action-btn btn-test" onclick="testConnector('webhook')">🧪 Test</button>
                            </div>
                        </div>
                        
                        <div class="connector-card">
                            <h3>🗃️ Database Connector</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Connect to SQL/NoSQL databases</p>
                            <select class="api-key-input" id="db-type">
                                <option value="postgresql">PostgreSQL</option>
                                <option value="mysql">MySQL</option>
                                <option value="mongodb">MongoDB</option>
                                <option value="redis">Redis</option>
                            </select>
                            <input type="text" class="api-key-input" id="db-connection" placeholder="Connection string">
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveConnector('database')">💾 Save</button>
                                <button class="action-btn btn-test" onclick="testConnector('database')">🧪 Test</button>
                            </div>
                        </div>
                        
                        <div class="connector-card">
                            <h3>☁️ Cloud Storage</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Connect to cloud storage services</p>
                            <select class="api-key-input" id="cloud-type">
                                <option value="aws">AWS S3</option>
                                <option value="gcp">Google Cloud Storage</option>
                                <option value="azure">Azure Blob Storage</option>
                            </select>
                            <input type="password" class="api-key-input" id="cloud-credentials" placeholder="Access credentials">
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveConnector('cloud')">💾 Save</button>
                                <button class="action-btn btn-test" onclick="testConnector('cloud')">🧪 Test</button>
                            </div>
                        </div>
                        
                        <div class="connector-card">
                            <h3>📁 File System</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Connect to local/network file systems</p>
                            <input type="text" class="api-key-input" id="fs-path" placeholder="/path/to/directory">
                            <input type="text" class="api-key-input" id="fs-permissions" placeholder="File permissions (755)">
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveConnector('filesystem')">💾 Save</button>
                                <button class="action-btn btn-test" onclick="testConnector('filesystem')">🧪 Test</button>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
            <!-- Advanced Settings Tab -->
            <div id="settings-tab" class="tab-content">
                <div class="settings-section">
                    <h2 style="margin-bottom: 2rem; color: #ffc107;">⚙️ Advanced Settings</h2>
                    <div class="settings-grid">
                        
                        <div class="setting-card">
                            <h3>⚡ Rate Limiting</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Control API request rates</p>
                            <input type="number" class="api-key-input" id="rate-limit" placeholder="100" value="100">
                            <label style="opacity: 0.8;">Requests per minute</label>
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveSetting('rate_limit')">💾 Save</button>
                            </div>
                        </div>
                        
                        <div class="setting-card">
                            <h3>🔄 Fallback Providers</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Set backup AI providers</p>
                            <select class="api-key-input" id="primary-provider">
                                <option value="openai">OpenAI</option>
                                <option value="anthropic">Anthropic</option>
                                <option value="google">Google</option>
                            </select>
                            <select class="api-key-input" id="fallback-provider">
                                <option value="groq">Groq</option>
                                <option value="grok">Grok</option>
                                <option value="ollama">Ollama</option>
                            </select>
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveSetting('fallback')">💾 Save</button>
                            </div>
                        </div>
                        
                        <div class="setting-card">
                            <h3>⚖️ Load Balancing</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Distribute requests across providers</p>
                            <select class="api-key-input" id="load-strategy">
                                <option value="round_robin">Round Robin</option>
                                <option value="random">Random</option>
                                <option value="least_busy">Least Busy</option>
                            </select>
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveSetting('load_balancing')">💾 Save</button>
                            </div>
                        </div>
                        
                        <div class="setting-card">
                            <h3>⏱️ Timeout Settings</h3>
                            <p style="opacity: 0.8; margin-bottom: 1rem;">Request timeout configuration</p>
                            <input type="number" class="api-key-input" id="timeout-seconds" placeholder="30" value="30">
                            <label style="opacity: 0.8;">Timeout in seconds</label>
                            <div class="provider-actions">
                                <button class="action-btn btn-save" onclick="saveSetting('timeout')">💾 Save</button>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="/cmms/dashboard/main" class="back-btn">⬅️ Back to Dashboard</a>
            </div>
        </div>
        
        <script>
            function switchTab(tabName) {
                // Hide all tab contents
                document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
                document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
                
                // Show selected tab
                document.getElementById(tabName + '-tab').classList.add('active');
                event.target.classList.add('active');
            }
            
            async function saveApiKey(provider) {
                const keyInput = document.getElementById(provider + '-key');
                const apiKey = keyInput.value;
                
                if (!apiKey || apiKey === '••••••••••••••••••••••••••••••••') {
                    alert('Please enter a valid API key');
                    return;
                }
                
                try {
                    const response = await fetch('/api/keys/store', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({ provider: provider, api_key: apiKey })
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        alert('✅ API key saved successfully!');
                        location.reload();
                    } else {
                        alert('❌ Error: ' + result.error);
                    }
                } catch (error) {
                    alert('❌ Network error: ' + error.message);
                }
            }
            
            async function deleteApiKey(provider) {
                if (!confirm('Delete this API key?')) return;
                
                try {
                    const response = await fetch('/api/keys/delete', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({provider: provider})
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        alert('✅ API key deleted!');
                        location.reload();
                    } else {
                        alert('❌ Error: ' + result.error);
                    }
                } catch (error) {
                    alert('❌ Network error: ' + error.message);
                }
            }
            
            async function testProvider(provider) {
                try {
                    const response = await fetch('/api/keys/test', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            provider: provider,
                            test_message: 'Hello, this is a test from ChatterFix CMMS'
                        })
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        alert('✅ Test successful!\\n\\nResponse: ' + result.response.substring(0, 150) + '...');
                    } else {
                        alert('❌ Test failed: ' + result.error);
                    }
                } catch (error) {
                    alert('❌ Network error: ' + error.message);
                }
            }
            
            async function saveConnector(type) {
                alert('🚧 Custom connectors feature coming soon!\\n\\nThis will enable integration with external APIs, databases, and services.');
            }
            
            async function testConnector(type) {
                alert('🚧 Testing connectors feature coming soon!');
            }
            
            async function saveSetting(setting) {
                alert('🚧 Advanced settings feature coming soon!\\n\\nThis will enable fine-tuning of AI provider behavior.');
            }
        </script>
    </body>
    </html>
    """
    
    return HTMLResponse(html_content)

@api_keys_router.post("/store")
async def store_api_key(request: Request):
    """Store API key for a provider"""
    try:
        data = await request.json()
        provider = data.get("provider")
        api_key = data.get("api_key")
        
        if not provider or not api_key:
            return JSONResponse({"success": False, "error": "Provider and API key are required"})
        
        success = keys_manager.store_api_key(provider, api_key)
        return JSONResponse({"success": success})
    except Exception as e:
        logger.error(f"Error storing API key: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.post("/store-custom")
async def store_custom_provider(request: Request):
    """Store custom provider configuration"""
    try:
        data = await request.json()
        base_url = data.get("base_url")
        api_key = data.get("api_key")
        
        if not base_url or not api_key:
            return JSONResponse({"success": False, "error": "Base URL and API key are required"})
        
        # Store custom provider configuration
        success = keys_manager.store_api_key("custom", f"{base_url}|{api_key}")
        return JSONResponse({"success": success})
    except Exception as e:
        logger.error(f"Error storing custom provider: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.post("/delete")
async def delete_api_key(request: Request):
    """Delete API key for a provider"""
    try:
        data = await request.json()
        provider = data.get("provider")
        
        if not provider:
            return JSONResponse({"success": False, "error": "Provider is required"})
        
        success = keys_manager.delete_api_key(provider)
        return JSONResponse({"success": success})
    except Exception as e:
        logger.error(f"Error deleting API key: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.post("/test")
async def test_provider(request: Request):
    """Test API provider connection"""
    try:
        data = await request.json()
        provider = data.get("provider")
        test_message = data.get("test_message", "Hello, this is a test")
        
        if not provider:
            return JSONResponse({"success": False, "error": "Provider is required"})
        
        # This would integrate with the AI model provider to test the connection
        # For now, return a mock success response
        return JSONResponse({
            "success": True, 
            "response": f"Test successful for {provider} provider",
            "provider": provider
        })
    except Exception as e:
        logger.error(f"Error testing provider: {e}")
        return JSONResponse({"success": False, "error": str(e)})

@api_keys_router.get("/list")
async def list_providers():
    """List all providers and their status"""
    try:
        providers = keys_manager.list_providers()
        return JSONResponse({"success": True, "providers": providers})
    except Exception as e:
        logger.error(f"Error listing providers: {e}")
        return JSONResponse({"success": False, "error": str(e)})

def get_user_api_key(provider: str, user_id: str = "default") -> Optional[str]:
    """Helper function to get API key for a provider"""
    return keys_manager.get_api_key(provider, user_id)