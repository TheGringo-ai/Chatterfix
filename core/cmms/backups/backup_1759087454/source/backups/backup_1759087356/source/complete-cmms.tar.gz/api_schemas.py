#!/usr/bin/env python3
"""
CMMS API Schemas and Validation Models
Comprehensive Pydantic models for all CMMS modules with validation
"""

from typing import List, Dict, Any, Optional, Union, Literal
from pydantic import BaseModel, Field, validator, EmailStr
from datetime import datetime, date
from enum import Enum
import re

# =============================================================================
# Base Models and Enums
# =============================================================================

class UserRole(str, Enum):
    ADMIN = "admin"
    MANAGER = "manager" 
    TECHNICIAN = "technician"
    VIEWER = "viewer"

class PriorityLevel(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class StatusType(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class BaseResponse(BaseModel):
    success: bool = True
    message: str = "Operation completed successfully"
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ErrorResponse(BaseModel):
    success: bool = False
    error: str
    detail: Optional[str] = None
    error_code: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class PaginationParams(BaseModel):
    page: int = Field(1, ge=1, description="Page number")
    limit: int = Field(50, ge=1, le=1000, description="Items per page")
    sort_by: Optional[str] = Field(None, description="Field to sort by")
    sort_order: Literal["asc", "desc"] = "asc"

class BulkResponse(BaseModel):
    processed: int
    successful: int
    failed: int
    errors: List[Dict[str, Any]] = []

# =============================================================================
# Work Orders Module Schemas
# =============================================================================

class WorkOrderType(str, Enum):
    REACTIVE = "reactive"
    PREVENTIVE = "preventive"
    PREDICTIVE = "predictive"
    EMERGENCY = "emergency"

class WorkOrderStatus(str, Enum):
    OPEN = "open"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    PARTS_REQUIRED = "parts_required"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    CLOSED = "closed"
    CANCELLED = "cancelled"

class WorkOrderCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=200, description="Work order title")
    description: str = Field(..., min_length=10, max_length=2000, description="Detailed description")
    asset_id: str = Field(..., pattern=r"^[A-Z]+-\d+$", description="Asset ID (format: ABC-123)")
    type: WorkOrderType
    priority: PriorityLevel
    assigned_to: Optional[str] = Field(None, description="Technician ID")
    due_date: Optional[date] = None
    estimated_hours: Optional[float] = Field(None, ge=0, le=1000)
    estimated_cost: Optional[float] = Field(None, ge=0)
    location: Optional[str] = Field(None, max_length=200)
    safety_requirements: Optional[str] = Field(None, max_length=1000)

class WorkOrderUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=200)
    description: Optional[str] = Field(None, min_length=10, max_length=2000)
    type: Optional[WorkOrderType] = None
    priority: Optional[PriorityLevel] = None
    status: Optional[WorkOrderStatus] = None
    assigned_to: Optional[str] = None
    due_date: Optional[date] = None
    estimated_hours: Optional[float] = Field(None, ge=0, le=1000)
    estimated_cost: Optional[float] = Field(None, ge=0)
    actual_hours: Optional[float] = Field(None, ge=0, le=1000)
    actual_cost: Optional[float] = Field(None, ge=0)
    completion_notes: Optional[str] = Field(None, max_length=2000)

class WorkOrderResponse(BaseModel):
    id: str
    title: str
    description: str
    asset_id: str
    type: WorkOrderType
    priority: PriorityLevel
    status: WorkOrderStatus
    created_date: datetime
    created_by: str
    assigned_to: Optional[str] = None
    due_date: Optional[date] = None
    completed_date: Optional[datetime] = None
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    estimated_cost: Optional[float] = None
    actual_cost: Optional[float] = None
    location: Optional[str] = None
    safety_requirements: Optional[str] = None
    completion_notes: Optional[str] = None
    comments_count: int = 0

class WorkOrderComment(BaseModel):
    id: str
    work_order_id: str
    author: str
    author_name: str
    timestamp: datetime
    comment: str = Field(..., min_length=1, max_length=2000)
    attachments: List[str] = []
    is_internal: bool = False

class WorkOrderBulkAssign(BaseModel):
    work_order_ids: List[str] = Field(..., min_items=1, max_items=100)
    assigned_to: str = Field(..., description="Technician ID to assign to")
    priority: Optional[PriorityLevel] = None
    due_date: Optional[date] = None

# =============================================================================
# Assets Module Schemas  
# =============================================================================

class AssetCategory(str, Enum):
    MECHANICAL = "mechanical"
    ELECTRICAL = "electrical"
    HVAC = "hvac"
    PLUMBING = "plumbing"
    SAFETY = "safety"
    IT = "it"
    VEHICLE = "vehicle"
    BUILDING = "building"

class AssetStatus(str, Enum):
    OPERATIONAL = "operational"
    MAINTENANCE = "maintenance"
    DOWN = "down"
    RETIRED = "retired"
    DISPOSED = "disposed"

class AssetCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=200, description="Asset name")
    asset_id: str = Field(..., pattern=r"^[A-Z]+-\d+$", description="Asset ID (format: ABC-123)")
    description: Optional[str] = Field(None, max_length=2000)
    category: AssetCategory
    location: str = Field(..., min_length=3, max_length=200, description="Asset location")
    status: AssetStatus = AssetStatus.OPERATIONAL
    criticality: PriorityLevel = PriorityLevel.MEDIUM
    manufacturer: Optional[str] = Field(None, max_length=100)
    model: Optional[str] = Field(None, max_length=100)
    serial_number: Optional[str] = Field(None, max_length=100)
    installation_date: Optional[date] = None
    warranty_expiry: Optional[date] = None
    maintenance_frequency: int = Field(30, ge=1, le=365, description="Days between maintenance")
    purchase_cost: Optional[float] = Field(None, ge=0)
    supplier: Optional[str] = Field(None, max_length=200)

    @validator('asset_id')
    def asset_id_must_be_unique_format(cls, v):
        if not re.match(r'^[A-Z]+-\d+$', v):
            raise ValueError('Asset ID must be in format ABC-123')
        return v.upper()

class AssetUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    category: Optional[AssetCategory] = None
    location: Optional[str] = Field(None, min_length=3, max_length=200)
    status: Optional[AssetStatus] = None
    criticality: Optional[PriorityLevel] = None
    manufacturer: Optional[str] = Field(None, max_length=100)
    model: Optional[str] = Field(None, max_length=100)
    serial_number: Optional[str] = Field(None, max_length=100)
    warranty_expiry: Optional[date] = None
    maintenance_frequency: Optional[int] = Field(None, ge=1, le=365)
    purchase_cost: Optional[float] = Field(None, ge=0)
    supplier: Optional[str] = Field(None, max_length=200)

class AssetResponse(BaseModel):
    id: str
    name: str
    asset_id: str
    description: Optional[str] = None
    category: AssetCategory
    location: str
    status: AssetStatus
    criticality: PriorityLevel
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    serial_number: Optional[str] = None
    installation_date: Optional[date] = None
    warranty_expiry: Optional[date] = None
    maintenance_frequency: int
    purchase_cost: Optional[float] = None
    supplier: Optional[str] = None
    created_date: datetime
    updated_date: datetime
    work_orders_count: int = 0
    last_maintenance: Optional[datetime] = None
    next_maintenance: Optional[date] = None

class AssetMaintenanceRecord(BaseModel):
    id: str
    asset_id: str
    work_order_id: Optional[str] = None
    maintenance_type: Literal["preventive", "corrective", "inspection"]
    performed_by: str
    performed_date: datetime
    description: str
    cost: Optional[float] = None
    parts_used: List[str] = []
    next_due_date: Optional[date] = None

# =============================================================================
# Asset Dashboard Module Schemas
# =============================================================================

class AssetKPIResponse(BaseModel):
    mtbf_hours: float = Field(..., description="Mean Time Between Failures in hours")
    mttr_hours: float = Field(..., description="Mean Time To Repair in hours") 
    pm_compliance_pct: float = Field(..., ge=0, le=100, description="PM compliance percentage")
    backlog_days: float = Field(..., ge=0, description="Work order backlog in days")
    uptime_pct: float = Field(..., ge=0, le=100, description="Asset uptime percentage")
    total_cost_ytd: float = Field(..., ge=0, description="Total maintenance cost year-to-date")
    failure_count_ytd: int = Field(..., ge=0, description="Number of failures year-to-date")
    window_start: str = Field(..., description="Start date of calculation window")
    window_end: str = Field(..., description="End date of calculation window")

class AssetHistoryEvent(BaseModel):
    id: str
    asset_id: str
    event_type: Literal["failure", "repair", "pm", "inspection", "part_change"]
    timestamp: datetime
    description: str
    technician: Optional[str] = None
    duration_hours: Optional[float] = Field(None, ge=0)
    cost: Optional[float] = Field(None, ge=0)
    parts_used: List[str] = []
    work_order_id: Optional[str] = None

class DocumentReference(BaseModel):
    id: str
    name: str
    type: str  # manual, schematic, parts_list, etc.
    url: str
    asset_id: str
    upload_date: datetime
    file_size: Optional[int] = None

class PartInventoryStatus(BaseModel):
    part_id: str
    name: str
    current_stock: int
    min_stock: int
    status: Literal["in_stock", "low_stock", "out_of_stock"]
    cost_per_unit: float

class AssetDashboardResponse(BaseModel):
    asset: AssetResponse
    kpis: AssetKPIResponse
    history: List[AssetHistoryEvent] = []
    upcoming_pms: List[Dict[str, Any]] = []  # PM schedules
    current_work_orders: List[Dict[str, Any]] = []
    documents: List[DocumentReference] = []
    inventory: List[PartInventoryStatus] = []

class AssetHistoryResponse(BaseModel):
    asset_id: str
    history: List[AssetHistoryEvent]
    total_count: int
    page: int = 1
    limit: int = 50

class PMCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=200)
    asset_id: str = Field(..., pattern=r"^[A-Z]+-\d+$")
    frequency_days: int = Field(..., ge=1, le=365)
    estimated_duration: float = Field(..., ge=0.1, le=100)
    priority: PriorityLevel = PriorityLevel.MEDIUM
    description: str = Field(..., min_length=10, max_length=2000)
    instructions: Optional[str] = Field(None, max_length=5000)
    required_parts: List[Dict[str, Any]] = []
    required_skills: List[str] = []
    safety_requirements: List[str] = []

class PMResponse(BaseModel):
    id: str
    name: str
    asset_id: str
    frequency_days: int
    estimated_duration: float
    priority: PriorityLevel
    description: str
    instructions: Optional[str] = None
    required_parts: List[Dict[str, Any]] = []
    required_skills: List[str] = []
    safety_requirements: List[str] = []
    last_completed: Optional[datetime] = None
    next_due: Optional[date] = None
    status: str
    created_date: datetime
    updated_date: datetime

# =============================================================================
# Parts Module Schemas
# =============================================================================

class PartCategory(str, Enum):
    BEARINGS = "bearings"
    BELTS = "belts"
    FILTERS = "filters"
    GASKETS = "gaskets"
    ELECTRICAL = "electrical"
    HYDRAULIC = "hydraulic"
    LUBRICANTS = "lubricants"
    FASTENERS = "fasteners"
    SEALS = "seals"
    OTHER = "other"

class PartCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=200, description="Part name")
    part_number: str = Field(..., min_length=3, max_length=50, description="Part number")
    description: Optional[str] = Field(None, max_length=1000)
    category: PartCategory
    manufacturer: Optional[str] = Field(None, max_length=100)
    manufacturer_part_number: Optional[str] = Field(None, max_length=50)
    supplier: Optional[str] = Field(None, max_length=200)
    supplier_part_number: Optional[str] = Field(None, max_length=50)
    unit_cost: float = Field(..., ge=0, description="Cost per unit")
    quantity: int = Field(..., ge=0, description="Current stock quantity")
    min_stock: int = Field(1, ge=0, description="Minimum stock level")
    max_stock: Optional[int] = Field(None, ge=0, description="Maximum stock level")
    location: Optional[str] = Field(None, max_length=200, description="Storage location")
    unit_of_measure: str = Field("each", max_length=20, description="Unit of measure")
    shelf_life_days: Optional[int] = Field(None, ge=0, description="Shelf life in days")
    is_active: bool = True

    @validator('part_number')
    def part_number_must_be_alphanumeric(cls, v):
        if not re.match(r'^[A-Z0-9\-_]+$', v.upper()):
            raise ValueError('Part number must contain only letters, numbers, hyphens, and underscores')
        return v.upper()

class PartUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    category: Optional[PartCategory] = None
    manufacturer: Optional[str] = Field(None, max_length=100)
    manufacturer_part_number: Optional[str] = Field(None, max_length=50)
    supplier: Optional[str] = Field(None, max_length=200)
    supplier_part_number: Optional[str] = Field(None, max_length=50)
    unit_cost: Optional[float] = Field(None, ge=0)
    min_stock: Optional[int] = Field(None, ge=0)
    max_stock: Optional[int] = Field(None, ge=0)
    location: Optional[str] = Field(None, max_length=200)
    shelf_life_days: Optional[int] = Field(None, ge=0)
    is_active: Optional[bool] = None

class PartResponse(BaseModel):
    id: str
    name: str
    part_number: str
    description: Optional[str] = None
    category: PartCategory
    manufacturer: Optional[str] = None
    manufacturer_part_number: Optional[str] = None
    supplier: Optional[str] = None
    supplier_part_number: Optional[str] = None
    unit_cost: float
    quantity: int
    min_stock: int
    max_stock: Optional[int] = None
    location: Optional[str] = None
    unit_of_measure: str
    shelf_life_days: Optional[int] = None
    is_active: bool
    created_date: datetime
    updated_date: datetime
    is_low_stock: bool = False
    last_issued: Optional[datetime] = None
    total_issued: int = 0

class StockAdjustment(BaseModel):
    part_id: str
    adjustment_type: Literal["receive", "issue", "transfer", "adjust", "return"]
    quantity: int = Field(..., description="Positive for increases, negative for decreases")
    reason: str = Field(..., min_length=3, max_length=500, description="Reason for adjustment")
    reference: Optional[str] = Field(None, max_length=100, description="Reference (WO#, PO#, etc.)")
    cost_per_unit: Optional[float] = Field(None, ge=0, description="Cost per unit for this transaction")
    performed_by: str = Field(..., description="User ID performing adjustment")

class StockTransaction(BaseModel):
    id: str
    part_id: str
    transaction_type: Literal["receive", "issue", "transfer", "adjust", "return"]
    quantity: int
    quantity_before: int
    quantity_after: int
    reason: str
    reference: Optional[str] = None
    cost_per_unit: Optional[float] = None
    total_cost: Optional[float] = None
    performed_by: str
    performed_date: datetime

# =============================================================================
# Preventive Maintenance Module Schemas
# =============================================================================

class PMStatus(str, Enum):
    SCHEDULED = "scheduled"
    DUE = "due"
    OVERDUE = "overdue"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"

class PMFrequency(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    SEMI_ANNUAL = "semi_annual"
    ANNUAL = "annual"
    CUSTOM = "custom"

class PMTaskCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=200, description="PM task title")
    description: str = Field(..., min_length=10, max_length=2000, description="Task description")
    asset_id: str = Field(..., pattern=r"^[A-Z]+-\d+$", description="Asset ID")
    frequency: PMFrequency
    frequency_days: Optional[int] = Field(None, ge=1, le=365, description="Custom frequency in days")
    priority: PriorityLevel = PriorityLevel.MEDIUM
    estimated_hours: Optional[float] = Field(None, ge=0, le=100)
    assigned_to: Optional[str] = Field(None, description="Default technician ID")
    instructions: Optional[str] = Field(None, max_length=5000, description="Detailed instructions")
    safety_requirements: Optional[str] = Field(None, max_length=1000)
    tools_required: List[str] = Field(default_factory=list, max_items=20)
    parts_required: List[str] = Field(default_factory=list, max_items=50, description="Part IDs")
    is_active: bool = True

    @validator('frequency_days')
    def validate_frequency_days(cls, v, values):
        if values.get('frequency') == PMFrequency.CUSTOM and v is None:
            raise ValueError('frequency_days required when frequency is custom')
        elif values.get('frequency') != PMFrequency.CUSTOM and v is not None:
            raise ValueError('frequency_days only allowed when frequency is custom')
        return v

class PMTaskUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=200)
    description: Optional[str] = Field(None, min_length=10, max_length=2000)
    frequency: Optional[PMFrequency] = None
    frequency_days: Optional[int] = Field(None, ge=1, le=365)
    priority: Optional[PriorityLevel] = None
    estimated_hours: Optional[float] = Field(None, ge=0, le=100)
    assigned_to: Optional[str] = None
    instructions: Optional[str] = Field(None, max_length=5000)
    safety_requirements: Optional[str] = Field(None, max_length=1000)
    tools_required: Optional[List[str]] = Field(None, max_items=20)
    parts_required: Optional[List[str]] = Field(None, max_items=50)
    is_active: Optional[bool] = None

class PMTaskResponse(BaseModel):
    id: str
    title: str
    description: str
    asset_id: str
    asset_name: str
    frequency: PMFrequency
    frequency_days: Optional[int] = None
    priority: PriorityLevel
    status: PMStatus
    estimated_hours: Optional[float] = None
    assigned_to: Optional[str] = None
    assigned_to_name: Optional[str] = None
    instructions: Optional[str] = None
    safety_requirements: Optional[str] = None
    tools_required: List[str] = []
    parts_required: List[str] = []
    is_active: bool
    created_date: datetime
    last_completed: Optional[datetime] = None
    next_due: Optional[date] = None
    completion_count: int = 0
    overdue_days: Optional[int] = None

class PMCompletion(BaseModel):
    pm_task_id: str
    completed_by: str
    completion_date: Optional[datetime] = Field(default_factory=datetime.utcnow)
    actual_hours: Optional[float] = Field(None, ge=0, le=100)
    completion_notes: str = Field(..., min_length=5, max_length=2000)
    parts_used: List[str] = Field(default_factory=list, description="Part IDs used")
    next_due_date: Optional[date] = None
    issues_found: Optional[str] = Field(None, max_length=2000, description="Issues discovered during PM")
    create_work_order: bool = False

# =============================================================================
# Technician Module Schemas
# =============================================================================

class TechnicianStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ON_LEAVE = "on_leave"
    TERMINATED = "terminated"

class ShiftType(str, Enum):
    FIRST = "first"    # 7AM-3PM
    SECOND = "second"  # 3PM-11PM  
    THIRD = "third"    # 11PM-7AM
    ROTATING = "rotating"
    ON_CALL = "on_call"

class TechnicianCreate(BaseModel):
    employee_id: str = Field(..., min_length=3, max_length=20, description="Employee ID")
    first_name: str = Field(..., min_length=2, max_length=50)
    last_name: str = Field(..., min_length=2, max_length=50) 
    email: EmailStr
    phone: Optional[str] = Field(None, pattern=r"^[\+]?[1-9][\d]{0,15}$")
    hire_date: date
    status: TechnicianStatus = TechnicianStatus.ACTIVE
    shift: ShiftType
    hourly_rate: Optional[float] = Field(None, ge=0, le=1000)
    skills: List[str] = Field(default_factory=list, max_items=20)
    certifications: List[str] = Field(default_factory=list, max_items=10)
    supervisor: Optional[str] = Field(None, description="Supervisor employee ID")
    emergency_contact_name: Optional[str] = Field(None, max_length=100)
    emergency_contact_phone: Optional[str] = Field(None, pattern=r"^[\+]?[1-9][\d]{0,15}$")

class TechnicianUpdate(BaseModel):
    first_name: Optional[str] = Field(None, min_length=2, max_length=50)
    last_name: Optional[str] = Field(None, min_length=2, max_length=50)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, pattern=r"^[\+]?[1-9][\d]{0,15}$")
    status: Optional[TechnicianStatus] = None
    shift: Optional[ShiftType] = None
    hourly_rate: Optional[float] = Field(None, ge=0, le=1000)
    skills: Optional[List[str]] = Field(None, max_items=20)
    certifications: Optional[List[str]] = Field(None, max_items=10)
    supervisor: Optional[str] = None
    emergency_contact_name: Optional[str] = Field(None, max_length=100)
    emergency_contact_phone: Optional[str] = Field(None, pattern=r"^[\+]?[1-9][\d]{0,15}$")

class TechnicianResponse(BaseModel):
    id: str
    employee_id: str
    first_name: str
    last_name: str
    full_name: str
    email: str
    phone: Optional[str] = None
    hire_date: date
    status: TechnicianStatus
    shift: ShiftType
    hourly_rate: Optional[float] = None
    skills: List[str] = []
    certifications: List[str] = []
    supervisor: Optional[str] = None
    supervisor_name: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    created_date: datetime
    updated_date: datetime
    active_work_orders: int = 0
    completed_work_orders: int = 0
    total_hours_logged: float = 0
    avg_completion_time: Optional[float] = None

class TimeEntry(BaseModel):
    technician_id: str
    work_order_id: Optional[str] = None
    pm_task_id: Optional[str] = None
    start_time: datetime
    end_time: Optional[datetime] = None
    hours: Optional[float] = Field(None, ge=0, le=24, description="Manual hours entry")
    activity_type: Literal["work_order", "preventive", "training", "other"]
    description: str = Field(..., min_length=3, max_length=500)
    break_time_minutes: Optional[int] = Field(None, ge=0, le=480, description="Break time in minutes")

    @validator('hours')
    def validate_hours_or_times(cls, v, values):
        start_time = values.get('start_time')
        end_time = values.get('end_time')
        
        if v is None and (start_time is None or end_time is None):
            raise ValueError('Either hours or start_time/end_time must be provided')
        
        if v is not None and end_time is not None:
            calculated_hours = (end_time - start_time).total_seconds() / 3600
            if abs(calculated_hours - v) > 0.1:  # Allow small differences
                raise ValueError('Manual hours entry does not match calculated time difference')
        
        return v

class TimeEntryResponse(BaseModel):
    id: str
    technician_id: str
    work_order_id: Optional[str] = None
    pm_task_id: Optional[str] = None
    start_time: datetime
    end_time: Optional[datetime] = None
    hours: float
    activity_type: str
    description: str
    break_time_minutes: Optional[int] = None
    created_at: datetime
    updated_at: datetime

class WorkNote(BaseModel):
    work_order_id: str
    author: str
    content: str = Field(..., min_length=1, max_length=2000)
    note_type: Literal["voice_transcription", "manual_text", "system_generated"] = "manual_text"
    audio_duration_seconds: Optional[float] = Field(None, ge=0, le=600, description="Audio duration for voice notes")
    confidence_score: Optional[float] = Field(None, ge=0, le=1, description="Transcription confidence for voice notes")
    
    @validator('content')
    def validate_content(cls, v):
        if not v.strip():
            raise ValueError('Note content cannot be empty')
        return v.strip()

class WorkNoteResponse(BaseModel):
    id: str
    work_order_id: str
    author: str
    content: str
    note_type: str
    audio_duration_seconds: Optional[float] = None
    confidence_score: Optional[float] = None
    created_at: datetime
    updated_at: datetime

class PhotoUpload(BaseModel):
    work_order_id: str
    caption: Optional[str] = Field(None, max_length=500)
    photo_type: Literal["before", "during", "after", "damage", "completion", "other"] = "other"
    gps_latitude: Optional[float] = Field(None, ge=-90, le=90)
    gps_longitude: Optional[float] = Field(None, ge=-180, le=180)
    
class PhotoUploadResponse(BaseModel):
    id: str
    work_order_id: str
    filename: str
    file_size_bytes: int
    mime_type: str
    caption: Optional[str] = None
    photo_type: str
    gps_latitude: Optional[float] = None
    gps_longitude: Optional[float] = None
    thumbnail_url: Optional[str] = None
    full_url: str
    uploaded_by: str
    created_at: datetime

class PartsCheckout(BaseModel):
    work_order_id: str
    technician_id: str
    parts: List[Dict[str, Any]] = Field(..., description="List of parts with part_id and quantity")
    checkout_notes: Optional[str] = Field(None, max_length=1000)
    
    @validator('parts')
    def validate_parts(cls, v):
        if not v:
            raise ValueError('At least one part must be specified')
        for part in v:
            if 'part_id' not in part or 'quantity' not in part:
                raise ValueError('Each part must have part_id and quantity')
            if not isinstance(part['quantity'], (int, float)) or part['quantity'] <= 0:
                raise ValueError('Part quantity must be positive')
        return v

class PartsCheckoutResponse(BaseModel):
    id: str
    work_order_id: str
    technician_id: str
    parts_checked_out: List[Dict[str, Any]]
    checkout_notes: Optional[str] = None
    total_value: float
    checkout_by: str
    checkout_at: datetime
    returned_at: Optional[datetime] = None

# =============================================================================
# Admin Module Schemas
# =============================================================================

class SystemUser(BaseModel):
    id: str
    username: str
    email: EmailStr
    first_name: str
    last_name: str
    full_name: str
    role: UserRole
    is_active: bool
    last_login: Optional[datetime] = None
    created_date: datetime
    updated_date: datetime

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_]+$")
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    first_name: str = Field(..., min_length=2, max_length=50)
    last_name: str = Field(..., min_length=2, max_length=50)
    role: UserRole
    is_active: bool = True

    @validator('password')
    def validate_password_strength(cls, v):
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'[0-9]', v):
            raise ValueError('Password must contain at least one digit')
        if not re.search(r'[!@#$%^&*(),.?\":{}|<>]', v):
            raise ValueError('Password must contain at least one special character')
        return v

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    first_name: Optional[str] = Field(None, min_length=2, max_length=50)
    last_name: Optional[str] = Field(None, min_length=2, max_length=50)
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None

class SystemConfig(BaseModel):
    company_name: str = Field(..., min_length=1, max_length=200)
    company_logo_url: Optional[str] = None
    timezone: str = Field("UTC", description="System timezone")
    date_format: str = Field("YYYY-MM-DD", description="Date display format")
    time_format: str = Field("HH:mm:ss", description="Time display format")
    currency: str = Field("USD", min_length=3, max_length=3)
    maintenance_window_start: str = Field("02:00", pattern=r"^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$")
    maintenance_window_end: str = Field("04:00", pattern=r"^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$")
    auto_assign_work_orders: bool = False
    email_notifications_enabled: bool = True
    sms_notifications_enabled: bool = False
    backup_retention_days: int = Field(30, ge=7, le=365)

class SystemStats(BaseModel):
    total_work_orders: int
    open_work_orders: int
    overdue_work_orders: int
    total_assets: int
    down_assets: int
    total_parts: int
    low_stock_parts: int
    total_technicians: int
    active_technicians: int
    uptime_percentage: float
    avg_response_time_ms: float
    disk_usage_percentage: float
    memory_usage_percentage: float
    cpu_usage_percentage: float

# =============================================================================
# Export and Bulk Operation Schemas
# =============================================================================

class ExportFormat(str, Enum):
    CSV = "csv"
    XLSX = "xlsx"
    PDF = "pdf"
    JSON = "json"

class ExportRequest(BaseModel):
    format: ExportFormat = ExportFormat.CSV
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    filters: Dict[str, Any] = Field(default_factory=dict)
    columns: Optional[List[str]] = None
    include_inactive: bool = False

class BulkDeleteRequest(BaseModel):
    ids: List[str] = Field(..., min_items=1, max_items=1000)
    force_delete: bool = False
    reason: Optional[str] = Field(None, max_length=500)

class AuditLogEntry(BaseModel):
    id: str
    user_id: str
    user_name: str
    action: str
    resource_type: str
    resource_id: str
    payload_hash: str
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    timestamp: datetime
    success: bool
    error_message: Optional[str] = None

# =============================================================================
# Work Order Dashboard Schemas (Phase 1)
# =============================================================================

class WorkOrderKPIs(BaseModel):
    open_count: int = Field(..., description="Number of open work orders")
    overdue_count: int = Field(..., description="Number of overdue work orders")
    high_priority_count: int = Field(..., description="Number of high priority work orders")
    average_age_days: float = Field(..., ge=0, description="Average age of open work orders in days")
    mttr_hours: float = Field(..., ge=0, description="Mean Time To Repair in hours")
    schedule_compliance_pct: float = Field(..., ge=0, le=100, description="Schedule compliance percentage")
    technician_utilization_pct: float = Field(..., ge=0, le=100, description="Technician utilization percentage")
    sla_breach_count: int = Field(..., ge=0, description="Number of SLA breaches")

class WorkOrderTabs(BaseModel):
    all: int = Field(..., description="Total work orders count")
    upcoming: int = Field(..., description="Upcoming work orders count") 
    past_due: int = Field(..., description="Past due work orders count")
    completed: int = Field(..., description="Completed work orders count")

class WorkOrderActivity(BaseModel):
    id: str
    work_order_id: str
    activity_type: Literal["created", "assigned", "started", "commented", "completed", "status_change"]
    description: str
    user: str
    timestamp: datetime

class TechnicianWorkload(BaseModel):
    technician_id: str
    technician_name: str
    active_work_orders: int
    estimated_hours: float
    actual_hours: float
    utilization_pct: float = Field(..., ge=0, le=100)

class WorkOrderDashboardResponse(BaseModel):
    kpis: WorkOrderKPIs
    tabs: WorkOrderTabs
    recent_activity: List[WorkOrderActivity] = []
    technician_workload: List[TechnicianWorkload] = []
    performance_trend: Dict[str, List[float]] = Field(default_factory=dict)

class ScheduledWorkOrder(BaseModel):
    id: str
    title: str
    asset_id: str
    assigned_to: Optional[str] = None
    assigned_to_name: Optional[str] = None
    scheduled_start: Optional[str] = None
    scheduled_end: Optional[str] = None
    estimated_hours: Optional[float] = None
    priority: str
    status: str
    color: str = "#4299e1"  # Default blue color

class ScheduleConflict(BaseModel):
    technician_id: str
    date: str
    overlapping_work_orders: List[str]
    total_hours: float
    message: str

class TechnicianAvailability(BaseModel):
    technician_id: str
    technician_name: str
    date: str
    available_hours: float
    scheduled_hours: float
    capacity_pct: float

class WorkOrderScheduleResponse(BaseModel):
    work_orders: List[ScheduledWorkOrder]
    conflicts: List[ScheduleConflict] = []
    availability: List[TechnicianAvailability] = []

class WorkOrderStatusUpdate(BaseModel):
    status: WorkOrderStatus
    notes: Optional[str] = Field(None, max_length=1000)
    actual_hours: Optional[float] = Field(None, ge=0)
    completion_date: Optional[datetime] = None

class BulkWorkOrderUpdate(BaseModel):
    work_order_ids: List[str] = Field(..., min_items=1, max_items=100)
    updates: WorkOrderUpdate
    reason: str = Field(..., min_length=5, max_length=500)

# =============================================================================
# List Response Schemas
# =============================================================================

class WorkOrderList(BaseModel):
    items: List[WorkOrderResponse]
    total: int
    page: int
    limit: int
    has_more: bool

class AssetList(BaseModel):
    items: List[AssetResponse]
    total: int
    page: int
    limit: int
    has_more: bool

class PartList(BaseModel):
    items: List[PartResponse]
    total: int
    page: int
    limit: int
    has_more: bool

class PMTaskList(BaseModel):
    items: List[PMTaskResponse]
    total: int
    page: int
    limit: int
    has_more: bool

class TechnicianList(BaseModel):
    items: List[TechnicianResponse]
    total: int
    page: int
    limit: int
    has_more: bool

# =============================================================================
# AI Assistance Schemas (Phase 3)
# =============================================================================

class AIIntentType(str, Enum):
    PLAN_WORK_ORDER = "plan_work_order"
    TROUBLESHOOT_ISSUE = "troubleshoot_issue" 
    IDENTIFY_PART_FROM_IMAGE = "identify_part_from_image"
    RESERVE_PARTS = "reserve_parts"
    ASSIGN_TECHNICIAN = "assign_technician"
    CHECK_CAPACITY = "check_capacity"
    SUMMARIZE_HISTORY = "summarize_history"

class AIIntentRequest(BaseModel):
    intent: AIIntentType
    context: Dict[str, Any] = Field(default_factory=dict, description="Context information for the AI request")
    constraints: Dict[str, Any] = Field(default_factory=dict, description="Constraints for the AI processing")
    work_order_id: Optional[str] = Field(None, description="Associated work order ID")
    user_id: str = Field(..., description="ID of the requesting user")

class AIAction(BaseModel):
    action_type: str = Field(..., description="Type of action to perform")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Parameters for the action")
    confirmation_required: bool = Field(False, description="Whether user confirmation is required")
    confidence: float = Field(..., ge=0, le=1, description="AI confidence in this action")

class Citation(BaseModel):
    document_id: str = Field(..., description="ID of the source document")
    filename: str = Field(..., description="Name of the source file")
    page_number: Optional[int] = Field(None, description="Page number in document")
    section_title: Optional[str] = Field(None, description="Section title if available")
    chunk_text: str = Field(..., max_length=500, description="Excerpt of relevant text")
    relevance_score: float = Field(..., ge=0, le=1, description="Relevance score for this citation")

class AIIntentResponse(BaseModel):
    intent: AIIntentType
    confidence: float = Field(..., ge=0, le=1, description="Overall confidence in the response")
    actions: List[AIAction] = Field(default_factory=list, description="List of suggested actions")
    clarifying_questions: List[str] = Field(default_factory=list, description="Questions to improve understanding")
    citations: List[Citation] = Field(default_factory=list, description="Source citations for the response")
    processing_time_ms: int = Field(..., ge=0, description="Processing time in milliseconds")
    model_used: str = Field(..., description="AI model that generated this response")

class TroubleshootingStep(BaseModel):
    step_number: int = Field(..., ge=1, description="Step sequence number")
    title: str = Field(..., max_length=200, description="Step title")
    description: str = Field(..., max_length=1000, description="Detailed step description")
    estimated_time_minutes: Optional[int] = Field(None, ge=1, description="Estimated time for this step")
    required_tools: List[str] = Field(default_factory=list, description="Tools needed for this step")
    safety_notes: Optional[str] = Field(None, max_length=500, description="Safety considerations")
    confidence: float = Field(..., ge=0, le=1, description="Confidence in this step")

class SimilarCase(BaseModel):
    work_order_id: str = Field(..., description="ID of similar work order")
    asset_id: str = Field(..., description="Asset involved in similar case")
    issue_description: str = Field(..., max_length=500, description="Description of similar issue")
    resolution: str = Field(..., max_length=1000, description="How the issue was resolved")
    resolution_time_hours: Optional[float] = Field(None, ge=0, description="Time taken to resolve")
    similarity_score: float = Field(..., ge=0, le=1, description="Similarity to current issue")

class TroubleshootingResponse(BaseModel):
    work_order_id: str = Field(..., description="Associated work order ID")
    issue_analysis: str = Field(..., max_length=2000, description="AI analysis of the issue")
    recommended_steps: List[TroubleshootingStep] = Field(..., description="Recommended troubleshooting steps")
    similar_cases: List[SimilarCase] = Field(default_factory=list, description="Similar past cases")
    confidence: float = Field(..., ge=0, le=1, description="Overall confidence in recommendations")
    citations: List[Citation] = Field(default_factory=list, description="Source citations")
    estimated_resolution_time_hours: Optional[float] = Field(None, ge=0, description="Estimated resolution time")
    required_parts: List[str] = Field(default_factory=list, description="Potentially required parts")
    required_skills: List[str] = Field(default_factory=list, description="Required technician skills")
    safety_warnings: List[str] = Field(default_factory=list, description="Important safety warnings")

class PartCandidate(BaseModel):
    part_number: str = Field(..., description="Part number")
    name: str = Field(..., description="Part name")
    description: str = Field(..., description="Part description")
    confidence: float = Field(..., ge=0, le=1, description="Confidence in identification")
    source: str = Field(..., description="Source of identification (OCR, visual, etc.)")
    manufacturer: Optional[str] = Field(None, description="Part manufacturer")
    in_stock: Optional[int] = Field(None, ge=0, description="Current stock quantity")
    estimated_cost: Optional[float] = Field(None, ge=0, description="Estimated cost")
    compatibility_notes: Optional[str] = Field(None, max_length=500, description="Compatibility information")

class PartIdentificationResponse(BaseModel):
    image_analysis: str = Field(..., max_length=1000, description="Analysis of the uploaded image")
    candidates: List[PartCandidate] = Field(..., description="Identified part candidates")
    overall_confidence: float = Field(..., ge=0, le=1, description="Overall identification confidence")
    processing_time_ms: int = Field(..., ge=0, description="Processing time in milliseconds")
    recommendations: List[str] = Field(default_factory=list, description="Next steps recommendations")
    alternative_actions: List[str] = Field(default_factory=list, description="Alternative identification methods")

class TechnicianSkill(BaseModel):
    skill_name: str = Field(..., description="Name of the skill")
    proficiency_level: Literal["beginner", "intermediate", "advanced", "expert"] = Field(..., description="Skill level")
    years_experience: Optional[int] = Field(None, ge=0, description="Years of experience with this skill")
    last_used: Optional[date] = Field(None, description="Last time skill was used")

class TechnicianCapacity(BaseModel):
    technician_id: str = Field(..., description="Technician ID")
    name: str = Field(..., description="Technician name")
    current_workload_hours: float = Field(..., ge=0, description="Current assigned hours")
    max_capacity_hours: float = Field(..., ge=0, description="Maximum weekly capacity")
    utilization_percentage: float = Field(..., ge=0, le=100, description="Current utilization percentage")
    available_hours: float = Field(..., ge=0, description="Available hours this week")
    skills: List[TechnicianSkill] = Field(default_factory=list, description="Technician skills")
    location: Optional[str] = Field(None, description="Technician location")
    shift: Optional[str] = Field(None, description="Working shift")
    availability_notes: Optional[str] = Field(None, max_length=500, description="Availability notes")

class CapacityAnalysisRequest(BaseModel):
    work_order_id: Optional[str] = Field(None, description="Work order to analyze capacity for")
    required_skills: List[str] = Field(default_factory=list, description="Required skills for the work")
    estimated_hours: Optional[float] = Field(None, ge=0, description="Estimated work hours")
    priority: Optional[PriorityLevel] = None
    preferred_date: Optional[date] = Field(None, description="Preferred completion date")
    location_constraint: Optional[str] = Field(None, description="Location constraint for work")

class CapacityAnalysisResponse(BaseModel):
    analysis_summary: str = Field(..., max_length=1000, description="Summary of capacity analysis")
    recommended_technicians: List[TechnicianCapacity] = Field(..., description="Recommended technicians")
    capacity_conflicts: List[str] = Field(default_factory=list, description="Identified conflicts")
    alternative_scheduling: List[Dict[str, Any]] = Field(default_factory=list, description="Alternative scheduling options")
    resource_constraints: List[str] = Field(default_factory=list, description="Resource constraints identified")
    confidence: float = Field(..., ge=0, le=1, description="Confidence in recommendations")
    processing_time_ms: int = Field(..., ge=0, description="Processing time in milliseconds")

class WorkOrderPlanningRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=200, description="Work order title")
    description: str = Field(..., min_length=10, max_length=2000, description="Work description")
    asset_id: str = Field(..., description="Asset ID")
    priority: PriorityLevel
    estimated_hours: Optional[float] = Field(None, ge=0, description="Estimated hours")
    required_skills: List[str] = Field(default_factory=list, description="Required skills")
    required_parts: List[str] = Field(default_factory=list, description="Required parts")
    target_completion_date: Optional[date] = Field(None, description="Target completion date")
    constraints: Dict[str, Any] = Field(default_factory=dict, description="Planning constraints")

class WorkOrderPlanningResponse(BaseModel):
    planning_summary: str = Field(..., max_length=1000, description="Planning summary")
    recommended_technician: Optional[str] = Field(None, description="Recommended technician ID")
    suggested_schedule: Dict[str, Any] = Field(default_factory=dict, description="Suggested scheduling")
    parts_availability: Dict[str, Any] = Field(default_factory=dict, description="Parts availability status")
    resource_allocation: Dict[str, Any] = Field(default_factory=dict, description="Resource allocation plan")
    estimated_completion_date: Optional[date] = Field(None, description="Estimated completion date")
    risk_factors: List[str] = Field(default_factory=list, description="Identified risk factors")
    optimization_suggestions: List[str] = Field(default_factory=list, description="Optimization suggestions")
    confidence: float = Field(..., ge=0, le=1, description="Confidence in plan")
    processing_time_ms: int = Field(..., ge=0, description="Processing time in milliseconds")

# =============================================================================
# Bulk Import/Export Operations (Phase 4)
# =============================================================================

class ImportMode(str, Enum):
    PREVIEW = "preview"
    COMMIT = "commit"

class ImportErrorType(str, Enum):
    VALIDATION_ERROR = "validation_error"
    BUSINESS_RULE_ERROR = "business_rule_error"
    REFERENTIAL_INTEGRITY_ERROR = "referential_integrity_error"
    DUPLICATE_ERROR = "duplicate_error"
    PARSING_ERROR = "parsing_error"

class ImportError(BaseModel):
    row: int = Field(..., ge=1, description="Row number (1-based)")
    column: Optional[str] = Field(None, description="Column name with error")
    field: str = Field(..., description="Field with error")
    error_type: ImportErrorType
    message: str = Field(..., min_length=1, description="Error message")
    value: Optional[str] = Field(None, description="Invalid value")
    suggestion: Optional[str] = Field(None, description="Fix suggestion")

class ImportValidationSummary(BaseModel):
    total_rows: int = Field(..., ge=0)
    valid_rows: int = Field(..., ge=0)
    invalid_rows: int = Field(..., ge=0)
    duplicate_rows: int = Field(..., ge=0)
    errors: List[ImportError] = Field(default_factory=list)
    warnings: List[ImportError] = Field(default_factory=list)
    
class ImportPreviewData(BaseModel):
    sample_rows: List[Dict[str, Any]] = Field(default_factory=list, max_items=10)
    field_mapping: Dict[str, str] = Field(default_factory=dict)
    detected_format: str = Field(..., description="csv or xlsx")
    column_headers: List[str] = Field(default_factory=list)
    total_columns: int = Field(..., ge=0)

class BulkImportRequest(BaseModel):
    mode: ImportMode = ImportMode.PREVIEW
    skip_duplicates: bool = True
    validate_references: bool = True
    dry_run: bool = False

class BulkImportResponse(BaseModel):
    mode: ImportMode
    task_id: Optional[str] = Field(None, description="Background task ID for large imports")
    validation_summary: ImportValidationSummary
    preview_data: Optional[ImportPreviewData] = None
    processing_time_ms: int = Field(..., ge=0)
    success: bool = True
    message: str = "Import processed successfully"

class ImportStatusResponse(BaseModel):
    task_id: str
    status: Literal["pending", "processing", "completed", "failed"] = "pending"
    progress_percent: float = Field(..., ge=0, le=100)
    processed_rows: int = Field(..., ge=0)
    total_rows: int = Field(..., ge=0)
    errors: List[ImportError] = Field(default_factory=list)
    estimated_completion_time: Optional[datetime] = None
    message: str = "Processing import..."

class ExportCustomization(BaseModel):
    format: Literal["csv", "xlsx"] = "csv"
    columns: Optional[List[str]] = Field(None, description="Columns to export")
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    status_filter: Optional[List[WorkOrderStatus]] = None
    priority_filter: Optional[List[PriorityLevel]] = None
    asset_filter: Optional[List[str]] = None
    technician_filter: Optional[List[str]] = None
    include_comments: bool = False
    include_time_entries: bool = False
    include_photos: bool = False
    timezone: str = "UTC"

class ExportRequestV2(BaseModel):
    customization: ExportCustomization
    async_export: bool = False
    
class ExportResponse(BaseModel):
    export_id: Optional[str] = Field(None, description="Export ID for async exports")
    download_url: Optional[str] = Field(None, description="Download URL for completed exports")
    total_records: int = Field(..., ge=0)
    file_size_bytes: Optional[int] = Field(None, ge=0)
    expires_at: Optional[datetime] = None
    processing_time_ms: int = Field(..., ge=0)

class BulkStatusUpdate(BaseModel):
    work_order_ids: List[str] = Field(..., min_items=1, max_items=1000)
    status: WorkOrderStatus
    notes: Optional[str] = Field(None, max_length=1000)
    priority: Optional[PriorityLevel] = None
    assigned_to: Optional[str] = None
    due_date: Optional[date] = None
    reason: str = Field(..., min_length=5, max_length=500, description="Reason for bulk update")

class BulkStatusUpdateResponse(BaseModel):
    successful_updates: int = Field(..., ge=0)
    failed_updates: int = Field(..., ge=0)
    updated_work_orders: List[str] = Field(default_factory=list)
    errors: List[Dict[str, Any]] = Field(default_factory=list)
    audit_trail_entries: List[str] = Field(default_factory=list)
    processing_time_ms: int = Field(..., ge=0)

class ValidationRule(BaseModel):
    field: str
    rule_type: Literal["required", "format", "business_logic", "reference", "duplicate"]
    rule_config: Dict[str, Any] = Field(default_factory=dict)
    error_message: str
    severity: Literal["error", "warning"] = "error"

class ImportFieldMapping(BaseModel):
    source_field: str = Field(..., description="Column header in import file")
    target_field: str = Field(..., description="Work order field name")
    required: bool = True
    validation_rules: List[ValidationRule] = Field(default_factory=list)
    default_value: Optional[str] = None
    transformation: Optional[str] = Field(None, description="Data transformation function")

class BulkOperationAudit(BaseModel):
    operation_id: str
    operation_type: Literal["import", "export", "bulk_update"]
    user_id: str
    timestamp: datetime
    affected_records: int
    success: bool
    details: Dict[str, Any] = Field(default_factory=dict)
    processing_time_ms: int

# =============================================================================
# Procurement Workflow Models (Phase 2)
# =============================================================================

class PRLineCreate(BaseModel):
    """Purchase request line item creation"""
    part_id: Optional[str] = None
    description: str = Field(..., min_length=1, max_length=500)
    quantity: int = Field(..., ge=1, le=10000)
    estimated_cost: Optional[float] = Field(None, ge=0)
    asset_id: Optional[str] = None
    notes: Optional[str] = None

class PurchaseRequestCreate(BaseModel):
    """Purchase request creation"""
    lines: List[PRLineCreate] = Field(..., min_items=1, max_items=100)
    priority: Literal["normal", "urgent", "critical"] = "normal"
    need_by_date: Optional[str] = None
    justification: Optional[str] = None
    work_order_id: Optional[str] = None

class PurchaseRequestResponse(BaseModel):
    """Purchase request response"""
    id: str
    requested_by: str
    status: str
    priority: str
    need_by_date: Optional[str] = None
    created_at: str
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    total_estimated: float
    justification: Optional[str] = None
    work_order_id: Optional[str] = None
    lines: List[Dict[str, Any]] = []

class RFQCreate(BaseModel):
    """RFQ creation from purchase request"""
    pr_id: str
    vendor_ids: List[str] = Field(..., min_items=1, max_items=20)
    response_due_date: str
    notes: Optional[str] = None

class RFQResponse(BaseModel):
    """RFQ response"""
    id: str
    pr_id: str
    status: str
    sent_date: str
    response_due_date: str
    created_by: str
    vendor_ids: List[str]
    notes: Optional[str] = None

class QuoteLineCreate(BaseModel):
    """Quote line item creation"""
    pr_line_id: str
    unit_price: float = Field(..., ge=0)
    quantity_available: int = Field(..., ge=0)
    lead_time_days: int = Field(..., ge=0, le=365)
    notes: Optional[str] = None

class QuoteAttach(BaseModel):
    """Attach vendor quote to RFQ"""
    rfq_id: str
    vendor_id: str
    quote_number: str
    lines: List[QuoteLineCreate] = Field(..., min_items=1)
    validity_date: str
    terms: Optional[str] = None
    notes: Optional[str] = None

class QuoteResponse(BaseModel):
    """Quote response"""
    id: str
    rfq_id: str
    vendor_id: str
    quote_number: str
    total_amount: float
    currency: str = "USD"
    validity_date: str
    lead_time_days: int
    terms: Optional[str] = None
    received_date: str
    status: str
    notes: Optional[str] = None
    lines: List[Dict[str, Any]] = []

class QuoteComparison(BaseModel):
    """Quote comparison data"""
    quote_id: str
    vendor_name: str
    vendor_rating: float
    total_amount: float
    lead_time_days: int
    price_per_unit: Dict[str, float]
    terms: str
    score: float
    pros: List[str] = []
    cons: List[str] = []

class QuoteComparisonResponse(BaseModel):
    """Quote comparison response"""
    rfq_id: str
    quotes: List[QuoteComparison]
    recommended_quote_id: Optional[str] = None
    recommendation_reason: Optional[str] = None
    total_savings_potential: Optional[float] = None

class POCreate(BaseModel):
    """Purchase order creation from quote"""
    quote_id: str
    vendor_id: str
    terms: Optional[str] = None
    expected_delivery: str
    notes: Optional[str] = None
    approval_override: bool = False

class PurchaseOrderResponse(BaseModel):
    """Purchase order response"""
    id: str
    vendor_id: str
    po_number: str
    status: str
    order_date: str
    expected_delivery: str
    actual_delivery: Optional[str] = None
    total_amount: float
    created_by: str
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    terms: Optional[str] = None
    notes: Optional[str] = None
    lines: List[Dict[str, Any]] = []
    approval_required: bool = False
    approval_threshold_exceeded: bool = False

class ReceivingLineCreate(BaseModel):
    """Receiving line item"""
    po_line_id: str
    part_id: Optional[str] = None
    quantity_received: int = Field(..., ge=0)
    condition: Literal["good", "damaged", "wrong_item"] = "good"
    bin_location: Optional[str] = None
    notes: Optional[str] = None

class ReceivingCreate(BaseModel):
    """Receiving creation"""
    po_id: str
    packing_slip: Optional[str] = None
    partial_shipment: bool = False
    lines: List[ReceivingLineCreate] = Field(..., min_items=1)
    notes: Optional[str] = None

class ReceivingResponse(BaseModel):
    """Receiving response"""
    id: str
    po_id: str
    received_by: str
    received_date: str
    packing_slip: Optional[str] = None
    partial_shipment: bool = False
    notes: Optional[str] = None
    lines: List[Dict[str, Any]] = []
    inventory_updated: bool = False

class VendorCreate(BaseModel):
    """Vendor creation"""
    name: str = Field(..., min_length=1, max_length=200)
    contact_email: Optional[EmailStr] = None
    contact_phone: Optional[str] = None
    contact_person: Optional[str] = None
    address: Optional[str] = None
    terms: str = "NET30"
    default_lead_days: int = Field(7, ge=0, le=365)
    notes: Optional[str] = None

class VendorResponse(BaseModel):
    """Vendor response"""
    id: str
    name: str
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None
    contact_person: Optional[str] = None
    address: Optional[str] = None
    terms: str
    default_lead_days: int
    rating: float
    active: bool
    created_at: str
    updated_at: str
    notes: Optional[str] = None

class ApprovalWorkflowResponse(BaseModel):
    """Approval workflow response"""
    id: str
    type: str  # purchase_order, purchase_request
    amount: float
    status: str  # pending, approved, rejected
    requested_by: str
    current_approver: Optional[str] = None
    approval_level: int
    created_at: str
    expires_at: Optional[str] = None
    approval_threshold: float
    requires_manager_approval: bool
    requires_admin_approval: bool

class ApprovalAction(BaseModel):
    """Approval action"""
    action: Literal["approve", "reject"]
    comments: Optional[str] = None
    override_reason: Optional[str] = None

class PartsKPIResponse(BaseModel):
    """Parts and inventory KPIs"""
    period_days: int
    stockouts_count: int
    fill_rate_pct: float
    inventory_turns: float
    avg_lead_time_days: float
    price_variance_pct: float
    on_time_delivery_pct: float
    total_inventory_value: float
    low_stock_count: int
    spend_analytics: Dict[str, Any]
    generated_at: str

class VendorPerformanceResponse(BaseModel):
    """Vendor performance metrics"""
    vendor_id: str
    vendor_name: str
    rating: float
    total_orders: int
    on_time_deliveries: int
    on_time_delivery_pct: float
    quality_score: float
    price_competitiveness: float
    total_spend_ytd: float
    avg_lead_time_days: float
    last_order_date: Optional[str] = None

class ProcurementAnalyticsResponse(BaseModel):
    """Procurement analytics"""
    period_days: int
    total_spend: float
    cost_savings: float
    purchase_orders_count: int
    avg_approval_time_hours: float
    vendor_performance: List[VendorPerformanceResponse]
    top_categories_by_spend: List[Dict[str, Any]]
    procurement_cycle_time_days: float
    generated_at: str