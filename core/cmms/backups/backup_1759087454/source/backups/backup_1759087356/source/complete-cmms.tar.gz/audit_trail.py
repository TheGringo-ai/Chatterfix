#!/usr/bin/env python3
"""
CMMS Audit Trail System
Comprehensive audit logging for all write operations with payload hashing
"""

import hashlib
import json
import logging
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
from fastapi import Request
import asyncio
from contextlib import asynccontextmanager

from api_schemas import AuditLogEntry

# =============================================================================
# Configuration
# =============================================================================

# In-memory audit log store (use database in production)
AUDIT_LOG: List[Dict[str, Any]] = []
MAX_AUDIT_LOG_SIZE = 10000  # Keep last 10k entries in memory

# Configure audit logger
audit_logger = logging.getLogger("chatterfix.audit")
audit_handler = logging.FileHandler("/tmp/chatterfix_audit.log")
audit_formatter = logging.Formatter(
    '%(asctime)s - AUDIT - %(message)s'
)
audit_handler.setFormatter(audit_formatter)
audit_logger.addHandler(audit_handler)
audit_logger.setLevel(logging.INFO)

# =============================================================================
# Audit Models
# =============================================================================

class AuditContext(BaseModel):
    """Context information for audit logging"""
    user_id: str
    user_name: str
    action: str
    resource_type: str
    resource_id: str
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    success: bool = True
    error_message: Optional[str] = None

class AuditFilter(BaseModel):
    """Filters for audit log queries"""
    user_id: Optional[str] = None
    resource_type: Optional[str] = None
    resource_id: Optional[str] = None
    action: Optional[str] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    success: Optional[bool] = None
    limit: int = 100

# =============================================================================
# Audit Functions
# =============================================================================

def generate_payload_hash(payload: Dict[str, Any]) -> str:
    """Generate SHA-256 hash of payload for integrity verification"""
    if not payload:
        return ""
    
    # Sort keys and create deterministic JSON string
    payload_json = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(payload_json.encode()).hexdigest()

def log_audit_entry(context: AuditContext) -> str:
    """Log an audit entry and return the entry ID"""
    entry_id = f"audit-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}-{len(AUDIT_LOG):06d}"
    
    # Generate payload hash
    payload_hash = generate_payload_hash(context.payload or {})
    
    # Create audit entry
    audit_entry = AuditLogEntry(
        id=entry_id,
        user_id=context.user_id,
        user_name=context.user_name,
        action=context.action,
        resource_type=context.resource_type,
        resource_id=context.resource_id,
        payload_hash=payload_hash,
        ip_address=context.ip_address,
        user_agent=context.user_agent,
        timestamp=datetime.now(timezone.utc),
        success=context.success,
        error_message=context.error_message
    )
    
    # Add to in-memory store
    AUDIT_LOG.append(audit_entry.dict())
    
    # Trim log if it exceeds max size
    if len(AUDIT_LOG) > MAX_AUDIT_LOG_SIZE:
        AUDIT_LOG.pop(0)
    
    # Log to file
    audit_logger.info(
        f"USER={context.user_id} ACTION={context.action} "
        f"RESOURCE={context.resource_type}/{context.resource_id} "
        f"SUCCESS={context.success} HASH={payload_hash[:16]} "
        f"IP={context.ip_address or 'unknown'}"
    )
    
    return entry_id

def get_audit_logs(filters: AuditFilter) -> List[AuditLogEntry]:
    """Retrieve audit logs with filtering"""
    filtered_logs = []
    
    for log_entry in reversed(AUDIT_LOG[-filters.limit:]):  # Most recent first
        # Apply filters
        if filters.user_id and log_entry["user_id"] != filters.user_id:
            continue
        if filters.resource_type and log_entry["resource_type"] != filters.resource_type:
            continue
        if filters.resource_id and log_entry["resource_id"] != filters.resource_id:
            continue
        if filters.action and log_entry["action"] != filters.action:
            continue
        if filters.success is not None and log_entry["success"] != filters.success:
            continue
        
        # Date filtering
        log_timestamp = datetime.fromisoformat(log_entry["timestamp"].replace('Z', '+00:00'))
        if filters.date_from and log_timestamp < filters.date_from:
            continue
        if filters.date_to and log_timestamp > filters.date_to:
            continue
        
        filtered_logs.append(AuditLogEntry(**log_entry))
        
        if len(filtered_logs) >= filters.limit:
            break
    
    return filtered_logs

def get_resource_audit_history(resource_type: str, resource_id: str, limit: int = 50) -> List[AuditLogEntry]:
    """Get audit history for a specific resource"""
    filters = AuditFilter(
        resource_type=resource_type,
        resource_id=resource_id,
        limit=limit
    )
    return get_audit_logs(filters)

def verify_payload_integrity(entry_id: str, payload: Dict[str, Any]) -> bool:
    """Verify payload integrity against stored hash"""
    for log_entry in AUDIT_LOG:
        if log_entry["id"] == entry_id:
            stored_hash = log_entry["payload_hash"]
            computed_hash = generate_payload_hash(payload)
            return stored_hash == computed_hash
    return False

# =============================================================================
# Audit Decorators and Context Managers
# =============================================================================

@asynccontextmanager
async def audit_operation(
    user_id: str,
    user_name: str,
    action: str,
    resource_type: str,
    resource_id: str,
    request: Optional[Request] = None,
    payload: Optional[Dict[str, Any]] = None
):
    """Context manager for auditing operations"""
    context = AuditContext(
        user_id=user_id,
        user_name=user_name,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        payload=payload
    )
    
    # Extract request info if available
    if request:
        context.ip_address = request.client.host if request.client else None
        context.user_agent = request.headers.get("user-agent")
    
    try:
        yield context
        # Operation succeeded
        context.success = True
        log_audit_entry(context)
        
    except Exception as e:
        # Operation failed
        context.success = False
        context.error_message = str(e)
        log_audit_entry(context)
        raise  # Re-raise the exception

def audit_create(resource_type: str):
    """Decorator for CREATE operations"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Extract common parameters
            current_user = kwargs.get('current_user')
            request = kwargs.get('request')
            
            if not current_user:
                return await func(*args, **kwargs)
            
            # Create resource first to get ID
            result = await func(*args, **kwargs)
            
            # Extract resource ID from result
            resource_id = "unknown"
            if isinstance(result, dict):
                resource_id = result.get('id', result.get('resource_id', 'unknown'))
            elif hasattr(result, 'id'):
                resource_id = result.id
            
            # Log audit entry after successful creation
            async with audit_operation(
                user_id=current_user.id,
                user_name=current_user.username,
                action="CREATE",
                resource_type=resource_type,
                resource_id=resource_id,
                request=request,
                payload=kwargs.get('data', {})
            ):
                pass
            
            return result
        
        return wrapper
    return decorator

def audit_update(resource_type: str):
    """Decorator for UPDATE operations"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get('current_user')
            request = kwargs.get('request')
            resource_id = kwargs.get('id', kwargs.get('resource_id', 'unknown'))
            
            if not current_user:
                return await func(*args, **kwargs)
            
            async with audit_operation(
                user_id=current_user.id,
                user_name=current_user.username,
                action="UPDATE",
                resource_type=resource_type,
                resource_id=str(resource_id),
                request=request,
                payload=kwargs.get('data', {})
            ):
                result = await func(*args, **kwargs)
            
            return result
        
        return wrapper
    return decorator

def audit_delete(resource_type: str):
    """Decorator for DELETE operations"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get('current_user')
            request = kwargs.get('request')
            resource_id = kwargs.get('id', kwargs.get('resource_id', 'unknown'))
            
            if not current_user:
                return await func(*args, **kwargs)
            
            async with audit_operation(
                user_id=current_user.id,
                user_name=current_user.username,
                action="DELETE",
                resource_type=resource_type,
                resource_id=str(resource_id),
                request=request,
                payload={"force_delete": kwargs.get('force_delete', False)}
            ):
                result = await func(*args, **kwargs)
            
            return result
        
        return wrapper
    return decorator

def audit_bulk_operation(resource_type: str, operation: str):
    """Decorator for bulk operations"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get('current_user')
            request = kwargs.get('request')
            
            if not current_user:
                return await func(*args, **kwargs)
            
            # Extract bulk data
            bulk_data = kwargs.get('data', {})
            resource_ids = bulk_data.get('ids', []) if isinstance(bulk_data, dict) else []
            
            async with audit_operation(
                user_id=current_user.id,
                user_name=current_user.username,
                action=f"BULK_{operation.upper()}",
                resource_type=resource_type,
                resource_id=f"bulk-{len(resource_ids)}-items",
                request=request,
                payload={
                    "operation": operation,
                    "count": len(resource_ids),
                    "resource_ids": resource_ids[:10],  # Log first 10 IDs
                    "total_count": len(resource_ids)
                }
            ):
                result = await func(*args, **kwargs)
            
            return result
        
        return wrapper
    return decorator

# =============================================================================
# Specific Audit Functions for Each Module
# =============================================================================

def audit_work_order_assignment(user_id: str, user_name: str, work_order_ids: List[str], 
                               assigned_to: str, request: Optional[Request] = None):
    """Audit work order assignments"""
    asyncio.create_task(_audit_work_order_assignment(
        user_id, user_name, work_order_ids, assigned_to, request
    ))

async def _audit_work_order_assignment(user_id: str, user_name: str, work_order_ids: List[str], 
                                     assigned_to: str, request: Optional[Request] = None):
    """Internal async function for work order assignment audit"""
    async with audit_operation(
        user_id=user_id,
        user_name=user_name,
        action="BULK_ASSIGN",
        resource_type="work_order",
        resource_id=f"bulk-{len(work_order_ids)}-work-orders",
        request=request,
        payload={
            "work_order_ids": work_order_ids,
            "assigned_to": assigned_to,
            "count": len(work_order_ids)
        }
    ):
        pass

def audit_stock_adjustment(user_id: str, user_name: str, part_id: str, 
                          adjustment_type: str, quantity: int, reason: str,
                          request: Optional[Request] = None):
    """Audit stock adjustments"""
    asyncio.create_task(_audit_stock_adjustment(
        user_id, user_name, part_id, adjustment_type, quantity, reason, request
    ))

async def _audit_stock_adjustment(user_id: str, user_name: str, part_id: str, 
                                adjustment_type: str, quantity: int, reason: str,
                                request: Optional[Request] = None):
    """Internal async function for stock adjustment audit"""
    async with audit_operation(
        user_id=user_id,
        user_name=user_name,
        action="STOCK_ADJUSTMENT",
        resource_type="part",
        resource_id=part_id,
        request=request,
        payload={
            "adjustment_type": adjustment_type,
            "quantity": quantity,
            "reason": reason
        }
    ):
        pass

def audit_pm_completion(user_id: str, user_name: str, pm_task_id: str, 
                       completion_data: Dict[str, Any], request: Optional[Request] = None):
    """Audit PM task completions"""
    asyncio.create_task(_audit_pm_completion(
        user_id, user_name, pm_task_id, completion_data, request
    ))

async def _audit_pm_completion(user_id: str, user_name: str, pm_task_id: str, 
                             completion_data: Dict[str, Any], request: Optional[Request] = None):
    """Internal async function for PM completion audit"""
    async with audit_operation(
        user_id=user_id,
        user_name=user_name,
        action="PM_COMPLETE",
        resource_type="pm_task",
        resource_id=pm_task_id,
        request=request,
        payload=completion_data
    ):
        pass

def audit_system_backup(user_id: str, user_name: str, backup_type: str, 
                       success: bool, file_path: str = None, error: str = None,
                       request: Optional[Request] = None):
    """Audit system backup operations"""
    asyncio.create_task(_audit_system_backup(
        user_id, user_name, backup_type, success, file_path, error, request
    ))

async def _audit_system_backup(user_id: str, user_name: str, backup_type: str, 
                             success: bool, file_path: str = None, error: str = None,
                             request: Optional[Request] = None):
    """Internal async function for system backup audit"""
    context = AuditContext(
        user_id=user_id,
        user_name=user_name,
        action="SYSTEM_BACKUP",
        resource_type="system",
        resource_id="backup",
        payload={
            "backup_type": backup_type,
            "file_path": file_path,
            "success": success
        },
        success=success,
        error_message=error
    )
    
    if request:
        context.ip_address = request.client.host if request.client else None
        context.user_agent = request.headers.get("user-agent")
    
    log_audit_entry(context)

# =============================================================================
# Audit Statistics and Reporting
# =============================================================================

def get_audit_statistics(days: int = 30) -> Dict[str, Any]:
    """Get audit statistics for the last N days"""
    cutoff_date = datetime.now(timezone.utc) - timedelta(days=days)
    
    stats = {
        "total_entries": 0,
        "successful_operations": 0,
        "failed_operations": 0,
        "actions": {},
        "resource_types": {},
        "top_users": {},
        "recent_failures": []
    }
    
    for entry in AUDIT_LOG:
        entry_time = datetime.fromisoformat(entry["timestamp"].replace('Z', '+00:00'))
        if entry_time < cutoff_date:
            continue
        
        stats["total_entries"] += 1
        
        if entry["success"]:
            stats["successful_operations"] += 1
        else:
            stats["failed_operations"] += 1
            if len(stats["recent_failures"]) < 10:
                stats["recent_failures"].append({
                    "timestamp": entry["timestamp"],
                    "action": entry["action"],
                    "resource": f"{entry['resource_type']}/{entry['resource_id']}",
                    "user": entry["user_name"],
                    "error": entry["error_message"]
                })
        
        # Count actions
        action = entry["action"]
        stats["actions"][action] = stats["actions"].get(action, 0) + 1
        
        # Count resource types
        resource_type = entry["resource_type"]
        stats["resource_types"][resource_type] = stats["resource_types"].get(resource_type, 0) + 1
        
        # Count users
        user = entry["user_name"]
        stats["top_users"][user] = stats["top_users"].get(user, 0) + 1
    
    # Sort top users
    stats["top_users"] = dict(sorted(stats["top_users"].items(), key=lambda x: x[1], reverse=True)[:10])
    
    return stats

def export_audit_log(filters: AuditFilter, format: str = "json") -> str:
    """Export audit log in specified format"""
    logs = get_audit_logs(filters)
    
    if format.lower() == "json":
        return json.dumps([log.dict() for log in logs], indent=2, default=str)
    elif format.lower() == "csv":
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=[
            "id", "timestamp", "user_name", "action", "resource_type", 
            "resource_id", "success", "error_message", "ip_address"
        ])
        writer.writeheader()
        
        for log in logs:
            writer.writerow({
                "id": log.id,
                "timestamp": log.timestamp.isoformat(),
                "user_name": log.user_name,
                "action": log.action,
                "resource_type": log.resource_type,
                "resource_id": log.resource_id,
                "success": log.success,
                "error_message": log.error_message or "",
                "ip_address": log.ip_address or ""
            })
        
        return output.getvalue()
    else:
        raise ValueError(f"Unsupported export format: {format}")

# =============================================================================
# Cleanup and Maintenance
# =============================================================================

def cleanup_old_audit_entries(days_to_keep: int = 90):
    """Remove audit entries older than specified days"""
    cutoff_date = datetime.now(timezone.utc) - timedelta(days=days_to_keep)
    
    # Filter entries to keep
    global AUDIT_LOG
    AUDIT_LOG = [
        entry for entry in AUDIT_LOG
        if datetime.fromisoformat(entry["timestamp"].replace('Z', '+00:00')) > cutoff_date
    ]
    
    audit_logger.info(f"Cleaned up audit entries older than {days_to_keep} days")

from datetime import timedelta