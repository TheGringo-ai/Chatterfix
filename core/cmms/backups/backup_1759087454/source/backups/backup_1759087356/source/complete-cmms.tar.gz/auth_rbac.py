#!/usr/bin/env python3
"""
CMMS Authentication and Role-Based Access Control (RBAC)
Comprehensive auth system with JWT tokens and role-based permissions
"""

import os
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Set
from functools import wraps
from fastapi import HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel
from enum import Enum

from api_schemas import UserRole, SystemUser

# =============================================================================
# Configuration
# =============================================================================

SECRET_KEY = os.getenv("JWT_SECRET_KEY", secrets.token_urlsafe(32))
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "15"))  # Shorter for security
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))
TOKEN_ROTATION_THRESHOLD_MINUTES = int(os.getenv("TOKEN_ROTATION_THRESHOLD_MINUTES", "5"))  # Rotate if <5min left
MAX_FAILED_ATTEMPTS = int(os.getenv("MAX_FAILED_ATTEMPTS", "5"))
LOCKOUT_DURATION_MINUTES = int(os.getenv("LOCKOUT_DURATION_MINUTES", "15"))

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Token rotation and security tracking
ROTATED_TOKENS: Dict[str, str] = {}  # old_jti -> new_jti mapping
FAILED_ATTEMPTS: Dict[str, List[datetime]] = {}  # username -> attempt timestamps
SESSION_METADATA: Dict[str, Dict] = {}  # jti -> session info (IP, user_agent, etc.)

# =============================================================================
# Data Models
# =============================================================================

class TokenData(BaseModel):
    user_id: str
    username: str
    role: UserRole
    exp: datetime
    iat: datetime
    jti: str  # JWT ID for revocation

class AuthUser(BaseModel):
    id: str
    username: str
    email: str
    first_name: str
    last_name: str
    role: UserRole
    is_active: bool
    permissions: Set[str] = set()

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    refresh_expires_in: int
    user: AuthUser
    request_id: str = None  # For audit trails

class Permission(str, Enum):
    # Work Orders - Enhanced permissions for dashboard
    WORK_ORDERS_VIEW = "work_orders:view"
    WORK_ORDERS_VIEW_ALL = "work_orders:view_all"
    WORK_ORDERS_VIEW_OWN = "work_orders:view_own"
    WORK_ORDERS_CREATE = "work_orders:create"
    WORK_ORDERS_UPDATE = "work_orders:update"
    WORK_ORDERS_UPDATE_OWN = "work_orders:update_own"
    WORK_ORDERS_UPDATE_ALL = "work_orders:update_all"
    WORK_ORDERS_DELETE = "work_orders:delete"
    WORK_ORDERS_ASSIGN = "work_orders:assign"
    WORK_ORDERS_BULK_UPDATE = "work_orders:bulk_update"
    WORK_ORDERS_EXPORT = "work_orders:export"
    WORK_ORDERS_DASHBOARD = "work_orders:dashboard"
    WORK_ORDERS_CALENDAR = "work_orders:calendar"
    WORK_ORDERS_SCHEDULE = "work_orders:schedule"
    
    # Assets
    ASSETS_VIEW = "assets:view"
    ASSETS_CREATE = "assets:create"
    ASSETS_UPDATE = "assets:update"
    ASSETS_DELETE = "assets:delete"
    ASSETS_EXPORT = "assets:export"
    
    # Parts
    PARTS_VIEW = "parts:view"
    PARTS_CREATE = "parts:create"
    PARTS_UPDATE = "parts:update"
    PARTS_DELETE = "parts:delete"
    PARTS_ADJUST_STOCK = "parts:adjust_stock"
    PARTS_EXPORT = "parts:export"
    
    # Preventive Maintenance
    PM_VIEW = "pm:view"
    PM_CREATE = "pm:create"
    PM_UPDATE = "pm:update"
    PM_DELETE = "pm:delete"
    PM_COMPLETE = "pm:complete"
    PM_EXPORT = "pm:export"
    
    # Technicians
    TECHNICIANS_VIEW = "technicians:view"
    TECHNICIANS_CREATE = "technicians:create"
    TECHNICIANS_UPDATE = "technicians:update"
    TECHNICIANS_DELETE = "technicians:delete"
    TECHNICIANS_EXPORT = "technicians:export"
    
    # Time Tracking
    TIME_ENTRY_VIEW = "time_entry:view"
    TIME_ENTRY_CREATE = "time_entry:create"
    TIME_ENTRY_UPDATE = "time_entry:update"
    TIME_ENTRY_DELETE = "time_entry:delete"
    
    # Admin
    ADMIN_VIEW = "admin:view"
    ADMIN_USERS = "admin:users"
    ADMIN_CONFIG = "admin:config"
    ADMIN_BACKUP = "admin:backup"
    ADMIN_LOGS = "admin:logs"
    
    # Reports
    REPORTS_VIEW = "reports:view"
    REPORTS_EXPORT = "reports:export"
    REPORTS_ADVANCED = "reports:advanced"

# =============================================================================
# Role-Based Permissions Matrix
# =============================================================================

ROLE_PERMISSIONS: Dict[UserRole, Set[Permission]] = {
    UserRole.ADMIN: {
        # Full access to everything
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_VIEW_ALL,
        Permission.WORK_ORDERS_VIEW_OWN,
        Permission.WORK_ORDERS_CREATE,
        Permission.WORK_ORDERS_UPDATE,
        Permission.WORK_ORDERS_UPDATE_OWN,
        Permission.WORK_ORDERS_UPDATE_ALL,
        Permission.WORK_ORDERS_DELETE,
        Permission.WORK_ORDERS_ASSIGN,
        Permission.WORK_ORDERS_BULK_UPDATE,
        Permission.WORK_ORDERS_EXPORT,
        Permission.WORK_ORDERS_DASHBOARD,
        Permission.WORK_ORDERS_CALENDAR,
        Permission.WORK_ORDERS_SCHEDULE,
        Permission.ASSETS_VIEW,
        Permission.ASSETS_CREATE,
        Permission.ASSETS_UPDATE,
        Permission.ASSETS_DELETE,
        Permission.ASSETS_EXPORT,
        Permission.PARTS_VIEW,
        Permission.PARTS_CREATE,
        Permission.PARTS_UPDATE,
        Permission.PARTS_DELETE,
        Permission.PARTS_ADJUST_STOCK,
        Permission.PARTS_EXPORT,
        Permission.PM_VIEW,
        Permission.PM_CREATE,
        Permission.PM_UPDATE,
        Permission.PM_DELETE,
        Permission.PM_COMPLETE,
        Permission.PM_EXPORT,
        Permission.TECHNICIANS_VIEW,
        Permission.TECHNICIANS_CREATE,
        Permission.TECHNICIANS_UPDATE,
        Permission.TECHNICIANS_DELETE,
        Permission.TECHNICIANS_EXPORT,
        Permission.TIME_ENTRY_VIEW,
        Permission.TIME_ENTRY_CREATE,
        Permission.TIME_ENTRY_UPDATE,
        Permission.TIME_ENTRY_DELETE,
        Permission.ADMIN_VIEW,
        Permission.ADMIN_USERS,
        Permission.ADMIN_CONFIG,
        Permission.ADMIN_BACKUP,
        Permission.ADMIN_LOGS,
        Permission.REPORTS_VIEW,
        Permission.REPORTS_EXPORT,
        Permission.REPORTS_ADVANCED,
    },
    
    UserRole.MANAGER: {
        # Management access - can view, create, update most things, limited delete
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_VIEW_ALL,
        Permission.WORK_ORDERS_CREATE,
        Permission.WORK_ORDERS_UPDATE,
        Permission.WORK_ORDERS_UPDATE_ALL,
        Permission.WORK_ORDERS_ASSIGN,
        Permission.WORK_ORDERS_BULK_UPDATE,
        Permission.WORK_ORDERS_EXPORT,
        Permission.WORK_ORDERS_DASHBOARD,
        Permission.WORK_ORDERS_CALENDAR,
        Permission.WORK_ORDERS_SCHEDULE,
        Permission.ASSETS_VIEW,
        Permission.ASSETS_CREATE,
        Permission.ASSETS_UPDATE,
        Permission.ASSETS_EXPORT,
        Permission.PARTS_VIEW,
        Permission.PARTS_CREATE,
        Permission.PARTS_UPDATE,
        Permission.PARTS_ADJUST_STOCK,
        Permission.PARTS_EXPORT,
        Permission.PM_VIEW,
        Permission.PM_CREATE,
        Permission.PM_UPDATE,
        Permission.PM_COMPLETE,
        Permission.PM_EXPORT,
        Permission.TECHNICIANS_VIEW,
        Permission.TECHNICIANS_UPDATE,
        Permission.TECHNICIANS_EXPORT,
        Permission.TIME_ENTRY_VIEW,
        Permission.TIME_ENTRY_UPDATE,
        Permission.REPORTS_VIEW,
        Permission.REPORTS_EXPORT,
        Permission.REPORTS_ADVANCED,
    },
    
    UserRole.TECHNICIAN: {
        # Technician access - can view most, update work orders assigned to them
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_VIEW_ALL,
        Permission.WORK_ORDERS_VIEW_OWN,
        Permission.WORK_ORDERS_UPDATE_OWN,  # Only own work orders
        Permission.WORK_ORDERS_DASHBOARD,
        Permission.WORK_ORDERS_CALENDAR,
        Permission.ASSETS_VIEW,
        Permission.PARTS_VIEW,
        Permission.PM_VIEW,
        Permission.PM_COMPLETE,
        Permission.TECHNICIANS_VIEW,
        Permission.TIME_ENTRY_VIEW,     # Only own time entries
        Permission.TIME_ENTRY_CREATE,
        Permission.TIME_ENTRY_UPDATE,   # Only own time entries
        Permission.REPORTS_VIEW,        # Limited reports
    },
    
    UserRole.VIEWER: {
        # Read-only access
        Permission.WORK_ORDERS_VIEW,
        Permission.WORK_ORDERS_VIEW_ALL,
        Permission.WORK_ORDERS_DASHBOARD,
        Permission.ASSETS_VIEW,
        Permission.PARTS_VIEW,
        Permission.PM_VIEW,
        Permission.TECHNICIANS_VIEW,
        Permission.REPORTS_VIEW,
    }
}

# =============================================================================
# In-Memory User Store (replace with database in production)
# =============================================================================

# Default admin user
USERS_DB: Dict[str, Dict] = {
    "admin": {
        "id": "user-admin-001",
        "username": "admin",
        "email": "admin@chatterfix.com",
        "first_name": "System",
        "last_name": "Administrator",
        "password_hash": pwd_context.hash("admin123!"),
        "role": UserRole.ADMIN,
        "is_active": True,
        "created_date": datetime.now(timezone.utc),
        "last_login": None,
    }
}

# Revoked tokens store (use Redis in production)
REVOKED_TOKENS: Set[str] = set()

# =============================================================================
# Authentication Functions
# =============================================================================

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against hash"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """Generate password hash"""
    return pwd_context.hash(password)

def authenticate_user(username: str, password: str) -> Optional[Dict]:
    """Authenticate user credentials"""
    user = USERS_DB.get(username)
    if not user:
        return None
    if not verify_password(password, user["password_hash"]):
        return None
    if not user["is_active"]:
        return None
    
    # Update last login
    user["last_login"] = datetime.now(timezone.utc)
    return user

def create_access_token(user: Dict) -> str:
    """Create JWT access token with enhanced security"""
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    # Enhanced payload with additional security claims
    payload = {
        "user_id": user["id"],
        "username": user["username"],
        "role": user["role"].value,
        "exp": expire,
        "iat": now,
        "nbf": now,  # Not before timestamp
        "jti": secrets.token_urlsafe(16),
        "token_type": "access",
        "token_version": "2.0",  # For future token format changes
        "iss": "chatterfix-cmms",  # Issuer
        "aud": "cmms-api"  # Audience
    }
    
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def create_refresh_token(user: Dict) -> str:
    """Create JWT refresh token"""
    now = datetime.now(timezone.utc)
    expire = now + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    
    payload = {
        "user_id": user["id"],
        "username": user["username"],
        "type": "refresh",
        "exp": expire,
        "iat": now,
        "jti": secrets.token_urlsafe(16)
    }
    
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def decode_token(token: str) -> Optional[TokenData]:
    """Decode and validate JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        
        # Check if token is revoked
        jti = payload.get("jti")
        if jti in REVOKED_TOKENS:
            return None
        
        # Parse token data
        token_data = TokenData(
            user_id=payload.get("user_id"),
            username=payload.get("username"),
            role=UserRole(payload.get("role")),
            exp=datetime.fromtimestamp(payload.get("exp"), timezone.utc),
            iat=datetime.fromtimestamp(payload.get("iat"), timezone.utc),
            jti=jti
        )
        
        return token_data
        
    except JWTError:
        return None

def revoke_token(jti: str):
    """Revoke a JWT token and clear session metadata"""
    REVOKED_TOKENS.add(jti)
    
    # Clean up session metadata
    if jti in SESSION_METADATA:
        del SESSION_METADATA[jti]
    
    # Clean up rotated token mappings
    for old_jti, new_jti in list(ROTATED_TOKENS.items()):
        if new_jti == jti:
            del ROTATED_TOKENS[old_jti]
            break

def rotate_token_if_needed(current_token: str, current_user: AuthUser) -> Optional[str]:
    """Rotate access token if it's close to expiry"""
    try:
        token_data = decode_token(current_token)
        if not token_data:
            return None
        
        # Check if token needs rotation (less than threshold minutes remaining)
        time_until_expiry = token_data.exp - datetime.now(timezone.utc)
        threshold = timedelta(minutes=TOKEN_ROTATION_THRESHOLD_MINUTES)
        
        if time_until_expiry <= threshold:
            # Create new token
            user_dict = {
                "id": current_user.id,
                "username": current_user.username, 
                "role": current_user.role
            }
            
            new_token = create_access_token(user_dict)
            new_token_data = decode_token(new_token)
            
            if new_token_data:
                # Track the rotation
                ROTATED_TOKENS[token_data.jti] = new_token_data.jti
                
                # Copy session metadata
                if token_data.jti in SESSION_METADATA:
                    SESSION_METADATA[new_token_data.jti] = SESSION_METADATA[token_data.jti].copy()
                    SESSION_METADATA[new_token_data.jti]['rotated_at'] = datetime.now(timezone.utc).isoformat()
                
                # Revoke old token after grace period
                revoke_token(token_data.jti)
                
                return new_token
        
        return None
        
    except Exception:
        return None

def check_account_lockout(username: str) -> bool:
    """Check if account is locked due to failed attempts"""
    if username not in FAILED_ATTEMPTS:
        return False
    
    now = datetime.now(timezone.utc)
    lockout_duration = timedelta(minutes=LOCKOUT_DURATION_MINUTES)
    
    # Clean old attempts
    FAILED_ATTEMPTS[username] = [
        attempt for attempt in FAILED_ATTEMPTS[username]
        if now - attempt < lockout_duration
    ]
    
    return len(FAILED_ATTEMPTS[username]) >= MAX_FAILED_ATTEMPTS

def record_failed_attempt(username: str):
    """Record a failed login attempt"""
    if username not in FAILED_ATTEMPTS:
        FAILED_ATTEMPTS[username] = []
    
    FAILED_ATTEMPTS[username].append(datetime.now(timezone.utc))

def clear_failed_attempts(username: str):
    """Clear failed attempts on successful login"""
    if username in FAILED_ATTEMPTS:
        del FAILED_ATTEMPTS[username]

def record_session_metadata(jti: str, ip_address: str = None, user_agent: str = None, additional_data: Dict = None):
    """Record session metadata for security tracking"""
    SESSION_METADATA[jti] = {
        'created_at': datetime.now(timezone.utc).isoformat(),
        'ip_address': ip_address,
        'user_agent': user_agent,
        'last_activity': datetime.now(timezone.utc).isoformat(),
        **(additional_data or {})
    }

def update_session_activity(jti: str):
    """Update last activity timestamp for session"""
    if jti in SESSION_METADATA:
        SESSION_METADATA[jti]['last_activity'] = datetime.now(timezone.utc).isoformat()

def get_active_sessions(user_id: str) -> List[Dict]:
    """Get all active sessions for a user"""
    sessions = []
    
    for jti, metadata in SESSION_METADATA.items():
        if jti not in REVOKED_TOKENS:
            # Check if this session belongs to the user
            try:
                # We'd need to track user_id in session metadata
                if 'user_id' in metadata and metadata['user_id'] == user_id:
                    sessions.append({
                        'jti': jti,
                        'created_at': metadata.get('created_at'),
                        'last_activity': metadata.get('last_activity'),
                        'ip_address': metadata.get('ip_address'),
                        'user_agent': metadata.get('user_agent')
                    })
            except Exception:
                continue
    
    return sessions

def revoke_all_user_sessions(user_id: str):
    """Revoke all active sessions for a user"""
    sessions_to_revoke = []
    
    for jti, metadata in SESSION_METADATA.items():
        if metadata.get('user_id') == user_id and jti not in REVOKED_TOKENS:
            sessions_to_revoke.append(jti)
    
    for jti in sessions_to_revoke:
        revoke_token(jti)

def get_user_permissions(role: UserRole) -> Set[str]:
    """Get permissions for a user role"""
    permissions = ROLE_PERMISSIONS.get(role, set())
    return {perm.value for perm in permissions}

# =============================================================================
# FastAPI Dependencies
# =============================================================================

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> AuthUser:
    """Get current authenticated user with enhanced security"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={"error": "Invalid authentication credentials", "request_id": secrets.token_urlsafe(8)},
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        token_data = decode_token(credentials.credentials)
        if token_data is None:
            raise credentials_exception
        
        # Update session activity
        update_session_activity(token_data.jti)
        
        # Get user from database
        user_data = None
        for user in USERS_DB.values():
            if user["id"] == token_data.user_id:
                user_data = user
                break
        
        if user_data is None or not user_data["is_active"]:
            raise credentials_exception
        
        # Check for account lockout
        if check_account_lockout(user_data["username"]):
            raise HTTPException(
                status_code=status.HTTP_423_LOCKED,
                detail={"error": "Account temporarily locked due to failed login attempts", "request_id": secrets.token_urlsafe(8)}
            )
        
        # Create AuthUser with permissions
        auth_user = AuthUser(
            id=user_data["id"],
            username=user_data["username"],
            email=user_data["email"],
            first_name=user_data["first_name"],
            last_name=user_data["last_name"],
            role=user_data["role"],
            is_active=user_data["is_active"],
            permissions=get_user_permissions(user_data["role"])
        )
        
        return auth_user
        
    except HTTPException:
        raise
    except Exception:
        raise credentials_exception

def require_permissions(*required_permissions: Permission):
    """Decorator to require specific permissions with enhanced error handling"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: AuthUser = Depends(get_current_user), **kwargs):
            missing_permissions = []
            for perm in required_permissions:
                if perm.value not in current_user.permissions:
                    missing_permissions.append(perm.value)
            
            if missing_permissions:
                request_id = secrets.token_urlsafe(8)
                
                # Log RBAC violation attempt (would integrate with audit system)
                rbac_violation = {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "user_id": current_user.id,
                    "username": current_user.username,
                    "role": current_user.role.value,
                    "attempted_action": func.__name__,
                    "required_permissions": [p.value for p in required_permissions],
                    "missing_permissions": missing_permissions,
                    "request_id": request_id
                }
                
                # In production, this would be logged to audit trail
                print(f"RBAC Violation: {rbac_violation}")
                
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail={
                        "error": "Insufficient permissions", 
                        "missing_permissions": missing_permissions,
                        "request_id": request_id
                    }
                )
            
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator

def require_role(*required_roles: UserRole):
    """Decorator to require specific roles with enhanced error handling"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: AuthUser = Depends(get_current_user), **kwargs):
            if current_user.role not in required_roles:
                request_id = secrets.token_urlsafe(8)
                
                # Log role violation attempt
                role_violation = {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "user_id": current_user.id,
                    "username": current_user.username,
                    "current_role": current_user.role.value,
                    "attempted_action": func.__name__,
                    "required_roles": [r.value for r in required_roles],
                    "request_id": request_id
                }
                
                # In production, this would be logged to audit trail
                print(f"Role Violation: {role_violation}")
                
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail={
                        "error": "Insufficient role access",
                        "required_roles": [r.value for r in required_roles],
                        "current_role": current_user.role.value,
                        "request_id": request_id
                    }
                )
            
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator

# =============================================================================
# Enhanced Authentication Functions
# =============================================================================

def authenticate_user_with_security(username: str, password: str, ip_address: str = None, user_agent: str = None) -> Optional[Dict]:
    """Authenticate user with enhanced security checks"""
    
    # Check account lockout first
    if check_account_lockout(username):
        return None
    
    # Find user
    user_data = None
    for user in USERS_DB.values():
        if user["username"] == username:
            user_data = user
            break
    
    if not user_data or not user_data["is_active"]:
        record_failed_attempt(username)
        return None
    
    # Verify password
    if not verify_password(password, user_data["password"]):
        record_failed_attempt(username)
        return None
    
    # Clear failed attempts on successful login
    clear_failed_attempts(username)
    
    # Create tokens with enhanced security
    access_token = create_access_token(user_data)
    refresh_token = create_refresh_token(user_data)
    
    # Record session metadata
    access_token_data = decode_token(access_token)
    if access_token_data:
        record_session_metadata(
            access_token_data.jti,
            ip_address=ip_address,
            user_agent=user_agent,
            additional_data={
                'user_id': user_data['id'],
                'login_method': 'password',
                'token_version': '2.0'  # Enhanced security version
            }
        )
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        "refresh_expires_in": REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
        "user": {
            "id": user_data["id"],
            "username": user_data["username"],
            "email": user_data["email"],
            "first_name": user_data["first_name"],
            "last_name": user_data["last_name"],
            "role": user_data["role"].value,
            "permissions": list(get_user_permissions(user_data["role"]))
        }
    }

def refresh_access_token(refresh_token: str, ip_address: str = None, user_agent: str = None) -> Optional[Dict]:
    """Refresh access token with security validation"""
    try:
        # Decode refresh token
        payload = jwt.decode(refresh_token, SECRET_KEY, algorithms=[ALGORITHM])
        
        # Check if refresh token is revoked
        jti = payload.get("jti")
        if jti in REVOKED_TOKENS:
            return None
        
        # Validate token type
        if payload.get("type") != "refresh":
            return None
        
        # Get user
        user_id = payload.get("user_id")
        user_data = None
        for user in USERS_DB.values():
            if user["id"] == user_id:
                user_data = user
                break
        
        if not user_data or not user_data["is_active"]:
            return None
        
        # Create new access token
        new_access_token = create_access_token(user_data)
        new_token_data = decode_token(new_access_token)
        
        if new_token_data:
            # Record session metadata for new token
            record_session_metadata(
                new_token_data.jti,
                ip_address=ip_address,
                user_agent=user_agent,
                additional_data={
                    'user_id': user_data['id'],
                    'refresh_from': jti,
                    'token_version': '2.0'
                }
            )
        
        return {
            "access_token": new_access_token,
            "token_type": "bearer",
            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
        }
        
    except JWTError:
        return None

def logout_user(access_token: str) -> bool:
    """Logout user by revoking their token"""
    try:
        token_data = decode_token(access_token)
        if token_data:
            revoke_token(token_data.jti)
            return True
    except Exception:
        pass
    
    return False

def change_password_with_security(user_id: str, old_password: str, new_password: str) -> bool:
    """Change user password with security validation"""
    
    # Get user
    user_data = None
    for user in USERS_DB.values():
        if user["id"] == user_id:
            user_data = user
            break
    
    if not user_data:
        return False
    
    # Verify old password
    if not verify_password(old_password, user_data["password"]):
        return False
    
    # Validate new password strength (basic validation)
    if len(new_password) < 8:
        return False
    
    # Update password
    user_data["password"] = get_password_hash(new_password)
    
    # Revoke all existing sessions to force re-login
    revoke_all_user_sessions(user_id)
    
    return True

# =============================================================================
# Resource-specific authorization helpers
# =============================================================================

def can_modify_work_order(user: AuthUser, work_order_assigned_to: str) -> bool:
    """Check if user can modify a specific work order"""
    # Admins and managers can modify any work order
    if user.role in [UserRole.ADMIN, UserRole.MANAGER]:
        return True
    
    # Technicians can only modify work orders assigned to them
    if user.role == UserRole.TECHNICIAN:
        return work_order_assigned_to == user.id
    
    return False

def can_view_time_entry(user: AuthUser, time_entry_technician_id: str) -> bool:
    """Check if user can view a specific time entry"""
    # Admins and managers can view all time entries
    if user.role in [UserRole.ADMIN, UserRole.MANAGER]:
        return True
    
    # Technicians can only view their own time entries
    if user.role == UserRole.TECHNICIAN:
        return time_entry_technician_id == user.id
    
    return False

def can_modify_time_entry(user: AuthUser, time_entry_technician_id: str) -> bool:
    """Check if user can modify a specific time entry"""
    # Admins and managers can modify any time entry
    if user.role in [UserRole.ADMIN, UserRole.MANAGER]:
        return True
    
    # Technicians can only modify their own time entries
    if user.role == UserRole.TECHNICIAN:
        return time_entry_technician_id == user.id
    
    return False

# =============================================================================
# User Management Functions
# =============================================================================

def create_user(username: str, email: str, password: str, first_name: str, 
                last_name: str, role: UserRole) -> Dict:
    """Create a new user"""
    if username in USERS_DB:
        raise ValueError("Username already exists")
    
    # Check email uniqueness
    for user in USERS_DB.values():
        if user["email"] == email:
            raise ValueError("Email already exists")
    
    user_id = f"user-{secrets.token_urlsafe(8)}"
    user_data = {
        "id": user_id,
        "username": username,
        "email": email,
        "first_name": first_name,
        "last_name": last_name,
        "password_hash": get_password_hash(password),
        "role": role,
        "is_active": True,
        "created_date": datetime.now(timezone.utc),
        "last_login": None,
    }
    
    USERS_DB[username] = user_data
    return user_data

def get_user_by_id(user_id: str) -> Optional[Dict]:
    """Get user by ID"""
    for user in USERS_DB.values():
        if user["id"] == user_id:
            return user
    return None

def get_user_by_username(username: str) -> Optional[Dict]:
    """Get user by username"""
    return USERS_DB.get(username)

def update_user(username: str, **updates) -> Optional[Dict]:
    """Update user data"""
    user = USERS_DB.get(username)
    if not user:
        return None
    
    for key, value in updates.items():
        if key in ["email", "first_name", "last_name", "role", "is_active"]:
            user[key] = value
        elif key == "password":
            user["password_hash"] = get_password_hash(value)
    
    return user

def list_users() -> List[Dict]:
    """List all users (without password hashes)"""
    users = []
    for user in USERS_DB.values():
        user_copy = user.copy()
        user_copy.pop("password_hash", None)
        users.append(user_copy)
    return users

# =============================================================================
# Login/Logout Endpoints
# =============================================================================

def login_user(login_request: LoginRequest) -> LoginResponse:
    """Authenticate user and return tokens"""
    user = authenticate_user(login_request.username, login_request.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    
    access_token = create_access_token(user)
    refresh_token = create_refresh_token(user)
    
    auth_user = AuthUser(
        id=user["id"],
        username=user["username"],
        email=user["email"],
        first_name=user["first_name"],
        last_name=user["last_name"],
        role=user["role"],
        is_active=user["is_active"],
        permissions=get_user_permissions(user["role"])
    )
    
    return LoginResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=auth_user
    )

def logout_user(credentials: HTTPAuthorizationCredentials) -> Dict:
    """Logout user by revoking token"""
    token_data = decode_token(credentials.credentials)
    if token_data:
        revoke_token(token_data.jti)
    
    return {"message": "Successfully logged out"}

def refresh_access_token(refresh_token: str) -> Dict:
    """Refresh access token using refresh token"""
    try:
        payload = jwt.decode(refresh_token, SECRET_KEY, algorithms=[ALGORITHM])
        
        if payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid refresh token"
            )
        
        user_id = payload.get("user_id")
        user = get_user_by_id(user_id)
        
        if not user or not user["is_active"]:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive"
            )
        
        new_access_token = create_access_token(user)
        
        return {
            "access_token": new_access_token,
            "token_type": "bearer",
            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
        }
        
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )