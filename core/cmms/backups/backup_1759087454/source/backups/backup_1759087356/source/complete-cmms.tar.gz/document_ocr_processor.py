#!/usr/bin/env python3
"""
Document OCR and Manual Processing System
AI-powered document analysis, OCR, and intelligent information extraction
"""

import os
import json
import logging
import asyncio
import base64
import io
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from PIL import Image
import pytesseract
import cv2
import numpy as np
from ai_model_provider import CentralizedAIProvider, AIResponse, AIProvider

logger = logging.getLogger(__name__)

# Document OCR router
ocr_router = APIRouter(prefix="/documents", tags=["documents"])

class DocumentType(Enum):
    """Document type enumeration"""
    NAMEPLATE = "nameplate"
    MANUAL = "manual"
    SCHEMATIC = "schematic"
    DATASHEET = "datasheet"
    CERTIFICATE = "certificate"
    INVOICE = "invoice"
    WORK_ORDER = "work_order"
    SAFETY_SHEET = "safety_sheet"
    UNKNOWN = "unknown"

class ProcessingStatus(Enum):
    """Processing status enumeration"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_REVIEW = "needs_review"

@dataclass
class ExtractedInformation:
    """Structured information extracted from documents"""
    document_type: DocumentType
    confidence: float
    manufacturer: Optional[str] = None
    model_number: Optional[str] = None
    serial_number: Optional[str] = None
    part_numbers: List[str] = field(default_factory=list)
    specifications: Dict[str, str] = field(default_factory=dict)
    safety_information: List[str] = field(default_factory=list)
    maintenance_procedures: List[str] = field(default_factory=list)
    contact_information: Dict[str, str] = field(default_factory=dict)
    raw_text: str = ""
    key_value_pairs: Dict[str, str] = field(default_factory=dict)

class DocumentUploadRequest(BaseModel):
    """Document upload request model"""
    document_name: str
    document_type: Optional[str] = None
    asset_id: Optional[str] = None
    expected_info: Optional[List[str]] = []  # What information to look for
    processing_options: Dict[str, Any] = {}

class OCRResult(BaseModel):
    """OCR processing result model"""
    document_id: str
    status: str
    confidence: float
    extracted_text: str
    extracted_information: Dict[str, Any]
    processing_time_ms: int
    suggestions: List[str]
    requires_review: bool

class DocumentOCRProcessor:
    """Advanced AI-powered document OCR and analysis system"""
    
    def __init__(self, ai_provider: Optional[CentralizedAIProvider] = None):
        self.ai_provider = ai_provider or CentralizedAIProvider()
        self.processed_documents = {}  # In-memory storage (would be database in production)
        self.template_patterns = self._load_template_patterns()
        self.equipment_database = self._load_equipment_database()
        
        # Configure Tesseract (adjust path as needed)
        # pytesseract.pytesseract.tesseract_cmd = r'/usr/bin/tesseract'  # Linux
        
    def _load_template_patterns(self) -> Dict[str, Any]:
        """Load common document template patterns"""
        return {
            "nameplate_patterns": [
                r"(?i)model[:\s]+([A-Z0-9\-]+)",
                r"(?i)serial[:\s#]+([A-Z0-9\-]+)",
                r"(?i)part[:\s#]+([A-Z0-9\-]+)",
                r"(?i)mfg[:\s]+([A-Z\s]+)",
                r"(?i)voltage[:\s]+(\d+(?:\.\d+)?\s*[V])",
                r"(?i)current[:\s]+(\d+(?:\.\d+)?\s*[A])",
                r"(?i)power[:\s]+(\d+(?:\.\d+)?\s*[WKM])",
                r"(?i)rpm[:\s]+(\d+)",
                r"(?i)pressure[:\s]+(\d+(?:\.\d+)?\s*(?:PSI|BAR|PA))"
            ],
            "manual_patterns": [
                r"(?i)maintenance\s+schedule",
                r"(?i)troubleshooting",
                r"(?i)parts\s+list",
                r"(?i)wiring\s+diagram",
                r"(?i)safety\s+precautions",
                r"(?i)operating\s+instructions"
            ],
            "safety_patterns": [
                r"(?i)warning",
                r"(?i)caution", 
                r"(?i)danger",
                r"(?i)hazard",
                r"(?i)ppe\s+required",
                r"(?i)lockout[/\s]*tagout",
                r"(?i)confined\s+space"
            ]
        }
    
    def _load_equipment_database(self) -> Dict[str, Any]:
        """Load equipment manufacturer and model database"""
        return {
            "manufacturers": {
                "abb": ["ABB", "ASEA Brown Boveri"],
                "siemens": ["Siemens", "Siemens AG"],
                "ge": ["General Electric", "GE"],
                "schneider": ["Schneider Electric", "Square D"],
                "allen_bradley": ["Allen-Bradley", "Rockwell"],
                "emerson": ["Emerson", "Fisher Controls"],
                "honeywell": ["Honeywell", "Honeywell Process"],
                "yokogawa": ["Yokogawa", "Yokogawa Electric"],
                "endress_hauser": ["Endress+Hauser", "E+H"],
                "rosemount": ["Rosemount", "Emerson Rosemount"]
            },
            "model_patterns": {
                "motor": [r"[A-Z]{2,4}\d{2,4}[A-Z]?", r"\d+HP", r"\d+KW"],
                "valve": [r"[A-Z]\d{3,4}[A-Z]?", r"DN\d+", r"\d+\""],
                "transmitter": [r"\d{4}[A-Z]{1,3}", r"[A-Z]{3}\d{3}"],
                "pump": [r"[A-Z]{2}\d{2,4}", r"[A-Z]\d+x\d+"]
            }
        }

    async def process_document(self, 
                             image_data: bytes, 
                             request: DocumentUploadRequest) -> OCRResult:
        """Main document processing pipeline"""
        
        start_time = datetime.now()
        document_id = f"DOC_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        try:
            # Step 1: Image preprocessing
            processed_image = self._preprocess_image(image_data)
            
            # Step 2: OCR text extraction
            raw_text = self._extract_text_ocr(processed_image)
            
            # Step 3: AI-enhanced text analysis
            extracted_info = await self._analyze_text_with_ai(
                raw_text, 
                request.document_type, 
                request.expected_info
            )
            
            # Step 4: Pattern matching and validation
            validated_info = self._validate_and_enhance_extraction(extracted_info, raw_text)
            
            # Step 5: Confidence assessment
            confidence = self._calculate_confidence(validated_info, raw_text)
            
            # Step 6: Generate suggestions and recommendations
            suggestions = self._generate_suggestions(validated_info, request)
            
            processing_time = int((datetime.now() - start_time).total_seconds() * 1000)
            requires_review = confidence < 0.8 or validated_info.document_type == DocumentType.UNKNOWN
            
            # Store processed document
            self.processed_documents[document_id] = {
                "request": request,
                "raw_text": raw_text,
                "extracted_info": validated_info,
                "processed_at": datetime.now().isoformat(),
                "confidence": confidence
            }
            
            return OCRResult(
                document_id=document_id,
                status=ProcessingStatus.COMPLETED.value,
                confidence=confidence,
                extracted_text=raw_text,
                extracted_information=self._serialize_extracted_info(validated_info),
                processing_time_ms=processing_time,
                suggestions=suggestions,
                requires_review=requires_review
            )
            
        except Exception as e:
            logger.error(f"Document processing failed: {e}")
            processing_time = int((datetime.now() - start_time).total_seconds() * 1000)
            
            return OCRResult(
                document_id=document_id,
                status=ProcessingStatus.FAILED.value,
                confidence=0.0,
                extracted_text="",
                extracted_information={},
                processing_time_ms=processing_time,
                suggestions=["Document processing failed - please try again or contact support"],
                requires_review=True
            )
    
    def _preprocess_image(self, image_data: bytes) -> np.ndarray:
        """Preprocess image for better OCR accuracy"""
        try:
            # Load image
            image = Image.open(io.BytesIO(image_data))
            img_array = np.array(image)
            
            # Convert to grayscale if needed
            if len(img_array.shape) == 3:
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            else:
                gray = img_array
            
            # Apply image enhancements
            # 1. Noise reduction
            denoised = cv2.fastNlMeansDenoising(gray)
            
            # 2. Contrast enhancement
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            enhanced = clahe.apply(denoised)
            
            # 3. Adaptive thresholding
            thresh = cv2.adaptiveThreshold(
                enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
            
            # 4. Morphological operations to clean up
            kernel = np.ones((1,1), np.uint8)
            cleaned = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
            
            return cleaned
            
        except Exception as e:
            logger.error(f"Image preprocessing failed: {e}")
            # Return original image as fallback
            image = Image.open(io.BytesIO(image_data))
            return np.array(image)
    
    def _extract_text_ocr(self, processed_image: np.ndarray) -> str:
        """Extract text using OCR with optimized settings"""
        try:
            # Configure Tesseract for better accuracy
            custom_config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,:-#/\()[] '
            
            # Extract text
            text = pytesseract.image_to_string(processed_image, config=custom_config)
            
            # Clean up text
            cleaned_text = self._clean_ocr_text(text)
            
            return cleaned_text
            
        except Exception as e:
            logger.error(f"OCR text extraction failed: {e}")
            return "OCR extraction failed"
    
    def _clean_ocr_text(self, text: str) -> str:
        """Clean and normalize OCR text"""
        import re
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove common OCR artifacts
        text = re.sub(r'[|]{2,}', '', text)  # Remove multiple pipes
        text = re.sub(r'[-_]{3,}', '', text)  # Remove long dashes/underscores
        
        # Fix common character substitutions
        substitutions = {
            '0': ['O', 'o'],  # Numbers for letters
            '1': ['I', 'l'],
            '5': ['S'],
            '8': ['B'],
        }
        
        # Apply context-aware substitutions (simplified)
        # In production, this would be more sophisticated
        
        return text.strip()

    async def _analyze_text_with_ai(self, 
                                  text: str, 
                                  document_type: Optional[str], 
                                  expected_info: Optional[List[str]]) -> ExtractedInformation:
        """Use AI to analyze and extract structured information"""
        
        analysis_prompt = f"""You are an expert document analyst specializing in industrial equipment documentation. 
Analyze this OCR text and extract structured information.

Document Type: {document_type or 'unknown'}
Expected Information: {', '.join(expected_info) if expected_info else 'general'}

OCR Text:
{text}

Extract and return JSON with these fields:
{{
    "document_type": "nameplate|manual|schematic|datasheet|certificate|work_order|safety_sheet|unknown",
    "confidence": 0.0-1.0,
    "manufacturer": "manufacturer name if found",
    "model_number": "model/part number if found",
    "serial_number": "serial number if found", 
    "part_numbers": ["list of part numbers found"],
    "specifications": {{"spec_name": "spec_value", ...}},
    "safety_information": ["safety warnings/instructions"],
    "maintenance_procedures": ["maintenance steps if found"],
    "contact_information": {{"type": "contact_details"}},
    "key_value_pairs": {{"key": "value", ...}}
}}

Be precise and only include information you're confident about. Mark uncertain extractions with low confidence."""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=analysis_prompt,
                system_context="You are an expert in industrial equipment documentation and technical specifications.",
                provider_type=AIProvider.LLAMA
            )
            
            # Parse AI response
            extracted_info = self._parse_ai_extraction_response(ai_response.content if ai_response else "")
            extracted_info.raw_text = text
            
            return extracted_info
            
        except Exception as e:
            logger.error(f"AI text analysis failed: {e}")
            return self._fallback_text_analysis(text, document_type)
    
    def _parse_ai_extraction_response(self, ai_response: str) -> ExtractedInformation:
        """Parse AI extraction response"""
        try:
            import json
            import re
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
            if json_match:
                parsed_data = json.loads(json_match.group())
                
                return ExtractedInformation(
                    document_type=DocumentType(parsed_data.get("document_type", "unknown")),
                    confidence=parsed_data.get("confidence", 0.5),
                    manufacturer=parsed_data.get("manufacturer"),
                    model_number=parsed_data.get("model_number"),
                    serial_number=parsed_data.get("serial_number"),
                    part_numbers=parsed_data.get("part_numbers", []),
                    specifications=parsed_data.get("specifications", {}),
                    safety_information=parsed_data.get("safety_information", []),
                    maintenance_procedures=parsed_data.get("maintenance_procedures", []),
                    contact_information=parsed_data.get("contact_information", {}),
                    key_value_pairs=parsed_data.get("key_value_pairs", {})
                )
                
        except Exception as e:
            logger.error(f"Failed to parse AI response: {e}")
        
        # Fallback
        return ExtractedInformation(
            document_type=DocumentType.UNKNOWN,
            confidence=0.3,
            raw_text=ai_response[:500]  # Store partial response
        )
    
    def _fallback_text_analysis(self, text: str, document_type: Optional[str]) -> ExtractedInformation:
        """Fallback text analysis using regex patterns"""
        import re
        
        extracted = ExtractedInformation(
            document_type=DocumentType(document_type) if document_type else DocumentType.UNKNOWN,
            confidence=0.6,
            raw_text=text
        )
        
        # Apply regex patterns from templates
        if "nameplate_patterns" in self.template_patterns:
            for pattern in self.template_patterns["nameplate_patterns"]:
                matches = re.findall(pattern, text)
                if matches:
                    # Determine what was matched based on pattern
                    if "model" in pattern.lower():
                        extracted.model_number = matches[0]
                    elif "serial" in pattern.lower():
                        extracted.serial_number = matches[0]
                    elif "part" in pattern.lower():
                        extracted.part_numbers.append(matches[0])
                    elif "voltage" in pattern.lower():
                        extracted.specifications["voltage"] = matches[0]
                    elif "current" in pattern.lower():
                        extracted.specifications["current"] = matches[0]
                    elif "power" in pattern.lower():
                        extracted.specifications["power"] = matches[0]
        
        # Look for manufacturer names
        text_upper = text.upper()
        for mfg_key, mfg_names in self.equipment_database["manufacturers"].items():
            for name in mfg_names:
                if name.upper() in text_upper:
                    extracted.manufacturer = name
                    break
        
        # Look for safety information
        if any(pattern in text.lower() for pattern in ["warning", "caution", "danger", "hazard"]):
            extracted.safety_information = ["Safety information detected - manual review required"]
        
        return extracted
    
    def _validate_and_enhance_extraction(self, extracted: ExtractedInformation, raw_text: str) -> ExtractedInformation:
        """Validate and enhance extracted information"""
        
        # Validate model numbers against known patterns
        if extracted.model_number and extracted.document_type == DocumentType.NAMEPLATE:
            # Check if model number matches expected patterns for equipment type
            is_valid = self._validate_model_number(extracted.model_number)
            if not is_valid:
                extracted.confidence *= 0.8  # Reduce confidence for suspicious model numbers
        
        # Enhance manufacturer information
        if extracted.manufacturer:
            normalized_mfg = self._normalize_manufacturer_name(extracted.manufacturer)
            if normalized_mfg:
                extracted.manufacturer = normalized_mfg
        
        # Cross-validate specifications
        if extracted.specifications:
            validated_specs = self._validate_specifications(extracted.specifications)
            extracted.specifications = validated_specs
        
        # Extract additional key-value pairs not caught by AI
        additional_kvp = self._extract_additional_key_values(raw_text)
        extracted.key_value_pairs.update(additional_kvp)
        
        return extracted
    
    def _validate_model_number(self, model_number: str) -> bool:
        """Validate model number format"""
        import re
        
        # Basic validation - contains alphanumeric characters
        if not re.match(r'^[A-Za-z0-9\-_]+$', model_number):
            return False
        
        # Length check
        if len(model_number) < 2 or len(model_number) > 20:
            return False
        
        return True
    
    def _normalize_manufacturer_name(self, manufacturer: str) -> Optional[str]:
        """Normalize manufacturer name to standard format"""
        mfg_lower = manufacturer.lower()
        
        for mfg_key, mfg_names in self.equipment_database["manufacturers"].items():
            for name in mfg_names:
                if name.lower() in mfg_lower or mfg_lower in name.lower():
                    return mfg_names[0]  # Return primary name
        
        return manufacturer  # Return as-is if not found
    
    def _validate_specifications(self, specifications: Dict[str, str]) -> Dict[str, str]:
        """Validate and clean specification values"""
        validated = {}
        
        for key, value in specifications.items():
            # Clean up the value
            cleaned_value = value.strip()
            
            # Validate based on key type
            if key.lower() in ["voltage", "current", "power", "frequency"]:
                # Should contain numbers and units
                import re
                if re.search(r'\d', cleaned_value):
                    validated[key] = cleaned_value
            else:
                validated[key] = cleaned_value
        
        return validated
    
    def _extract_additional_key_values(self, text: str) -> Dict[str, str]:
        """Extract additional key-value pairs from text"""
        import re
        
        kvp = {}
        
        # Common patterns for key-value extraction
        patterns = [
            r'(\w+):\s*([^\n\r]+)',  # Key: Value
            r'(\w+)\s*=\s*([^\n\r]+)',  # Key = Value  
            r'(\w+)\s+(\d+(?:\.\d+)?(?:\s*[A-Za-z]+)?)'  # Key Number Unit
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for key, value in matches:
                if len(key) > 1 and len(value) > 0:  # Basic quality filter
                    kvp[key.strip()] = value.strip()
        
        return kvp
    
    def _calculate_confidence(self, extracted: ExtractedInformation, raw_text: str) -> float:
        """Calculate overall confidence score"""
        confidence = extracted.confidence
        
        # Boost confidence based on amount of extracted information
        info_count = 0
        if extracted.manufacturer: info_count += 1
        if extracted.model_number: info_count += 1
        if extracted.serial_number: info_count += 1
        if extracted.part_numbers: info_count += len(extracted.part_numbers)
        if extracted.specifications: info_count += len(extracted.specifications)
        
        # Adjust confidence based on information richness
        if info_count >= 5:
            confidence = min(1.0, confidence + 0.2)
        elif info_count >= 3:
            confidence = min(1.0, confidence + 0.1)
        elif info_count == 0:
            confidence = max(0.1, confidence - 0.3)
        
        # Penalize if text is too short (likely poor OCR)
        if len(raw_text) < 50:
            confidence *= 0.7
        
        # Penalize if document type is unknown
        if extracted.document_type == DocumentType.UNKNOWN:
            confidence *= 0.8
        
        return round(confidence, 2)
    
    def _generate_suggestions(self, extracted: ExtractedInformation, request: DocumentUploadRequest) -> List[str]:
        """Generate helpful suggestions based on extraction results"""
        suggestions = []
        
        if extracted.confidence < 0.6:
            suggestions.append("Low confidence - consider rescanning with better lighting or resolution")
        
        if not extracted.manufacturer and extracted.document_type == DocumentType.NAMEPLATE:
            suggestions.append("Manufacturer not detected - look for company logos or text")
        
        if not extracted.model_number:
            suggestions.append("Model/part number not found - check for alphanumeric codes")
        
        if extracted.document_type == DocumentType.UNKNOWN:
            suggestions.append("Document type unclear - specify document type for better analysis")
        
        if extracted.safety_information:
            suggestions.append("Safety information detected - review safety requirements before maintenance")
        
        if request.asset_id and not extracted.serial_number:
            suggestions.append("Consider linking this document to asset record for future reference")
        
        if len(extracted.specifications) > 5:
            suggestions.append("Rich specification data found - consider updating equipment database")
        
        return suggestions[:5]  # Limit to top 5 suggestions
    
    def _serialize_extracted_info(self, extracted: ExtractedInformation) -> Dict[str, Any]:
        """Serialize extracted information for JSON response"""
        return {
            "document_type": extracted.document_type.value,
            "confidence": extracted.confidence,
            "manufacturer": extracted.manufacturer,
            "model_number": extracted.model_number,
            "serial_number": extracted.serial_number,
            "part_numbers": extracted.part_numbers,
            "specifications": extracted.specifications,
            "safety_information": extracted.safety_information,
            "maintenance_procedures": extracted.maintenance_procedures,
            "contact_information": extracted.contact_information,
            "key_value_pairs": extracted.key_value_pairs
        }

    async def generate_manual_summary(self, text: str) -> Dict[str, Any]:
        """Generate AI-powered summary of manual content"""
        
        summary_prompt = f"""You are an expert technical writer. Create a concise summary of this equipment manual text:

{text[:2000]}  # Limit text for processing

Provide:
1. Equipment overview
2. Key specifications
3. Important maintenance points
4. Safety considerations
5. Critical procedures

Format as structured summary suitable for technicians."""

        try:
            ai_response = await self.ai_provider.query_provider(
                prompt=summary_prompt,
                system_context="You are a technical documentation expert who creates clear, actionable summaries.",
                provider_type=AIProvider.LLAMA
            )
            
            return {
                "summary": ai_response.content if ai_response else "Summary generation unavailable",
                "generated_at": datetime.now().isoformat(),
                "text_length": len(text),
                "processing_confidence": "high" if ai_response else "low"
            }
            
        except Exception as e:
            logger.error(f"Manual summary generation failed: {e}")
            return {"error": "Summary generation failed"}

# Global instance
ocr_processor = DocumentOCRProcessor()

# API Endpoints
@ocr_router.post("/upload", response_model=OCRResult)
async def upload_document(
    file: UploadFile = File(...),
    document_name: str = Form(...),
    document_type: Optional[str] = Form(None),
    asset_id: Optional[str] = Form(None),
    expected_info: Optional[str] = Form(None)  # JSON string
):
    """Upload and process document with OCR"""
    
    # Validate file type
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="Only image files are supported")
    
    # Read image data
    image_data = await file.read()
    
    # Parse expected info if provided
    expected_info_list = []
    if expected_info:
        try:
            expected_info_list = json.loads(expected_info)
        except:
            pass
    
    # Create request
    request = DocumentUploadRequest(
        document_name=document_name,
        document_type=document_type,
        asset_id=asset_id,
        expected_info=expected_info_list
    )
    
    # Process document
    return await ocr_processor.process_document(image_data, request)

@ocr_router.get("/document/{document_id}")
async def get_document(document_id: str):
    """Get processed document information"""
    if document_id not in ocr_processor.processed_documents:
        raise HTTPException(status_code=404, detail="Document not found")
    
    return ocr_processor.processed_documents[document_id]

@ocr_router.post("/analyze-text")
async def analyze_text(text: str, document_type: Optional[str] = None):
    """Analyze raw text without OCR processing"""
    
    extracted_info = await ocr_processor._analyze_text_with_ai(
        text, document_type, []
    )
    
    return {
        "extracted_information": ocr_processor._serialize_extracted_info(extracted_info),
        "confidence": extracted_info.confidence,
        "suggestions": ocr_processor._generate_suggestions(
            extracted_info, 
            DocumentUploadRequest(document_name="text_analysis")
        )
    }

@ocr_router.post("/generate-summary")
async def generate_manual_summary(text: str):
    """Generate AI summary of manual content"""
    return await ocr_processor.generate_manual_summary(text)

@ocr_router.get("/supported-types")
async def get_supported_document_types():
    """Get supported document types"""
    return {
        "document_types": [doc_type.value for doc_type in DocumentType],
        "ocr_capabilities": [
            "Text extraction from images",
            "AI-powered information extraction", 
            "Pattern matching and validation",
            "Specification parsing",
            "Safety information detection",
            "Manufacturer/model identification"
        ]
    }

@ocr_router.get("/processing-stats")
async def get_processing_stats():
    """Get OCR processing statistics"""
    total_docs = len(ocr_processor.processed_documents)
    
    if total_docs == 0:
        return {"total_documents": 0, "average_confidence": 0.0}
    
    avg_confidence = sum(
        doc["confidence"] for doc in ocr_processor.processed_documents.values()
    ) / total_docs
    
    doc_type_counts = {}
    for doc in ocr_processor.processed_documents.values():
        doc_type = doc["extracted_info"].document_type.value
        doc_type_counts[doc_type] = doc_type_counts.get(doc_type, 0) + 1
    
    return {
        "total_documents": total_docs,
        "average_confidence": round(avg_confidence, 2),
        "document_type_breakdown": doc_type_counts,
        "last_processed": max(
            (doc["processed_at"] for doc in ocr_processor.processed_documents.values()),
            default=None
        )
    }

# Export main components
__all__ = ['ocr_router', 'DocumentOCRProcessor', 'ocr_processor', 'DocumentType', 'OCRResult']