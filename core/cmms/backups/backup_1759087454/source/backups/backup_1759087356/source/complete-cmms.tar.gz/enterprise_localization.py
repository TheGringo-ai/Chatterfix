#!/usr/bin/env python3
"""
ChatterFix CMMS - Enterprise Localization & Multi-Currency Platform
Global localization with multi-language and multi-currency support
"""

import os
import json
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_HALF_UP
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import JSONResponse
import requests
from babel import Locale, dates, numbers
from babel.support import Format
from babel.core import get_global

# Enterprise Localization Router
enterprise_localization_router = APIRouter(prefix="/cmms/enterprise/localization", tags=["Enterprise Localization"])

@dataclass
class LocalizationConfig:
    """Tenant localization configuration"""
    tenant_id: str
    primary_language: str = "en"
    supported_languages: List[str] = None
    primary_currency: str = "USD"
    supported_currencies: List[str] = None
    timezone: str = "UTC"
    date_format: str = "yyyy-MM-dd"
    time_format: str = "HH:mm:ss"
    number_format: str = "#,##0.##"
    currency_display: str = "symbol"  # symbol, code, name
    created_at: datetime = None
    updated_at: datetime = None

@dataclass
class TranslationEntry:
    """Translation entry for a specific key"""
    key: str
    language: str
    value: str
    context: Optional[str] = None
    plural_forms: Optional[Dict[str, str]] = None
    last_modified: datetime = None

@dataclass
class CurrencyRate:
    """Currency exchange rate"""
    from_currency: str
    to_currency: str
    rate: Decimal
    last_updated: datetime
    source: str = "exchange_api"

class EnterpriseLocalizationManager:
    """Enterprise localization and multi-currency manager"""
    
    def __init__(self):
        self.localization_configs: Dict[str, LocalizationConfig] = {}
        self.translations: Dict[str, Dict[str, TranslationEntry]] = {}  # {language: {key: entry}}
        self.currency_rates: Dict[Tuple[str, str], CurrencyRate] = {}
        
        # Initialize supported languages and currencies
        self.supported_languages = {
            "en": {"name": "English", "native": "English", "flag": "🇺🇸", "rtl": False},
            "es": {"name": "Spanish", "native": "Español", "flag": "🇪🇸", "rtl": False},
            "fr": {"name": "French", "native": "Français", "flag": "🇫🇷", "rtl": False},
            "de": {"name": "German", "native": "Deutsch", "flag": "🇩🇪", "rtl": False},
            "it": {"name": "Italian", "native": "Italiano", "flag": "🇮🇹", "rtl": False},
            "pt": {"name": "Portuguese", "native": "Português", "flag": "🇵🇹", "rtl": False},
            "ja": {"name": "Japanese", "native": "日本語", "flag": "🇯🇵", "rtl": False},
            "ko": {"name": "Korean", "native": "한국어", "flag": "🇰🇷", "rtl": False},
            "zh": {"name": "Chinese", "native": "中文", "flag": "🇨🇳", "rtl": False},
            "ru": {"name": "Russian", "native": "Русский", "flag": "🇷🇺", "rtl": False},
            "ar": {"name": "Arabic", "native": "العربية", "flag": "🇸🇦", "rtl": True},
            "hi": {"name": "Hindi", "native": "हिन्दी", "flag": "🇮🇳", "rtl": False},
            "nl": {"name": "Dutch", "native": "Nederlands", "flag": "🇳🇱", "rtl": False},
            "sv": {"name": "Swedish", "native": "Svenska", "flag": "🇸🇪", "rtl": False},
            "no": {"name": "Norwegian", "native": "Norsk", "flag": "🇳🇴", "rtl": False}
        }
        
        self.supported_currencies = {
            "USD": {"name": "US Dollar", "symbol": "$", "decimal_places": 2},
            "EUR": {"name": "Euro", "symbol": "€", "decimal_places": 2},
            "GBP": {"name": "British Pound", "symbol": "£", "decimal_places": 2},
            "JPY": {"name": "Japanese Yen", "symbol": "¥", "decimal_places": 0},
            "AUD": {"name": "Australian Dollar", "symbol": "A$", "decimal_places": 2},
            "CAD": {"name": "Canadian Dollar", "symbol": "C$", "decimal_places": 2},
            "CHF": {"name": "Swiss Franc", "symbol": "CHF", "decimal_places": 2},
            "CNY": {"name": "Chinese Yuan", "symbol": "¥", "decimal_places": 2},
            "KRW": {"name": "South Korean Won", "symbol": "₩", "decimal_places": 0},
            "BRL": {"name": "Brazilian Real", "symbol": "R$", "decimal_places": 2},
            "INR": {"name": "Indian Rupee", "symbol": "₹", "decimal_places": 2},
            "MXN": {"name": "Mexican Peso", "symbol": "$", "decimal_places": 2},
            "SGD": {"name": "Singapore Dollar", "symbol": "S$", "decimal_places": 2},
            "HKD": {"name": "Hong Kong Dollar", "symbol": "HK$", "decimal_places": 2},
            "NOK": {"name": "Norwegian Krone", "symbol": "kr", "decimal_places": 2},
            "SEK": {"name": "Swedish Krona", "symbol": "kr", "decimal_places": 2}
        }
        
        # Initialize demo configurations
        self._init_demo_configurations()
        self._init_base_translations()
        self._init_sample_currency_rates()
    
    def _init_demo_configurations(self):
        """Initialize demo localization configurations"""
        
        # North American Manufacturing
        self.localization_configs["demo_manufacturing"] = LocalizationConfig(
            tenant_id="demo_manufacturing",
            primary_language="en",
            supported_languages=["en", "es"],
            primary_currency="USD",
            supported_currencies=["USD", "CAD", "MXN"],
            timezone="America/New_York",
            date_format="MM/dd/yyyy",
            time_format="h:mm a"
        )
        
        # European Healthcare
        self.localization_configs["demo_healthcare"] = LocalizationConfig(
            tenant_id="demo_healthcare",
            primary_language="en",
            supported_languages=["en", "de", "fr", "it"],
            primary_currency="EUR",
            supported_currencies=["EUR", "CHF", "GBP"],
            timezone="Europe/Berlin",
            date_format="dd.MM.yyyy",
            time_format="HH:mm"
        )
        
        # Asian Logistics
        self.localization_configs["demo_logistics"] = LocalizationConfig(
            tenant_id="demo_logistics",
            primary_language="en",
            supported_languages=["en", "ja", "ko", "zh"],
            primary_currency="JPY",
            supported_currencies=["JPY", "KRW", "CNY", "SGD"],
            timezone="Asia/Tokyo",
            date_format="yyyy年MM月dd日",
            time_format="HH時mm分"
        )
        
        # Global Enterprise
        self.localization_configs["demo_global"] = LocalizationConfig(
            tenant_id="demo_global",
            primary_language="en",
            supported_languages=["en", "es", "fr", "de", "ja", "zh", "ar"],
            primary_currency="USD",
            supported_currencies=["USD", "EUR", "GBP", "JPY", "CNY", "INR", "BRL"],
            timezone="UTC",
            date_format="yyyy-MM-dd",
            time_format="HH:mm:ss"
        )
    
    def _init_base_translations(self):
        """Initialize base translations for core CMMS terms"""
        
        base_translations = {
            # Navigation & General
            "dashboard": {
                "en": "Dashboard",
                "es": "Panel de Control",
                "fr": "Tableau de Bord",
                "de": "Armaturenbrett",
                "it": "Pannello di Controllo",
                "ja": "ダッシュボード",
                "ko": "대시보드",
                "zh": "仪表盘",
                "ru": "Панель управления",
                "ar": "لوحة المراقبة"
            },
            
            "work_orders": {
                "en": "Work Orders",
                "es": "Órdenes de Trabajo",
                "fr": "Ordres de Travail",
                "de": "Arbeitsaufträge",
                "it": "Ordini di Lavoro",
                "ja": "作業指示書",
                "ko": "작업 주문",
                "zh": "工单",
                "ru": "Наряды на работу",
                "ar": "أوامر العمل"
            },
            
            "assets": {
                "en": "Assets",
                "es": "Activos",
                "fr": "Actifs",
                "de": "Anlagen",
                "it": "Beni",
                "ja": "資産",
                "ko": "자산",
                "zh": "资产",
                "ru": "Активы",
                "ar": "الأصول"
            },
            
            "maintenance": {
                "en": "Maintenance",
                "es": "Mantenimiento",
                "fr": "Maintenance",
                "de": "Wartung",
                "it": "Manutenzione",
                "ja": "保守",
                "ko": "유지보수",
                "zh": "维护",
                "ru": "Техническое обслуживание",
                "ar": "الصيانة"
            },
            
            "inventory": {
                "en": "Inventory",
                "es": "Inventario",
                "fr": "Inventaire",
                "de": "Bestand",
                "it": "Inventario",
                "ja": "在庫",
                "ko": "재고",
                "zh": "库存",
                "ru": "Инвентарь",
                "ar": "المخزون"
            },
            
            "reports": {
                "en": "Reports",
                "es": "Reportes",
                "fr": "Rapports",
                "de": "Berichte",
                "it": "Rapporti",
                "ja": "レポート",
                "ko": "보고서",
                "zh": "报告",
                "ru": "Отчеты",
                "ar": "التقارير"
            },
            
            # Status Terms
            "pending": {
                "en": "Pending",
                "es": "Pendiente",
                "fr": "En Attente",
                "de": "Ausstehend",
                "it": "In Attesa",
                "ja": "保留中",
                "ko": "대기 중",
                "zh": "待处理",
                "ru": "Ожидается",
                "ar": "معلق"
            },
            
            "in_progress": {
                "en": "In Progress",
                "es": "En Progreso",
                "fr": "En Cours",
                "de": "In Bearbeitung",
                "it": "In Corso",
                "ja": "進行中",
                "ko": "진행 중",
                "zh": "进行中",
                "ru": "В процессе",
                "ar": "قيد التنفيذ"
            },
            
            "completed": {
                "en": "Completed",
                "es": "Completado",
                "fr": "Terminé",
                "de": "Abgeschlossen",
                "it": "Completato",
                "ja": "完了",
                "ko": "완료",
                "zh": "已完成",
                "ru": "Завершено",
                "ar": "مكتمل"
            },
            
            # Priority Levels
            "high_priority": {
                "en": "High Priority",
                "es": "Alta Prioridad",
                "fr": "Priorité Élevée",
                "de": "Hohe Priorität",
                "it": "Priorità Alta",
                "ja": "高優先度",
                "ko": "높은 우선순위",
                "zh": "高优先级",
                "ru": "Высокий приоритет",
                "ar": "أولوية عالية"
            },
            
            "critical": {
                "en": "Critical",
                "es": "Crítico",
                "fr": "Critique",
                "de": "Kritisch",
                "it": "Critico",
                "ja": "緊急",
                "ko": "중요",
                "zh": "关键",
                "ru": "Критический",
                "ar": "بالغ الأهمية"
            },
            
            # Actions
            "create": {
                "en": "Create",
                "es": "Crear",
                "fr": "Créer",
                "de": "Erstellen",
                "it": "Creare",
                "ja": "作成",
                "ko": "생성",
                "zh": "创建",
                "ru": "Создать",
                "ar": "إنشاء"
            },
            
            "edit": {
                "en": "Edit",
                "es": "Editar",
                "fr": "Modifier",
                "de": "Bearbeiten",
                "it": "Modificare",
                "ja": "編集",
                "ko": "편집",
                "zh": "编辑",
                "ru": "Редактировать",
                "ar": "تحرير"
            },
            
            "delete": {
                "en": "Delete",
                "es": "Eliminar",
                "fr": "Supprimer",
                "de": "Löschen",
                "it": "Eliminare",
                "ja": "削除",
                "ko": "삭제",
                "zh": "删除",
                "ru": "Удалить",
                "ar": "حذف"
            },
            
            "save": {
                "en": "Save",
                "es": "Guardar",
                "fr": "Enregistrer",
                "de": "Speichern",
                "it": "Salvare",
                "ja": "保存",
                "ko": "저장",
                "zh": "保存",
                "ru": "Сохранить",
                "ar": "حفظ"
            }
        }
        
        # Convert to TranslationEntry objects
        for key, translations in base_translations.items():
            for language, value in translations.items():
                if language not in self.translations:
                    self.translations[language] = {}
                
                self.translations[language][key] = TranslationEntry(
                    key=key,
                    language=language,
                    value=value,
                    last_modified=datetime.utcnow()
                )
    
    def _init_sample_currency_rates(self):
        """Initialize sample currency exchange rates"""
        # Sample rates (in production, fetch from real API)
        sample_rates = [
            ("USD", "EUR", Decimal("0.85")),
            ("USD", "GBP", Decimal("0.73")),
            ("USD", "JPY", Decimal("110.25")),
            ("USD", "CAD", Decimal("1.25")),
            ("USD", "AUD", Decimal("1.35")),
            ("USD", "CHF", Decimal("0.92")),
            ("USD", "CNY", Decimal("6.45")),
            ("USD", "KRW", Decimal("1180.50")),
            ("USD", "BRL", Decimal("5.20")),
            ("USD", "INR", Decimal("74.85")),
            ("EUR", "GBP", Decimal("0.86")),
            ("EUR", "JPY", Decimal("129.70")),
            ("GBP", "JPY", Decimal("151.00"))
        ]
        
        for from_curr, to_curr, rate in sample_rates:
            self.currency_rates[(from_curr, to_curr)] = CurrencyRate(
                from_currency=from_curr,
                to_currency=to_curr,
                rate=rate,
                last_updated=datetime.utcnow(),
                source="demo_data"
            )
            
            # Add reverse rate
            reverse_rate = Decimal("1") / rate
            self.currency_rates[(to_curr, from_curr)] = CurrencyRate(
                from_currency=to_curr,
                to_currency=from_curr,
                rate=reverse_rate.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP),
                last_updated=datetime.utcnow(),
                source="demo_data"
            )
    
    def get_translation(self, key: str, language: str, default: Optional[str] = None) -> str:
        """Get translation for a key in specified language"""
        if language in self.translations and key in self.translations[language]:
            return self.translations[language][key].value
        
        # Fallback to English
        if language != "en" and "en" in self.translations and key in self.translations["en"]:
            return self.translations["en"][key].value
        
        return default or key
    
    def convert_currency(self, amount: Decimal, from_currency: str, to_currency: str) -> Decimal:
        """Convert amount from one currency to another"""
        if from_currency == to_currency:
            return amount
        
        rate_key = (from_currency, to_currency)
        if rate_key in self.currency_rates:
            rate = self.currency_rates[rate_key].rate
            return (amount * rate).quantize(
                Decimal("0.01") if self.supported_currencies[to_currency]["decimal_places"] == 2 else Decimal("1"),
                rounding=ROUND_HALF_UP
            )
        
        raise ValueError(f"Exchange rate not available for {from_currency} to {to_currency}")
    
    def format_currency(self, amount: Decimal, currency: str, language: str = "en") -> str:
        """Format currency amount according to locale"""
        try:
            locale = Locale(language)
            currency_info = self.supported_currencies.get(currency, {})
            
            return numbers.format_currency(
                float(amount),
                currency,
                locale=locale
            )
        except Exception:
            # Fallback formatting
            currency_info = self.supported_currencies.get(currency, {})
            symbol = currency_info.get("symbol", currency)
            return f"{symbol}{amount:,.2f}"
    
    def format_date(self, date_obj: datetime, language: str = "en", format_pattern: str = None) -> str:
        """Format date according to locale"""
        try:
            locale = Locale(language)
            return dates.format_date(date_obj, locale=locale)
        except Exception:
            return date_obj.strftime("%Y-%m-%d")
    
    def format_number(self, number: float, language: str = "en") -> str:
        """Format number according to locale"""
        try:
            locale = Locale(language)
            return numbers.format_number(number, locale=locale)
        except Exception:
            return f"{number:,}"

# Localization API Endpoints

@enterprise_localization_router.get("/config/{tenant_id}")
async def get_localization_config(tenant_id: str):
    """Get localization configuration for tenant"""
    manager = EnterpriseLocalizationManager()
    
    config = manager.localization_configs.get(tenant_id)
    if not config:
        # Return default config
        config = LocalizationConfig(tenant_id=tenant_id)
    
    return JSONResponse({
        "success": True,
        "config": asdict(config)
    })

@enterprise_localization_router.put("/config/{tenant_id}")
async def update_localization_config(tenant_id: str, config_data: dict):
    """Update localization configuration"""
    manager = EnterpriseLocalizationManager()
    
    try:
        config = LocalizationConfig(
            tenant_id=tenant_id,
            primary_language=config_data.get("primary_language", "en"),
            supported_languages=config_data.get("supported_languages", ["en"]),
            primary_currency=config_data.get("primary_currency", "USD"),
            supported_currencies=config_data.get("supported_currencies", ["USD"]),
            timezone=config_data.get("timezone", "UTC"),
            date_format=config_data.get("date_format", "yyyy-MM-dd"),
            time_format=config_data.get("time_format", "HH:mm:ss"),
            updated_at=datetime.utcnow()
        )
        
        manager.localization_configs[tenant_id] = config
        
        return JSONResponse({
            "success": True,
            "message": "Localization configuration updated successfully",
            "config": asdict(config)
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update config: {str(e)}")

@enterprise_localization_router.get("/translations/{language}")
async def get_translations(language: str, keys: Optional[List[str]] = Query(None)):
    """Get translations for specified language"""
    manager = EnterpriseLocalizationManager()
    
    if language not in manager.translations:
        raise HTTPException(status_code=404, detail=f"Language '{language}' not supported")
    
    translations = manager.translations[language]
    
    if keys:
        filtered_translations = {key: entry.value for key, entry in translations.items() if key in keys}
    else:
        filtered_translations = {key: entry.value for key, entry in translations.items()}
    
    return JSONResponse({
        "success": True,
        "language": language,
        "translations": filtered_translations,
        "total": len(filtered_translations)
    })

@enterprise_localization_router.post("/translations/{language}")
async def add_translation(language: str, translation_data: dict):
    """Add or update translation for specified language"""
    manager = EnterpriseLocalizationManager()
    
    try:
        key = translation_data["key"]
        value = translation_data["value"]
        context = translation_data.get("context")
        
        if language not in manager.translations:
            manager.translations[language] = {}
        
        manager.translations[language][key] = TranslationEntry(
            key=key,
            language=language,
            value=value,
            context=context,
            last_modified=datetime.utcnow()
        )
        
        return JSONResponse({
            "success": True,
            "message": f"Translation added for '{key}' in {language}",
            "translation": {
                "key": key,
                "language": language,
                "value": value
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to add translation: {str(e)}")

@enterprise_localization_router.get("/currency/rates")
async def get_currency_rates(base_currency: str = "USD"):
    """Get current currency exchange rates"""
    manager = EnterpriseLocalizationManager()
    
    rates = {}
    for (from_curr, to_curr), rate_info in manager.currency_rates.items():
        if from_curr == base_currency:
            rates[to_curr] = {
                "rate": float(rate_info.rate),
                "last_updated": rate_info.last_updated.isoformat(),
                "source": rate_info.source
            }
    
    return JSONResponse({
        "success": True,
        "base_currency": base_currency,
        "rates": rates,
        "timestamp": datetime.utcnow().isoformat()
    })

@enterprise_localization_router.post("/currency/convert")
async def convert_currency_amount(conversion_data: dict):
    """Convert currency amount"""
    manager = EnterpriveLocalizationManager()
    
    try:
        amount = Decimal(str(conversion_data["amount"]))
        from_currency = conversion_data["from_currency"]
        to_currency = conversion_data["to_currency"]
        language = conversion_data.get("language", "en")
        
        converted_amount = manager.convert_currency(amount, from_currency, to_currency)
        formatted_amount = manager.format_currency(converted_amount, to_currency, language)
        
        return JSONResponse({
            "success": True,
            "original_amount": float(amount),
            "converted_amount": float(converted_amount),
            "formatted_amount": formatted_amount,
            "from_currency": from_currency,
            "to_currency": to_currency,
            "exchange_rate": float(manager.currency_rates.get((from_currency, to_currency), CurrencyRate("", "", Decimal("1"), datetime.utcnow())).rate)
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Currency conversion failed: {str(e)}")

@enterprise_localization_router.get("/languages")
async def get_supported_languages():
    """Get list of supported languages with details"""
    manager = EnterpriseLocalizationManager()
    
    return JSONResponse({
        "success": True,
        "supported_languages": manager.supported_languages,
        "total": len(manager.supported_languages)
    })

@enterprise_localization_router.get("/currencies")
async def get_supported_currencies():
    """Get list of supported currencies with details"""
    manager = EnterpriseLocalizationManager()
    
    return JSONResponse({
        "success": True,
        "supported_currencies": manager.supported_currencies,
        "total": len(manager.supported_currencies)
    })

@enterprise_localization_router.get("/demo-configs")
async def get_demo_localization_configs():
    """Get demo localization configurations"""
    manager = EnterpriseLocalizationManager()
    
    demo_configs = {}
    for tenant_id, config in manager.localization_configs.items():
        demo_configs[tenant_id] = asdict(config)
    
    return JSONResponse({
        "success": True,
        "demo_configurations": demo_configs,
        "available_languages": list(manager.supported_languages.keys()),
        "available_currencies": list(manager.supported_currencies.keys())
    })

if __name__ == "__main__":
    # Demo the localization system
    manager = EnterpriseLocalizationManager()
    
    print("\n🌍 ChatterFix Enterprise Localization & Multi-Currency Platform")
    print("=" * 70)
    
    print(f"\n📋 Demo Configurations: {len(manager.localization_configs)}")
    for tenant_id, config in manager.localization_configs.items():
        print(f"   • {tenant_id}")
        print(f"     Languages: {', '.join(config.supported_languages)}")
        print(f"     Currencies: {', '.join(config.supported_currencies)}")
        print(f"     Timezone: {config.timezone}")
    
    print(f"\n🗣️ Supported Languages: {len(manager.supported_languages)}")
    for lang_code, lang_info in manager.supported_languages.items():
        print(f"   • {lang_info['flag']} {lang_info['native']} ({lang_code})")
    
    print(f"\n💰 Supported Currencies: {len(manager.supported_currencies)}")
    for curr_code, curr_info in manager.supported_currencies.items():
        print(f"   • {curr_info['symbol']} {curr_info['name']} ({curr_code})")
    
    print(f"\n📚 Base Translations: {len(manager.translations)} languages")
    for language in manager.translations.keys():
        translation_count = len(manager.translations[language])
        print(f"   • {language}: {translation_count} terms")
    
    print(f"\n💱 Exchange Rates: {len(manager.currency_rates)} pairs")
    
    # Demo currency conversion
    try:
        amount = Decimal("1000")
        converted = manager.convert_currency(amount, "USD", "EUR")
        formatted = manager.format_currency(converted, "EUR", "en")
        print(f"\n💸 Demo Conversion: $1,000 USD = {formatted}")
    except Exception as e:
        print(f"   Conversion error: {e}")
    
    # Demo translations
    print(f"\n🔄 Demo Translations:")
    test_keys = ["work_orders", "maintenance", "critical"]
    for key in test_keys:
        print(f"   • {key}:")
        for lang in ["en", "es", "de", "ja"]:
            translation = manager.get_translation(key, lang)
            print(f"     {lang}: {translation}")
    
    print("\n✅ Localization Platform Ready!")