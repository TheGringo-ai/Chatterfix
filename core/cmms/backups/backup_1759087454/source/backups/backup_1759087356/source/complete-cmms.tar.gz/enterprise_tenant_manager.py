#!/usr/bin/env python3
"""
ChatterFix Enterprise Multi-Tenant Architecture
Advanced tenant isolation, resource management, and enterprise scalability
"""

import os
import json
import logging
import asyncio
import hashlib
import secrets
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass

from fastapi import APIRouter, HTTPException, Depends, Request, Header
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, validator
import jwt
from passlib.context import CryptContext

logger = logging.getLogger(__name__)

# Enterprise tenant router
enterprise_router = APIRouter(prefix="/enterprise", tags=["enterprise-management"])

class TenantTier(str, Enum):
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"
    ENTERPRISE_PLUS = "enterprise_plus"

class TenantStatus(str, Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    TRIAL = "trial"
    PENDING = "pending"
    CANCELLED = "cancelled"

@dataclass
class TenantLimits:
    max_users: int
    max_assets: int
    max_work_orders_per_month: int
    max_storage_gb: int
    api_rate_limit_per_minute: int
    ai_features_enabled: bool
    predictive_maintenance: bool
    white_label: bool
    custom_integrations: bool
    priority_support: bool

class TenantConfig(BaseModel):
    tenant_id: str
    tenant_name: str
    domain: str
    tier: TenantTier
    status: TenantStatus
    limits: Dict[str, Any]
    features: Dict[str, bool]
    branding: Dict[str, Any]
    integrations: List[str]
    billing_info: Dict[str, Any]
    created_at: str
    updated_at: str
    expires_at: Optional[str] = None

class TenantUser(BaseModel):
    user_id: str
    tenant_id: str
    email: str
    role: str
    permissions: List[str]
    is_active: bool
    created_at: str
    last_login: Optional[str] = None

class TenantUsage(BaseModel):
    tenant_id: str
    period_start: str
    period_end: str
    users_count: int
    assets_count: int
    work_orders_count: int
    storage_used_gb: float
    api_calls_count: int
    ai_predictions_count: int
    cost_breakdown: Dict[str, float]

class EnterpriseMultiTenantManager:
    def __init__(self):
        self.tenants: Dict[str, TenantConfig] = {}
        self.tenant_users: Dict[str, List[TenantUser]] = {}
        self.usage_tracking: Dict[str, List[TenantUsage]] = {}
        self.tenant_databases: Dict[str, str] = {}
        self.security = HTTPBearer()
        self.pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        self.jwt_secret = os.getenv("JWT_SECRET", secrets.token_urlsafe(32))
        
        # Initialize tier limits
        self.tier_limits = {
            TenantTier.STARTER: TenantLimits(
                max_users=5,
                max_assets=50,
                max_work_orders_per_month=200,
                max_storage_gb=5,
                api_rate_limit_per_minute=100,
                ai_features_enabled=True,
                predictive_maintenance=False,
                white_label=False,
                custom_integrations=False,
                priority_support=False
            ),
            TenantTier.PROFESSIONAL: TenantLimits(
                max_users=25,
                max_assets=500,
                max_work_orders_per_month=2000,
                max_storage_gb=50,
                api_rate_limit_per_minute=500,
                ai_features_enabled=True,
                predictive_maintenance=True,
                white_label=False,
                custom_integrations=True,
                priority_support=True
            ),
            TenantTier.ENTERPRISE: TenantLimits(
                max_users=100,
                max_assets=2000,
                max_work_orders_per_month=10000,
                max_storage_gb=500,
                api_rate_limit_per_minute=2000,
                ai_features_enabled=True,
                predictive_maintenance=True,
                white_label=True,
                custom_integrations=True,
                priority_support=True
            ),
            TenantTier.ENTERPRISE_PLUS: TenantLimits(
                max_users=1000,
                max_assets=10000,
                max_work_orders_per_month=100000,
                max_storage_gb=5000,
                api_rate_limit_per_minute=10000,
                ai_features_enabled=True,
                predictive_maintenance=True,
                white_label=True,
                custom_integrations=True,
                priority_support=True
            )
        }
        
        # Initialize demo tenants
        asyncio.create_task(self.initialize_demo_tenants())
    
    async def initialize_demo_tenants(self):
        """Initialize demo tenants for different tiers"""
        try:
            logger.info("🏢 Initializing enterprise demo tenants...")
            
            demo_tenants = [
                {
                    "tenant_id": "tenant_acme_corp",
                    "tenant_name": "ACME Corporation",
                    "domain": "acme.chatterfix.com",
                    "tier": TenantTier.ENTERPRISE,
                    "status": TenantStatus.ACTIVE,
                    "branding": {
                        "logo_url": "https://acme.com/logo.png",
                        "primary_color": "#2E86AB",
                        "secondary_color": "#A23B72",
                        "company_name": "ACME Corporation"
                    },
                    "integrations": ["sap", "microsoft_365", "tableau"],
                    "billing_info": {
                        "plan": "Enterprise Annual",
                        "monthly_cost": 2500.00,
                        "currency": "USD",
                        "billing_contact": "billing@acme.com"
                    }
                },
                {
                    "tenant_id": "tenant_global_mfg",
                    "tenant_name": "Global Manufacturing Inc",
                    "domain": "globalmfg.chatterfix.com",
                    "tier": TenantTier.ENTERPRISE_PLUS,
                    "status": TenantStatus.ACTIVE,
                    "branding": {
                        "logo_url": "https://globalmfg.com/brand.png",
                        "primary_color": "#1B4332",
                        "secondary_color": "#95D5B2",
                        "company_name": "Global Manufacturing Inc"
                    },
                    "integrations": ["oracle", "sap", "google_workspace", "power_bi"],
                    "billing_info": {
                        "plan": "Enterprise Plus Annual",
                        "monthly_cost": 8500.00,
                        "currency": "USD",
                        "billing_contact": "finance@globalmfg.com"
                    }
                },
                {
                    "tenant_id": "tenant_startup_demo",
                    "tenant_name": "TechStart Solutions",
                    "domain": "techstart.chatterfix.com",
                    "tier": TenantTier.PROFESSIONAL,
                    "status": TenantStatus.TRIAL,
                    "branding": {
                        "logo_url": "https://techstart.com/logo-sm.png",
                        "primary_color": "#7209B7",
                        "secondary_color": "#F72585",
                        "company_name": "TechStart Solutions"
                    },
                    "integrations": ["quickbooks", "slack"],
                    "billing_info": {
                        "plan": "Professional Trial",
                        "monthly_cost": 0.00,
                        "currency": "USD",
                        "trial_expires": (datetime.now() + timedelta(days=30)).isoformat()
                    }
                }
            ]
            
            for tenant_data in demo_tenants:
                await self.create_tenant(tenant_data)
            
            logger.info("✅ Enterprise demo tenants initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize demo tenants: {e}")
    
    async def create_tenant(self, tenant_data: Dict[str, Any]) -> TenantConfig:
        """Create new tenant with proper isolation"""
        try:
            tenant_id = tenant_data["tenant_id"]
            tier = TenantTier(tenant_data["tier"])
            
            # Get tier limits
            limits = self.tier_limits[tier]
            
            # Create tenant configuration
            tenant_config = TenantConfig(
                tenant_id=tenant_id,
                tenant_name=tenant_data["tenant_name"],
                domain=tenant_data["domain"],
                tier=tier,
                status=TenantStatus(tenant_data["status"]),
                limits=limits.__dict__,
                features={
                    "ai_features": limits.ai_features_enabled,
                    "predictive_maintenance": limits.predictive_maintenance,
                    "white_label": limits.white_label,
                    "custom_integrations": limits.custom_integrations,
                    "priority_support": limits.priority_support,
                    "advanced_analytics": tier in [TenantTier.ENTERPRISE, TenantTier.ENTERPRISE_PLUS],
                    "api_access": True,
                    "mobile_app": True,
                    "voice_commands": limits.ai_features_enabled
                },
                branding=tenant_data.get("branding", {}),
                integrations=tenant_data.get("integrations", []),
                billing_info=tenant_data.get("billing_info", {}),
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                expires_at=tenant_data.get("billing_info", {}).get("trial_expires")
            )
            
            # Store tenant configuration
            self.tenants[tenant_id] = tenant_config
            
            # Initialize tenant users list
            self.tenant_users[tenant_id] = []
            
            # Initialize usage tracking
            self.usage_tracking[tenant_id] = []
            
            # Create tenant database namespace (in production, separate DB schemas)
            await self.create_tenant_database_namespace(tenant_id)
            
            # Initialize tenant with sample data
            await self.initialize_tenant_data(tenant_id)
            
            logger.info(f"✅ Created tenant: {tenant_config.tenant_name} ({tenant_id})")
            
            return tenant_config
            
        except Exception as e:
            logger.error(f"❌ Failed to create tenant: {e}")
            raise HTTPException(status_code=500, detail=f"Tenant creation failed: {str(e)}")
    
    async def create_tenant_database_namespace(self, tenant_id: str):
        """Create isolated database namespace for tenant"""
        try:
            # In production, this would create separate DB schemas or databases
            # For demo, we'll use logical separation with tenant_id prefixes
            
            database_name = f"chatterfix_{tenant_id}"
            self.tenant_databases[tenant_id] = database_name
            
            logger.info(f"📊 Created database namespace: {database_name}")
            
        except Exception as e:
            logger.error(f"❌ Failed to create database namespace: {e}")
    
    async def initialize_tenant_data(self, tenant_id: str):
        """Initialize tenant with sample data based on tier"""
        try:
            tenant = self.tenants[tenant_id]
            tier = tenant.tier
            
            # Create admin user for tenant
            admin_user = TenantUser(
                user_id=f"user_{tenant_id}_admin",
                tenant_id=tenant_id,
                email=f"admin@{tenant.domain}",
                role="admin",
                permissions=["*"],  # All permissions
                is_active=True,
                created_at=datetime.now().isoformat()
            )
            
            self.tenant_users[tenant_id].append(admin_user)
            
            # Add sample users based on tier
            sample_users = []
            if tier == TenantTier.ENTERPRISE:
                sample_users = [
                    ("manager@", "manager", ["read_all", "create_wo", "assign_wo"]),
                    ("tech1@", "technician", ["read_assigned", "update_wo"]),
                    ("tech2@", "technician", ["read_assigned", "update_wo"]),
                ]
            elif tier == TenantTier.ENTERPRISE_PLUS:
                sample_users = [
                    ("operations@", "operations_manager", ["read_all", "create_wo", "assign_wo", "reports"]),
                    ("manager1@", "manager", ["read_department", "create_wo", "assign_wo"]),
                    ("manager2@", "manager", ["read_department", "create_wo", "assign_wo"]),
                    ("tech1@", "technician", ["read_assigned", "update_wo"]),
                    ("tech2@", "technician", ["read_assigned", "update_wo"]),
                    ("tech3@", "technician", ["read_assigned", "update_wo"]),
                ]
            
            for email_prefix, role, permissions in sample_users:
                user = TenantUser(
                    user_id=f"user_{tenant_id}_{role}_{len(sample_users)}",
                    tenant_id=tenant_id,
                    email=f"{email_prefix}{tenant.domain}",
                    role=role,
                    permissions=permissions,
                    is_active=True,
                    created_at=datetime.now().isoformat()
                )
                self.tenant_users[tenant_id].append(user)
            
            # Initialize usage tracking
            current_usage = TenantUsage(
                tenant_id=tenant_id,
                period_start=datetime.now().replace(day=1).isoformat(),
                period_end=datetime.now().isoformat(),
                users_count=len(self.tenant_users[tenant_id]),
                assets_count=0,  # Will be populated as tenant uses system
                work_orders_count=0,
                storage_used_gb=0.1,  # Base usage
                api_calls_count=0,
                ai_predictions_count=0,
                cost_breakdown={
                    "base_subscription": tenant.billing_info.get("monthly_cost", 0),
                    "additional_users": 0.0,
                    "storage_overage": 0.0,
                    "api_overage": 0.0
                }
            )
            
            self.usage_tracking[tenant_id].append(current_usage)
            
            logger.info(f"📝 Initialized data for tenant: {tenant_id}")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize tenant data: {e}")
    
    async def get_tenant_from_request(self, request: Request) -> Optional[TenantConfig]:
        """Extract tenant from request (subdomain or header)"""
        try:
            # Try to get tenant from subdomain
            host = request.headers.get("host", "")
            if ".chatterfix.com" in host:
                subdomain = host.split(".chatterfix.com")[0]
                
                # Find tenant by domain
                for tenant in self.tenants.values():
                    if tenant.domain.startswith(subdomain):
                        return tenant
            
            # Try to get tenant from header
            tenant_id = request.headers.get("X-Tenant-ID")
            if tenant_id and tenant_id in self.tenants:
                return self.tenants[tenant_id]
            
            # Try to get tenant from JWT token
            auth_header = request.headers.get("authorization")
            if auth_header and auth_header.startswith("Bearer "):
                token = auth_header.split(" ")[1]
                payload = jwt.decode(token, self.jwt_secret, algorithms=["HS256"])
                tenant_id = payload.get("tenant_id")
                if tenant_id and tenant_id in self.tenants:
                    return self.tenants[tenant_id]
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Failed to extract tenant from request: {e}")
            return None
    
    async def validate_tenant_limits(self, tenant_id: str, resource_type: str, requested_amount: int = 1) -> bool:
        """Validate if tenant can use additional resources"""
        try:
            if tenant_id not in self.tenants:
                return False
            
            tenant = self.tenants[tenant_id]
            limits = self.tier_limits[tenant.tier]
            
            # Get current usage
            current_usage = await self.get_current_tenant_usage(tenant_id)
            
            # Check specific resource limits
            if resource_type == "users":
                return (current_usage.users_count + requested_amount) <= limits.max_users
            elif resource_type == "assets":
                return (current_usage.assets_count + requested_amount) <= limits.max_assets
            elif resource_type == "work_orders":
                return (current_usage.work_orders_count + requested_amount) <= limits.max_work_orders_per_month
            elif resource_type == "storage":
                return (current_usage.storage_used_gb + requested_amount) <= limits.max_storage_gb
            elif resource_type == "api_calls":
                # Check rate limiting (per minute)
                return requested_amount <= limits.api_rate_limit_per_minute
            elif resource_type == "ai_features":
                return limits.ai_features_enabled
            elif resource_type == "predictive_maintenance":
                return limits.predictive_maintenance
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to validate tenant limits: {e}")
            return False
    
    async def get_current_tenant_usage(self, tenant_id: str) -> TenantUsage:
        """Get current tenant usage statistics"""
        try:
            if tenant_id not in self.usage_tracking or not self.usage_tracking[tenant_id]:
                # Return default usage if no data
                return TenantUsage(
                    tenant_id=tenant_id,
                    period_start=datetime.now().replace(day=1).isoformat(),
                    period_end=datetime.now().isoformat(),
                    users_count=0,
                    assets_count=0,
                    work_orders_count=0,
                    storage_used_gb=0.0,
                    api_calls_count=0,
                    ai_predictions_count=0,
                    cost_breakdown={}
                )
            
            # Return most recent usage record
            return self.usage_tracking[tenant_id][-1]
            
        except Exception as e:
            logger.error(f"❌ Failed to get tenant usage: {e}")
            raise HTTPException(status_code=500, detail="Failed to retrieve usage data")
    
    async def update_tenant_usage(self, tenant_id: str, resource_type: str, amount: int = 1):
        """Update tenant usage counters"""
        try:
            current_usage = await self.get_current_tenant_usage(tenant_id)
            
            # Update usage counters
            if resource_type == "work_orders":
                current_usage.work_orders_count += amount
            elif resource_type == "api_calls":
                current_usage.api_calls_count += amount
            elif resource_type == "ai_predictions":
                current_usage.ai_predictions_count += amount
            elif resource_type == "storage":
                current_usage.storage_used_gb += amount
            
            # Recalculate costs
            await self.calculate_tenant_costs(tenant_id, current_usage)
            
        except Exception as e:
            logger.error(f"❌ Failed to update tenant usage: {e}")
    
    async def calculate_tenant_costs(self, tenant_id: str, usage: TenantUsage):
        """Calculate tenant costs based on usage"""
        try:
            tenant = self.tenants[tenant_id]
            limits = self.tier_limits[tenant.tier]
            
            base_cost = tenant.billing_info.get("monthly_cost", 0)
            additional_costs = 0.0
            
            # Calculate overages
            if usage.users_count > limits.max_users:
                additional_users = usage.users_count - limits.max_users
                additional_costs += additional_users * 50.0  # $50/user/month
            
            if usage.storage_used_gb > limits.max_storage_gb:
                storage_overage = usage.storage_used_gb - limits.max_storage_gb
                additional_costs += storage_overage * 2.0  # $2/GB/month
            
            if usage.work_orders_count > limits.max_work_orders_per_month:
                wo_overage = usage.work_orders_count - limits.max_work_orders_per_month
                additional_costs += wo_overage * 0.50  # $0.50/work order
            
            # Update cost breakdown
            usage.cost_breakdown = {
                "base_subscription": base_cost,
                "additional_users": additional_users * 50.0 if usage.users_count > limits.max_users else 0.0,
                "storage_overage": (usage.storage_used_gb - limits.max_storage_gb) * 2.0 if usage.storage_used_gb > limits.max_storage_gb else 0.0,
                "work_order_overage": (usage.work_orders_count - limits.max_work_orders_per_month) * 0.50 if usage.work_orders_count > limits.max_work_orders_per_month else 0.0,
                "total_monthly": base_cost + additional_costs
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to calculate tenant costs: {e}")
    
    async def create_tenant_jwt_token(self, tenant_id: str, user_id: str, permissions: List[str]) -> str:
        """Create JWT token for tenant user"""
        try:
            payload = {
                "tenant_id": tenant_id,
                "user_id": user_id,
                "permissions": permissions,
                "iat": datetime.utcnow(),
                "exp": datetime.utcnow() + timedelta(hours=24)
            }
            
            token = jwt.encode(payload, self.jwt_secret, algorithm="HS256")
            return token
            
        except Exception as e:
            logger.error(f"❌ Failed to create JWT token: {e}")
            raise HTTPException(status_code=500, detail="Token creation failed")
    
    async def validate_tenant_access(self, tenant_id: str, user_id: str, required_permission: str) -> bool:
        """Validate if user has required permission in tenant"""
        try:
            if tenant_id not in self.tenant_users:
                return False
            
            tenant_users = self.tenant_users[tenant_id]
            user = next((u for u in tenant_users if u.user_id == user_id), None)
            
            if not user or not user.is_active:
                return False
            
            # Check permissions
            if "*" in user.permissions or required_permission in user.permissions:
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Failed to validate tenant access: {e}")
            return False

# Initialize global tenant manager
tenant_manager = EnterpriseMultiTenantManager()

# Dependency for extracting current tenant
async def get_current_tenant(request: Request) -> TenantConfig:
    """Dependency to get current tenant from request"""
    tenant = await tenant_manager.get_tenant_from_request(request)
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return tenant

# Dependency for validating tenant access
async def validate_tenant_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(HTTPBearer())
) -> Tuple[TenantConfig, str]:
    """Dependency to validate tenant user authentication"""
    try:
        # Decode JWT token
        payload = jwt.decode(credentials.credentials, tenant_manager.jwt_secret, algorithms=["HS256"])
        tenant_id = payload.get("tenant_id")
        user_id = payload.get("user_id")
        
        if not tenant_id or not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        # Get tenant
        if tenant_id not in tenant_manager.tenants:
            raise HTTPException(status_code=404, detail="Tenant not found")
        
        tenant = tenant_manager.tenants[tenant_id]
        
        # Validate user exists and is active
        tenant_users = tenant_manager.tenant_users.get(tenant_id, [])
        user = next((u for u in tenant_users if u.user_id == user_id), None)
        
        if not user or not user.is_active:
            raise HTTPException(status_code=401, detail="User not found or inactive")
        
        return tenant, user_id
        
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception as e:
        logger.error(f"❌ Tenant user validation failed: {e}")
        raise HTTPException(status_code=401, detail="Authentication failed")

# API Endpoints
@enterprise_router.post("/tenants")
async def create_new_tenant(tenant_data: Dict[str, Any]):
    """Create new enterprise tenant"""
    try:
        tenant_config = await tenant_manager.create_tenant(tenant_data)
        return JSONResponse({
            "success": True,
            "tenant": tenant_config.dict(),
            "message": f"Tenant '{tenant_config.tenant_name}' created successfully"
        })
    except Exception as e:
        logger.error(f"❌ Tenant creation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@enterprise_router.get("/tenants/{tenant_id}")
async def get_tenant_info(tenant_id: str):
    """Get tenant configuration and details"""
    if tenant_id not in tenant_manager.tenants:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    tenant = tenant_manager.tenants[tenant_id]
    usage = await tenant_manager.get_current_tenant_usage(tenant_id)
    
    return JSONResponse({
        "tenant": tenant.dict(),
        "usage": usage.dict(),
        "users_count": len(tenant_manager.tenant_users.get(tenant_id, [])),
        "database": tenant_manager.tenant_databases.get(tenant_id)
    })

@enterprise_router.get("/tenants")
async def list_all_tenants():
    """List all enterprise tenants"""
    tenants_list = []
    
    for tenant_id, tenant in tenant_manager.tenants.items():
        usage = await tenant_manager.get_current_tenant_usage(tenant_id)
        
        tenants_list.append({
            "tenant_id": tenant_id,
            "tenant_name": tenant.tenant_name,
            "domain": tenant.domain,
            "tier": tenant.tier,
            "status": tenant.status,
            "users_count": len(tenant_manager.tenant_users.get(tenant_id, [])),
            "monthly_cost": usage.cost_breakdown.get("total_monthly", 0),
            "created_at": tenant.created_at
        })
    
    return JSONResponse({
        "tenants": tenants_list,
        "total_tenants": len(tenants_list)
    })

@enterprise_router.get("/tenants/{tenant_id}/usage")
async def get_tenant_usage(tenant_id: str):
    """Get detailed tenant usage and billing information"""
    if tenant_id not in tenant_manager.tenants:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    usage = await tenant_manager.get_current_tenant_usage(tenant_id)
    tenant = tenant_manager.tenants[tenant_id]
    limits = tenant_manager.tier_limits[tenant.tier]
    
    return JSONResponse({
        "current_usage": usage.dict(),
        "limits": limits.__dict__,
        "utilization": {
            "users": f"{(usage.users_count / limits.max_users * 100):.1f}%",
            "assets": f"{(usage.assets_count / limits.max_assets * 100):.1f}%",
            "work_orders": f"{(usage.work_orders_count / limits.max_work_orders_per_month * 100):.1f}%",
            "storage": f"{(usage.storage_used_gb / limits.max_storage_gb * 100):.1f}%"
        },
        "cost_projection": usage.cost_breakdown
    })

@enterprise_router.post("/tenants/{tenant_id}/users")
async def create_tenant_user(tenant_id: str, user_data: Dict[str, Any]):
    """Create new user for tenant"""
    if tenant_id not in tenant_manager.tenants:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    # Validate user limits
    if not await tenant_manager.validate_tenant_limits(tenant_id, "users", 1):
        raise HTTPException(status_code=403, detail="User limit exceeded for tenant tier")
    
    # Create user
    user = TenantUser(
        user_id=f"user_{tenant_id}_{len(tenant_manager.tenant_users[tenant_id]) + 1}",
        tenant_id=tenant_id,
        email=user_data["email"],
        role=user_data.get("role", "user"),
        permissions=user_data.get("permissions", ["read"]),
        is_active=True,
        created_at=datetime.now().isoformat()
    )
    
    tenant_manager.tenant_users[tenant_id].append(user)
    
    # Update usage
    await tenant_manager.update_tenant_usage(tenant_id, "users", 1)
    
    return JSONResponse({
        "success": True,
        "user": user.dict(),
        "message": "User created successfully"
    })

@enterprise_router.post("/auth/tenant-login")
async def tenant_user_login(login_data: Dict[str, Any]):
    """Authenticate tenant user and return JWT token"""
    try:
        email = login_data.get("email")
        password = login_data.get("password")
        tenant_domain = login_data.get("tenant_domain")
        
        if not all([email, password, tenant_domain]):
            raise HTTPException(status_code=400, detail="Email, password, and tenant domain required")
        
        # Find tenant by domain
        tenant = None
        for t in tenant_manager.tenants.values():
            if t.domain == tenant_domain:
                tenant = t
                break
        
        if not tenant:
            raise HTTPException(status_code=404, detail="Tenant not found")
        
        # Find user
        tenant_users = tenant_manager.tenant_users.get(tenant.tenant_id, [])
        user = next((u for u in tenant_users if u.email == email), None)
        
        if not user or not user.is_active:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # In production, verify password hash
        # For demo, accept any password
        
        # Create JWT token
        token = await tenant_manager.create_tenant_jwt_token(
            tenant.tenant_id, user.user_id, user.permissions
        )
        
        return JSONResponse({
            "access_token": token,
            "token_type": "bearer",
            "tenant_id": tenant.tenant_id,
            "user_id": user.user_id,
            "permissions": user.permissions,
            "expires_in": 86400  # 24 hours
        })
        
    except Exception as e:
        logger.error(f"❌ Tenant login failed: {e}")
        raise HTTPException(status_code=500, detail="Login failed")

@enterprise_router.get("/my-tenant")
async def get_my_tenant_info(tenant_user: Tuple[TenantConfig, str] = Depends(validate_tenant_user)):
    """Get current user's tenant information"""
    tenant, user_id = tenant_user
    
    usage = await tenant_manager.get_current_tenant_usage(tenant.tenant_id)
    
    return JSONResponse({
        "tenant": tenant.dict(),
        "current_usage": usage.dict(),
        "user_id": user_id,
        "features_available": tenant.features
    })

@enterprise_router.get("/tiers")
async def get_tenant_tiers():
    """Get available tenant tiers and pricing"""
    tiers_info = {}
    
    for tier, limits in tenant_manager.tier_limits.items():
        # Mock pricing for different tiers
        pricing = {
            TenantTier.STARTER: {"monthly": 99, "annual": 990},
            TenantTier.PROFESSIONAL: {"monthly": 299, "annual": 2990},
            TenantTier.ENTERPRISE: {"monthly": 999, "annual": 9990},
            TenantTier.ENTERPRISE_PLUS: {"monthly": 2999, "annual": 29990}
        }
        
        tiers_info[tier.value] = {
            "name": tier.value.replace("_", " ").title(),
            "limits": limits.__dict__,
            "pricing": pricing[tier],
            "features": [
                "AI-powered maintenance predictions",
                "Voice command interface",
                "Mobile-first design",
                "Real-time analytics dashboard",
                "Automated work order routing"
            ] + (["White-label branding", "Custom integrations", "Priority support"] if tier in [TenantTier.ENTERPRISE, TenantTier.ENTERPRISE_PLUS] else [])
        }
    
    return JSONResponse({"tiers": tiers_info})

@enterprise_router.get("/system/stats")
async def get_system_statistics():
    """Get global system statistics across all tenants"""
    total_tenants = len(tenant_manager.tenants)
    active_tenants = len([t for t in tenant_manager.tenants.values() if t.status == TenantStatus.ACTIVE])
    total_users = sum(len(users) for users in tenant_manager.tenant_users.values())
    
    # Calculate revenue
    total_monthly_revenue = 0
    for tenant in tenant_manager.tenants.values():
        usage = await tenant_manager.get_current_tenant_usage(tenant.tenant_id)
        total_monthly_revenue += usage.cost_breakdown.get("total_monthly", 0)
    
    tier_distribution = {}
    for tier in TenantTier:
        tier_distribution[tier.value] = len([t for t in tenant_manager.tenants.values() if t.tier == tier])
    
    return JSONResponse({
        "system_stats": {
            "total_tenants": total_tenants,
            "active_tenants": active_tenants,
            "trial_tenants": len([t for t in tenant_manager.tenants.values() if t.status == TenantStatus.TRIAL]),
            "total_users": total_users,
            "monthly_recurring_revenue": total_monthly_revenue,
            "annual_revenue_projection": total_monthly_revenue * 12
        },
        "tier_distribution": tier_distribution,
        "growth_metrics": {
            "tenants_this_month": 3,  # Mock data
            "revenue_growth": 0.15,   # 15% growth
            "user_growth": 0.23       # 23% user growth
        }
    })