#!/usr/bin/env python3
"""
Intelligent Asset Health Scoring Feature
Uses AI to analyze maintenance patterns and calculate health scores
"""

# Health scoring function to add to assets.py
HEALTH_SCORING_FUNCTION = '''

@assets_router.post("/analyze-health/{asset_id}")
async def analyze_asset_health(asset_id: str) -> Dict:
    """AI-powered asset health analysis"""
    try:
        # Get asset information
        asset = None
        for a in assets_db:
            if a.get("id") == asset_id or a.get("name") == asset_id:
                asset = a
                break
        
        if not asset:
            raise HTTPException(status_code=404, detail="Asset not found")
        
        # Get maintenance history for this asset
        from workorders import work_orders_db
        asset_workorders = [wo for wo in work_orders_db 
                           if wo.get("asset_id") == asset_id or wo.get("asset_id") == asset.get("name")]
        
        # Calculate basic metrics
        total_workorders = len(asset_workorders)
        emergency_repairs = len([wo for wo in asset_workorders if wo.get("type") == "emergency"])
        preventive_maintenance = len([wo for wo in asset_workorders if wo.get("type") == "preventive"])
        
        # Calculate age-based scoring
        install_date = asset.get("installation_date")
        age_score = 10.0  # Default for new equipment
        
        if install_date:
            from datetime import datetime
            try:
                install_dt = datetime.strptime(install_date, "%Y-%m-%d")
                age_years = (datetime.now() - install_dt).days / 365.25
                # Reduce score based on age (assuming 20-year equipment life)
                age_score = max(1.0, 10.0 - (age_years / 20.0) * 5.0)
            except:
                pass
        
        # Calculate maintenance pattern score
        maintenance_score = 10.0
        if total_workorders > 0:
            emergency_ratio = emergency_repairs / total_workorders
            preventive_ratio = preventive_maintenance / total_workorders
            
            # Penalty for high emergency repairs
            maintenance_score -= emergency_ratio * 6.0
            
            # Bonus for good preventive maintenance
            maintenance_score += preventive_ratio * 2.0
            
            # Penalty for too many work orders overall
            if total_workorders > 10:
                maintenance_score -= min(3.0, (total_workorders - 10) * 0.3)
        
        # Calculate final health score (weighted average)
        raw_health_score = (age_score * 0.4 + maintenance_score * 0.6)
        health_score = max(1.0, min(10.0, raw_health_score))
        
        # Use AI to generate insights
        ai_prompt = f"""
Analyze this asset health data and provide maintenance insights:

Asset: {asset.get('name', 'Unknown')}
Type: {asset.get('category', 'Unknown')}
Health Score: {health_score:.1f}/10
Total Work Orders: {total_workorders}
Emergency Repairs: {emergency_repairs}
Preventive Maintenance: {preventive_maintenance}
Age Score: {age_score:.1f}/10
Maintenance Score: {maintenance_score:.1f}/10

Provide brief insights (2-3 sentences) about:
1. Current condition assessment
2. Recommended actions
3. Risk factors

Keep response concise and actionable."""

        # Get AI insights
        from ai import query_llama
        ai_insights = await query_llama(ai_prompt, "asset_health_analysis", "health_analyzer")
        
        # Determine health status
        if health_score >= 8.0:
            status = "excellent"
            color = "#27ae60"
        elif health_score >= 6.0:
            status = "good"
            color = "#f39c12"
        elif health_score >= 4.0:
            status = "fair"
            color = "#e67e22"
        else:
            status = "poor"
            color = "#e74c3c"
        
        # Update asset health score in database
        asset["health_score"] = round(health_score, 1)
        asset["last_health_check"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        logger.info(f"Health analysis completed for {asset_id}: {health_score:.1f}/10 ({status})")
        
        return {
            "asset_id": asset_id,
            "asset_name": asset.get("name", "Unknown"),
            "health_score": round(health_score, 1),
            "status": status,
            "status_color": color,
            "metrics": {
                "age_score": round(age_score, 1),
                "maintenance_score": round(maintenance_score, 1),
                "total_workorders": total_workorders,
                "emergency_repairs": emergency_repairs,
                "preventive_maintenance": preventive_maintenance,
                "emergency_ratio": round(emergency_repairs / max(1, total_workorders) * 100, 1)
            },
            "ai_insights": ai_insights,
            "last_updated": datetime.now().isoformat(),
            "analysis_method": "ai_enhanced"
        }
        
    except Exception as e:
        logger.error(f"Health analysis failed for {asset_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Health analysis failed: {str(e)}")

@assets_router.post("/bulk-health-analysis")
async def bulk_health_analysis() -> Dict:
    """Analyze health for all assets"""
    try:
        results = []
        
        for asset in assets_db:
            asset_id = asset.get("id") or asset.get("name")
            if asset_id:
                try:
                    health_result = await analyze_asset_health(asset_id)
                    results.append({
                        "asset_id": asset_id,
                        "health_score": health_result["health_score"],
                        "status": health_result["status"]
                    })
                except Exception as e:
                    logger.warning(f"Failed to analyze {asset_id}: {e}")
                    results.append({
                        "asset_id": asset_id,
                        "health_score": 5.0,
                        "status": "unknown",
                        "error": str(e)
                    })
        
        # Calculate fleet statistics
        valid_scores = [r["health_score"] for r in results if "error" not in r]
        if valid_scores:
            avg_health = sum(valid_scores) / len(valid_scores)
            poor_assets = len([s for s in valid_scores if s < 4.0])
            good_assets = len([s for s in valid_scores if s >= 6.0])
        else:
            avg_health = 0.0
            poor_assets = 0
            good_assets = 0
        
        logger.info(f"Bulk health analysis completed: {len(results)} assets analyzed")
        
        return {
            "total_assets": len(results),
            "average_health": round(avg_health, 1),
            "fleet_status": "good" if avg_health >= 6.0 else "needs_attention" if avg_health >= 4.0 else "critical",
            "summary": {
                "good_assets": good_assets,
                "poor_assets": poor_assets,
                "needs_attention": len(valid_scores) - good_assets - poor_assets
            },
            "assets": results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Bulk health analysis failed: {e}")
        raise HTTPException(status_code=500, detail=f"Bulk analysis failed: {str(e)}")
'''

def apply_patch():
    """Apply health scoring patch to assets.py"""
    print("🏥 Adding Intelligent Asset Health Scoring feature...")
    
    # Read current assets.py
    with open('/opt/chatterfix/assets.py', 'r') as f:
        content = f.read()
    
    # Check if already patched
    if 'analyze-health' in content:
        print("✅ Health scoring feature already exists")
        return True
    
    # Find insertion point - before the last function or at the end
    import re
    router_matches = list(re.finditer(r'@assets_router\\.', content))
    
    if router_matches:
        # Insert before the last router definition
        last_router_pos = router_matches[-1].start()
        insertion_point = content.rfind('\\n', 0, last_router_pos)
        if insertion_point == -1:
            insertion_point = last_router_pos
    else:
        # Insert at the end
        main_pos = content.find('if __name__ == "__main__"')
        if main_pos != -1:
            insertion_point = content.rfind('\\n', 0, main_pos)
        else:
            insertion_point = len(content)
    
    # Insert the health scoring functions
    new_content = (content[:insertion_point] + 
                   HEALTH_SCORING_FUNCTION + 
                   content[insertion_point:])
    
    # Write the updated content
    with open('/opt/chatterfix/assets.py', 'w') as f:
        f.write(new_content)
    
    print("✅ Intelligent Asset Health Scoring feature added to assets.py")
    return True

if __name__ == "__main__":
    apply_patch()