#!/usr/bin/env python3
"""
Mobile-Optimized Work Orders Module
Touch-friendly work order management with offline capabilities
"""

from fastapi import APIRouter, HTTPException, Request, Form, Query
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import json
import logging

logger = logging.getLogger(__name__)

# Mobile work orders router
mobile_workorders_router = APIRouter(prefix="/workorders/mobile", tags=["mobile-workorders"])

# Enhanced data models with mobile features
class MobileWorkOrder(BaseModel):
    id: str
    wo_number: str
    title: str
    description: str
    asset_id: str
    asset_name: str
    location: str
    type: str  # reactive, preventive, predictive
    priority: str  # critical, high, medium, low
    status: str  # open, assigned, in_progress, complete, overdue
    created_date: str
    created_by: str
    assigned_to: Optional[str] = None
    assigned_to_name: Optional[str] = None
    due_date: Optional[str] = None
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    cost: Optional[float] = None
    voice_created: bool = False
    offline_sync: bool = False
    ai_suggestions: List[str] = []

# Enhanced mock database with mobile-optimized data
mobile_work_orders_db = [
    {
        "id": "WO-001",
        "wo_number": "WO-2025-001",
        "title": "Emergency Generator Repair",
        "description": "Generator failed to start during weekly test. Investigate and repair fuel system issue.",
        "asset_id": "AST-004",
        "asset_name": "Emergency Generator #1",
        "location": "Building A - Basement",
        "type": "reactive",
        "priority": "critical",
        "status": "in_progress",
        "created_date": "2025-09-05T08:30:00Z",
        "created_by": "John Smith",
        "assigned_to": "TECH-001",
        "assigned_to_name": "Mike Johnson",
        "due_date": "2025-09-06T17:00:00Z",
        "estimated_hours": 6.0,
        "actual_hours": 3.5,
        "cost": 450.00,
        "voice_created": False,
        "offline_sync": False,
        "ai_suggestions": [
            "Check fuel filter condition",
            "Test fuel pump pressure",
            "Inspect electrical connections"
        ]
    },
    {
        "id": "WO-002", 
        "wo_number": "WO-2025-002",
        "title": "Conveyor Belt Inspection",
        "description": "Monthly preventive maintenance inspection of main conveyor system.",
        "asset_id": "AST-002",
        "asset_name": "Conveyor Belt Line 1",
        "location": "Production Floor",
        "type": "preventive",
        "priority": "medium", 
        "status": "assigned",
        "created_date": "2025-09-04T10:00:00Z",
        "created_by": "System",
        "assigned_to": "TECH-002",
        "assigned_to_name": "Sarah Davis",
        "due_date": "2025-09-07T16:00:00Z",
        "estimated_hours": 2.0,
        "actual_hours": None,
        "cost": None,
        "voice_created": False,
        "offline_sync": False,
        "ai_suggestions": [
            "Check belt tension",
            "Lubricate bearings",
            "Inspect safety guards"
        ]
    },
    {
        "id": "WO-003",
        "wo_number": "WO-2025-003", 
        "title": "HVAC Filter Replacement",
        "description": "Replace air filters in main HVAC unit and check system performance.",
        "asset_id": "AST-003",
        "asset_name": "HVAC Unit - Main",
        "location": "Building B - Rooftop",
        "type": "preventive",
        "priority": "low",
        "status": "open", 
        "created_date": "2025-09-03T14:20:00Z",
        "created_by": "Sarah Davis",
        "assigned_to": None,
        "assigned_to_name": None,
        "due_date": "2025-09-10T12:00:00Z",
        "estimated_hours": 4.0,
        "actual_hours": None,
        "cost": None,
        "voice_created": True,
        "offline_sync": False,
        "ai_suggestions": [
            "Order replacement filters",
            "Check airflow measurements",
            "Update maintenance log"
        ]
    }
]

@mobile_workorders_router.get("/list", response_class=HTMLResponse)
async def mobile_work_orders_list():
    """Mobile-optimized work orders list with touch-friendly interface"""
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Work Orders - ChatterFix CMMS</title>
        <link rel="stylesheet" href="/static/css/mobile.css">
        <link rel="manifest" href="/manifest.json">
        <meta name="theme-color" content="#667eea">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="default">
    </head>
    <body>
        <!-- Sync Status Bar -->
        <div class="sync-status-bar" id="syncStatus">
            <div class="sync-status online">
                <span>🌐</span>
                <span>Online - All changes synced</span>
            </div>
            <div class="sync-status syncing" style="display: none;">
                <div class="spinner-sm"></div>
                <span>Syncing changes...</span>
            </div>
            <div class="sync-status offline" style="display: none;">
                <span>📱</span>
                <span>Offline</span>
                <button class="btn-sm" onclick="offlineSyncManager.forceSync()">Retry</button>
            </div>
        </div>
        
        <!-- Navigation -->
        <nav class="navbar">
            <div class="container d-flex justify-between align-center">
                <a href="/" class="navbar-brand">ChatterFix</a>
                <div class="navbar-nav">
                    <a href="/cmms/dashboard/main" class="nav-link">Dashboard</a>
                    <a href="/cmms/workorders/mobile/list" class="nav-link active">Work Orders</a>
                    <a href="/cmms/assets/list" class="nav-link">Assets</a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <div class="container">
            <div class="d-flex justify-between align-center mb-lg">
                <h1>Work Orders</h1>
                <button class="btn btn-primary" onclick="openCreateWorkOrder()">
                    <span>➕</span>
                    New Work Order
                </button>
            </div>
            
            <!-- Filter Bar -->
            <div class="d-flex gap-md mb-lg">
                <select class="form-control" id="statusFilter" onchange="filterWorkOrders()">
                    <option value="">All Status</option>
                    <option value="open">Open</option>
                    <option value="assigned">Assigned</option>
                    <option value="in_progress">In Progress</option>
                    <option value="complete">Complete</option>
                    <option value="overdue">Overdue</option>
                </select>
                
                <select class="form-control" id="priorityFilter" onchange="filterWorkOrders()">
                    <option value="">All Priority</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                </select>
            </div>
            
            <!-- Work Orders List -->
            <div id="workOrdersList">
                <!-- Work orders will be loaded here -->
            </div>
        </div>
        
        <!-- Voice Command FAB -->
        <button class="voice-fab" onclick="startVoiceCommand()" title="Voice Command">
            🎤
        </button>
        
        <!-- Work Order Detail Modal -->
        <div class="modal" id="workOrderModal" style="display: none;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="modalTitle">Work Order Details</h3>
                    <button class="modal-close" onclick="closeModal()">&times;</button>
                </div>
                <div class="modal-body" id="modalBody">
                    <!-- Details will be loaded here -->
                </div>
            </div>
        </div>
        
        <script src="/static/js/offline-sync.js"></script>
        <script>
            // Work orders data
            let workOrders = {json.dumps(mobile_work_orders_db)};
            let filteredWorkOrders = workOrders;
            
            // Initialize page
            document.addEventListener('DOMContentLoaded', function() {{
                renderWorkOrders();
                registerServiceWorker();
            }});
            
            // Register service worker for PWA functionality
            async function registerServiceWorker() {{
                if ('serviceWorker' in navigator) {{
                    try {{
                        const registration = await navigator.serviceWorker.register('/static/js/sw.js');
                        console.log('✅ Service worker registered:', registration.scope);
                    }} catch (error) {{
                        console.error('❌ Service worker registration failed:', error);
                    }}
                }}
            }}
            
            // Render work orders list
            function renderWorkOrders() {{
                const container = document.getElementById('workOrdersList');
                
                if (filteredWorkOrders.length === 0) {{
                    container.innerHTML = `
                        <div class="text-center p-lg">
                            <h3>No work orders found</h3>
                            <p>Create a new work order to get started</p>
                        </div>
                    `;
                    return;
                }}
                
                const workOrdersHtml = filteredWorkOrders.map(wo => `
                    <div class="work-order-card status-${{wo.status}} animate-fade-in" 
                         onclick="openWorkOrderDetails('${{wo.id}}')">
                        <div class="work-order-header">
                            <div>
                                <div class="work-order-id">${{wo.wo_number}}</div>
                                <h4 class="work-order-title">${{wo.title}}</h4>
                            </div>
                            <div class="d-flex gap-sm">
                                <span class="badge priority-badge ${{wo.priority}}">${{wo.priority}}</span>
                                <span class="badge status-badge ${{wo.status}}">${{wo.status.replace('_', ' ')}}</span>
                                ${{wo.voice_created ? '<span class="badge" style="background: #9b59b6; color: white;">🎤</span>' : ''}}
                            </div>
                        </div>
                        
                        <div class="work-order-meta">
                            <span><strong>Asset:</strong> ${{wo.asset_name}}</span>
                            <span><strong>Location:</strong> ${{wo.location}}</span>
                            ${{wo.assigned_to_name ? `<span><strong>Assigned:</strong> ${{wo.assigned_to_name}}</span>` : ''}}
                            ${{wo.due_date ? `<span><strong>Due:</strong> ${{formatDate(wo.due_date)}}</span>` : ''}}
                        </div>
                        
                        <p>${{wo.description.substring(0, 120)}}${{wo.description.length > 120 ? '...' : ''}}</p>
                        
                        <div class="work-order-actions">
                            <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); updateWorkOrderStatus('${{wo.id}}')">
                                Update Status
                            </button>
                            <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation(); assignTechnician('${{wo.id}}')">
                                Assign
                            </button>
                            ${{wo.ai_suggestions && wo.ai_suggestions.length > 0 ? 
                                `<button class="btn btn-sm" style="background: #11998e; color: white;" onclick="event.stopPropagation(); showAiSuggestions('${{wo.id}}')">
                                    🤖 AI Help
                                </button>` : ''}}
                        </div>
                    </div>
                `).join('');
                
                container.innerHTML = workOrdersHtml;
            }}
            
            // Filter work orders
            function filterWorkOrders() {{
                const statusFilter = document.getElementById('statusFilter').value;
                const priorityFilter = document.getElementById('priorityFilter').value;
                
                filteredWorkOrders = workOrders.filter(wo => {{
                    const statusMatch = !statusFilter || wo.status === statusFilter;
                    const priorityMatch = !priorityFilter || wo.priority === priorityFilter;
                    return statusMatch && priorityMatch;
                }});
                
                renderWorkOrders();
            }}
            
            // Format date for display
            function formatDate(dateStr) {{
                const date = new Date(dateStr);
                return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {{hour: '2-digit', minute:'2-digit'}});
            }}
            
            // Open work order details modal
            function openWorkOrderDetails(workOrderId) {{
                const wo = workOrders.find(w => w.id === workOrderId);
                if (!wo) return;
                
                const modalBody = document.getElementById('modalBody');
                modalBody.innerHTML = `
                    <div class="form-group">
                        <strong>Work Order:</strong> ${{wo.wo_number}}
                    </div>
                    <div class="form-group">
                        <strong>Title:</strong> ${{wo.title}}
                    </div>
                    <div class="form-group">
                        <strong>Description:</strong><br>
                        ${{wo.description}}
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <strong>Asset:</strong> ${{wo.asset_name}}
                        </div>
                        <div class="col-6">
                            <strong>Location:</strong> ${{wo.location}}
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <strong>Priority:</strong> <span class="badge priority-badge ${{wo.priority}}">${{wo.priority}}</span>
                        </div>
                        <div class="col-6">
                            <strong>Status:</strong> <span class="badge status-badge ${{wo.status}}">${{wo.status.replace('_', ' ')}}</span>
                        </div>
                    </div>
                    ${{wo.assigned_to_name ? `
                        <div class="form-group">
                            <strong>Assigned to:</strong> ${{wo.assigned_to_name}}
                        </div>
                    ` : ''}}
                    ${{wo.due_date ? `
                        <div class="form-group">
                            <strong>Due Date:</strong> ${{formatDate(wo.due_date)}}
                        </div>
                    ` : ''}}
                    ${{wo.ai_suggestions && wo.ai_suggestions.length > 0 ? `
                        <div class="form-group">
                            <strong>🤖 AI Suggestions:</strong>
                            <ul>
                                ${{wo.ai_suggestions.map(suggestion => `<li>${{suggestion}}</li>`).join('')}}
                            </ul>
                        </div>
                    ` : ''}}
                `;
                
                document.getElementById('workOrderModal').style.display = 'flex';
            }}
            
            // Close modal
            function closeModal() {{
                document.getElementById('workOrderModal').style.display = 'none';
            }}
            
            // Voice command functionality
            function startVoiceCommand() {{
                const voiceFab = document.querySelector('.voice-fab');
                voiceFab.classList.add('listening');
                
                // Simulated voice command
                setTimeout(() => {{
                    voiceFab.classList.remove('listening');
                    alert('🎤 Voice command processed! In production, this would create a work order from your voice input.');
                }}, 2000);
            }}
            
            // Update work order status
            function updateWorkOrderStatus(workOrderId) {{
                const newStatus = prompt('Enter new status (open, assigned, in_progress, complete):');
                if (newStatus) {{
                    const wo = workOrders.find(w => w.id === workOrderId);
                    if (wo) {{
                        wo.status = newStatus;
                        renderWorkOrders();
                        
                        // Show toast notification
                        showToast('Work order status updated', 'success');
                    }}
                }}
            }}
            
            // Assign technician
            function assignTechnician(workOrderId) {{
                const technicianName = prompt('Assign to technician:');
                if (technicianName) {{
                    const wo = workOrders.find(w => w.id === workOrderId);
                    if (wo) {{
                        wo.assigned_to = 'TECH-NEW';
                        wo.assigned_to_name = technicianName;
                        wo.status = 'assigned';
                        renderWorkOrders();
                        
                        showToast(`Work order assigned to ${{technicianName}}`, 'success');
                    }}
                }}
            }}
            
            // Show AI suggestions
            function showAiSuggestions(workOrderId) {{
                const wo = workOrders.find(w => w.id === workOrderId);
                if (wo && wo.ai_suggestions) {{
                    alert('🤖 AI Suggestions:\\n\\n' + wo.ai_suggestions.join('\\n• '));
                }}
            }}
            
            // Show toast notification
            function showToast(message, type = 'info') {{
                const toast = document.createElement('div');
                toast.className = `toast toast-${{type}} show`;
                toast.innerHTML = `
                    <div class="toast-icon">${{type === 'success' ? '✅' : 'ℹ️'}}</div>
                    <div class="toast-content">
                        <strong>${{message}}</strong>
                    </div>
                    <button class="toast-close" onclick="this.parentElement.remove()">×</button>
                `;
                
                document.body.appendChild(toast);
                
                setTimeout(() => {{
                    if (toast.parentElement) {{
                        toast.remove();
                    }}
                }}, 4000);
            }}
            
            // Open create work order form
            function openCreateWorkOrder() {{
                // In production, this would open a mobile-optimized form
                window.location.href = '/cmms/workorders/mobile/new';
            }}
        </script>
        
        <style>
            .modal {{
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 2000;
                padding: var(--spacing-md);
            }}
            
            .modal-content {{
                background: var(--surface);
                border-radius: var(--radius-lg);
                max-width: 500px;
                width: 100%;
                max-height: 80vh;
                overflow-y: auto;
            }}
            
            .modal-header {{
                padding: var(--spacing-lg);
                border-bottom: 1px solid var(--border-light);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }}
            
            .modal-body {{
                padding: var(--spacing-lg);
            }}
            
            .modal-close {{
                background: none;
                border: none;
                font-size: var(--font-2xl);
                cursor: pointer;
                padding: 0;
                color: var(--text-secondary);
            }}
            
            .spinner-sm {{
                width: 16px;
                height: 16px;
                border: 2px solid transparent;
                border-top: 2px solid currentColor;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }}
            
            @keyframes spin {{
                0% {{ transform: rotate(0deg); }}
                100% {{ transform: rotate(360deg); }}
            }}
        </style>
    </body>
    </html>
    """

@mobile_workorders_router.get("/new", response_class=HTMLResponse) 
async def mobile_create_work_order():
    """Mobile-optimized work order creation form"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>New Work Order - ChatterFix CMMS</title>
        <link rel="stylesheet" href="/static/css/mobile.css">
    </head>
    <body>
        <nav class="navbar">
            <div class="container d-flex justify-between align-center">
                <a href="/cmms/workorders/mobile/list" class="btn btn-secondary">← Back</a>
                <h2>New Work Order</h2>
                <div></div>
            </div>
        </nav>
        
        <div class="container">
            <form id="workOrderForm" onsubmit="submitWorkOrder(event)">
                <div class="form-group">
                    <label class="form-label">Title *</label>
                    <input type="text" class="form-control" name="title" required 
                           placeholder="Brief description of the work">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Description *</label>
                    <textarea class="form-control" name="description" required rows="4"
                              placeholder="Detailed description of the work needed"></textarea>
                </div>
                
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Asset</label>
                            <select class="form-control" name="asset_id">
                                <option value="">Select Asset</option>
                                <option value="AST-001">Pump #1</option>
                                <option value="AST-002">Conveyor Belt</option>
                                <option value="AST-003">HVAC Unit</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Priority *</label>
                            <select class="form-control" name="priority" required>
                                <option value="low">Low</option>
                                <option value="medium" selected>Medium</option>
                                <option value="high">High</option>
                                <option value="critical">Critical</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Type</label>
                            <select class="form-control" name="type">
                                <option value="reactive" selected>Reactive</option>
                                <option value="preventive">Preventive</option>
                                <option value="predictive">Predictive</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Due Date</label>
                            <input type="datetime-local" class="form-control" name="due_date">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Estimated Hours</label>
                    <input type="number" class="form-control" name="estimated_hours" 
                           step="0.5" min="0.5" placeholder="2.0">
                </div>
                
                <div class="d-flex gap-md">
                    <button type="button" class="btn btn-secondary btn-block" 
                            onclick="window.history.back()">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-block">
                        Create Work Order
                    </button>
                </div>
            </form>
        </div>
        
        <button class="voice-fab" onclick="startVoiceWorkOrder()" title="Voice Create">
            🎤
        </button>
        
        <script src="/static/js/offline-sync.js"></script>
        <script>
            function submitWorkOrder(event) {
                event.preventDefault();
                
                const formData = new FormData(event.target);
                const workOrder = Object.fromEntries(formData);
                
                // Add generated fields
                workOrder.id = 'WO-' + Date.now();
                workOrder.wo_number = 'WO-2025-' + String(Date.now()).slice(-3);
                workOrder.status = 'open';
                workOrder.created_date = new Date().toISOString();
                workOrder.created_by = 'Current User';
                workOrder.voice_created = false;
                
                // Simulate form submission (in production this would POST to server)
                console.log('Creating work order:', workOrder);
                
                // Show success message
                alert('✅ Work order created successfully!');
                
                // Redirect back to list
                window.location.href = '/cmms/workorders/mobile/list';
            }
            
            function startVoiceWorkOrder() {
                alert('🎤 Voice work order creation would activate here. Say something like: "Create work order for pump repair in Building A"');
            }
        </script>
    </body>
    </html>
    """

@mobile_workorders_router.post("/api/create")
async def create_mobile_work_order(
    title: str = Form(...),
    description: str = Form(...),
    asset_id: str = Form(None),
    priority: str = Form("medium"),
    type: str = Form("reactive"),
    due_date: str = Form(None),
    estimated_hours: float = Form(None),
    voice_created: bool = Form(False),
    offline_sync: bool = Form(False)
):
    """API endpoint for creating work orders from mobile forms"""
    
    # Generate new work order ID
    new_id = f"WO-{len(mobile_work_orders_db) + 1:03d}"
    wo_number = f"WO-2025-{len(mobile_work_orders_db) + 1:03d}"
    
    # Create new work order
    new_work_order = {
        "id": new_id,
        "wo_number": wo_number,
        "title": title,
        "description": description,
        "asset_id": asset_id or "AST-001",
        "asset_name": "Unknown Asset",  # Would lookup from asset_id
        "location": "Unknown Location",  # Would lookup from asset
        "type": type,
        "priority": priority,
        "status": "open",
        "created_date": datetime.now().isoformat(),
        "created_by": "Mobile User",  # Would get from auth
        "assigned_to": None,
        "assigned_to_name": None,
        "due_date": due_date,
        "estimated_hours": estimated_hours,
        "actual_hours": None,
        "cost": None,
        "voice_created": voice_created,
        "offline_sync": offline_sync,
        "ai_suggestions": []
    }
    
    # Add to database
    mobile_work_orders_db.append(new_work_order)
    
    logger.info(f"Created work order: {wo_number}")
    
    return JSONResponse({
        "success": True,
        "work_order": new_work_order,
        "message": "Work order created successfully"
    })

@mobile_workorders_router.get("/api/list")
async def get_mobile_work_orders_api(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    assigned_to: Optional[str] = Query(None)
):
    """API endpoint for fetching work orders with mobile optimizations"""
    
    filtered_orders = mobile_work_orders_db.copy()
    
    # Apply filters
    if status:
        filtered_orders = [wo for wo in filtered_orders if wo["status"] == status]
    if priority:
        filtered_orders = [wo for wo in filtered_orders if wo["priority"] == priority]
    if assigned_to:
        filtered_orders = [wo for wo in filtered_orders if wo.get("assigned_to") == assigned_to]
    
    return JSONResponse({
        "success": True,
        "work_orders": filtered_orders,
        "count": len(filtered_orders)
    })