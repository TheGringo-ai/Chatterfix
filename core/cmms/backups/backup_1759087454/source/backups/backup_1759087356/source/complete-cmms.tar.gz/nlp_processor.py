#!/usr/bin/env python3
"""
ChatterFix Natural Language Processing Engine
Advanced NLP for work order processing, asset queries, and maintenance insights
"""

import os
import json
import logging
import asyncio
import re
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from collections import Counter, defaultdict

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# NLP imports
try:
    import spacy  # type: ignore
except Exception:
    spacy = None  # type: ignore

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
    import torch
    NLP_AVAILABLE = True
except ImportError:
    NLP_AVAILABLE = False
    logger.warning("⚠️ NLP libraries not available. Install spacy and transformers for advanced NLP features.")

logger = logging.getLogger(__name__)

# NLP router
nlp_router = APIRouter(prefix="/ai/nlp", tags=["natural-language-processing"])

class NLPAnalysisResult(BaseModel):
    text: str
    intent: str
    entities: Dict[str, List[str]]
    sentiment: str
    confidence: float
    keywords: List[str]
    summary: str
    urgency_score: float
    complexity_score: float

class WorkOrderEnrichment(BaseModel):
    original_description: str
    enhanced_description: str
    extracted_assets: List[str]
    extracted_locations: List[str]
    suggested_priority: str
    estimated_duration: float
    required_skills: List[str]
    safety_concerns: List[str]

class MaintenanceInsight(BaseModel):
    insight_type: str  # trend, pattern, recommendation, alert
    title: str
    description: str
    confidence: float
    impact: str  # low, medium, high, critical
    recommended_actions: List[str]
    data_sources: List[str]

class NLPProcessor:
    def __init__(self):
        self.nlp_model = None
        self.sentiment_analyzer = None
        self.intent_classifier = None
        self.tokenizer = None
        
        # Domain-specific vocabularies
        self.asset_vocabulary = {}
        self.location_vocabulary = {}
        self.skill_vocabulary = {}
        self.maintenance_patterns = {}
        
        # Initialize NLP models
        if NLP_AVAILABLE:
            asyncio.create_task(self.initialize_nlp_models())
        
        # Load domain vocabularies
        self.load_domain_vocabularies()
    
    async def initialize_nlp_models(self):
        """Initialize NLP models and pipelines"""
        try:
            logger.info("🧠 Initializing NLP models...")
            
            # Load spaCy model
            try:
                if spacy:
                    self.nlp_model = spacy.load("en_core_web_sm")
                else:
                    self.nlp_model = None
                logger.info("✅ spaCy model loaded")
            except OSError:
                logger.warning("⚠️ spaCy model not found. Install with: python -m spacy download en_core_web_sm")
                self.nlp_model = None
            
            # Load sentiment analysis pipeline
            try:
                self.sentiment_analyzer = pipeline(
                    "sentiment-analysis",
                    model="cardiffnlp/twitter-roberta-base-sentiment-latest",
                    device=-1  # CPU
                )
                logger.info("✅ Sentiment analyzer loaded")
            except Exception as e:
                logger.warning(f"⚠️ Sentiment analyzer not available: {e}")
                self.sentiment_analyzer = None
            
            # Load intent classification (using a general model, would train domain-specific in production)
            try:
                self.intent_classifier = pipeline(
                    "zero-shot-classification",
                    model="facebook/bart-large-mnli",
                    device=-1  # CPU
                )
                logger.info("✅ Intent classifier loaded")
            except Exception as e:
                logger.warning(f"⚠️ Intent classifier not available: {e}")
                self.intent_classifier = None
            
            logger.info("🎯 NLP models initialization complete")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize NLP models: {e}")
    
    def load_domain_vocabularies(self):
        """Load domain-specific vocabularies for CMMS"""
        self.asset_vocabulary = {
            "pumps": [
                "pump", "impeller", "volute", "seal", "suction", "discharge", 
                "cavitation", "priming", "centrifugal", "positive displacement"
            ],
            "motors": [
                "motor", "rotor", "stator", "winding", "bearing", "shaft",
                "coupling", "alignment", "vibration", "current", "torque"
            ],
            "generators": [
                "generator", "alternator", "fuel", "diesel", "gas", "engine",
                "cooling", "radiator", "battery", "charger", "load bank"
            ],
            "hvac": [
                "hvac", "air conditioning", "heating", "cooling", "refrigerant",
                "compressor", "condenser", "evaporator", "filter", "ductwork"
            ],
            "conveyors": [
                "conveyor", "belt", "roller", "idler", "pulley", "drive",
                "tension", "tracking", "safety", "guard"
            ],
            "electrical": [
                "electrical", "power", "voltage", "current", "circuit", "breaker",
                "fuse", "transformer", "panel", "wiring", "conduit"
            ]
        }
        
        self.location_vocabulary = {
            "buildings": ["building a", "building b", "building c", "main building"],
            "floors": ["basement", "ground floor", "first floor", "second floor", "rooftop"],
            "areas": [
                "production floor", "warehouse", "office", "maintenance shop",
                "parking lot", "loading dock", "storage area", "control room"
            ],
            "zones": ["zone 1", "zone 2", "north", "south", "east", "west"]
        }
        
        self.skill_vocabulary = {
            "mechanical": [
                "mechanical", "machinist", "fitter", "millwright", "rigging",
                "welding", "fabrication", "alignment", "balancing"
            ],
            "electrical": [
                "electrical", "electrician", "wiring", "controls", "plc", 
                "motor control", "instrumentation", "automation"
            ],
            "hvac": [
                "hvac technician", "refrigeration", "air conditioning", "heating",
                "epa certified", "brazing", "recovery", "charging"
            ],
            "hydraulics": [
                "hydraulics", "pneumatics", "fluid power", "pumps", "valves",
                "cylinders", "pressure", "flow"
            ],
            "safety": [
                "safety", "lockout tagout", "confined space", "fall protection",
                "hazmat", "first aid", "cpr", "safety training"
            ]
        }
        
        self.maintenance_patterns = {
            "failure_indicators": [
                "broken", "failed", "not working", "down", "stopped", "dead",
                "leaking", "overheating", "noise", "vibration", "sparking"
            ],
            "urgency_indicators": [
                "emergency", "urgent", "asap", "immediately", "critical", 
                "safety", "hazard", "danger", "shutdown"
            ],
            "routine_indicators": [
                "scheduled", "preventive", "routine", "maintenance", "service",
                "inspection", "lubrication", "cleaning"
            ],
            "condition_indicators": [
                "worn", "corroded", "cracked", "loose", "tight", "hot",
                "cold", "dirty", "clogged", "blocked"
            ]
        }
    
    async def analyze_text(self, text: str, context: str = "general") -> NLPAnalysisResult:
        """Perform comprehensive NLP analysis on text"""
        try:
            logger.info(f"🔍 Analyzing text: '{text[:50]}...' (context: {context})")
            
            # Initialize result
            result = NLPAnalysisResult(
                text=text,
                intent="unknown",
                entities={},
                sentiment="neutral",
                confidence=0.0,
                keywords=[],
                summary="",
                urgency_score=0.0,
                complexity_score=0.0
            )
            
            # Extract entities using spaCy if available
            if self.nlp_model:
                doc = self.nlp_model(text)
                
                # Extract named entities
                entities = defaultdict(list)
                for ent in doc.ents:
                    entities[ent.label_].append(ent.text)
                
                result.entities = dict(entities)
                
                # Extract keywords (nouns and important verbs)
                keywords = []
                for token in doc:
                    if (token.pos_ in ['NOUN', 'VERB'] and 
                        not token.is_stop and 
                        not token.is_punct and 
                        len(token.text) > 2):
                        keywords.append(token.lemma_.lower())
                
                result.keywords = list(set(keywords))[:10]  # Top 10 unique keywords
                
                # Generate summary (first sentence or first 100 chars)
                sentences = [sent.text.strip() for sent in doc.sents]
                result.summary = sentences[0] if sentences else text[:100] + "..."
            
            # Classify intent
            result.intent = self.classify_intent(text, context)
            
            # Analyze sentiment
            if self.sentiment_analyzer:
                try:
                    sentiment_result = self.sentiment_analyzer(text)[0]
                    result.sentiment = sentiment_result['label'].lower()
                    result.confidence = sentiment_result['score']
                except Exception as e:
                    logger.warning(f"Sentiment analysis failed: {e}")
                    result.sentiment = "neutral"
                    result.confidence = 0.5
            else:
                # Simple rule-based sentiment
                result.sentiment = self.simple_sentiment_analysis(text)
                result.confidence = 0.6
            
            # Calculate urgency score
            result.urgency_score = self.calculate_urgency_score(text)
            
            # Calculate complexity score
            result.complexity_score = self.calculate_complexity_score(text)
            
            # Extract domain-specific entities
            domain_entities = self.extract_domain_entities(text)
            result.entities.update(domain_entities)
            
            logger.info(f"✅ NLP analysis complete. Intent: {result.intent}, Urgency: {result.urgency_score:.2f}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ NLP analysis failed: {e}")
            raise HTTPException(status_code=500, detail=f"NLP analysis failed: {str(e)}")
    
    def classify_intent(self, text: str, context: str) -> str:
        """Classify the intent of the text"""
        try:
            text_lower = text.lower()
            
            # Define intent patterns
            intent_patterns = {
                "create_work_order": [
                    r"create.*work order", r"new.*work order", r"need.*repair",
                    r"broken", r"failed", r"not working", r"fix", r"repair"
                ],
                "status_inquiry": [
                    r"status.*", r"what.*happening", r"how.*going",
                    r"progress.*", r"update.*"
                ],
                "schedule_maintenance": [
                    r"schedule.*maintenance", r"plan.*service", r"preventive",
                    r"routine.*maintenance", r"pm.*due"
                ],
                "parts_request": [
                    r"need.*part", r"order.*part", r"replace.*part",
                    r"part.*number", r"inventory"
                ],
                "safety_concern": [
                    r"safety.*", r"hazard", r"danger", r"leak", r"fire",
                    r"emergency", r"unsafe"
                ],
                "information_request": [
                    r"how.*", r"what.*", r"where.*", r"when.*", r"why.*",
                    r"explain", r"show.*", r"find.*"
                ]
            }
            
            # Score each intent
            intent_scores = {}
            for intent, patterns in intent_patterns.items():
                score = 0
                for pattern in patterns:
                    if re.search(pattern, text_lower):
                        score += 1
                if score > 0:
                    intent_scores[intent] = score
            
            # Return highest scoring intent
            if intent_scores:
                return max(intent_scores, key=intent_scores.get)
            
            # Use transformer model if available
            if self.intent_classifier:
                try:
                    candidate_labels = list(intent_patterns.keys())
                    result = self.intent_classifier(text, candidate_labels)
                    return result['labels'][0]
                except Exception as e:
                    logger.warning(f"Intent classification failed: {e}")
            
            return "general_inquiry"
            
        except Exception as e:
            logger.error(f"❌ Intent classification failed: {e}")
            return "unknown"
    
    def simple_sentiment_analysis(self, text: str) -> str:
        """Simple rule-based sentiment analysis"""
        try:
            text_lower = text.lower()
            
            positive_words = [
                "good", "great", "excellent", "working", "fixed", "completed",
                "success", "resolved", "improved", "better"
            ]
            
            negative_words = [
                "bad", "terrible", "broken", "failed", "problem", "issue",
                "error", "fault", "wrong", "poor", "worse", "emergency"
            ]
            
            positive_score = sum(1 for word in positive_words if word in text_lower)
            negative_score = sum(1 for word in negative_words if word in text_lower)
            
            if positive_score > negative_score:
                return "positive"
            elif negative_score > positive_score:
                return "negative"
            else:
                return "neutral"
                
        except Exception as e:
            logger.error(f"❌ Simple sentiment analysis failed: {e}")
            return "neutral"
    
    def calculate_urgency_score(self, text: str) -> float:
        """Calculate urgency score (0.0 - 1.0)"""
        try:
            text_lower = text.lower()
            urgency_score = 0.0
            
            # Check for urgency indicators
            urgency_indicators = self.maintenance_patterns["urgency_indicators"]
            failure_indicators = self.maintenance_patterns["failure_indicators"]
            
            for indicator in urgency_indicators:
                if indicator in text_lower:
                    urgency_score += 0.3
            
            for indicator in failure_indicators:
                if indicator in text_lower:
                    urgency_score += 0.2
            
            # Check for time-sensitive words
            time_sensitive = ["now", "today", "asap", "immediately", "urgent"]
            for word in time_sensitive:
                if word in text_lower:
                    urgency_score += 0.2
            
            # Check for safety keywords
            safety_keywords = ["safety", "hazard", "danger", "leak", "fire", "smoke"]
            for keyword in safety_keywords:
                if keyword in text_lower:
                    urgency_score += 0.3
            
            return min(1.0, urgency_score)
            
        except Exception as e:
            logger.error(f"❌ Urgency score calculation failed: {e}")
            return 0.5  # Default medium urgency
    
    def calculate_complexity_score(self, text: str) -> float:
        """Calculate task complexity score (0.0 - 1.0)"""
        try:
            text_lower = text.lower()
            complexity_score = 0.0
            
            # Simple indicators
            simple_keywords = ["clean", "inspect", "lubricate", "check", "test"]
            simple_count = sum(1 for keyword in simple_keywords if keyword in text_lower)
            
            # Complex indicators
            complex_keywords = [
                "rebuild", "overhaul", "replace", "install", "modify", 
                "upgrade", "troubleshoot", "diagnose", "calibrate"
            ]
            complex_count = sum(1 for keyword in complex_keywords if keyword in text_lower)
            
            # Multiple systems involved
            system_keywords = ["electrical", "mechanical", "hydraulic", "pneumatic", "control"]
            system_count = sum(1 for keyword in system_keywords if keyword in text_lower)
            
            # Calculate base complexity
            if complex_count > 0:
                complexity_score += 0.3 + (complex_count * 0.1)
            elif simple_count > 0:
                complexity_score += 0.1
            else:
                complexity_score += 0.2  # Default
            
            # Add complexity for multiple systems
            if system_count > 1:
                complexity_score += 0.2
            
            # Add complexity for long descriptions (more detail usually means more complex)
            if len(text) > 200:
                complexity_score += 0.1
            elif len(text) > 400:
                complexity_score += 0.2
            
            return min(1.0, complexity_score)
            
        except Exception as e:
            logger.error(f"❌ Complexity score calculation failed: {e}")
            return 0.5  # Default medium complexity
    
    def extract_domain_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract CMMS domain-specific entities"""
        try:
            text_lower = text.lower()
            entities = defaultdict(list)
            
            # Extract assets
            for asset_type, keywords in self.asset_vocabulary.items():
                for keyword in keywords:
                    if keyword in text_lower:
                        entities["assets"].append(keyword)
            
            # Extract locations
            for location_type, keywords in self.location_vocabulary.items():
                for keyword in keywords:
                    if keyword in text_lower:
                        entities["locations"].append(keyword)
            
            # Extract skills
            for skill_type, keywords in self.skill_vocabulary.items():
                for keyword in keywords:
                    if keyword in text_lower:
                        entities["required_skills"].append(skill_type)
            
            # Extract work order numbers
            wo_pattern = r'[Ww][Oo][-\s]?(\d{3,})'
            work_orders = re.findall(wo_pattern, text)
            if work_orders:
                entities["work_orders"] = [f"WO-{wo}" for wo in work_orders]
            
            # Extract asset IDs
            asset_pattern = r'[Aa][Ss][Tt][-\s]?(\d{3,})'
            asset_ids = re.findall(asset_pattern, text)
            if asset_ids:
                entities["asset_ids"] = [f"AST-{aid}" for aid in asset_ids]
            
            # Remove duplicates
            for key in entities:
                entities[key] = list(set(entities[key]))
            
            return dict(entities)
            
        except Exception as e:
            logger.error(f"❌ Domain entity extraction failed: {e}")
            return {}
    
    async def enrich_work_order_description(self, description: str) -> WorkOrderEnrichment:
        """Enrich work order description with AI analysis"""
        try:
            # Analyze the original description
            analysis = await self.analyze_text(description, "work_order")
            
            # Generate enhanced description
            enhanced_description = self.enhance_description(description, analysis)
            
            # Extract specific information
            extracted_assets = analysis.entities.get("assets", [])
            extracted_locations = analysis.entities.get("locations", [])
            required_skills = analysis.entities.get("required_skills", [])
            
            # Suggest priority based on urgency
            if analysis.urgency_score >= 0.8:
                suggested_priority = "critical"
            elif analysis.urgency_score >= 0.6:
                suggested_priority = "high"
            elif analysis.urgency_score >= 0.4:
                suggested_priority = "medium"
            else:
                suggested_priority = "low"
            
            # Estimate duration based on complexity
            base_duration = 2.0  # hours
            duration_multiplier = 1 + analysis.complexity_score
            estimated_duration = base_duration * duration_multiplier
            
            # Identify safety concerns
            safety_concerns = self.identify_safety_concerns(description)
            
            return WorkOrderEnrichment(
                original_description=description,
                enhanced_description=enhanced_description,
                extracted_assets=extracted_assets,
                extracted_locations=extracted_locations,
                suggested_priority=suggested_priority,
                estimated_duration=estimated_duration,
                required_skills=required_skills,
                safety_concerns=safety_concerns
            )
            
        except Exception as e:
            logger.error(f"❌ Work order enrichment failed: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    def enhance_description(self, original: str, analysis: NLPAnalysisResult) -> str:
        """Enhance work order description with additional context"""
        try:
            enhanced_parts = [original]
            
            # Add extracted assets if not explicitly mentioned
            if analysis.entities.get("assets"):
                assets_str = ", ".join(analysis.entities["assets"][:3])
                enhanced_parts.append(f"Affected equipment: {assets_str}")
            
            # Add location context
            if analysis.entities.get("locations"):
                location_str = ", ".join(analysis.entities["locations"][:2])
                enhanced_parts.append(f"Location: {location_str}")
            
            # Add urgency context
            if analysis.urgency_score > 0.7:
                enhanced_parts.append("⚠️ HIGH PRIORITY: Requires immediate attention")
            
            # Add complexity warning
            if analysis.complexity_score > 0.7:
                enhanced_parts.append("🔧 COMPLEX TASK: May require specialized skills or extended time")
            
            # Add safety note if concerns identified
            safety_keywords = ["safety", "hazard", "danger", "leak", "fire"]
            if any(keyword in original.lower() for keyword in safety_keywords):
                enhanced_parts.append("🚨 SAFETY CONCERN: Follow all safety protocols")
            
            return "\n\n".join(enhanced_parts)
            
        except Exception as e:
            logger.error(f"❌ Description enhancement failed: {e}")
            return original
    
    def identify_safety_concerns(self, text: str) -> List[str]:
        """Identify potential safety concerns from text"""
        try:
            text_lower = text.lower()
            concerns = []
            
            safety_patterns = {
                "Electrical hazard": ["electrical", "power", "voltage", "shock", "arc", "electrocution"],
                "Fire/explosion risk": ["fire", "explosion", "flammable", "gas", "fuel", "spark"],
                "Chemical hazard": ["chemical", "toxic", "corrosive", "acid", "caustic", "fumes"],
                "Fall hazard": ["height", "ladder", "scaffold", "roof", "elevated", "climbing"],
                "Confined space": ["tank", "vessel", "pit", "sewer", "confined", "enclosed"],
                "Machinery hazard": ["rotating", "moving parts", "crushing", "pinch point", "blade"],
                "Pressure hazard": ["pressure", "compressed", "steam", "hydraulic", "pneumatic"],
                "Temperature hazard": ["hot", "cold", "steam", "freezing", "burn", "frostbite"]
            }
            
            for concern_type, keywords in safety_patterns.items():
                if any(keyword in text_lower for keyword in keywords):
                    concerns.append(concern_type)
            
            # General safety indicators
            general_safety = ["leak", "spill", "damage", "broken", "emergency"]
            if any(keyword in text_lower for keyword in general_safety):
                concerns.append("General safety assessment required")
            
            return concerns[:5]  # Limit to top 5 concerns
            
        except Exception as e:
            logger.error(f"❌ Safety concern identification failed: {e}")
            return []
    
    async def generate_maintenance_insights(self, work_orders: List[Dict]) -> List[MaintenanceInsight]:
        """Generate insights from historical work order data"""
        try:
            insights = []
            
            if not work_orders:
                return insights
            
            # Analyze patterns in work orders
            asset_frequency = Counter()
            issue_frequency = Counter()
            location_frequency = Counter()
            
            for wo in work_orders:
                description = wo.get("description", "").lower()
                asset_name = wo.get("asset_name", "").lower()
                location = wo.get("location", "").lower()
                
                if asset_name:
                    asset_frequency[asset_name] += 1
                
                if location:
                    location_frequency[location] += 1
                
                # Extract issue types
                for pattern_type, keywords in self.maintenance_patterns.items():
                    for keyword in keywords:
                        if keyword in description:
                            issue_frequency[f"{pattern_type}:{keyword}"] += 1
            
            # Generate insights for frequent assets
            if asset_frequency:
                most_frequent_asset = asset_frequency.most_common(1)[0]
                if most_frequent_asset[1] > 3:  # More than 3 work orders
                    insights.append(MaintenanceInsight(
                        insight_type="trend",
                        title=f"High Maintenance Frequency: {most_frequent_asset[0].title()}",
                        description=f"Asset has {most_frequent_asset[1]} work orders, indicating potential reliability issues.",
                        confidence=0.85,
                        impact="medium",
                        recommended_actions=[
                            "Schedule comprehensive inspection",
                            "Review maintenance procedures",
                            "Consider equipment upgrade"
                        ],
                        data_sources=["work_order_history"]
                    ))
            
            # Generate insights for problem locations
            if location_frequency:
                problematic_location = location_frequency.most_common(1)[0]
                if problematic_location[1] > 2:
                    insights.append(MaintenanceInsight(
                        insight_type="pattern",
                        title=f"Problem Location: {problematic_location[0].title()}",
                        description=f"Location has {problematic_location[1]} maintenance issues, may indicate environmental factors.",
                        confidence=0.75,
                        impact="medium",
                        recommended_actions=[
                            "Investigate environmental conditions",
                            "Increase preventive maintenance frequency",
                            "Consider asset relocation"
                        ],
                        data_sources=["work_order_history", "location_data"]
                    ))
            
            # Generate insights for common failure modes
            failure_issues = {k: v for k, v in issue_frequency.items() if "failure_indicators" in k}
            if failure_issues:
                most_common_failure = max(failure_issues.items(), key=lambda item: item[1])[0] if failure_issues else None
                failure_type = most_common_failure.split(":")[-1]
                count = failure_issues[most_common_failure]
                
                if count > 2:
                    insights.append(MaintenanceInsight(
                        insight_type="alert",
                        title=f"Recurring Failure Mode: {failure_type.title()}",
                        description=f"'{failure_type}' appears in {count} work orders, indicating systemic issue.",
                        confidence=0.80,
                        impact="high",
                        recommended_actions=[
                            f"Root cause analysis for {failure_type} failures",
                            "Update preventive maintenance procedures",
                            "Staff training on failure prevention"
                        ],
                        data_sources=["failure_analysis", "maintenance_records"]
                    ))
            
            # Generate seasonal/temporal insights (if date information available)
            recent_wos = [wo for wo in work_orders if self.is_recent_work_order(wo)]
            if len(recent_wos) > len(work_orders) * 0.7:  # 70% of WOs are recent
                insights.append(MaintenanceInsight(
                    insight_type="trend",
                    title="Increased Maintenance Activity",
                    description=f"{len(recent_wos)} of {len(work_orders)} work orders created recently, indicating increased maintenance needs.",
                    confidence=0.70,
                    impact="medium",
                    recommended_actions=[
                        "Review maintenance scheduling",
                        "Assess equipment condition",
                        "Consider additional resources"
                    ],
                    data_sources=["temporal_analysis"]
                ))
            
            return insights
            
        except Exception as e:
            logger.error(f"❌ Maintenance insights generation failed: {e}")
            return []
    
    def is_recent_work_order(self, work_order: Dict) -> bool:
        """Check if work order is recent (within last 30 days)"""
        try:
            created_date = work_order.get("created_date", "")
            if created_date:
                wo_date = datetime.fromisoformat(created_date.replace('Z', '+00:00'))
                cutoff_date = datetime.now() - timedelta(days=30)
                return wo_date > cutoff_date
            return False
        except:
            return False

# Initialize global NLP processor
nlp_processor = NLPProcessor()

# API Endpoints
@nlp_router.post("/analyze-text")
async def analyze_text_endpoint(data: Dict[str, Any]):
    """Analyze text using NLP"""
    text = data.get("text", "")
    context = data.get("context", "general")
    
    if not text:
        raise HTTPException(status_code=400, detail="Text is required")
    
    result = await nlp_processor.analyze_text(text, context)
    return result

@nlp_router.post("/enrich-work-order")
async def enrich_work_order_endpoint(data: Dict[str, Any]):
    """Enrich work order description with AI analysis"""
    description = data.get("description", "")
    
    if not description:
        raise HTTPException(status_code=400, detail="Description is required")
    
    enrichment = await nlp_processor.enrich_work_order_description(description)
    return enrichment

@nlp_router.post("/generate-insights")
async def generate_maintenance_insights_endpoint(data: Dict[str, Any]):
    """Generate maintenance insights from work order data"""
    work_orders = data.get("work_orders", [])
    
    insights = await nlp_processor.generate_maintenance_insights(work_orders)
    
    return JSONResponse({
        "success": True,
        "insights": [insight.dict() for insight in insights],
        "total_insights": len(insights),
        "analyzed_work_orders": len(work_orders)
    })

@nlp_router.get("/vocabulary")
async def get_domain_vocabulary():
    """Get domain-specific vocabularies"""
    return JSONResponse({
        "asset_vocabulary": nlp_processor.asset_vocabulary,
        "location_vocabulary": nlp_processor.location_vocabulary,
        "skill_vocabulary": nlp_processor.skill_vocabulary,
        "maintenance_patterns": nlp_processor.maintenance_patterns
    })

@nlp_router.get("/models/status")
async def get_nlp_model_status():
    """Get NLP model status"""
    return JSONResponse({
        "nlp_available": NLP_AVAILABLE,
        "spacy_model_loaded": nlp_processor.nlp_model is not None,
        "sentiment_analyzer_loaded": nlp_processor.sentiment_analyzer is not None,
        "intent_classifier_loaded": nlp_processor.intent_classifier is not None,
        "domain_vocabularies_loaded": bool(nlp_processor.asset_vocabulary)
    })