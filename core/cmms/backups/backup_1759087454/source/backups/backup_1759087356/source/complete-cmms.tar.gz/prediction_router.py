"""
Predictive Maintenance API Router for ChatterFix CMMS
FastAPI endpoints for asset risk prediction and maintenance planning.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import logging
from datetime import datetime, timedelta
import asyncio
from baseline_predictor import BaselinePredictiveEngine, AssetRiskPrediction, RiskLevel, RiskReasonCode

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize router
router = APIRouter(prefix="/ai", tags=["predictive", "maintenance"])

# Global predictive engine instance
predictive_engine = None

def get_predictive_engine():
    """Dependency to get predictive engine instance"""
    global predictive_engine
    if predictive_engine is None:
        predictive_engine = BaselinePredictiveEngine()
    return predictive_engine

# =============================================================================
# Request/Response Models
# =============================================================================

class RiskReasonResponse(BaseModel):
    """Response model for risk reasons"""
    code: str
    description: str
    weight: float
    confidence: float
    supporting_data: Dict[str, Any]

class AssetRiskResponse(BaseModel):
    """Response model for asset risk prediction"""
    asset_id: str
    risk_score: float
    risk_level: str
    reasons: List[RiskReasonResponse]
    next_check_date: datetime
    confidence: float
    prediction_date: datetime
    data_quality: float
    upgrade_recommendations: List[str]

class TopRiskAssetsResponse(BaseModel):
    """Response model for top risk assets dashboard"""
    total_assets_analyzed: int
    risk_summary: Dict[str, int]
    top_risk_assets: List[AssetRiskResponse]
    generated_at: datetime
    next_update: datetime

class BatchPredictionRequest(BaseModel):
    """Request model for batch predictions"""
    asset_ids: List[str] = Field(..., min_items=1, max_items=100, description="List of asset IDs to analyze")
    include_details: bool = Field(True, description="Include detailed risk reasons")

class BatchPredictionResponse(BaseModel):
    """Response model for batch predictions"""
    predictions: Dict[str, AssetRiskResponse]
    summary: Dict[str, Any]
    processing_time_ms: int

# =============================================================================
# API Endpoints
# =============================================================================

@router.get("/predict/asset/{asset_id}", response_model=AssetRiskResponse)
async def predict_asset_risk(asset_id: str):
    """
    Predict risk score and failure probability for a specific asset.
    
    Returns stable risk score (0-1) and at least 2 reason codes explaining the risk factors.
    Risk assessment includes failure history, maintenance patterns, age factors, and workload analysis.
    """
    try:
        logger.info(f"Predicting risk for asset: {asset_id}")
        
        engine = get_predictive_engine()
        if not engine:
            raise HTTPException(status_code=503, detail="Predictive engine not available")
        
        # Get prediction
        prediction = engine.predict_asset_risk(asset_id)
        
        # Convert to response format
        return AssetRiskResponse(
            asset_id=prediction.asset_id,
            risk_score=prediction.risk_score,
            risk_level=prediction.risk_level.value,
            reasons=[
                RiskReasonResponse(
                    code=reason.code.value,
                    description=reason.description,
                    weight=reason.weight,
                    confidence=reason.confidence,
                    supporting_data=reason.supporting_data
                ) for reason in prediction.reasons
            ],
            next_check_date=prediction.next_check_date,
            confidence=prediction.confidence,
            prediction_date=prediction.prediction_date,
            data_quality=prediction.data_quality,
            upgrade_recommendations=prediction.upgrade_recommendations
        )
        
    except Exception as e:
        logger.error(f"Risk prediction failed for asset {asset_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Risk prediction failed: {str(e)}"
        )

@router.post("/predict/batch", response_model=BatchPredictionResponse)
async def batch_predict_assets(request: BatchPredictionRequest):
    """
    Batch prediction for multiple assets.
    Useful for dashboard updates and bulk analysis.
    """
    start_time = datetime.now()
    
    try:
        engine = get_predictive_engine()
        if not engine:
            raise HTTPException(status_code=503, detail="Predictive engine not available")
        
        logger.info(f"Batch predicting risk for {len(request.asset_ids)} assets")
        
        predictions = {}
        risk_summary = {"low": 0, "medium": 0, "high": 0, "critical": 0}
        
        for asset_id in request.asset_ids:
            try:
                prediction = engine.predict_asset_risk(asset_id)
                
                predictions[asset_id] = AssetRiskResponse(
                    asset_id=prediction.asset_id,
                    risk_score=prediction.risk_score,
                    risk_level=prediction.risk_level.value,
                    reasons=[
                        RiskReasonResponse(
                            code=reason.code.value,
                            description=reason.description,
                            weight=reason.weight,
                            confidence=reason.confidence,
                            supporting_data=reason.supporting_data
                        ) for reason in prediction.reasons
                    ] if request.include_details else [],
                    next_check_date=prediction.next_check_date,
                    confidence=prediction.confidence,
                    prediction_date=prediction.prediction_date,
                    data_quality=prediction.data_quality,
                    upgrade_recommendations=prediction.upgrade_recommendations
                )
                
                # Update risk summary
                risk_summary[prediction.risk_level.value] += 1
                
            except Exception as e:
                logger.warning(f"Failed to predict risk for {asset_id}: {e}")
                continue
        
        processing_time = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return BatchPredictionResponse(
            predictions=predictions,
            summary={
                "total_analyzed": len(predictions),
                "total_requested": len(request.asset_ids),
                "risk_distribution": risk_summary,
                "average_risk_score": sum(p.risk_score for p in predictions.values()) / max(1, len(predictions)),
                "high_risk_count": risk_summary["high"] + risk_summary["critical"]
            },
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.error(f"Batch prediction failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Batch prediction failed: {str(e)}"
        )

@router.get("/predict/top-risk", response_model=TopRiskAssetsResponse)
async def get_top_risk_assets(limit: int = 20):
    """
    Get top N at-risk assets for dashboard display.
    Rankings are consistent across runs with same data.
    """
    try:
        engine = get_predictive_engine()
        if not engine:
            raise HTTPException(status_code=503, detail="Predictive engine not available")
        
        # Demo asset list - in production this would come from database
        demo_assets = [
            "PUMP-001", "PUMP-002", "PUMP-003", "PUMP-012", "PUMP-015",
            "MOTOR-X", "MOTOR-Y", "MOTOR-Z", "MOTOR-A1", "MOTOR-B2",
            "VALVE-001", "VALVE-002", "VALVE-003", "VALVE-101", "VALVE-201",
            "COMPRESSOR-001", "COMPRESSOR-002", "GENERATOR-001", "GENERATOR-002",
            "TANK-001", "TANK-002", "CONVEYOR-001", "CONVEYOR-002", "FAN-001", "FAN-002"
        ]
        
        logger.info(f"Getting top {limit} at-risk assets from {len(demo_assets)} total assets")
        
        # Get predictions for all assets
        top_predictions = engine.get_top_risk_assets(demo_assets, limit)
        
        # Convert to response format
        top_risk_assets = []
        risk_summary = {"low": 0, "medium": 0, "high": 0, "critical": 0}
        
        for prediction in top_predictions:
            risk_summary[prediction.risk_level.value] += 1
            
            top_risk_assets.append(AssetRiskResponse(
                asset_id=prediction.asset_id,
                risk_score=prediction.risk_score,
                risk_level=prediction.risk_level.value,
                reasons=[
                    RiskReasonResponse(
                        code=reason.code.value,
                        description=reason.description,
                        weight=reason.weight,
                        confidence=reason.confidence,
                        supporting_data=reason.supporting_data
                    ) for reason in prediction.reasons
                ],
                next_check_date=prediction.next_check_date,
                confidence=prediction.confidence,
                prediction_date=prediction.prediction_date,
                data_quality=prediction.data_quality,
                upgrade_recommendations=prediction.upgrade_recommendations
            ))
        
        return TopRiskAssetsResponse(
            total_assets_analyzed=len(demo_assets),
            risk_summary=risk_summary,
            top_risk_assets=top_risk_assets,
            generated_at=datetime.now(),
            next_update=datetime.now() + timedelta(hours=24)  # Daily batch update
        )
        
    except Exception as e:
        logger.error(f"Failed to get top risk assets: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get top risk assets: {str(e)}"
        )

@router.post("/predict/dashboard-update")
async def update_dashboard_predictions(background_tasks: BackgroundTasks):
    """
    Trigger daily batch update of risk predictions for dashboard.
    Runs in background to avoid blocking the request.
    """
    try:
        # Add background task for dashboard update
        background_tasks.add_task(run_daily_batch_update)
        
        return {
            "message": "Dashboard update initiated",
            "status": "running",
            "estimated_completion": (datetime.now() + timedelta(minutes=5)).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to initiate dashboard update: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Dashboard update failed: {str(e)}"
        )

async def run_daily_batch_update():
    """Background task for daily batch prediction update"""
    try:
        logger.info("Starting daily batch prediction update")
        
        engine = get_predictive_engine()
        demo_assets = [
            "PUMP-001", "PUMP-002", "PUMP-003", "PUMP-012", "PUMP-015",
            "MOTOR-X", "MOTOR-Y", "MOTOR-Z", "MOTOR-A1", "MOTOR-B2",
            "VALVE-001", "VALVE-002", "VALVE-003", "VALVE-101", "VALVE-201",
            "COMPRESSOR-001", "COMPRESSOR-002", "GENERATOR-001", "GENERATOR-002",
            "TANK-001", "TANK-002", "CONVEYOR-001", "CONVEYOR-002", "FAN-001", "FAN-002"
        ]
        
        # Run predictions for all assets
        predictions = []
        for asset_id in demo_assets:
            try:
                prediction = engine.predict_asset_risk(asset_id)
                predictions.append(prediction)
            except Exception as e:
                logger.warning(f"Failed to predict risk for {asset_id} in batch update: {e}")
                continue
        
        # Sort by risk (top 20 for dashboard)
        predictions.sort(key=lambda p: p.risk_score, reverse=True)
        top_20 = predictions[:20]
        
        # In production, this would save to database/cache
        logger.info(f"Daily batch update completed: {len(predictions)} assets analyzed, top 20 identified")
        logger.info(f"Top risk assets: {[p.asset_id for p in top_20[:5]]}")  # Log top 5
        
        # For demo purposes, just log the results
        critical_count = len([p for p in predictions if p.risk_level == RiskLevel.CRITICAL])
        high_count = len([p for p in predictions if p.risk_level == RiskLevel.HIGH])
        
        logger.info(f"Risk summary - Critical: {critical_count}, High: {high_count}")
        
    except Exception as e:
        logger.error(f"Daily batch update failed: {e}")

# =============================================================================
# Health and Status Endpoints
# =============================================================================

@router.get("/predict/health")
async def prediction_system_health():
    """Health check for predictive maintenance system"""
    try:
        engine = get_predictive_engine()
        
        # Quick test prediction
        test_prediction = engine.predict_asset_risk("TEST-ASSET-001")
        
        return {
            "status": "healthy",
            "engine_loaded": True,
            "test_prediction_risk": test_prediction.risk_score,
            "test_prediction_reasons": len(test_prediction.reasons),
            "baseline_version": True,
            "upgrade_available": True,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@router.get("/predict/stats")
async def prediction_statistics():
    """Get prediction system statistics"""
    return {
        "version": "baseline_v1.0",
        "prediction_model": "statistical_baseline",
        "risk_factors": [
            "failure_history",
            "maintenance_patterns", 
            "asset_age",
            "work_order_density",
            "performance_trends"
        ],
        "supported_assets": ["pumps", "motors", "valves", "compressors", "generic"],
        "prediction_accuracy": "baseline",
        "upgrade_path": "machine_learning",
        "update_frequency": "daily_batch",
        "risk_levels": ["low", "medium", "high", "critical"],
        "timestamp": datetime.now().isoformat()
    }

# Export router
__all__ = ["router"]