#!/usr/bin/env python3
"""
ChatterFix CMMS - Quality Module
Quality control, inspections, and compliance management
"""

from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta, timezone
import logging
import time
# Import removed to avoid dependency issues
# from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles
# from form_components import FormComponents

logger = logging.getLogger(__name__)

# Quality router
print("QUALITY DEBUG: Creating quality router")
quality_router = APIRouter(prefix="/quality", tags=["quality"])
print("QUALITY DEBUG: Quality router created successfully")

# Mock database for demo purposes
quality_inspections_db = [
    {
        "id": "QC-001",
        "title": "Production Line A Inspection",
        "type": "scheduled",
        "status": "completed",
        "priority": "medium",
        "assigned_to": "TECH-001",
        "created_date": "2025-09-14",
        "due_date": "2025-09-14",
        "completion_date": "2025-09-14",
        "score": 95,
        "passed": True,
        "defects_found": 2,
        "corrective_actions": ["Minor calibration adjustment", "Filter replacement"]
    },
    {
        "id": "QC-002", 
        "title": "Incoming Materials Inspection",
        "type": "incoming",
        "status": "in_progress",
        "priority": "high",
        "assigned_to": "TECH-002",
        "created_date": "2025-09-15",
        "due_date": "2025-09-15",
        "completion_date": None,
        "score": None,
        "passed": None,
        "defects_found": 0,
        "corrective_actions": []
    },
    {
        "id": "QC-003",
        "title": "Final Product Quality Check", 
        "type": "final",
        "status": "failed",
        "priority": "urgent",
        "assigned_to": "TECH-003",
        "created_date": "2025-09-15",
        "due_date": "2025-09-15", 
        "completion_date": "2025-09-15",
        "score": 72,
        "passed": False,
        "defects_found": 8,
        "corrective_actions": ["Rework required", "Process review", "Equipment calibration"]
    }
]

# Mock AI request class for template compatibility
class MockRequest:
    def __init__(self):
        self.url = type('obj', (object,), {'path': '/cmms/quality/dashboard'})()
        
    def get(self, key, default=None):
        return default

print("QUALITY DEBUG: Defining routes")

@quality_router.get("/")
async def quality_root():
    """Redirect to quality dashboard"""
    print("QUALITY DEBUG: Root route called")
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/quality/dashboard", status_code=302)

@quality_router.get("/dashboard", response_class=HTMLResponse)
async def quality_dashboard():
    """Quality dashboard"""
    print("QUALITY DEBUG: Dashboard route called")
    
    # Calculate metrics
    total_inspections = len(quality_inspections_db)
    completed = len([q for q in quality_inspections_db if q['status'] == 'completed'])
    failed = len([q for q in quality_inspections_db if q['status'] == 'failed'])
    in_progress = len([q for q in quality_inspections_db if q['status'] == 'in_progress'])
    
    pass_rate = round((completed / total_inspections * 100) if total_inspections > 0 else 100, 1)
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en" data-theme="dark">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Quality Control - ChatterFix CMMS</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
                min-height: 100vh;
                color: white;
                padding: 2rem;
            }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ text-align: center; margin-bottom: 3rem; }}
            .header h1 {{ font-size: 2.5rem; margin-bottom: 1rem; color: #3498db; }}
            .metrics-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 3rem; }}
            .metric-card {{ 
                background: rgba(255,255,255,0.1);
                backdrop-filter: blur(15px);
                border-radius: 15px;
                padding: 2rem;
                text-align: center;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            .metric-value {{ font-size: 3rem; font-weight: bold; margin-bottom: 0.5rem; }}
            .metric-label {{ font-size: 1.1rem; opacity: 0.8; }}
            .pass {{ color: #2ecc71; }}
            .fail {{ color: #e74c3c; }}
            .progress {{ color: #f39c12; }}
            .total {{ color: #3498db; }}
            .inspections-section {{ 
                background: rgba(255,255,255,0.05);
                border-radius: 20px;
                padding: 2rem;
                margin-bottom: 2rem;
            }}
            .section-title {{ font-size: 1.5rem; margin-bottom: 1.5rem; color: #3498db; }}
            .inspection-card {{ 
                background: rgba(255,255,255,0.08);
                border-radius: 10px;
                padding: 1.5rem;
                margin-bottom: 1rem;
                border-left: 4px solid #3498db;
            }}
            .inspection-header {{ display: flex; justify-content: between; align-items: center; margin-bottom: 1rem; }}
            .inspection-title {{ font-size: 1.2rem; font-weight: bold; }}
            .status-badge {{ 
                padding: 0.3rem 0.8rem;
                border-radius: 20px;
                font-size: 0.8rem;
                font-weight: bold;
                text-transform: uppercase;
            }}
            .status-completed {{ background: #2ecc71; color: white; }}
            .status-failed {{ background: #e74c3c; color: white; }}
            .status-in_progress {{ background: #f39c12; color: white; }}
            .inspection-details {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }}
            .detail-item {{ }}
            .detail-label {{ font-size: 0.9rem; opacity: 0.7; }}
            .detail-value {{ font-size: 1.1rem; font-weight: bold; }}
            .actions-list {{ list-style: none; padding-left: 1rem; }}
            .actions-list li {{ margin-bottom: 0.3rem; opacity: 0.8; }}
            .nav-link {{ color: #3498db; text-decoration: none; margin-right: 1rem; }}
            .nav-link:hover {{ text-decoration: underline; }}
            .refresh-btn {{ 
                background: #3498db;
                color: white;
                border: none;
                padding: 0.8rem 1.5rem;
                border-radius: 8px;
                cursor: pointer;
                font-size: 1rem;
                margin-top: 1rem;
            }}
            .refresh-btn:hover {{ background: #2980b9; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔍 Quality Control Dashboard</h1>
                <p>Monitor inspections, compliance, and quality metrics</p>
                <div style="margin-top: 1rem;">
                    <a href="/cmms/dashboard/main" class="nav-link">📊 Main Dashboard</a>
                    <a href="/cmms/parts/dashboard" class="nav-link">📦 Parts</a>
                    <a href="/cmms/workorders/dashboard" class="nav-link">📋 Work Orders</a>
                    <a href="/cmms/assets/dashboard" class="nav-link">⚙️ Assets</a>
                </div>
            </div>

            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-value total">{total_inspections}</div>
                    <div class="metric-label">Total Inspections</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value pass">{completed}</div>
                    <div class="metric-label">Completed</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value fail">{failed}</div>
                    <div class="metric-label">Failed</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value progress">{pass_rate}%</div>
                    <div class="metric-label">Pass Rate</div>
                </div>
            </div>

            <div class="inspections-section">
                <div class="section-title">📋 Recent Quality Inspections</div>"""
    
    # Add inspection cards
    for inspection in quality_inspections_db:
        status_class = f"status-{inspection['status'].replace(' ', '_')}"
        score_display = f"Score: {inspection['score']}" if inspection['score'] else "Pending"
        
        actions_html = ""
        if inspection['corrective_actions']:
            actions_html = "<ul class='actions-list'>"
            for action in inspection['corrective_actions']:
                actions_html += f"<li>• {action}</li>"
            actions_html += "</ul>"
        
        html_content += f"""
                <div class="inspection-card">
                    <div class="inspection-header">
                        <div>
                            <div class="inspection-title">{inspection['title']}</div>
                            <div class="detail-label">ID: {inspection['id']}</div>
                        </div>
                        <div class="status-badge {status_class}">{inspection['status']}</div>
                    </div>
                    <div class="inspection-details">
                        <div class="detail-item">
                            <div class="detail-label">Type</div>
                            <div class="detail-value">{inspection['type'].title()}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Priority</div>
                            <div class="detail-value">{inspection['priority'].title()}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Assigned To</div>
                            <div class="detail-value">{inspection['assigned_to']}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Due Date</div>
                            <div class="detail-value">{inspection['due_date']}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Score</div>
                            <div class="detail-value">{score_display}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Defects Found</div>
                            <div class="detail-value">{inspection['defects_found']}</div>
                        </div>
                    </div>
                    {f'<div style="margin-top: 1rem;"><div class="detail-label">Corrective Actions:</div>{actions_html}</div>' if actions_html else ''}
                </div>"""
    
    html_content += """
            </div>
            
            <div style="text-align: center;">
                <button class="refresh-btn" onclick="window.location.reload()">🔄 Refresh Dashboard</button>
            </div>
        </div>
        
        <script>
            // Auto-refresh every 30 seconds
            setTimeout(() => {
                window.location.reload();
            }, 30000);
        </script>
    </body>
    </html>
    """
    
    return HTMLResponse(html_content)

print("QUALITY DEBUG: Routes defined successfully")

@quality_router.get("/api")
async def get_quality_inspections(
    status: Optional[str] = Query(None),
    type: Optional[str] = Query(None),
    priority: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all quality inspections with optional filtering"""
    filtered_inspections = quality_inspections_db
    
    if status:
        filtered_inspections = [q for q in filtered_inspections if q['status'] == status]
    if type:
        filtered_inspections = [q for q in filtered_inspections if q['type'] == type]
    if priority:
        filtered_inspections = [q for q in filtered_inspections if q['priority'] == priority]
    
    return filtered_inspections

@quality_router.get("/{inspection_id}")
async def get_quality_inspection(inspection_id: str) -> Dict:
    """Get specific quality inspection details"""
    inspection = next((q for q in quality_inspections_db if q['id'] == inspection_id), None)
    if not inspection:
        raise HTTPException(status_code=404, detail="Inspection not found")
    return inspection