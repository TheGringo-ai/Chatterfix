#!/usr/bin/env python3
"""
ChatterFix CMMS - Security Headers Module
Comprehensive security headers implementation with CSP, HSTS, XFO, and more
"""

import os
import secrets
from typing import Dict, List, Optional, Union
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

# =============================================================================
# Configuration
# =============================================================================

# Environment-based configuration
ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()
DOMAIN = os.getenv("DOMAIN", "chatterfix.com")
ENABLE_HSTS = os.getenv("ENABLE_HSTS", "true").lower() == "true"
HSTS_MAX_AGE = int(os.getenv("HSTS_MAX_AGE", "31536000"))  # 1 year
CSP_REPORT_URI = os.getenv("CSP_REPORT_URI", f"/api/security/csp-report")

# =============================================================================
# Content Security Policy (CSP) Configuration
# =============================================================================

def get_csp_policy(nonce: str = None) -> str:
    """
    Generate Content Security Policy based on environment and requirements
    """
    
    # Base CSP directives
    csp_directives = {
        "default-src": ["'self'"],
        "script-src": [
            "'self'",
            "'unsafe-inline'",  # Needed for some frameworks - consider removing in production
            "https://cdnjs.cloudflare.com",
            "https://cdn.jsdelivr.net",
            "https://unpkg.com"
        ],
        "style-src": [
            "'self'",
            "'unsafe-inline'",  # Needed for dynamic styles - consider using nonces
            "https://fonts.googleapis.com",
            "https://cdnjs.cloudflare.com"
        ],
        "font-src": [
            "'self'",
            "https://fonts.gstatic.com",
            "data:"
        ],
        "img-src": [
            "'self'",
            "data:",
            "https:",
            "blob:"
        ],
        "connect-src": [
            "'self'",
            "wss:",
            "ws:"
        ],
        "media-src": ["'self'"],
        "object-src": ["'none'"],
        "base-uri": ["'self'"],
        "form-action": ["'self'"],
        "frame-ancestors": ["'none'"],
        "upgrade-insecure-requests": None,  # Directive without value
        "block-all-mixed-content": None    # Directive without value
    }
    
    # Add nonce to script-src if provided
    if nonce:
        csp_directives["script-src"].append(f"'nonce-{nonce}'")
        csp_directives["style-src"].append(f"'nonce-{nonce}'")
    
    # Environment-specific adjustments
    if ENVIRONMENT == "development":
        # Allow localhost for development
        csp_directives["script-src"].extend([
            "http://localhost:*",
            "http://127.0.0.1:*",
            "ws://localhost:*",
            "ws://127.0.0.1:*"
        ])
        csp_directives["connect-src"].extend([
            "http://localhost:*",
            "http://127.0.0.1:*",
            "ws://localhost:*",
            "ws://127.0.0.1:*"
        ])
        csp_directives["style-src"].extend([
            "http://localhost:*",
            "http://127.0.0.1:*"
        ])
        
        # Allow eval for development tools
        csp_directives["script-src"].append("'unsafe-eval'")
    
    # Add report URI
    if CSP_REPORT_URI:
        csp_directives["report-uri"] = [CSP_REPORT_URI]
    
    # Convert to CSP string
    csp_parts = []
    for directive, values in csp_directives.items():
        if values is None:
            # Directive without values (like upgrade-insecure-requests)
            csp_parts.append(directive)
        else:
            csp_parts.append(f"{directive} {' '.join(values)}")
    
    return "; ".join(csp_parts)

# =============================================================================
# Security Headers Configuration
# =============================================================================

def get_security_headers(request: Request, nonce: str = None) -> Dict[str, str]:
    """
    Generate comprehensive security headers
    """
    headers = {}
    
    # Content Security Policy
    csp_policy = get_csp_policy(nonce)
    headers["Content-Security-Policy"] = csp_policy
    
    # Also set CSP as report-only for testing (can be removed in production)
    if ENVIRONMENT == "development":
        headers["Content-Security-Policy-Report-Only"] = csp_policy
    
    # HTTP Strict Transport Security (HSTS)
    if ENABLE_HSTS and request.url.scheme == "https":
        hsts_value = f"max-age={HSTS_MAX_AGE}; includeSubDomains"
        if ENVIRONMENT == "production":
            hsts_value += "; preload"
        headers["Strict-Transport-Security"] = hsts_value
    
    # X-Frame-Options (XFO) - Prevents clickjacking
    headers["X-Frame-Options"] = "DENY"
    
    # X-Content-Type-Options - Prevents MIME sniffing
    headers["X-Content-Type-Options"] = "nosniff"
    
    # X-XSS-Protection - XSS filter (legacy but still useful)
    headers["X-XSS-Protection"] = "1; mode=block"
    
    # Referrer Policy - Controls referrer information
    headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    
    # Permissions Policy (formerly Feature Policy)
    permissions_policy = [
        "geolocation=(self)",
        "microphone=()",
        "camera=()",
        "magnetometer=()",
        "gyroscope=()",
        "speaker=(self)",
        "notifications=(self)",
        "push=(self)",
        "payment=()"
    ]
    headers["Permissions-Policy"] = ", ".join(permissions_policy)
    
    # Cross-Origin Embedder Policy
    headers["Cross-Origin-Embedder-Policy"] = "require-corp"
    
    # Cross-Origin Opener Policy  
    headers["Cross-Origin-Opener-Policy"] = "same-origin"
    
    # Cross-Origin Resource Policy
    headers["Cross-Origin-Resource-Policy"] = "same-origin"
    
    # Production-correct HTTP caching rules
    path = str(request.url.path).lower()
    
    # Sensitive/authenticated routes - no cache, private
    if any(sensitive in path for sensitive in ["/auth", "/api", "/admin", "/cmms/", "/metrics"]):
        headers["Cache-Control"] = "no-cache, private"
        headers["Pragma"] = "no-cache"
        headers["Expires"] = "0"
    
    # Static versioned assets - long cache, public, immutable
    elif any(static in path for static in ["/static/", ".js", ".css", ".png", ".jpg", ".ico", ".woff", ".svg"]):
        headers["Cache-Control"] = "public, max-age=31536000, immutable"
    
    # Default for other content - short cache
    else:
        headers["Cache-Control"] = "public, max-age=300"
    
    # Server header removal/modification
    headers["Server"] = "ChatterFix-CMMS"
    
    # Custom security headers
    headers["X-Security-Headers"] = "enabled"
    headers["X-Request-ID"] = getattr(request.state, "request_id", "unknown")
    
    return headers

# =============================================================================
# Security Headers Middleware
# =============================================================================

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Middleware to add comprehensive security headers to all responses
    """
    
    def __init__(
        self,
        app: ASGIApp,
        enable_csp: bool = True,
        enable_hsts: bool = True,
        enable_referrer_policy: bool = True,
        enable_permissions_policy: bool = True,
        custom_headers: Dict[str, str] = None
    ):
        super().__init__(app)
        self.enable_csp = enable_csp
        self.enable_hsts = enable_hsts
        self.enable_referrer_policy = enable_referrer_policy
        self.enable_permissions_policy = enable_permissions_policy
        self.custom_headers = custom_headers or {}
    
    async def dispatch(self, request: Request, call_next):
        """Process request and add security headers to response"""
        
        # Generate nonce for CSP
        nonce = secrets.token_urlsafe(16)
        request.state.csp_nonce = nonce
        
        try:
            # Process the request
            response = await call_next(request)
            
            # Get security headers
            security_headers = get_security_headers(request, nonce)
            
            # Add security headers to response
            for header_name, header_value in security_headers.items():
                # Allow disabling specific headers
                if header_name.startswith("Content-Security-Policy") and not self.enable_csp:
                    continue
                if header_name.startswith("Strict-Transport-Security") and not self.enable_hsts:
                    continue
                if header_name == "Referrer-Policy" and not self.enable_referrer_policy:
                    continue
                if header_name == "Permissions-Policy" and not self.enable_permissions_policy:
                    continue
                
                response.headers[header_name] = header_value
            
            # Add any custom headers
            for header_name, header_value in self.custom_headers.items():
                response.headers[header_name] = header_value
            
            return response
            
        except Exception as e:
            # Even for errors, we want security headers
            error_response = JSONResponse(
                status_code=500,
                content={"error": "Internal server error", "request_id": getattr(request.state, "request_id", "unknown")}
            )
            
            # Add basic security headers to error response
            basic_headers = {
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": "DENY",
                "Referrer-Policy": "strict-origin-when-cross-origin",
                "X-Request-ID": getattr(request.state, "request_id", "unknown")
            }
            
            for header_name, header_value in basic_headers.items():
                error_response.headers[header_name] = header_value
            
            return error_response

# =============================================================================
# CSP Violation Reporting
# =============================================================================

class CSPViolationReport:
    """Handler for CSP violation reports"""
    
    def __init__(self):
        self.violations = []
    
    async def handle_csp_report(self, request: Request) -> JSONResponse:
        """Handle CSP violation report"""
        try:
            report_data = await request.json()
            
            violation = {
                "timestamp": request.state.get("timestamp"),
                "user_agent": request.headers.get("user-agent"),
                "ip_address": request.client.host if request.client else "unknown",
                "violation": report_data.get("csp-report", {}),
                "request_id": getattr(request.state, "request_id", "unknown")
            }
            
            # Store violation (in production, this would go to a database or logging system)
            self.violations.append(violation)
            
            # Log the violation
            print(f"CSP_VIOLATION: {violation}")
            
            return JSONResponse({"status": "received"}, status_code=204)
            
        except Exception as e:
            print(f"CSP report handling error: {e}")
            return JSONResponse({"error": "Invalid report"}, status_code=400)
    
    def get_violations(self, limit: int = 100) -> List[Dict]:
        """Get recent CSP violations"""
        return self.violations[-limit:]

# =============================================================================
# Security Configuration Validation
# =============================================================================

def validate_security_config() -> Dict[str, Union[bool, List[str]]]:
    """
    Validate current security configuration
    """
    issues = []
    warnings = []
    
    # Check HTTPS enforcement
    if not ENABLE_HSTS:
        warnings.append("HSTS is disabled - consider enabling for production")
    
    # Check CSP configuration
    csp = get_csp_policy()
    if "'unsafe-inline'" in csp:
        warnings.append("CSP allows 'unsafe-inline' - consider using nonces or hashes")
    
    if "'unsafe-eval'" in csp:
        warnings.append("CSP allows 'unsafe-eval' - this may be needed for development")
    
    # Check environment-specific settings
    if ENVIRONMENT == "production":
        if "localhost" in csp:
            issues.append("Production CSP should not include localhost sources")
        
        if not ENABLE_HSTS:
            issues.append("HSTS should be enabled in production")
    
    # Check domain configuration
    if DOMAIN == "chatterfix.com" and ENVIRONMENT == "development":
        warnings.append("Using production domain in development environment")
    
    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "warnings": warnings,
        "environment": ENVIRONMENT,
        "hsts_enabled": ENABLE_HSTS,
        "csp_report_uri": CSP_REPORT_URI
    }

# =============================================================================
# Utility Functions
# =============================================================================

def get_nonce_from_request(request: Request) -> Optional[str]:
    """Get the CSP nonce from request state"""
    return getattr(request.state, "csp_nonce", None)

def is_secure_request(request: Request) -> bool:
    """Check if request is over HTTPS"""
    return request.url.scheme == "https"

def get_security_headers_info() -> Dict:
    """Get information about available security headers"""
    return {
        "available_headers": [
            "Content-Security-Policy",
            "Strict-Transport-Security",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "X-XSS-Protection",
            "Referrer-Policy",
            "Permissions-Policy",
            "Cross-Origin-Embedder-Policy",
            "Cross-Origin-Opener-Policy",
            "Cross-Origin-Resource-Policy"
        ],
        "environment": ENVIRONMENT,
        "hsts_max_age": HSTS_MAX_AGE,
        "domain": DOMAIN,
        "csp_report_uri": CSP_REPORT_URI
    }

# Global CSP violation reporter instance
csp_reporter = CSPViolationReport()