#!/usr/bin/env python3
"""
Shared State Manager
Manages shared state and communication between CMMS modules
"""

import asyncio
import logging
import time
from typing import Dict, Any, List, Callable, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from enum import Enum

logger = logging.getLogger(__name__)

class EventType(Enum):
    """Event types for inter-module communication"""
    WORK_ORDER_CREATED = "work_order_created"
    WORK_ORDER_UPDATED = "work_order_updated"
    ASSET_STATUS_CHANGED = "asset_status_changed"
    MAINTENANCE_SCHEDULED = "maintenance_scheduled"
    AI_PREDICTION_GENERATED = "ai_prediction_generated"
    SYSTEM_HEALTH_CHANGED = "system_health_changed"
    USER_ACTION = "user_action"
    MODULE_STATUS_CHANGED = "module_status_changed"

@dataclass
class SystemEvent:
    """System event data structure"""
    event_type: EventType
    source_module: str
    data: Dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    event_id: str = field(default_factory=lambda: f"evt_{int(time.time() * 1000)}")
    priority: int = 1  # 1=high, 2=medium, 3=low

class SharedStateManager:
    """Manages shared state across all CMMS modules"""
    
    def __init__(self):
        self.shared_data: Dict[str, Any] = {}
        self.event_subscribers: Dict[EventType, List[Callable]] = {}
        self.event_history: List[SystemEvent] = []
        self.max_event_history = 1000
        self._lock = asyncio.Lock()
        
        # System-wide metrics
        self.metrics = {
            "events_processed": 0,
            "active_subscribers": 0,
            "last_activity": None
        }
        
        logger.info("🔄 Shared State Manager initialized")
    
    async def set_shared_data(self, key: str, value: Any, source_module: str = "unknown") -> None:
        """Set shared data with thread safety"""
        async with self._lock:
            old_value = self.shared_data.get(key)
            self.shared_data[key] = value
            self.metrics["last_activity"] = datetime.now(timezone.utc)
            
            # Emit data change event
            await self.emit_event(
                EventType.MODULE_STATUS_CHANGED,
                source_module,
                {
                    "key": key,
                    "old_value": old_value,
                    "new_value": value
                }
            )
    
    async def get_shared_data(self, key: str, default: Any = None) -> Any:
        """Get shared data with thread safety"""
        async with self._lock:
            return self.shared_data.get(key, default)
    
    async def update_shared_data(self, updates: Dict[str, Any], source_module: str = "unknown") -> None:
        """Batch update shared data"""
        async with self._lock:
            changes = {}
            for key, value in updates.items():
                old_value = self.shared_data.get(key)
                self.shared_data[key] = value
                changes[key] = {"old": old_value, "new": value}
            
            self.metrics["last_activity"] = datetime.now(timezone.utc)
            
            # Emit batch update event
            await self.emit_event(
                EventType.MODULE_STATUS_CHANGED,
                source_module,
                {"batch_update": changes}
            )
    
    def subscribe_to_event(self, event_type: EventType, callback: Callable[[SystemEvent], None]) -> None:
        """Subscribe to specific event types"""
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = []
        
        self.event_subscribers[event_type].append(callback)
        self.metrics["active_subscribers"] = sum(len(subs) for subs in self.event_subscribers.values())
        
        logger.info(f"📡 New subscriber for {event_type.value}")
    
    async def emit_event(self, event_type: EventType, source_module: str, data: Dict[str, Any], priority: int = 2) -> None:
        """Emit an event to all subscribers"""
        event = SystemEvent(
            event_type=event_type,
            source_module=source_module,
            data=data,
            priority=priority
        )
        
        # Add to history
        self.event_history.append(event)
        if len(self.event_history) > self.max_event_history:
            self.event_history = self.event_history[-self.max_event_history:]
        
        self.metrics["events_processed"] += 1
        
        # Notify subscribers
        subscribers = self.event_subscribers.get(event_type, [])
        for callback in subscribers:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(event)
                else:
                    callback(event)
            except Exception as e:
                logger.error(f"Error in event callback for {event_type.value}: {e}")
        
        logger.debug(f"📤 Emitted event: {event_type.value} from {source_module}")
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        async with self._lock:
            recent_events = [
                {
                    "type": event.event_type.value,
                    "source": event.source_module,
                    "timestamp": event.timestamp.isoformat(),
                    "priority": event.priority
                }
                for event in self.event_history[-10:]  # Last 10 events
            ]
            
            return {
                "shared_data_keys": list(self.shared_data.keys()),
                "metrics": self.metrics.copy(),
                "recent_events": recent_events,
                "event_types_subscribed": [et.value for et in self.event_subscribers.keys()],
                "total_subscribers": self.metrics["active_subscribers"]
            }
    
    async def get_module_communication_health(self) -> Dict[str, Any]:
        """Analyze communication health between modules"""
        # Analyze event patterns
        module_activity = {}
        event_type_counts = {}
        
        for event in self.event_history[-100:]:  # Analyze last 100 events
            # Track module activity
            if event.source_module not in module_activity:
                module_activity[event.source_module] = 0
            module_activity[event.source_module] += 1
            
            # Track event type distribution
            event_key = event.event_type.value
            if event_key not in event_type_counts:
                event_type_counts[event_key] = 0
            event_type_counts[event_key] += 1
        
        return {
            "module_activity": module_activity,
            "event_distribution": event_type_counts,
            "communication_health": "healthy" if len(module_activity) > 1 else "limited",
            "active_modules": len(module_activity),
            "event_variety": len(event_type_counts)
        }
    
    def clear_event_history(self) -> None:
        """Clear event history (useful for testing or maintenance)"""
        self.event_history.clear()
        self.metrics["events_processed"] = 0
        logger.info("🧹 Event history cleared")

# Global shared state manager instance
shared_state = SharedStateManager()

# Convenience functions for common operations
async def set_system_status(module_name: str, status: str, details: Dict[str, Any] = None) -> None:
    """Convenience function to set module status"""
    await shared_state.emit_event(
        EventType.MODULE_STATUS_CHANGED,
        module_name,
        {"status": status, "details": details or {}}
    )

async def notify_work_order_change(module_name: str, work_order_id: str, action: str, data: Dict[str, Any] = None) -> None:
    """Convenience function for work order notifications"""
    event_type = EventType.WORK_ORDER_CREATED if action == "created" else EventType.WORK_ORDER_UPDATED
    await shared_state.emit_event(
        event_type,
        module_name,
        {"work_order_id": work_order_id, "action": action, "data": data or {}},
        priority=1  # High priority for work orders
    )

async def notify_asset_change(module_name: str, asset_id: str, old_status: str, new_status: str, details: Dict[str, Any] = None) -> None:
    """Convenience function for asset status changes"""
    await shared_state.emit_event(
        EventType.ASSET_STATUS_CHANGED,
        module_name,
        {
            "asset_id": asset_id,
            "old_status": old_status,
            "new_status": new_status,
            "details": details or {}
        },
        priority=1
    )

async def notify_ai_prediction(module_name: str, prediction_type: str, asset_id: str, prediction_data: Dict[str, Any]) -> None:
    """Convenience function for AI prediction notifications"""
    await shared_state.emit_event(
        EventType.AI_PREDICTION_GENERATED,
        module_name,
        {
            "prediction_type": prediction_type,
            "asset_id": asset_id,
            "prediction": prediction_data
        },
        priority=2
    )

if __name__ == "__main__":
    # Test the shared state manager
    async def test_shared_state():
        await shared_state.set_shared_data("test_key", "test_value", "test_module")
        value = await shared_state.get_shared_data("test_key")
        print(f"Retrieved value: {value}")
        
        status = await shared_state.get_system_status()
        print("System status:", status)
    
    asyncio.run(test_shared_state())