#!/usr/bin/env python3
"""
Smart Work Order Creation Feature
Adds AI-powered natural language to structured work order conversion
"""

# Smart work order creation function to add to workorders.py
SMART_WORKORDER_FUNCTION = '''

@workorders_router.post("/smart-create")
async def smart_create_work_order(request: Dict[str, str]) -> Dict:
    """Create work order from natural language using AI"""
    try:
        natural_language = request.get("message", "")
        user_context = request.get("context", "work_order_creation")
        
        if not natural_language.strip():
            raise HTTPException(status_code=400, detail="Message cannot be empty")
        
        # Use AI to parse natural language into structured data
        ai_prompt = f"""
Convert this maintenance request into structured work order data. Respond with JSON only:

Request: "{natural_language}"

Extract these fields:
- title: Brief descriptive title (max 50 chars)
- description: Detailed description 
- asset_id: Equipment/asset name or "Unknown Asset"
- type: "repair", "preventive", "inspection", or "emergency"
- priority: "low", "medium", "high", or "critical"
- estimated_hours: Number (1-40 hours reasonable estimate)

JSON format only:"""

        # Call AI to parse the request
        from ai import query_llama
        ai_response = await query_llama(ai_prompt, user_context, "smart_workorder")
        
        # Try to extract JSON from AI response
        import json
        import re
        
        # Find JSON in the response
        json_match = re.search(r'\\{.*\\}', ai_response, re.DOTALL)
        if json_match:
            try:
                parsed_data = json.loads(json_match.group())
            except json.JSONDecodeError:
                # Fallback parsing if JSON is malformed
                parsed_data = parse_fallback(natural_language)
        else:
            # Fallback parsing if no JSON found
            parsed_data = parse_fallback(natural_language)
        
        # Validate and clean the parsed data
        work_order_data = {
            "title": str(parsed_data.get("title", "AI Generated Work Order"))[:50],
            "description": str(parsed_data.get("description", natural_language))[:500],
            "asset_id": str(parsed_data.get("asset_id", "Unknown Asset")),
            "type": parsed_data.get("type", "repair").lower(),
            "priority": parsed_data.get("priority", "medium").lower(),
            "estimated_hours": float(parsed_data.get("estimated_hours", 2.0)),
            "created_by": "AI Assistant",
            "ai_generated": True,
            "original_request": natural_language
        }
        
        # Validate priority and type
        if work_order_data["priority"] not in ["low", "medium", "high", "critical"]:
            work_order_data["priority"] = "medium"
        
        if work_order_data["type"] not in ["repair", "preventive", "inspection", "emergency"]:
            work_order_data["type"] = "repair"
        
        # Create the work order using existing function
        result = await create_work_order(work_order_data)
        
        # Add AI parsing metadata
        result["ai_parsed"] = True
        result["original_request"] = natural_language
        result["parsing_method"] = "llama_ai" if json_match else "fallback"
        
        logger.info(f"Smart work order created: {result['id']} from request: {natural_language[:50]}...")
        
        return result
        
    except Exception as e:
        logger.error(f"Smart work order creation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create smart work order: {str(e)}")

def parse_fallback(text: str) -> Dict:
    """Fallback parsing if AI fails"""
    text_lower = text.lower()
    
    # Determine priority from keywords
    priority = "medium"
    if any(word in text_lower for word in ["urgent", "critical", "emergency", "down", "broken"]):
        priority = "high"
    elif any(word in text_lower for word in ["asap", "priority", "important"]):
        priority = "high"
    elif any(word in text_lower for word in ["routine", "scheduled", "low"]):
        priority = "low"
    
    # Determine type from keywords
    work_type = "repair"
    if any(word in text_lower for word in ["inspect", "check", "review"]):
        work_type = "inspection"
    elif any(word in text_lower for word in ["preventive", "maintenance", "service"]):
        work_type = "preventive"
    elif any(word in text_lower for word in ["emergency", "urgent", "critical"]):
        work_type = "emergency"
    
    # Extract asset information
    asset_id = "Unknown Asset"
    for equipment in ["hvac", "pump", "motor", "conveyor", "compressor", "generator", "boiler"]:
        if equipment in text_lower:
            asset_id = equipment.upper()
            break
    
    # Estimate hours based on type and priority
    hours = 2.0
    if work_type == "inspection":
        hours = 1.0
    elif work_type == "preventive":
        hours = 3.0
    elif priority == "high":
        hours = 4.0
    
    return {
        "title": text[:50] if len(text) <= 50 else text[:47] + "...",
        "description": text,
        "asset_id": asset_id,
        "type": work_type,
        "priority": priority,
        "estimated_hours": hours
    }
'''

def apply_patch():
    """Apply the smart work order patch to workorders.py"""
    print("📝 Adding Smart Work Order Creation feature...")
    
    # Read current workorders.py
    with open('/opt/chatterfix/workorders.py', 'r') as f:
        content = f.read()
    
    # Check if already patched
    if 'smart-create' in content:
        print("✅ Smart work order feature already exists")
        return True
    
    # Find a good insertion point (before the last function or at the end)
    # Insert before the last @workorders_router line
    import re
    router_matches = list(re.finditer(r'@workorders_router\\.', content))
    
    if router_matches:
        # Insert before the last router definition
        last_router_pos = router_matches[-1].start()
        insertion_point = content.rfind('\\n', 0, last_router_pos)
        
        if insertion_point == -1:
            insertion_point = last_router_pos
    else:
        # Insert at the end before any main block
        main_pos = content.find('if __name__ == "__main__"')
        if main_pos != -1:
            insertion_point = content.rfind('\\n', 0, main_pos)
        else:
            insertion_point = len(content)
    
    # Insert the smart work order function
    new_content = (content[:insertion_point] + 
                   SMART_WORKORDER_FUNCTION + 
                   content[insertion_point:])
    
    # Write the updated content
    with open('/opt/chatterfix/workorders.py', 'w') as f:
        f.write(new_content)
    
    print("✅ Smart Work Order Creation feature added to workorders.py")
    return True

if __name__ == "__main__":
    apply_patch()