#!/usr/bin/env python3
"""
CMMS Technician Module
Technician portal, task management, and mobile interface
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging
from unified_cmms_system import create_unified_page

logger = logging.getLogger(__name__)

# Technician router
technician_router = APIRouter(prefix="/technician", tags=["technician"])

# Data models
class Technician(BaseModel):
    id: str
    name: str
    email: str
    phone: str
    skills: List[str]
    certifications: List[str]
    status: str
    location: str
    shift: str

class TechnicianTask(BaseModel):
    id: str
    title: str
    description: str
    asset_id: str
    priority: str
    status: str
    assigned_date: str
    due_date: str
    estimated_hours: float
    technician_id: str

class TimeEntry(BaseModel):
    id: str
    technician_id: str
    task_id: str
    date: str
    hours: float
    description: str
    status: str

# Mock database
technicians_db = [
    {
        "id": "TECH-001",
        "name": "John Smith",
        "email": "john.smith@chatterfix.com",
        "phone": "(555) 123-4567",
        "skills": ["Mechanical", "Electrical", "Pneumatics", "Generator"],
        "certifications": ["OSHA 30", "Electrical License", "Arc Flash"],
        "status": "available",
        "location": "Building A",
        "shift": "day"
    },
    {
        "id": "TECH-002",
        "name": "Mike Johnson",
        "email": "mike.johnson@chatterfix.com", 
        "phone": "(555) 234-5678",
        "skills": ["Mechanical", "Belt Systems", "Conveyor", "Packaging"],
        "certifications": ["OSHA 10", "Mechanical Certification"],
        "status": "busy",
        "location": "Production Floor 1",
        "shift": "day"
    },
    {
        "id": "TECH-003",
        "name": "Sarah Davis",
        "email": "sarah.davis@chatterfix.com",
        "phone": "(555) 345-6789",
        "skills": ["HVAC", "Refrigeration", "Controls", "Electronics"],
        "certifications": ["EPA 608", "HVAC License", "Controls Certification"],
        "status": "available",
        "location": "Building A - Roof",
        "shift": "day"
    },
    {
        "id": "TECH-004",
        "name": "Carlos Rodriguez",
        "email": "carlos.rodriguez@chatterfix.com",
        "phone": "(555) 456-7890",
        "skills": ["Electrical", "Automation", "PLC", "Motor Control"],
        "certifications": ["Journeyman Electrician", "PLC Programming", "Safety Training"],
        "status": "busy",
        "location": "Production Floor 2",
        "shift": "night"
    },
    {
        "id": "TECH-005",
        "name": "Lisa Wong",
        "email": "lisa.wong@chatterfix.com",
        "phone": "(555) 567-8901",
        "skills": ["Mechanical", "Welding", "Fabrication", "Precision"],
        "certifications": ["AWS Welding", "Machinist Certificate", "Safety Training"],
        "status": "available",
        "location": "Maintenance Shop",
        "shift": "day"
    }
]

technician_tasks_db = [
    {
        "id": "TASK-001",
        "title": "Weekly Generator Test",
        "description": "Perform weekly function test on emergency generator",
        "asset_id": "AST-004",
        "priority": "high",
        "status": "in_progress",
        "assigned_date": "2025-09-01",
        "due_date": "2025-09-01",
        "estimated_hours": 1.0,
        "technician_id": "TECH-001"
    },
    {
        "id": "TASK-002",
        "title": "Conveyor Belt Maintenance",
        "description": "Monthly belt inspection and lubrication",
        "asset_id": "AST-002", 
        "priority": "medium",
        "status": "assigned",
        "assigned_date": "2025-09-01",
        "due_date": "2025-09-03",
        "estimated_hours": 2.0,
        "technician_id": "TECH-002"
    },
    {
        "id": "TASK-003",
        "title": "HVAC Filter Replacement",
        "description": "Replace filters and check system operation",
        "asset_id": "AST-003",
        "priority": "medium",
        "status": "assigned",
        "assigned_date": "2025-08-30",
        "due_date": "2025-09-05",
        "estimated_hours": 4.0,
        "technician_id": "TECH-003"
    },
    {
        "id": "TASK-004",
        "title": "Packaging Machine Repair",
        "description": "Diagnose and repair motor bearing issues",
        "asset_id": "AST-005",
        "priority": "urgent",
        "status": "assigned",
        "assigned_date": "2025-08-31",
        "due_date": "2025-09-02",
        "estimated_hours": 8.0,
        "technician_id": "TECH-004"
    },
    {
        "id": "TASK-005",
        "title": "Compressor Oil Analysis",
        "description": "Collect oil sample and perform analysis",
        "asset_id": "AST-001",
        "priority": "low",
        "status": "pending",
        "assigned_date": "2025-09-01",
        "due_date": "2025-09-10",
        "estimated_hours": 0.5,
        "technician_id": "TECH-001"
    }
]

time_entries_db = [
    {
        "id": "TIME-001",
        "technician_id": "TECH-001",
        "task_id": "TASK-001",
        "date": "2025-09-01",
        "hours": 0.5,
        "description": "Started generator test - checking fuel level",
        "status": "active"
    },
    {
        "id": "TIME-002",
        "technician_id": "TECH-002",
        "task_id": "TASK-002",
        "date": "2025-08-31",
        "hours": 1.0,
        "description": "Prepared tools and safety equipment",
        "status": "submitted"
    },
    {
        "id": "TIME-003",
        "technician_id": "TECH-004",
        "task_id": "TASK-004",
        "date": "2025-08-31",
        "hours": 2.5,
        "description": "Diagnosed bearing issue, ordered replacement parts",
        "status": "submitted"
    }
]

@technician_router.get("/")
async def technician_root():
    """Redirect to technician portal"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/technician/portal", status_code=302)

@technician_router.get("/portal", response_class=HTMLResponse)
async def technician_portal():
    """Main technician portal dashboard"""
    breadcrumbs = [
        {"name": "Technician Portal"}
    ]
    
    content = """
        <div class="stats-grid">
            <div class="cmms-card" onclick="window.location.href='/cmms/workorders/dashboard'">
                <h3>📋 My Work Orders</h3>
                <p>View assigned tasks and update status</p>
                <button class="cmms-btn">View Tasks</button>
            </div>
            
            <div class="cmms-card" onclick="window.location.href='/cmms/technicians/schedule'">
                <h3>📅 Schedule</h3>
                <p>Today's assignments and calendar</p>
                <button class="cmms-btn">View Schedule</button>
            </div>
            
            <div class="cmms-card" onclick="window.location.href='/cmms/assets/dashboard'">
                <h3>⚙️ Equipment</h3>
                <p>Asset information and history</p>
                <button class="cmms-btn">Browse Assets</button>
            </div>
            
            <div class="cmms-card" onclick="window.location.href='/cmms/parts/dashboard'">
                <h3>📦 Parts Lookup</h3>
                <p>Find spare parts and inventory</p>
                <button class="cmms-btn">Search Parts</button>
            </div>
            
            <div class="cmms-card" onclick="window.location.href='/cmms/ai-enhanced/dashboard/universal'">
                <h3>🤖 AI Assistant</h3>
                <p>Get help with troubleshooting and repairs</p>
                <button class="cmms-btn">Ask AI</button>
            </div>
            
            <div class="cmms-card" onclick="window.location.href='/cmms/technicians/reports/productivity'">
                <h3>📊 My Reports</h3>
                <p>Productivity and performance metrics</p>
                <button class="cmms-btn">View Reports</button>
            </div>
        </div>
        
        <div class="cmms-card">
            <h3>🔧 Quick Actions</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
                <button class="cmms-btn" onclick="createWorkOrder()">🆕 Create Work Order</button>
                <button class="cmms-btn" onclick="scanBarcode()">📷 Scan Barcode</button>
                <button class="cmms-btn" onclick="logTime()">⏱️ Log Time</button>
                <button class="cmms-btn" onclick="requestParts()">📦 Request Parts</button>
                <button class="cmms-btn" onclick="uploadPhoto()">📸 Upload Photo</button>
                <button class="cmms-btn" onclick="voiceCommand()">🎤 Voice Command</button>
            </div>
        </div>
        
        <div class="cmms-card">
            <h3>📱 Mobile Tools</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
                <button class="cmms-btn cmms-btn-success" onclick="openCamera()">📸 Take Photo</button>
                <button class="cmms-btn cmms-btn-success" onclick="recordVoice()">🎤 Voice Note</button>
                <button class="cmms-btn cmms-btn-success" onclick="useFlashlight()">🔦 Flashlight</button>
                <button class="cmms-btn cmms-btn-success" onclick="measureTool()">📏 Measure</button>
                <button class="cmms-btn cmms-btn-success" onclick="ocrScan()">📄 OCR Scan</button>
                <button class="cmms-btn cmms-btn-success" onclick="manualLookup()">📚 View Manuals</button>
            </div>
        </div>
        
        <script>
            function createWorkOrder() { 
                showModal('Create Work Order', `
                    <form id="createWorkOrderForm">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Title:</label>
                            <input type="text" name="title" required style="width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.2); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Priority:</label>
                            <select name="priority" required style="width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.2); color: white;">
                                <option value="low">Low</option>
                                <option value="medium" selected>Medium</option>
                                <option value="high">High</option>
                                <option value="urgent">Urgent</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Description:</label>
                            <textarea name="description" required style="width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.2); color: white; height: 100px;"></textarea>
                        </div>
                    </form>
                `, [
                    { text: 'Cancel', onclick: 'closeModal()' },
                    { text: 'Create', class: 'cmms-btn-success', onclick: 'submitWorkOrder()' }
                ]);
            }
            
            function submitWorkOrder() {
                const form = document.getElementById('createWorkOrderForm');
                const formData = new FormData(form);
                const data = Object.fromEntries(formData);
                
                fetch('/cmms/workorders/', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(result => {
                    showNotification('Work order created successfully!', 'success');
                    closeModal();
                })
                .catch(error => {
                    showNotification('Error creating work order', 'error');
                });
            }
            
            function scanBarcode() { 
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    showNotification('Opening barcode scanner...', 'info');
                    // Would integrate with barcode scanning library
                } else {
                    showNotification('Camera not available on this device', 'warning');
                }
            }
            
            function logTime() { 
                showModal('Log Time', `
                    <form id="logTimeForm">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Task:</label>
                            <select name="task_id" required style="width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.2); color: white;">
                                <option value="">Select Task</option>
                                <option value="TASK-001">Generator Test</option>
                                <option value="TASK-002">Conveyor Maintenance</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Hours:</label>
                            <input type="number" step="0.5" name="hours" required style="width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.2); color: white;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem;">Description:</label>
                            <textarea name="description" required style="width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.2); color: white; height: 80px;"></textarea>
                        </div>
                    </form>
                `, [
                    { text: 'Cancel', onclick: 'closeModal()' },
                    { text: 'Log Time', class: 'cmms-btn-success', onclick: 'submitTimeLog()' }
                ]);
            }
            
            function submitTimeLog() {
                const form = document.getElementById('logTimeForm');
                const formData = new FormData(form);
                const data = Object.fromEntries(formData);
                
                fetch('/cmms/technicians/time-entry', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({...data, technician_id: 'current-user'})
                })
                .then(response => response.json())
                .then(result => {
                    showNotification('Time logged successfully!', 'success');
                    closeModal();
                })
                .catch(error => {
                    showNotification('Error logging time', 'error');
                });
            }
            
            function requestParts() { 
                window.location.href = '/cmms/parts/request';
            }
            
            function uploadPhoto() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.capture = 'environment';
                input.onchange = function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        showNotification(`Photo selected: ${file.name}`, 'success');
                        // Would upload to server
                    }
                };
                input.click();
            }
            
            function voiceCommand() {
                if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
                    showNotification('Voice recognition activated - say "Create work order" or "Log time"', 'info');
                    // Would integrate with speech recognition
                } else {
                    showNotification('Voice recognition not supported on this browser', 'warning');
                }
            }
            
            function openCamera() {
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    navigator.mediaDevices.getUserMedia({ video: true })
                        .then(stream => {
                            showNotification('Camera ready for photo capture', 'success');
                            stream.getTracks().forEach(track => track.stop());
                        })
                        .catch(err => showNotification('Camera access denied', 'error'));
                } else {
                    showNotification('Camera not available', 'warning');
                }
            }
            
            function recordVoice() {
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    showNotification('Voice recording would start here', 'info');
                } else {
                    showNotification('Microphone not available', 'warning');
                }
            }
            
            function useFlashlight() {
                showNotification('Flashlight functionality would activate here', 'info');
            }
            
            function measureTool() {
                showNotification('AR measurement tool would open here', 'info');
            }
            
            function ocrScan() {
                showNotification('OCR scanning for equipment identification', 'info');
            }
            
            function manualLookup() {
                window.location.href = '/cmms/assets/manuals';
            }
        </script>
    """
    
    return create_unified_page("👷 Technician Portal", content, "technicians", breadcrumbs)

@technician_router.get("/dashboard/{technician_id}", response_class=HTMLResponse)
async def technician_dashboard(technician_id: str):
    """Technician personal dashboard"""
    technician = next((t for t in technicians_db if t['id'] == technician_id), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    
    # Get technician's tasks
    my_tasks = [t for t in technician_tasks_db if t['technician_id'] == technician_id]
    active_tasks = [t for t in my_tasks if t['status'] in ['assigned', 'in_progress']]
    overdue_tasks = [t for t in my_tasks if t['due_date'] < datetime.now().strftime("%Y-%m-%d") and t['status'] not in ['completed']]
    completed_today = len([t for t in my_tasks if t['status'] == 'completed'])
    
    # Time tracking
    today_hours = sum(te['hours'] for te in time_entries_db if te['technician_id'] == technician_id and te['date'] == datetime.now().strftime("%Y-%m-%d"))
    week_hours = sum(te['hours'] for te in time_entries_db if te['technician_id'] == technician_id)  # Simplified
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix Technician Portal - {technician['name']}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * {{ box-sizing: border-box; }}
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem; }}
            .header h1 {{ margin: 0; font-size: 1.5rem; }}
            .header p {{ margin: 0.5rem 0 0 0; opacity: 0.9; }}
            .container {{ max-width: 1200px; margin: 1rem auto; padding: 0 1rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-bottom: 1rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 0.5rem 0; }}
            .stat-value {{ font-size: 1.5rem; font-weight: bold; }}
            .status-good {{ color: #38a169; }}
            .status-warning {{ color: #d69e2e; }}
            .status-critical {{ color: #e53e3e; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; text-decoration: none; display: inline-block; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-success {{ background: #38a169; }}
            .btn-primary {{ background: #4299e1; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .btn-sm {{ padding: 0.25rem 0.5rem; font-size: 0.875rem; }}
            .task-card {{ border-left: 4px solid #4299e1; margin-bottom: 1rem; }}
            .task-card.urgent {{ border-left-color: #e53e3e; }}
            .task-card.high {{ border-left-color: #d69e2e; }}
            .task-card.medium {{ border-left-color: #38a169; }}
            .task-card.low {{ border-left-color: #a0aec0; }}
            .badge {{ padding: 0.25rem 0.5rem; border-radius: 12px; font-size: 0.75rem; font-weight: 500; }}
            .badge-urgent {{ background: #fed7d7; color: #e53e3e; }}
            .badge-high {{ background: #fef5e7; color: #d69e2e; }}
            .badge-medium {{ background: #f0fff4; color: #38a169; }}
            .badge-low {{ background: #f7fafc; color: #4a5568; }}
            .time-tracker {{ position: sticky; top: 1rem; }}
            .active-timer {{ background: #38a169; color: white; }}
            .mobile-nav {{ display: none; position: fixed; bottom: 0; left: 0; right: 0; background: white; border-top: 1px solid #e2e8f0; padding: 0.5rem; }}
            .mobile-nav a {{ flex: 1; text-align: center; padding: 0.5rem; text-decoration: none; color: #4a5568; }}
            .mobile-nav a.active {{ color: #4299e1; }}
            
            @media (max-width: 768px) {{
                .container {{ padding: 0 0.5rem; margin-bottom: 4rem; }}
                .grid {{ grid-template-columns: 1fr; gap: 0.5rem; }}
                .mobile-nav {{ display: flex; }}
                .header {{ padding: 0.75rem; }}
                .card {{ padding: 0.75rem; }}
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>=' {technician['name']}</h1>
            <p>{technician['location']} " {technician['shift'].title()} Shift</p>
        </div>
        
        <div class="container">
            <!-- Stats Overview -->
            <div class="grid">
                <div class="card">
                    <h3>=Ê My Tasks Today</h3>
                    <div class="stat">
                        <span>Active Tasks</span>
                        <span class="stat-value status-good">{len(active_tasks)}</span>
                    </div>
                    <div class="stat">
                        <span>Overdue</span>
                        <span class="stat-value status-critical">{len(overdue_tasks)}</span>
                    </div>
                    <div class="stat">
                        <span>Completed Today</span>
                        <span class="stat-value status-good">{completed_today}</span>
                    </div>
                </div>
                
                <div class="card time-tracker">
                    <h3>ñ Time Tracking</h3>
                    <div class="stat">
                        <span>Today</span>
                        <span class="stat-value">{today_hours:.1f}h</span>
                    </div>
                    <div class="stat">
                        <span>This Week</span>
                        <span class="stat-value">{week_hours:.1f}h</span>
                    </div>
                    <button class="btn btn-success" onclick="startTimer()" id="timerBtn">Start Timer</button>
                    <button class="btn" onclick="viewTimesheet()">View Timesheet</button>
                </div>
                
                <div class="card">
                    <h3>=h=' My Skills</h3>
                    <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 1rem 0;">
                        {chr(10).join([f'<span class="badge badge-medium">{skill}</span>' for skill in technician['skills']])}
                    </div>
                    <div>
                        <strong>Certifications:</strong><br>
                        <small>{', '.join(technician['certifications'])}</small>
                    </div>
                </div>
            </div>
            
            <!-- Active Tasks -->
            <div class="card">
                <h3>=Ë My Active Tasks</h3>
                <div id="activeTasks">
                    {chr(10).join([f'''
                    <div class="card task-card {task['priority']}" data-task-id="{task['id']}">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">
                            <div>
                                <h4 style="margin: 0; font-size: 1rem;">{task['title']}</h4>
                                <p style="margin: 0.25rem 0; color: #718096; font-size: 0.9rem;">Asset: {task['asset_id']} " Due: {task['due_date']}</p>
                            </div>
                            <span class="badge badge-{task['priority']}">{task['priority'].upper()}</span>
                        </div>
                        
                        <p style="margin: 0.5rem 0; font-size: 0.9rem; color: #4a5568;">
                            {task['description'][:60]}{'...' if len(task['description']) > 60 else ''}
                        </p>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                            <div style="font-size: 0.85rem; color: #718096;">
                                Est. {task['estimated_hours']}h " Status: {task['status'].replace('_', ' ').title()}
                            </div>
                            <div>
                                <button class="btn btn-sm btn-success" onclick="startTask('{task['id']}')">{task['status'] == 'in_progress' and 'Continue' or 'Start'}</button>
                                <button class="btn btn-sm" onclick="viewTaskDetails('{task['id']}')">Details</button>
                            </div>
                        </div>
                    </div>''' for task in active_tasks])}
                </div>
                
                {f'<div style="text-align: center; color: #718096; padding: 2rem;">No active tasks assigned</div>' if not active_tasks else ''}
            </div>
            
            <!-- Quick Actions -->
            <div class="grid">
                <div class="card">
                    <h3>= Quick Actions</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 0.5rem;">
                        <button class="btn" onclick="scanQR()">Scan QR Code</button>
                        <button class="btn" onclick="reportIssue()">Report Issue</button>
                        <button class="btn" onclick="requestParts()">Request Parts</button>
                        <button class="btn" onclick="viewManuals()">View Manuals</button>
                        <button class="btn" onclick="safetyChecklist()">Safety Check</button>
                        <button class="btn" onclick="contactSupport()">Get Help</button>
                    </div>
                </div>
                
                <div class="card">
                    <h3>=ñ Mobile Tools</h3>
                    <button class="btn" onclick="openCamera()">=ø Take Photo</button>
                    <button class="btn" onclick="recordVoice()"><¤ Voice Note</button>
                    <button class="btn" onclick="useFlashlight()">=& Flashlight</button>
                    <button class="btn" onclick="measureTool()">=Ï Measure</button>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card">
                <h3>=Ý Recent Time Entries</h3>
                <div>
                    {chr(10).join([f'''
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; border-bottom: 1px solid #e2e8f0;">
                        <div>
                            <div style="font-weight: 500;">{next((t['title'] for t in technician_tasks_db if t['id'] == entry['task_id']), 'Unknown Task')}</div>
                            <div style="font-size: 0.85rem; color: #718096;">{entry['description']}</div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: bold;">{entry['hours']}h</div>
                            <div style="font-size: 0.75rem; color: #718096;">{entry['date']}</div>
                        </div>
                    </div>''' for entry in time_entries_db if entry['technician_id'] == technician_id][-5:])}
                </div>
            </div>
        </div>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav">
            <a href="/technician/dashboard/{technician_id}" class="active"><à Home</a>
            <a href="/technician/{technician_id}/tasks">=Ë Tasks</a>
            <a href="/technician/{technician_id}/time">ñ Time</a>
            <a href="/technician/{technician_id}/tools">=à Tools</a>
            <a href="/technician/profile/{technician_id}">=d Profile</a>
        </div>
        
        <script>
            let timerRunning = false;
            let currentTaskId = null;
            let timerInterval = null;
            let elapsedSeconds = 0;
            
            function startTimer() {{
                const btn = document.getElementById('timerBtn');
                if (!timerRunning) {{
                    // Start timer
                    timerRunning = true;
                    btn.textContent = 'Stop Timer';
                    btn.className = 'btn btn-danger';
                    
                    // Get current task
                    const activeTasks = document.querySelectorAll('[data-task-id]');
                    if (activeTasks.length > 0) {{
                        currentTaskId = activeTasks[0].dataset.taskId;
                    }}
                    
                    // Start interval
                    timerInterval = setInterval(() => {{
                        elapsedSeconds++;
                        const hours = Math.floor(elapsedSeconds / 3600);
                        const minutes = Math.floor((elapsedSeconds % 3600) / 60);
                        const seconds = elapsedSeconds % 60;
                        btn.textContent = `Stop Timer (${{hours.toString().padStart(2, '0')}}:${{minutes.toString().padStart(2, '0')}}:${{seconds.toString().padStart(2, '0')}})`;
                    }}, 1000);
                }} else {{
                    // Stop timer
                    stopTimer();
                }}
            }}
            
            function stopTimer() {{
                if (timerRunning) {{
                    timerRunning = false;
                    clearInterval(timerInterval);
                    
                    const hours = elapsedSeconds / 3600;
                    const description = prompt('Enter work description:');
                    
                    if (description && currentTaskId) {{
                        // Submit time entry
                        fetch('/technician/time-entry', {{
                            method: 'POST',
                            headers: {{ 'Content-Type': 'application/json' }},
                            body: JSON.stringify({{
                                technician_id: '{technician_id}',
                                task_id: currentTaskId,
                                hours: hours,
                                description: description
                            }})
                        }})
                        .then(() => location.reload());
                    }}
                    
                    // Reset timer
                    elapsedSeconds = 0;
                    const btn = document.getElementById('timerBtn');
                    btn.textContent = 'Start Timer';
                    btn.className = 'btn btn-success';
                }}
            }}
            
            function startTask(taskId) {{
                // Update task status and start timer
                fetch(`/technician/tasks/${{taskId}}/start`, {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ technician_id: '{technician_id}' }})
                }})
                .then(() => {{
                    currentTaskId = taskId;
                    if (!timerRunning) startTimer();
                }});
            }}
            
            function viewTaskDetails(taskId) {{
                window.open(`/technician/tasks/${{taskId}}`, '_blank');
            }}
            
            function completeTask(taskId) {{
                // Prompt for completion notes
                const notes = prompt('Add completion notes (optional):');
                
                if (notes === null) return; // User cancelled
                
                // Complete the task
                fetch(`/technicians/tasks/${{taskId}}/complete`, {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ 
                        technician_id: '{technician_id}',
                        notes: notes || '',
                        completion_time: new Date().toISOString()
                    }})
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.status === 'completed') {{
                        alert('Task completed successfully!');
                        // Stop the timer if this was the current task
                        if (currentTaskId === taskId) {{
                            stopTimer();
                            currentTaskId = null;
                        }}
                        // Refresh the page to update the task list
                        location.reload();
                    }}
                }})
                .catch(error => {{
                    console.error('Error completing task:', error);
                    alert('Error completing task. Please try again.');
                }});
            }}
            
            function viewTimesheet() {{
                window.location.href = '/technician/{technician_id}/timesheet';
            }}
            
            function scanQR() {{
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {{
                    alert('QR Scanner would open here');
                }} else {{
                    alert('Camera not available');
                }}
            }}
            
            function reportIssue() {{
                window.location.href = '/workorders/create?technician_id={technician_id}';
            }}
            
            function requestParts() {{
                window.location.href = '/parts/request?technician_id={technician_id}';
            }}
            
            function viewManuals() {{
                window.location.href = '/technician/manuals';
            }}
            
            function safetyChecklist() {{
                window.location.href = '/technician/safety-checklist';
            }}
            
            function contactSupport() {{
                window.location.href = 'tel:+15551234567';
            }}
            
            function openCamera() {{
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {{
                    navigator.mediaDevices.getUserMedia({{ video: true }})
                        .then(stream => {{
                            alert('Camera would open here for photo capture');
                            stream.getTracks().forEach(track => track.stop());
                        }})
                        .catch(err => alert('Camera access denied'));
                }} else {{
                    alert('Camera not available');
                }}
            }}
            
            function recordVoice() {{
                alert('Voice recording would start here');
            }}
            
            function useFlashlight() {{
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {{
                    alert('Flashlight functionality would activate here');
                }} else {{
                    alert('Flashlight not available');
                }}
            }}
            
            function measureTool() {{
                alert('AR measurement tool would open here');
            }}
            
            // Auto-save work in progress
            setInterval(() => {{
                if (timerRunning && currentTaskId) {{
                    const hours = elapsedSeconds / 3600;
                    fetch('/technician/time-entry/autosave', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            technician_id: '{technician_id}',
                            task_id: currentTaskId,
                            hours: hours,
                            description: 'Work in progress'
                        }})
                    }});
                }}
            }}, 300000); // Every 5 minutes
        </script>
    </body>
    </html>
    """

@technician_router.get("/")
async def get_technicians(
    status: Optional[str] = Query(None),
    skill: Optional[str] = Query(None),
    shift: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all technicians with optional filtering"""
    filtered_technicians = technicians_db
    
    if status:
        filtered_technicians = [t for t in filtered_technicians if t['status'] == status]
    if skill:
        filtered_technicians = [t for t in filtered_technicians if skill in t['skills']]
    if shift:
        filtered_technicians = [t for t in filtered_technicians if t['shift'] == shift]
    
    return filtered_technicians

@technician_router.get("/{technician_id}")
async def get_technician_details(technician_id: str) -> Dict:
    """Get specific technician details"""
    technician = next((t for t in technicians_db if t['id'] == technician_id), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    
    # Get technician's tasks and time entries
    tasks = [t for t in technician_tasks_db if t['technician_id'] == technician_id]
    time_entries = [te for te in time_entries_db if te['technician_id'] == technician_id]
    
    # Calculate metrics
    total_hours_week = sum(te['hours'] for te in time_entries if te['date'] >= (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"))
    active_tasks = len([t for t in tasks if t['status'] in ['assigned', 'in_progress']])
    completed_tasks = len([t for t in tasks if t['status'] == 'completed'])
    
    return {
        "technician": technician,
        "tasks": tasks,
        "time_entries": time_entries,
        "metrics": {
            "active_tasks": active_tasks,
            "completed_tasks": completed_tasks,
            "hours_this_week": total_hours_week,
            "efficiency_rating": 4.2,
            "on_time_completion": 89.5
        }
    }

@technician_router.get("/{technician_id}/tasks")
async def get_technician_tasks(
    technician_id: str,
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None)
) -> List[Dict]:
    """Get technician's assigned tasks"""
    tasks = [t for t in technician_tasks_db if t['technician_id'] == technician_id]
    
    if status:
        tasks = [t for t in tasks if t['status'] == status]
    if priority:
        tasks = [t for t in tasks if t['priority'] == priority]
    
    return tasks

@technician_router.post("/tasks/{task_id}/start")
async def start_task(task_id: str, task_data: Dict[str, Any]) -> Dict:
    """Start working on a task"""
    task = next((t for t in technician_tasks_db if t['id'] == task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    if task['technician_id'] != task_data['technician_id']:
        raise HTTPException(status_code=403, detail="Task not assigned to this technician")
    
    task['status'] = 'in_progress'
    
    # Create time entry
    time_entry_id = f"TIME-{len(time_entries_db) + 1:03d}"
    time_entry = {
        "id": time_entry_id,
        "technician_id": task_data['technician_id'],
        "task_id": task_id,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "hours": 0,
        "description": "Task started",
        "status": "active"
    }
    
    time_entries_db.append(time_entry)
    
    logger.info(f"Task started: {task_id} by {task_data['technician_id']}")
    return {"task": task, "time_entry": time_entry}

@technician_router.post("/tasks/{task_id}/complete")
async def complete_task(task_id: str, completion_data: Dict[str, Any]) -> Dict:
    """Mark task as completed with notes and completion tracking"""
    task = next((t for t in technician_tasks_db if t['id'] == task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    completion_date = datetime.now().strftime("%Y-%m-%d")
    completion_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Update task status and completion info
    task['status'] = 'completed'
    task['completion_date'] = completion_date
    task['completion_time'] = completion_time
    task['completion_notes'] = completion_data.get("notes", "")
    task['completed_by'] = completion_data.get("technician_id", "")
    
    # Update any active time entries
    total_task_hours = 0
    for time_entry in time_entries_db:
        if time_entry['task_id'] == task_id and time_entry['status'] == 'active':
            time_entry['status'] = 'completed'
            time_entry['description'] += f" - Completed on {completion_date}"
            if completion_data.get("notes"):
                time_entry['description'] += f" | Notes: {completion_data.get('notes')}"
            total_task_hours += time_entry.get('hours', 0)
    
    # Store completion summary
    task['actual_hours'] = total_task_hours
    
    logger.info(f"Task completed: {task_id} by {completion_data.get('technician_id', 'unknown')} in {total_task_hours}h")
    
    return {
        "task_id": task_id,
        "status": "completed",
        "completion_date": completion_date,
        "completion_time": completion_time,
        "notes": completion_data.get("notes", ""),
        "actual_hours": total_task_hours,
        "message": "Task completed successfully! 🎉"
    }

@technician_router.post("/time-entry")
async def create_time_entry(time_data: Dict[str, Any]) -> Dict:
    """Create time entry for technician"""
    time_entry_id = f"TIME-{len(time_entries_db) + 1:03d}"
    
    time_entry = {
        "id": time_entry_id,
        "technician_id": time_data["technician_id"],
        "task_id": time_data["task_id"],
        "date": datetime.now().strftime("%Y-%m-%d"),
        "hours": float(time_data["hours"]),
        "description": time_data["description"],
        "status": "submitted"
    }
    
    time_entries_db.append(time_entry)
    
    logger.info(f"Time entry created: {time_entry_id}")
    return time_entry

@technician_router.get("/{technician_id}/timesheet")
async def get_technician_timesheet(
    technician_id: str,
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None)
) -> Dict:
    """Get technician's timesheet"""
    timesheet_entries = [te for te in time_entries_db if te['technician_id'] == technician_id]
    
    if start_date:
        timesheet_entries = [te for te in timesheet_entries if te['date'] >= start_date]
    if end_date:
        timesheet_entries = [te for te in timesheet_entries if te['date'] <= end_date]
    
    total_hours = sum(te['hours'] for te in timesheet_entries)
    
    # Group by date
    by_date = {}
    for entry in timesheet_entries:
        date = entry['date']
        if date not in by_date:
            by_date[date] = {"entries": [], "total_hours": 0}
        by_date[date]["entries"].append(entry)
        by_date[date]["total_hours"] += entry['hours']
    
    return {
        "technician_id": technician_id,
        "total_hours": total_hours,
        "entries_count": len(timesheet_entries),
        "by_date": by_date,
        "entries": timesheet_entries
    }

@technician_router.get("/schedule")
async def get_technician_schedule(
    date: Optional[str] = Query(None),
    shift: Optional[str] = Query(None)
) -> List[Dict]:
    """Get technician schedule for planning"""
    schedule_data = []
    
    for technician in technicians_db:
        if shift and technician['shift'] != shift:
            continue
            
        # Get assigned tasks
        assigned_tasks = [t for t in technician_tasks_db if t['technician_id'] == technician['id']]
        if date:
            assigned_tasks = [t for t in assigned_tasks if t['due_date'] <= date]
        
        workload = sum(t['estimated_hours'] for t in assigned_tasks if t['status'] in ['assigned', 'in_progress'])
        
        schedule_data.append({
            "technician_id": technician['id'],
            "name": technician['name'],
            "status": technician['status'],
            "location": technician['location'],
            "shift": technician['shift'],
            "skills": technician['skills'],
            "assigned_tasks": len(assigned_tasks),
            "workload_hours": workload,
            "availability": "available" if workload < 8 else "busy"
        })
    
    return schedule_data

@technician_router.post("/assign-task")
async def assign_task_to_technician(assignment_data: Dict[str, Any]) -> Dict:
    """Assign a task to a technician"""
    technician = next((t for t in technicians_db if t['id'] == assignment_data['technician_id']), None)
    if not technician:
        raise HTTPException(status_code=404, detail="Technician not found")
    
    task_id = f"TASK-{len(technician_tasks_db) + 1:03d}"
    
    new_task = {
        "id": task_id,
        "title": assignment_data["title"],
        "description": assignment_data["description"],
        "asset_id": assignment_data["asset_id"],
        "priority": assignment_data["priority"],
        "status": "assigned",
        "assigned_date": datetime.now().strftime("%Y-%m-%d"),
        "due_date": assignment_data["due_date"],
        "estimated_hours": float(assignment_data["estimated_hours"]),
        "technician_id": assignment_data["technician_id"]
    }
    
    technician_tasks_db.append(new_task)
    
    # Update technician status
    current_workload = sum(
        t['estimated_hours'] for t in technician_tasks_db 
        if t['technician_id'] == assignment_data['technician_id'] 
        and t['status'] in ['assigned', 'in_progress']
    )
    
    technician['status'] = 'busy' if current_workload > 6 else 'available'
    
    logger.info(f"Task assigned: {task_id} to {assignment_data['technician_id']}")
    return new_task

@technician_router.get("/reports/productivity")
async def get_productivity_report() -> Dict:
    """Get technician productivity report"""
    productivity_data = {}
    
    for technician in technicians_db:
        tech_id = technician['id']
        
        # Get technician's data
        tasks = [t for t in technician_tasks_db if t['technician_id'] == tech_id]
        time_entries = [te for te in time_entries_db if te['technician_id'] == tech_id]
        
        completed_tasks = len([t for t in tasks if t['status'] == 'completed'])
        total_hours = sum(te['hours'] for te in time_entries)
        avg_task_time = total_hours / max(completed_tasks, 1)
        
        productivity_data[tech_id] = {
            "technician_name": technician['name'],
            "skills": technician['skills'],
            "location": technician['location'],
            "completed_tasks": completed_tasks,
            "total_hours": total_hours,
            "average_task_time": avg_task_time,
            "productivity_score": min(100, (completed_tasks / max(total_hours / 8, 1)) * 100),
            "utilization_rate": min(100, (total_hours / (5 * 8)) * 100)  # 5 days * 8 hours
        }
    
    return {
        "technicians": productivity_data,
        "overall_metrics": {
            "total_completed_tasks": sum(len([t for t in technician_tasks_db if t['technician_id'] == tech_id and t['status'] == 'completed']) for tech_id in [t['id'] for t in technicians_db]),
            "total_hours_logged": sum(te['hours'] for te in time_entries_db),
            "average_productivity": sum(data['productivity_score'] for data in productivity_data.values()) / len(productivity_data) if productivity_data else 0,
            "technicians_available": len([t for t in technicians_db if t['status'] == 'available'])
        },
        "generated_at": datetime.now().isoformat()
    }

# =============================================================================
# Enhanced Work Order Management System for Technicians
# =============================================================================

# Mock work orders database (normally would come from work order module)
mock_work_orders = [
    {
        "id": "WO-001",
        "title": "Emergency Generator Repair", 
        "description": "Generator failed to start during weekly test. Investigate and repair fuel system issue.",
        "asset_id": "AST-004",
        "asset_name": "Emergency Generator",
        "type": "reactive",
        "priority": "urgent",
        "status": "in_progress",
        "created_date": "2025-08-30",
        "assigned_to": "TECH-001",
        "due_date": "2025-09-02",
        "estimated_hours": 6.0,
        "actual_hours": 3.5,
        "parts_required": ["PRT-001", "PRT-004"],
        "safety_requirements": ["LOTO", "PPE", "Gas Monitor"]
    },
    {
        "id": "WO-002",
        "title": "Conveyor Belt Inspection",
        "description": "Monthly preventive maintenance inspection of main conveyor system.",
        "asset_id": "AST-002", 
        "asset_name": "Main Conveyor",
        "type": "preventive",
        "priority": "medium",
        "status": "assigned",
        "created_date": "2025-08-31",
        "assigned_to": "TECH-002",
        "due_date": "2025-09-05",
        "estimated_hours": 2.0,
        "parts_required": ["PRT-002"],
        "safety_requirements": ["LOTO", "PPE"]
    },
    {
        "id": "WO-003",
        "title": "HVAC Filter Replacement",
        "description": "Replace air filters in main HVAC unit and check system performance.",
        "asset_id": "AST-003",
        "asset_name": "HVAC Unit A1",
        "type": "preventive", 
        "priority": "low",
        "status": "open",
        "created_date": "2025-08-28",
        "assigned_to": "TECH-003",
        "due_date": "2025-09-10",
        "estimated_hours": 4.0,
        "parts_required": ["PRT-002"],
        "safety_requirements": ["PPE", "Ladder Safety"]
    }
]

@technician_router.get("/workorders/dashboard", response_class=HTMLResponse)
async def technician_workorder_dashboard():
    """Enhanced Work Order Dashboard for Technicians with Parts Integration"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Technician Work Orders - ChatterFix CMMS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: #333;
                overflow-x: hidden;
            }}
            
            .header {{
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                padding: 1.5rem 2rem;
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
                color: white;
                text-align: center;
            }}
            
            .header h1 {{
                font-size: 2rem;
                font-weight: 600;
                margin-bottom: 0.5rem;
            }}
            
            .container {{
                max-width: 1400px;
                margin: 0 auto;
                padding: 2rem;
            }}
            
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1.5rem;
                margin-bottom: 2rem;
            }}
            
            .stat-card {{
                background: rgba(255, 255, 255, 0.95);
                border-radius: 12px;
                padding: 1.5rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.2);
                text-align: center;
                transition: transform 0.3s ease;
            }}
            
            .stat-card:hover {{
                transform: translateY(-4px);
            }}
            
            .stat-value {{
                font-size: 2.5rem;
                font-weight: 700;
                color: #2d3748;
                margin-bottom: 0.5rem;
            }}
            
            .stat-label {{
                font-size: 0.9rem;
                color: #6b7280;
                font-weight: 500;
            }}
            
            .urgent {{ color: #dc2626; }}
            .high {{ color: #ea580c; }}
            .medium {{ color: #ca8a04; }}
            .low {{ color: #16a34a; }}
            
            .workorders-container {{
                background: rgba(255, 255, 255, 0.95);
                border-radius: 16px;
                padding: 2rem;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.2);
                margin-bottom: 2rem;
            }}
            
            .filter-bar {{
                display: flex;
                gap: 1rem;
                margin-bottom: 2rem;
                flex-wrap: wrap;
                align-items: center;
            }}
            
            .filter-group {{
                display: flex;
                flex-direction: column;
                min-width: 150px;
            }}
            
            .filter-group label {{
                font-size: 0.8rem;
                font-weight: 600;
                color: #4a5568;
                margin-bottom: 0.25rem;
            }}
            
            .filter-group select,
            .filter-group input {{
                padding: 0.5rem;
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                font-size: 0.9rem;
            }}
            
            .wo-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
                gap: 1.5rem;
            }}
            
            .wo-card {{
                background: white;
                border-radius: 12px;
                padding: 1.5rem;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                border-left: 4px solid #e2e8f0;
                transition: all 0.3s ease;
                position: relative;
            }}
            
            .wo-card:hover {{
                transform: translateY(-2px);
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
            }}
            
            .wo-card.urgent {{ border-left-color: #dc2626; }}
            .wo-card.high {{ border-left-color: #ea580c; }}
            .wo-card.medium {{ border-left-color: #ca8a04; }}
            .wo-card.low {{ border-left-color: #16a34a; }}
            
            .wo-header {{
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 1rem;
            }}
            
            .wo-title {{
                font-size: 1.1rem;
                font-weight: 600;
                color: #1f2937;
                margin-bottom: 0.25rem;
            }}
            
            .wo-id {{
                font-size: 0.8rem;
                color: #6b7280;
                font-family: monospace;
            }}
            
            .wo-status {{
                padding: 0.25rem 0.75rem;
                border-radius: 12px;
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
            }}
            
            .status-open {{ background: #fef3c7; color: #92400e; }}
            .status-assigned {{ background: #dbeafe; color: #1e40af; }}
            .status-in_progress {{ background: #fde68a; color: #92400e; }}
            .status-completed {{ background: #dcfce7; color: #166534; }}
            .status-parts_required {{ background: #fed7d7; color: #c53030; }}
            
            .wo-details {{
                margin-bottom: 1rem;
            }}
            
            .wo-description {{
                font-size: 0.9rem;
                color: #4b5563;
                line-height: 1.5;
                margin-bottom: 0.75rem;
            }}
            
            .wo-meta {{
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 0.5rem;
                font-size: 0.8rem;
                color: #6b7280;
            }}
            
            .wo-meta-item {{
                display: flex;
                align-items: center;
                gap: 0.25rem;
            }}
            
            .wo-actions {{
                display: flex;
                gap: 0.5rem;
                margin-top: 1rem;
                flex-wrap: wrap;
            }}
            
            .btn {{
                padding: 0.5rem 1rem;
                border: none;
                border-radius: 6px;
                font-size: 0.8rem;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s ease;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 0.25rem;
            }}
            
            .btn-primary {{
                background: #3b82f6;
                color: white;
            }}
            
            .btn-primary:hover {{
                background: #2563eb;
            }}
            
            .btn-success {{
                background: #10b981;
                color: white;
            }}
            
            .btn-success:hover {{
                background: #059669;
            }}
            
            .btn-warning {{
                background: #f59e0b;
                color: white;
            }}
            
            .btn-warning:hover {{
                background: #d97706;
            }}
            
            .btn-secondary {{
                background: #6b7280;
                color: white;
            }}
            
            .btn-secondary:hover {{
                background: #4b5563;
            }}
            
            .parts-list {{
                margin-top: 0.75rem;
                padding: 0.75rem;
                background: #f8fafc;
                border-radius: 6px;
                border-left: 3px solid #3b82f6;
            }}
            
            .parts-title {{
                font-size: 0.8rem;
                font-weight: 600;
                color: #374151;
                margin-bottom: 0.5rem;
            }}
            
            .parts-items {{
                display: flex;
                flex-wrap: wrap;
                gap: 0.25rem;
            }}
            
            .part-tag {{
                background: #e0e7ff;
                color: #3730a3;
                padding: 0.2rem 0.5rem;
                border-radius: 4px;
                font-size: 0.7rem;
                font-weight: 500;
            }}
            
            .safety-requirements {{
                margin-top: 0.75rem;
                padding: 0.75rem;
                background: #fef2f2;
                border-radius: 6px;
                border-left: 3px solid #dc2626;
            }}
            
            .safety-title {{
                font-size: 0.8rem;
                font-weight: 600;
                color: #991b1b;
                margin-bottom: 0.5rem;
            }}
            
            .safety-items {{
                display: flex;
                flex-wrap: wrap;
                gap: 0.25rem;
            }}
            
            .safety-tag {{
                background: #fee2e2;
                color: #991b1b;
                padding: 0.2rem 0.5rem;
                border-radius: 4px;
                font-size: 0.7rem;
                font-weight: 500;
            }}
            
            .mobile-actions {{
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                z-index: 1000;
            }}
            
            .fab {{
                width: 60px;
                height: 60px;
                border-radius: 50%;
                background: #3b82f6;
                color: white;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                transition: all 0.3s ease;
                margin-bottom: 1rem;
                display: block;
            }}
            
            .fab:hover {{
                background: #2563eb;
                transform: scale(1.1);
            }}
            
            .modal {{
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 2000;
                backdrop-filter: blur(4px);
            }}
            
            .modal-content {{
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: white;
                border-radius: 12px;
                padding: 2rem;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
            }}
            
            .form-group {{
                margin-bottom: 1rem;
            }}
            
            .form-group label {{
                display: block;
                font-weight: 600;
                margin-bottom: 0.5rem;
                color: #374151;
            }}
            
            .form-group input,
            .form-group textarea,
            .form-group select {{
                width: 100%;
                padding: 0.75rem;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 0.9rem;
            }}
            
            .form-group textarea {{
                resize: vertical;
                min-height: 100px;
            }}
            
            @media (max-width: 768px) {{
                .container {{
                    padding: 1rem;
                }}
                
                .stats-grid {{
                    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                }}
                
                .wo-grid {{
                    grid-template-columns: 1fr;
                }}
                
                .filter-bar {{
                    flex-direction: column;
                    align-items: stretch;
                }}
                
                .filter-group {{
                    min-width: unset;
                }}
            }}
            
            /* File Gallery Styles */
            .files-gallery {{
                max-height: 400px;
                overflow-y: auto;
                margin-bottom: 1rem;
            }}
            
            .file-item {{
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 0.75rem;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                margin-bottom: 0.5rem;
                background: white;
            }}
            
            .file-info {{
                display: flex;
                align-items: center;
                gap: 0.75rem;
                flex: 1;
            }}
            
            .file-icon {{
                font-size: 1.5rem;
                width: 2rem;
                text-align: center;
            }}
            
            .file-actions {{
                display: flex;
                gap: 0.5rem;
            }}
            
            .btn-sm {{
                padding: 0.25rem 0.5rem;
                font-size: 0.8rem;
            }}
            
            .no-files {{
                text-align: center;
                padding: 2rem;
                color: #6b7280;
            }}
            
            .gallery-actions {{
                text-align: center;
                margin-top: 1rem;
                padding-top: 1rem;
                border-top: 1px solid #e5e7eb;
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🔧 Technician Work Orders</h1>
            <p>Manage and complete your assigned work orders</p>
        </div>
        
        <div class="container">
            <!-- Statistics Overview -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value urgent" id="urgentCount">2</div>
                    <div class="stat-label">Urgent</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value high" id="highCount">1</div>
                    <div class="stat-label">High Priority</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value medium" id="mediumCount">3</div>
                    <div class="stat-label">Medium Priority</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value low" id="lowCount">2</div>
                    <div class="stat-label">Low Priority</div>
                </div>
            </div>
            
            <!-- Work Orders Container -->
            <div class="workorders-container">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">📋 My Work Orders</h2>
                
                <!-- Filter Bar -->
                <div class="filter-bar">
                    <div class="filter-group">
                        <label>Status</label>
                        <select id="statusFilter" onchange="filterWorkOrders()">
                            <option value="">All Statuses</option>
                            <option value="open">Open</option>
                            <option value="assigned">Assigned</option>
                            <option value="in_progress">In Progress</option>
                            <option value="parts_required">Parts Required</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Priority</label>
                        <select id="priorityFilter" onchange="filterWorkOrders()">
                            <option value="">All Priorities</option>
                            <option value="urgent">Urgent</option>
                            <option value="high">High</option>
                            <option value="medium">Medium</option>
                            <option value="low">Low</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Asset</label>
                        <input type="text" id="assetFilter" placeholder="Filter by asset..." onkeyup="filterWorkOrders()">
                    </div>
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" id="searchFilter" placeholder="Search work orders..." onkeyup="filterWorkOrders()">
                    </div>
                </div>
                
                <!-- Work Orders Grid -->
                <div class="wo-grid" id="workOrdersGrid">
                    <!-- Work orders will be populated here -->
                </div>
            </div>
        </div>
        
        <!-- Mobile Actions -->
        <div class="mobile-actions">
            <button class="fab" onclick="refreshWorkOrders()" title="Refresh">
                🔄
            </button>
            <button class="fab" onclick="showTimeEntry()" title="Log Time">
                ⏱️
            </button>
            <button class="fab" onclick="showPartsRequest()" title="Request Parts">
                📦
            </button>
            <button class="fab" onclick="showFileUpload()" title="Upload Files">
                📷
            </button>
        </div>
        
        <!-- Time Entry Modal -->
        <div id="timeEntryModal" class="modal">
            <div class="modal-content">
                <h3>⏱️ Log Time Entry</h3>
                <form id="timeEntryForm">
                    <div class="form-group">
                        <label>Work Order</label>
                        <select id="timeWorkOrder" required>
                            <option value="">Select Work Order</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Hours Worked</label>
                        <input type="number" id="timeHours" min="0.25" step="0.25" required>
                    </div>
                    <div class="form-group">
                        <label>Description of Work</label>
                        <textarea id="timeDescription" placeholder="Describe the work performed..." required></textarea>
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('timeEntryModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">Log Time</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Parts Request Modal -->
        <div id="partsRequestModal" class="modal">
            <div class="modal-content">
                <h3>📦 Request Parts</h3>
                <form id="partsRequestForm">
                    <div class="form-group">
                        <label>Work Order</label>
                        <select id="partsWorkOrder" required>
                            <option value="">Select Work Order</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Part Number or Description</label>
                        <input type="text" id="partNumber" placeholder="Enter part number or description..." required>
                    </div>
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" id="partQuantity" min="1" required>
                    </div>
                    <div class="form-group">
                        <label>Priority</label>
                        <select id="partPriority" required>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                            <option value="urgent">Urgent</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Notes</label>
                        <textarea id="partNotes" placeholder="Additional notes about the part request..."></textarea>
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('partsRequestModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">Request Parts</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Work Order Completion Modal -->
        <div id="completionModal" class="modal">
            <div class="modal-content">
                <h3>✅ Complete Work Order</h3>
                <form id="completionForm">
                    <input type="hidden" id="completionWorkOrderId">
                    <div class="form-group">
                        <label>Work Order</label>
                        <input type="text" id="completionWorkOrderTitle" readonly>
                    </div>
                    <div class="form-group">
                        <label>Total Hours Worked</label>
                        <input type="number" id="completionHours" min="0.25" step="0.25" required>
                    </div>
                    <div class="form-group">
                        <label>Work Completed</label>
                        <textarea id="completionDescription" placeholder="Describe the work completed..." required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Parts Used</label>
                        <textarea id="completionParts" placeholder="List parts used (optional)..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select id="completionStatus" required>
                            <option value="completed">Completed</option>
                            <option value="parts_required">Parts Required</option>
                            <option value="escalated">Needs Escalation</option>
                        </select>
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('completionModal')">Cancel</button>
                        <button type="submit" class="btn btn-success">Complete Work Order</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- File Upload Modal -->
        <div id="fileUploadModal" class="modal">
            <div class="modal-content">
                <h3>📷 Upload Files</h3>
                <form id="fileUploadForm">
                    <div class="form-group">
                        <label>Work Order</label>
                        <select id="fileWorkOrder" required>
                            <option value="">Select Work Order</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Files</label>
                        <input type="file" id="fileInput" multiple accept="image/*,video/*,.pdf,.doc,.docx" required>
                        <small style="color: #6b7280; margin-top: 0.25rem; display: block;">
                            Upload photos, videos, documents related to this work order
                        </small>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea id="fileDescription" placeholder="Describe what these files show..." rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label>File Type</label>
                        <select id="fileType">
                            <option value="before_photo">Before Photo</option>
                            <option value="after_photo">After Photo</option>
                            <option value="repair_video">Repair Video</option>
                            <option value="part_photo">Part Photo</option>
                            <option value="documentation">Documentation</option>
                            <option value="inspection_report">Inspection Report</option>
                            <option value="safety_issue">Safety Issue</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div id="uploadProgress" style="display: none; margin-top: 1rem;">
                        <div style="background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                            <div id="uploadProgressBar" style="background: #3b82f6; height: 8px; width: 0%; transition: width 0.3s ease;"></div>
                        </div>
                        <div id="uploadStatus" style="margin-top: 0.5rem; font-size: 0.8rem; color: #6b7280;">Uploading...</div>
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1.5rem;">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('fileUploadModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">📤 Upload Files</button>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            // Mock work orders data
            const workOrders = [
                {{
                    id: "WO-001",
                    title: "Emergency Generator Repair",
                    description: "Generator failed to start during weekly test. Investigate and repair fuel system issue.",
                    asset_id: "AST-004",
                    asset_name: "Emergency Generator",
                    type: "reactive",
                    priority: "urgent",
                    status: "in_progress",
                    created_date: "2025-08-30",
                    assigned_to: "TECH-001",
                    due_date: "2025-09-02",
                    estimated_hours: 6.0,
                    actual_hours: 3.5,
                    parts_required: ["Deep Groove Ball Bearing", "Oil Seal 25x40x7"],
                    safety_requirements: ["LOTO", "PPE", "Gas Monitor"]
                }},
                {{
                    id: "WO-002",
                    title: "Conveyor Belt Inspection",
                    description: "Monthly preventive maintenance inspection of main conveyor system.",
                    asset_id: "AST-002",
                    asset_name: "Main Conveyor",
                    type: "preventive",
                    priority: "medium",
                    status: "assigned",
                    created_date: "2025-08-31",
                    assigned_to: "TECH-002",
                    due_date: "2025-09-05",
                    estimated_hours: 2.0,
                    parts_required: ["Air Filter Element"],
                    safety_requirements: ["LOTO", "PPE"]
                }},
                {{
                    id: "WO-003",
                    title: "HVAC Filter Replacement",
                    description: "Replace air filters in main HVAC unit and check system performance.",
                    asset_id: "AST-003",
                    asset_name: "HVAC Unit A1",
                    type: "preventive",
                    priority: "low",
                    status: "open",
                    created_date: "2025-08-28",
                    assigned_to: "TECH-003",
                    due_date: "2025-09-10",
                    estimated_hours: 4.0,
                    parts_required: ["Air Filter Element"],
                    safety_requirements: ["PPE", "Ladder Safety"]
                }}
            ];
            
            let filteredWorkOrders = [...workOrders];
            
            function renderWorkOrders() {{
                const grid = document.getElementById('workOrdersGrid');
                
                if (filteredWorkOrders.length === 0) {{
                    grid.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 2rem;">No work orders match your filters.</p>';
                    return;
                }}
                
                grid.innerHTML = filteredWorkOrders.map(wo => `
                    <div class="wo-card ${{wo.priority}}" data-status="${{wo.status}}" data-priority="${{wo.priority}}" data-asset="${{wo.asset_name.toLowerCase()}}">
                        <div class="wo-header">
                            <div>
                                <div class="wo-title">${{wo.title}}</div>
                                <div class="wo-id">${{wo.id}}</div>
                            </div>
                            <span class="wo-status status-${{wo.status.replace('_', '_')}}">${{wo.status.replace('_', ' ')}}</span>
                        </div>
                        
                        <div class="wo-details">
                            <div class="wo-description">${{wo.description}}</div>
                            
                            <div class="wo-meta">
                                <div class="wo-meta-item">
                                    <span>🏭</span>
                                    <span>${{wo.asset_name}}</span>
                                </div>
                                <div class="wo-meta-item">
                                    <span>📅</span>
                                    <span>Due: ${{wo.due_date}}</span>
                                </div>
                                <div class="wo-meta-item">
                                    <span>⏱️</span>
                                    <span>${{wo.estimated_hours}}h estimated</span>
                                </div>
                                <div class="wo-meta-item">
                                    <span>🎯</span>
                                    <span>${{wo.type}} maintenance</span>
                                </div>
                            </div>
                            
                            ${{wo.parts_required && wo.parts_required.length > 0 ? `
                                <div class="parts-list">
                                    <div class="parts-title">📦 Required Parts</div>
                                    <div class="parts-items">
                                        ${{wo.parts_required.map(part => `<span class="part-tag">${{part}}</span>`).join('')}}
                                    </div>
                                </div>
                            ` : ''}}
                            
                            ${{wo.safety_requirements && wo.safety_requirements.length > 0 ? `
                                <div class="safety-requirements">
                                    <div class="safety-title">⚠️ Safety Requirements</div>
                                    <div class="safety-items">
                                        ${{wo.safety_requirements.map(req => `<span class="safety-tag">${{req}}</span>`).join('')}}
                                    </div>
                                </div>
                            ` : ''}}
                        </div>
                        
                        <div class="wo-actions">
                            ${{wo.status === 'assigned' || wo.status === 'open' ? `
                                <button class="btn btn-primary" onclick="startWorkOrder('${{wo.id}}')">
                                    ▶️ Start Work
                                </button>
                            ` : ''}}
                            ${{wo.status === 'in_progress' ? `
                                <button class="btn btn-success" onclick="completeWorkOrder('${{wo.id}}', '${{wo.title}}')">
                                    ✅ Complete
                                </button>
                                <button class="btn btn-warning" onclick="pauseWorkOrder('${{wo.id}}')">
                                    ⏸️ Pause
                                </button>
                            ` : ''}}
                            <button class="btn btn-secondary" onclick="viewWorkOrder('${{wo.id}}')">
                                👁️ View Details
                            </button>
                            <button class="btn btn-secondary" onclick="showTimeEntryForWO('${{wo.id}}')">
                                ⏱️ Log Time
                            </button>
                            <button class="btn btn-info" onclick="viewWorkOrderFiles('${{wo.id}}')">
                                📁 View Files
                            </button>
                        </div>
                    </div>
                `).join('');
            }}
            
            function filterWorkOrders() {{
                const statusFilter = document.getElementById('statusFilter').value;
                const priorityFilter = document.getElementById('priorityFilter').value;
                const assetFilter = document.getElementById('assetFilter').value.toLowerCase();
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                filteredWorkOrders = workOrders.filter(wo => {{
                    return (!statusFilter || wo.status === statusFilter) &&
                           (!priorityFilter || wo.priority === priorityFilter) &&
                           (!assetFilter || wo.asset_name.toLowerCase().includes(assetFilter)) &&
                           (!searchFilter || wo.title.toLowerCase().includes(searchFilter) || 
                            wo.description.toLowerCase().includes(searchFilter));
                }});
                
                renderWorkOrders();
                updateStats();
            }}
            
            function updateStats() {{
                const stats = {{
                    urgent: workOrders.filter(wo => wo.priority === 'urgent').length,
                    high: workOrders.filter(wo => wo.priority === 'high').length,
                    medium: workOrders.filter(wo => wo.priority === 'medium').length,
                    low: workOrders.filter(wo => wo.priority === 'low').length
                }};
                
                document.getElementById('urgentCount').textContent = stats.urgent;
                document.getElementById('highCount').textContent = stats.high;
                document.getElementById('mediumCount').textContent = stats.medium;
                document.getElementById('lowCount').textContent = stats.low;
            }}
            
            function startWorkOrder(woId) {{
                const wo = workOrders.find(w => w.id === woId);
                if (wo) {{
                    wo.status = 'in_progress';
                    renderWorkOrders();
                    showNotification(`Started work on ${{wo.title}}`, 'success');
                }}
            }}
            
            function pauseWorkOrder(woId) {{
                const wo = workOrders.find(w => w.id === woId);
                if (wo) {{
                    wo.status = 'assigned';
                    renderWorkOrders();
                    showNotification(`Paused work on ${{wo.title}}`, 'info');
                }}
            }}
            
            function completeWorkOrder(woId, woTitle) {{
                document.getElementById('completionWorkOrderId').value = woId;
                document.getElementById('completionWorkOrderTitle').value = woTitle;
                document.getElementById('completionModal').style.display = 'block';
            }}
            
            function viewWorkOrder(woId) {{
                const wo = workOrders.find(w => w.id === woId);
                if (wo) {{
                    alert(`Work Order Details:\\n\\nID: ${{wo.id}}\\nTitle: ${{wo.title}}\\nAsset: ${{wo.asset_name}}\\nPriority: ${{wo.priority}}\\nStatus: ${{wo.status}}\\nDescription: ${{wo.description}}`);
                }}
            }}
            
            function showTimeEntry() {{
                const select = document.getElementById('timeWorkOrder');
                select.innerHTML = '<option value="">Select Work Order</option>' +
                    workOrders.map(wo => `<option value="${{wo.id}}">${{wo.id}} - ${{wo.title}}</option>`).join('');
                document.getElementById('timeEntryModal').style.display = 'block';
            }}
            
            function showTimeEntryForWO(woId) {{
                const wo = workOrders.find(w => w.id === woId);
                if (wo) {{
                    const select = document.getElementById('timeWorkOrder');
                    select.innerHTML = `<option value="${{wo.id}}" selected>${{wo.id}} - ${{wo.title}}</option>`;
                    document.getElementById('timeEntryModal').style.display = 'block';
                }}
            }}
            
            function showPartsRequest() {{
                const select = document.getElementById('partsWorkOrder');
                select.innerHTML = '<option value="">Select Work Order</option>' +
                    workOrders.map(wo => `<option value="${{wo.id}}">${{wo.id}} - ${{wo.title}}</option>`).join('');
                document.getElementById('partsRequestModal').style.display = 'block';
            }}
            
            function showFileUpload() {{
                const select = document.getElementById('fileWorkOrder');
                select.innerHTML = '<option value="">Select Work Order</option>' +
                    workOrders.map(wo => `<option value="${{wo.id}}">${{wo.id}} - ${{wo.title}}</option>`).join('');
                document.getElementById('fileUploadModal').style.display = 'block';
            }}
            
            async function uploadFiles(workOrderId, files, description, fileType) {{
                const progressDiv = document.getElementById('uploadProgress');
                const progressBar = document.getElementById('uploadProgressBar');
                const statusDiv = document.getElementById('uploadStatus');
                
                progressDiv.style.display = 'block';
                
                let uploaded = 0;
                const total = files.length;
                
                for (const file of files) {{
                    const formData = new FormData();
                    formData.append('file', file);
                    formData.append('entity_type', 'work_order');
                    formData.append('entity_id', workOrderId);
                    formData.append('description', description);
                    formData.append('tags', fileType);
                    formData.append('uploaded_by', 'technician');
                    
                    try {{
                        const response = await fetch('/cmms/files/upload', {{
                            method: 'POST',
                            body: formData
                        }});
                        
                        if (response.ok) {{
                            uploaded++;
                            const progress = (uploaded / total) * 100;
                            progressBar.style.width = progress + '%';
                            statusDiv.textContent = `Uploaded ${{uploaded}} of ${{total}} files...`;
                        }} else {{
                            console.error('Upload failed for file:', file.name);
                        }}
                    }} catch (error) {{
                        console.error('Upload error:', error);
                    }}
                }}
                
                setTimeout(() => {{
                    progressDiv.style.display = 'none';
                    progressBar.style.width = '0%';
                }}, 2000);
                
                return uploaded;
            }}
            
            function viewWorkOrderFiles(workOrderId) {{
                fetch(`/cmms/files/list?entity_type=workorder&entity_id=${{workOrderId}}`)
                    .then(response => response.json())
                    .then(files => {{
                        if (files.length === 0) {{
                            showModal('workOrderFilesModal', 'Work Order Files', `
                                <div class="no-files">
                                    <p>📂 No files uploaded for this work order yet.</p>
                                    <button onclick="showFileUpload(); closeModal('workOrderFilesModal');" class="btn btn-primary">
                                        📤 Upload Files
                                    </button>
                                </div>
                            `, [{{ text: 'Close', onclick: 'closeModal("workOrderFilesModal")' }}]);
                        }} else {{
                            const filesList = files.map(file => `
                                <div class="file-item">
                                    <div class="file-info">
                                        <span class="file-icon">${{
                                            file.filename.toLowerCase().includes('.jpg') || file.filename.toLowerCase().includes('.png') || file.filename.toLowerCase().includes('.jpeg') ? '🖼️' :
                                            file.filename.toLowerCase().includes('.pdf') ? '📄' :
                                            file.filename.toLowerCase().includes('.mp4') || file.filename.toLowerCase().includes('.mov') ? '🎥' :
                                            '📄'
                                        }}</span>
                                        <div>
                                            <strong>${{file.filename}}</strong>
                                            <br><small>${{new Date(file.upload_date).toLocaleDateString()}}</small>
                                        </div>
                                    </div>
                                    <div class="file-actions">
                                        <button onclick="window.open('/cmms/files/view/${{file.id}}', '_blank')" class="btn btn-sm btn-secondary">
                                            👁️ View
                                        </button>
                                        <button onclick="window.open('/cmms/files/download/${{file.id}}', '_blank')" class="btn btn-sm btn-primary">
                                            📥 Download
                                        </button>
                                    </div>
                                </div>
                            `).join('');
                            
                            showModal('workOrderFilesModal', 'Work Order Files', `
                                <div class="files-gallery">
                                    ${{filesList}}
                                </div>
                                <div class="gallery-actions">
                                    <button onclick="showFileUpload(); closeModal('workOrderFilesModal');" class="btn btn-primary">
                                        📤 Upload More Files
                                    </button>
                                </div>
                            `, [{{ text: 'Close', onclick: 'closeModal("workOrderFilesModal")' }}]);
                        }}
                    }})
                    .catch(error => {{
                        console.error('Error loading files:', error);
                        showNotification('Error loading files', 'error');
                    }});
            }}
            
            function closeModal(modalId) {{
                document.getElementById(modalId).style.display = 'none';
            }}
            
            function refreshWorkOrders() {{
                renderWorkOrders();
                showNotification('Work orders refreshed', 'success');
            }}
            
            function showNotification(message, type = 'info') {{
                // Simple notification - in a real app, you'd use a proper notification library
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 2rem;
                    right: 2rem;
                    background: ${{type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'}};
                    color: white;
                    padding: 1rem 1.5rem;
                    border-radius: 8px;
                    z-index: 3000;
                    font-weight: 500;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                `;
                notification.textContent = message;
                document.body.appendChild(notification);
                
                setTimeout(() => {{
                    document.body.removeChild(notification);
                }}, 3000);
            }}
            
            // Form submissions
            document.getElementById('timeEntryForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                const formData = new FormData(e.target);
                const timeData = Object.fromEntries(formData);
                console.log('Time entry:', timeData);
                showNotification('Time entry logged successfully', 'success');
                closeModal('timeEntryModal');
                e.target.reset();
            }});
            
            document.getElementById('partsRequestForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                const formData = new FormData(e.target);
                const partsData = Object.fromEntries(formData);
                console.log('Parts request:', partsData);
                showNotification('Parts request submitted', 'success');
                closeModal('partsRequestModal');
                e.target.reset();
            }});
            
            document.getElementById('completionForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                const formData = new FormData(e.target);
                const completionData = Object.fromEntries(formData);
                
                const woId = completionData.completionWorkOrderId;
                const wo = workOrders.find(w => w.id === woId);
                if (wo) {{
                    wo.status = completionData.completionStatus;
                    wo.actual_hours = parseFloat(completionData.completionHours);
                    renderWorkOrders();
                    showNotification(`Work order ${{woId}} ${{completionData.completionStatus}}`, 'success');
                }}
                
                closeModal('completionModal');
                e.target.reset();
            }});
            
            document.getElementById('fileUploadForm').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const workOrderId = document.getElementById('fileWorkOrder').value;
                const files = document.getElementById('fileInput').files;
                const description = document.getElementById('fileDescription').value;
                const fileType = document.getElementById('fileType').value;
                
                if (!workOrderId || files.length === 0) {{
                    showNotification('Please select work order and files', 'error');
                    return;
                }}
                
                try {{
                    const uploadedCount = await uploadFiles(workOrderId, Array.from(files), description, fileType);
                    
                    if (uploadedCount > 0) {{
                        showNotification(`Successfully uploaded ${{uploadedCount}} file(s) to ${{workOrderId}}`, 'success');
                        closeModal('fileUploadModal');
                        e.target.reset();
                        
                        // Add visual indicator to the work order card
                        const woCard = document.querySelector(`[data-wo-id="${{workOrderId}}"]`);
                        if (woCard) {{
                            woCard.style.border = '2px solid #10b981';
                            setTimeout(() => {{
                                woCard.style.border = '';
                            }}, 3000);
                        }}
                    }} else {{
                        showNotification('Failed to upload files', 'error');
                    }}
                }} catch (error) {{
                    console.error('Upload error:', error);
                    showNotification('Error uploading files', 'error');
                }}
            }});
            
            // Close modals when clicking outside
            window.addEventListener('click', function(e) {{
                if (e.target.classList.contains('modal')) {{
                    e.target.style.display = 'none';
                }}
            }});
            
            // Initialize the page
            document.addEventListener('DOMContentLoaded', function() {{
                renderWorkOrders();
                updateStats();
            }});
        </script>
    </body>
    </html>
    """