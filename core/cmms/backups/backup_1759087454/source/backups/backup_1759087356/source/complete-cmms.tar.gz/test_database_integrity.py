#!/usr/bin/env python3
"""Database integrity test for ChatterFix CMMS"""

import sqlite3
import json
from datetime import datetime

DB_PATH = "/Users/fredtaylor/Desktop/Projects/ai-tools/core/cmms/cmms.db"

def test_database_integrity():
    """Test database tables and record counts"""
    results = {
        "timestamp": datetime.now().isoformat(),
        "database_path": DB_PATH,
        "tables": {},
        "total_records": 0,
        "status": "pass"
    }
    
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        
        # Get all table names
        cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cur.fetchall()]
        
        # Count records in each table
        for table in tables:
            try:
                cur.execute(f"SELECT COUNT(*) FROM {table};")
                count = cur.fetchone()[0]
                results["tables"][table] = count
                results["total_records"] += count
                
                # Sample first few records for key tables
                if table in ["assets", "work_orders", "workorders"] and count > 0:
                    cur.execute(f"SELECT * FROM {table} LIMIT 3;")
                    columns = [desc[0] for desc in cur.description]
                    rows = cur.fetchall()
                    results["tables"][f"{table}_sample"] = {
                        "columns": columns,
                        "sample_data": [dict(zip(columns, row)) for row in rows]
                    }
            except Exception as e:
                results["tables"][table] = f"Error: {e}"
                results["status"] = "warning"
        
        conn.close()
        
        # Summary
        results["summary"] = {
            "total_tables": len(tables),
            "assets_count": results["tables"].get("assets", 0),
            "work_orders_count": results["tables"].get("work_orders", 0) + results["tables"].get("workorders", 0),
            "total_records": results["total_records"]
        }
        
    except Exception as e:
        results["status"] = "fail"
        results["error"] = str(e)
    
    return results

if __name__ == "__main__":
    results = test_database_integrity()
    print(json.dumps(results, indent=2, default=str))