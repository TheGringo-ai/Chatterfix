#!/usr/bin/env python3
"""
CMMS UI Flow Testing Script
Simulates end-user browser flows using requests to test the UI components
"""
import requests
import json
from datetime import datetime
import os

# Configuration
BASE_URL = "http://127.0.0.1:8888"
VALIDATION_DIR = "ai-memory/validation/e2e"

def test_ui_flows():
    """Test end-user UI flows"""
    results = {
        "timestamp": datetime.now().isoformat(),
        "test_type": "ui_flows",
        "base_url": BASE_URL,
        "tests": []
    }
    
    print("🌐 CMMS UI Flow Validation")
    print("==========================")
    print(f"Target: {BASE_URL}")
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Test 1: Dashboard Access
    print("🏠 Test 1: Dashboard Navigation")
    print("==============================")
    
    try:
        # Main Dashboard
        resp = requests.get(f"{BASE_URL}/", timeout=10)
        dashboard_working = resp.status_code == 200 and "ChatterFix CMMS" in resp.text
        
        if dashboard_working:
            print("✅ Main Dashboard: ACCESSIBLE")
            print(f"   - Status: {resp.status_code}")
            print(f"   - Title found: {'ChatterFix CMMS' in resp.text}")
            print(f"   - Page size: {len(resp.text)} bytes")
            
            # Check for key UI elements
            ui_elements = {
                "Admin Dashboard Link": "admin/dashboard" in resp.text,
                "AI Assistant Link": "ai/dashboard" in resp.text,
                "System Health Link": "/health" in resp.text,
                "Navigation Grid": "nav-grid" in resp.text,
            }
            
            for element, found in ui_elements.items():
                status_icon = "✅" if found else "❌"
                print(f"   {status_icon} {element}: {'FOUND' if found else 'MISSING'}")
            
            results["tests"].append({
                "test": "main_dashboard_access",
                "status": "PASS",
                "details": "Main dashboard accessible with all UI elements",
                "ui_elements": ui_elements
            })
        else:
            print(f"❌ Main Dashboard: FAILED ({resp.status_code})")
            results["tests"].append({
                "test": "main_dashboard_access", 
                "status": "FAIL",
                "details": f"Dashboard not accessible: {resp.status_code}"
            })
            
    except Exception as e:
        print(f"❌ Main Dashboard: ERROR - {e}")
        results["tests"].append({
            "test": "main_dashboard_access",
            "status": "ERROR", 
            "details": str(e)
        })
    
    print()
    
    # Test 2: Admin Dashboard
    print("⚡ Test 2: Admin Dashboard")
    print("=========================")
    
    try:
        resp = requests.get(f"{BASE_URL}/admin/dashboard", timeout=10)
        admin_working = resp.status_code == 200
        
        if admin_working:
            print("✅ Admin Dashboard: ACCESSIBLE")
            print(f"   - Status: {resp.status_code}")
            print(f"   - Content length: {len(resp.text)} bytes")
            
            # Check for admin UI elements
            admin_elements = {
                "User Management": "users" in resp.text.lower(),
                "System Stats": "stats" in resp.text.lower() or "statistics" in resp.text.lower(),
                "Configuration": "config" in resp.text.lower(),
                "Admin Controls": "admin" in resp.text.lower(),
            }
            
            for element, found in admin_elements.items():
                status_icon = "✅" if found else "❌"
                print(f"   {status_icon} {element}: {'FOUND' if found else 'MISSING'}")
                
            results["tests"].append({
                "test": "admin_dashboard_access",
                "status": "PASS",
                "details": "Admin dashboard accessible",
                "ui_elements": admin_elements
            })
        else:
            print(f"❌ Admin Dashboard: FAILED ({resp.status_code})")
            results["tests"].append({
                "test": "admin_dashboard_access",
                "status": "FAIL", 
                "details": f"Admin dashboard not accessible: {resp.status_code}"
            })
            
    except Exception as e:
        print(f"❌ Admin Dashboard: ERROR - {e}")
        results["tests"].append({
            "test": "admin_dashboard_access",
            "status": "ERROR",
            "details": str(e)
        })
    
    print()
    
    # Test 3: AI Dashboard  
    print("🤖 Test 3: AI Dashboard")
    print("=======================")
    
    try:
        resp = requests.get(f"{BASE_URL}/ai/dashboard", timeout=10)
        ai_working = resp.status_code == 200
        
        if ai_working:
            print("✅ AI Dashboard: ACCESSIBLE")
            print(f"   - Status: {resp.status_code}")
            print(f"   - Content length: {len(resp.text)} bytes")
            
            # Check for AI UI elements
            ai_elements = {
                "Chat Interface": "chat" in resp.text.lower(),
                "AI Models": "model" in resp.text.lower() or "llama" in resp.text.lower(),
                "Intelligence Features": "intelligence" in resp.text.lower() or "smart" in resp.text.lower(),
                "Voice Support": "voice" in resp.text.lower(),
            }
            
            for element, found in ai_elements.items():
                status_icon = "✅" if found else "❌"
                print(f"   {status_icon} {element}: {'FOUND' if found else 'MISSING'}")
                
            results["tests"].append({
                "test": "ai_dashboard_access",
                "status": "PASS",
                "details": "AI dashboard accessible",
                "ui_elements": ai_elements
            })
        else:
            print(f"❌ AI Dashboard: FAILED ({resp.status_code})")
            results["tests"].append({
                "test": "ai_dashboard_access",
                "status": "FAIL",
                "details": f"AI dashboard not accessible: {resp.status_code}"
            })
            
    except Exception as e:
        print(f"❌ AI Dashboard: ERROR - {e}")
        results["tests"].append({
            "test": "ai_dashboard_access",
            "status": "ERROR",
            "details": str(e)
        })
    
    print()
    
    # Test 4: AI Chat Functionality
    print("💬 Test 4: AI Chat Flow")
    print("======================")
    
    try:
        chat_payload = {
            "message": "What is the system status?",
            "context": "system", 
            "user_type": "technician"
        }
        
        resp = requests.post(f"{BASE_URL}/ai/chat", json=chat_payload, timeout=30)
        chat_working = resp.status_code == 200
        
        if chat_working:
            chat_data = resp.json()
            print("✅ AI Chat: FUNCTIONAL")
            print(f"   - Status: {resp.status_code}")
            print(f"   - Response received: {bool(chat_data.get('response'))}")
            print(f"   - Model used: {chat_data.get('model_used', 'unknown')}")
            print(f"   - Confidence: {chat_data.get('confidence', 'unknown')}")
            
            results["tests"].append({
                "test": "ai_chat_functionality",
                "status": "PASS",
                "details": "AI chat responding correctly",
                "response_data": {
                    "model": chat_data.get('model_used'),
                    "confidence": chat_data.get('confidence'),
                    "response_length": len(str(chat_data.get('response', '')))
                }
            })
        else:
            print(f"❌ AI Chat: FAILED ({resp.status_code})")
            results["tests"].append({
                "test": "ai_chat_functionality",
                "status": "FAIL",
                "details": f"AI chat not responding: {resp.status_code}"
            })
            
    except Exception as e:
        print(f"❌ AI Chat: ERROR - {e}")
        results["tests"].append({
            "test": "ai_chat_functionality",
            "status": "ERROR",
            "details": str(e)
        })
    
    print()
    
    # Test 5: API Documentation
    print("📚 Test 5: API Documentation")
    print("============================")
    
    try:
        # Test Swagger UI
        resp = requests.get(f"{BASE_URL}/docs", timeout=10)
        docs_working = resp.status_code == 200 and "swagger" in resp.text.lower()
        
        if docs_working:
            print("✅ API Documentation: ACCESSIBLE")
            print(f"   - Status: {resp.status_code}")
            print(f"   - Swagger UI loaded: {'swagger-ui' in resp.text}")
            print(f"   - Interactive docs: {'interactive' in resp.text.lower()}")
            
            results["tests"].append({
                "test": "api_documentation",
                "status": "PASS", 
                "details": "API documentation accessible via Swagger UI"
            })
        else:
            print(f"❌ API Documentation: FAILED ({resp.status_code})")
            results["tests"].append({
                "test": "api_documentation",
                "status": "FAIL",
                "details": f"API docs not accessible: {resp.status_code}"
            })
            
    except Exception as e:
        print(f"❌ API Documentation: ERROR - {e}")
        results["tests"].append({
            "test": "api_documentation",
            "status": "ERROR",
            "details": str(e)
        })
    
    print()
    
    # Test 6: System Health & Monitoring
    print("🏥 Test 6: System Health")
    print("========================")
    
    try:
        resp = requests.get(f"{BASE_URL}/health", timeout=10)
        health_working = resp.status_code == 200
        
        if health_working:
            health_data = resp.json()
            print("✅ System Health: HEALTHY")
            print(f"   - Status: {health_data.get('status', 'unknown')}")
            print(f"   - Service: {health_data.get('service', 'unknown')}")
            print(f"   - Modules: {health_data.get('modules', {})}")
            
            results["tests"].append({
                "test": "system_health",
                "status": "PASS",
                "details": "System health endpoint responding correctly",
                "health_data": health_data
            })
        else:
            print(f"❌ System Health: FAILED ({resp.status_code})")
            results["tests"].append({
                "test": "system_health", 
                "status": "FAIL",
                "details": f"Health endpoint not responding: {resp.status_code}"
            })
            
    except Exception as e:
        print(f"❌ System Health: ERROR - {e}")
        results["tests"].append({
            "test": "system_health",
            "status": "ERROR",
            "details": str(e)
        })
    
    print()
    
    # Save results
    os.makedirs(VALIDATION_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f"{VALIDATION_DIR}/ui_flow_results_{timestamp}.json"
    
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    # Generate summary
    total_tests = len(results["tests"])
    passed_tests = sum(1 for test in results["tests"] if test["status"] == "PASS")
    failed_tests = sum(1 for test in results["tests"] if test["status"] == "FAIL") 
    error_tests = sum(1 for test in results["tests"] if test["status"] == "ERROR")
    
    print("📊 UI Flow Test Summary")
    print("======================")
    print(f"Total Tests: {total_tests}")
    print(f"✅ Passed: {passed_tests}")
    print(f"❌ Failed: {failed_tests}")
    print(f"⚠️  Errors: {error_tests}")
    print(f"📁 Results: {results_file}")
    
    if failed_tests == 0 and error_tests == 0:
        print("\n🎉 ALL UI FLOWS WORKING!")
        return True
    else:
        print(f"\n⚠️  Some issues found. Check {results_file} for details.")
        return False

if __name__ == "__main__":
    test_ui_flows()