"""
Universal AI Endpoints - OCR & Voice across entire CMMS
Add these to app.py to make AI features available everywhere
"""

from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import JSONResponse
import speech_recognition as sr
import pytesseract
from PIL import Image
import io
import tempfile
import os

app = FastAPI()

# Universal OCR endpoint - can be called from any module
@app.post("/api/ocr")
async def universal_ocr(
    photo: UploadFile = File(...),
    context: str = Form(default="general"),  # workorder, asset, part, safety, etc.
    language: str = Form(default="eng")
):
    """Universal OCR processing for any document/image across CMMS"""
    try:
        # Read image
        image_data = await photo.read()
        image = Image.open(io.BytesIO(image_data))
        
        # Extract text
        extracted_text = pytesseract.image_to_string(image, lang=language)
        
        # Context-aware processing
        processed_data = process_ocr_by_context(extracted_text, context)
        
        return {
            "success": True,
            "extracted_text": extracted_text,
            "context": context,
            "processed_data": processed_data,
            "confidence": calculate_confidence(extracted_text),
            "suggestions": generate_suggestions(extracted_text, context)
        }
        
    except Exception as e:
        return JSONResponse(
            {"error": f"OCR processing failed: {str(e)}", "success": False},
            status_code=400
        )

@app.post("/api/voice")
async def universal_voice(
    audio: UploadFile = File(...),
    context: str = Form(default="general"),  # workorder, navigation, search, etc.
    language: str = Form(default="en-US")
):
    """Universal voice processing for any voice command across CMMS"""
    try:
        # Save audio temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp_file:
            tmp_file.write(await audio.read())
            tmp_file_path = tmp_file.name
        
        # Speech to text
        recognizer = sr.Recognizer()
        with sr.AudioFile(tmp_file_path) as source:
            audio_data = recognizer.record(source)
            transcription = recognizer.recognize_google(audio_data, language=language)
        
        # Process command based on context
        command_result = process_voice_command(transcription, context)
        
        # Cleanup
        os.unlink(tmp_file_path)
        
        return {
            "success": True,
            "transcription": transcription,
            "context": context,
            "command": command_result,
            "confidence": 0.95,  # Would be actual confidence from speech recognition
            "actions": generate_voice_actions(transcription, context)
        }
        
    except Exception as e:
        return JSONResponse(
            {"error": f"Voice processing failed: {str(e)}", "success": False},
            status_code=400
        )

def process_ocr_by_context(text: str, context: str):
    """Process OCR text based on context"""
    if context == "part":
        return extract_part_info(text)
    elif context == "asset":
        return extract_asset_info(text)
    elif context == "workorder":
        return extract_maintenance_info(text)
    elif context == "safety":
        return extract_safety_info(text)
    else:
        return {"raw_text": text}

def process_voice_command(transcription: str, context: str):
    """Process voice command based on context"""
    lower_text = transcription.lower()
    
    if context == "workorder":
        if "create" in lower_text and "work order" in lower_text:
            return {"action": "create_workorder", "data": extract_wo_details(transcription)}
        elif "complete" in lower_text:
            return {"action": "complete_workorder", "data": extract_completion_details(transcription)}
    
    elif context == "navigation":
        if "go to" in lower_text or "navigate to" in lower_text:
            return {"action": "navigate", "destination": extract_destination(transcription)}
    
    elif context == "search":
        return {"action": "search", "query": extract_search_query(transcription)}
    
    return {"action": "general_command", "text": transcription}

def extract_part_info(text: str):
    """Extract part information from OCR text"""
    import re
    
    # Look for part numbers, model numbers, etc.
    part_patterns = [
        r'P/N[:\s]*([A-Z0-9\-]+)',
        r'Part[:\s]*([A-Z0-9\-]+)',
        r'Model[:\s]*([A-Z0-9\-]+)'
    ]
    
    extracted = {}
    for pattern in part_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            extracted['part_number'] = match.group(1)
            break
    
    extracted['full_text'] = text
    return extracted

def extract_asset_info(text: str):
    """Extract asset information from OCR text"""
    import re
    
    # Look for asset tags, serial numbers, etc.
    asset_patterns = [
        r'Asset[:\s]*([A-Z0-9\-]+)',
        r'Serial[:\s]*([A-Z0-9\-]+)',
        r'Tag[:\s]*([A-Z0-9\-]+)'
    ]
    
    extracted = {}
    for pattern in asset_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            extracted['asset_id'] = match.group(1)
            break
    
    extracted['full_text'] = text
    return extracted

def extract_maintenance_info(text: str):
    """Extract maintenance information from OCR text"""
    # Look for maintenance procedures, safety warnings, etc.
    return {
        "procedures": extract_procedures(text),
        "safety_notes": extract_safety_notes(text),
        "full_text": text
    }

def extract_safety_info(text: str):
    """Extract safety information from OCR text"""
    import re
    
    safety_keywords = ['warning', 'caution', 'danger', 'ppe', 'lockout', 'tagout']
    found_safety = []
    
    for keyword in safety_keywords:
        if keyword in text.lower():
            found_safety.append(keyword)
    
    return {
        "safety_items": found_safety,
        "full_text": text
    }

def calculate_confidence(text: str):
    """Calculate OCR confidence based on text quality"""
    # Simple heuristic - could be improved with actual OCR confidence scores
    if len(text.strip()) == 0:
        return 0.0
    
    # Check for common OCR artifacts
    artifacts = ['?', '|', '~', '`']
    artifact_count = sum(text.count(char) for char in artifacts)
    
    base_confidence = 0.9
    confidence = max(0.1, base_confidence - (artifact_count * 0.1))
    
    return round(confidence, 2)

def generate_suggestions(text: str, context: str):
    """Generate contextual suggestions based on OCR results"""
    suggestions = []
    
    if context == "part" and text:
        suggestions.append("Create new part entry")
        suggestions.append("Search existing parts database")
    
    elif context == "workorder" and text:
        suggestions.append("Create work order from procedure")
        suggestions.append("Add to maintenance checklist")
    
    return suggestions

def generate_voice_actions(transcription: str, context: str):
    """Generate possible actions based on voice command"""
    actions = []
    lower_text = transcription.lower()
    
    if "create" in lower_text:
        actions.append({"action": "create", "confidence": 0.8})
    
    if "search" in lower_text or "find" in lower_text:
        actions.append({"action": "search", "confidence": 0.9})
    
    if "navigate" in lower_text or "go to" in lower_text:
        actions.append({"action": "navigate", "confidence": 0.85})
    
    return actions

# Helper extraction functions
def extract_wo_details(text: str):
    """Extract work order details from voice command"""
    # Simple extraction - could be enhanced with NLP
    return {
        "title": f"Voice created: {text[:50]}...",
        "description": text,
        "priority": "Medium"
    }

def extract_completion_details(text: str):
    """Extract completion details from voice"""
    return {
        "completion_notes": text,
        "status": "Completed"
    }

def extract_destination(text: str):
    """Extract navigation destination from voice"""
    destinations = {
        "dashboard": ["dashboard", "home", "main"],
        "workorders": ["work orders", "work order", "maintenance"],
        "assets": ["assets", "equipment", "machines"],
        "parts": ["parts", "inventory", "stock"],
        "technicians": ["technicians", "techs", "staff"]
    }
    
    lower_text = text.lower()
    for dest, keywords in destinations.items():
        if any(keyword in lower_text for keyword in keywords):
            return dest
    
    return "dashboard"  # default

def extract_search_query(text: str):
    """Extract search query from voice command"""
    # Remove command words
    query_words = ["search for", "find", "look for", "show me"]
    lower_text = text.lower()
    
    for query_word in query_words:
        if query_word in lower_text:
            return text[lower_text.index(query_word) + len(query_word):].strip()
    
    return text

def extract_procedures(text: str):
    """Extract maintenance procedures from text"""
    # Look for numbered steps, bullet points, etc.
    import re
    
    procedures = []
    
    # Look for numbered steps
    steps = re.findall(r'\d+\.\s*([^\n]+)', text)
    if steps:
        procedures.extend(steps)
    
    # Look for bullet points
    bullets = re.findall(r'[•\-\*]\s*([^\n]+)', text)
    if bullets:
        procedures.extend(bullets)
    
    return procedures

def extract_safety_notes(text: str):
    """Extract safety notes from text"""
    import re
    
    safety_patterns = [
        r'WARNING[:\s]*([^\n]+)',
        r'CAUTION[:\s]*([^\n]+)',
        r'DANGER[:\s]*([^\n]+)'
    ]
    
    safety_notes = []
    for pattern in safety_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        safety_notes.extend(matches)
    
    return safety_notes