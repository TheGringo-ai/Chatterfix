#!/usr/bin/env python3
"""
Voice Command Processor for ChatterFix CMMS
Handles speech-to-text, natural language processing, and voice-activated workflows
"""

import os
import json
import logging
import asyncio
import base64
import io
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass
from datetime import datetime
from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse
import speech_recognition as sr
from pydantic import BaseModel
from ai_technician_assistant import ai_assistant, IntentType, ExtractedData

logger = logging.getLogger(__name__)

# Voice router
voice_router = APIRouter(prefix="/voice", tags=["voice"])

class VoiceCommandRequest(BaseModel):
    """Voice command request model"""
    audio_data: Optional[str] = None  # Base64 encoded audio
    text_input: Optional[str] = None  # Direct text input
    user_id: str
    session_id: Optional[str] = None
    context: Optional[Dict] = None

class VoiceResponse(BaseModel):
    """Voice command response model"""
    success: bool
    transcription: Optional[str] = None
    intent: Optional[str] = None
    confidence: float
    action_taken: Optional[str] = None
    work_order_id: Optional[str] = None
    ai_response: str
    suggestions: List[str] = []
    follow_up_questions: List[str] = []

@dataclass
class VoiceSession:
    """Voice session state management"""
    session_id: str
    user_id: str
    context: Dict
    conversation_history: List[Dict]
    current_workflow: Optional[str] = None
    pending_confirmations: List[Dict] = None

class VoiceCommandProcessor:
    """Advanced voice command processor with contextual awareness"""
    
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.microphone = None
        self.sessions = {}  # Session management
        self.command_patterns = self._load_command_patterns()
        
        # Initialize speech recognition settings
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.pause_threshold = 0.5
        
    def _load_command_patterns(self) -> Dict[str, List[str]]:
        """Load common voice command patterns"""
        return {
            "create_work_order": [
                "create work order for {asset}",
                "new maintenance request for {asset}",
                "report issue with {asset}",
                "{asset} needs repair",
                "{asset} is broken",
                "schedule maintenance for {asset}",
                "log problem with {asset}",
                "submit ticket for {asset}"
            ],
            "check_status": [
                "what's the status of {work_order}",
                "check work order {work_order}",
                "update on {asset}",
                "how is {asset} doing",
                "progress on {work_order}",
                "show me work order {work_order}"
            ],
            "complete_task": [
                "complete work order {work_order}",
                "finished working on {asset}",
                "mark {work_order} as done",
                "close {work_order}",
                "finish job {work_order}",
                "wrap up {work_order}"
            ],
            "emergency": [
                "emergency with {asset}",
                "urgent repair needed",
                "critical issue with {asset}",
                "safety concern",
                "equipment down",
                "immediate attention needed",
                "production stopped"
            ],
            "voice_navigation": [
                "show me dashboard",
                "open work orders",
                "go to assets",
                "display parts inventory",
                "navigate to reports"
            ]
        }

    def _enhance_maintenance_vocabulary(self, text: str) -> str:
        """Enhance recognized text with maintenance-specific vocabulary corrections"""
        # Common misrecognized maintenance terms
        vocab_corrections = {
            # Core CMMS terms
            "work order": ["worker", "work odor", "worker der", "work or der"],
            "work orders": ["workers", "work odors"],
            "asset": ["a set", "as et", "assets"],
            "preventive maintenance": ["prevent of maintenance", "preventative maintenance"],
            "predictive maintenance": ["predict of maintenance", "predictive main tenance"],
            
            # Equipment types - comprehensive
            "pump": ["mom", "palm", "pum", "pomps", "pumps"],
            "motor": ["moter", "motter", "mode er", "motors"],
            "conveyor": ["can bear", "convey or", "conveyer", "convener"],
            "boiler": ["boy ler", "boil er", "boyle er"],
            "valve": ["valve", "valv", "val ve", "valves"],
            "bearing": ["baring", "barring", "barrel", "bearings"],
            "seal": ["steel", "seale", "seel", "seals"],
            "compressor": ["compress or", "compresser", "com pressor"],
            "generator": ["generate or", "generater", "gen erator"],
            "turbine": ["tur bine", "turbin"],
            "gearbox": ["gear box", "geer box"],
            "heat exchanger": ["heat ex changer"],
            
            # Advanced equipment
            "injection molding": ["injection mold ing", "in jection molding"],
            "cnc machine": ["c n c machine", "cnc mach ine", "c and c machine"],
            "robotic arm": ["robot ic arm", "robot arm"],
            "plc": ["p l c", "p.l.c", "plc controller"],
            
            # Technical systems
            "hydraulic": ["high draw lic", "high drolic", "hi drolic", "hydraulik"],
            "pneumatic": ["new mat ic", "pnumatic", "pneumatik", "new matic"],
            "mechanical": ["mech an ical", "mechan ical", "mechanicel"],
            "electrical": ["elect rical", "electric al", "elektrical"],
            "automation": ["auto mation", "auto nation"],
            
            # Measurement terms
            "vibration": ["vi bra tion", "vibraytion", "vy bration"],
            "temperature": ["temp er ature", "temperture", "temp rature"],
            "pressure": ["press ure", "preasure", "preshure"],
            "torque": ["tork", "turk", "torq"],
            "rpm": ["r p m", "r.p.m", "revolutions per minute"],
            "frequency": ["freq uency", "frequ ency"],
            
            # Maintenance actions
            "repair": ["repare", "re pair"],
            "inspect": ["in spect"],
            "replace": ["re place"],
            "maintain": ["main tain"],
            "service": ["sir vice"],
            "alignment": ["aline ment", "align ment"],
            "calibration": ["cal i bration", "calibraytion"],
            "lubrication": ["lub ri cation", "lube rication"],
            
            # Priority levels
            "urgent": ["ur gent", "urgant"],
            "critical": ["crit ical", "kritical"],
            "emergency": ["e mer gen cy", "emerg ency"],
            "high priority": ["hi priority", "high prior ity"],
            "medium priority": ["med ium priority"],
            "low priority": ["lo priority"],
            
            # Failure modes
            "leaking": ["leak ing", "leak age", "leakage"],
            "overheating": ["over heat ing", "over heating", "overheat"],
            "misalignment": ["mis align ment", "mis alignment"],
            "vibration excessive": ["vibration excess ive", "excessive vibration"],
            "wear": ["ware", "wearing"],
            "corrosion": ["corosion", "cor osion"],
            "contamination": ["contam ination", "contamina tion"],
            
            # Status terms
            "completed": ["complete", "compleat"],
            "in progress": ["in progres", "in pro gress"],
            "assigned": ["asigned", "a signed"],
            "scheduled": ["sked uled", "sched uled"],
            
            # Tools
            "wrench": ["rench", "wrenches"],
            "screwdriver": ["screw driver", "scru driver"],
            "multimeter": ["multi meter", "mult imeter"],
            "socket": ["sockit", "soket"],
            
            # Parts
            "gasket": ["gas kit", "gaskit"],
            "belt": ["bel", "belts"],
            "filter": ["fil ter", "filters"],
            "coupling": ["coup ling"],
            
            # Safety
            "lockout tagout": ["lock out tag out", "lockout tag out", "loto"],
            "confined space": ["con fined space"],
            "personal protective equipment": ["p p e"],
            "safety": ["safe ty"]
        }
        
        corrected_text = text.lower()
        for correct_term, variations in vocab_corrections.items():
            for variation in variations:
                corrected_text = corrected_text.replace(variation, correct_term)
        
        return corrected_text
    
    async def process_voice_command(self, request: VoiceCommandRequest) -> VoiceResponse:
        """Main voice command processing pipeline"""
        try:
            # Step 1: Speech-to-text conversion (if audio provided)
            transcription = None
            if request.audio_data:
                transcription = await self._speech_to_text(request.audio_data)
            elif request.text_input:
                transcription = request.text_input
            else:
                raise HTTPException(status_code=400, detail="No audio or text input provided")
            
            if not transcription:
                return VoiceResponse(
                    success=False,
                    confidence=0.0,
                    ai_response="Sorry, I couldn't understand the audio. Could you please repeat?"
                )
            
            # Step 2: Enhanced natural language processing with voice context
            voice_context = {
                "input_method": "voice",
                "audio_quality": "standard",  # Could be enhanced with actual audio analysis
                "session_id": request.session_id,
                "user_id": request.user_id,
                **(request.context or {})
            }
            
            extracted_data = await ai_assistant.process_natural_language(
                transcription, 
                voice_context
            )
            
            # Step 3: Context awareness and session management
            session = self._get_or_create_session(request.user_id, request.session_id)
            session.conversation_history.append({
                "timestamp": datetime.now().isoformat(),
                "input": transcription,
                "intent": extracted_data.intent.value,
                "confidence": extracted_data.confidence
            })
            
            # Step 4: Execute command based on intent
            action_result = await self._execute_command(extracted_data, session)
            
            # Step 5: Generate response
            response = await self._generate_response(
                transcription, extracted_data, action_result, session
            )
            
            return response
            
        except Exception as e:
            logger.error(f"Voice command processing failed: {e}")
            return VoiceResponse(
                success=False,
                confidence=0.0,
                ai_response=f"I encountered an error processing your request: {str(e)}"
            )
    
    async def _speech_to_text(self, audio_data: str) -> Optional[str]:
        """Enhanced speech-to-text with multiple engines and noise reduction"""
        try:
            # Decode base64 audio
            audio_bytes = base64.b64decode(audio_data)
            audio_file = io.BytesIO(audio_bytes)
            
            # Enhanced audio preprocessing
            with sr.AudioFile(audio_file) as source:
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                audio = self.recognizer.record(source)
                
            # Try multiple recognition engines for better accuracy
            recognition_results = []
            
            try:
                # Primary: Google Speech Recognition with enhanced parameters
                text = self.recognizer.recognize_google(
                    audio, 
                    language='en-US',
                    show_all=False,
                    with_confidence=False
                )
                
                # Post-process for maintenance terminology
                text = self._enhance_maintenance_vocabulary(text)
                recognition_results.append({"engine": "google", "text": text, "confidence": 0.9})
                logger.info(f"Google Speech recognized: {text}")
                
            except sr.UnknownValueError:
                logger.warning("Google Speech Recognition could not understand audio")
            except sr.RequestError as e:
                logger.warning(f"Google Speech Recognition error: {e}")
                
            try:
                # Secondary: Google with alternative language models
                text = self.recognizer.recognize_google(audio, language='en-US', show_all=False)
                if text and text not in [r["text"] for r in recognition_results]:
                    recognition_results.append({"engine": "google_alt", "text": text, "confidence": 0.85})
                    
            except Exception:
                pass
                
            try:
                # Fallback: PocketSphinx (offline)
                text = self.recognizer.recognize_sphinx(audio)
                if text and text not in [r["text"] for r in recognition_results]:
                    recognition_results.append({"engine": "sphinx", "text": text, "confidence": 0.7})
                    logger.info(f"Sphinx recognition: {text}")
                    
            except Exception:
                pass
            
            # If we have recognition results, use the best one
            if recognition_results:
                # Sort by confidence and return the best result
                best_result = max(recognition_results, key=lambda x: x["confidence"])
                logger.info(f"Best STT result: {best_result['text']} (engine: {best_result['engine']}, confidence: {best_result['confidence']})")
                return best_result["text"]
            
            # If all engines fail, try LLaMA-based audio processing (if available)
            try:
                return await self._llama_audio_processing(audio_data)
            except Exception as e:
                logger.warning(f"LLaMA audio processing failed: {e}")
                
            return None
                    
        except Exception as e:
            logger.error(f"Speech-to-text failed: {e}")
            return None
    
    async def _llama_audio_processing(self, audio_data: str) -> Optional[str]:
        """Advanced LLaMA-based audio processing with acoustic analysis"""
        try:
            # Import AI orchestrator for better model selection
            try:
                from ai_orchestrator import ai_orchestrator
            except ImportError:
                try:
                    from .ai_orchestrator import ai_orchestrator
                except ImportError:
                    logger.warning("AI orchestrator not available for audio processing")
                    return None
            
            # Analyze audio characteristics
            audio_bytes = base64.b64decode(audio_data)
            audio_length = len(audio_bytes)
            
            # Basic audio analysis (can be enhanced with actual audio processing libraries)
            estimated_duration = audio_length / 16000  # Rough estimate for 16kHz sampling
            noise_level = "high" if audio_length > 100000 else "medium"
            
            # Create advanced contextual prompt for LLaMA
            context_prompt = f"""ADVANCED VOICE RECOGNITION CONTEXT ANALYSIS

AUDIO CHARACTERISTICS:
- Data size: {audio_length} bytes
- Estimated duration: {estimated_duration:.1f} seconds
- Environment: Industrial maintenance facility
- Noise level: {noise_level}
- Expected speaker: Maintenance technician

MAINTENANCE CONTEXT:
- Common equipment: pumps, motors, conveyors, boilers, valves
- Typical actions: repair, inspect, replace, maintain, troubleshoot
- Priority keywords: urgent, critical, emergency, routine
- Safety terms: lockout, tagout, PPE, hazard, leak, pressure

VOICE PATTERN ANALYSIS:
Based on the audio duration and industrial context, predict the most likely maintenance voice commands.
Consider that technicians often use:
- Short, direct commands (2-8 words)
- Equipment-specific terminology
- Action-oriented language
- Safety priorities

Generate 5 most probable voice commands this technician might have spoken, ranked by likelihood.
Format as: "1. [command] - [confidence %]" """

            # Use intelligent model selection for voice processing
            ai_response = await ai_orchestrator.intelligent_response(
                message=context_prompt,
                context="voice_audio_analysis",
                complexity_level="medium"
            )
            
            if ai_response and ai_response.get("response"):
                # Parse the AI response to extract likely commands
                response_text = ai_response["response"]
                logger.info(f"LLaMA audio analysis: {response_text}")
                
                # Extract the highest confidence prediction
                lines = response_text.split('\n')
                for line in lines:
                    if line.strip().startswith('1.'):
                        # Extract the command from "1. [command] - [confidence %]"
                        command_part = line.split('-')[0].strip()
                        if command_part.startswith('1.'):
                            predicted_command = command_part[2:].strip().strip('"').strip("'")
                            logger.info(f"Predicted voice command: {predicted_command}")
                            return predicted_command
            
            return None
            
        except Exception as e:
            logger.error(f"LLaMA audio processing error: {e}")
            return None
    
    def _get_or_create_session(self, user_id: str, session_id: Optional[str] = None) -> VoiceSession:
        """Get existing session or create new one"""
        if not session_id:
            session_id = f"{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
        if session_id not in self.sessions:
            self.sessions[session_id] = VoiceSession(
                session_id=session_id,
                user_id=user_id,
                context={},
                conversation_history=[],
                pending_confirmations=[]
            )
            
        return self.sessions[session_id]
    
    async def _execute_command(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Execute the appropriate command based on intent"""
        
        if extracted.intent == IntentType.CREATE_WORK_ORDER:
            return await self._handle_create_work_order(extracted, session)
            
        elif extracted.intent == IntentType.DIAGNOSE_ISSUE:
            return await self._handle_diagnose_issue(extracted, session)
            
        elif extracted.intent == IntentType.LOOKUP_PART:
            return await self._handle_lookup_part(extracted, session)
            
        elif extracted.intent == IntentType.COMPLETE_ORDER:
            return await self._handle_complete_order(extracted, session)
            
        elif extracted.intent == IntentType.UPDATE_STATUS:
            return await self._handle_update_status(extracted, session)
            
        elif extracted.intent == IntentType.SAFETY_GUIDANCE:
            return await self._handle_safety_guidance(extracted, session)
            
        else:
            return {"action": "unknown", "message": "I'm not sure how to help with that."}
    
    async def _handle_create_work_order(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Handle work order creation from voice command"""
        
        # Check if we have enough information
        missing_info = []
        if not extracted.asset_id and not extracted.asset_name:
            missing_info.append("asset identification")
        if not extracted.description:
            missing_info.append("problem description")
            
        if missing_info:
            session.current_workflow = "creating_work_order"
            session.context.update(asdict(extracted))
            return {
                "action": "request_info",
                "missing": missing_info,
                "message": f"I need more information to create the work order. Please specify: {', '.join(missing_info)}"
            }
        
        # Create work order using AI assistant
        try:
            work_order_result = await ai_assistant.create_work_order_from_nl(extracted)
            work_order = work_order_result["work_order"]
            ai_insights = work_order_result["ai_insights"]
            
            # Store in session context
            session.context["last_work_order"] = work_order["id"]
            
            return {
                "action": "work_order_created",
                "work_order_id": work_order["id"],
                "work_order": work_order,
                "ai_insights": ai_insights,
                "message": f"Work order {work_order['id']} created successfully for {extracted.asset_name or 'the specified asset'}."
            }
            
        except Exception as e:
            logger.error(f"Work order creation failed: {e}")
            return {
                "action": "error",
                "message": "Sorry, I couldn't create the work order right now. Please try again or create it manually."
            }
    
    async def _handle_diagnose_issue(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Handle diagnostic assistance from voice command"""
        
        try:
            diagnosis_result = await ai_assistant.diagnose_issue(extracted)
            
            return {
                "action": "diagnosis_provided",
                "diagnosis": diagnosis_result,
                "message": f"I've analyzed the issue with {extracted.asset_name or 'your equipment'}. Here's my diagnostic assessment."
            }
            
        except Exception as e:
            logger.error(f"Diagnosis failed: {e}")
            return {
                "action": "error", 
                "message": "I couldn't provide a diagnosis right now. Please check with a senior technician."
            }
    
    async def _handle_lookup_part(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Handle parts lookup from voice command"""
        
        # Search parts database
        matching_parts = []
        if extracted.part_number:
            # Direct part number lookup
            for part_key, part_data in ai_assistant.parts_database.items():
                if extracted.part_number.lower() in part_data["part_number"].lower():
                    matching_parts.append(part_data)
                    
        elif extracted.asset_id:
            # Asset-compatible parts
            for part_key, part_data in ai_assistant.parts_database.items():
                if extracted.asset_id in part_data.get("compatible_assets", []):
                    matching_parts.append(part_data)
                    
        elif extracted.part_description:
            # Description-based search
            for part_key, part_data in ai_assistant.parts_database.items():
                if any(word in part_data["description"].lower() 
                      for word in extracted.part_description.lower().split()):
                    matching_parts.append(part_data)
        
        if matching_parts:
            return {
                "action": "parts_found",
                "parts": matching_parts[:5],  # Limit to top 5
                "message": f"I found {len(matching_parts)} matching parts."
            }
        else:
            return {
                "action": "no_parts_found",
                "message": "I couldn't find any matching parts. You may need to check with the parts department."
            }
    
    async def _handle_complete_order(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Handle work order completion from voice command"""
        
        work_order_id = extracted.work_order_id or session.context.get("last_work_order")
        
        if not work_order_id:
            return {
                "action": "request_info",
                "message": "Which work order would you like to complete? Please provide the work order number."
            }
        
        # In a real system, this would update the database
        return {
            "action": "order_completed",
            "work_order_id": work_order_id,
            "message": f"Work order {work_order_id} has been marked as completed. Great work!"
        }
    
    async def _handle_update_status(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Handle status update from voice command"""
        
        work_order_id = extracted.work_order_id or session.context.get("last_work_order")
        
        if not work_order_id:
            return {
                "action": "request_info", 
                "message": "Which work order status would you like to update?"
            }
        
        return {
            "action": "status_updated",
            "work_order_id": work_order_id,
            "message": f"Status updated for work order {work_order_id}."
        }
    
    async def _handle_safety_guidance(self, extracted: ExtractedData, session: VoiceSession) -> Dict[str, Any]:
        """Handle safety guidance request"""
        
        safety_notes = ai_assistant._get_safety_notes(extracted)
        safety_alerts = ai_assistant._get_safety_alerts(extracted)
        
        return {
            "action": "safety_guidance",
            "safety_notes": safety_notes,
            "safety_alerts": safety_alerts,
            "message": "Here are the safety guidelines for this equipment and task."
        }
    
    async def _generate_response(
        self, 
        transcription: str, 
        extracted: ExtractedData, 
        action_result: Dict[str, Any], 
        session: VoiceSession
    ) -> VoiceResponse:
        """Generate comprehensive voice response with LLaMA enhancement"""
        
        # Use LLaMA to generate context-aware voice response
        try:
            # Import AI provider
            try:
                from .ai_model_provider import ai_provider
            except ImportError:
                from ai_model_provider import ai_provider
            
            # Create enhanced voice response prompt
            voice_response_prompt = f"""Generate a natural, conversational voice response for a maintenance technician.

VOICE COMMAND PROCESSED:
- Original Speech: "{transcription}"
- Intent Detected: {extracted.intent.value}
- Confidence: {extracted.confidence:.2f}
- Action Taken: {action_result.get('action', 'processed')}

CONTEXT:
- User Session: {len(session.conversation_history)} previous interactions
- Current Workflow: {session.current_workflow or 'none'}
- Work Order Created: {action_result.get('work_order_id', 'none')}

ACTION RESULT:
{action_result.get('message', 'Request processed successfully')}

VOICE RESPONSE REQUIREMENTS:
- Keep response under 30 seconds when spoken
- Use clear, professional maintenance terminology
- Include next steps or confirmation
- Be conversational but informative
- Optimize for voice output (avoid complex punctuation)

Generate a natural voice response that a technician would find helpful and easy to understand."""

            ai_response_result = await ai_provider.generate(
                message=voice_response_prompt,
                context="voice_response",
                system_prompt="You are ChatterFix Voice AI. Generate clear, concise voice responses for maintenance technicians. Optimize for speech synthesis and field use.",
                max_tokens=150,
                temperature=0.3,
                metadata={
                    "response_type": "voice_optimized",
                    "intent": extracted.intent.value,
                    "user_session": session.session_id
                }
            )
            
            ai_response = ai_response_result.content
            
        except Exception as e:
            logger.warning(f"AI voice response generation failed: {e}")
            # Fallback to basic response
            ai_response = action_result.get("message", "I processed your request.")
        
        # Add context-aware suggestions
        suggestions = await self._generate_ai_suggestions(extracted, action_result, session)
        
        # Add follow-up questions if needed
        follow_up_questions = self._generate_follow_up_questions(extracted, action_result, session)
        
        return VoiceResponse(
            success=action_result.get("action") != "error",
            transcription=transcription,
            intent=extracted.intent.value,
            confidence=extracted.confidence,
            action_taken=action_result.get("action"),
            work_order_id=action_result.get("work_order_id"),
            ai_response=ai_response,
            suggestions=suggestions,
            follow_up_questions=follow_up_questions
        )
    
    async def _generate_ai_suggestions(self, extracted: ExtractedData, action_result: Dict, session: VoiceSession) -> List[str]:
        """Generate AI-powered contextual suggestions"""
        try:
            # Import AI provider
            try:
                from .ai_model_provider import ai_provider
            except ImportError:
                from ai_model_provider import ai_provider
            
            suggestion_prompt = f"""Generate 2-3 helpful suggestions for a maintenance technician based on their voice command.

CONTEXT:
- Intent: {extracted.intent.value}
- Action Completed: {action_result.get('action')}
- Asset: {extracted.asset_name or 'unspecified'}
- Priority: {extracted.priority or 'unspecified'}

REQUIREMENTS:
- Each suggestion should be actionable
- Focus on immediate next steps
- Consider safety and best practices
- Keep suggestions brief and practical

Return as a simple list, one suggestion per line."""

            response = await ai_provider.generate(
                message=suggestion_prompt,
                context="suggestions",
                max_tokens=100,
                temperature=0.4
            )
            
            # Parse suggestions from response
            suggestions = [
                line.strip().lstrip('- ').lstrip('• ')
                for line in response.content.split('\n')
                if line.strip() and not line.strip().startswith('#')
            ]
            
            return suggestions[:3]  # Limit to 3 suggestions
            
        except Exception as e:
            logger.warning(f"AI suggestion generation failed: {e}")
            return self._generate_suggestions(extracted, action_result, session)
    
    def _generate_suggestions(self, extracted: ExtractedData, action_result: Dict, session: VoiceSession) -> List[str]:
        """Generate contextual suggestions for the user"""
        suggestions = []
        
        if extracted.intent == IntentType.CREATE_WORK_ORDER and action_result.get("action") == "work_order_created":
            suggestions.extend([
                "Would you like to assign this work order to a specific technician?",
                "Do you need to add any safety notes or special instructions?",
                "Should I check for required parts and tools?"
            ])
            
        elif extracted.intent == IntentType.DIAGNOSE_ISSUE:
            suggestions.extend([
                "Would you like me to create a work order for this issue?",
                "Do you need the diagnostic checklist for this equipment?",
                "Should I look up the maintenance manual?"
            ])
            
        elif extracted.safety_concern:
            suggestions.extend([
                "Would you like me to escalate this safety concern?",
                "Do you need the emergency contact information?",
                "Should I create a high-priority work order?"
            ])
            
        return suggestions[:3]  # Limit to top 3
    
    def _generate_follow_up_questions(self, extracted: ExtractedData, action_result: Dict, session: VoiceSession) -> List[str]:
        """Generate relevant follow-up questions"""
        questions = []
        
        if action_result.get("action") == "request_info":
            return [f"Could you provide {info}?" for info in action_result.get("missing", [])]
        
        if extracted.intent == IntentType.CREATE_WORK_ORDER and not extracted.priority:
            questions.append("What priority level should I assign to this work order?")
            
        if extracted.intent == IntentType.DIAGNOSE_ISSUE and not extracted.symptoms:
            questions.append("What specific symptoms are you observing?")
            
        return questions[:2]  # Limit to 2 questions

# Global instance
voice_processor = VoiceCommandProcessor()

# API Endpoints
@voice_router.post("/command", response_model=VoiceResponse)
async def process_voice_command(request: VoiceCommandRequest):
    """Process voice command endpoint"""
    return await voice_processor.process_voice_command(request)

@voice_router.post("/upload-audio")
async def upload_audio(audio_file: UploadFile = File(...), user_id: str = "default"):
    """Upload audio file for processing"""
    try:
        # Read audio file
        audio_data = await audio_file.read()
        audio_base64 = base64.b64encode(audio_data).decode('utf-8')
        
        # Process command
        request = VoiceCommandRequest(
            audio_data=audio_base64,
            user_id=user_id
        )
        
        response = await voice_processor.process_voice_command(request)
        return response
        
    except Exception as e:
        logger.error(f"Audio upload processing failed: {e}")
        raise HTTPException(status_code=500, detail="Audio processing failed")

@voice_router.get("/sessions/{user_id}")
async def get_user_sessions(user_id: str):
    """Get user's voice command sessions"""
    user_sessions = {
        session_id: session for session_id, session in voice_processor.sessions.items()
        if session.user_id == user_id
    }
    
    return {
        "user_id": user_id,
        "active_sessions": len(user_sessions),
        "sessions": [
            {
                "session_id": session.session_id,
                "created": session.conversation_history[0]["timestamp"] if session.conversation_history else None,
                "commands_processed": len(session.conversation_history),
                "current_workflow": session.current_workflow
            }
            for session in user_sessions.values()
        ]
    }

@voice_router.delete("/sessions/{session_id}")
async def clear_session(session_id: str):
    """Clear a specific voice session"""
    if session_id in voice_processor.sessions:
        del voice_processor.sessions[session_id]
        return {"message": f"Session {session_id} cleared"}
    else:
        raise HTTPException(status_code=404, detail="Session not found")

# Export main components
__all__ = ['voice_router', 'VoiceCommandProcessor', 'voice_processor', 'VoiceCommandRequest', 'VoiceResponse']