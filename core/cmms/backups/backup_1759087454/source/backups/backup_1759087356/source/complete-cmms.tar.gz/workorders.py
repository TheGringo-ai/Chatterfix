#!/usr/bin/env python3
"""
CMMS Work Orders Module
Work order creation, tracking, assignment and lifecycle management
"""

from fastapi import APIRouter, HTTPException, Query, UploadFile, File, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta, timezone
import logging
import time
# Handle speech recognition dependency gracefully
try:
    import speech_recognition as sr
    SPEECH_RECOGNITION_AVAILABLE = True
except ImportError:
    SPEECH_RECOGNITION_AVAILABLE = False
    sr = None
import tempfile
import os
import base64
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles
from form_components import FormComponents
from api_schemas import (
    WorkOrderStatus, WorkOrderKPIs, WorkOrderTabs, WorkOrderActivity, 
    TechnicianWorkload, ScheduledWorkOrder, WorkOrderDashboardResponse, WorkOrderScheduleResponse,
    TimeEntry, TimeEntryResponse, WorkNote, WorkNoteResponse, PartsCheckout, PartsCheckoutResponse,
    ScheduleConflict, TechnicianAvailability, PhotoUploadResponse
)

logger = logging.getLogger(__name__)

# Handle pandas dependency gracefully
try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

# Initialize missing data stores
photos_db = []  # Photo storage for work orders
comments_db = []  # Comments storage

# Industrial Voice Transcription System
class VoiceTranscriptionRequest(BaseModel):
    audio_data: str  # Base64 encoded audio
    audio_format: str = "wav"
    noise_filtering: bool = True
    context_hints: Optional[List[str]] = ["pump", "conveyor", "motor", "repair", "maintenance", "urgent"]

def transcribe_industrial_voice(audio_data: str, audio_format: str = "wav", 
                               noise_filtering: bool = True, context_hints: Optional[List[str]] = None) -> Dict[str, Any]:
    """
    Industrial-grade voice transcription with noise filtering for factory environments.
    
    Args:
        audio_data: Base64 encoded audio data
        audio_format: Audio format (wav, mp3, etc.)
        noise_filtering: Enable ambient noise filtering
        context_hints: Industrial maintenance vocabulary hints
        
    Returns:
        Dict with transcription, confidence, and metadata
    """
    if not SPEECH_RECOGNITION_AVAILABLE:
        return {
            "success": False,
            "error": "Speech recognition not available",
            "transcription": "",
            "confidence": 0.0,
            "processing_time": 0.0,
            "suggestion": "Install speech_recognition package for voice functionality"
        }
        
    try:
        # Initialize recognizer with industrial settings
        recognizer = sr.Recognizer()
        
        # Factory environment optimizations
        recognizer.energy_threshold = 4000  # Higher threshold for noisy environments
        recognizer.dynamic_energy_threshold = True
        recognizer.pause_threshold = 0.8  # Longer pause detection
        
        # Decode base64 audio data
        audio_bytes = base64.b64decode(audio_data)
        
        # Create temporary audio file
        with tempfile.NamedTemporaryFile(suffix=f".{audio_format}", delete=False) as temp_file:
            temp_file.write(audio_bytes)
            temp_file_path = temp_file.name
        
        try:
            # Load audio file
            with sr.AudioFile(temp_file_path) as source:
                # Apply noise filtering for factory environments
                if noise_filtering:
                    recognizer.adjust_for_ambient_noise(source, duration=1.0)
                
                # Record audio with industrial optimizations
                audio = recognizer.record(source)
            
            # Multi-provider transcription for maximum accuracy
            transcription_results = []
            
            # Google Speech Recognition (primary)
            try:
                google_result = recognizer.recognize_google(
                    audio, 
                    language="en-US",
                    show_all=True
                )
                if google_result and 'alternative' in google_result:
                    best_result = google_result['alternative'][0]
                    transcription_results.append({
                        'provider': 'google',
                        'text': best_result['transcript'],
                        'confidence': best_result.get('confidence', 0.0)
                    })
            except sr.UnknownValueError:
                pass
            except Exception as e:
                logger.warning(f"Google transcription failed: {e}")
            
            # Sphinx (offline backup)
            try:
                sphinx_result = recognizer.recognize_sphinx(audio)
                transcription_results.append({
                    'provider': 'sphinx',
                    'text': sphinx_result,
                    'confidence': 0.7  # Estimated confidence for Sphinx
                })
            except Exception as e:
                logger.warning(f"Sphinx transcription failed: {e}")
            
            if not transcription_results:
                return {
                    'success': False,
                    'error': 'Could not transcribe audio',
                    'confidence': 0.0,
                    'provider': 'none'
                }
            
            # Select best transcription result
            best_result = max(transcription_results, key=lambda x: x['confidence'])
            
            # Post-process for industrial maintenance context
            transcribed_text = best_result['text'].lower()
            
            # Apply maintenance vocabulary corrections
            maintenance_corrections = {
                'pump': ['pup', 'pump', 'pumps'],
                'conveyor': ['conveyor belt', 'conveyer', 'conveyor'],
                'motor': ['motor', 'moter', 'engine'],
                'bearing': ['bearing', 'baring'],
                'seal': ['seal', 'steel'],
                'urgent': ['urgent', 'emergency', 'critical'],
                'repair': ['repair', 'fix', 'maintenance'],
                'vibration': ['vibration', 'vibrating', 'shaking'],
                'leak': ['leak', 'leaking', 'dripping']
            }
            
            corrected_text = transcribed_text
            for correct_term, variations in maintenance_corrections.items():
                for variation in variations:
                    if variation in corrected_text:
                        corrected_text = corrected_text.replace(variation, correct_term)
            
            return {
                'success': True,
                'transcription': corrected_text.capitalize(),
                'confidence': best_result['confidence'],
                'provider': best_result['provider'],
                'audio_duration': len(audio_bytes) / 16000,  # Estimated duration
                'noise_filtered': noise_filtering,
                'alternatives': [r['text'] for r in transcription_results],
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
            
        finally:
            # Clean up temporary file
            os.unlink(temp_file_path)
            
    except Exception as e:
        logger.error(f"Voice transcription failed: {e}")
        return {
            'success': False,
            'error': str(e),
            'confidence': 0.0,
            'provider': 'error'
        }

# Enums are imported from api_schemas.py

# Work orders router
workorders_router = APIRouter(prefix="/workorders", tags=["workorders"])

# Data models
class WorkOrder(BaseModel):
    id: str
    title: str
    description: str
    asset_id: str
    type: str  # reactive, preventive, predictive
    priority: str
    status: str
    created_date: str
    created_by: str
    assigned_to: Optional[str] = None
    due_date: Optional[str] = None
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    cost: Optional[float] = None
    sla_hours: Optional[int] = None
    acknowledged_at: Optional[str] = None
    closed_date: Optional[str] = None
    escalated: Optional[bool] = False

class WorkOrderComment(BaseModel):
    id: str
    work_order_id: str
    author: str
    timestamp: str
    comment: str
    attachments: List[str]

class WorkOrderStatusHistory(BaseModel):
    id: str
    work_order_id: str
    status: str
    timestamp: str
    updated_by: str
    notes: str

# Mock database
work_orders_db = [
    {
        "id": "WO-001",
        "title": "Emergency Generator Repair",
        "description": "Generator failed to start during weekly test. Investigate and repair fuel system issue.",
        "asset_id": "AST-004",
        "type": "reactive",
        "priority": "urgent",
        "status": "in_progress",
        "created_date": "2025-08-30",
        "created_by": "John Smith",
        "assigned_to": "TECH-001",
        "due_date": "2025-09-02",
        "estimated_hours": 6.0,
        "actual_hours": 3.5,
        "cost": 450.00,
        "sla_hours": 24,
        "acknowledged_at": "2025-08-30 11:00:00"
    },
    {
        "id": "WO-002",
        "title": "Conveyor Belt Inspection",
        "description": "Monthly preventive maintenance inspection of main conveyor system.",
        "asset_id": "AST-002",
        "type": "preventive", 
        "priority": "medium",
        "status": "assigned",
        "created_date": "2025-08-31",
        "created_by": "System",
        "assigned_to": "TECH-002",
        "due_date": "2025-09-05",
        "estimated_hours": 2.0,
        "actual_hours": None,
        "cost": None,
        "sla_hours": 72
    },
    {
        "id": "WO-003",
        "title": "HVAC Filter Replacement", 
        "description": "Replace air filters in main HVAC unit and check system performance.",
        "asset_id": "AST-003",
        "type": "preventive",
        "priority": "low",
        "status": "open",
        "created_date": "2025-08-28",
        "created_by": "Sarah Davis",
        "assigned_to": None,
        "due_date": "2025-09-10",
        "estimated_hours": 4.0,
        "actual_hours": None,
        "cost": None,
        "sla_hours": 96
    },
    {
        "id": "WO-004",
        "title": "Packaging Machine Motor Bearing",
        "description": "Replace motor bearing on packaging line. Machine making unusual noise and vibration detected.",
        "asset_id": "AST-005",
        "type": "predictive",
        "priority": "high",
        "status": "parts_required",
        "created_date": "2025-08-29",
        "created_by": "Mike Johnson",
        "assigned_to": "TECH-004",
        "due_date": "2025-09-03",
        "estimated_hours": 8.0,
        "actual_hours": 2.0,
        "cost": 1200.00,
        "sla_hours": 48
    },
    {
        "id": "WO-005",
        "title": "Compressor Oil Analysis",
        "description": "Collect and analyze oil sample from primary air compressor for contamination.",
        "asset_id": "AST-001",
        "type": "preventive",
        "priority": "low",
        "status": "completed",
        "created_date": "2025-08-25",
        "created_by": "System",
        "assigned_to": "TECH-001",
        "due_date": "2025-08-30",
        "estimated_hours": 1.0,
        "actual_hours": 0.5,
        "cost": 75.00,
        "sla_hours": 24,
        "closed_date": "2025-08-30 09:00:00"
    }
]

work_order_comments_db = [
    {
        "id": "CMT-001",
        "work_order_id": "WO-001",
        "author": "TECH-001",
        "timestamp": "2025-08-30 14:30:00",
        "comment": "Initial diagnosis complete. Fuel pump needs replacement. Ordering part now.",
        "attachments": ["fuel_pump_photo.jpg"]
    },
    {
        "id": "CMT-002",
        "work_order_id": "WO-001",
        "author": "TECH-001",
        "timestamp": "2025-08-31 09:15:00",
        "comment": "Part received. Installing new fuel pump. Estimated completion by 2 PM.",
        "attachments": []
    },
    {
        "id": "CMT-003",
        "work_order_id": "WO-004",
        "author": "TECH-004",
        "timestamp": "2025-08-29 16:45:00",
        "comment": "Confirmed bearing failure. Ordered replacement bearing PRT-001. Expected delivery tomorrow.",
        "attachments": ["bearing_inspection.jpg", "vibration_data.pdf"]
    }
]

work_order_status_history_db = [
    {
        "id": "STS-001",
        "work_order_id": "WO-001",
        "status": "open",
        "timestamp": "2025-08-30 10:00:00",
        "updated_by": "John Smith",
        "notes": "Work order created"
    },
    {
        "id": "STS-002",
        "work_order_id": "WO-001", 
        "status": "assigned",
        "timestamp": "2025-08-30 10:30:00",
        "updated_by": "System",
        "notes": "Assigned to TECH-001"
    },
    {
        "id": "STS-003",
        "work_order_id": "WO-001",
        "status": "in_progress",
        "timestamp": "2025-08-30 14:00:00",
        "updated_by": "TECH-001",
        "notes": "Started troubleshooting"
    }
]

# Time entries database
time_entries_db = []

# Work notes database (for voice notes and manual notes)
work_notes_db = []

# Photo uploads database
photo_uploads_db = []

# Parts checkouts database  
parts_checkouts_db = []

try:
    from .db.database import get_session, get_engine
    from .db.models import WorkOrderORM
    _DB_ENABLED = True
except Exception:  # relative import may fail if running directly
    try:
        from db.database import get_session, get_engine  # type: ignore
        from db.models import WorkOrderORM  # type: ignore
        _DB_ENABLED = True
    except Exception:
        _DB_ENABLED = False
        get_session = None  # type: ignore

# =============================================================================
# Industry-Standard KPI Calculation Functions
# =============================================================================

def calculate_work_order_kpis(window_days: int = 90) -> WorkOrderKPIs:
    """Calculate KPIs using industry-standard formulas (ISO 14224, SMRP Best Practices)"""
    
    now = datetime.now()
    window_start = now - timedelta(days=window_days)
    today_str = now.strftime("%Y-%m-%d")
    
    # Get work orders within calculation window
    all_wos = work_orders_db.copy()
    
    # Open work orders (not completed/closed/cancelled)
    open_wos = [wo for wo in all_wos if wo['status'] not in ['completed', 'closed', 'cancelled']]
    
    # Overdue work orders - past due date and not completed
    overdue_wos = []
    for wo in open_wos:
        if wo.get('due_date') and wo['due_date'] < today_str:
            overdue_wos.append(wo)
    
    # High priority work orders (urgent + high)
    high_priority_wos = [wo for wo in open_wos if wo.get('priority', '').lower() in ['urgent', 'critical', 'high']]
    
    # Calculate average age of open work orders in days
    total_age_days = 0
    for wo in open_wos:
        created_date = datetime.strptime(wo['created_date'], "%Y-%m-%d")
        age_days = (now - created_date).days
        total_age_days += age_days
    
    avg_age_days = total_age_days / len(open_wos) if open_wos else 0
    
    # MTTR (Mean Time To Repair) - ISO 14224 standard
    # Calculate from completed work orders with actual hours
    completed_wos = [wo for wo in all_wos if wo['status'] == 'completed' and wo.get('actual_hours')]
    window_completed = []
    for wo in completed_wos:
        created_date = datetime.strptime(wo['created_date'], "%Y-%m-%d")
        if created_date >= window_start:
            window_completed.append(wo)
    
    total_repair_hours = sum(wo.get('actual_hours', 0) for wo in window_completed)
    mttr_hours = total_repair_hours / len(window_completed) if window_completed else 0
    
    # Schedule Compliance - SMRP Best Practices
    # Percentage of work orders completed on or before due date
    scheduled_completed = []
    on_time_completions = 0
    
    for wo in window_completed:
        if wo.get('due_date'):
            scheduled_completed.append(wo)
            # For completed WOs, assume completion was on time if closed_date <= due_date
            # In real system, would compare actual completion date to due date
            if wo.get('closed_date'):
                try:
                    closed_dt = datetime.strptime(wo['closed_date'], "%Y-%m-%d %H:%M:%S")
                    due_dt = datetime.strptime(wo['due_date'], "%Y-%m-%d")
                    if closed_dt.date() <= due_dt.date():
                        on_time_completions += 1
                except:
                    # If dates can't be parsed, assume on time
                    on_time_completions += 1
            else:
                # If no closed date, assume on time for completed WOs
                on_time_completions += 1
    
    schedule_compliance_pct = (on_time_completions / len(scheduled_completed) * 100) if scheduled_completed else 100
    
    # SLA Breaches - Work orders exceeding SLA time
    sla_breaches = 0
    for wo in open_wos:
        if wo.get('sla_hours'):
            created_dt = datetime.strptime(wo['created_date'], "%Y-%m-%d")
            hours_open = (now - created_dt).total_seconds() / 3600
            if hours_open > wo['sla_hours']:
                sla_breaches += 1
    
    # Technician Utilization - Basic calculation
    # In a real system, this would be based on actual time tracking
    total_estimated_hours = sum(wo.get('estimated_hours', 0) for wo in open_wos)
    # Assume 8 hours per day per technician, with 3 active technicians (simplified)
    available_hours = 8 * 3 * window_days
    utilization_pct = min((total_estimated_hours / available_hours * 100), 100) if available_hours > 0 else 0
    
    return WorkOrderKPIs(
        open_count=len(open_wos),
        overdue_count=len(overdue_wos),
        high_priority_count=len(high_priority_wos),
        average_age_days=round(avg_age_days, 1),
        mttr_hours=round(mttr_hours, 2),
        schedule_compliance_pct=round(schedule_compliance_pct, 1),
        technician_utilization_pct=round(utilization_pct, 1),
        sla_breach_count=sla_breaches
    )

def calculate_work_order_tabs() -> WorkOrderTabs:
    """Calculate tab counts for dashboard"""
    all_count = len(work_orders_db)
    
    # Upcoming - work orders due within next 7 days and not completed
    now = datetime.now()
    upcoming_date = (now + timedelta(days=7)).strftime("%Y-%m-%d")
    today_str = now.strftime("%Y-%m-%d")
    
    upcoming_count = 0
    for wo in work_orders_db:
        if (wo['status'] not in ['completed', 'closed', 'cancelled'] and 
            wo.get('due_date') and 
            today_str <= wo['due_date'] <= upcoming_date):
            upcoming_count += 1
    
    # Past due - work orders past due date and not completed
    past_due_count = 0
    for wo in work_orders_db:
        if (wo['status'] not in ['completed', 'closed', 'cancelled'] and 
            wo.get('due_date') and wo['due_date'] < today_str):
            past_due_count += 1
    
    # Completed
    completed_count = len([wo for wo in work_orders_db if wo['status'] == 'completed'])
    
    return WorkOrderTabs(
        all=all_count,
        upcoming=upcoming_count,
        past_due=past_due_count,
        completed=completed_count
    )

def get_recent_activity(limit: int = 10) -> List[WorkOrderActivity]:
    """Get recent work order activity from status history and comments"""
    activities = []
    
    # Convert status history to activities
    for status in work_order_status_history_db:
        activities.append(WorkOrderActivity(
            id=status['id'],
            work_order_id=status['work_order_id'],
            activity_type="status_change",
            description=f"Status changed to {status['status'].replace('_', ' ').title()}",
            user=status['updated_by'],
            timestamp=datetime.strptime(status['timestamp'], "%Y-%m-%d %H:%M:%S")
        ))
    
    # Convert comments to activities
    for comment in work_order_comments_db:
        activities.append(WorkOrderActivity(
            id=comment['id'],
            work_order_id=comment['work_order_id'],
            activity_type="commented",
            description=comment['comment'][:100] + "..." if len(comment['comment']) > 100 else comment['comment'],
            user=comment['author'],
            timestamp=datetime.strptime(comment['timestamp'], "%Y-%m-%d %H:%M:%S")
        ))
    
    # Sort by timestamp descending and limit
    activities.sort(key=lambda x: x.timestamp, reverse=True)
    return activities[:limit]

def get_technician_workload() -> List[TechnicianWorkload]:
    """Calculate technician workload metrics"""
    technicians = {}
    
    # Get active work orders by technician
    for wo in work_orders_db:
        if wo.get('assigned_to') and wo['status'] not in ['completed', 'closed', 'cancelled']:
            tech_id = wo['assigned_to']
            if tech_id not in technicians:
                technicians[tech_id] = {
                    'technician_id': tech_id,
                    'technician_name': tech_id,  # In real system, would lookup name
                    'active_work_orders': 0,
                    'estimated_hours': 0,
                    'actual_hours': 0
                }
            
            technicians[tech_id]['active_work_orders'] += 1
            technicians[tech_id]['estimated_hours'] += wo.get('estimated_hours') or 0
            technicians[tech_id]['actual_hours'] += wo.get('actual_hours') or 0
    
    # Calculate utilization (simplified - assume 40 hours per week capacity)
    workload_list = []
    for tech_data in technicians.values():
        utilization_pct = min((tech_data['estimated_hours'] / 40) * 100, 100)
        workload_list.append(TechnicianWorkload(
            technician_id=tech_data['technician_id'],
            technician_name=tech_data['technician_name'],
            active_work_orders=tech_data['active_work_orders'],
            estimated_hours=tech_data['estimated_hours'],
            actual_hours=tech_data['actual_hours'],
            utilization_pct=round(utilization_pct, 1)
        ))
    
    return workload_list

def get_scheduled_work_orders(start_date: str, end_date: str) -> List[ScheduledWorkOrder]:
    """Get work orders with scheduling information for calendar view"""
    scheduled_wos = []
    
    priority_colors = {
        'critical': '#e53e3e',
        'urgent': '#e53e3e', 
        'high': '#d69e2e',
        'medium': '#38a169',
        'low': '#4299e1'
    }
    
    for wo in work_orders_db:
        # Only include work orders with due dates or in progress
        if wo.get('due_date') or wo['status'] == 'in_progress':
            color = priority_colors.get(wo.get('priority', 'low'), '#4299e1')
            
            scheduled_wo = ScheduledWorkOrder(
                id=wo['id'],
                title=wo['title'],
                asset_id=wo['asset_id'],
                assigned_to=wo.get('assigned_to'),
                assigned_to_name=wo.get('assigned_to'),  # In real system, would lookup name
                scheduled_start=wo.get('due_date'),
                scheduled_end=wo.get('due_date'),  # Simplified - would calculate based on duration
                estimated_hours=wo.get('estimated_hours'),
                priority=wo.get('priority', 'low'),
                status=wo['status'],
                color=color
            )
            scheduled_wos.append(scheduled_wo)
    
    return scheduled_wos

def detect_schedule_conflicts(work_orders: List[ScheduledWorkOrder]) -> List[ScheduleConflict]:
    """Detect scheduling conflicts for technicians"""
    conflicts = []
    technician_schedules = {}
    
    # Group work orders by technician and date
    for wo in work_orders:
        if wo.assigned_to and wo.scheduled_start:
            tech_id = wo.assigned_to
            date = wo.scheduled_start
            
            if tech_id not in technician_schedules:
                technician_schedules[tech_id] = {}
            if date not in technician_schedules[tech_id]:
                technician_schedules[tech_id][date] = []
            
            technician_schedules[tech_id][date].append(wo)
    
    # Check for conflicts (more than 8 hours scheduled per day)
    for tech_id, dates in technician_schedules.items():
        for date, wo_list in dates.items():
            total_hours = sum(wo.estimated_hours or 4 for wo in wo_list)  # Default 4 hours if not specified
            
            if total_hours > 8:  # Standard 8-hour workday
                conflicts.append(ScheduleConflict(
                    technician_id=tech_id,
                    date=date,
                    overlapping_work_orders=[wo.id for wo in wo_list],
                    total_hours=total_hours,
                    message=f"Overallocated by {total_hours - 8:.1f} hours"
                ))
    
    return conflicts

# After mock database definitions, add sync helper
if _DB_ENABLED:
    try:
        eng = get_engine()
        # Create tables if missing
        from sqlalchemy import inspect  # type: ignore
        insp = inspect(eng)
        if 'work_orders' not in insp.get_table_names():
            from db.database import Base  # type: ignore
            Base.metadata.create_all(bind=eng)  # type: ignore
        # Seed DB if empty
        with get_session() as s:  # type: ignore
            if not s.query(WorkOrderORM).first():  # type: ignore
                for wo in work_orders_db:
                    s.add(WorkOrderORM(**wo))  # type: ignore
                s.commit()
    except Exception as e:  # pragma: no cover
        logger.warning(f"DB init failed, running in memory-only mode: {e}")
        _DB_ENABLED = False

# =============================================================================
# Enhanced Dashboard API Endpoints
# =============================================================================

@workorders_router.get("/api/dashboard")
async def get_work_orders_dashboard() -> WorkOrderDashboardResponse:
    """Get comprehensive work orders dashboard data with KPIs, tabs, and activities"""
    
    kpis = calculate_work_order_kpis()
    tabs = calculate_work_order_tabs()
    recent_activity = get_recent_activity()
    technician_workload = get_technician_workload()
    
    # Performance trend data (mock data - in real system would be calculated)
    performance_trend = {
        "completion_rate": [85.2, 87.1, 84.6, 89.3, 91.2, 88.7],
        "mttr_hours": [4.2, 3.8, 4.1, 3.5, 3.2, 3.6],
        "schedule_compliance": [78.5, 82.1, 80.3, 85.7, 87.2, 83.9]
    }
    
    return WorkOrderDashboardResponse(
        kpis=kpis,
        tabs=tabs,
        recent_activity=recent_activity,
        technician_workload=technician_workload,
        performance_trend=performance_trend
    )

@workorders_router.get("/api/schedule")
async def get_work_order_schedule(
    start_date: str = Query(..., description="Start date (YYYY-MM-DD)"),
    end_date: str = Query(..., description="End date (YYYY-MM-DD)"),
    technician: Optional[str] = Query(None, description="Filter by technician ID")
) -> WorkOrderScheduleResponse:
    """Get work order schedule for calendar view with conflict detection"""
    
    # Get scheduled work orders within date range
    scheduled_wos = []
    for wo in work_orders_db:
        if wo.get('due_date') and start_date <= wo['due_date'] <= end_date:
            priority_colors = {
                'critical': '#e53e3e', 'urgent': '#e53e3e', 
                'high': '#d69e2e', 'medium': '#38a169', 'low': '#4299e1'
            }
            color = priority_colors.get(wo.get('priority', 'low'), '#4299e1')
            
            scheduled_wo = ScheduledWorkOrder(
                id=wo['id'],
                title=wo['title'],
                asset_id=wo['asset_id'],
                assigned_to=wo.get('assigned_to'),
                assigned_to_name=wo.get('assigned_to'),
                scheduled_start=wo.get('due_date'),
                scheduled_end=wo.get('due_date'),
                estimated_hours=wo.get('estimated_hours'),
                priority=wo.get('priority', 'low'),
                status=wo['status'],
                color=color
            )
            scheduled_wos.append(scheduled_wo)
    
    # Filter by technician if specified
    if technician:
        scheduled_wos = [wo for wo in scheduled_wos if wo.assigned_to == technician]
    
    # Detect scheduling conflicts
    conflicts = detect_schedule_conflicts(scheduled_wos)
    
    # Calculate technician availability
    availability = []
    technicians = set(wo.assigned_to for wo in scheduled_wos if wo.assigned_to)
    
    for tech_id in technicians:
        tech_wos = [wo for wo in scheduled_wos if wo.assigned_to == tech_id]
        scheduled_hours = sum(wo.estimated_hours or 4 for wo in tech_wos)
        
        availability.append(TechnicianAvailability(
            technician_id=tech_id,
            technician_name=tech_id,
            date=start_date,
            available_hours=8.0,
            scheduled_hours=scheduled_hours,
            capacity_pct=min((scheduled_hours / 8.0) * 100, 100)
        ))
    
    return WorkOrderScheduleResponse(
        work_orders=scheduled_wos,
        conflicts=conflicts,
        availability=availability
    )

@workorders_router.patch("/api/{work_order_id}/status")
async def update_work_order_status(
    work_order_id: str,
    status_update: Dict[str, Any]
) -> Dict:
    """Update work order status with tracking"""
    
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    old_status = work_order['status']
    new_status = status_update.get('status')
    
    if new_status:
        work_order['status'] = new_status
        
        # Update completion data if completing
        if new_status == 'completed':
            work_order['actual_hours'] = status_update.get('actual_hours')
            work_order['closed_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Record status change
        status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
        status_entry = {
            "id": status_id,
            "work_order_id": work_order_id,
            "status": new_status,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "updated_by": status_update.get("updated_by", "System"),
            "notes": status_update.get("notes", f"Status changed from {old_status} to {new_status}")
        }
        work_order_status_history_db.append(status_entry)
        
        logger.info(f"Work order {work_order_id} status changed: {old_status} -> {new_status}")
    
    return {"message": "Status updated successfully", "work_order": work_order}

@workorders_router.post("/api/bulk-update")
async def bulk_update_work_orders(bulk_update: Dict[str, Any]) -> Dict:
    """Bulk update multiple work orders"""
    
    work_order_ids = bulk_update.get('work_order_ids', [])
    updates = bulk_update.get('updates', {})
    reason = bulk_update.get('reason', 'Bulk update')
    
    if not work_order_ids:
        raise HTTPException(status_code=400, detail="No work order IDs provided")
    
    updated_count = 0
    errors = []
    
    for wo_id in work_order_ids:
        try:
            work_order = next((wo for wo in work_orders_db if wo['id'] == wo_id), None)
            if work_order:
                for key, value in updates.items():
                    if key in work_order and value is not None:
                        old_value = work_order[key]
                        work_order[key] = value
                        
                        if key == 'status' and old_value != value:
                            status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
                            status_entry = {
                                "id": status_id,
                                "work_order_id": wo_id,
                                "status": value,
                                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                "updated_by": "System",
                                "notes": f"Bulk update: {reason}"
                            }
                            work_order_status_history_db.append(status_entry)
                
                updated_count += 1
            else:
                errors.append({"work_order_id": wo_id, "error": "Work order not found"})
                
        except Exception as e:
            errors.append({"work_order_id": wo_id, "error": str(e)})
    
    return {
        "message": f"Updated {updated_count} work orders",
        "updated_count": updated_count,
        "total_requested": len(work_order_ids),
        "errors": errors
    }

@workorders_router.get("/dashboard", response_class=HTMLResponse)
async def workorders_dashboard(request: Request = None):
    """Enhanced Work Orders Dashboard with KPIs, tabs, and calendar view"""
    from fastapi.templating import Jinja2Templates
    import os
    
    # Use optimized template system
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    templates = Jinja2Templates(directory=template_dir)
    
    # Get dashboard data using new KPI functions
    kpis = calculate_work_order_kpis()
    tabs = calculate_work_order_tabs()
    
    # Extract variables for template (safe/backward compatible)
    try:
        total_work_orders = len(work_orders_db)
        # Use string values instead of enum to ensure compatibility
        open_work_orders = len([wo for wo in work_orders_db if str(wo.get('status', '')).lower() in ['open', 'assigned']])
        in_progress = len([wo for wo in work_orders_db if str(wo.get('status', '')).lower() == 'in_progress'])
        overdue = len([wo for wo in work_orders_db if wo.get('due_date') and str(wo.get('status', '')).lower() not in ['completed', 'cancelled']])
    except Exception as e:
        # Fallback to safe defaults if there's any issue
        total_work_orders = 0
        open_work_orders = 0
        in_progress = 0
        overdue = 0
    # Calculate actual SLA breaches
    from datetime import datetime, timedelta
    sla_breaches = 0
    now = datetime.now()
    try:
        for wo in work_orders_db:
            if wo.get('sla_hours') and wo.get('created_date') and str(wo.get('status', '')).lower() not in ['completed', 'cancelled']:
                try:
                    created = datetime.fromisoformat(wo['created_date'].replace('Z', '+00:00'))
                    sla_deadline = created + timedelta(hours=wo['sla_hours'])
                    if now > sla_deadline:
                        sla_breaches += 1
                except (ValueError, TypeError):
                    continue  # Skip invalid date formats
    except Exception:
        sla_breaches = 0  # Safe fallback
    work_orders_html = ""  # Will be generated later
    
    # Generate work order table rows
    def generate_wo_row(wo):
        return f"""
        <tr data-status="{wo['status']}" data-priority="{wo['priority']}" data-type="{wo['type']}" 
            data-technician="{wo.get('assigned_to', '')}" data-title="{wo['title'].lower()}" 
            data-wo-id="{wo['id']}">
            <td class="wo-checkbox-cell">
                <input type="checkbox" class="wo-checkbox" value="{wo['id']}" />
            </td>
            <td><strong class="wo-id">{wo['id']}</strong></td>
            <td class="wo-title-cell">
                <div class="wo-title">{wo['title'][:40]}{'...' if len(wo['title']) > 40 else ''}</div>
                <div class="wo-description">{wo['description'][:60]}{'...' if len(wo['description']) > 60 else ''}</div>
            </td>
            <td><a href="/cmms/assets/{wo['asset_id']}/view" class="asset-link">{wo['asset_id']}</a></td>
            <td><span class="type-badge type-{wo['type']}">{wo['type'].title()}</span></td>
            <td><span class="priority-{wo['priority']}">{wo['priority'].title()}</span></td>
            <td><span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span></td>
            <td class="technician-cell">{wo.get('assigned_to', 'Unassigned')}</td>
            <td class="due-date-cell" data-due-date="{wo.get('due_date', '')}">{wo.get('due_date', 'Not set')}</td>
            <td class="wo-actions">
                <div class="action-buttons">
                    <button class="btn btn-sm btn-primary" onclick="viewWorkOrder('{wo['id']}')">View</button>
                    <button class="btn btn-sm btn-warning" onclick="editWorkOrder('{wo['id']}')">Edit</button>
                    {'<button class="btn btn-sm btn-success" onclick="startWork(&quot;' + wo['id'] + '&quot;)">Start</button>' if wo['status'] == 'assigned' else ''}
                    {'<button class="btn btn-sm btn-success" onclick="completeWork(&quot;' + wo['id'] + '&quot;)">Complete</button>' if wo['status'] == 'in_progress' else ''}
                </div>
            </td>
        </tr>
        """
    
    # Generate data for modern dashboard template
    # Prepare data for optimized template (safe/backward compatible)
    try:
        stats = {
            "active_workorders": len([wo for wo in work_orders_db if str(wo.get('status', '')).lower() in ['open', 'assigned', 'in_progress']]),
            "total_assets": total_work_orders, 
            "parts_in_stock": len([wo for wo in work_orders_db if str(wo.get('status', '')).lower() == 'completed']),
            "system_health": round((len([wo for wo in work_orders_db if str(wo.get('status', '')).lower() == 'completed'])/total_work_orders)*100) if total_work_orders > 0 else 0
        }
    except Exception:
        # Safe fallback stats
        stats = {
            "active_workorders": 0,
            "total_assets": 0, 
            "parts_in_stock": 0,
            "system_health": 85  # Default reasonable value
        }
    
    recent_workorders = []
    try:
        for wo in work_orders_db[:5]:
            recent_workorders.append({
                "id": wo.get('id', 'N/A'),
                "title": wo.get('title', 'N/A'),
                "asset_name": wo.get('asset_name', 'N/A'),
                "technician": wo.get('assigned_to', 'Unassigned'),
                "status": str(wo.get('status', 'Unknown')),
                "priority": wo.get('priority', 'Medium')
            })
    except Exception:
        # Safe fallback with sample data
        recent_workorders = [
            {"id": "WO-001", "title": "System Check", "asset_name": "N/A", "technician": "Unassigned", "status": "open", "priority": "medium"}
        ]
    
    # Create a mock request if none provided
    if request is None:
        from starlette.requests import Request as StarletteRequest
        from starlette.datastructures import URL, Headers
        
        scope = {
            "type": "http",
            "method": "GET",
            "path": "/cmms/workorders/dashboard",
            "headers": [],
            "query_string": b"",
        }
        request = StarletteRequest(scope)
    
    try:
        return templates.TemplateResponse("dashboard-rich.html", {
            "request": request,
            "module_name": "Work Orders Management",
            "stats": stats,
            "recent_workorders": recent_workorders,
            "top_assets": [
                {"name": "Equipment A", "health_score": 88, "status": "Operational", "last_maintenance": "3 days ago"},
                {"name": "Equipment B", "health_score": 92, "status": "Operational", "last_maintenance": "1 week ago"}
            ],
            "ai_stats": {"predictions_today": 23, "automation_rate": 82, "response_time": 2.3},
            "ai_activities": [
                {"icon": "📋", "title": "Work Order Analysis", "description": f"{open_work_orders} work orders need attention", "timestamp": "14:30", "confidence": 91}
            ],
            "performance": {"dashboard_load": 1.8, "ai_response": 2.3, "health_check": 8.1},
            "metrics": {"uptime": 97.5, "api_success": 96.8, "satisfaction": 4.5, "cost_savings": 9200},
            "recent_activities": [
                {"timestamp": "14:25", "icon": "📋", "type": "Work Order", "description": "New work order created", "user": "Technician", "module": "Work Orders", "status": "Success"}
            ]
        })
    except Exception as e:
        # Fallback to simple HTML response if template fails
        from fastapi.responses import HTMLResponse
        return HTMLResponse(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>ChatterFix CMMS - Work Orders</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
                .container {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                .header {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; margin-bottom: 20px; }}
                .stats {{ display: flex; gap: 20px; margin: 20px 0; }}
                .stat-card {{ background: #ecf0f1; padding: 15px; border-radius: 5px; flex: 1; text-align: center; }}
                .stat-number {{ font-size: 24px; font-weight: bold; color: #2c3e50; }}
                .stat-label {{ color: #7f8c8d; margin-top: 5px; }}
                .error {{ background: #ffe6e6; border: 1px solid #ff9999; padding: 10px; border-radius: 5px; margin: 10px 0; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1 class="header">🔧 ChatterFix CMMS - Work Orders Dashboard</h1>
                
                <div class="stats">
                    <div class="stat-card">
                        <div class="stat-number">{total_work_orders}</div>
                        <div class="stat-label">Total Work Orders</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{open_work_orders}</div>
                        <div class="stat-label">Open Orders</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{in_progress}</div>
                        <div class="stat-label">In Progress</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{overdue}</div>
                        <div class="stat-label">Overdue</div>
                    </div>
                </div>
                
                <p>✅ <strong>System Status:</strong> Work Orders system is operational</p>
                <p>🤖 <strong>AI Integration:</strong> LLaMA + premium providers active</p>
                <p>🗄️ <strong>Database:</strong> Connected and functioning</p>
                
                <div class="error">
                    <strong>Note:</strong> Dashboard template temporarily unavailable. This is a simplified view.
                    <br><small>Error: {str(e)[:100]}...</small>
                </div>
                
                <!-- Work Orders Table -->
                <div style="margin-top: 30px;">
                    <h2>Active Work Orders</h2>
                    <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
                        <thead>
                            <tr style="background: #3498db; color: white;">
                                <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">ID</th>
                                <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">Title</th>
                                <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">Asset</th>
                                <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">Priority</th>
                                <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">Status</th>
                                <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {"".join([f'''
                            <tr style="border: 1px solid #ddd;">
                                <td style="padding: 10px; border: 1px solid #ddd;"><strong>{wo["id"]}</strong></td>
                                <td style="padding: 10px; border: 1px solid #ddd;">{wo["title"][:40]}{'...' if len(wo["title"]) > 40 else ''}</td>
                                <td style="padding: 10px; border: 1px solid #ddd;">{wo["asset_id"]}</td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><span style="color: {'red' if wo['priority'] == 'critical' else 'orange' if wo['priority'] == 'high' else 'blue'};">{wo["priority"].title()}</span></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><span style="background: {'green' if wo['status'] == 'completed' else 'orange' if wo['status'] == 'in_progress' else 'blue'}; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">{wo["status"].replace('_', ' ').title()}</span></td>
                                <td style="padding: 10px; border: 1px solid #ddd;">
                                    <button onclick="viewWorkOrder('{wo["id"]}')" style="background: #3498db; color: white; border: none; padding: 6px 12px; margin: 2px; border-radius: 4px; cursor: pointer;">View</button>
                                    <button onclick="editWorkOrder('{wo["id"]}')" style="background: #f39c12; color: white; border: none; padding: 6px 12px; margin: 2px; border-radius: 4px; cursor: pointer;">Edit</button>
                                </td>
                            </tr>
                            ''' for wo in work_orders_db[:10]])}
                        </tbody>
                    </table>
                </div>
                
                <script>
                    // Work Order Management Functions
                    function viewWorkOrder(woId) {{
                        window.open(`/cmms/workorders/${{woId}}/view`, '_blank');
                    }}
                    
                    function editWorkOrder(woId) {{
                        window.open(`/cmms/workorders/${{woId}}/edit`, '_blank');
                    }}
                    
                    function startWork(woId) {{
                        if(confirm('Start work on order ' + woId + '?')) {{
                            fetch(`/cmms/workorders/${{woId}}/start`, {{
                                method: 'POST',
                                headers: {{'Content-Type': 'application/json'}},
                                body: JSON.stringify({{start_time: new Date().toISOString(), technician: 'Current User'}})
                            }})
                            .then(response => response.json())
                            .then(data => {{
                                if(data.success) {{
                                    alert('Work started successfully!');
                                    location.reload();
                                }} else {{
                                    alert('Error starting work: ' + (data.message || 'Unknown error'));
                                }}
                            }})
                            .catch(error => {{
                                alert('Error: ' + error.message);
                            }});
                        }}
                    }}
                    
                    function completeWork(woId) {{
                        if(confirm('Mark work order ' + woId + ' as complete?')) {{
                            window.open(`/cmms/workorders/${{woId}}/complete`, '_blank');
                        }}
                    }}
                    
                    // Add photo functionality
                    function addPhoto(woId) {{
                        const input = document.createElement('input');
                        input.type = 'file';
                        input.accept = 'image/*';
                        input.multiple = true;
                        input.onchange = function(e) {{
                            const files = e.target.files;
                            if(files.length > 0) {{
                                const formData = new FormData();
                                for(let file of files) {{
                                    formData.append('photos', file);
                                }}
                                
                                fetch(`/cmms/workorders/${{woId}}/photos`, {{
                                    method: 'POST',
                                    body: formData
                                }})
                                .then(response => response.json())
                                .then(data => {{
                                    alert('Photos uploaded successfully!');
                                }})
                                .catch(error => {{
                                    alert('Error uploading photos: ' + error.message);
                                }});
                            }}
                        }};
                        input.click();
                    }}
                    
                    // Add note functionality
                    function addNote(woId) {{
                        const note = prompt('Enter note for work order ' + woId + ':');
                        if(note) {{
                            fetch(`/cmms/workorders/${{woId}}/notes`, {{
                                method: 'POST',
                                headers: {{'Content-Type': 'application/json'}},
                                body: JSON.stringify({{
                                    note_text: note,
                                    note_type: 'manual',
                                    created_by: 'Current User'
                                }})
                            }})
                            .then(response => response.json())
                            .then(data => {{
                                alert('Note added successfully!');
                            }})
                            .catch(error => {{
                                alert('Error adding note: ' + error.message);
                            }});
                        }}
                    }}
                </script>
                
                <p>
                    <a href="/cmms/workorders/api" style="color: #3498db;">📊 API Data</a> | 
                    <a href="/cmms/dashboard/main" style="color: #3498db;">🏠 Main Dashboard</a> |
                    <a href="/cmms/ai/health" style="color: #3498db;">🤖 AI Status</a>
                </p>
            </div>
        </body>
        </html>
        """)

@workorders_router.get("/")
async def workorders_root():
    """Redirect to workorders dashboard"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/cmms/workorders/dashboard", status_code=302)

@workorders_router.get("/api")
async def get_work_orders(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    type: Optional[str] = Query(None),
    assigned_to: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all work orders with optional filtering"""
    filtered_work_orders = work_orders_db
    
    if status:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo['status'] == status]
    if priority:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo['priority'] == priority]
    if type:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo['type'] == type]
    if assigned_to:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo.get('assigned_to') == assigned_to]
    
    return filtered_work_orders

@workorders_router.get("/{work_order_id}")
async def get_work_order_details(work_order_id: str) -> Dict:
    """Get specific work order details"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # Get comments and status history
    comments = [c for c in work_order_comments_db if c['work_order_id'] == work_order_id]
    status_history = [s for s in work_order_status_history_db if s['work_order_id'] == work_order_id]
    
    return {
        "work_order": work_order,
        "comments": comments,
        "status_history": status_history,
        "metrics": {
            "days_open": (datetime.now() - datetime.strptime(work_order['created_date'], "%Y-%m-%d")).days,
            "estimated_vs_actual": {
                "estimated_hours": work_order.get('estimated_hours'),
                "actual_hours": work_order.get('actual_hours'),
                "variance_percent": ((work_order.get('actual_hours', 0) - work_order.get('estimated_hours', 0)) / work_order.get('estimated_hours', 1)) * 100 if work_order.get('estimated_hours') else 0
            },
            "on_schedule": work_order.get('due_date', '') >= datetime.now().strftime("%Y-%m-%d") if work_order.get('due_date') else True
        }
    }

# AI-Enhanced Natural Language Work Order Creation
class NLWorkOrderRequest(BaseModel):
    natural_language_input: str
    context: Optional[Dict[str, Any]] = None
    user_id: str = "default"
    voice_input: bool = False
    audio_data: Optional[str] = None

class NLWorkOrderResponse(BaseModel):
    success: bool
    work_order_id: Optional[str] = None
    extracted_data: Dict[str, Any]
    confidence: float
    missing_fields: List[str] = []
    suggestions: List[str] = []
    clarification_questions: List[str] = []
    ai_insights: Dict[str, Any] = {}

@workorders_router.post("/create-from-voice")
async def create_work_order_from_voice(
    audio_file: UploadFile = File(...),
    user_id: str = "default"
) -> NLWorkOrderResponse:
    """Create work order from voice input with AI processing"""
    try:
        # Read audio file
        audio_data = await audio_file.read()
        audio_base64 = base64.b64encode(audio_data).decode('utf-8')
        
        # Transcribe voice input
        transcription_result = transcribe_industrial_voice(
            audio_base64, 
            audio_format="wav",
            noise_filtering=True
        )
        
        if not transcription_result.get("success"):
            return NLWorkOrderResponse(
                success=False,
                extracted_data={},
                confidence=0.0,
                suggestions=["Voice transcription failed. Please try speaking clearly or use text input."]
            )
        
        transcribed_text = transcription_result["transcription"]
        
        # Process with natural language AI
        return await create_work_order_from_natural_language(
            NLWorkOrderRequest(
                natural_language_input=transcribed_text,
                user_id=user_id,
                voice_input=True,
                audio_data=audio_base64
            )
        )
        
    except Exception as e:
        logger.error(f"Voice work order creation failed: {e}")
        return NLWorkOrderResponse(
            success=False,
            extracted_data={},
            confidence=0.0,
            suggestions=[f"Error processing voice input: {str(e)}"]
        )

@workorders_router.post("/create-from-nl")
async def create_work_order_from_natural_language(request: NLWorkOrderRequest) -> NLWorkOrderResponse:
    """Create work order from natural language input with intelligent slot filling"""
    try:
        # Import AI technician assistant
        try:
            from ai_technician_assistant import ai_assistant
        except ImportError:
            try:
                from .ai_technician_assistant import ai_assistant
            except ImportError:
                return NLWorkOrderResponse(
                    success=False,
                    extracted_data={},
                    confidence=0.0,
                    suggestions=["AI assistant not available. Please use the standard work order form."]
                )
        
        # Process natural language with AI
        extracted_data = await ai_assistant.process_natural_language(
            request.natural_language_input,
            {
                "user_id": request.user_id,
                "input_method": "voice" if request.voice_input else "text",
                "context": request.context or {}
            }
        )
        
        # Enhanced slot filling with intelligent suggestions
        work_order_data, missing_fields, suggestions = await _intelligent_slot_filling(
            extracted_data, request.natural_language_input
        )
        
        # Generate clarification questions for missing critical fields
        clarification_questions = _generate_clarification_questions(missing_fields, extracted_data)
        
        # If we have enough information, create the work order
        if len(missing_fields) <= 1 and extracted_data.asset_id and extracted_data.description:
            try:
                # Create work order using AI assistant
                work_order_result = await ai_assistant.create_work_order_from_nl(extracted_data)
                work_order = work_order_result["work_order"]
                ai_insights = work_order_result["ai_insights"]
                
                # Add to database
                work_orders_db.append(work_order)
                
                return NLWorkOrderResponse(
                    success=True,
                    work_order_id=work_order["id"],
                    extracted_data=work_order,
                    confidence=extracted_data.confidence,
                    missing_fields=[],
                    suggestions=suggestions,
                    ai_insights=ai_insights
                )
                
            except Exception as e:
                logger.error(f"Work order creation failed: {e}")
                return NLWorkOrderResponse(
                    success=False,
                    extracted_data=work_order_data,
                    confidence=extracted_data.confidence,
                    missing_fields=missing_fields,
                    suggestions=suggestions + [f"Creation failed: {str(e)}"],
                    clarification_questions=clarification_questions
                )
        else:
            # Return partial data for user completion
            return NLWorkOrderResponse(
                success=False,
                extracted_data=work_order_data,
                confidence=extracted_data.confidence,
                missing_fields=missing_fields,
                suggestions=suggestions,
                clarification_questions=clarification_questions,
                ai_insights={"reason": "Insufficient information to create work order automatically"}
            )
        
    except Exception as e:
        logger.error(f"Natural language work order processing failed: {e}")
        return NLWorkOrderResponse(
            success=False,
            extracted_data={},
            confidence=0.0,
            suggestions=[f"Processing error: {str(e)}"]
        )

async def _intelligent_slot_filling(extracted_data, original_input: str) -> tuple:
    """Enhanced slot filling with AI-powered suggestions"""
    
    # Start with extracted data
    work_order_data = {
        "title": extracted_data.asset_name or "Maintenance Request",
        "description": extracted_data.description or original_input,
        "asset_id": extracted_data.asset_id or "unknown",
        "type": "reactive",  # Default type
        "priority": extracted_data.priority or "medium",
        "created_by": "AI Assistant",
        "estimated_hours": 2.0  # Default estimate
    }
    
    # Update with any specific extracted information
    if extracted_data.asset_name and extracted_data.description:
        work_order_data["title"] = f"{extracted_data.asset_name} - {extracted_data.problem_type or 'Maintenance'}"
    
    if extracted_data.urgency:
        urgency_priority_map = {
            "emergency": "critical",
            "urgent": "high", 
            "routine": "medium",
            "low": "low"
        }
        work_order_data["priority"] = urgency_priority_map.get(extracted_data.urgency, "medium")
    
    # Determine work order type based on context
    if any(keyword in original_input.lower() for keyword in ["schedule", "preventive", "planned"]):
        work_order_data["type"] = "preventive"
    elif any(keyword in original_input.lower() for keyword in ["predict", "condition", "monitoring"]):
        work_order_data["type"] = "predictive"
    
    # Check for missing critical fields
    missing_fields = []
    if not extracted_data.asset_id or extracted_data.asset_id == "unknown":
        missing_fields.append("asset_id")
    if not extracted_data.description or len(extracted_data.description.strip()) < 10:
        missing_fields.append("description")
    
    # Generate intelligent suggestions
    suggestions = []
    
    if extracted_data.safety_concern:
        suggestions.append("⚠️ Safety concern detected - consider high priority assignment")
        work_order_data["priority"] = "high"
    
    if extracted_data.symptoms:
        suggestions.append(f"Symptoms detected: {', '.join(extracted_data.symptoms)}")
    
    if extracted_data.equipment_type:
        suggestions.append(f"Equipment type identified: {extracted_data.equipment_type}")
    
    # Add contextual suggestions based on asset type
    if extracted_data.asset_id in ["pump_3", "conveyor_belt_1", "boiler_2"]:
        suggestions.append("Asset found in registry - auto-populated specifications")
    elif extracted_data.equipment_type:
        suggestions.append(f"Similar {extracted_data.equipment_type} assets available for reference")
    
    return work_order_data, missing_fields, suggestions

def _generate_clarification_questions(missing_fields: List[str], extracted_data) -> List[str]:
    """Generate intelligent clarification questions"""
    questions = []
    
    if "asset_id" in missing_fields:
        if extracted_data.equipment_type:
            questions.append(f"Which specific {extracted_data.equipment_type} needs attention?")
        else:
            questions.append("Which equipment or asset requires maintenance?")
    
    if "description" in missing_fields:
        questions.append("Can you provide more details about the problem or maintenance needed?")
    
    if extracted_data.symptoms and not extracted_data.problem_type:
        questions.append("What type of maintenance action is required? (repair, inspection, replacement)")
    
    if not extracted_data.priority and not extracted_data.urgency:
        questions.append("How urgent is this maintenance request? (low, medium, high, critical)")
    
    return questions

@workorders_router.post("/")
async def create_work_order(work_order_data: Dict[str, Any]) -> Dict:
    """Create new work order"""
    work_order_id = f"WO-{len(work_orders_db) + 1:03d}"
    
    new_work_order = {
        "id": work_order_id,
        "title": work_order_data["title"],
        "description": work_order_data["description"],
        "asset_id": work_order_data["asset_id"],
        "type": work_order_data["type"],
        "priority": work_order_data["priority"],
        "status": "assigned" if work_order_data.get("assigned_to") else "open",
        "created_date": datetime.now().strftime("%Y-%m-%d"),
        "created_by": work_order_data.get("created_by", "System"),
        "assigned_to": work_order_data.get("assigned_to"),
        "due_date": work_order_data.get("due_date"),
        "estimated_hours": float(work_order_data["estimated_hours"]) if work_order_data.get("estimated_hours") else None,
        "actual_hours": None,
        "cost": None
    }
    
    work_orders_db.append(new_work_order)
    if _DB_ENABLED:
        try:
            with get_session() as s:  # type: ignore
                if not s.get(WorkOrderORM, work_order_id):  # type: ignore
                    s.add(WorkOrderORM(**new_work_order))  # type: ignore
                    s.commit()
        except Exception as e:  # pragma: no cover
            logger.error(f"Failed to persist WO {work_order_id}: {e}")
    
    # Create initial status entry
    status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
    status_entry = {
        "id": status_id,
        "work_order_id": work_order_id,
        "status": new_work_order["status"],
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_by": work_order_data.get("created_by", "System"),
        "notes": "Work order created"
    }
    work_order_status_history_db.append(status_entry)
    
    logger.info(f"Work order created: {work_order_id}")
    return {
        **new_work_order,
        "message": f"Work order {work_order_id} created successfully",
        "redirect": "/cmms/workorders/dashboard"
    }

@workorders_router.put("/{work_order_id}")
async def update_work_order(work_order_id: str, update_data: Dict[str, Any]) -> Dict:
    """Update work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # Track status changes
    old_status = work_order.get('status')
    work_order.update(update_data)
    
    # If status changed, record it
    if 'status' in update_data and update_data['status'] != old_status:
        status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
        status_entry = {
            "id": status_id,
            "work_order_id": work_order_id,
            "status": update_data['status'],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "updated_by": update_data.get("updated_by", "System"),
            "notes": update_data.get("status_notes", f"Status changed to {update_data['status']}")
        }
        work_order_status_history_db.append(status_entry)
    
    if _DB_ENABLED:
        try:
            with get_session() as s:  # type: ignore
                obj = s.get(WorkOrderORM, work_order_id)  # type: ignore
                if obj:
                    for k,v in update_data.items():
                        if hasattr(obj, k):
                            setattr(obj, k, v)
                    s.commit()
        except Exception as e:  # pragma: no cover
            logger.error(f"Failed to update WO in DB {work_order_id}: {e}")
    
    logger.info(f"Work order updated: {work_order_id}")
    return work_order

@workorders_router.post("/{work_order_id}/start")
async def start_work_order(work_order_id: str, start_data: Dict[str, Any]) -> Dict:
    """Start work on a work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    work_order['status'] = 'in_progress'
    
    # Record status change
    status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
    status_entry = {
        "id": status_id,
        "work_order_id": work_order_id,
        "status": "in_progress",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_by": start_data.get("updated_by", work_order.get("assigned_to", "System")),
        "notes": "Work started"
    }
    work_order_status_history_db.append(status_entry)
    
    logger.info(f"Work order started: {work_order_id}")
    return {
        "work_order_id": work_order_id, 
        "status": "in_progress", 
        "started_at": datetime.now().isoformat(),
        "message": f"Work order {work_order_id} started successfully"
    }

@workorders_router.post("/{work_order_id}/complete")
async def complete_work_order(work_order_id: str, completion_data: Dict[str, Any]) -> Dict:
    """Complete a work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    work_order['status'] = 'completed'
    work_order['actual_hours'] = completion_data.get('actual_hours')
    work_order['cost'] = completion_data.get('cost')
    
    completion_date = datetime.now().strftime("%Y-%m-%d")
    
    # Record status change
    status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
    status_entry = {
        "id": status_id,
        "work_order_id": work_order_id,
        "status": "completed",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_by": completion_data.get("updated_by", work_order.get("assigned_to", "System")),
        "notes": completion_data.get("notes", "Work completed")
    }
    work_order_status_history_db.append(status_entry)
    
    # Add completion comment if notes provided
    if completion_data.get("notes"):
        comment_id = f"CMT-{len(work_order_comments_db) + 1:03d}"
        comment = {
            "id": comment_id,
            "work_order_id": work_order_id,
            "author": completion_data.get("updated_by", work_order.get("assigned_to", "System")),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "comment": f"Work completed: {completion_data['notes']}",
            "attachments": []
        }
        work_order_comments_db.append(comment)
    
    logger.info(f"Work order completed: {work_order_id}")
    return {
        "work_order_id": work_order_id,
        "status": "completed",
        "completion_date": completion_date,
        "actual_hours": completion_data.get('actual_hours'),
        "cost": completion_data.get('cost'),
        "message": f"Work order {work_order_id} completed successfully",
        "redirect": f"/cmms/workorders/{work_order_id}/view"
    }

@workorders_router.post("/{work_order_id}/comments")
async def add_work_order_comment(work_order_id: str, comment_data: Dict[str, Any]) -> Dict:
    """Add comment to work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    comment_id = f"CMT-{len(work_order_comments_db) + 1:03d}"
    comment = {
        "id": comment_id,
        "work_order_id": work_order_id,
        "author": comment_data.get("author", "System"),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "comment": comment_data.get("comment", comment_data.get("message", "")),
        "attachments": comment_data.get("attachments", [])
    }
    
    work_order_comments_db.append(comment)
    
    logger.info(f"Comment added to work order: {work_order_id}")
    return comment

# =============================================================================
# Technician Workspace API Endpoints (Phase 2)
# =============================================================================

@workorders_router.post("/{work_order_id}/time")
async def add_time_entry(work_order_id: str, time_data: TimeEntry) -> TimeEntryResponse:
    """Add time entry for a work order with start/pause/complete tracking"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # Generate unique ID for time entry
    entry_id = f"TE-{len(time_entries_db) + 1:03d}"
    
    # Calculate hours if not provided
    hours = time_data.hours
    if hours is None and time_data.start_time and time_data.end_time:
        time_diff = time_data.end_time - time_data.start_time
        hours = time_diff.total_seconds() / 3600
        if time_data.break_time_minutes:
            hours -= time_data.break_time_minutes / 60
    
    # Create time entry
    time_entry = {
        "id": entry_id,
        "technician_id": time_data.technician_id,
        "work_order_id": work_order_id,
        "pm_task_id": time_data.pm_task_id,
        "start_time": time_data.start_time,
        "end_time": time_data.end_time,
        "hours": hours or 0,
        "activity_type": time_data.activity_type,
        "description": time_data.description,
        "break_time_minutes": time_data.break_time_minutes,
        "created_at": datetime.now(),
        "updated_at": datetime.now()
    }
    
    time_entries_db.append(time_entry)
    
    # Update work order actual hours
    if work_order_id:
        total_hours = sum(te.get('hours', 0) for te in time_entries_db if te.get('work_order_id') == work_order_id)
        work_order['actual_hours'] = total_hours
    
    logger.info(f"Time entry added for work order {work_order_id}: {hours} hours")
    
    return TimeEntryResponse(**time_entry)

@workorders_router.post("/{work_order_id}/notes")
async def add_work_note(work_order_id: str, note_data: WorkNote) -> WorkNoteResponse:
    """Add voice note or manual text note to work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # Generate unique ID for work note
    note_id = f"WN-{len(work_notes_db) + 1:03d}"
    
    # Create work note
    work_note = {
        "id": note_id,
        "work_order_id": work_order_id,
        "author": note_data.author,
        "content": note_data.content,
        "note_type": note_data.note_type,
        "audio_duration_seconds": note_data.audio_duration_seconds,
        "confidence_score": note_data.confidence_score,
        "created_at": datetime.now(),
        "updated_at": datetime.now()
    }
    
    work_notes_db.append(work_note)
    
    # Also add to work order comments for backward compatibility
    comment = {
        "id": f"CMT-{len(work_order_comments_db) + 1:03d}",
        "work_order_id": work_order_id,
        "author": note_data.author,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "comment": f"[{note_data.note_type.title()}] {note_data.content}",
        "attachments": []
    }
    work_order_comments_db.append(comment)
    
    logger.info(f"Work note added for work order {work_order_id}: {note_data.note_type}")
    
    return WorkNoteResponse(**work_note)

@workorders_router.post("/{work_order_id}/photos")
async def upload_work_photos(work_order_id: str, photos: List[UploadFile] = File(...)) -> List[PhotoUploadResponse]:
    """Upload photos for work order with metadata"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    uploaded_photos = []
    
    for photo in photos:
        # Validate file type
        if not photo.content_type or not photo.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail=f"File {photo.filename} is not an image")
        
        # Generate unique ID for photo
        photo_id = f"PH-{len(photo_uploads_db) + 1:03d}"
        
        # Mock file processing (in real implementation, save to storage)
        file_size = len(await photo.read())
        await photo.seek(0)  # Reset file pointer
        
        # Create photo upload record
        photo_upload = {
            "id": photo_id,
            "work_order_id": work_order_id,
            "filename": photo.filename,
            "file_size_bytes": file_size,
            "mime_type": photo.content_type,
            "caption": None,
            "photo_type": "other",
            "gps_latitude": None,
            "gps_longitude": None,
            "thumbnail_url": f"/api/photos/{photo_id}/thumbnail",
            "full_url": f"/api/photos/{photo_id}/full",
            "uploaded_by": "current_user",  # Should get from auth context
            "created_at": datetime.now()
        }
        
        photo_uploads_db.append(photo_upload)
        uploaded_photos.append(PhotoUploadResponse(**photo_upload))
    
    logger.info(f"Uploaded {len(photos)} photos for work order {work_order_id}")
    
    return uploaded_photos

@workorders_router.post("/{work_order_id}/parts")
async def checkout_parts(work_order_id: str, parts_data: PartsCheckout) -> PartsCheckoutResponse:
    """Checkout parts for work order with inventory validation"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # TODO: Add real inventory validation with part.py integration
    # For now, mock validation
    total_value = 0.0
    validated_parts = []
    
    for part in parts_data.parts:
        part_id = part.get('part_id')
        quantity = part.get('quantity')
        
        # Mock part lookup and validation
        part_info = {
            "part_id": part_id,
            "quantity": quantity,
            "unit_cost": 25.50,  # Mock price
            "description": f"Part {part_id}",
            "available_quantity": 100  # Mock availability
        }
        
        if quantity > part_info['available_quantity']:
            raise HTTPException(
                status_code=400, 
                detail=f"Insufficient inventory for part {part_id}: requested {quantity}, available {part_info['available_quantity']}"
            )
        
        part_total = quantity * part_info['unit_cost']
        total_value += part_total
        
        validated_parts.append({
            **part_info,
            "total_cost": part_total
        })
    
    # Generate unique ID for checkout
    checkout_id = f"PC-{len(parts_checkouts_db) + 1:03d}"
    
    # Create parts checkout record
    parts_checkout = {
        "id": checkout_id,
        "work_order_id": work_order_id,
        "technician_id": parts_data.technician_id,
        "parts_checked_out": validated_parts,
        "checkout_notes": parts_data.checkout_notes,
        "total_value": total_value,
        "checkout_by": parts_data.technician_id,
        "checkout_at": datetime.now(),
        "returned_at": None
    }
    
    parts_checkouts_db.append(parts_checkout)
    
    logger.info(f"Parts checked out for work order {work_order_id}: {len(validated_parts)} parts, ${total_value:.2f}")
    
    return PartsCheckoutResponse(**parts_checkout)

@workorders_router.get("/reports/summary")
async def get_work_orders_summary() -> Dict:
    """Get work orders summary report"""
    total_work_orders = len(work_orders_db)
    
    # Status breakdown
    status_breakdown = {}
    for wo in work_orders_db:
        status = wo['status']
        status_breakdown[status] = status_breakdown.get(status, 0) + 1
    
    # Priority breakdown
    priority_breakdown = {}
    for wo in work_orders_db:
        priority = wo['priority']
        priority_breakdown[priority] = priority_breakdown.get(priority, 0) + 1
    
    # Type breakdown
    type_breakdown = {}
    for wo in work_orders_db:
        wo_type = wo['type']
        type_breakdown[wo_type] = type_breakdown.get(wo_type, 0) + 1
    
    # Calculate metrics
    completed_work_orders = [wo for wo in work_orders_db if wo['status'] == 'completed']
    total_actual_hours = sum(wo.get('actual_hours', 0) for wo in completed_work_orders)
    total_estimated_hours = sum(wo.get('estimated_hours', 0) for wo in completed_work_orders if wo.get('estimated_hours'))
    total_cost = sum(wo.get('cost', 0) for wo in completed_work_orders)
    
    # On-time completion
    on_time_completed = 0
    for wo in completed_work_orders:
        if wo.get('due_date'):
            # Simplified check - in real implementation would compare completion date to due date
            on_time_completed += 1
    
    on_time_rate = (on_time_completed / len(completed_work_orders) * 100) if completed_work_orders else 0
    
    return {
        "total_work_orders": total_work_orders,
        "status_breakdown": status_breakdown,
        "priority_breakdown": priority_breakdown,
        "type_breakdown": type_breakdown,
        "metrics": {
            "completion_rate": len(completed_work_orders) / total_work_orders * 100 if total_work_orders else 0,
            "on_time_rate": on_time_rate,
            "average_actual_hours": total_actual_hours / len(completed_work_orders) if completed_work_orders else 0,
            "hours_variance": ((total_actual_hours - total_estimated_hours) / total_estimated_hours * 100) if total_estimated_hours else 0,
            "total_cost": total_cost,
            "average_cost_per_wo": total_cost / len(completed_work_orders) if completed_work_orders else 0
        },
        "trends": {
            "monthly_wo_count": [45, 52, 38, 61, 47, 55],  # Mock data
            "completion_time_trend": [3.2, 2.8, 3.1, 2.5, 2.3, 2.7],  # Days
            "cost_trend": [250, 280, 310, 265, 290, 275]  # Average cost
        },
        "generated_at": datetime.now().isoformat()
    }

@workorders_router.get("/calendar", response_class=HTMLResponse)
async def calendar_view():
    """Work Orders Calendar View with KPI overlays"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Work Orders Calendar</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; text-decoration: none; display: inline-block; }}
            .calendar-grid {{ display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; }}
            .day-cell {{ background: #edf2f7; min-height: 120px; padding: 4px; border-radius: 4px; position: relative; font-size: 0.75rem; }}
            .day-number {{ font-weight: 600; color: #2d3748; }}
            .wo-pill {{ display: block; padding: 2px 4px; border-radius: 3px; margin: 2px 0; font-size: 0.65rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
            .legend {{ display: flex; gap: 1rem; font-size: 0.75rem; }}
            .legend span {{ display: inline-flex; align-items: center; gap: 4px; }}
            .filter-bar {{ display:flex; gap:1rem; flex-wrap:wrap; margin-bottom:1rem; }}
            .filter-bar select {{ padding:0.4rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📅 Work Orders Calendar</h1>
            <p>Schedule and timeline view of work orders</p>
        </div>
        <div class="container">
            <div class="card">
              <div class="filter-bar">
                 <select id=priorityFilter onchange="renderCalendar()">
                    <option value="">All Priorities</option>
                    <option value="urgent">Urgent</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                 </select>
                 <select id=statusFilter onchange="renderCalendar()">
                    <option value="">All Status</option>
                    <option value="open">Open</option>
                    <option value="assigned">Assigned</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                 </select>
                 <button class="btn" onclick="changeMonth(-1)">◀ Prev</button>
                 <div id=currentMonth style="font-weight:600; padding:0.5rem 1rem;"></div>
                 <button class="btn" onclick="changeMonth(1)">Next ▶</button>
                 <a href="/cmms/workorders/dashboard" class="btn">↩ Dashboard</a>
              </div>
              <div class="legend" style="margin-bottom:0.5rem;">
                 <span><span style="width:12px;height:12px;background:#e53e3e;border-radius:2px;"></span> Urgent</span>
                 <span><span style="width:12px;height:12px;background:#d69e2e;border-radius:2px;"></span> High</span>
                 <span><span style="width:12px;height:12px;background:#38a169;border-radius:2px;"></span> Medium</span>
                 <span><span style="width:12px;height:12px;background:#4299e1;border-radius:2px;"></span> Low</span>
              </div>
              <div id=calendarGrid class="calendar-grid"></div>
            </div>
        </div>
        <script>
           let current = new Date();
           let workOrders = [];
           async function loadData() {
              const res = await fetch('/cmms/workorders/calendar?start_date=1970-01-01&end_date=2100-01-01');
              workOrders = await res.json();
              renderCalendar();
           }
           function changeMonth(delta){
              current.setMonth(current.getMonth()+delta);
              renderCalendar();
           }
           function renderCalendar(){
              const grid = document.getElementById('calendarGrid');
              const monthStart = new Date(current.getFullYear(), current.getMonth(),1);
              const nextMonth = new Date(current.getFullYear(), current.getMonth()+1,1);
              const daysInMonth = Math.round((nextMonth - monthStart)/86400000);
              const firstDow = monthStart.getDay();
              document.getElementById('currentMonth').innerText = monthStart.toLocaleString('default',{month:'long', year:'numeric'});
              grid.innerHTML='';
              for(let i=0;i<firstDow;i++){ grid.appendChild(document.createElement('div')); }
              const priFilter = document.getElementById('priorityFilter').value;
              const statusFilter = document.getElementById('statusFilter').value;
              for(let day=1; day<=daysInMonth; day++){
                  const cell = document.createElement('div');
                  cell.className='day-cell';
                  const dateStr = `${current.getFullYear()}-${String(current.getMonth()+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
                  cell.innerHTML = `<div class='day-number'>${day}</div>`;
                  workOrders.filter(w=>w.start===dateStr && (!priFilter || w.priority===priFilter) && (!statusFilter || w.status===statusFilter)).forEach(w=>{
                  const todays = workOrders.filter(w=>w.start===dateStr && (!priFilter || w.priority===priFilter) && (!statusFilter || w.status===statusFilter));
                  let urgentCnt=0, overdueCnt=0, slaBreach=0; const todayObj = new Date(dateStr); const now = new Date();
                  todays.forEach(w=>{ if(w.priority==='urgent') urgentCnt++; if(w.status!=='completed' && todayObj<now && w.start < now.toISOString().slice(0,10)) overdueCnt++; if(w.priority==='urgent' && todayObj<now) slaBreach++; });
                  if(urgentCnt||overdueCnt||slaBreach){ const wrap=document.createElement('div'); wrap.className='overlay-badges'; if(urgentCnt){const b=document.createElement('span'); b.className='badge u'; b.title='Urgent'; b.textContent=urgentCnt; wrap.appendChild(b);} if(overdueCnt){const b=document.createElement('span'); b.className='badge o'; b.title='Overdue'; b.textContent=overdueCnt; wrap.appendChild(b);} if(slaBreach){const b=document.createElement('span'); b.className='badge b'; b.title='SLA'; b.textContent=slaBreach; wrap.appendChild(b);} cell.appendChild(wrap);} 
                      const pill = document.createElement('a');
                      pill.className='wo-pill';
                      pill.href=`/cmms/workorders/${w.id}/view`;
                      pill.style.background=w.color;
                      pill.style.color='#fff';
                      pill.title = w.title;
                      pill.textContent = `${w.id} ${w.title.substring(0,12)}`;
                      cell.appendChild(pill);
                  });
                  grid.appendChild(cell);
              }
           }
           loadData();
        </script>
    </body>
    </html>
    """

@workorders_router.get("/{work_order_id}/view", response_class=HTMLResponse)
async def view_work_order_page(work_order_id: str):
    """Display a single work order in a full HTML page."""
    try:
        wo_details = await get_work_order_details(work_order_id)
        wo = wo_details['work_order']
        comments = wo_details['comments']
        status_history = wo_details['status_history']
        metrics = wo_details['metrics']

        # Helper to generate comment HTML
        def generate_comments_html(comments):
            if not comments:
                return "<p>No comments yet.</p>"
            html = ""
            for comment in sorted(comments, key=lambda x: x['timestamp'], reverse=True):
                html += f"""
                <div class="comment-card">
                    <div class="comment-header">
                        <strong>{comment['author']}</strong>
                        <span class="timestamp">{comment['timestamp']}</span>
                    </div>
                    <p>{comment['comment']}</p>
                    {'<p>Attachments: ' + ', '.join(comment['attachments']) + '</p>' if comment['attachments'] else ''}
                </div>
                """
            return html

        # Helper to generate status history HTML
        def generate_status_history_html(status_history):
            if not status_history:
                return "<p>No status history.</p>"
            html = "<ul>"
            for status in sorted(status_history, key=lambda x: x['timestamp']):
                html += f"<li><strong>{status['status'].replace('_', ' ').title()}</strong> at {status['timestamp']} by {status['updated_by']} - <em>{status['notes']}</em></li>"
            html += "</ul>"
            return html

        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Work Order {wo['id']}</title>
            <style>
                /* Using the same styles from the dashboard for consistency */
                body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; color: #2d3748; }}
                .header {{ background: #2d3748; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }}
                .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
                .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 2rem; }}
                .grid {{ display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; }}
                h1, h2, h3 {{ color: #1a202c; }}
                .wo-title {{ font-size: 2.5rem; margin-bottom: 0.5rem; }}
                .status-badge {{ padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 1rem; font-weight: 600; display: inline-block; }}
                .status-open {{ background: #e2e8f0; color: #4a5568; }}
                .status-assigned {{ background: #bee3f8; color: #2b6cb0; }}
                .status-in_progress {{ background: #c6f6d5; color: #276749; }}
                .status-completed {{ background: #c6f6d5; color: #276749; }}
                .status-parts_required {{ background: #fef5e7; color: #d69e2e; }}
                .priority-urgent {{ color: #e53e3e; }}
                .priority-high {{ color: #d69e2e; }}
                .priority-medium {{ color: #38a169; }}
                .priority-low {{ color: #a0aec0; }}
                .details-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1.5rem; }}
                .detail-item {{ background: #edf2f7; padding: 1rem; border-radius: 4px; }}
                .detail-item strong {{ display: block; font-size: 0.8rem; color: #718096; margin-bottom: 0.25rem; }}
                .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }}
                .btn-warning {{ background: #d69e2e; }}
                .btn-success {{ background: #38a169; }}
                .comment-card {{ border: 1px solid #e2e8f0; border-radius: 4px; padding: 1rem; margin-bottom: 1rem; }}
                .comment-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }}
                .timestamp {{ font-size: 0.8rem; color: #718096; }}
                #ai-assistant {{ margin-top: 1rem; }}
                #ai-input {{ width: calc(100% - 110px); padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px; }}
                #ai-submit {{ padding: 0.5rem 1rem; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>ChatterFix CMMS</h1>
                <a href="/cmms/workorders/dashboard" class="btn">Back to Dashboard</a>
            </div>
            <div class="container">
                <div class="card">
                    <h1 class="wo-title">{wo['title']}</h1>
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem;">
                        <span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span>
                        <span class="priority-{wo['priority']}"><strong>Priority:</strong> {wo['priority'].title()}</span>
                    </div>
                    <p>{wo['description']}</p>
                </div>

                <div class="grid">
                    <div class="main-content">
                        <div class="card">
                            <h2>Work Order Details</h2>
                            <div class="details-grid">
                                <div class="detail-item"><strong>Work Order ID</strong> {wo['id']}</div>
                                <div class="detail-item"><strong>Asset ID</strong> <a href="/cmms/assets/{wo['asset_id']}/view">{wo['asset_id']}</a></div>
                                <div class="detail-item"><strong>Work Order Type</strong> {wo['type'].title()}</div>
                                <div class="detail-item"><strong>Created Date</strong> {wo['created_date']}</div>
                                <div class="detail-item"><strong>Created By</strong> {wo['created_by']}</div>
                                <div class="detail-item"><strong>Assigned To</strong> {wo.get('assigned_to', 'Unassigned')}</div>
                                <div class="detail-item"><strong>Due Date</strong> {wo.get('due_date', 'Not set')}</div>
                                <div class="detail-item"><strong>Estimated Hours</strong> {wo.get('estimated_hours', 'N/A')}</div>
                                <div class="detail-item"><strong>Actual Hours</strong> {wo.get('actual_hours', 'N/A')}</div>
                                <div class="detail-item"><strong>Cost</strong> ${wo.get('cost', 0.00):.2f}</div>
                            </div>
                        </div>

                        <div class="card">
                            <h2>Comments & AI Assistant</h2>
                            <div id="comments-section">
                                {generate_comments_html(comments)}
                            </div>
                            <div id="ai-assistant">
                                <h4>AI Assistant (Voice & Text)</h4>
                                <textarea id="ai-input" placeholder="Type or use voice to add a comment, ask for help, or find parts..."></textarea>
                                <button id="ai-submit" class="btn">Submit</button>
                                <button id="voice-input" class="btn">🎤</button>
                            </div>
                        </div>
                    </div>
                    <div class="sidebar">
                        <div class="card">
                            <h2>Actions</h2>
                            <button id="open-technician-workspace" class="btn btn-primary" style="display: block; margin-bottom: 1rem; text-align: center; width: 100%;">🔧 Technician Workspace</button>
                            <a href="#" class="btn btn-warning" style="display: block; margin-bottom: 1rem; text-align: center;">Edit Work Order</a>
                            <a href="#" class="btn btn-success" style="display: block; text-align: center;">Complete Work Order</a>
                        </div>
                        <div class="card">
                            <h2>Status History</h2>
                            {generate_status_history_html(status_history)}
                        </div>
                        <div class="card">
                            <h2>Metrics</h2>
                            <p><strong>Days Open:</strong> {metrics['days_open']}</p>
                            <p><strong>On Schedule:</strong> {'Yes' if metrics['on_schedule'] else 'No'}</p>
                            <p><strong>Hours Variance:</strong> {metrics['estimated_vs_actual']['variance_percent']:.2f}%</p>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                // Voice to text functionality
                const voiceInputBtn = document.getElementById('voice-input');
                const aiInput = document.getElementById('ai-input');
                const aiSubmitBtn = document.getElementById('ai-submit');

                if ('webkitSpeechRecognition' in window) {{
                    const recognition = new webkitSpeechRecognition();
                    recognition.continuous = false;
                    recognition.interimResults = false;
                    recognition.lang = 'en-US';

                    voiceInputBtn.addEventListener('click', () => {{
                        recognition.start();
                        voiceInputBtn.textContent = '🔴';
                    }});

                    recognition.onresult = (event) => {{
                        const transcript = event.results[0][0].transcript;
                        aiInput.value = transcript;
                        // Optionally submit automatically
                        // submitAiInteraction(transcript); 
                    }};

                    recognition.onerror = (event) => {{
                        console.error('Speech recognition error:', event.error);
                        alert('Error in speech recognition: ' + event.error);
                    }};

                    recognition.onend = () => {{
                        voiceInputBtn.textContent = '🎤';
                    }};
                }} else {{
                    voiceInputBtn.style.display = 'none';
                    // alert('Speech recognition not supported in this browser.');
                }}

                aiSubmitBtn.addEventListener('click', () => {{
                    const text = aiInput.value;
                    if (text) {{
                        submitAiInteraction(text);
                    }}
                }});

                function submitAiInteraction(text) {{
                    console.log('Submitting to AI:', text);
                    // Here you would call your AI backend
                    // For now, we'll just add it as a comment
                    fetch(`/cmms/workorders/{wo['id']}/comments`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            author: 'AI Assistant', // Or the logged in user
                            comment: '(AI Interaction) ' + text
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Comment added:', data);
                        location.reload(); // Simple refresh to show new comment
                    }});
                }}
                
                // Technician Workspace Modal
                const techWorkspaceModal = document.createElement('div');
                techWorkspaceModal.id = 'technician-workspace-modal';
                techWorkspaceModal.innerHTML = `
                    <div class="modal-overlay" onclick="closeTechWorkspace()">
                        <div class="modal-content technician-workspace" onclick="event.stopPropagation()">
                            <div class="workspace-header">
                                <h2>🔧 Technician Workspace - {wo['id']}</h2>
                                <button onclick="closeTechWorkspace()" class="close-btn">×</button>
                            </div>
                            <div class="workspace-tabs">
                                <button class="tab-btn active" data-tab="timer">⏱️ Time</button>
                                <button class="tab-btn" data-tab="notes">📝 Notes</button>
                                <button class="tab-btn" data-tab="photos">📸 Photos</button>
                                <button class="tab-btn" data-tab="parts">🔧 Parts</button>
                            </div>
                            
                            <!-- Timer Tab -->
                            <div class="tab-content active" id="timer-tab">
                                <div class="timer-section">
                                    <div class="timer-display">
                                        <span id="timer-hours">00</span>:<span id="timer-minutes">00</span>:<span id="timer-seconds">00</span>
                                    </div>
                                    <div class="timer-controls">
                                        <button id="start-timer" class="btn btn-success">▶️ Start</button>
                                        <button id="pause-timer" class="btn btn-warning" disabled>⏸️ Pause</button>
                                        <button id="stop-timer" class="btn btn-danger" disabled>⏹️ Complete</button>
                                    </div>
                                    <div class="manual-time">
                                        <h4>Manual Time Entry</h4>
                                        <input type="number" id="manual-hours" placeholder="Hours" step="0.25" min="0" max="24">
                                        <input type="text" id="activity-description" placeholder="Description of work performed">
                                        <button id="add-time" class="btn">Add Time</button>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Notes Tab -->
                            <div class="tab-content" id="notes-tab">
                                <div class="notes-section">
                                    <div class="voice-recording">
                                        <button id="voice-record-btn" class="btn btn-primary">🎤 Voice Note</button>
                                        <span id="recording-status"></span>
                                    </div>
                                    <textarea id="manual-note" placeholder="Type your note here..." rows="4"></textarea>
                                    <button id="add-note" class="btn">Add Note</button>
                                    <div id="notes-list"></div>
                                </div>
                            </div>
                            
                            <!-- Photos Tab -->
                            <div class="tab-content" id="photos-tab">
                                <div class="photos-section">
                                    <div class="photo-upload">
                                        <input type="file" id="photo-input" accept="image/*" multiple capture="environment">
                                        <button onclick="document.getElementById('photo-input').click()" class="btn">📸 Take Photo</button>
                                        <select id="photo-type">
                                            <option value="before">Before Work</option>
                                            <option value="during">During Work</option>
                                            <option value="after">After Work</option>
                                            <option value="damage">Damage</option>
                                            <option value="completion">Completion</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                    <div id="photo-preview"></div>
                                    <div id="uploaded-photos"></div>
                                </div>
                            </div>
                            
                            <!-- Parts Tab -->
                            <div class="tab-content" id="parts-tab">
                                <div class="parts-section">
                                    <div class="parts-checkout">
                                        <h4>Parts Checkout</h4>
                                        <div class="part-entry">
                                            <input type="text" id="part-id" placeholder="Part ID/Number">
                                            <input type="number" id="part-quantity" placeholder="Qty" min="1">
                                            <button id="add-part" class="btn">Add Part</button>
                                        </div>
                                        <div id="selected-parts"></div>
                                        <button id="checkout-parts" class="btn btn-success" disabled>Checkout Parts</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                // Add modal styles
                const modalStyles = `
                    <style>
                    .modal-overlay {
                        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                        background: rgba(0,0,0,0.7); display: none; z-index: 1000;
                        align-items: center; justify-content: center;
                    }
                    .modal-overlay.show { display: flex; }
                    .technician-workspace {
                        background: white; border-radius: 12px; width: 90%; max-width: 800px;
                        max-height: 90vh; overflow: hidden; display: flex; flex-direction: column;
                    }
                    .workspace-header {
                        background: #2d3748; color: white; padding: 1rem 2rem;
                        display: flex; justify-content: space-between; align-items: center;
                    }
                    .close-btn {
                        background: none; border: none; color: white; font-size: 1.5rem; cursor: pointer;
                    }
                    .workspace-tabs {
                        display: flex; border-bottom: 1px solid #e2e8f0;
                    }
                    .tab-btn {
                        flex: 1; padding: 1rem; border: none; background: #f7fafc;
                        cursor: pointer; border-bottom: 3px solid transparent;
                    }
                    .tab-btn.active { background: white; border-bottom-color: #4299e1; }
                    .tab-content {
                        display: none; padding: 2rem; flex: 1; overflow-y: auto;
                    }
                    .tab-content.active { display: block; }
                    .timer-display {
                        font-size: 3rem; font-weight: bold; text-align: center;
                        margin: 1rem 0; color: #4299e1;
                    }
                    .timer-controls {
                        display: flex; gap: 1rem; justify-content: center; margin-bottom: 2rem;
                    }
                    .manual-time {
                        border-top: 1px solid #e2e8f0; padding-top: 1rem;
                    }
                    .manual-time input { margin: 0.5rem; padding: 0.5rem; }
                    .voice-recording { margin-bottom: 1rem; }
                    #recording-status { margin-left: 1rem; color: #e53e3e; }
                    .photo-upload { display: flex; gap: 1rem; align-items: center; margin-bottom: 1rem; }
                    .part-entry { display: flex; gap: 1rem; margin-bottom: 1rem; }
                    .part-entry input { flex: 1; padding: 0.5rem; }
                    #selected-parts { border: 1px solid #e2e8f0; padding: 1rem; margin: 1rem 0; min-height: 100px; }
                    .btn-primary { background: #4299e1; }
                    .btn-success { background: #38a169; }
                    .btn-warning { background: #d69e2e; }
                    .btn-danger { background: #e53e3e; }
                    .btn:disabled { background: #a0aec0; cursor: not-allowed; }
                    
                    @media (max-width: 768px) {{
                        .technician-workspace {{ width: 95%; max-width: none; }}
                        .workspace-tabs {{ flex-direction: column; }}
                        .tab-btn {{ border-right: none; border-bottom: 1px solid #e2e8f0; }}
                        .timer-display {{ font-size: 2rem; }}
                        .timer-controls {{ flex-direction: column; }}
                        .photo-upload, .part-entry {{ flex-direction: column; }}
                    }}
                    </style>
                `;
                
                document.head.insertAdjacentHTML('beforeend', modalStyles);
                document.body.appendChild(techWorkspaceModal);
                
                // Workspace JavaScript functionality
                let timerInterval;
                let startTime;
                let elapsedTime = 0;
                let isRunning = false;
                let selectedParts = [];
                
                // Tab switching
                document.querySelectorAll('.tab-btn').forEach(btn => {{
                    btn.addEventListener('click', () => {{
                        const tab = btn.dataset.tab;
                        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                        btn.classList.add('active');
                        document.getElementById(tab + '-tab').classList.add('active');
                    }});
                }});
                
                // Timer functionality
                function updateTimerDisplay() {{
                    const totalSeconds = Math.floor(elapsedTime / 1000);
                    const hours = Math.floor(totalSeconds / 3600);
                    const minutes = Math.floor((totalSeconds % 3600) / 60);
                    const seconds = totalSeconds % 60;
                    
                    document.getElementById('timer-hours').textContent = hours.toString().padStart(2, '0');
                    document.getElementById('timer-minutes').textContent = minutes.toString().padStart(2, '0');
                    document.getElementById('timer-seconds').textContent = seconds.toString().padStart(2, '0');
                }}
                
                document.getElementById('start-timer').addEventListener('click', () => {{
                    if (!isRunning) {{
                        startTime = Date.now() - elapsedTime;
                        timerInterval = setInterval(() => {{
                            elapsedTime = Date.now() - startTime;
                            updateTimerDisplay();
                        }}, 1000);
                        isRunning = true;
                        document.getElementById('start-timer').disabled = true;
                        document.getElementById('pause-timer').disabled = false;
                        document.getElementById('stop-timer').disabled = false;
                    }}
                }});
                
                document.getElementById('pause-timer').addEventListener('click', () => {{
                    if (isRunning) {{
                        clearInterval(timerInterval);
                        isRunning = false;
                        document.getElementById('start-timer').disabled = false;
                        document.getElementById('pause-timer').disabled = true;
                    }}
                }});
                
                document.getElementById('stop-timer').addEventListener('click', () => {{
                    clearInterval(timerInterval);
                    const hours = elapsedTime / (1000 * 60 * 60);
                    
                    // Submit time entry
                    fetch(`/cmms/workorders/{wo['id']}/time`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            technician_id: 'TECH-001',
                            start_time: new Date(Date.now() - elapsedTime).toISOString(),
                            end_time: new Date().toISOString(),
                            hours: hours,
                            activity_type: 'work_order',
                            description: 'Timer-tracked work session'
                        }})
                    }}).then(() => {{
                        alert(`Time logged: ${{hours.toFixed(2)}} hours`);
                        // Reset timer
                        elapsedTime = 0;
                        isRunning = false;
                        updateTimerDisplay();
                        document.getElementById('start-timer').disabled = false;
                        document.getElementById('pause-timer').disabled = true;
                        document.getElementById('stop-timer').disabled = true;
                    }});
                }});
                
                // Manual time entry
                document.getElementById('add-time').addEventListener('click', () => {{
                    const hours = parseFloat(document.getElementById('manual-hours').value);
                    const description = document.getElementById('activity-description').value;
                    
                    if (!hours || !description) {{
                        alert('Please enter both hours and description');
                        return;
                    }}
                    
                    fetch(`/cmms/workorders/{wo['id']}/time`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            technician_id: 'TECH-001',
                            hours: hours,
                            activity_type: 'work_order',
                            description: description
                        }})
                    }}).then(() => {{
                        alert(`Manual time entry added: ${{hours}} hours`);
                        document.getElementById('manual-hours').value = '';
                        document.getElementById('activity-description').value = '';
                    }});
                }});
                
                // Add note
                document.getElementById('add-note').addEventListener('click', () => {{
                    const content = document.getElementById('manual-note').value;
                    if (!content) {{
                        alert('Please enter a note');
                        return;
                    }}
                    
                    fetch(`/cmms/workorders/{wo['id']}/notes`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            author: 'TECH-001',
                            content: content,
                            note_type: 'manual_text'
                        }})
                    }}).then(() => {{
                        alert('Note added successfully');
                        document.getElementById('manual-note').value = '';
                        location.reload();
                    }});
                }});
                
                // Photo upload
                document.getElementById('photo-input').addEventListener('change', (event) => {{
                    const files = Array.from(event.target.files);
                    const formData = new FormData();
                    
                    files.forEach(file => formData.append('photos', file));
                    
                    fetch(`/cmms/workorders/{wo['id']}/photos`, {{
                        method: 'POST',
                        body: formData
                    }}).then(response => response.json())
                    .then(photos => {{
                        alert(`Uploaded ${{photos.length}} photos successfully`);
                        const photoDiv = document.getElementById('uploaded-photos');
                        photos.forEach(photo => {{
                            photoDiv.innerHTML += `<div>📸 ${{photo.filename}}</div>`;
                        }});
                    }});
                }});
                
                // Parts management
                document.getElementById('add-part').addEventListener('click', () => {{
                    const partId = document.getElementById('part-id').value;
                    const quantity = parseInt(document.getElementById('part-quantity').value);
                    
                    if (!partId || !quantity) {{
                        alert('Please enter part ID and quantity');
                        return;
                    }}
                    
                    selectedParts.push({{ part_id: partId, quantity: quantity }});
                    
                    const partsDiv = document.getElementById('selected-parts');
                    partsDiv.innerHTML += `<div>${{partId}} x${{quantity}} <button onclick="removePart('${{partId}}')">Remove</button></div>`;
                    
                    document.getElementById('part-id').value = '';
                    document.getElementById('part-quantity').value = '';
                    document.getElementById('checkout-parts').disabled = selectedParts.length === 0;
                }});
                
                // Remove part function
                window.removePart = (partId) => {{
                    selectedParts = selectedParts.filter(p => p.part_id !== partId);
                    const partsDiv = document.getElementById('selected-parts');
                    partsDiv.innerHTML = '';
                    selectedParts.forEach(part => {{
                        partsDiv.innerHTML += `<div>${{part.part_id}} x${{part.quantity}} <button onclick="removePart('${{part.part_id}}')">Remove</button></div>`;
                    }});
                    document.getElementById('checkout-parts').disabled = selectedParts.length === 0;
                }};
                
                // Checkout parts
                document.getElementById('checkout-parts').addEventListener('click', () => {{
                    if (selectedParts.length === 0) return;
                    
                    fetch(`/cmms/workorders/{wo['id']}/parts`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            technician_id: 'TECH-001',
                            parts: selectedParts,
                            checkout_notes: 'Field checkout via workspace'
                        }})
                    }}).then(response => response.json())
                    .then(data => {{
                        alert(`Parts checked out successfully. Total value: $${{data.total_value.toFixed(2)}}`);
                        selectedParts = [];
                        document.getElementById('selected-parts').innerHTML = '';
                        document.getElementById('checkout-parts').disabled = true;
                    }});
                }});
                
                // Voice recording (simplified - would integrate with Web Speech API)
                document.getElementById('voice-record-btn').addEventListener('click', () => {{
                    if ('webkitSpeechRecognition' in window) {{
                        const recognition = new webkitSpeechRecognition();
                        recognition.continuous = false;
                        recognition.interimResults = false;
                        recognition.lang = 'en-US';
                        
                        recognition.onstart = () => {{
                            document.getElementById('recording-status').textContent = 'Listening...';
                            document.getElementById('voice-record-btn').textContent = '🔴 Listening...';
                        }};
                        
                        recognition.onresult = (event) => {{
                            const transcript = event.results[0][0].transcript;
                            document.getElementById('manual-note').value = transcript;
                        }};
                        
                        recognition.onend = () => {{
                            document.getElementById('recording-status').textContent = '';
                            document.getElementById('voice-record-btn').textContent = '🎤 Voice Note';
                        }};
                        
                        recognition.start();
                    }} else {{
                        alert('Speech recognition not supported in this browser');
                    }}
                }});
                
                // Open workspace modal
                document.getElementById('open-technician-workspace').addEventListener('click', () => {{
                    document.getElementById('technician-workspace-modal').querySelector('.modal-overlay').classList.add('show');
                }});
                
                // Close workspace modal
                window.closeTechWorkspace = () => {{
                    document.getElementById('technician-workspace-modal').querySelector('.modal-overlay').classList.remove('show');
                }};
                
                updateTimerDisplay();
                
                // Register service worker for offline support
                if ('serviceWorker' in navigator) {{
                    navigator.serviceWorker.register('/static/js/sw.js')
                        .then(registration => {{
                            console.log('🎯 Technician Workspace: Service Worker registered', registration);
                        }})
                        .catch(error => {{
                            console.error('❌ Technician Workspace: Service Worker registration failed', error);
                        }});
                }}
                
                // Handle service worker messages for offline sync
                if ('serviceWorker' in navigator) {{
                    navigator.serviceWorker.addEventListener('message', event => {{
                        const {{ type, action, submission }} = event.data;
                        
                        switch (type) {{
                            case 'STORE_WORKSPACE_ACTION':
                                // Store workspace action in IndexedDB for offline sync
                                console.log('📱 Storing workspace action offline:', action);
                                // Integration with offline-sync.js would go here
                                break;
                                
                            case 'WORKSPACE_ACTION_ONLINE':
                                console.log('🌐 Workspace action synced online');
                                break;
                        }}
                    }});
                }}
            </script>
        </body>
        </html>
        """
    except HTTPException as e:
        return f"<h1>Error</h1><p>Could not find work order with ID {work_order_id}.</p><p>{e.detail}</p>"

# Missing GET routes for forms

@workorders_router.get("/{work_order_id}/complete", response_class=HTMLResponse)
async def complete_work_order_form(work_order_id: str):
    """Work order completion form"""
    wo = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not wo:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    nav_html = get_navigation_html("workorders")
    nav_styles = get_navigation_styles()
    nav_js = get_navigation_javascript()
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Complete Work Order: {wo['title']} - ChatterFix CMMS</title>
        <!-- CMMS CSS links -->
        <style>
            {nav_styles}
            {get_base_styles()}
            .completion-container {{ max-width: 800px; margin: 2rem auto; padding: 0 2rem; }}
            .wo-summary {{ background: #f7fafc; border-left: 4px solid #4299e1; padding: 1.5rem; margin-bottom: 2rem; border-radius: 0 8px 8px 0; }}
            .completion-form {{ background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
            .status-badge {{ padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.875rem; font-weight: 600; }}
            .status-in_progress {{ background: #fef5e7; color: #c05621; }}
            .priority-badge {{ padding: 0.25rem 0.75rem; border-radius: 4px; font-size: 0.875rem; font-weight: 600; }}
            .priority-critical {{ background: #fed7d7; color: #c53030; }}
            .priority-high {{ background: #feebc8; color: #dd6b20; }}
            .priority-medium {{ background: #e6fffa; color: #2c7a7b; }}
            .priority-low {{ background: #f0fff4; color: #38a169; }}
        </style>
    </head>
    <body>
        {nav_html}
        
        <div class="completion-container">
            <h1 style="color: #2d3748; margin-bottom: 2rem;">🏁 Complete Work Order</h1>
            
            <div class="wo-summary">
                <h3 style="margin: 0 0 1rem 0; color: #2d3748;">{wo['title']} ({work_order_id})</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div><strong>Asset:</strong> {wo['asset_id']}</div>
                    <div><strong>Status:</strong> <span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span></div>
                    <div><strong>Priority:</strong> <span class="priority-badge priority-{wo['priority']}">{wo['priority'].title()}</span></div>
                    <div><strong>Assigned to:</strong> {wo.get('assigned_to', 'Unassigned')}</div>
                    <div><strong>Estimated Hours:</strong> {wo.get('estimated_hours', 'Not set')}</div>
                    <div><strong>Created:</strong> {wo['created_date']}</div>
                </div>
                <div style="margin-top: 1rem;"><strong>Description:</strong> {wo['description']}</div>
            </div>
            
            <div class="completion-form">
                <form class="cmms-form" data-endpoint="/cmms/workorders/{work_order_id}/complete" method="POST">
                    <h2 style="margin: 0 0 1.5rem 0; color: #333;">Work Completion Details</h2>
                    
                    <div class="cmms-field-group">
                        <label class="cmms-label required" for="actual_hours">Actual Hours Spent</label>
                        <input type="number" id="actual_hours" name="actual_hours" class="cmms-input" 
                               min="0" step="0.25" placeholder="e.g., 3.5" required/>
                        <div class="cmms-help-text">Total time spent completing this work order</div>
                    </div>
                    
                    <div class="cmms-field-group">
                        <label class="cmms-label" for="cost">Total Cost ($)</label>
                        <input type="number" id="cost" name="cost" class="cmms-input" 
                               min="0" step="0.01" placeholder="e.g., 450.75"/>
                        <div class="cmms-help-text">Include parts, labor, and other expenses</div>
                    </div>
                    
                    <div class="cmms-field-group">
                        <label class="cmms-label required" for="notes">Completion Notes</label>
                        <textarea id="notes" name="notes" class="cmms-textarea" rows="4" 
                                  placeholder="Describe work performed, issues resolved, parts used, etc." required></textarea>
                        <div class="cmms-help-text">Detailed summary of work completed</div>
                    </div>
                    
                    <div class="cmms-field-group">
                        <label class="cmms-label" for="updated_by">Completed By</label>
                        <input type="text" id="updated_by" name="updated_by" class="cmms-input" 
                               value="{wo.get('assigned_to', '')}" placeholder="Technician name"/>
                    </div>
                    
                    <div class="cmms-button-group" style="justify-content: space-between; align-items: center;">
                        <div>
                            <button type="button" class="cmms-btn cmms-btn-secondary" onclick="window.history.back()">Cancel</button>
                            <a href="/cmms/workorders/{work_order_id}/view" class="cmms-btn cmms-btn-secondary">View Details</a>
                        </div>
                        <button type="submit" class="cmms-btn cmms-btn-success">✅ Complete Work Order</button>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            {nav_js}
        </script>
        {FormComponents.get_form_javascript()}
    </body>
    </html>
    """
    
    return HTMLResponse(content=html_content, media_type="text/html; charset=utf-8")

@workorders_router.get("/{work_order_id}/edit", response_class=HTMLResponse)
async def edit_work_order_form(work_order_id: str):
    """Edit work order form"""
    wo = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not wo:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Edit Work Order: {wo['title']}</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 800px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .form-group {{ margin: 1rem 0; }}
            .form-group label {{ display: block; margin-bottom: 0.5rem; font-weight: 600; }}
            .form-group input, .form-group textarea, .form-group select {{ width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn-success {{ background: #38a169; }}
            .wo-info {{ background: #f7fafc; padding: 1rem; border-left: 4px solid #4299e1; margin-bottom: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🔧 Edit Work Order</h1>
            <p>Update work order details and assignments</p>
        </div>
        
        <div class="container">
            <div class="wo-info">
                <h3>{wo['title']} ({work_order_id})</h3>
                <p><strong>Asset:</strong> {wo['asset_id']}</p>
                <p><strong>Current Status:</strong> {wo['status'].title()}</p>
                <p><strong>Priority:</strong> {wo['priority'].title()}</p>
            </div>
            
            <div class="card">
                <form id="editWOForm">
                    <div class="form-group">
                        <label>Title:</label>
                        <input type="text" name="title" value="{wo['title']}" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Description:</label>
                        <textarea name="description" rows="4" required>{wo['description']}</textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Priority:</label>
                        <select name="priority">
                            <option value="low" {"selected" if wo['priority'] == 'low' else ""}>Low</option>
                            <option value="medium" {"selected" if wo['priority'] == 'medium' else ""}>Medium</option>
                            <option value="high" {"selected" if wo['priority'] == 'high' else ""}>High</option>
                            <option value="critical" {"selected" if wo['priority'] == 'critical' else ""}>Critical</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Status:</label>
                        <select name="status">
                            <option value="open" {"selected" if wo['status'] == 'open' else ""}>Open</option>
                            <option value="in_progress" {"selected" if wo['status'] == 'in_progress' else ""}>In Progress</option>
                            <option value="completed" {"selected" if wo['status'] == 'completed' else ""}>Completed</option>
                            <option value="cancelled" {"selected" if wo['status'] == 'cancelled' else ""}>Cancelled</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Assigned Technician:</label>
                        <select name="assigned_to">
                            <option value="">Unassigned</option>
                            <option value="John Smith" {"selected" if wo.get('assigned_to') == 'John Smith' else ""}>John Smith</option>
                            <option value="Mike Johnson" {"selected" if wo.get('assigned_to') == 'Mike Johnson' else ""}>Mike Johnson</option>
                            <option value="Sarah Davis" {"selected" if wo.get('assigned_to') == 'Sarah Davis' else ""}>Sarah Davis</option>
                            <option value="Carlos Rodriguez" {"selected" if wo.get('assigned_to') == 'Carlos Rodriguez' else ""}>Carlos Rodriguez</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Estimated Hours:</label>
                        <input type="number" step="0.5" name="estimated_hours" value="{wo.get('estimated_hours', 0)}">
                    </div>
                    
                    <div style="text-align: center; padding-top: 1rem;">
                        <button type="submit" class="btn btn-success">💾 Save Changes</button>
                        <button type="button" class="btn" onclick="window.history.back()">↩️ Cancel</button>
                        <a href="/cmms/workorders/dashboard" class="btn">📋 Back to Dashboard</a>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            document.getElementById('editWOForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const woData = Object.fromEntries(formData);
                
                fetch('/cmms/workorders/{work_order_id}', {{
                    method: 'PUT',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(woData)
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.id) {{
                        alert('Work order updated successfully!');
                        window.location.href = '/cmms/workorders/dashboard';
                    }} else {{
                        alert('Error updating work order: ' + (data.message || 'Unknown error'));
                    }}
                }})
                .catch(error => {{
                    alert('Error: ' + error.message);
                }});
            }});
        </script>
    </body>
    </html>
    """

@workorders_router.get("/bulk-assign", response_class=HTMLResponse)
async def bulk_assign_form():
    """Bulk assign work orders form"""
    open_wos = [wo for wo in work_orders_db if wo['status'] == 'open']
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Bulk Assign Work Orders</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1000px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn-success {{ background: #38a169; }}
            .wo-item {{ display: flex; align-items: center; padding: 0.5rem; border-bottom: 1px solid #e2e8f0; }}
            .wo-item:last-child {{ border-bottom: none; }}
            .wo-checkbox {{ margin-right: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📋 Bulk Assign Work Orders</h1>
            <p>Assign multiple work orders to technicians</p>
        </div>
        
        <div class="container">
            <div class="card">
                <h3>Open Work Orders ({len(open_wos)})</h3>
                <form id="bulkAssignForm">
                    <div style="margin-bottom: 1rem;">
                        <label>Assign to Technician:</label>
                        <select name="technician" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                            <option value="">Select Technician</option>
                            <option value="John Smith">John Smith</option>
                            <option value="Mike Johnson">Mike Johnson</option>
                            <option value="Sarah Davis">Sarah Davis</option>
                            <option value="Carlos Rodriguez">Carlos Rodriguez</option>
                        </select>
                    </div>
                    
                    <div style="max-height: 400px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 4px;">
                        {"".join([f'''
                        <div class="wo-item">
                            <input type="checkbox" name="work_orders" value="{wo['id']}" class="wo-checkbox">
                            <div>
                                <strong>{wo['title']}</strong><br>
                                <small>{wo['asset_id']} - {wo['priority'].title()} Priority</small>
                            </div>
                        </div>''' for wo in open_wos[:20]])}
                        {f'<div class="wo-item" style="color: #718096;"><em>... and {len(open_wos) - 20} more work orders</em></div>' if len(open_wos) > 20 else ''}
                    </div>
                    
                    <div style="text-align: center; padding-top: 1rem;">
                        <button type="button" onclick="selectAll()" class="btn">Select All</button>
                        <button type="button" onclick="selectNone()" class="btn">Select None</button>
                        <button type="submit" class="btn btn-success">🎯 Assign Selected</button>
                        <a href="/cmms/workorders/dashboard" class="btn">↩️ Back to Dashboard</a>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            function selectAll() {{
                document.querySelectorAll('.wo-checkbox').forEach(cb => cb.checked = true);
            }}
            
            function selectNone() {{
                document.querySelectorAll('.wo-checkbox').forEach(cb => cb.checked = false);
            }}
            
            document.getElementById('bulkAssignForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const technician = formData.get('technician');
                const selectedWOs = formData.getAll('work_orders');
                
                if (!selectedWOs.length) {{
                    alert('Please select at least one work order');
                    return;
                }}
                
                // For now, just show success message
                alert(`Assigned ${{selectedWOs.length}} work orders to ${{technician}}`);
                window.location.href = '/cmms/workorders/dashboard';
            }});
        </script>
    </body>
    </html>
    """

# =============================================================================
# AI Assistance Endpoints (Phase 3)
# =============================================================================

@workorders_router.post("/api/ai/intent")
async def process_ai_intent(intent_request: Dict[str, Any]) -> Dict[str, Any]:
    """Process AI intent for work order assistance"""
    try:
        from rag_system import generate_troubleshooting_response
        import time
        
        intent = intent_request.get('intent')
        context = intent_request.get('context', {})
        work_order_id = intent_request.get('work_order_id')
        user_id = intent_request.get('user_id', 'anonymous')
        
        start_time = time.time()
        
        # Check confidence threshold
        confidence_threshold = 0.7
        
        if intent == "troubleshoot_issue":
            issue_description = context.get('issue_description', '')
            if not work_order_id or not issue_description:
                return {
                    'intent': intent,
                    'confidence': 0.0,
                    'actions': [],
                    'clarifying_questions': [
                        'Which work order needs troubleshooting?',
                        'Can you describe the issue in more detail?'
                    ],
                    'citations': [],
                    'processing_time_ms': int((time.time() - start_time) * 1000),
                    'model_used': 'no_context'
                }
            
            # Generate troubleshooting response
            troubleshooting_result = await generate_troubleshooting_response(work_order_id, issue_description)
            
            if troubleshooting_result['confidence'] < confidence_threshold:
                return {
                    'intent': intent,
                    'confidence': troubleshooting_result['confidence'],
                    'actions': [],
                    'clarifying_questions': [
                        'Could you be more specific about the symptoms?',
                        'What troubleshooting steps have you already tried?',
                        'Are there any error messages or unusual sounds?'
                    ],
                    'citations': troubleshooting_result['citations'],
                    'processing_time_ms': troubleshooting_result['processing_time_ms'],
                    'model_used': 'work_order_rag'
                }
            
            return {
                'intent': intent,
                'confidence': troubleshooting_result['confidence'],
                'actions': [{
                    'action_type': 'show_troubleshooting_steps',
                    'parameters': {
                        'steps': troubleshooting_result['recommended_steps'],
                        'analysis': troubleshooting_result['issue_analysis'],
                        'similar_cases': troubleshooting_result['similar_cases'],
                        'estimated_time_hours': troubleshooting_result['estimated_resolution_time_hours']
                    },
                    'confirmation_required': False,
                    'confidence': troubleshooting_result['confidence']
                }],
                'clarifying_questions': [],
                'citations': troubleshooting_result['citations'],
                'processing_time_ms': troubleshooting_result['processing_time_ms'],
                'model_used': 'work_order_rag'
            }
        
        elif intent == "identify_part_from_image":
            # This would be called after image upload
            return {
                'intent': intent,
                'confidence': 0.8,
                'actions': [{
                    'action_type': 'request_image_upload',
                    'parameters': {
                        'upload_endpoint': '/ai/voice/vision/identify-work-order-part',
                        'work_order_id': work_order_id
                    },
                    'confirmation_required': False,
                    'confidence': 0.8
                }],
                'clarifying_questions': [],
                'citations': [],
                'processing_time_ms': int((time.time() - start_time) * 1000),
                'model_used': 'part_identification'
            }
        
        elif intent == "check_capacity":
            # Analyze technician capacity
            capacity_result = await analyze_technician_capacity(context)
            
            return {
                'intent': intent,
                'confidence': capacity_result['confidence'],
                'actions': [{
                    'action_type': 'show_capacity_analysis',
                    'parameters': capacity_result,
                    'confirmation_required': False,
                    'confidence': capacity_result['confidence']
                }],
                'clarifying_questions': [],
                'citations': [],
                'processing_time_ms': capacity_result['processing_time_ms'],
                'model_used': 'capacity_analyzer'
            }
        
        elif intent == "plan_work_order":
            # AI-powered work order planning
            planning_result = await plan_work_order_with_ai(context)
            
            return {
                'intent': intent,
                'confidence': planning_result['confidence'],
                'actions': [{
                    'action_type': 'show_work_order_plan',
                    'parameters': planning_result,
                    'confirmation_required': True,
                    'confidence': planning_result['confidence']
                }],
                'clarifying_questions': [],
                'citations': [],
                'processing_time_ms': planning_result['processing_time_ms'],
                'model_used': 'work_order_planner'
            }
        
        else:
            return {
                'intent': intent or 'unknown',
                'confidence': 0.0,
                'actions': [],
                'clarifying_questions': [
                    f"I don't understand the '{intent}' request. Could you rephrase?",
                    "Try asking me to troubleshoot an issue or identify a part from an image."
                ],
                'citations': [],
                'processing_time_ms': int((time.time() - start_time) * 1000),
                'model_used': 'unknown_intent'
            }
    
    except Exception as e:
        logger.error(f"AI intent processing failed: {e}")
        return {
            'intent': intent_request.get('intent', 'unknown'),
            'confidence': 0.0,
            'actions': [],
            'clarifying_questions': ['An error occurred processing your request. Please try again.'],
            'citations': [],
            'processing_time_ms': int((time.time() - start_time) * 1000) if 'start_time' in locals() else 0,
            'model_used': 'error'
        }

async def analyze_technician_capacity(context: Dict[str, Any]) -> Dict[str, Any]:
    """Analyze technician capacity and availability"""
    start_time = time.time()
    
    # Mock technician data - in production this would come from a database
    mock_technicians = [
        {
            'technician_id': 'TECH-001',
            'name': 'John Smith',
            'current_workload_hours': 32.0,
            'max_capacity_hours': 40.0,
            'utilization_percentage': 80.0,
            'available_hours': 8.0,
            'skills': [
                {'skill_name': 'Electrical', 'proficiency_level': 'expert'},
                {'skill_name': 'HVAC', 'proficiency_level': 'advanced'},
                {'skill_name': 'Mechanical', 'proficiency_level': 'intermediate'}
            ],
            'location': 'Main Building',
            'shift': 'Day Shift'
        },
        {
            'technician_id': 'TECH-002', 
            'name': 'Mike Johnson',
            'current_workload_hours': 28.0,
            'max_capacity_hours': 40.0,
            'utilization_percentage': 70.0,
            'available_hours': 12.0,
            'skills': [
                {'skill_name': 'Mechanical', 'proficiency_level': 'expert'},
                {'skill_name': 'Hydraulics', 'proficiency_level': 'advanced'}
            ],
            'location': 'Production Floor',
            'shift': 'Day Shift'
        }
    ]
    
    required_skills = context.get('required_skills', [])
    estimated_hours = context.get('estimated_hours', 0)
    
    # Score technicians based on availability and skills
    recommendations = []
    for tech in mock_technicians:
        score = 0.0
        
        # Availability score (0-0.5)
        if tech['available_hours'] >= estimated_hours:
            score += 0.5 * (1 - tech['utilization_percentage'] / 100)
        
        # Skills match score (0-0.5)
        if required_skills:
            tech_skills = [s['skill_name'].lower() for s in tech['skills']]
            skill_matches = sum(1 for skill in required_skills if skill.lower() in tech_skills)
            score += 0.5 * (skill_matches / len(required_skills))
        else:
            score += 0.25  # Default skill score when no specific skills required
        
        if score >= 0.3:  # Only recommend if score is decent
            recommendations.append({
                **tech,
                'recommendation_score': score,
                'recommendation_reason': f"Available for {tech['available_hours']}h, {int(tech['utilization_percentage'])}% utilized"
            })
    
    recommendations.sort(key=lambda x: x['recommendation_score'], reverse=True)
    
    # Detect conflicts
    conflicts = []
    if estimated_hours > 0:
        for tech in recommendations:
            if tech['available_hours'] < estimated_hours:
                conflicts.append(f"{tech['name']} only has {tech['available_hours']}h available but needs {estimated_hours}h")
    
    processing_time = int((time.time() - start_time) * 1000)
    
    return {
        'analysis_summary': f"Found {len(recommendations)} available technicians. Best match: {recommendations[0]['name'] if recommendations else 'None'}",
        'recommended_technicians': recommendations[:3],  # Top 3 recommendations
        'capacity_conflicts': conflicts,
        'alternative_scheduling': [],  # Would be populated with schedule alternatives
        'resource_constraints': ['All technicians at 70%+ utilization'] if all(t['utilization_percentage'] >= 70 for t in mock_technicians) else [],
        'confidence': min(1.0, len(recommendations) * 0.3),
        'processing_time_ms': processing_time
    }

async def plan_work_order_with_ai(context: Dict[str, Any]) -> Dict[str, Any]:
    """AI-powered work order planning with resource optimization"""
    start_time = time.time()
    
    title = context.get('title', '')
    description = context.get('description', '')
    asset_id = context.get('asset_id', '')
    priority = context.get('priority', 'medium')
    
    if not title or not asset_id:
        return {
            'planning_summary': 'Insufficient information for planning',
            'confidence': 0.0,
            'processing_time_ms': int((time.time() - start_time) * 1000)
        }
    
    # Get asset information
    from assets import assets_db
    asset = next((a for a in assets_db if a['id'] == asset_id), None)
    
    # Analyze requirements based on description
    estimated_hours = 2.0  # Default
    required_skills = ['General maintenance']
    
    description_lower = description.lower()
    if any(word in description_lower for word in ['electrical', 'power', 'circuit']):
        required_skills.append('Electrical')
        estimated_hours += 1.0
    if any(word in description_lower for word in ['mechanical', 'motor', 'bearing']):
        required_skills.append('Mechanical')
        estimated_hours += 0.5
    if any(word in description_lower for word in ['hydraulic', 'pressure', 'pump']):
        required_skills.append('Hydraulics')
        estimated_hours += 1.0
    
    # Priority adjustments
    if priority == 'critical':
        estimated_hours *= 1.2  # Rush jobs take longer
    elif priority == 'low':
        estimated_hours *= 0.9
    
    # Get capacity analysis
    capacity_context = {
        'required_skills': required_skills,
        'estimated_hours': estimated_hours
    }
    capacity_result = await analyze_technician_capacity(capacity_context)
    
    # Parts availability (mock)
    parts_availability = {
        'all_available': True,
        'lead_time_days': 0,
        'estimated_cost': 150.0
    }
    
    # Calculate suggested completion date
    from datetime import datetime, timedelta
    suggested_date = datetime.now() + timedelta(days=1 if priority == 'critical' else 3)
    
    processing_time = int((time.time() - start_time) * 1000)
    
    return {
        'planning_summary': f'Optimal plan for {title}: Assign to {capacity_result["recommended_technicians"][0]["name"] if capacity_result["recommended_technicians"] else "TBD"}, estimated {estimated_hours:.1f}h',
        'recommended_technician': capacity_result['recommended_technicians'][0]['technician_id'] if capacity_result['recommended_technicians'] else None,
        'suggested_schedule': {
            'estimated_hours': estimated_hours,
            'suggested_start': datetime.now().isoformat(),
            'estimated_completion': suggested_date.isoformat()
        },
        'parts_availability': parts_availability,
        'resource_allocation': {
            'technician': capacity_result['recommended_technicians'][0]['name'] if capacity_result['recommended_technicians'] else 'TBD',
            'skills_required': required_skills,
            'tools_needed': ['Standard tools', 'Safety equipment']
        },
        'estimated_completion_date': suggested_date.date().isoformat(),
        'risk_factors': ['High priority - rush completion may affect quality'] if priority == 'critical' else [],
        'optimization_suggestions': [
            'Schedule during technician available hours',
            'Ensure parts are pre-ordered',
            'Coordinate with operations for minimal downtime'
        ],
        'confidence': min(0.8, capacity_result['confidence'] + 0.2),
        'processing_time_ms': processing_time
    }

@workorders_router.post("/api/ai/troubleshoot")
async def troubleshoot_work_order(troubleshoot_request: Dict[str, Any]) -> Dict[str, Any]:
    """Generate AI-powered troubleshooting guidance for work orders"""
    try:
        work_order_id = troubleshoot_request.get('work_order_id')
        issue_description = troubleshoot_request.get('issue_description', '')
        
        if not work_order_id or not issue_description:
            raise HTTPException(status_code=400, detail="work_order_id and issue_description required")
        
        from rag_system import generate_troubleshooting_response
        result = await generate_troubleshooting_response(work_order_id, issue_description)
        
        return result
        
    except Exception as e:
        logger.error(f"Troubleshooting request failed: {e}")
        raise HTTPException(status_code=500, detail=f"Troubleshooting failed: {str(e)}")

@workorders_router.post("/api/ai/capacity-check")
async def check_capacity(capacity_request: Dict[str, Any]) -> Dict[str, Any]:
    """Check technician capacity and availability"""
    try:
        result = await analyze_technician_capacity(capacity_request)
        return result
        
    except Exception as e:
        logger.error(f"Capacity check failed: {e}")
        raise HTTPException(status_code=500, detail=f"Capacity check failed: {str(e)}")

@workorders_router.post("/api/ai/plan-work-order")
async def ai_plan_work_order(planning_request: Dict[str, Any]) -> Dict[str, Any]:
    """AI-powered work order planning"""
    try:
        result = await plan_work_order_with_ai(planning_request)
        return result
        
    except Exception as e:
        logger.error(f"Work order planning failed: {e}")
        raise HTTPException(status_code=500, detail=f"Work order planning failed: {str(e)}")

# =============================================================================
# Bulk Import/Export Operations (Phase 4)
# =============================================================================

@workorders_router.post("/api/import")
async def bulk_import_work_orders(
    file: UploadFile = File(...),
    mode: str = Query("preview", regex="^(preview|commit)$"),
    skip_duplicates: bool = Query(True),
    validate_references: bool = Query(True),
    dry_run: bool = Query(False)
) -> Dict[str, Any]:
    """
    Bulk import work orders from CSV/XLSX file
    
    Args:
        file: CSV or XLSX file with work order data
        mode: preview (validate only) or commit (import data)
        skip_duplicates: Skip duplicate work orders
        validate_references: Validate asset/technician references
        dry_run: Perform validation without importing
        
    Returns:
        BulkImportResponse with validation results and preview data
    """
    
    try:
        import pandas as pd
        import time
        from datetime import datetime
        
        start_time = time.time()
        
        # Check file format
        if not file.filename.endswith(('.csv', '.xlsx')):
            raise HTTPException(
                status_code=400, 
                detail="Unsupported file format. Please upload CSV or XLSX files only."
            )
        
        # Read file content
        file_content = await file.read()
        
        # For large files (>1MB), use background processing
        if len(file_content) > 1024 * 1024:  # 1MB
            from .ai_memory.work_orders.bulk_operations.background_processor import task_processor
            
            task_id = await task_processor.start_import_task(
                file_data=file_content,
                file_name=file.filename,
                import_options={
                    'mode': mode,
                    'skip_duplicates': skip_duplicates,
                    'validate_references': validate_references,
                    'dry_run': dry_run
                },
                user_id="current_user"  # In production, get from auth
            )
            
            return {
                "mode": mode,
                "task_id": task_id,
                "validation_summary": {
                    "total_rows": 0,
                    "valid_rows": 0,
                    "invalid_rows": 0,
                    "duplicate_rows": 0,
                    "errors": [],
                    "warnings": []
                },
                "preview_data": None,
                "processing_time_ms": int((time.time() - start_time) * 1000),
                "success": True,
                "message": "Large file import started in background. Use task_id to check progress."
            }
        
        # Process small files synchronously
        # Parse file
        try:
            if file.filename.endswith('.xlsx'):
                try:
                    import pandas as pd
                    df = pd.read_excel(pd.io.BytesIO(file_content))
                except ImportError:
                    raise HTTPException(status_code=500, detail="pandas required for Excel processing")
            else:
                try:
                    import pandas as pd
                    df = pd.read_csv(pd.io.BytesIO(file_content))
                except ImportError:
                    raise HTTPException(status_code=500, detail="pandas required for CSV processing")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to parse file: {str(e)}")
        
        if df.empty:
            raise HTTPException(status_code=400, detail="File is empty or contains no data")
        
        # Validate data
        try:
            from .ai_memory.work_orders.bulk_operations.import_validator import WorkOrderImportValidator
            validator = WorkOrderImportValidator()
            
            validation_result = await validator.validate_import_data(
                df, 
                validate_references=validate_references,
                skip_duplicates=skip_duplicates
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")
        
        # Prepare preview data
        preview_data = None
        if mode == "preview":
            # Normalize column headers
            df_normalized = df.copy()
            df_normalized.columns = df_normalized.columns.str.lower().str.strip()
            
            # Auto-map columns
            validator = WorkOrderImportValidator()
            field_mapping = validator._auto_map_columns(df_normalized.columns.tolist())
            
            # Sample rows for preview (first 10 rows)
            sample_df = df.head(10)
            sample_rows = sample_df.to_dict('records')
            
            preview_data = {
                "sample_rows": sample_rows,
                "field_mapping": field_mapping,
                "detected_format": "xlsx" if file.filename.endswith('.xlsx') else "csv",
                "column_headers": df.columns.tolist(),
                "total_columns": len(df.columns)
            }
        
        # Import valid data if in commit mode
        imported_count = 0
        if mode == "commit" and validation_result.valid_rows > 0 and not dry_run:
            try:
                # Get valid rows (rows without critical errors)
                error_rows = set(error.row - 2 for error in validation_result.errors 
                               if error.error_type in ['validation_error', 'business_rule_error'])
                
                for idx, row in df.iterrows():
                    if idx not in error_rows:
                        # Convert row to work order format
                        wo_data = _convert_import_row_to_work_order(row, df.columns)
                        work_orders_db.append(wo_data)
                        imported_count += 1
                        
            except Exception as e:
                logger.error(f"Import processing failed: {str(e)}")
                # Continue with validation results even if import fails
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return {
            "mode": mode,
            "task_id": None,
            "validation_summary": {
                "total_rows": validation_result.total_rows,
                "valid_rows": validation_result.valid_rows,
                "invalid_rows": validation_result.invalid_rows,
                "duplicate_rows": validation_result.duplicate_rows,
                "errors": [
                    {
                        "row": error.row,
                        "column": error.column,
                        "field": error.field,
                        "error_type": error.error_type,
                        "message": error.message,
                        "value": error.value,
                        "suggestion": error.suggestion
                    } for error in validation_result.errors[:50]  # Limit errors to prevent large response
                ],
                "warnings": [
                    {
                        "row": warning.row,
                        "column": warning.column,
                        "field": warning.field,
                        "error_type": warning.error_type,
                        "message": warning.message,
                        "value": warning.value,
                        "suggestion": warning.suggestion
                    } for warning in validation_result.warnings[:20]  # Limit warnings
                ]
            },
            "preview_data": preview_data,
            "processing_time_ms": processing_time,
            "success": True,
            "message": f"Import {mode} completed successfully" + (f". {imported_count} work orders imported." if imported_count > 0 else "")
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Bulk import failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

@workorders_router.get("/api/export")
async def export_work_orders(
    format: str = Query("csv", regex="^(csv|xlsx)$"),
    columns: Optional[str] = Query(None, description="Comma-separated column names"),
    date_from: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    date_to: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    status_filter: Optional[str] = Query(None, description="Comma-separated status values"),
    priority_filter: Optional[str] = Query(None, description="Comma-separated priority values"),
    asset_filter: Optional[str] = Query(None, description="Comma-separated asset IDs"),
    technician_filter: Optional[str] = Query(None, description="Comma-separated technician IDs"),
    include_comments: bool = Query(False),
    include_time_entries: bool = Query(False),
    include_photos: bool = Query(False),
    timezone: str = Query("UTC"),
    async_export: bool = Query(False, description="Use background processing for large exports")
):
    """
    Export work orders to CSV/XLSX format
    
    Args:
        format: Export format (csv or xlsx)
        columns: Specific columns to include
        date_from/date_to: Date range filter
        status_filter: Filter by work order status
        priority_filter: Filter by priority level
        asset_filter: Filter by asset IDs
        technician_filter: Filter by technician IDs
        include_comments: Include work order comments
        include_time_entries: Include time tracking data
        include_photos: Include photo attachments info
        timezone: Timezone for date fields
        async_export: Use background processing
        
    Returns:
        StreamingResponse with file download or export task ID
    """
    
    try:
        import pandas as pd
        import io
        import time
        from datetime import datetime
        from fastapi.responses import StreamingResponse
        
        start_time = time.time()
        
        # Apply filters
        filtered_wos = work_orders_db.copy()
        
        # Date range filter
        if date_from or date_to:
            if date_from:
                try:
                    from_date = datetime.fromisoformat(date_from).date()
                    filtered_wos = [wo for wo in filtered_wos 
                                  if datetime.fromisoformat(wo['created_date']).date() >= from_date]
                except ValueError:
                    raise HTTPException(status_code=400, detail="Invalid date_from format. Use YYYY-MM-DD.")
            
            if date_to:
                try:
                    to_date = datetime.fromisoformat(date_to).date()
                    filtered_wos = [wo for wo in filtered_wos 
                                  if datetime.fromisoformat(wo['created_date']).date() <= to_date]
                except ValueError:
                    raise HTTPException(status_code=400, detail="Invalid date_to format. Use YYYY-MM-DD.")
        
        # Status filter
        if status_filter:
            status_list = [s.strip() for s in status_filter.split(',')]
            filtered_wos = [wo for wo in filtered_wos if wo['status'] in status_list]
        
        # Priority filter
        if priority_filter:
            priority_list = [p.strip() for p in priority_filter.split(',')]
            filtered_wos = [wo for wo in filtered_wos if wo['priority'] in priority_list]
        
        # Asset filter
        if asset_filter:
            asset_list = [a.strip() for a in asset_filter.split(',')]
            filtered_wos = [wo for wo in filtered_wos if wo['asset_id'] in asset_list]
        
        # Technician filter
        if technician_filter:
            tech_list = [t.strip() for t in technician_filter.split(',')]
            filtered_wos = [wo for wo in filtered_wos if wo.get('assigned_to') in tech_list]
        
        # For large exports (>1000 records), use background processing if requested
        if len(filtered_wos) > 1000 and async_export:
            from .ai_memory.work_orders.bulk_operations.background_processor import task_processor
            
            export_options = {
                'customization': {
                    'format': format,
                    'columns': columns.split(',') if columns else None,
                    'date_from': date_from,
                    'date_to': date_to,
                    'status_filter': status_filter.split(',') if status_filter else None,
                    'priority_filter': priority_filter.split(',') if priority_filter else None,
                    'asset_filter': asset_filter.split(',') if asset_filter else None,
                    'technician_filter': technician_filter.split(',') if technician_filter else None,
                    'include_comments': include_comments,
                    'include_time_entries': include_time_entries,
                    'include_photos': include_photos,
                    'timezone': timezone
                }
            }
            
            task_id = await task_processor.start_export_task(
                export_options=export_options,
                user_id="current_user"  # In production, get from auth
            )
            
            return {
                "export_id": task_id,
                "download_url": None,
                "total_records": len(filtered_wos),
                "file_size_bytes": None,
                "expires_at": None,
                "processing_time_ms": int((time.time() - start_time) * 1000),
                "message": "Large export started in background. Use export_id to check progress."
            }
        
        # Process export synchronously for smaller datasets
        # Convert to DataFrame
        try:
            import pandas as pd
            df = pd.DataFrame(filtered_wos)
        except ImportError:
            raise HTTPException(status_code=500, detail="pandas required for export")
        
        if df.empty:
            raise HTTPException(status_code=404, detail="No work orders found matching the specified filters")
        
        # Select specific columns if specified
        if columns:
            column_list = [col.strip() for col in columns.split(',')]
            available_columns = [col for col in column_list if col in df.columns]
            if available_columns:
                df = df[available_columns]
            else:
                raise HTTPException(status_code=400, detail="None of the specified columns exist in the data")
        
        # Add additional data if requested
        if include_comments:
            # Add comments count (mock implementation)
            df['comments_count'] = [len([c for c in work_order_comments_db if c['work_order_id'] == wo['id']]) 
                                   for wo in filtered_wos]
        
        if include_time_entries:
            # Add total hours worked (mock implementation)
            df['total_hours_worked'] = [sum([t['hours'] for t in time_entries_db if t['work_order_id'] == wo['id']], 0) 
                                       for wo in filtered_wos]
        
        if include_photos:
            # Add photos count (mock implementation)
            df['photos_count'] = [len([p for p in photos_db if p['work_order_id'] == wo['id']]) 
                                 for wo in filtered_wos]
        
        # Sort by created_date
        if 'created_date' in df.columns:
            df = df.sort_values('created_date', ascending=False)
        
        # Generate file
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"work_orders_export_{timestamp}.{format}"
        
        if format == "csv":
            output = io.StringIO()
            df.to_csv(output, index=False)
            output.seek(0)
            
            def iter_csv():
                yield output.getvalue().encode('utf-8')
            
            return StreamingResponse(
                iter_csv(),
                media_type="text/csv",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
        
        elif format == "xlsx":
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Work Orders', index=False)
                
                # Add metadata sheet
                metadata = pd.DataFrame({
                    'Export Info': ['Generated On', 'Total Records', 'Filters Applied', 'Processing Time'],
                    'Value': [
                        datetime.now().isoformat(),
                        len(df),
                        f"Date: {date_from or 'N/A'} to {date_to or 'N/A'}, Status: {status_filter or 'All'}",
                        f"{int((time.time() - start_time) * 1000)}ms"
                    ]
                })
                metadata.to_excel(writer, sheet_name='Export Metadata', index=False)
            
            output.seek(0)
            
            def iter_xlsx():
                yield output.getvalue()
            
            return StreamingResponse(
                iter_xlsx(),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Export failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

@workorders_router.get("/api/import-status/{task_id}")
async def get_import_status(task_id: str) -> Dict[str, Any]:
    """
    Get status of background import task
    
    Args:
        task_id: Background task ID
        
    Returns:
        ImportStatusResponse with current progress
    """
    
    try:
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        from ai_memory.work_orders.bulk_operations.background_processor import task_processor
        
        task_status = await task_processor.get_task_status(task_id)
        
        if not task_status:
            raise HTTPException(status_code=404, detail="Task not found or has expired")
        
        return {
            "task_id": task_status.task_id,
            "status": task_status.status,
            "progress_percent": task_status.progress_percent,
            "processed_rows": task_status.processed_items,
            "total_rows": task_status.total_items,
            "errors": getattr(task_status.result_data, 'errors', []) if task_status.result_data else [],
            "estimated_completion_time": task_status.estimated_completion_time.isoformat() if task_status.estimated_completion_time else None,
            "message": f"Task {task_status.status}" + (f" - {task_status.error_message}" if task_status.error_message else "")
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get import status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get task status: {str(e)}")

@workorders_router.post("/api/bulk-assign")
async def bulk_assign_work_orders(bulk_assign_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Bulk assign multiple work orders to a technician
    
    Args:
        bulk_assign_data: Dict with work_order_ids and assigned_to
        
    Returns:
        Dict with assignment results
    """
    work_order_ids = bulk_assign_data.get('work_order_ids', [])
    assigned_to = bulk_assign_data.get('assigned_to')
    
    if not work_order_ids:
        raise HTTPException(status_code=400, detail="No work order IDs provided")
    
    if not assigned_to:
        raise HTTPException(status_code=400, detail="No technician specified for assignment")
    
    updated_count = 0
    errors = []
    
    for wo_id in work_order_ids:
        try:
            # Find work order
            wo_index = None
            for i, wo in enumerate(work_orders_db):
                if wo['id'] == wo_id:
                    wo_index = i
                    break
            
            if wo_index is None:
                errors.append(f"Work order {wo_id} not found")
                continue
            
            # Update assignment
            work_orders_db[wo_index]['assigned_to'] = assigned_to
            if work_orders_db[wo_index]['status'] == 'open':
                work_orders_db[wo_index]['status'] = 'assigned'
            
            updated_count += 1
            
        except Exception as e:
            errors.append(f"Failed to assign {wo_id}: {str(e)}")
    
    return {
        "success": True,
        "updated_count": updated_count,
        "assigned_to": assigned_to,
        "work_orders": work_order_ids,
        "errors": errors if errors else None
    }

@workorders_router.post("/api/bulk-status-update")
async def bulk_status_update(
    work_order_ids: List[str],
    status: Optional[str] = None,
    priority: Optional[str] = None,
    assigned_to: Optional[str] = None,
    due_date: Optional[str] = None,
    notes: Optional[str] = None,
    reason: str = "Bulk update operation"
) -> Dict[str, Any]:
    """
    Bulk update work order status and properties
    
    Args:
        work_order_ids: List of work order IDs to update
        status: New status to set
        priority: New priority to set
        assigned_to: New assignee
        due_date: New due date (YYYY-MM-DD)
        notes: Additional notes
        reason: Reason for bulk update
        
    Returns:
        BulkStatusUpdateResponse with results
    """
    
    try:
        import time
        from datetime import datetime
        
        start_time = time.time()
        
        if not work_order_ids:
            raise HTTPException(status_code=400, detail="No work order IDs provided")
        
        if len(work_order_ids) > 1000:
            raise HTTPException(status_code=400, detail="Cannot update more than 1000 work orders at once")
        
        # Validate inputs
        valid_statuses = ['open', 'assigned', 'in_progress', 'parts_required', 'on_hold', 'completed', 'closed', 'cancelled']
        valid_priorities = ['critical', 'high', 'medium', 'low']
        
        if status and status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}")
        
        if priority and priority not in valid_priorities:
            raise HTTPException(status_code=400, detail=f"Invalid priority. Must be one of: {', '.join(valid_priorities)}")
        
        if due_date:
            try:
                datetime.fromisoformat(due_date)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid due_date format. Use YYYY-MM-DD.")
        
        # For large bulk updates (>100 items), use background processing
        if len(work_order_ids) > 100:
            from .ai_memory.work_orders.bulk_operations.background_processor import task_processor
            
            updates = {}
            if status:
                updates['status'] = status
            if priority:
                updates['priority'] = priority
            if assigned_to:
                updates['assigned_to'] = assigned_to
            if due_date:
                updates['due_date'] = due_date
            if notes:
                updates['notes'] = notes
            
            task_id = await task_processor.start_bulk_update_task(
                work_order_ids=work_order_ids,
                updates=updates,
                user_id="current_user"  # In production, get from auth
            )
            
            return {
                "successful_updates": 0,
                "failed_updates": 0,
                "updated_work_orders": [],
                "errors": [],
                "audit_trail_entries": [],
                "processing_time_ms": int((time.time() - start_time) * 1000),
                "task_id": task_id,
                "message": "Large bulk update started in background. Use task_id to check progress."
            }
        
        # Process smaller updates synchronously
        successful_updates = []
        failed_updates = []
        audit_entries = []
        
        for wo_id in work_order_ids:
            try:
                # Find work order
                wo = next((w for w in work_orders_db if w['id'] == wo_id), None)
                if not wo:
                    failed_updates.append({
                        'work_order_id': wo_id,
                        'error': 'Work order not found'
                    })
                    continue
                
                # Track changes for audit
                changes = {}
                old_values = {}
                
                # Update fields
                if status and wo['status'] != status:
                    old_values['status'] = wo['status']
                    wo['status'] = status
                    changes['status'] = {'old': old_values['status'], 'new': status}
                
                if priority and wo['priority'] != priority:
                    old_values['priority'] = wo['priority']
                    wo['priority'] = priority
                    changes['priority'] = {'old': old_values['priority'], 'new': priority}
                
                if assigned_to and wo.get('assigned_to') != assigned_to:
                    old_values['assigned_to'] = wo.get('assigned_to')
                    wo['assigned_to'] = assigned_to
                    changes['assigned_to'] = {'old': old_values['assigned_to'], 'new': assigned_to}
                
                if due_date and wo.get('due_date') != due_date:
                    old_values['due_date'] = wo.get('due_date')
                    wo['due_date'] = due_date
                    changes['due_date'] = {'old': old_values['due_date'], 'new': due_date}
                
                # Add update metadata
                wo['updated_at'] = datetime.now().isoformat()
                wo['updated_by'] = 'Bulk Update System'
                
                # Add status history entry if status changed
                if 'status' in changes:
                    status_entry = {
                        "id": f"SH-{len(work_order_status_history_db) + 1:03d}",
                        "work_order_id": wo_id,
                        "status": status,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "updated_by": "Bulk Update System",
                        "notes": f"Bulk update: {reason}" + (f" - {notes}" if notes else "")
                    }
                    work_order_status_history_db.append(status_entry)
                
                # Create audit trail entry
                if changes:
                    audit_entry_id = f"AUDIT-{len(audit_entries) + 1:06d}"
                    audit_entry = {
                        "id": audit_entry_id,
                        "work_order_id": wo_id,
                        "operation": "bulk_update",
                        "changes": changes,
                        "reason": reason,
                        "timestamp": datetime.now().isoformat(),
                        "user_id": "current_user"
                    }
                    audit_entries.append(audit_entry_id)
                
                successful_updates.append(wo_id)
                
            except Exception as e:
                failed_updates.append({
                    'work_order_id': wo_id,
                    'error': str(e)
                })
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return {
            "successful_updates": len(successful_updates),
            "failed_updates": len(failed_updates),
            "updated_work_orders": successful_updates,
            "errors": failed_updates,
            "audit_trail_entries": audit_entries,
            "processing_time_ms": processing_time,
            "task_id": None,
            "message": f"Bulk update completed. {len(successful_updates)} work orders updated successfully."
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Bulk update failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Bulk update failed: {str(e)}")

def _convert_import_row_to_work_order(row: Any, columns: List[str]) -> Dict[str, Any]:
    """Convert imported row to work order format"""
    
    import time
    from datetime import datetime
    
    # Create mapping from common column variations
    column_map = {}
    for col in columns:
        col_lower = col.lower().strip()
        if 'title' in col_lower or 'summary' in col_lower:
            column_map['title'] = col
        elif 'description' in col_lower or 'details' in col_lower:
            column_map['description'] = col
        elif 'asset' in col_lower and 'id' in col_lower:
            column_map['asset_id'] = col
        elif 'type' in col_lower or 'category' in col_lower:
            column_map['type'] = col
        elif 'priority' in col_lower or 'urgency' in col_lower:
            column_map['priority'] = col
        elif 'status' in col_lower:
            column_map['status'] = col
        elif 'assigned' in col_lower or 'technician' in col_lower:
            column_map['assigned_to'] = col
        elif 'due' in col_lower and 'date' in col_lower:
            column_map['due_date'] = col
        elif 'estimated' in col_lower and 'hours' in col_lower:
            column_map['estimated_hours'] = col
        elif 'cost' in col_lower or 'budget' in col_lower:
            column_map['estimated_cost'] = col
    
    # Generate unique work order ID
    wo_id = f"WO-{int(time.time() * 1000) % 1000000:06d}"
    
    # Build work order data
    wo_data = {
        'id': wo_id,
        'title': str(row.get(column_map.get('title', ''), '')).strip(),
        'description': str(row.get(column_map.get('description', ''), '')).strip(),
        'asset_id': str(row.get(column_map.get('asset_id', ''), '')).strip(),
        'type': str(row.get(column_map.get('type', 'reactive'), 'reactive')).lower(),
        'priority': str(row.get(column_map.get('priority', 'medium'), 'medium')).lower(),
        'status': str(row.get(column_map.get('status', 'open'), 'open')).lower(),
        'created_date': datetime.now().strftime('%Y-%m-%d'),
        'created_by': 'Import System',
        'assigned_to': None,
        'due_date': None,
        'estimated_hours': None,
        'actual_hours': None,
        'cost': None
    }
    
    # Handle optional fields
    if column_map.get('assigned_to') and row.get(column_map['assigned_to']) is not None and str(row.get(column_map['assigned_to'])).strip() != '':
        wo_data['assigned_to'] = str(row[column_map['assigned_to']]).strip()
    
    if column_map.get('due_date') and row.get(column_map['due_date']) is not None and str(row.get(column_map['due_date'])).strip() != '':
        try:
            # Try to parse date
            date_str = str(row[column_map['due_date']]).strip()
            if date_str:
                # Try multiple date formats
                for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                    try:
                        parsed_date = datetime.strptime(date_str, fmt)
                        wo_data['due_date'] = parsed_date.strftime('%Y-%m-%d')
                        break
                    except ValueError:
                        continue
        except:
            pass
    
    if column_map.get('estimated_hours') and row.get(column_map['estimated_hours']) is not None and str(row.get(column_map['estimated_hours'])).strip() != '':
        try:
            wo_data['estimated_hours'] = float(row[column_map['estimated_hours']])
        except:
            pass
    
    if column_map.get('estimated_cost') and row.get(column_map['estimated_cost']) is not None and str(row.get(column_map['estimated_cost'])).strip() != '':
        try:
            wo_data['cost'] = float(row[column_map['estimated_cost']])
        except:
            pass
    
    return wo_data

@workorders_router.get("/reports", response_class=HTMLResponse)
async def reports_dashboard():
    """Work Orders Reports Dashboard"""
    total_wos = len(work_orders_db)
    completed_wos = len([wo for wo in work_orders_db if wo['status'] == 'completed'])
    open_wos = len([wo for wo in work_orders_db if wo['status'] == 'open'])
    in_progress_wos = len([wo for wo in work_orders_db if wo['status'] == 'in_progress'])
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Work Orders Reports</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; margin: 0.5rem; text-decoration: none; display: inline-block; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; }}
            .stat-card {{ text-align: center; padding: 1rem; border: 1px solid #e2e8f0; border-radius: 8px; }}
            .stat-value {{ font-size: 2rem; font-weight: bold; color: #4299e1; }}
            .report-card {{ border: 1px solid #e2e8f0; border-radius: 8px; padding: 1rem; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📊 Work Orders Reports</h1>
            <p>Analytics and Performance Metrics</p>
        </div>
        
        <div class="container">
            <div class="card">
                <h3>Work Orders Overview</h3>
                <div class="grid">
                    <div class="stat-card">
                        <div class="stat-value">{total_wos}</div>
                        <div>Total Work Orders</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #38a169;">{completed_wos}</div>
                        <div>Completed</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #d69e2e;">{in_progress_wos}</div>
                        <div>In Progress</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: #e53e3e;">{open_wos}</div>
                        <div>Open</div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <h3>Available Reports</h3>
                <div class="grid">
                    <div class="report-card">
                        <h4>Completion Rate Report</h4>
                        <p>Work order completion trends and metrics</p>
                        <button class="btn" onclick="generateCompletionReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Technician Performance</h4>
                        <p>Individual technician efficiency and workload</p>
                        <button class="btn" onclick="generateTechnicianReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Asset Maintenance Report</h4>
                        <p>Work orders by asset and maintenance history</p>
                        <button class="btn" onclick="generateAssetReport()">Generate Report</button>
                    </div>
                    
                    <div class="report-card">
                        <h4>Cost Analysis</h4>
                        <p>Labor costs and parts usage analysis</p>
                        <button class="btn" onclick="generateCostReport()">Generate Report</button>
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <a href="/cmms/workorders/dashboard" class="btn">↩️ Back to Dashboard</a>
                </div>
            </div>
        </div>
        
        <script>
            function generateCompletionReport() {{
                alert('Completion rate report - Feature coming soon!');
            }}
            
            function generateTechnicianReport() {{
                alert('Technician performance report - Feature coming soon!');
            }}
            
            function generateAssetReport() {{
                alert('Asset maintenance report - Feature coming soon!');
            }}
            
            function generateCostReport() {{
                alert('Cost analysis report - Feature coming soon!');
            }}
        </script>
    </body>
    </html>
    """
# Industrial Voice Transcription API Endpoints

@workorders_router.post("/voice/transcribe")
async def transcribe_voice_to_work_order(request: VoiceTranscriptionRequest):
    """
    Industrial voice transcription endpoint for converting speech to work order text.
    Optimized for noisy factory environments with maintenance vocabulary.
    """
    try:
        # Transcribe the voice input
        transcription_result = transcribe_industrial_voice(
            audio_data=request.audio_data,
            audio_format=request.audio_format,
            noise_filtering=request.noise_filtering,
            context_hints=request.context_hints
        )
        
        if not transcription_result["success"]:
            raise HTTPException(status_code=400, detail=transcription_result["error"])
        
        # Optional: Auto-generate work order from transcription
        transcribed_text = transcription_result["transcription"]
        
        # Check if transcription contains work order creation intent
        create_wo_keywords = ["create work order", "new work order", "urgent repair", "maintenance needed"]
        auto_create = any(keyword in transcribed_text.lower() for keyword in create_wo_keywords)
        
        result = {
            **transcription_result,
            "suggested_work_order": None
        }
        
        if auto_create:
            # Extract work order details from transcription
            suggested_wo = extract_work_order_from_text(transcribed_text)
            result["suggested_work_order"] = suggested_wo
        
        return result
        
    except Exception as e:
        logger.error(f"Voice transcription failed: {e}")
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")

def extract_work_order_from_text(text: str) -> Dict[str, Any]:
    """Extract work order details from transcribed text using NLP"""
    
    # Priority extraction
    priority = "medium"
    if any(word in text.lower() for word in ["urgent", "emergency", "critical"]):
        priority = "high"
    elif any(word in text.lower() for word in ["routine", "scheduled"]):
        priority = "low"
    
    # Asset extraction (simple pattern matching)
    asset_keywords = {
        "pump": ["pump", "pumps"],
        "conveyor": ["conveyor", "belt", "conveyor belt"],
        "motor": ["motor", "engine", "motors"],
        "compressor": ["compressor", "air compressor"],
        "hvac": ["hvac", "air conditioning", "heating"]
    }
    
    detected_asset = None
    for asset_type, keywords in asset_keywords.items():
        if any(keyword in text.lower() for keyword in keywords):
            detected_asset = asset_type
            break
    
    # Problem extraction
    problem_keywords = {
        "leak": ["leak", "leaking", "dripping"],
        "noise": ["noise", "loud", "grinding", "squeaking"],
        "vibration": ["vibration", "vibrating", "shaking"],
        "failure": ["broken", "failed", "not working", "down"],
        "maintenance": ["maintenance", "service", "inspection"]
    }
    
    detected_problems = []
    for problem_type, keywords in problem_keywords.items():
        if any(keyword in text.lower() for keyword in keywords):
            detected_problems.append(problem_type)
    
    # Generate suggested work order
    title = f"Repair {detected_asset or 'Equipment'}"
    if detected_problems:
        title += f" - {' '.join(detected_problems).title()}"
    
    return {
        "suggested_title": title,
        "suggested_description": text,
        "suggested_priority": priority,
        "detected_asset_type": detected_asset,
        "detected_problems": detected_problems,
        "confidence": 0.85 if detected_asset else 0.6
    }

# File Management Integration Endpoints
@workorders_router.post("/upload")
async def upload_workorder_file(
    file: UploadFile = File(...),
    work_order_id: Optional[str] = None,
    description: Optional[str] = None,
    tags: Optional[str] = None
):
    """Upload file for work order"""
    from file_manager import upload_file
    return await upload_file(
        file=file,
        entity_type="work_order",
        entity_id=work_order_id or "new",
        description=description or "",
        tags=tags or "",
        uploaded_by="technician"
    )

@workorders_router.get("/export")
async def export_workorders_data(
    format: str = Query("excel", regex="^(excel|csv|pdf|json)$"),
    work_order_id: Optional[str] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    """Export work orders data in various formats"""
    # Filter work orders based on parameters
    filtered_data = []
    
    for wo in work_orders_db:
        if work_order_id and wo["id"] != work_order_id:
            continue
        if status and wo["status"] != status:
            continue
        # Add date filtering logic here if needed
        filtered_data.append(wo)
    
    if format == "excel":
        if not PANDAS_AVAILABLE:
            raise HTTPException(status_code=400, detail="Excel export requires pandas")
        
        import pandas as pd
        from io import BytesIO
        
        df = pd.DataFrame(filtered_data)
        output = BytesIO()
        df.to_excel(output, index=False, sheet_name="Work Orders")
        output.seek(0)
        
        from fastapi.responses import StreamingResponse
        return StreamingResponse(
            BytesIO(output.read()),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=workorders_export.xlsx"}
        )
    
    elif format == "csv":
        if not PANDAS_AVAILABLE:
            # Fallback CSV creation without pandas
            import csv
            from io import StringIO
            
            output = StringIO()
            if filtered_data:
                writer = csv.DictWriter(output, fieldnames=filtered_data[0].keys())
                writer.writeheader()
                writer.writerows(filtered_data)
            
            from fastapi.responses import StreamingResponse
            from io import BytesIO
            return StreamingResponse(
                BytesIO(output.getvalue().encode()),
                media_type="text/csv",
                headers={"Content-Disposition": "attachment; filename=workorders_export.csv"}
            )
        
        import pandas as pd
        from io import BytesIO
        
        df = pd.DataFrame(filtered_data)
        output = BytesIO()
        df.to_csv(output, index=False)
        output.seek(0)
        
        from fastapi.responses import StreamingResponse
        return StreamingResponse(
            output,
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=workorders_export.csv"}
        )
    
    elif format == "json":
        from fastapi.responses import JSONResponse
        return JSONResponse(
            content={"work_orders": filtered_data, "exported_at": datetime.now().isoformat()},
            headers={"Content-Disposition": "attachment; filename=workorders_export.json"}
        )
    
    elif format == "pdf":
        raise HTTPException(status_code=501, detail="PDF export not yet implemented")

@workorders_router.post("/import")
async def import_workorders_data(
    file: UploadFile = File(...),
    overwrite: bool = False,
    validate_only: bool = False
):
    """Import work orders data from Excel/CSV file"""
    if not file.filename or not file.filename.endswith(('.xlsx', '.xls', '.csv')):
        raise HTTPException(status_code=400, detail="Only Excel and CSV files are supported")
    
    try:
        content = await file.read()
        
        if file.filename.endswith('.csv'):
            import csv
            from io import StringIO
            
            csv_content = StringIO(content.decode('utf-8'))
            reader = csv.DictReader(csv_content)
            imported_data = list(reader)
        else:
            if not PANDAS_AVAILABLE:
                raise HTTPException(status_code=400, detail="Excel import requires pandas")
            
            import pandas as pd
            from io import BytesIO
            
            df = pd.read_excel(BytesIO(content))
            imported_data = df.to_dict('records')
        
        # Validate data
        validation_errors = []
        valid_records = []
        
        for i, record in enumerate(imported_data):
            try:
                # Basic validation
                if not record.get('title'):
                    validation_errors.append(f"Row {i+1}: Title is required")
                    continue
                
                if not record.get('status'):
                    record['status'] = 'open'
                
                if not record.get('priority'):
                    record['priority'] = 'medium'
                
                # Create work order object
                work_order = {
                    "id": record.get('id', f"WO-IMP-{int(time.time())}-{i}"),
                    "title": record['title'],
                    "description": record.get('description', ''),
                    "status": record['status'],
                    "priority": record['priority'],
                    "assigned_to": record.get('assigned_to', ''),
                    "asset_id": record.get('asset_id', ''),
                    "location": record.get('location', ''),
                    "created_date": datetime.now().isoformat(),
                    "due_date": record.get('due_date', ''),
                    "estimated_hours": float(record.get('estimated_hours', 0)) if record.get('estimated_hours') else 0,
                    "imported": True
                }
                
                valid_records.append(work_order)
                
            except Exception as e:
                validation_errors.append(f"Row {i+1}: {str(e)}")
        
        if validate_only:
            return {
                "validation_result": {
                    "total_rows": len(imported_data),
                    "valid_rows": len(valid_records),
                    "errors": validation_errors,
                    "preview": valid_records[:5]  # Show first 5 valid records
                }
            }
        
        # Import valid records
        imported_count = 0
        for work_order in valid_records:
            if overwrite or not any(wo["id"] == work_order["id"] for wo in work_orders_db):
                if overwrite:
                    # Remove existing record
                    work_orders_db[:] = [wo for wo in work_orders_db if wo["id"] != work_order["id"]]
                
                work_orders_db.append(work_order)
                imported_count += 1
        
        return {
            "import_result": {
                "total_rows": len(imported_data),
                "imported_rows": imported_count,
                "skipped_rows": len(valid_records) - imported_count,
                "errors": validation_errors
            }
        }
        
    except Exception as e:
        logger.error(f"Import failed: {e}")
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

@workorders_router.get("/files/{work_order_id}")
async def get_workorder_files(work_order_id: str):
    """Get all files associated with a work order"""
    from file_manager import list_files
    return await list_files(entity_type="work_order", entity_id=work_order_id)

@workorders_router.get("/{work_order_id}/edit", response_class=HTMLResponse)
async def edit_work_order_form(work_order_id: str):
    """Edit work order form"""
    # Find the work order
    work_order = None
    for wo in work_orders_db:
        if wo["id"] == work_order_id:
            work_order = wo
            break
    
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Edit Work Order - ChatterFix CMMS</title>
        <style>
            {get_base_styles()}
            .edit-form {{ max-width: 800px; margin: 2rem auto; padding: 2rem; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            .form-group {{ margin-bottom: 1.5rem; }}
            .form-group label {{ display: block; margin-bottom: 0.5rem; font-weight: 600; color: #2d3748; }}
            .form-control {{ width: 100%; padding: 0.75rem; border: 1px solid #e2e8f0; border-radius: 4px; font-size: 1rem; }}
            .form-control:focus {{ outline: none; border-color: #4299e1; box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.1); }}
            .btn-group {{ display: flex; gap: 1rem; margin-top: 2rem; }}
            .btn {{ padding: 0.75rem 1.5rem; border: none; border-radius: 4px; cursor: pointer; font-size: 1rem; text-decoration: none; display: inline-block; text-align: center; }}
            .btn-primary {{ background: #4299e1; color: white; }}
            .btn-secondary {{ background: #718096; color: white; }}
            .btn:hover {{ opacity: 0.9; }}
            select.form-control {{ background: white; }}
        </style>
    </head>
    <body>
        <div class="edit-form">
            <h1>Edit Work Order #{work_order["id"]}</h1>
            
            <form id="editForm">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" class="form-control" value="{work_order.get('title', '')}" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control" rows="4" required>{work_order.get('description', '')}</textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label for="priority">Priority</label>
                        <select id="priority" name="priority" class="form-control" required>
                            <option value="Low" {'selected' if work_order.get('priority') == 'Low' else ''}>Low</option>
                            <option value="Medium" {'selected' if work_order.get('priority') == 'Medium' else ''}>Medium</option>
                            <option value="High" {'selected' if work_order.get('priority') == 'High' else ''}>High</option>
                            <option value="Critical" {'selected' if work_order.get('priority') == 'Critical' else ''}>Critical</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" class="form-control" required>
                            <option value="Open" {'selected' if work_order.get('status') == 'Open' else ''}>Open</option>
                            <option value="In Progress" {'selected' if work_order.get('status') == 'In Progress' else ''}>In Progress</option>
                            <option value="Completed" {'selected' if work_order.get('status') == 'Completed' else ''}>Completed</option>
                            <option value="Cancelled" {'selected' if work_order.get('status') == 'Cancelled' else ''}>Cancelled</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label for="assigned_to">Assigned To</label>
                        <input type="text" id="assigned_to" name="assigned_to" class="form-control" value="{work_order.get('assigned_to', '')}">
                    </div>
                    
                    <div class="form-group">
                        <label for="due_date">Due Date</label>
                        <input type="date" id="due_date" name="due_date" class="form-control" value="{work_order.get('due_date', '').split('T')[0] if work_order.get('due_date') else ''}">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="location">Location</label>
                    <input type="text" id="location" name="location" class="form-control" value="{work_order.get('location', '')}">
                </div>
                
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">💾 Save Changes</button>
                    <a href="/cmms/workorders/list" class="btn btn-secondary">❌ Cancel</a>
                </div>
            </form>
        </div>
        
        <script>
            document.getElementById('editForm').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const formData = new FormData(this);
                const data = Object.fromEntries(formData.entries());
                
                try {{
                    const response = await fetch('/cmms/workorders/{work_order_id}/update', {{
                        method: 'PUT',
                        headers: {{
                            'Content-Type': 'application/json',
                        }},
                        body: JSON.stringify(data)
                    }});
                    
                    if (response.ok) {{
                        alert('✅ Work order updated successfully!');
                        window.location.href = '/cmms/workorders/list';
                    }} else {{
                        alert('❌ Error updating work order');
                    }}
                }} catch (error) {{
                    alert('❌ Error: ' + error.message);
                }}
            }});
        </script>
    </body>
    </html>
    """

@workorders_router.put("/{work_order_id}/update")
async def update_work_order(work_order_id: str, work_order_data: dict):
    """Update a work order"""
    # Find and update the work order
    for i, wo in enumerate(work_orders_db):
        if wo["id"] == work_order_id:
            # Update fields
            work_orders_db[i].update(work_order_data)
            work_orders_db[i]["updated_at"] = datetime.now().isoformat()
            
            return {
                "success": True,
                "message": "Work order updated successfully",
                "work_order": work_orders_db[i]
            }
    
    raise HTTPException(status_code=404, detail="Work order not found")

