#!/usr/bin/env python3
"""
Minimal Work Orders module for CMMS - Dashboard only
"""
from fastapi import APIRouter
from fastapi.responses import HTMLResponse

# Create router
workorders_router = APIRouter(prefix="/workorders", tags=["workorders"])

# Sample data
sample_stats = {
    "total": 5,
    "open": 2, 
    "in_progress": 1,
    "overdue": 4,
    "sla_breaches": 4
}

@workorders_router.get("/dashboard", response_class=HTMLResponse)
async def workorders_dashboard():
    """Work Orders Dashboard"""
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatterFix Work Orders</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }}
        .header {{ 
            padding: 2rem;
            text-align: center;
            background: rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 2rem;
        }}
        .header h1 {{ 
            font-size: 2.5rem; 
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 2rem; }}
        .card {{ 
            background: rgba(255,255,255,0.15); 
            border-radius: 15px; 
            padding: 2rem; 
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 2rem;
        }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }}
        .stat {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }}
        .stat-value {{ font-size: 1.5rem; font-weight: bold; }}
        .status-critical {{ color: #ff6b6b; }}
        .status-warning {{ color: #ffd93d; }}
        .status-good {{ color: #6bcf7f; }}
        .btn {{ 
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 0.5rem;
            width: 100%;
        }}
        .btn:hover {{ background: rgba(255,255,255,0.3); }}
    </style>
</head>
<body>
    <div class="header">
        <h1>📋 ChatterFix Work Orders</h1>
        <p>Work Order Management, Tracking & Assignment</p>
    </div>
    
    <div class="container">
        <div class="grid">
            <div class="card">
                <h3>📊 Work Order Overview</h3>
                <div class="stat">
                    <span>Total Work Orders</span>
                    <span class="stat-value">{sample_stats['total']}</span>
                </div>
                <div class="stat">
                    <span>Open/Assigned</span>
                    <span class="stat-value status-warning">{sample_stats['open']}</span>
                </div>
                <div class="stat">
                    <span>In Progress</span>
                    <span class="stat-value status-good">{sample_stats['in_progress']}</span>
                </div>
                <div class="stat">
                    <span>Overdue</span>
                    <span class="stat-value status-critical">{sample_stats['overdue']}</span>
                </div>
                <div class="stat">
                    <span>SLA Breaches</span>
                    <span class="stat-value status-critical">{sample_stats['sla_breaches']}</span>
                </div>
            </div>
            
            <div class="card">
                <h3>⚡ Quick Actions</h3>
                <button class="btn">Create Work Order</button>
                <button class="btn">Bulk Assign</button>
                <button class="btn">Generate Reports</button>
                <button class="btn">Calendar View</button>
                <button class="btn">Export Data</button>
            </div>
            
            <div class="card">
                <h3>📈 Performance Metrics</h3>
                <div class="stat">
                    <span>Avg. Response Time</span>
                    <span class="stat-value">2.4h</span>
                </div>
                <div class="stat">
                    <span>Completion Rate</span>
                    <span class="stat-value">87%</span>
                </div>
                <div class="stat">
                    <span>SLA Compliance</span>
                    <span class="stat-value status-warning">75%</span>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h3>✅ System Status</h3>
            <p>Work Orders module loaded successfully with emoji encoding fix applied!</p>
            <p>All emojis (📋 📊 ⚡ 📈 ✅) should display correctly now.</p>
        </div>
    </div>
</body>
</html>"""
    
    return HTMLResponse(content=html, media_type="text/html; charset=utf-8")