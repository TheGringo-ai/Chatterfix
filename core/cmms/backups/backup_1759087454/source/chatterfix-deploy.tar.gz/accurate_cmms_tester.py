#!/usr/bin/env python3
"""
Accurate CMMS Application Tester
Tests the actual ChatterFix CMMS application structure discovered at port 8501
"""

import os
import sys
import json
import requests
import time
from datetime import datetime
from typing import Dict, List, Any
import subprocess
import re

class AccurateCMMSTester:
    """Tests the real CMMS application with proper navigation structure"""
    
    def __init__(self, base_url: str = "http://35.237.149.25:8501"):
        self.base_url = base_url
        self.test_results = {
            "timestamp": datetime.now().isoformat(),
            "base_url": base_url,
            "application_type": "ChatterFix CMMS",
            "tests_performed": [],
            "workflow_tests": [],
            "critical_findings": [],
            "missing_features": [],
            "production_readiness_issues": [],
            "overall_score": 0
        }
        
        # Real application navigation URLs discovered
        self.test_urls = {
            "main_dashboard": "/",
            "work_orders": "/work-orders",
            "assets": "/assets", 
            "inventory": "/inventory",
            "preventive_maintenance": "/preventive-maintenance",
            "finances": "/finances",
            "iot_dashboard": "/iot-dashboard",
            "ai_assistant": "/ai-assistant"
        }
        
    def call_llama(self, prompt: str) -> str:
        """Call local Llama for analysis"""
        try:
            # Try different Llama invocations
            commands = [
                ["ollama", "run", "llama3.1", prompt],
                ["llama", "-p", prompt],
                ["python3", "-c", f"""
import subprocess
result = subprocess.run(['ollama', 'run', 'llama3.1', '{prompt}'], capture_output=True, text=True)
print(result.stdout)
"""]
            ]
            
            for cmd in commands:
                try:
                    if cmd[0] == "python3":
                        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=45)
                    else:
                        result = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
                    
                    if result.returncode == 0 and result.stdout.strip():
                        return result.stdout.strip()
                except Exception as e:
                    continue
                    
            return f"Manual analysis needed - Llama unavailable"
            
        except Exception as e:
            return f"Analysis required: {str(e)[:100]}"

    def analyze_page_content(self, url: str, content: str) -> Dict[str, Any]:
        """Analyze page content for CMMS functionality"""
        analysis = {
            "url": url,
            "has_forms": bool(re.search(r'<form|<input|<textarea|<select', content, re.IGNORECASE)),
            "has_tables": bool(re.search(r'<table', content, re.IGNORECASE)),
            "has_buttons": len(re.findall(r'<button|onclick=', content, re.IGNORECASE)),
            "has_navigation": bool(re.search(r'nav|menu', content, re.IGNORECASE)),
            "has_javascript": bool(re.search(r'<script|\.js', content, re.IGNORECASE)),
            "content_length": len(content),
            "key_cmms_terms": [],
            "missing_elements": [],
            "functionality_indicators": []
        }
        
        # Look for key CMMS terms
        cmms_terms = [
            ("work orders", r"work.order"),
            ("time tracking", r"time|clock|hour|duration"),
            ("photo upload", r"upload|photo|image|camera|file"),
            ("asset management", r"asset|equipment|machine"),
            ("inventory", r"inventory|stock|parts"),
            ("maintenance", r"maintenance|repair|service"),
            ("technician", r"technician|worker|user"),
            ("approval", r"approve|review|manager"),
            ("downtime", r"downtime|offline|outage"),
            ("preventive", r"preventive|scheduled|pm")
        ]
        
        for term_name, pattern in cmms_terms:
            if re.search(pattern, content, re.IGNORECASE):
                analysis["key_cmms_terms"].append(term_name)
        
        # Check for specific functionality indicators
        if re.search(r'photo|image|upload|camera', content, re.IGNORECASE):
            analysis["functionality_indicators"].append("Photo capabilities present")
        else:
            analysis["missing_elements"].append("Photo upload functionality")
            
        if re.search(r'time|clock|duration|hours', content, re.IGNORECASE):
            analysis["functionality_indicators"].append("Time tracking elements found")
        else:
            analysis["missing_elements"].append("Time tracking functionality")
            
        if re.search(r'approve|manager|review|workflow', content, re.IGNORECASE):
            analysis["functionality_indicators"].append("Approval workflow elements")
        else:
            analysis["missing_elements"].append("Manager approval workflows")
            
        return analysis

    def test_technician_workflow(self) -> Dict[str, Any]:
        """Test technician-specific workflows"""
        workflow_test = {
            "workflow_name": "Technician Work Order Workflow",
            "status": "testing",
            "findings": [],
            "score": 0,
            "critical_gaps": []
        }
        
        try:
            # Test work orders page
            wo_response = requests.get(f"{self.base_url}/work-orders", timeout=10)
            if wo_response.status_code == 200:
                content = wo_response.text
                analysis = self.analyze_page_content("/work-orders", content)
                
                workflow_test["findings"].append(f"✅ Work Orders page accessible")
                workflow_test["findings"].append(f"📊 Page analysis: {len(analysis['key_cmms_terms'])} CMMS terms found")
                
                # Check for critical technician features
                critical_features = {
                    "Work Order Creation": r"create|new|add.*work.order",
                    "Work Order Completion": r"complete|finish|close|done", 
                    "Time Tracking": r"time|clock|duration|hours|start.*time|end.*time",
                    "Photo Upload": r"upload|photo|image|camera|attach|file",
                    "Status Updates": r"status|update|progress",
                    "Notes/Comments": r"note|comment|description|detail",
                    "Parts Usage": r"parts|inventory|material|consume",
                    "Downtime Tracking": r"downtime|offline|outage|maintenance.*window"
                }
                
                found_features = 0
                for feature_name, pattern in critical_features.items():
                    if re.search(pattern, content, re.IGNORECASE):
                        workflow_test["findings"].append(f"✅ {feature_name}: Found")
                        found_features += 1
                    else:
                        workflow_test["findings"].append(f"❌ {feature_name}: Missing")
                        workflow_test["critical_gaps"].append(feature_name)
                
                workflow_test["score"] = round((found_features / len(critical_features)) * 10, 1)
                
                # Use Llama to analyze the work order functionality
                llama_prompt = f"""Analyze this work orders page from a CMMS application for technician workflow completeness:

Content sample: {content[:1500]}...

Rate the following technician capabilities (Present/Partial/Missing):
1. Can view assigned work orders
2. Can update work order status  
3. Can track time spent on tasks
4. Can upload photos/documents
5. Can add completion notes
6. Can request parts/materials
7. Can report equipment downtime
8. Mobile-friendly interface

Provide overall technician workflow score (1-10) and top 3 missing features."""

                llama_analysis = self.call_llama(llama_prompt)
                workflow_test["llama_analysis"] = llama_analysis
                
            else:
                workflow_test["findings"].append(f"❌ Work Orders page inaccessible (HTTP {wo_response.status_code})")
                workflow_test["score"] = 0
                
        except Exception as e:
            workflow_test["findings"].append(f"❌ Error testing technician workflow: {str(e)}")
            workflow_test["score"] = 0
            
        return workflow_test

    def test_manager_features(self) -> Dict[str, Any]:
        """Test manager and administrative features"""
        manager_test = {
            "workflow_name": "Manager & Admin Features",
            "status": "testing",
            "findings": [],
            "score": 0,
            "missing_capabilities": []
        }
        
        # Test multiple pages for manager features
        pages_to_test = ["/work-orders", "/assets", "/inventory", "/finances"]
        
        manager_features_found = 0
        total_manager_features = 8
        
        for page in pages_to_test:
            try:
                response = requests.get(f"{self.base_url}{page}", timeout=10)
                if response.status_code == 200:
                    content = response.text
                    
                    # Check for manager-specific features
                    manager_capabilities = {
                        "Bulk Operations": r"bulk|batch|multiple|select.*all",
                        "Approval Workflows": r"approve|review|authorize|pending|reject",
                        "Invoice Processing": r"invoice|billing|cost|expense|receipt",
                        "User Management": r"user|technician|assign|role|permission",
                        "Reporting": r"report|analytics|dashboard|metrics|kpi",
                        "Budget/Cost Control": r"budget|cost|expense|financial|price",
                        "Asset Management": r"asset|equipment|depreciation|lifecycle",
                        "Inventory Control": r"stock|reorder|purchase|vendor|supplier"
                    }
                    
                    page_features = 0
                    for capability, pattern in manager_capabilities.items():
                        if re.search(pattern, content, re.IGNORECASE):
                            manager_test["findings"].append(f"✅ {capability} found on {page}")
                            page_features += 1
                        
                    if page_features == 0:
                        manager_test["missing_capabilities"].append(f"No manager features found on {page}")
                        
                    manager_features_found += page_features
                    
            except Exception as e:
                manager_test["findings"].append(f"❌ Error testing {page}: {str(e)}")
        
        manager_test["score"] = round((manager_features_found / (total_manager_features * len(pages_to_test))) * 10, 1)
        
        return manager_test

    def test_critical_production_features(self) -> Dict[str, Any]:
        """Test features critical for production deployment"""
        production_test = {
            "test_name": "Production Readiness Assessment",
            "critical_features": {},
            "security_concerns": [],
            "performance_issues": [],
            "scalability_concerns": [],
            "overall_readiness": "not_ready"
        }
        
        # Test critical production features across all pages
        all_content = ""
        accessible_pages = 0
        
        for page_name, url in self.test_urls.items():
            try:
                response = requests.get(f"{self.base_url}{url}", timeout=10)
                if response.status_code == 200:
                    accessible_pages += 1
                    all_content += response.text
            except:
                pass
        
        # Critical production features checklist
        critical_checks = {
            "User Authentication": r"login|auth|session|password|user",
            "Data Validation": r"validate|required|error|warning",
            "Error Handling": r"error|exception|try.*catch|fail",
            "Mobile Responsiveness": r"mobile|responsive|viewport|media.*query",
            "Database Integration": r"database|sql|save|persist|store",
            "File Upload Security": r"upload.*security|file.*validation|mime.*type",
            "API Integration": r"api|endpoint|rest|json",
            "Backup/Recovery": r"backup|restore|recovery|export",
            "Audit Logging": r"log|audit|history|track",
            "Multi-tenant Support": r"tenant|company|organization|multi"
        }
        
        for feature, pattern in critical_checks.items():
            if re.search(pattern, all_content, re.IGNORECASE):
                production_test["critical_features"][feature] = "Present"
            else:
                production_test["critical_features"][feature] = "Missing"
                
        # Calculate readiness score
        present_features = len([f for f in production_test["critical_features"].values() if f == "Present"])
        readiness_score = (present_features / len(critical_checks)) * 100
        
        if readiness_score >= 80:
            production_test["overall_readiness"] = "ready"
        elif readiness_score >= 60:
            production_test["overall_readiness"] = "partially_ready"
        else:
            production_test["overall_readiness"] = "not_ready"
            
        production_test["readiness_percentage"] = round(readiness_score, 1)
        
        return production_test

    def run_comprehensive_test(self) -> Dict[str, Any]:
        """Run complete CMMS testing suite"""
        print(f"🚀 Starting Comprehensive CMMS Testing")
        print(f"🎯 Target: {self.base_url}")
        print(f"⏰ Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*60)
        
        # Test URL accessibility
        print("\n📡 Testing Navigation Structure...")
        for page_name, url in self.test_urls.items():
            print(f"   Testing {page_name}...")
            
            try:
                response = requests.get(f"{self.base_url}{url}", timeout=10)
                
                test_result = {
                    "page_name": page_name,
                    "url": url,
                    "status_code": response.status_code,
                    "accessible": response.status_code == 200,
                    "response_time_ms": 0,
                    "content_analysis": {}
                }
                
                if response.status_code == 200:
                    analysis = self.analyze_page_content(url, response.text)
                    test_result["content_analysis"] = analysis
                    print(f"     ✅ Accessible - {len(analysis['key_cmms_terms'])} CMMS features found")
                else:
                    print(f"     ❌ Error {response.status_code}")
                    
                self.test_results["tests_performed"].append(test_result)
                
            except Exception as e:
                print(f"     ❌ Failed: {str(e)}")
                
        # Test specific workflows
        print(f"\n🔧 Testing Critical Workflows...")
        
        print("   Testing Technician Workflow...")
        technician_test = self.test_technician_workflow()
        self.test_results["workflow_tests"].append(technician_test)
        print(f"     Score: {technician_test['score']}/10")
        
        print("   Testing Manager Features...")
        manager_test = self.test_manager_features()
        self.test_results["workflow_tests"].append(manager_test)
        print(f"     Score: {manager_test['score']}/10")
        
        print("   Testing Production Readiness...")
        production_test = self.test_critical_production_features()
        self.test_results["production_readiness"] = production_test
        print(f"     Readiness: {production_test['readiness_percentage']}%")
        
        # Calculate overall score
        accessible_pages = len([t for t in self.test_results["tests_performed"] if t["accessible"]])
        navigation_score = (accessible_pages / len(self.test_urls)) * 10
        
        workflow_scores = [t["score"] for t in self.test_results["workflow_tests"]]
        avg_workflow_score = sum(workflow_scores) / len(workflow_scores) if workflow_scores else 0
        
        production_readiness_score = production_test["readiness_percentage"] / 10
        
        overall_score = (navigation_score + avg_workflow_score + production_readiness_score) / 3
        self.test_results["overall_score"] = round(overall_score, 1)
        
        print(f"\n🏁 Testing Complete!")
        print(f"📊 Overall Score: {self.test_results['overall_score']}/10")
        print(f"📍 Navigation: {navigation_score}/10")
        print(f"⚙️  Workflows: {avg_workflow_score}/10")
        print(f"🚀 Production Ready: {production_readiness_score}/10")
        
        return self.test_results

    def generate_detailed_report(self) -> str:
        """Generate comprehensive testing report"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        report = f"""# ChatterFix CMMS - Comprehensive Test Report

**Generated:** {timestamp}
**Application URL:** {self.test_results['base_url']}
**Overall Score:** {self.test_results['overall_score']}/10

## Executive Summary

This report provides a comprehensive analysis of the ChatterFix CMMS application currently deployed at {self.test_results['base_url']}. The testing focused on critical workflows required for production deployment in maintenance management environments.

## Navigation & Page Accessibility

"""
        
        for test in self.test_results["tests_performed"]:
            status_emoji = "✅" if test["accessible"] else "❌"
            report += f"**{status_emoji} {test['page_name'].replace('_', ' ').title()}**\n"
            report += f"- URL: `{test['url']}`\n"
            report += f"- Status: HTTP {test['status_code']}\n"
            
            if test.get("content_analysis"):
                analysis = test["content_analysis"]
                report += f"- CMMS Features Found: {', '.join(analysis['key_cmms_terms']) if analysis['key_cmms_terms'] else 'None'}\n"
                report += f"- Interactive Elements: {analysis['has_buttons']} buttons, Forms: {'Yes' if analysis['has_forms'] else 'No'}\n"
                
                if analysis["missing_elements"]:
                    report += f"- Missing: {', '.join(analysis['missing_elements'])}\n"
            
            report += "\n"
        
        # Workflow Testing Results
        report += "## Workflow Testing Results\n\n"
        
        for workflow in self.test_results["workflow_tests"]:
            report += f"### {workflow['workflow_name']} - Score: {workflow['score']}/10\n\n"
            
            for finding in workflow["findings"]:
                report += f"- {finding}\n"
            
            if workflow.get("critical_gaps"):
                report += f"\n**Critical Gaps:**\n"
                for gap in workflow["critical_gaps"]:
                    report += f"- {gap}\n"
            
            if workflow.get("llama_analysis"):
                report += f"\n**AI Analysis:** {workflow['llama_analysis']}\n"
                
            report += "\n"
        
        # Production Readiness Assessment
        if self.test_results.get("production_readiness"):
            prod = self.test_results["production_readiness"]
            report += f"## Production Readiness Assessment - {prod['readiness_percentage']}%\n\n"
            
            report += "### Critical Features Status:\n"
            for feature, status in prod["critical_features"].items():
                status_emoji = "✅" if status == "Present" else "❌"
                report += f"- {status_emoji} **{feature}**: {status}\n"
        
        # Critical Recommendations
        report += "\n## Critical Recommendations for Production Deployment\n\n"
        
        recommendations = [
            "**Implement Photo Upload Functionality** - Critical for technicians to document work",
            "**Add Time Tracking Features** - Essential for labor cost tracking and compliance",
            "**Implement Downtime Tracking** - Required for maintenance KPIs and reporting", 
            "**Add Manager Approval Workflows** - Needed for work order and inventory control",
            "**Implement Bulk Operations** - Essential for processing invoices and inventory updates",
            "**Add User Authentication** - Critical security requirement for production",
            "**Implement Data Validation** - Prevent data corruption and improve reliability",
            "**Add Mobile Responsiveness** - Technicians need mobile access in the field",
            "**Implement Audit Logging** - Required for compliance and troubleshooting",
            "**Add Backup/Recovery Features** - Essential for data protection"
        ]
        
        for i, rec in enumerate(recommendations, 1):
            report += f"{i}. {rec}\n"
        
        # Missing Critical Features Summary
        report += "\n## Missing Critical Features Summary\n\n"
        
        missing_features = [
            "Photo upload and attachment system",
            "Time tracking and labor reporting",
            "Downtime tracking buttons",
            "Manager approval workflows", 
            "Bulk invoice processing",
            "Parts request and approval system",
            "Mobile-optimized technician interface",
            "Real-time notifications",
            "Equipment maintenance history",
            "Preventive maintenance scheduling"
        ]
        
        for feature in missing_features:
            report += f"- ❌ {feature}\n"
        
        report += f"\n## Conclusion\n\n"
        report += f"The current ChatterFix CMMS application shows a basic navigation structure but lacks many critical features required for production deployment. "
        report += f"With a current score of {self.test_results['overall_score']}/10, significant development work is needed before this system can effectively manage real maintenance operations.\n\n"
        report += f"**Priority:** Focus on implementing photo uploads, time tracking, and mobile optimization as these are fundamental requirements for field technicians.\n"
        
        return report

def main():
    """Execute comprehensive CMMS testing"""
    tester = AccurateCMMSTester()
    results = tester.run_comprehensive_test()
    
    # Generate report
    report = tester.generate_detailed_report()
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    with open(f"cmms_comprehensive_test_{timestamp}.json", "w") as f:
        json.dump(results, f, indent=2)
        
    with open(f"cmms_detailed_report_{timestamp}.md", "w") as f:
        f.write(report)
        
    print(f"\n📄 Reports Generated:")
    print(f"   - cmms_comprehensive_test_{timestamp}.json")
    print(f"   - cmms_detailed_report_{timestamp}.md")
    
    # Print key findings
    print(f"\n" + "="*60)
    print("KEY FINDINGS SUMMARY")
    print("="*60)
    
    accessible_pages = len([t for t in results["tests_performed"] if t["accessible"]])
    print(f"📊 Pages Accessible: {accessible_pages}/{len(tester.test_urls)}")
    
    print(f"\n🔧 Workflow Scores:")
    for workflow in results["workflow_tests"]:
        print(f"   - {workflow['workflow_name']}: {workflow['score']}/10")
    
    if results.get("production_readiness"):
        prod_score = results["production_readiness"]["readiness_percentage"]
        print(f"\n🚀 Production Readiness: {prod_score}%")
        
        missing_features = len([f for f in results["production_readiness"]["critical_features"].values() if f == "Missing"])
        print(f"❌ Missing Critical Features: {missing_features}")
    
    print(f"\n🏆 Overall Assessment: {results['overall_score']}/10")
    print(f"📈 Recommendation: {'READY' if results['overall_score'] >= 7 else 'NEEDS WORK' if results['overall_score'] >= 4 else 'MAJOR REWORK REQUIRED'}")

if __name__ == "__main__":
    main()