#!/usr/bin/env python3
"""
ChatterFix AI Enhanced Module
Comprehensive AI integration with Llama, voice, OCR, and PM planning
"""

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, File, UploadFile, Form
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging
import json
import base64
import httpx
import asyncio
from enum import Enum

logger = logging.getLogger(__name__)

ai_enhanced_router = APIRouter(prefix="/ai-enhanced", tags=["ai-enhanced"])

# Configuration for Llama server
LLAMA_SERVER = "http://localhost:11434"  # Local Ollama server

class AIRole(Enum):
    TECHNICIAN = "technician"
    MANAGER = "manager"
    SUPERVISOR = "supervisor"
    PLANNER = "planner"
    ADMIN = "admin"

class AIRequest(BaseModel):
    message: str
    role: AIRole = AIRole.TECHNICIAN
    context: Optional[Dict[str, Any]] = None
    voice_input: Optional[bool] = False

class VoiceCommand(BaseModel):
    audio_data: str  # Base64 encoded audio
    role: AIRole
    command_type: str  # "create_wo", "lookup_part", "status_update"

class OCRScan(BaseModel):
    image_data: str  # Base64 encoded image
    scan_type: str  # "nameplate", "serial", "barcode", "document"
    auto_create_asset: bool = False

class PMPlanRequest(BaseModel):
    asset_id: str
    maintenance_type: str
    frequency_days: int
    ai_optimize: bool = True

# AI-powered Work Order creation from voice
class VoiceWorkOrder(BaseModel):
    transcript: str
    priority: Optional[str] = None
    asset_id: Optional[str] = None
    estimated_hours: Optional[float] = None

# WebSocket manager for real-time AI chat
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info(f"Client {client_id} connected")

    def disconnect(self, client_id: str):
        if client_id in self.active_connections:
            del self.active_connections[client_id]
            logger.info(f"Client {client_id} disconnected")

    async def send_message(self, message: str, client_id: str):
        if client_id in self.active_connections:
            await self.active_connections[client_id].send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections.values():
            await connection.send_text(message)

manager = ConnectionManager()

async def query_llama(prompt: str, role: AIRole, context: Optional[Dict] = None) -> str:
    """Query Llama model on the server"""
    try:
        system_prompts = {
            AIRole.TECHNICIAN: "You are a skilled CMMS technician assistant. Help with equipment repairs, troubleshooting, and work orders. Be concise and technical.",
            AIRole.MANAGER: "You are a maintenance manager assistant. Focus on KPIs, resource allocation, cost analysis, and strategic planning.",
            AIRole.SUPERVISOR: "You are a maintenance supervisor assistant. Help with scheduling, team coordination, and daily operations.",
            AIRole.PLANNER: "You are a PM planning specialist. Create comprehensive preventive maintenance schedules and optimize maintenance intervals.",
            AIRole.ADMIN: "You are a CMMS administrator. Help with system configuration, user management, and data integrity."
        }
        
        full_prompt = f"{system_prompts[role]}\n\n"
        if context:
            full_prompt += f"Context: {json.dumps(context)}\n\n"
        full_prompt += f"User: {prompt}\nAssistant:"
        
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{LLAMA_SERVER}/api/generate",
                json={
                    "model": "llama3.1:latest",
                    "prompt": full_prompt,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "AI response unavailable")
            else:
                logger.error(f"Llama query failed: {response.status_code}")
                return "AI temporarily unavailable. Please try again."
                
    except Exception as e:
        logger.error(f"Llama query error: {e}")
        return f"AI error: {str(e)}"

@ai_enhanced_router.post("/chat")
async def ai_chat(request: AIRequest):
    """AI chat endpoint with role-based responses"""
    response = await query_llama(request.message, request.role, request.context)
    
    # Log for analytics
    logger.info(f"AI Chat - Role: {request.role.value}, Message: {request.message[:50]}...")
    
    return {
        "response": response,
        "role": request.role.value,
        "timestamp": datetime.now().isoformat(),
        "voice_compatible": True
    }

@ai_enhanced_router.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    """Real-time AI chat via WebSocket"""
    await manager.connect(websocket, client_id)
    try:
        while True:
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            # Process with Llama
            role = AIRole(message_data.get("role", "technician"))
            response = await query_llama(message_data["message"], role)
            
            # Send response
            await manager.send_message(json.dumps({
                "type": "ai_response",
                "message": response,
                "timestamp": datetime.now().isoformat()
            }), client_id)
            
    except WebSocketDisconnect:
        manager.disconnect(client_id)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(client_id)

@ai_enhanced_router.post("/voice/command")
async def process_voice_command(command: VoiceCommand):
    """Process voice commands for various CMMS operations"""
    
    # Here you would integrate with a speech-to-text service
    # For now, we'll simulate the transcription
    transcript = "Create work order for pump maintenance in building 2"
    
    # Process with AI based on command type
    if command.command_type == "create_wo":
        prompt = f"Extract work order details from: {transcript}"
        ai_response = await query_llama(prompt, command.role)
        
        # Parse AI response to create structured WO
        return {
            "action": "work_order_created",
            "transcript": transcript,
            "ai_interpretation": ai_response,
            "wo_data": {
                "title": "Pump Maintenance - Building 2",
                "priority": "medium",
                "estimated_hours": 2.5,
                "ai_suggested": True
            }
        }
    
    elif command.command_type == "lookup_part":
        prompt = f"Find part information for: {transcript}"
        ai_response = await query_llama(prompt, command.role)
        
        return {
            "action": "part_lookup",
            "transcript": transcript,
            "ai_response": ai_response,
            "parts_found": [
                {"part_number": "PMP-2345", "description": "Centrifugal Pump Seal"},
                {"part_number": "BRG-7890", "description": "Pump Bearing Assembly"}
            ]
        }
    
    return {"status": "processed", "transcript": transcript}

@ai_enhanced_router.post("/ocr/scan")
async def process_ocr_scan(scan: OCRScan):
    """Process OCR scans for equipment identification"""
    
    # In production, integrate with OCR service (Tesseract, Google Vision, etc.)
    # Simulate OCR results
    ocr_results = {
        "text_detected": "Model: PMP-5000\nSerial: SN-2024-0845\nMfg Date: 2024-03",
        "confidence": 0.95
    }
    
    # Use AI to interpret and structure the OCR data
    prompt = f"Extract equipment information from OCR scan: {ocr_results['text_detected']}"
    ai_interpretation = await query_llama(prompt, AIRole.TECHNICIAN)
    
    structured_data = {
        "model": "PMP-5000",
        "serial_number": "SN-2024-0845",
        "manufacture_date": "2024-03",
        "ai_interpretation": ai_interpretation
    }
    
    if scan.auto_create_asset:
        # Auto-create asset in system
        structured_data["asset_created"] = True
        structured_data["asset_id"] = f"AST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    return {
        "ocr_results": ocr_results,
        "structured_data": structured_data,
        "scan_type": scan.scan_type
    }

@ai_enhanced_router.post("/pm/plan")
async def create_pm_plan(request: PMPlanRequest):
    """Create AI-optimized PM planning board"""
    
    # Generate comprehensive PM plan with AI
    prompt = f"""Create a preventive maintenance plan for asset {request.asset_id}:
    - Maintenance Type: {request.maintenance_type}
    - Base Frequency: Every {request.frequency_days} days
    - Optimize for reliability and cost
    - Include task checklist and spare parts
    """
    
    ai_plan = await query_llama(prompt, AIRole.PLANNER)
    
    # Structure the PM plan
    pm_schedule = {
        "asset_id": request.asset_id,
        "plan_name": f"PM-{request.asset_id}-{datetime.now().strftime('%Y%m')}",
        "frequency_days": request.frequency_days,
        "next_due": (datetime.now() + timedelta(days=request.frequency_days)).isoformat(),
        "tasks": [
            "Visual inspection",
            "Check vibration levels",
            "Lubrication check",
            "Belt tension verification",
            "Temperature monitoring"
        ],
        "estimated_duration_hours": 2.5,
        "required_parts": [
            {"part": "Lubricant", "quantity": "500ml"},
            {"part": "Filter", "quantity": "1"}
        ],
        "ai_recommendations": ai_plan,
        "ai_optimized": request.ai_optimize
    }
    
    return pm_schedule

@ai_enhanced_router.get("/dashboard/universal", response_class=HTMLResponse)
async def universal_ai_dashboard():
    """Universal AI assistant that appears on all pages"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix AI Assistant</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            
            /* Floating AI Assistant Button */
            .ai-fab {
                position: fixed;
                bottom: 30px;
                right: 30px;
                width: 60px;
                height: 60px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
                z-index: 9999;
                transition: transform 0.3s ease;
            }
            
            .ai-fab:hover {
                transform: scale(1.1);
            }
            
            .ai-fab-icon {
                font-size: 30px;
            }
            
            /* AI Assistant Panel */
            .ai-panel {
                position: fixed;
                bottom: 100px;
                right: 30px;
                width: 400px;
                max-width: 90vw;
                height: 600px;
                max-height: 70vh;
                background: #1a1a2e;
                border-radius: 20px;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
                display: none;
                flex-direction: column;
                z-index: 9998;
                border: 1px solid rgba(102, 126, 234, 0.3);
            }
            
            .ai-panel.active {
                display: flex;
            }
            
            .ai-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 1rem;
                border-radius: 20px 20px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: center;
                color: white;
            }
            
            .ai-role-selector {
                display: flex;
                gap: 0.5rem;
                padding: 0.5rem;
                background: rgba(0, 0, 0, 0.2);
                border-radius: 10px;
            }
            
            .role-btn {
                padding: 0.3rem 0.6rem;
                background: rgba(255, 255, 255, 0.1);
                border: none;
                border-radius: 5px;
                color: white;
                cursor: pointer;
                font-size: 0.8rem;
            }
            
            .role-btn.active {
                background: rgba(255, 255, 255, 0.3);
            }
            
            .ai-chat-area {
                flex: 1;
                overflow-y: auto;
                padding: 1rem;
                background: #0f0f1e;
            }
            
            .ai-message {
                margin-bottom: 1rem;
                padding: 0.8rem;
                border-radius: 10px;
                animation: fadeIn 0.3s ease;
            }
            
            .user-message {
                background: rgba(102, 126, 234, 0.2);
                margin-left: 20%;
                border: 1px solid rgba(102, 126, 234, 0.3);
                color: #e0e0e0;
            }
            
            .ai-response {
                background: rgba(118, 75, 162, 0.2);
                margin-right: 20%;
                border: 1px solid rgba(118, 75, 162, 0.3);
                color: #e0e0e0;
            }
            
            .ai-input-area {
                padding: 1rem;
                background: #16213e;
                border-radius: 0 0 20px 20px;
                display: flex;
                gap: 0.5rem;
            }
            
            .ai-input {
                flex: 1;
                padding: 0.8rem;
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(102, 126, 234, 0.3);
                border-radius: 10px;
                color: white;
                font-size: 0.9rem;
            }
            
            .ai-input::placeholder {
                color: rgba(255, 255, 255, 0.5);
            }
            
            .ai-tools {
                display: flex;
                gap: 0.5rem;
            }
            
            .tool-btn {
                width: 40px;
                height: 40px;
                background: rgba(102, 126, 234, 0.3);
                border: 1px solid rgba(102, 126, 234, 0.5);
                border-radius: 10px;
                color: white;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
            }
            
            .tool-btn:hover {
                background: rgba(102, 126, 234, 0.5);
                transform: scale(1.05);
            }
            
            /* Voice Recording Indicator */
            .voice-recording {
                position: absolute;
                top: -40px;
                left: 50%;
                transform: translateX(-50%);
                background: #ff4444;
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 20px;
                display: none;
                animation: pulse 1s infinite;
            }
            
            .voice-recording.active {
                display: block;
            }
            
            @keyframes pulse {
                0% { opacity: 1; }
                50% { opacity: 0.7; }
                100% { opacity: 1; }
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            /* PM Planning Board */
            .pm-board {
                display: none;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 80%;
                max-width: 1200px;
                height: 80%;
                background: #1a1a2e;
                border-radius: 20px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
                z-index: 10000;
                overflow: hidden;
            }
            
            .pm-board.active {
                display: block;
            }
            
            .pm-board-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 1.5rem;
                color: white;
            }
            
            .pm-board-content {
                padding: 2rem;
                height: calc(100% - 80px);
                overflow-y: auto;
            }
            
            .pm-timeline {
                display: flex;
                gap: 1rem;
                overflow-x: auto;
                padding: 1rem 0;
            }
            
            .pm-task-card {
                min-width: 250px;
                background: rgba(102, 126, 234, 0.1);
                border: 1px solid rgba(102, 126, 234, 0.3);
                border-radius: 10px;
                padding: 1rem;
                color: white;
            }
            
            .close-btn {
                background: none;
                border: none;
                color: white;
                font-size: 1.5rem;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <!-- Floating AI Assistant Button -->
        <div class="ai-fab" onclick="toggleAIPanel()">
            <span class="ai-fab-icon">🤖</span>
        </div>
        
        <!-- AI Assistant Panel -->
        <div class="ai-panel" id="aiPanel">
            <div class="ai-header">
                <div>
                    <h3>ChatterFix AI Assistant</h3>
                    <small id="aiStatus">Connected to Llama 3.1</small>
                </div>
                <button class="close-btn" onclick="toggleAIPanel()">×</button>
            </div>
            
            <div class="ai-role-selector">
                <button class="role-btn active" onclick="selectRole('technician')">Tech</button>
                <button class="role-btn" onclick="selectRole('manager')">Manager</button>
                <button class="role-btn" onclick="selectRole('supervisor')">Supervisor</button>
                <button class="role-btn" onclick="selectRole('planner')">Planner</button>
                <button class="role-btn" onclick="selectRole('admin')">Admin</button>
            </div>
            
            <div class="ai-chat-area" id="chatArea">
                <div class="ai-message ai-response">
                    Hello! I'm your ChatterFix AI Assistant powered by Llama 3.1. I can help you with:
                    <br><br>
                    🔧 Creating work orders<br>
                    🎤 Voice commands<br>
                    📷 OCR scanning<br>
                    📊 PM planning<br>
                    💡 Troubleshooting<br>
                    <br>
                    How can I assist you today?
                </div>
            </div>
            
            <div class="voice-recording" id="voiceRecording">
                🔴 Recording...
            </div>
            
            <div class="ai-input-area">
                <input 
                    type="text" 
                    class="ai-input" 
                    id="aiInput" 
                    placeholder="Type your message or use voice..."
                    onkeypress="handleKeyPress(event)"
                >
                <div class="ai-tools">
                    <button class="tool-btn" onclick="startVoiceRecording()" title="Voice Input">
                        🎤
                    </button>
                    <button class="tool-btn" onclick="startOCRScan()" title="OCR Scan">
                        📷
                    </button>
                    <button class="tool-btn" onclick="openPMBoard()" title="PM Planning">
                        📅
                    </button>
                    <button class="tool-btn" onclick="sendMessage()" title="Send">
                        ➤
                    </button>
                </div>
            </div>
        </div>
        
        <!-- PM Planning Board -->
        <div class="pm-board" id="pmBoard">
            <div class="pm-board-header">
                <h2>🗓️ Preventive Maintenance Planning Board</h2>
                <button class="close-btn" onclick="closePMBoard()">×</button>
            </div>
            <div class="pm-board-content">
                <h3>AI-Optimized PM Schedule</h3>
                <div class="pm-timeline" id="pmTimeline">
                    <!-- PM tasks will be dynamically added here -->
                </div>
            </div>
        </div>
        
        <script>
            let ws = null;
            let currentRole = 'technician';
            let isRecording = false;
            let mediaRecorder = null;
            let audioChunks = [];
            
            // Initialize WebSocket connection
            function initWebSocket() {
                const clientId = 'client_' + Date.now();
                ws = new WebSocket(`ws://35.237.149.25:8000/ai-enhanced/ws/${clientId}`);
                
                ws.onopen = () => {
                    console.log('AI WebSocket connected');
                    document.getElementById('aiStatus').textContent = 'Connected to Llama 3.1';
                };
                
                ws.onmessage = (event) => {
                    const data = JSON.parse(event.data);
                    if (data.type === 'ai_response') {
                        addMessage(data.message, 'ai-response');
                    }
                };
                
                ws.onerror = (error) => {
                    console.error('WebSocket error:', error);
                    document.getElementById('aiStatus').textContent = 'Connection error';
                };
                
                ws.onclose = () => {
                    document.getElementById('aiStatus').textContent = 'Reconnecting...';
                    setTimeout(initWebSocket, 3000);
                };
            }
            
            function toggleAIPanel() {
                const panel = document.getElementById('aiPanel');
                panel.classList.toggle('active');
                
                if (panel.classList.contains('active') && !ws) {
                    initWebSocket();
                }
            }
            
            function selectRole(role) {
                currentRole = role;
                document.querySelectorAll('.role-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                event.target.classList.add('active');
                
                addMessage(`Switched to ${role} mode`, 'ai-response');
            }
            
            function handleKeyPress(event) {
                if (event.key === 'Enter') {
                    sendMessage();
                }
            }
            
            function sendMessage() {
                const input = document.getElementById('aiInput');
                const message = input.value.trim();
                
                if (!message) return;
                
                addMessage(message, 'user-message');
                
                // Send via WebSocket or HTTP
                if (ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({
                        message: message,
                        role: currentRole
                    }));
                } else {
                    // Fallback to HTTP
                    fetch('/ai-enhanced/chat', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            message: message,
                            role: currentRole
                        })
                    })
                    .then(r => r.json())
                    .then(data => {
                        addMessage(data.response, 'ai-response');
                    });
                }
                
                input.value = '';
            }
            
            function addMessage(text, className) {
                const chatArea = document.getElementById('chatArea');
                const messageDiv = document.createElement('div');
                messageDiv.className = `ai-message ${className}`;
                messageDiv.textContent = text;
                chatArea.appendChild(messageDiv);
                chatArea.scrollTop = chatArea.scrollHeight;
            }
            
            async function startVoiceRecording() {
                if (!isRecording) {
                    try {
                        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                        mediaRecorder = new MediaRecorder(stream);
                        audioChunks = [];
                        
                        mediaRecorder.ondataavailable = (event) => {
                            audioChunks.push(event.data);
                        };
                        
                        mediaRecorder.onstop = async () => {
                            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                            const reader = new FileReader();
                            reader.onloadend = () => {
                                const base64Audio = reader.result.split(',')[1];
                                processVoiceCommand(base64Audio);
                            };
                            reader.readAsDataURL(audioBlob);
                        };
                        
                        mediaRecorder.start();
                        isRecording = true;
                        document.getElementById('voiceRecording').classList.add('active');
                        
                        // Auto-stop after 10 seconds
                        setTimeout(() => {
                            if (isRecording) {
                                stopVoiceRecording();
                            }
                        }, 10000);
                        
                    } catch (err) {
                        console.error('Microphone access denied:', err);
                        addMessage('Please allow microphone access to use voice commands', 'ai-response');
                    }
                } else {
                    stopVoiceRecording();
                }
            }
            
            function stopVoiceRecording() {
                if (mediaRecorder && isRecording) {
                    mediaRecorder.stop();
                    isRecording = false;
                    document.getElementById('voiceRecording').classList.remove('active');
                    mediaRecorder.stream.getTracks().forEach(track => track.stop());
                }
            }
            
            async function processVoiceCommand(audioData) {
                addMessage('Processing voice command...', 'ai-response');
                
                const response = await fetch('/ai-enhanced/voice/command', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        audio_data: audioData,
                        role: currentRole,
                        command_type: 'create_wo'
                    })
                });
                
                const data = await response.json();
                addMessage(`Voice: "${data.transcript}"`, 'user-message');
                addMessage(data.ai_interpretation || 'Work order created', 'ai-response');
            }
            
            async function startOCRScan() {
                // Create file input for image selection
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.capture = 'environment';
                
                input.onchange = async (e) => {
                    const file = e.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onloadend = async () => {
                            const base64Image = reader.result.split(',')[1];
                            
                            addMessage('Processing OCR scan...', 'ai-response');
                            
                            const response = await fetch('/ai-enhanced/ocr/scan', {
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                body: JSON.stringify({
                                    image_data: base64Image,
                                    scan_type: 'nameplate',
                                    auto_create_asset: true
                                })
                            });
                            
                            const data = await response.json();
                            addMessage(`OCR detected: ${data.ocr_results.text_detected}`, 'ai-response');
                            if (data.structured_data.asset_created) {
                                addMessage(`Asset created: ${data.structured_data.asset_id}`, 'ai-response');
                            }
                        };
                        reader.readAsDataURL(file);
                    }
                };
                
                input.click();
            }
            
            function openPMBoard() {
                document.getElementById('pmBoard').classList.add('active');
                loadPMSchedule();
            }
            
            function closePMBoard() {
                document.getElementById('pmBoard').classList.remove('active');
            }
            
            async function loadPMSchedule() {
                // Load PM schedule with AI optimization
                const response = await fetch('/ai-enhanced/pm/plan', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        asset_id: 'PUMP-001',
                        maintenance_type: 'preventive',
                        frequency_days: 30,
                        ai_optimize: true
                    })
                });
                
                const data = await response.json();
                const timeline = document.getElementById('pmTimeline');
                timeline.innerHTML = '';
                
                // Create task cards
                data.tasks.forEach((task, index) => {
                    const card = document.createElement('div');
                    card.className = 'pm-task-card';
                    card.innerHTML = `
                        <h4>Task ${index + 1}</h4>
                        <p>${task}</p>
                        <small>Due: ${data.next_due}</small>
                    `;
                    timeline.appendChild(card);
                });
            }
            
            // Auto-inject AI assistant into all pages
            if (window.self === window.top) {
                // Only inject if we're not in an iframe
                document.addEventListener('DOMContentLoaded', () => {
                    // The AI assistant is now available on this page
                    console.log('ChatterFix AI Assistant loaded');
                });
            }
        </script>
    </body>
    </html>
    """

@ai_enhanced_router.get("/inject-script")
async def get_injection_script():
    """JavaScript to inject AI assistant into all CMMS pages"""
    return """
    // ChatterFix AI Assistant Injection Script
    (function() {
        if (window.chatterFixAILoaded) return;
        window.chatterFixAILoaded = true;
        
        // Create and inject AI assistant HTML
        const aiHTML = `
            <div class="ai-fab" onclick="window.toggleAIPanel()">
                <span style="font-size: 30px;">🤖</span>
            </div>
            <div id="aiContainer"></div>
        `;
        
        const div = document.createElement('div');
        div.innerHTML = aiHTML;
        document.body.appendChild(div);
        
        // Load AI assistant iframe
        const iframe = document.createElement('iframe');
        iframe.src = '/ai-enhanced/dashboard/universal';
        iframe.style.cssText = 'position:fixed;bottom:0;right:0;width:100%;height:100%;border:none;pointer-events:none;z-index:9999';
        iframe.id = 'chatterFixAI';
        document.getElementById('aiContainer').appendChild(iframe);
        
        window.toggleAIPanel = function() {
            iframe.style.pointerEvents = iframe.style.pointerEvents === 'none' ? 'all' : 'none';
        };
        
        console.log('ChatterFix AI Assistant injected successfully');
    })();
    """