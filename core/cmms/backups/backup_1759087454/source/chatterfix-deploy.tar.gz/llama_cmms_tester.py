#!/usr/bin/env python3
"""
Llama-Powered CMMS Application Tester
Comprehensive testing of ChatterFix CMMS application
"""

import os
import sys
import json
import requests
import time
from datetime import datetime
from typing import Dict, List, Any
import subprocess

class CMMSTester:
    """Comprehensive CMMS application tester using Llama for intelligent analysis"""
    
    def __init__(self, base_url: str = "http://35.237.149.25:8501"):
        self.base_url = base_url
        self.test_results = {
            "timestamp": datetime.now().isoformat(),
            "base_url": base_url,
            "tests_performed": [],
            "issues_found": [],
            "missing_features": [],
            "recommendations": [],
            "overall_score": 0
        }
        
        # Test URLs to check
        self.test_urls = {
            "main_dashboard": "/",
            "dashboard_main": "/dashboard/main",
            "workorders": "/workorders/dashboard", 
            "assets": "/assets/dashboard",
            "technicians": "/technicians/portal",
            "parts": "/parts/dashboard",
            "preventive": "/preventive/dashboard",
            "ai": "/ai/dashboard",
            "admin": "/admin/dashboard",
            "health": "/health",
            "api": "/api"
        }
        
    def call_llama(self, prompt: str) -> str:
        """Call local Llama for analysis"""
        try:
            # Try different possible Llama invocations
            commands = [
                ["llama", prompt],
                ["ollama", "run", "llama3.1", prompt],
                ["python", "-c", f"import ollama; print(ollama.chat(model='llama3.1', messages=[{{'role': 'user', 'content': '{prompt}'}}])['message']['content'])"]
            ]
            
            for cmd in commands:
                try:
                    result = subprocess.run(
                        cmd, 
                        capture_output=True, 
                        text=True, 
                        timeout=30
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        return result.stdout.strip()
                except Exception:
                    continue
                    
            return f"Llama analysis unavailable - manual inspection required for: {prompt[:100]}..."
            
        except Exception as e:
            return f"Error calling Llama: {str(e)}"

    def test_url_accessibility(self, url_name: str, endpoint: str) -> Dict[str, Any]:
        """Test if URL is accessible and analyze response"""
        full_url = f"{self.base_url}{endpoint}"
        test_result = {
            "test_name": f"URL Accessibility - {url_name}",
            "url": full_url,
            "status": "failed",
            "response_time": 0,
            "status_code": None,
            "content_type": None,
            "content_length": 0,
            "analysis": None,
            "issues": []
        }
        
        try:
            start_time = time.time()
            response = requests.get(full_url, timeout=10)
            response_time = (time.time() - start_time) * 1000
            
            test_result.update({
                "status": "passed" if response.status_code == 200 else "failed",
                "response_time": round(response_time, 2),
                "status_code": response.status_code,
                "content_type": response.headers.get('content-type', 'unknown'),
                "content_length": len(response.content)
            })
            
            if response.status_code == 200:
                # Get Llama analysis of the content
                content_preview = response.text[:2000]  # First 2000 chars
                llama_prompt = f"""Analyze this CMMS web page content for functionality and completeness:
                
URL: {full_url}
Content Type: {response.headers.get('content-type', 'unknown')}
Content Preview:
{content_preview}

Please identify:
1. What functionality this page appears to provide
2. Any obvious missing features or broken elements
3. UI/UX issues
4. Whether this looks like a production-ready interface
5. Overall assessment (1-10 score)

Response format: Brief analysis in 3-4 sentences."""
                
                analysis = self.call_llama(llama_prompt)
                test_result["analysis"] = analysis
                
                # Check for common issues
                if "error" in response.text.lower() or "404" in response.text:
                    test_result["issues"].append("Error indicators found in content")
                if response.status_code != 200:
                    test_result["issues"].append(f"Non-200 status code: {response.status_code}")
                if len(response.content) < 100:
                    test_result["issues"].append("Suspiciously short content")
                    
            else:
                test_result["issues"].append(f"HTTP {response.status_code} error")
                
        except requests.exceptions.Timeout:
            test_result["issues"].append("Request timeout")
        except requests.exceptions.ConnectionError:
            test_result["issues"].append("Connection error - server may be down")
        except Exception as e:
            test_result["issues"].append(f"Unexpected error: {str(e)}")
            
        return test_result

    def test_specific_workflows(self) -> List[Dict[str, Any]]:
        """Test specific CMMS workflows"""
        workflow_tests = []
        
        # Technician Work Order Workflow Test
        workflow_test = {
            "workflow_name": "Technician Work Order Management",
            "test_steps": [
                "Access technician portal",
                "View work orders list", 
                "Open individual work order",
                "Check for time tracking capabilities",
                "Check for photo upload functionality",
                "Check for work order completion features",
                "Check for downtime tracking button"
            ],
            "status": "testing",
            "findings": [],
            "score": 0
        }
        
        # Test technician portal
        tech_portal_url = f"{self.base_url}/technicians/portal"
        try:
            response = requests.get(tech_portal_url, timeout=10)
            if response.status_code == 200:
                content = response.text
                
                # Llama analysis for technician workflow
                llama_prompt = f"""Analyze this technician portal page for work order management capabilities:

Content: {content[:3000]}

Specifically look for:
1. Work order viewing/listing functionality
2. Time tracking features
3. Photo upload capabilities  
4. Work order completion/editing
5. Downtime tracking buttons
6. Mobile-friendly interface elements

Rate each feature as: Present, Partially Present, Missing, or Unknown
Provide overall workflow completeness score (1-10)."""

                analysis = self.call_llama(llama_prompt)
                workflow_test["findings"].append(f"Technician Portal Analysis: {analysis}")
                
                # Check for key elements
                key_elements = [
                    ("time tracking", "time|clock|duration|hours"),
                    ("photo upload", "upload|photo|image|camera"),
                    ("work order", "work.order|workorder|task"),
                    ("completion", "complete|finish|done|submit"),
                    ("downtime", "downtime|offline|maintenance")
                ]
                
                for element_name, pattern in key_elements:
                    import re
                    if re.search(pattern, content, re.IGNORECASE):
                        workflow_test["findings"].append(f"✅ Found {element_name} functionality")
                    else:
                        workflow_test["findings"].append(f"❌ Missing {element_name} functionality")
                        
            else:
                workflow_test["findings"].append(f"❌ Technician portal inaccessible (HTTP {response.status_code})")
                
        except Exception as e:
            workflow_test["findings"].append(f"❌ Error testing technician portal: {str(e)}")
            
        workflow_tests.append(workflow_test)
        
        # Asset Management Workflow Test
        asset_workflow = {
            "workflow_name": "Asset & Manual Management",
            "test_steps": [
                "Access asset dashboard",
                "Check equipment listings",
                "Look for manual/documentation access",
                "Check component documentation",
                "Verify photo linking capabilities"
            ],
            "status": "testing", 
            "findings": [],
            "score": 0
        }
        
        # Test asset management
        assets_url = f"{self.base_url}/assets/dashboard"
        try:
            response = requests.get(assets_url, timeout=10)
            if response.status_code == 200:
                content = response.text
                
                llama_prompt = f"""Analyze this asset management page:

Content: {content[:3000]}

Look for:
1. Equipment/asset listings
2. Manual/documentation access
3. Component documentation
4. Photo/attachment capabilities
5. Asset lifecycle tracking

Rate completeness and identify missing features."""

                analysis = self.call_llama(llama_prompt)
                asset_workflow["findings"].append(f"Asset Management Analysis: {analysis}")
                
        except Exception as e:
            asset_workflow["findings"].append(f"❌ Error testing asset management: {str(e)}")
            
        workflow_tests.append(asset_workflow)
        
        return workflow_tests

    def run_comprehensive_test(self) -> Dict[str, Any]:
        """Run complete CMMS application test suite"""
        print(f"🧪 Starting comprehensive CMMS testing for {self.base_url}")
        print(f"⏰ Test started at: {datetime.now()}")
        
        # Test URL accessibility
        print("\n📡 Testing URL accessibility...")
        for url_name, endpoint in self.test_urls.items():
            print(f"  Testing {url_name}...")
            result = self.test_url_accessibility(url_name, endpoint)
            self.test_results["tests_performed"].append(result)
            
            if result["status"] == "failed":
                self.test_results["issues_found"].append(f"{url_name}: {', '.join(result['issues'])}")
        
        # Test specific workflows
        print("\n🔧 Testing specific workflows...")
        workflow_results = self.test_specific_workflows()
        self.test_results["workflow_tests"] = workflow_results
        
        # Generate overall assessment with Llama
        print("\n🤖 Generating Llama assessment...")
        
        summary_data = {
            "total_urls_tested": len(self.test_urls),
            "successful_urls": len([t for t in self.test_results["tests_performed"] if t["status"] == "passed"]),
            "failed_urls": len([t for t in self.test_results["tests_performed"] if t["status"] == "failed"]),
            "issues_count": len(self.test_results["issues_found"])
        }
        
        llama_assessment_prompt = f"""As an expert CMMS application reviewer, analyze this test summary:

Test Results Summary:
- Total URLs tested: {summary_data['total_urls_tested']}
- Successful: {summary_data['successful_urls']}
- Failed: {summary_data['failed_urls']}
- Issues found: {summary_data['issues_count']}

Key Issues:
{chr(10).join(self.test_results['issues_found'][:5])}

Based on this testing, provide:
1. Overall production readiness score (1-10)
2. Top 3 critical issues that must be fixed
3. Top 3 missing features for production use
4. Overall assessment in 2-3 sentences

Be specific and actionable."""

        overall_assessment = self.call_llama(llama_assessment_prompt)
        self.test_results["llama_assessment"] = overall_assessment
        
        # Calculate overall score
        success_rate = summary_data['successful_urls'] / summary_data['total_urls_tested'] if summary_data['total_urls_tested'] > 0 else 0
        self.test_results["overall_score"] = round(success_rate * 10, 1)
        
        print(f"\n✅ Testing complete! Overall score: {self.test_results['overall_score']}/10")
        
        return self.test_results

    def generate_report(self) -> str:
        """Generate comprehensive test report"""
        report = f"""
# CMMS Application Test Report
**Generated:** {self.test_results['timestamp']}
**Target URL:** {self.test_results['base_url']}
**Overall Score:** {self.test_results['overall_score']}/10

## Executive Summary
{self.test_results.get('llama_assessment', 'Analysis pending...')}

## URL Accessibility Results
"""
        
        for test in self.test_results["tests_performed"]:
            status_emoji = "✅" if test["status"] == "passed" else "❌"
            report += f"\n### {status_emoji} {test['test_name']}\n"
            report += f"- **URL:** {test['url']}\n"
            report += f"- **Status Code:** {test['status_code']}\n"
            report += f"- **Response Time:** {test['response_time']}ms\n"
            
            if test.get("analysis"):
                report += f"- **Analysis:** {test['analysis']}\n"
            
            if test["issues"]:
                report += f"- **Issues:** {', '.join(test['issues'])}\n"
        
        if self.test_results.get("workflow_tests"):
            report += "\n## Workflow Testing Results\n"
            for workflow in self.test_results["workflow_tests"]:
                report += f"\n### {workflow['workflow_name']}\n"
                for finding in workflow["findings"]:
                    report += f"- {finding}\n"
        
        if self.test_results["issues_found"]:
            report += "\n## Critical Issues Found\n"
            for i, issue in enumerate(self.test_results["issues_found"], 1):
                report += f"{i}. {issue}\n"
        
        report += "\n## Recommendations for Production Readiness\n"
        report += "1. Fix all failed URL endpoints\n"
        report += "2. Implement missing photo upload functionality\n"
        report += "3. Add proper time tracking for work orders\n"
        report += "4. Implement downtime tracking buttons\n"
        report += "5. Add bulk invoice processing capabilities\n"
        report += "6. Improve manager approval workflows\n"
        report += "7. Enhance mobile responsiveness for technicians\n"
        
        return report

def main():
    """Main testing function"""
    # Check both possible ports
    test_urls = [
        "http://35.237.149.25:8501",
        "http://35.237.149.25:8080", 
        "http://35.237.149.25:3000"
    ]
    
    active_url = None
    for url in test_urls:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                active_url = url
                break
        except:
            continue
    
    if not active_url:
        print("❌ No accessible CMMS application found on any expected port")
        print("Checked ports: 8501, 8080, 3000")
        return
        
    print(f"🎯 Found active CMMS application at: {active_url}")
    
    # Initialize tester
    tester = CMMSTester(active_url)
    
    # Run comprehensive test
    results = tester.run_comprehensive_test()
    
    # Generate and save report
    report = tester.generate_report()
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Save JSON results
    with open(f"cmms_test_results_{timestamp}.json", "w") as f:
        json.dump(results, f, indent=2)
    
    # Save report
    with open(f"cmms_test_report_{timestamp}.md", "w") as f:
        f.write(report)
    
    print(f"\n📄 Results saved:")
    print(f"   - cmms_test_results_{timestamp}.json")
    print(f"   - cmms_test_report_{timestamp}.md")
    
    # Print summary
    print("\n" + "="*60)
    print("TESTING SUMMARY")
    print("="*60)
    print(report)

if __name__ == "__main__":
    main()