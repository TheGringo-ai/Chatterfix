#!/usr/bin/env python3
"""
ChatterFix CMMS - Simple Production Deploy
"""

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from admin import admin_router
from ai import ai_router

# Create FastAPI app
app = FastAPI(
    title="ChatterFix CMMS",
    version="3.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include working routers only
app.include_router(admin_router)
app.include_router(ai_router)

@app.get("/", response_class=HTMLResponse)
async def main_dashboard():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix CMMS v3.0.0</title>
        <style>
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
                margin: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
            }
            .container { max-width: 800px; padding: 2rem; }
            h1 { font-size: 4rem; margin-bottom: 1rem; }
            .version { 
                background: linear-gradient(45deg, #11998e, #38ef7d);
                padding: 10px 20px;
                border-radius: 25px;
                font-size: 1rem;
                font-weight: bold;
                display: inline-block;
                margin: 1rem 0;
            }
            .nav-grid { 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
                gap: 1.5rem; 
                margin-top: 2rem;
            }
            .nav-btn { 
                background: rgba(255,255,255,0.1); 
                border: none;
                color: white;
                padding: 1.5rem;
                border-radius: 12px;
                cursor: pointer;
                text-decoration: none;
                display: block;
                transition: all 0.3s;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }
            .nav-btn:hover { 
                transform: translateY(-5px); 
                background: rgba(255,255,255,0.2);
            }
            .nav-btn h3 { margin: 0 0 0.5rem 0; font-size: 1.2rem; }
            .nav-btn p { margin: 0; opacity: 0.9; font-size: 0.9rem; }
            .status { 
                position: fixed; 
                top: 20px; 
                right: 20px; 
                background: #38ef7d; 
                padding: 10px 15px; 
                border-radius: 10px; 
                font-size: 0.8rem;
            }
        </style>
    </head>
    <body>
        <div class="status">🟢 System Online</div>
        
        <div class="container">
            <h1>⚡ ChatterFix CMMS</h1>
            <div class="version">v3.0.0 - Production Ready</div>
            <p>Comprehensive Maintenance Management • AI-Powered • Modular Architecture</p>
            
            <div class="nav-grid">
                <a href="/admin/dashboard" class="nav-btn">
                    <h3>⚖️ Admin Dashboard</h3>
                    <p>User management & system configuration</p>
                </a>
                
                <a href="/ai/dashboard" class="nav-btn">
                    <h3>🤖 AI Assistant</h3>
                    <p>Multi-model AI chat & predictive analytics</p>
                </a>
                
                <a href="/health" class="nav-btn">
                    <h3>🏥 System Health</h3>
                    <p>API status & health monitoring</p>
                </a>
                
                <a href="http://www.chatterfix.com/admin" class="nav-btn">
                    <h3>🌐 Production Portal</h3>
                    <p>Access via chatterfix.com domain</p>
                </a>
            </div>
        </div>
    </body>
    </html>
    """

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "ChatterFix CMMS v3.0.0",
        "modules": {
            "admin": "operational",
            "ai": "operational"
        },
        "ollama": "connected",
        "timestamp": "2025-09-01T23:45:00Z"
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 3000))
    uvicorn.run("simple_app:app", host="0.0.0.0", port=port, reload=False)