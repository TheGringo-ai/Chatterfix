#!/usr/bin/env python3
"""
CMMS Work Orders Module
Work order creation, tracking, assignment and lifecycle management
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Work orders router
workorders_router = APIRouter(prefix="/workorders", tags=["workorders"])

# Data models
class WorkOrder(BaseModel):
    id: str
    title: str
    description: str
    asset_id: str
    type: str  # reactive, preventive, predictive
    priority: str
    status: str
    created_date: str
    created_by: str
    assigned_to: Optional[str] = None
    due_date: Optional[str] = None
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    cost: Optional[float] = None

class WorkOrderComment(BaseModel):
    id: str
    work_order_id: str
    author: str
    timestamp: str
    comment: str
    attachments: List[str]

class WorkOrderStatus(BaseModel):
    id: str
    work_order_id: str
    status: str
    timestamp: str
    updated_by: str
    notes: str

# Mock database
work_orders_db = [
    {
        "id": "WO-001",
        "title": "Emergency Generator Repair",
        "description": "Generator failed to start during weekly test. Investigate and repair fuel system issue.",
        "asset_id": "AST-004",
        "type": "reactive",
        "priority": "urgent",
        "status": "in_progress",
        "created_date": "2025-08-30",
        "created_by": "John Smith",
        "assigned_to": "TECH-001",
        "due_date": "2025-09-02",
        "estimated_hours": 6.0,
        "actual_hours": 3.5,
        "cost": 450.00
    },
    {
        "id": "WO-002",
        "title": "Conveyor Belt Inspection",
        "description": "Monthly preventive maintenance inspection of main conveyor system.",
        "asset_id": "AST-002",
        "type": "preventive", 
        "priority": "medium",
        "status": "assigned",
        "created_date": "2025-08-31",
        "created_by": "System",
        "assigned_to": "TECH-002",
        "due_date": "2025-09-05",
        "estimated_hours": 2.0,
        "actual_hours": None,
        "cost": None
    },
    {
        "id": "WO-003",
        "title": "HVAC Filter Replacement", 
        "description": "Replace air filters in main HVAC unit and check system performance.",
        "asset_id": "AST-003",
        "type": "preventive",
        "priority": "low",
        "status": "open",
        "created_date": "2025-08-28",
        "created_by": "Sarah Davis",
        "assigned_to": None,
        "due_date": "2025-09-10",
        "estimated_hours": 4.0,
        "actual_hours": None,
        "cost": None
    },
    {
        "id": "WO-004",
        "title": "Packaging Machine Motor Bearing",
        "description": "Replace motor bearing on packaging line. Machine making unusual noise and vibration detected.",
        "asset_id": "AST-005",
        "type": "predictive",
        "priority": "high",
        "status": "parts_required",
        "created_date": "2025-08-29",
        "created_by": "Mike Johnson",
        "assigned_to": "TECH-004",
        "due_date": "2025-09-03",
        "estimated_hours": 8.0,
        "actual_hours": 2.0,
        "cost": 1200.00
    },
    {
        "id": "WO-005",
        "title": "Compressor Oil Analysis",
        "description": "Collect and analyze oil sample from primary air compressor for contamination.",
        "asset_id": "AST-001",
        "type": "preventive",
        "priority": "low",
        "status": "completed",
        "created_date": "2025-08-25",
        "created_by": "System",
        "assigned_to": "TECH-001",
        "due_date": "2025-08-30",
        "estimated_hours": 1.0,
        "actual_hours": 0.5,
        "cost": 75.00
    }
]

work_order_comments_db = [
    {
        "id": "CMT-001",
        "work_order_id": "WO-001",
        "author": "TECH-001",
        "timestamp": "2025-08-30 14:30:00",
        "comment": "Initial diagnosis complete. Fuel pump needs replacement. Ordering part now.",
        "attachments": ["fuel_pump_photo.jpg"]
    },
    {
        "id": "CMT-002",
        "work_order_id": "WO-001",
        "author": "TECH-001",
        "timestamp": "2025-08-31 09:15:00",
        "comment": "Part received. Installing new fuel pump. Estimated completion by 2 PM.",
        "attachments": []
    },
    {
        "id": "CMT-003",
        "work_order_id": "WO-004",
        "author": "TECH-004",
        "timestamp": "2025-08-29 16:45:00",
        "comment": "Confirmed bearing failure. Ordered replacement bearing PRT-001. Expected delivery tomorrow.",
        "attachments": ["bearing_inspection.jpg", "vibration_data.pdf"]
    }
]

work_order_status_history_db = [
    {
        "id": "STS-001",
        "work_order_id": "WO-001",
        "status": "open",
        "timestamp": "2025-08-30 10:00:00",
        "updated_by": "John Smith",
        "notes": "Work order created"
    },
    {
        "id": "STS-002",
        "work_order_id": "WO-001", 
        "status": "assigned",
        "timestamp": "2025-08-30 10:30:00",
        "updated_by": "System",
        "notes": "Assigned to TECH-001"
    },
    {
        "id": "STS-003",
        "work_order_id": "WO-001",
        "status": "in_progress",
        "timestamp": "2025-08-30 14:00:00",
        "updated_by": "TECH-001",
        "notes": "Started troubleshooting"
    }
]

@workorders_router.get("/dashboard", response_class=HTMLResponse)
async def workorders_dashboard():
    """Work orders dashboard"""
    total_work_orders = len(work_orders_db)
    open_work_orders = len([wo for wo in work_orders_db if wo['status'] in ['open', 'assigned']])
    in_progress = len([wo for wo in work_orders_db if wo['status'] == 'in_progress'])
    overdue = len([wo for wo in work_orders_db if wo.get('due_date') and wo['due_date'] < datetime.now().strftime("%Y-%m-%d") and wo['status'] not in ['completed', 'cancelled']])
    completed_today = len([wo for wo in work_orders_db if wo['status'] == 'completed'])
    
    work_orders_html = "".join([
        f"""
        <tr data-status="{wo['status']}" data-priority="{wo['priority']}" data-type="{wo['type']}" data-technician="{wo.get('assigned_to', '')}" data-title="{wo['title'].lower()}">
            <td><strong>{wo['id']}</strong></td>
            <td>
                {wo['title'][:30]}{'...' if len(wo['title']) > 30 else ''}
                <div style="font-size: 0.8rem; color: #718096;">{wo['description'][:40]}{'...' if len(wo['description']) > 40 else ''}</div>
            </td>
            <td>{wo['asset_id']}</td>
            <td>{wo['type'].title()}</td>
            <td><span class="priority-{wo['priority']}">{wo['priority'].title()}</span></td>
            <td><span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span></td>
            <td>{wo.get('assigned_to', 'Unassigned')}</td>
            <td>{wo.get('due_date', 'Not set')}</td>
            <td>
                <button class="btn btn-sm" onclick="viewWorkOrder('{wo['id']}')">View</button>
                <button class="btn btn-sm btn-warning" onclick="editWorkOrder('{wo['id']}')">Edit</button>
                {(f'<button class="btn btn-sm btn-success" onclick="startWork(&quot;{wo["id"]}&quot;)">Start</button>' if wo["status"] == "assigned" else '')}
                {(f'<button class="btn btn-sm btn-success" onclick="completeWork(&quot;{wo["id"]}&quot;)">Complete</button>' if wo["status"] == "in_progress" else '')}
            </td>
        </tr>
        """ for wo in work_orders_db if wo['status'] != 'completed'
    ])

    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix Work Orders</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 1rem 0; }}
            .stat-value {{ font-size: 2rem; font-weight: bold; }}
            .status-good {{ color: #38a169; }}
            .status-warning {{ color: #d69e2e; }}
            .status-critical {{ color: #e53e3e; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-success {{ background: #38a169; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .btn-sm {{ padding: 0.25rem 0.5rem; font-size: 0.875rem; }}
            .table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
            .table th, .table td {{ padding: 0.75rem; text-align: left; border-bottom: 1px solid #e2e8f0; }}
            .table th {{ background: #edf2f7; font-weight: 600; }}
            .filter-bar {{ background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; align-items: center; }}
            .filter-bar select, .filter-bar input {{ padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .wo-card {{ border-left: 4px solid #4299e1; margin-bottom: 1rem; }}
            .wo-card.urgent {{ border-left-color: #e53e3e; }}
            .wo-card.high {{ border-left-color: #d69e2e; }}
            .wo-card.medium {{ border-left-color: #38a169; }}
            .wo-card.low {{ border-left-color: #a0aec0; }}
            .status-badge {{ padding: 0.25rem 0.5rem; border-radius: 12px; font-size: 0.75rem; font-weight: 500; }}
            .status-open {{ background: #e2e8f0; color: #4a5568; }}
            .status-assigned {{ background: #bee3f8; color: #2b6cb0; }}
            .status-in_progress {{ background: #c6f6d5; color: #276749; }}
            .status-completed {{ background: #c6f6d5; color: #276749; }}
            .status-parts_required {{ background: #fef5e7; color: #d69e2e; }}
            .priority-urgent {{ color: #e53e3e; font-weight: bold; }}
            .priority-high {{ color: #d69e2e; font-weight: bold; }}
            .priority-medium {{ color: #38a169; }}
            .priority-low {{ color: #a0aec0; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>=� ChatterFix Work Orders</h1>
            <p>Work Order Management, Tracking & Assignment</p>
        </div>
        
        <div class="container">
            <!-- Stats Overview -->
            <div class="grid">
                <div class="card">
                    <h3>=� Work Order Overview</h3>
                    <div class="stat">
                        <span>Total Work Orders</span>
                        <span class="stat-value">{total_work_orders}</span>
                    </div>
                    <div class="stat">
                        <span>Open/Assigned</span>
                        <span class="stat-value status-warning">{open_work_orders}</span>
                    </div>
                    <div class="stat">
                        <span>In Progress</span>
                        <span class="stat-value status-good">{in_progress}</span>
                    </div>
                    <div class="stat">
                        <span>Overdue</span>
                        <span class="stat-value status-critical">{overdue}</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>=� Quick Actions</h3>
                    <button class="btn" onclick="createWorkOrder()">Create Work Order</button>
                    <button class="btn btn-warning" onclick="assignWorkOrders()">Bulk Assign</button>
                    <button class="btn btn-success" onclick="generateReports()">Generate Reports</button>
                    <button class="btn" onclick="viewCalendar()">Calendar View</button>
                    <button class="btn" onclick="exportData()">Export Data</button>
                </div>
                
                <div class="card">
                    <h3>=� Performance Metrics</h3>
                    <div class="stat">
                        <span>Avg. Response Time</span>
                        <span class="stat-value">2.3 hrs</span>
                    </div>
                    <div class="stat">
                        <span>Completion Rate</span>
                        <span class="stat-value status-good">94.2%</span>
                    </div>
                    <div class="stat">
                        <span>On-Time Delivery</span>
                        <span class="stat-value status-good">87.5%</span>
                    </div>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <label>Filter by:</label>
                <select id="statusFilter" onchange="filterWorkOrders()">
                    <option value="">All Status</option>
                    <option value="open">Open</option>
                    <option value="assigned">Assigned</option>
                    <option value="in_progress">In Progress</option>
                    <option value="parts_required">Parts Required</option>
                    <option value="completed">Completed</option>
                </select>
                <select id="priorityFilter" onchange="filterWorkOrders()">
                    <option value="">All Priority</option>
                    <option value="urgent">Urgent</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                </select>
                <select id="typeFilter" onchange="filterWorkOrders()">
                    <option value="">All Types</option>
                    <option value="reactive">Reactive</option>
                    <option value="preventive">Preventive</option>
                    <option value="predictive">Predictive</option>
                </select>
                <select id="technicianFilter" onchange="filterWorkOrders()">
                    <option value="">All Technicians</option>
                    <option value="TECH-001">John Smith</option>
                </select>
                <input id="searchFilter" type="text" placeholder="Search titles..." oninput="filterWorkOrders()" />
            </div>

            <!-- Work Orders Table -->
            <div class="card">
                <table class="table" id="workOrdersTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Asset</th>
                            <th>Type</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Assigned To</th>
                            <th>Due Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {work_orders_html}
                    </tbody>
                </table>
            </div>
            
            <!-- Recent Activity -->
            <div class="grid" style="margin-top: 2rem;">
                <div class="card">
                    <h3>=� Recent Comments</h3>
                    <div>
                        {chr(10).join([f'''
                        <div style="border-bottom: 1px solid #e2e8f0; padding: 0.75rem 0;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                                <div style="font-weight: 500;">WO-{comment['work_order_id'][-3:]}</div>
                                <div style="font-size: 0.8rem; color: #718096;">{comment['timestamp']}</div>
                            </div>
                            <div style="font-size: 0.9rem; color: #4a5568;">{comment['comment'][:80]}{'...' if len(comment['comment']) > 80 else ''}</div>
                            <div style="font-size: 0.8rem; color: #718096;">by {comment['author']}</div>
                        </div>''' for comment in work_order_comments_db[-5:]])}
                    </div>
                </div>
                
                <div class="card">
                    <h3>= Status Changes</h3>
                    <div>
                        {chr(10).join([f'''
                        <div style="border-bottom: 1px solid #e2e8f0; padding: 0.75rem 0;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <div style="font-weight: 500;">WO-{status['work_order_id'][-3:]} � {status['status'].replace('_', ' ').title()}</div>
                                    <div style="font-size: 0.8rem; color: #718096;">{status['notes']}</div>
                                </div>
                                <div style="font-size: 0.8rem; color: #718096;">{status['timestamp'][:10]}</div>
                            </div>
                        </div>''' for status in work_order_status_history_db[-5:]])}
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            function filterWorkOrders() {{
                const statusFilter = document.getElementById('statusFilter').value;
                const priorityFilter = document.getElementById('priorityFilter').value;
                const typeFilter = document.getElementById('typeFilter').value;
                const technicianFilter = document.getElementById('technicianFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const rows = document.querySelectorAll('#workOrdersTable tbody tr');
                rows.forEach(row => {{
                    const status = row.dataset.status;
                    const priority = row.dataset.priority;
                    const type = row.dataset.type;
                    const technician = row.dataset.technician;
                    const title = row.dataset.title;
                    
                    const statusMatch = !statusFilter || status === statusFilter;
                    const priorityMatch = !priorityFilter || priority === priorityFilter;
                    const typeMatch = !typeFilter || type === typeFilter;
                    const technicianMatch = !technicianFilter || technician === technicianFilter;
                    const searchMatch = !searchFilter || title.includes(searchFilter);
                    
                    row.style.display = (statusMatch && priorityMatch && typeMatch && technicianMatch && searchMatch) ? '' : 'none';
                }});
            }}
            
            function createWorkOrder() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 700px; width: 90%; max-height: 90%; overflow-y: auto;" onclick="event.stopPropagation()">
                            <h3>Create Work Order</h3>
                            <form id="createWOForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Title:</label><br>
                                    <input type="text" name="title" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Description:</label><br>
                                    <textarea name="description" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 80px;"></textarea>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Asset ID:</label><br>
                                        <select name="asset_id" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="">Select Asset</option>
                                            <option value="AST-001">AST-001 - Air Compressor</option>
                                            <option value="AST-002">AST-002 - Conveyor Belt</option>
                                            <option value="AST-003">AST-003 - HVAC Unit</option>
                                            <option value="AST-004">AST-004 - Generator</option>
                                            <option value="AST-005">AST-005 - Packaging Machine</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Type:</label><br>
                                        <select name="type" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="">Select Type</option>
                                            <option value="reactive">Reactive</option>
                                            <option value="preventive">Preventive</option>
                                            <option value="predictive">Predictive</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Priority:</label><br>
                                        <select name="priority" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="">Select Priority</option>
                                            <option value="urgent">Urgent</option>
                                            <option value="high">High</option>
                                            <option value="medium">Medium</option>
                                            <option value="low">Low</option>
                                        </select>
                                    </div>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Assigned To:</label><br>
                                        <select name="assigned_to" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="">Unassigned</option>
                                            <option value="TECH-001">John Smith</option>
                                            <option value="TECH-002">Mike Johnson</option>
                                            <option value="TECH-003">Sarah Davis</option>
                                            <option value="TECH-004">Carlos Rodriguez</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Due Date:</label><br>
                                        <input type="date" name="due_date" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Estimated Hours:</label><br>
                                    <input type="number" step="0.5" name="estimated_hours" style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" class="btn">Create Work Order</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('createWOForm').addEventListener('submit', function(e) {{
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const woData = Object.fromEntries(formData);
                    
                    fetch('/workorders', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(woData)
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Work order created:', data);
                        location.reload();
                    }});
                }});
            }}
            
            function closeModal(event) {{
                if (event.target === event.currentTarget) {{
                    document.body.removeChild(event.currentTarget);
                }}
            }}
            
            function viewWorkOrder(woId) {{
                window.open(`/cmms/workorders/${{woId}}/view`, '_blank');
            }}
            
            function editWorkOrder(woId) {{
                window.location.href = `/workorders/${{woId}}/edit`;
            }}
            
            function startWork(woId) {{
                fetch(`/workorders/${{woId}}/start`, {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ status: 'in_progress' }})
                }})
                .then(() => location.reload());
            }}
            
            function completeWork(woId) {{
                const hours = prompt('Enter actual hours worked:');
                const notes = prompt('Enter completion notes:');
                
                if (hours) {{
                    fetch(`/workorders/${{woId}}/complete`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ 
                            actual_hours: parseFloat(hours),
                            notes: notes || 'Work completed'
                        }})
                    }})
                    .then(() => location.reload());
                }}
            }}
            
            function assignWorkOrders() {{
                window.location.href = '/workorders/bulk-assign';
            }}
            
            function generateReports() {{
                window.location.href = '/workorders/reports';
            }}
            
            function viewCalendar() {{
                window.location.href = '/workorders/calendar';
            }}
            
            function exportData() {{
                window.open('/workorders/export', '_blank');
            }}
        </script>
    </body>
    </html>
    """

@workorders_router.get("/")
async def get_work_orders(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    type: Optional[str] = Query(None),
    assigned_to: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all work orders with optional filtering"""
    filtered_work_orders = work_orders_db
    
    if status:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo['status'] == status]
    if priority:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo['priority'] == priority]
    if type:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo['type'] == type]
    if assigned_to:
        filtered_work_orders = [wo for wo in filtered_work_orders if wo.get('assigned_to') == assigned_to]
    
    return filtered_work_orders

@workorders_router.get("/{work_order_id}")
async def get_work_order_details(work_order_id: str) -> Dict:
    """Get specific work order details"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # Get comments and status history
    comments = [c for c in work_order_comments_db if c['work_order_id'] == work_order_id]
    status_history = [s for s in work_order_status_history_db if s['work_order_id'] == work_order_id]
    
    return {
        "work_order": work_order,
        "comments": comments,
        "status_history": status_history,
        "metrics": {
            "days_open": (datetime.now() - datetime.strptime(work_order['created_date'], "%Y-%m-%d")).days,
            "estimated_vs_actual": {
                "estimated_hours": work_order.get('estimated_hours'),
                "actual_hours": work_order.get('actual_hours'),
                "variance_percent": ((work_order.get('actual_hours', 0) - work_order.get('estimated_hours', 0)) / work_order.get('estimated_hours', 1)) * 100 if work_order.get('estimated_hours') else 0
            },
            "on_schedule": work_order.get('due_date', '') >= datetime.now().strftime("%Y-%m-%d") if work_order.get('due_date') else True
        }
    }

@workorders_router.post("/")
async def create_work_order(work_order_data: Dict[str, Any]) -> Dict:
    """Create new work order"""
    work_order_id = f"WO-{len(work_orders_db) + 1:03d}"
    
    new_work_order = {
        "id": work_order_id,
        "title": work_order_data["title"],
        "description": work_order_data["description"],
        "asset_id": work_order_data["asset_id"],
        "type": work_order_data["type"],
        "priority": work_order_data["priority"],
        "status": "assigned" if work_order_data.get("assigned_to") else "open",
        "created_date": datetime.now().strftime("%Y-%m-%d"),
        "created_by": work_order_data.get("created_by", "System"),
        "assigned_to": work_order_data.get("assigned_to"),
        "due_date": work_order_data.get("due_date"),
        "estimated_hours": float(work_order_data["estimated_hours"]) if work_order_data.get("estimated_hours") else None,
        "actual_hours": None,
        "cost": None
    }
    
    work_orders_db.append(new_work_order)
    
    # Create initial status entry
    status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
    status_entry = {
        "id": status_id,
        "work_order_id": work_order_id,
        "status": new_work_order["status"],
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_by": work_order_data.get("created_by", "System"),
        "notes": "Work order created"
    }
    work_order_status_history_db.append(status_entry)
    
    logger.info(f"Work order created: {work_order_id}")
    return new_work_order

@workorders_router.put("/{work_order_id}")
async def update_work_order(work_order_id: str, update_data: Dict[str, Any]) -> Dict:
    """Update work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    # Track status changes
    old_status = work_order.get('status')
    work_order.update(update_data)
    
    # If status changed, record it
    if 'status' in update_data and update_data['status'] != old_status:
        status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
        status_entry = {
            "id": status_id,
            "work_order_id": work_order_id,
            "status": update_data['status'],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "updated_by": update_data.get("updated_by", "System"),
            "notes": update_data.get("status_notes", f"Status changed to {update_data['status']}")
        }
        work_order_status_history_db.append(status_entry)
    
    logger.info(f"Work order updated: {work_order_id}")
    return work_order

@workorders_router.post("/{work_order_id}/start")
async def start_work_order(work_order_id: str, start_data: Dict[str, Any]) -> Dict:
    """Start work on a work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    work_order['status'] = 'in_progress'
    
    # Record status change
    status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
    status_entry = {
        "id": status_id,
        "work_order_id": work_order_id,
        "status": "in_progress",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_by": start_data.get("updated_by", work_order.get("assigned_to", "System")),
        "notes": "Work started"
    }
    work_order_status_history_db.append(status_entry)
    
    logger.info(f"Work order started: {work_order_id}")
    return {"work_order_id": work_order_id, "status": "in_progress", "started_at": datetime.now().isoformat()}

@workorders_router.post("/{work_order_id}/complete")
async def complete_work_order(work_order_id: str, completion_data: Dict[str, Any]) -> Dict:
    """Complete a work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    work_order['status'] = 'completed'
    work_order['actual_hours'] = completion_data.get('actual_hours')
    work_order['cost'] = completion_data.get('cost')
    
    completion_date = datetime.now().strftime("%Y-%m-%d")
    
    # Record status change
    status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
    status_entry = {
        "id": status_id,
        "work_order_id": work_order_id,
        "status": "completed",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_by": completion_data.get("updated_by", work_order.get("assigned_to", "System")),
        "notes": completion_data.get("notes", "Work completed")
    }
    work_order_status_history_db.append(status_entry)
    
    # Add completion comment if notes provided
    if completion_data.get("notes"):
        comment_id = f"CMT-{len(work_order_comments_db) + 1:03d}"
        comment = {
            "id": comment_id,
            "work_order_id": work_order_id,
            "author": completion_data.get("updated_by", work_order.get("assigned_to", "System")),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "comment": f"Work completed: {completion_data['notes']}",
            "attachments": []
        }
        work_order_comments_db.append(comment)
    
    logger.info(f"Work order completed: {work_order_id}")
    return {
        "work_order_id": work_order_id,
        "status": "completed",
        "completion_date": completion_date,
        "actual_hours": completion_data.get('actual_hours'),
        "cost": completion_data.get('cost')
    }

@workorders_router.post("/{work_order_id}/comments")
async def add_work_order_comment(work_order_id: str, comment_data: Dict[str, Any]) -> Dict:
    """Add comment to work order"""
    work_order = next((wo for wo in work_orders_db if wo['id'] == work_order_id), None)
    if not work_order:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    comment_id = f"CMT-{len(work_order_comments_db) + 1:03d}"
    comment = {
        "id": comment_id,
        "work_order_id": work_order_id,
        "author": comment_data["author"],
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "comment": comment_data["comment"],
        "attachments": comment_data.get("attachments", [])
    }
    
    work_order_comments_db.append(comment)
    
    logger.info(f"Comment added to work order: {work_order_id}")
    return comment

@workorders_router.get("/reports/summary")
async def get_work_orders_summary() -> Dict:
    """Get work orders summary report"""
    total_work_orders = len(work_orders_db)
    
    # Status breakdown
    status_breakdown = {}
    for wo in work_orders_db:
        status = wo['status']
        status_breakdown[status] = status_breakdown.get(status, 0) + 1
    
    # Priority breakdown
    priority_breakdown = {}
    for wo in work_orders_db:
        priority = wo['priority']
        priority_breakdown[priority] = priority_breakdown.get(priority, 0) + 1
    
    # Type breakdown
    type_breakdown = {}
    for wo in work_orders_db:
        wo_type = wo['type']
        type_breakdown[wo_type] = type_breakdown.get(wo_type, 0) + 1
    
    # Calculate metrics
    completed_work_orders = [wo for wo in work_orders_db if wo['status'] == 'completed']
    total_actual_hours = sum(wo.get('actual_hours', 0) for wo in completed_work_orders)
    total_estimated_hours = sum(wo.get('estimated_hours', 0) for wo in completed_work_orders if wo.get('estimated_hours'))
    total_cost = sum(wo.get('cost', 0) for wo in completed_work_orders)
    
    # On-time completion
    on_time_completed = 0
    for wo in completed_work_orders:
        if wo.get('due_date'):
            # Simplified check - in real implementation would compare completion date to due date
            on_time_completed += 1
    
    on_time_rate = (on_time_completed / len(completed_work_orders) * 100) if completed_work_orders else 0
    
    return {
        "total_work_orders": total_work_orders,
        "status_breakdown": status_breakdown,
        "priority_breakdown": priority_breakdown,
        "type_breakdown": type_breakdown,
        "metrics": {
            "completion_rate": len(completed_work_orders) / total_work_orders * 100 if total_work_orders else 0,
            "on_time_rate": on_time_rate,
            "average_actual_hours": total_actual_hours / len(completed_work_orders) if completed_work_orders else 0,
            "hours_variance": ((total_actual_hours - total_estimated_hours) / total_estimated_hours * 100) if total_estimated_hours else 0,
            "total_cost": total_cost,
            "average_cost_per_wo": total_cost / len(completed_work_orders) if completed_work_orders else 0
        },
        "trends": {
            "monthly_wo_count": [45, 52, 38, 61, 47, 55],  # Mock data
            "completion_time_trend": [3.2, 2.8, 3.1, 2.5, 2.3, 2.7],  # Days
            "cost_trend": [250, 280, 310, 265, 290, 275]  # Average cost
        },
        "generated_at": datetime.now().isoformat()
    }

@workorders_router.get("/calendar")
async def get_work_orders_calendar(
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None)
) -> List[Dict]:
    """Get work orders for calendar view"""
    calendar_work_orders = []
    
    for wo in work_orders_db:
        if wo.get('due_date'):
            # Filter by date range if provided
            if start_date and wo['due_date'] < start_date:
                continue
            if end_date and wo['due_date'] > end_date:
                continue
            
            calendar_work_orders.append({
                "id": wo['id'],
                "title": wo['title'],
                "start": wo['due_date'],
                "asset_id": wo['asset_id'],
                "priority": wo['priority'],
                "status": wo['status'],
                "assigned_to": wo.get('assigned_to'),
                "estimated_hours": wo.get('estimated_hours'),
                "color": {
                    "urgent": "#e53e3e",
                    "high": "#d69e2e", 
                    "medium": "#38a169",
                    "low": "#4299e1"
                }.get(wo['priority'], "#4299e1")
            })
    
    return calendar_work_orders

@workorders_router.post("/bulk-assign")
async def bulk_assign_work_orders(assignment_data: Dict[str, Any]) -> Dict:
    """Bulk assign work orders to technicians"""
    work_order_ids = assignment_data["work_order_ids"]
    technician_id = assignment_data["technician_id"]
    
    assigned_count = 0
    errors = []
    
    for wo_id in work_order_ids:
        work_order = next((wo for wo in work_orders_db if wo['id'] == wo_id), None)
        if work_order:
            work_order['assigned_to'] = technician_id
            work_order['status'] = 'assigned' if work_order['status'] == 'open' else work_order['status']
            assigned_count += 1
            
            # Record status change
            status_id = f"STS-{len(work_order_status_history_db) + 1:03d}"
            status_entry = {
                "id": status_id,
                "work_order_id": wo_id,
                "status": work_order['status'],
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "updated_by": assignment_data.get("assigned_by", "System"),
                "notes": f"Bulk assigned to {technician_id}"
            }
            work_order_status_history_db.append(status_entry)
        else:
            errors.append(f"Work order {wo_id} not found")
    
    logger.info(f"Bulk assigned {assigned_count} work orders to {technician_id}")
    return {
        "assigned_count": assigned_count,
        "errors": errors,
        "technician_id": technician_id
    }

@workorders_router.get("/export/csv")
async def export_work_orders_csv() -> Dict:
    """Export work orders to CSV"""
    import io
    import csv
    
    output = io.StringIO()
    
    # Define CSV columns
    fieldnames = ['id', 'title', 'description', 'asset_id', 'type', 'priority', 'status', 
                  'created_date', 'created_by', 'assigned_to', 'due_date', 'estimated_hours', 
                  'actual_hours', 'cost']
    
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    
    for wo in work_orders_db:
        writer.writerow({field: wo.get(field, '') for field in fieldnames})
    
    return {
        "filename": f"chatterfix_workorders_{datetime.now().strftime('%Y%m%d')}.csv",
        "content": output.getvalue(),
        "content_type": "text/csv"
    }

@workorders_router.get("/{work_order_id}/view", response_class=HTMLResponse)
async def view_work_order_page(work_order_id: str):
    """Display a single work order in a full HTML page."""
    try:
        wo_details = await get_work_order_details(work_order_id)
        wo = wo_details['work_order']
        comments = wo_details['comments']
        status_history = wo_details['status_history']
        metrics = wo_details['metrics']

        # Helper to generate comment HTML
        def generate_comments_html(comments):
            if not comments:
                return "<p>No comments yet.</p>"
            html = ""
            for comment in sorted(comments, key=lambda x: x['timestamp'], reverse=True):
                html += f"""
                <div class="comment-card">
                    <div class="comment-header">
                        <strong>{comment['author']}</strong>
                        <span class="timestamp">{comment['timestamp']}</span>
                    </div>
                    <p>{comment['comment']}</p>
                    {'<p>Attachments: ' + ', '.join(comment['attachments']) + '</p>' if comment['attachments'] else ''}
                </div>
                """
            return html

        # Helper to generate status history HTML
        def generate_status_history_html(status_history):
            if not status_history:
                return "<p>No status history.</p>"
            html = "<ul>"
            for status in sorted(status_history, key=lambda x: x['timestamp']):
                html += f"<li><strong>{status['status'].replace('_', ' ').title()}</strong> at {status['timestamp']} by {status['updated_by']} - <em>{status['notes']}</em></li>"
            html += "</ul>"
            return html

        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Work Order {wo['id']}</title>
            <style>
                /* Using the same styles from the dashboard for consistency */
                body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; color: #2d3748; }}
                .header {{ background: #2d3748; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }}
                .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
                .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 2rem; }}
                .grid {{ display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; }}
                h1, h2, h3 {{ color: #1a202c; }}
                .wo-title {{ font-size: 2.5rem; margin-bottom: 0.5rem; }}
                .status-badge {{ padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 1rem; font-weight: 600; display: inline-block; }}
                .status-open {{ background: #e2e8f0; color: #4a5568; }}
                .status-assigned {{ background: #bee3f8; color: #2b6cb0; }}
                .status-in_progress {{ background: #c6f6d5; color: #276749; }}
                .status-completed {{ background: #c6f6d5; color: #276749; }}
                .status-parts_required {{ background: #fef5e7; color: #d69e2e; }}
                .priority-urgent {{ color: #e53e3e; }}
                .priority-high {{ color: #d69e2e; }}
                .priority-medium {{ color: #38a169; }}
                .priority-low {{ color: #a0aec0; }}
                .details-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1.5rem; }}
                .detail-item {{ background: #edf2f7; padding: 1rem; border-radius: 4px; }}
                .detail-item strong {{ display: block; font-size: 0.8rem; color: #718096; margin-bottom: 0.25rem; }}
                .btn {{ background: #4299e1; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }}
                .btn-warning {{ background: #d69e2e; }}
                .btn-success {{ background: #38a169; }}
                .comment-card {{ border: 1px solid #e2e8f0; border-radius: 4px; padding: 1rem; margin-bottom: 1rem; }}
                .comment-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }}
                .timestamp {{ font-size: 0.8rem; color: #718096; }}
                #ai-assistant {{ margin-top: 1rem; }}
                #ai-input {{ width: calc(100% - 110px); padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px; }}
                #ai-submit {{ padding: 0.5rem 1rem; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>ChatterFix CMMS</h1>
                <a href="/cmms/workorders/dashboard" class="btn">Back to Dashboard</a>
            </div>
            <div class="container">
                <div class="card">
                    <h1 class="wo-title">{wo['title']}</h1>
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem;">
                        <span class="status-badge status-{wo['status']}">{wo['status'].replace('_', ' ').title()}</span>
                        <span class="priority-{wo['priority']}"><strong>Priority:</strong> {wo['priority'].title()}</span>
                    </div>
                    <p>{wo['description']}</p>
                </div>

                <div class="grid">
                    <div class="main-content">
                        <div class="card">
                            <h2>Work Order Details</h2>
                            <div class="details-grid">
                                <div class="detail-item"><strong>Work Order ID</strong> {wo['id']}</div>
                                <div class="detail-item"><strong>Asset ID</strong> <a href="/cmms/assets/{wo['asset_id']}/view">{wo['asset_id']}</a></div>
                                <div class="detail-item"><strong>Work Order Type</strong> {wo['type'].title()}</div>
                                <div class="detail-item"><strong>Created Date</strong> {wo['created_date']}</div>
                                <div class="detail-item"><strong>Created By</strong> {wo['created_by']}</div>
                                <div class="detail-item"><strong>Assigned To</strong> {wo.get('assigned_to', 'Unassigned')}</div>
                                <div class="detail-item"><strong>Due Date</strong> {wo.get('due_date', 'Not set')}</div>
                                <div class="detail-item"><strong>Estimated Hours</strong> {wo.get('estimated_hours', 'N/A')}</div>
                                <div class="detail-item"><strong>Actual Hours</strong> {wo.get('actual_hours', 'N/A')}</div>
                                <div class="detail-item"><strong>Cost</strong> ${wo.get('cost', 0.00):.2f}</div>
                            </div>
                        </div>

                        <div class="card">
                            <h2>Comments & AI Assistant</h2>
                            <div id="comments-section">
                                {generate_comments_html(comments)}
                            </div>
                            <div id="ai-assistant">
                                <h4>AI Assistant (Voice & Text)</h4>
                                <textarea id="ai-input" placeholder="Type or use voice to add a comment, ask for help, or find parts..."></textarea>
                                <button id="ai-submit" class="btn">Submit</button>
                                <button id="voice-input" class="btn">🎤</button>
                            </div>
                        </div>
                    </div>
                    <div class="sidebar">
                        <div class="card">
                            <h2>Actions</h2>
                            <a href="#" class="btn btn-warning" style="display: block; margin-bottom: 1rem; text-align: center;">Edit Work Order</a>
                            <a href="#" class="btn btn-success" style="display: block; text-align: center;">Complete Work Order</a>
                        </div>
                        <div class="card">
                            <h2>Status History</h2>
                            {generate_status_history_html(status_history)}
                        </div>
                        <div class="card">
                            <h2>Metrics</h2>
                            <p><strong>Days Open:</strong> {metrics['days_open']}</p>
                            <p><strong>On Schedule:</strong> {'Yes' if metrics['on_schedule'] else 'No'}</p>
                            <p><strong>Hours Variance:</strong> {metrics['estimated_vs_actual']['variance_percent']:.2f}%</p>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                // Voice to text functionality
                const voiceInputBtn = document.getElementById('voice-input');
                const aiInput = document.getElementById('ai-input');
                const aiSubmitBtn = document.getElementById('ai-submit');

                if ('webkitSpeechRecognition' in window) {{
                    const recognition = new webkitSpeechRecognition();
                    recognition.continuous = false;
                    recognition.interimResults = false;
                    recognition.lang = 'en-US';

                    voiceInputBtn.addEventListener('click', () => {{
                        recognition.start();
                        voiceInputBtn.textContent = '🔴';
                    }});

                    recognition.onresult = (event) => {{
                        const transcript = event.results[0][0].transcript;
                        aiInput.value = transcript;
                        // Optionally submit automatically
                        // submitAiInteraction(transcript); 
                    }};

                    recognition.onerror = (event) => {{
                        console.error('Speech recognition error:', event.error);
                        alert('Error in speech recognition: ' + event.error);
                    }};

                    recognition.onend = () => {{
                        voiceInputBtn.textContent = '🎤';
                    }};
                }} else {{
                    voiceInputBtn.style.display = 'none';
                    // alert('Speech recognition not supported in this browser.');
                }}

                aiSubmitBtn.addEventListener('click', () => {{
                    const text = aiInput.value;
                    if (text) {{
                        submitAiInteraction(text);
                    }}
                }});

                function submitAiInteraction(text) {{
                    console.log('Submitting to AI:', text);
                    // Here you would call your AI backend
                    // For now, we'll just add it as a comment
                    fetch(`/cmms/workorders/{wo['id']}/comments`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{
                            author: 'AI Assistant', // Or the logged in user
                            comment: '(AI Interaction) ' + text
                        }})
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Comment added:', data);
                        location.reload(); // Simple refresh to show new comment
                    }});
                }}
            </script>
        </body>
        </html>
        """
    except HTTPException as e:
        return f"<h1>Error</h1><p>Could not find work order with ID {work_order_id}.</p><p>{e.detail}</p>"