#!/usr/bin/env python3
"""
CMMS Preventive Maintenance Module
Preventive maintenance scheduling, planning, and management
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Preventive maintenance router
preventive_router = APIRouter(prefix="/preventive", tags=["preventive"])

# Data models
class PreventiveMaintenance(BaseModel):
    id: str
    name: str
    asset_id: str
    frequency_days: int
    estimated_duration: float  # hours
    priority: str
    description: str
    instructions: str
    required_parts: List[Dict[str, Any]]
    required_skills: List[str]
    safety_requirements: List[str]
    last_completed: Optional[str] = None
    next_due: str
    status: str

class MaintenanceSchedule(BaseModel):
    id: str
    pm_id: str
    asset_id: str
    scheduled_date: str
    assigned_technician: Optional[str] = None
    estimated_duration: float
    status: str
    notes: Optional[str] = None

class PMTemplate(BaseModel):
    id: str
    name: str
    category: str
    frequency_days: int
    checklist_items: List[Dict[str, str]]
    required_parts: List[Dict[str, Any]]
    safety_requirements: List[str]

# Mock database
preventive_maintenance_db = [
    {
        "id": "PM-001",
        "name": "Compressor Quarterly Service",
        "asset_id": "AST-001",
        "frequency_days": 90,
        "estimated_duration": 6.0,
        "priority": "high",
        "description": "Complete quarterly maintenance for air compressor",
        "instructions": "1. Shutdown compressor\n2. Drain oil and replace\n3. Replace air filters\n4. Check belts and tension\n5. Inspect safety valves\n6. Performance test",
        "required_parts": [
            {"part_id": "PRT-002", "quantity": 1, "description": "Air filter"},
            {"part_id": "PRT-003", "quantity": 4, "description": "Compressor oil"}
        ],
        "required_skills": ["Mechanical", "Electrical", "Pneumatics"],
        "safety_requirements": ["Lockout/Tagout", "PPE", "Confined Space"],
        "last_completed": "2025-08-15",
        "next_due": "2025-11-15",
        "status": "scheduled"
    },
    {
        "id": "PM-002",
        "name": "Conveyor Monthly Inspection",
        "asset_id": "AST-002",
        "frequency_days": 30,
        "estimated_duration": 2.0,
        "priority": "medium",
        "description": "Monthly belt and drive inspection",
        "instructions": "1. Visual belt inspection\n2. Check belt tension\n3. Lubricate bearings\n4. Clean sensors\n5. Test emergency stops",
        "required_parts": [
            {"part_id": "PRT-001", "quantity": 2, "description": "Bearings if needed"}
        ],
        "required_skills": ["Mechanical"],
        "safety_requirements": ["Lockout/Tagout", "PPE"],
        "last_completed": "2025-08-20",
        "next_due": "2025-09-20",
        "status": "due"
    },
    {
        "id": "PM-003",
        "name": "HVAC Seasonal Service",
        "asset_id": "AST-003",
        "frequency_days": 90,
        "estimated_duration": 4.0,
        "priority": "medium",
        "description": "Quarterly HVAC maintenance and filter change",
        "instructions": "1. Replace filters\n2. Clean coils\n3. Check refrigerant levels\n4. Inspect ductwork\n5. Calibrate controls\n6. Performance test",
        "required_parts": [
            {"part_id": "PRT-002", "quantity": 4, "description": "HVAC filters"}
        ],
        "required_skills": ["HVAC", "Electrical", "Refrigeration"],
        "safety_requirements": ["PPE", "Chemical Safety"],
        "last_completed": "2025-06-01",
        "next_due": "2025-09-01",
        "status": "overdue"
    },
    {
        "id": "PM-004",
        "name": "Generator Weekly Test",
        "asset_id": "AST-004",
        "frequency_days": 7,
        "estimated_duration": 1.0,
        "priority": "critical",
        "description": "Weekly generator function test",
        "instructions": "1. Check fuel level\n2. Test start sequence\n3. Run for 30 minutes\n4. Check voltage output\n5. Monitor temperature\n6. Log readings",
        "required_parts": [],
        "required_skills": ["Electrical", "Generator"],
        "safety_requirements": ["PPE", "Ventilation"],
        "last_completed": "2025-08-25",
        "next_due": "2025-09-01",
        "status": "due"
    },
    {
        "id": "PM-005",
        "name": "Packaging Machine Service",
        "asset_id": "AST-005",
        "frequency_days": 30,
        "estimated_duration": 3.0,
        "priority": "high",
        "description": "Monthly packaging equipment maintenance",
        "instructions": "1. Clean and inspect sealing elements\n2. Check pneumatic connections\n3. Lubricate moving parts\n4. Calibrate sensors\n5. Test safety interlocks",
        "required_parts": [
            {"part_id": "PRT-001", "quantity": 2, "description": "Bearings"},
            {"part_id": "PRT-005", "quantity": 1, "description": "Solenoid valve"}
        ],
        "required_skills": ["Mechanical", "Pneumatics", "Electronics"],
        "safety_requirements": ["Lockout/Tagout", "PPE"],
        "last_completed": "2025-07-10",
        "next_due": "2025-08-10",
        "status": "overdue"
    }
]

maintenance_schedule_db = [
    {
        "id": "SCH-001",
        "pm_id": "PM-002",
        "asset_id": "AST-002",
        "scheduled_date": "2025-09-03",
        "assigned_technician": "Mike Johnson",
        "estimated_duration": 2.0,
        "status": "scheduled",
        "notes": "Priority due to production schedule"
    },
    {
        "id": "SCH-002",
        "pm_id": "PM-004",
        "asset_id": "AST-004",
        "scheduled_date": "2025-09-02",
        "assigned_technician": "John Smith",
        "estimated_duration": 1.0,
        "status": "scheduled",
        "notes": "Weekly test - must not delay"
    },
    {
        "id": "SCH-003",
        "pm_id": "PM-003",
        "asset_id": "AST-003",
        "scheduled_date": "2025-09-05",
        "assigned_technician": None,
        "estimated_duration": 4.0,
        "status": "unassigned",
        "notes": "Overdue - needs immediate attention"
    }
]

pm_templates_db = [
    {
        "id": "TPL-001",
        "name": "Compressor Maintenance",
        "category": "Compressor",
        "frequency_days": 90,
        "checklist_items": [
            {"item": "Check oil level and condition", "type": "inspection"},
            {"item": "Replace air filter", "type": "replacement"},
            {"item": "Check belt tension", "type": "adjustment"},
            {"item": "Test safety valves", "type": "functional"},
            {"item": "Clean cooler fins", "type": "cleaning"}
        ],
        "required_parts": [
            {"part_category": "Filters", "typical_quantity": 1},
            {"part_category": "Lubricants", "typical_quantity": 4}
        ],
        "safety_requirements": ["Lockout/Tagout", "PPE", "Pressure Release"]
    },
    {
        "id": "TPL-002", 
        "name": "Belt Drive Maintenance",
        "category": "Conveyor",
        "frequency_days": 30,
        "checklist_items": [
            {"item": "Inspect belt condition", "type": "inspection"},
            {"item": "Check alignment", "type": "measurement"},
            {"item": "Adjust tension", "type": "adjustment"},
            {"item": "Lubricate bearings", "type": "lubrication"},
            {"item": "Clean debris", "type": "cleaning"}
        ],
        "required_parts": [
            {"part_category": "Bearings", "typical_quantity": 2},
            {"part_category": "Lubricants", "typical_quantity": 1}
        ],
        "safety_requirements": ["Lockout/Tagout", "PPE"]
    }
]

@preventive_router.get("/dashboard", response_class=HTMLResponse)
async def preventive_dashboard():
    """Preventive maintenance dashboard"""
    total_pm_tasks = len(preventive_maintenance_db)
    overdue_tasks = len([pm for pm in preventive_maintenance_db if pm['status'] == 'overdue'])
    due_this_week = len([pm for pm in preventive_maintenance_db if pm['status'] == 'due'])
    scheduled_tasks = len([sch for sch in maintenance_schedule_db if sch['status'] == 'scheduled'])
    
    # Calculate compliance rate
    total_completed = len([pm for pm in preventive_maintenance_db if pm.get('last_completed')])
    compliance_rate = (total_completed / total_pm_tasks * 100) if total_pm_tasks > 0 else 0
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix Preventive Maintenance</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 1rem 0; }}
            .stat-value {{ font-size: 2rem; font-weight: bold; }}
            .status-good {{ color: #38a169; }}
            .status-warning {{ color: #d69e2e; }}
            .status-critical {{ color: #e53e3e; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-success {{ background: #38a169; }}
            .btn-warning {{ background: #d69e2e; }}
            .btn-danger {{ background: #e53e3e; }}
            .table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
            .table th, .table td {{ padding: 0.75rem; text-align: left; border-bottom: 1px solid #e2e8f0; }}
            .table th {{ background: #edf2f7; font-weight: 600; }}
            .filter-bar {{ background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; align-items: center; }}
            .filter-bar select, .filter-bar input {{ padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; }}
            .pm-card {{ border-left: 4px solid #4299e1; }}
            .pm-card.critical {{ border-left-color: #e53e3e; }}
            .pm-card.high {{ border-left-color: #d69e2e; }}
            .pm-card.medium {{ border-left-color: #38a169; }}
            .pm-card.overdue {{ border-left-color: #e53e3e; background: #fef5e7; }}
            .pm-card.due {{ border-left-color: #d69e2e; background: #fffbf0; }}
            .progress-bar {{ width: 100%; height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden; }}
            .progress-fill {{ height: 100%; background: #38a169; transition: width 0.3s ease; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>=' ChatterFix Preventive Maintenance</h1>
            <p>Maintenance Scheduling, Planning & Compliance Management</p>
        </div>
        
        <div class="container">
            <!-- Stats Overview -->
            <div class="grid">
                <div class="card">
                    <h3>=Ã PM Overview</h3>
                    <div class="stat">
                        <span>Total PM Tasks</span>
                        <span class="stat-value">{total_pm_tasks}</span>
                    </div>
                    <div class="stat">
                        <span>Overdue</span>
                        <span class="stat-value status-critical">{overdue_tasks}</span>
                    </div>
                    <div class="stat">
                        <span>Due This Week</span>
                        <span class="stat-value status-warning">{due_this_week}</span>
                    </div>
                    <div class="stat">
                        <span>Scheduled</span>
                        <span class="stat-value status-good">{scheduled_tasks}</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>=Ã Compliance Metrics</h3>
                    <div class="stat">
                        <span>Compliance Rate</span>
                        <span class="stat-value status-good">{compliance_rate:.1f}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {compliance_rate}%;"></div>
                    </div>
                    <div class="stat">
                        <span>On-Time Completion</span>
                        <span class="stat-value status-good">89.2%</span>
                    </div>
                    <div class="stat">
                        <span>Avg. Response Time</span>
                        <span class="stat-value">2.1 days</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3>=Ã  Quick Actions</h3>
                    <button class="btn" onclick="createPMTask()">Create PM Task</button>
                    <button class="btn btn-warning" onclick="scheduleOverdue()">Schedule Overdue</button>
                    <button class="btn btn-success" onclick="generateSchedule()">Auto-Schedule</button>
                    <button class="btn" onclick="managePMTemplates()">PM Templates</button>
                    <button class="btn" onclick="viewReports()">View Reports</button>
                </div>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <label>Filter by:</label>
                <select id="statusFilter" onchange="filterPMTasks()">
                    <option value="">All Status</option>
                    <option value="overdue">Overdue</option>
                    <option value="due">Due</option>
                    <option value="scheduled">Scheduled</option>
                </select>
                <select id="priorityFilter" onchange="filterPMTasks()">
                    <option value="">All Priority</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                </select>
                <select id="technicianFilter" onchange="filterPMTasks()">
                    <option value="">All Technicians</option>
                    <option value="John Smith">John Smith</option>
                    <option value="Mike Johnson">Mike Johnson</option>
                    <option value="Sarah Davis">Sarah Davis</option>
                </select>
                <input type="text" id="searchFilter" placeholder="Search PM tasks..." onkeyup="filterPMTasks()">
            </div>
            
            <!-- PM Tasks Grid -->
            <div class="grid" id="pmTasksGrid">
                {chr(10).join([f'''
                <div class="card pm-card {pm['priority']} {pm['status']}" data-status="{pm['status']}" data-priority="{pm['priority']}" data-name="{pm['name'].lower()}">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                        <div>
                            <h4 style="margin: 0; color: #2d3748;">{pm['name']}</h4>
                            <p style="margin: 0.25rem 0; color: #718096;">Asset: {pm['asset_id']} " Every {pm['frequency_days']} days</p>
                        </div>
                        <span class="btn btn-sm {'btn-danger' if pm['status'] == 'overdue' else 'btn-warning' if pm['status'] == 'due' else 'btn-success'}">{pm['status'].title()}</span>
                    </div>
                    
                    <div style="margin-bottom: 1rem;">
                        <div><strong>Priority:</strong> {pm['priority'].title()}</div>
                        <div><strong>Duration:</strong> {pm['estimated_duration']} hours</div>
                        <div><strong>Last Completed:</strong> {pm.get('last_completed', 'Never')}</div>
                        <div><strong>Next Due:</strong> {pm['next_due']}</div>
                    </div>
                    
                    <div style="margin-bottom: 1rem; padding: 0.75rem; background: #f7fafc; border-radius: 4px; font-size: 0.9rem;">
                        <div><strong>Required Skills:</strong> {', '.join(pm['required_skills'])}</div>
                        <div><strong>Parts Needed:</strong> {len(pm['required_parts'])} items</div>
                        <div><strong>Safety:</strong> {', '.join(pm['safety_requirements'][:2])}{'...' if len(pm['safety_requirements']) > 2 else ''}</div>
                    </div>
                    
                    <div style="margin-bottom: 1rem; max-height: 60px; overflow: hidden;">
                        <div style="font-size: 0.9rem; color: #4a5568;">
                            {pm['description'][:80]}{'...' if len(pm['description']) > 80 else ''}
                        </div>
                    </div>
                    
                    <div>
                        <button class="btn btn-sm" onclick="viewPMDetails('{pm['id']}')">View Details</button>
                        <button class="btn btn-sm btn-warning" onclick="schedulePM('{pm['id']}')">Schedule</button>
                        <button class="btn btn-sm btn-success" onclick="completePM('{pm['id']}')">Complete</button>
                        <button class="btn btn-sm" onclick="editPM('{pm['id']}')">Edit</button>
                    </div>
                </div>''' for pm in preventive_maintenance_db])}
            </div>
            
            <!-- Upcoming Schedule -->
            <div class="card" style="margin-top: 2rem;">
                <h3>=Ã Upcoming Scheduled Maintenance</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>PM Task</th>
                            <th>Asset</th>
                            <th>Technician</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {chr(10).join([f'''
                        <tr>
                            <td>{sch['scheduled_date']}</td>
                            <td>{next((pm['name'] for pm in preventive_maintenance_db if pm['id'] == sch['pm_id']), 'Unknown')}</td>
                            <td>{sch['asset_id']}</td>
                            <td>{sch.get('assigned_technician', 'Unassigned')}</td>
                            <td>{sch['estimated_duration']}h</td>
                            <td><span class="btn btn-sm {'btn-success' if sch['status'] == 'scheduled' else 'btn-warning'}">{sch['status'].title()}</span></td>
                            <td>
                                <button class="btn btn-sm" onclick="editSchedule('{sch['id']}')">Edit</button>
                                <button class="btn btn-sm btn-success" onclick="startWork('{sch['id']}')">Start</button>
                            </td>
                        </tr>''' for sch in maintenance_schedule_db[:10]])}
                    </tbody>
                </table>
            </div>
            
            <!-- PM Templates -->
            <div class="card" style="margin-top: 2rem;">
                <h3>=Ã PM Templates</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem;">
                    {chr(10).join([f'''
                    <div style="border: 1px solid #e2e8f0; border-radius: 4px; padding: 1rem;">
                        <h4 style="margin: 0 0 0.5rem 0;">{template['name']}</h4>
                        <div style="font-size: 0.9rem; color: #718096; margin-bottom: 0.5rem;">
                            {template['category']} " Every {template['frequency_days']} days
                        </div>
                        <div style="font-size: 0.85rem; color: #4a5568;">
                            {len(template['checklist_items'])} checklist items<br>
                            {len(template['required_parts'])} part categories<br>
                            {len(template['safety_requirements'])} safety requirements
                        </div>
                        <button class="btn btn-sm" onclick="useTemplate('{template['id']}')" style="margin-top: 0.5rem;">Use Template</button>
                    </div>''' for template in pm_templates_db])}
                </div>
            </div>
        </div>
        
        <script>
            function filterPMTasks() {{
                const statusFilter = document.getElementById('statusFilter').value;
                const priorityFilter = document.getElementById('priorityFilter').value;
                const technicianFilter = document.getElementById('technicianFilter').value;
                const searchFilter = document.getElementById('searchFilter').value.toLowerCase();
                
                const pmCards = document.querySelectorAll('.pm-card');
                pmCards.forEach(card => {{
                    const status = card.dataset.status;
                    const priority = card.dataset.priority;
                    const name = card.dataset.name;
                    
                    const statusMatch = !statusFilter || status === statusFilter;
                    const priorityMatch = !priorityFilter || priority === priorityFilter;
                    const searchMatch = !searchFilter || name.includes(searchFilter);
                    
                    card.style.display = (statusMatch && priorityMatch && searchMatch) ? 'block' : 'none';
                }});
            }}
            
            function createPMTask() {{
                const formHtml = `
                    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;" onclick="closeModal(event)">
                        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 700px; width: 90%; max-height: 90%; overflow-y: auto;" onclick="event.stopPropagation()">
                            <h3>Create PM Task</h3>
                            <form id="createPMForm">
                                <div style="margin-bottom: 1rem;">
                                    <label>Task Name:</label><br>
                                    <input type="text" name="name" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Asset ID:</label><br>
                                    <select name="asset_id" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                        <option value="">Select Asset</option>
                                        <option value="AST-001">AST-001 - Primary Air Compressor</option>
                                        <option value="AST-002">AST-002 - Conveyor Belt System</option>
                                        <option value="AST-003">AST-003 - HVAC Unit 1</option>
                                        <option value="AST-004">AST-004 - Emergency Generator</option>
                                        <option value="AST-005">AST-005 - Packaging Machine Alpha</option>
                                    </select>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                    <div>
                                        <label>Frequency (days):</label><br>
                                        <input type="number" name="frequency_days" value="30" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                    <div>
                                        <label>Duration (hours):</label><br>
                                        <input type="number" step="0.5" name="estimated_duration" value="2" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                    </div>
                                    <div>
                                        <label>Priority:</label><br>
                                        <select name="priority" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem;">
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                            <option value="critical">Critical</option>
                                        </select>
                                    </div>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Description:</label><br>
                                    <textarea name="description" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 60px;"></textarea>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label>Instructions:</label><br>
                                    <textarea name="instructions" required style="width: 100%; padding: 0.5rem; margin-top: 0.25rem; height: 80px;" placeholder="Step-by-step instructions..."></textarea>
                                </div>
                                <div style="text-align: right;">
                                    <button type="button" onclick="document.body.removeChild(document.querySelector('[onclick=\\"closeModal(event)\\"]'))" style="margin-right: 1rem; padding: 0.5rem 1rem; border: 1px solid #ccc; background: white; border-radius: 4px;">Cancel</button>
                                    <button type="submit" class="btn">Create PM Task</button>
                                </div>
                            </form>
                        </div>
                    </div>
                `;
                document.body.insertAdjacentHTML('beforeend', formHtml);
                
                document.getElementById('createPMForm').addEventListener('submit', function(e) {{
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    const pmData = Object.fromEntries(formData);
                    
                    fetch('/preventive', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(pmData)
                    }})
                    .then(response => response.json())
                    .then(data => {{
                        console.log('PM task created:', data);
                        location.reload();
                    }});
                }});
            }}
            
            function closeModal(event) {{
                if (event.target === event.currentTarget) {{
                    document.body.removeChild(event.currentTarget);
                }}
            }}
            
            function viewPMDetails(pmId) {{
                window.open(`/preventive/${{pmId}}`, '_blank');
            }}
            
            function schedulePM(pmId) {{
                const date = prompt('Enter scheduled date (YYYY-MM-DD):');
                if (date) {{
                    fetch(`/preventive/${{pmId}}/schedule`, {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ scheduled_date: date }})
                    }})
                    .then(() => location.reload());
                }}
            }}
            
            function completePM(pmId) {{
                window.location.href = `/preventive/${{pmId}}/complete`;
            }}
            
            function editPM(pmId) {{
                window.location.href = `/preventive/${{pmId}}/edit`;
            }}
            
            function editSchedule(scheduleId) {{
                window.location.href = `/preventive/schedule/${{scheduleId}}/edit`;
            }}
            
            function startWork(scheduleId) {{
                window.location.href = `/workorders/create?schedule_id=${{scheduleId}}`;
            }}
            
            function scheduleOverdue() {{
                fetch('/preventive/schedule-overdue', {{ method: 'POST' }})
                    .then(response => response.json())
                    .then(data => {{
                        alert(`Scheduled ${{data.scheduled_count}} overdue PM tasks`);
                        location.reload();
                    }});
            }}
            
            function generateSchedule() {{
                window.location.href = '/preventive/auto-schedule';
            }}
            
            function managePMTemplates() {{
                window.location.href = '/preventive/templates';
            }}
            
            function viewReports() {{
                window.location.href = '/preventive/reports';
            }}
            
            function useTemplate(templateId) {{
                window.location.href = `/preventive/templates/${{templateId}}/create`;
            }}
        </script>
    </body>
    </html>
    """

@preventive_router.get("/")
async def get_preventive_maintenance(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    asset_id: Optional[str] = Query(None)
) -> List[Dict]:
    """Get all preventive maintenance tasks with optional filtering"""
    filtered_pms = preventive_maintenance_db
    
    if status:
        filtered_pms = [pm for pm in filtered_pms if pm['status'] == status]
    if priority:
        filtered_pms = [pm for pm in filtered_pms if pm['priority'] == priority]
    if asset_id:
        filtered_pms = [pm for pm in filtered_pms if pm['asset_id'] == asset_id]
    
    return filtered_pms

@preventive_router.get("/{pm_id}")
async def get_preventive_maintenance_details(pm_id: str) -> Dict:
    """Get specific preventive maintenance details"""
    pm = next((pm for pm in preventive_maintenance_db if pm['id'] == pm_id), None)
    if not pm:
        raise HTTPException(status_code=404, detail="PM task not found")
    
    # Get associated schedules
    schedules = [sch for sch in maintenance_schedule_db if sch['pm_id'] == pm_id]
    
    return {
        "pm_task": pm,
        "schedules": schedules,
        "compliance_metrics": {
            "completion_rate": 92.5,
            "average_duration": pm['estimated_duration'] * 1.1,
            "cost_per_execution": 150.00,
            "downtime_reduction": "15% vs reactive"
        }
    }

@preventive_router.post("/")
async def create_preventive_maintenance(pm_data: Dict[str, Any]) -> Dict:
    """Create new preventive maintenance task"""
    pm_id = f"PM-{len(preventive_maintenance_db) + 1:03d}"
    
    # Calculate next due date based on frequency
    next_due = datetime.now() + timedelta(days=int(pm_data['frequency_days']))
    
    new_pm = {
        "id": pm_id,
        "name": pm_data["name"],
        "asset_id": pm_data["asset_id"],
        "frequency_days": int(pm_data["frequency_days"]),
        "estimated_duration": float(pm_data["estimated_duration"]),
        "priority": pm_data["priority"],
        "description": pm_data["description"],
        "instructions": pm_data["instructions"],
        "required_parts": pm_data.get("required_parts", []),
        "required_skills": pm_data.get("required_skills", []),
        "safety_requirements": pm_data.get("safety_requirements", []),
        "last_completed": None,
        "next_due": next_due.strftime("%Y-%m-%d"),
        "status": "scheduled"
    }
    
    preventive_maintenance_db.append(new_pm)
    logger.info(f"PM task created: {pm_id}")
    return new_pm

@preventive_router.post("/{pm_id}/schedule")
async def schedule_preventive_maintenance(pm_id: str, schedule_data: Dict[str, Any]) -> Dict:
    """Schedule a preventive maintenance task"""
    pm = next((pm for pm in preventive_maintenance_db if pm['id'] == pm_id), None)
    if not pm:
        raise HTTPException(status_code=404, detail="PM task not found")
    
    schedule_id = f"SCH-{len(maintenance_schedule_db) + 1:03d}"
    
    new_schedule = {
        "id": schedule_id,
        "pm_id": pm_id,
        "asset_id": pm['asset_id'],
        "scheduled_date": schedule_data["scheduled_date"],
        "assigned_technician": schedule_data.get("assigned_technician"),
        "estimated_duration": pm['estimated_duration'],
        "status": "scheduled",
        "notes": schedule_data.get("notes")
    }
    
    maintenance_schedule_db.append(new_schedule)
    
    # Update PM status
    pm['status'] = 'scheduled'
    
    logger.info(f"PM scheduled: {pm_id} on {schedule_data['scheduled_date']}")
    return new_schedule

@preventive_router.post("/{pm_id}/complete")
async def complete_preventive_maintenance(pm_id: str, completion_data: Dict[str, Any]) -> Dict:
    """Mark preventive maintenance as completed"""
    pm = next((pm for pm in preventive_maintenance_db if pm['id'] == pm_id), None)
    if not pm:
        raise HTTPException(status_code=404, detail="PM task not found")
    
    # Update PM task
    pm['last_completed'] = datetime.now().strftime("%Y-%m-%d")
    next_due = datetime.now() + timedelta(days=pm['frequency_days'])
    pm['next_due'] = next_due.strftime("%Y-%m-%d")
    pm['status'] = 'scheduled'
    
    # Update any associated schedule
    for schedule in maintenance_schedule_db:
        if schedule['pm_id'] == pm_id and schedule['status'] == 'scheduled':
            schedule['status'] = 'completed'
            break
    
    logger.info(f"PM completed: {pm_id}")
    return {
        "pm_id": pm_id,
        "completed_date": pm['last_completed'],
        "next_due_date": pm['next_due'],
        "status": "completed"
    }

@preventive_router.post("/schedule-overdue")
async def schedule_overdue_maintenance() -> Dict:
    """Automatically schedule overdue maintenance tasks"""
    overdue_pms = [pm for pm in preventive_maintenance_db if pm['status'] == 'overdue']
    scheduled_count = 0
    
    for pm in overdue_pms:
        # Auto-schedule for next available date
        schedule_date = datetime.now() + timedelta(days=1)
        
        schedule_id = f"SCH-{len(maintenance_schedule_db) + 1:03d}"
        new_schedule = {
            "id": schedule_id,
            "pm_id": pm['id'],
            "asset_id": pm['asset_id'],
            "scheduled_date": schedule_date.strftime("%Y-%m-%d"),
            "assigned_technician": None,
            "estimated_duration": pm['estimated_duration'],
            "status": "unassigned",
            "notes": "Auto-scheduled overdue PM"
        }
        
        maintenance_schedule_db.append(new_schedule)
        pm['status'] = 'scheduled'
        scheduled_count += 1
    
    logger.info(f"Auto-scheduled {scheduled_count} overdue PM tasks")
    return {"scheduled_count": scheduled_count, "message": f"Scheduled {scheduled_count} overdue PM tasks"}

@preventive_router.get("/schedule")
async def get_maintenance_schedule(
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    technician: Optional[str] = Query(None)
) -> List[Dict]:
    """Get maintenance schedule with optional date and technician filtering"""
    filtered_schedule = maintenance_schedule_db
    
    if start_date:
        filtered_schedule = [sch for sch in filtered_schedule if sch['scheduled_date'] >= start_date]
    if end_date:
        filtered_schedule = [sch for sch in filtered_schedule if sch['scheduled_date'] <= end_date]
    if technician:
        filtered_schedule = [sch for sch in filtered_schedule if sch.get('assigned_technician') == technician]
    
    return filtered_schedule

@preventive_router.get("/templates")
async def get_pm_templates() -> List[Dict]:
    """Get all PM templates"""
    return pm_templates_db

@preventive_router.post("/templates/{template_id}/create-pm")
async def create_pm_from_template(template_id: str, pm_data: Dict[str, Any]) -> Dict:
    """Create PM task from template"""
    template = next((t for t in pm_templates_db if t['id'] == template_id), None)
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    
    pm_id = f"PM-{len(preventive_maintenance_db) + 1:03d}"
    
    next_due = datetime.now() + timedelta(days=template['frequency_days'])
    
    new_pm = {
        "id": pm_id,
        "name": f"{template['name']} - {pm_data['asset_id']}",
        "asset_id": pm_data["asset_id"],
        "frequency_days": template['frequency_days'],
        "estimated_duration": pm_data.get("estimated_duration", 2.0),
        "priority": pm_data.get("priority", "medium"),
        "description": f"PM task created from template: {template['name']}",
        "instructions": "\\n".join([f"{i+1}. {item['item']}" for i, item in enumerate(template['checklist_items'])]),
        "required_parts": template.get('required_parts', []),
        "required_skills": ["General Maintenance"],
        "safety_requirements": template['safety_requirements'],
        "last_completed": None,
        "next_due": next_due.strftime("%Y-%m-%d"),
        "status": "scheduled"
    }
    
    preventive_maintenance_db.append(new_pm)
    logger.info(f"PM task created from template {template_id}: {pm_id}")
    return new_pm

@preventive_router.get("/reports/compliance")
async def get_compliance_report() -> Dict:
    """Get PM compliance report"""
    total_pms = len(preventive_maintenance_db)
    completed_on_time = len([pm for pm in preventive_maintenance_db if pm.get('last_completed')])
    overdue_pms = len([pm for pm in preventive_maintenance_db if pm['status'] == 'overdue'])
    
    compliance_rate = (completed_on_time / total_pms * 100) if total_pms > 0 else 0
    
    # Compliance by priority
    by_priority = {}
    for priority in ['critical', 'high', 'medium']:
        priority_pms = [pm for pm in preventive_maintenance_db if pm['priority'] == priority]
        completed_priority = len([pm for pm in priority_pms if pm.get('last_completed')])
        by_priority[priority] = {
            "total": len(priority_pms),
            "completed": completed_priority,
            "compliance_rate": (completed_priority / len(priority_pms) * 100) if priority_pms else 0
        }
    
    return {
        "overall_compliance_rate": compliance_rate,
        "total_pm_tasks": total_pms,
        "completed_on_time": completed_on_time,
        "overdue_tasks": overdue_pms,
        "compliance_by_priority": by_priority,
        "trends": {
            "monthly_completion_rate": [89, 92, 87, 94, 91, 88],
            "average_response_time": 2.1,
            "cost_savings_vs_reactive": "35%"
        },
        "generated_at": datetime.now().isoformat()
    }