/**
 * ChatterFix CMMS Service Worker
 * Enables offline functionality and PWA capabilities
 */

const CACHE_NAME = 'chatterfix-cmms-v1';
const STATIC_CACHE_URLS = [
    '/',
    '/cmms/dashboard/main',
    '/cmms/workorders/list',
    '/cmms/assets/list', 
    '/cmms/ai/dashboard',
    '/static/css/mobile.css',
    '/static/css/main.css',
    '/static/js/offline-sync.js',
    '/static/js/voice-commands.js'
];

const API_CACHE_URLS = [
    '/cmms/workorders/api/list',
    '/cmms/assets/api/list',
    '/cmms/dashboard/api/stats'
];

// Install event - cache static resources
self.addEventListener('install', event => {
    console.log('🚀 ChatterFix SW: Installing service worker...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('📦 ChatterFix SW: Caching static resources');
                return cache.addAll(STATIC_CACHE_URLS);
            })
            .then(() => {
                console.log('✅ ChatterFix SW: Static resources cached');
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('❌ ChatterFix SW: Cache failed:', error);
            })
    );
});

// Activate event - cleanup old caches
self.addEventListener('activate', event => {
    console.log('🔄 ChatterFix SW: Activating service worker...');
    
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames
                        .filter(cacheName => cacheName !== CACHE_NAME)
                        .map(cacheName => {
                            console.log('🗑️ ChatterFix SW: Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        })
                );
            })
            .then(() => {
                console.log('✅ ChatterFix SW: Activated and ready');
                return self.clients.claim();
            })
    );
});

// Fetch event - network-first for API, cache-first for static
self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);
    
    // API requests - network first with cache fallback
    if (url.pathname.includes('/api/')) {
        event.respondWith(networkFirstStrategy(request));
    }
    // Static resources - cache first with network fallback  
    else if (STATIC_CACHE_URLS.some(staticUrl => url.pathname === staticUrl)) {
        event.respondWith(cacheFirstStrategy(request));
    }
    // Work order forms - special offline handling
    else if (request.method === 'POST' && url.pathname.includes('/workorders/')) {
        event.respondWith(handleOfflineFormSubmission(request));
    }
    // Everything else - network with cache fallback
    else {
        event.respondWith(networkFirstStrategy(request));
    }
});

/**
 * Network-first strategy for dynamic content
 */
async function networkFirstStrategy(request) {
    try {
        // Try network first
        const networkResponse = await fetch(request);
        
        // If successful, cache the response (for GET requests)
        if (networkResponse.ok && request.method === 'GET') {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.log('🌐 ChatterFix SW: Network failed, trying cache:', request.url);
        
        // Network failed, try cache
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        
        // If no cache, return offline page for navigation requests
        if (request.mode === 'navigate') {
            return caches.match('/offline.html');
        }
        
        throw error;
    }
}

/**
 * Cache-first strategy for static resources
 */
async function cacheFirstStrategy(request) {
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
        return cachedResponse;
    }
    
    // Cache miss - fetch from network and cache
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        console.error('❌ ChatterFix SW: Failed to fetch static resource:', request.url);
        throw error;
    }
}

/**
 * Handle offline form submissions
 */
async function handleOfflineFormSubmission(request) {
    try {
        // Try to submit online first
        const response = await fetch(request);
        
        if (response.ok) {
            // Success - clear any queued offline submissions for this form
            self.postMessage({
                type: 'FORM_SUBMITTED_ONLINE',
                url: request.url
            });
        }
        
        return response;
    } catch (error) {
        console.log('📱 ChatterFix SW: Offline form submission detected');
        
        // Store form data for later sync
        const formData = await request.formData();
        const offlineSubmission = {
            id: `offline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            url: request.url,
            method: request.method,
            data: Object.fromEntries(formData),
            timestamp: Date.now(),
            headers: Object.fromEntries(request.headers.entries())
        };
        
        // Store in IndexedDB via message to main thread
        self.postMessage({
            type: 'STORE_OFFLINE_SUBMISSION',
            submission: offlineSubmission
        });
        
        // Return success response for UX
        return new Response(JSON.stringify({
            success: true,
            offline: true,
            message: 'Form saved locally. Will sync when online.',
            submissionId: offlineSubmission.id
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

// Background sync for queued submissions
self.addEventListener('sync', event => {
    if (event.tag === 'background-sync-forms') {
        console.log('🔄 ChatterFix SW: Background sync triggered');
        event.waitUntil(syncOfflineSubmissions());
    }
});

/**
 * Sync offline submissions when back online
 */
async function syncOfflineSubmissions() {
    try {
        // Get pending submissions from main thread
        const clients = await self.clients.matchAll();
        if (clients.length > 0) {
            clients[0].postMessage({ type: 'SYNC_OFFLINE_SUBMISSIONS' });
        }
    } catch (error) {
        console.error('❌ ChatterFix SW: Sync failed:', error);
    }
}

// Push notifications for work order updates
self.addEventListener('push', event => {
    if (!event.data) return;
    
    const data = event.data.json();
    
    const options = {
        body: data.message,
        icon: '/static/icons/icon-192.png',
        badge: '/static/icons/badge-72.png',
        tag: data.tag || 'chatterfix-notification',
        requireInteraction: data.priority === 'high',
        actions: [
            {
                action: 'view',
                title: 'View Details',
                icon: '/static/icons/view-icon.png'
            },
            {
                action: 'dismiss',
                title: 'Dismiss',
                icon: '/static/icons/dismiss-icon.png'
            }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
    event.notification.close();
    
    if (event.action === 'view') {
        // Open the relevant work order or page
        event.waitUntil(
            clients.openWindow(`/cmms/workorders/${event.notification.tag}`)
        );
    }
});

console.log('🎯 ChatterFix CMMS Service Worker loaded and ready');