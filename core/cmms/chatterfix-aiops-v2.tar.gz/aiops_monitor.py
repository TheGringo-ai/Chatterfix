"""
AIOps Monitoring System for ChatterFix CMMS
Monitors logs, detects incidents, and triggers self-healing actions.
"""

import os
import re
import json
import hashlib
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
from enum import Enum
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class IncidentSeverity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class IncidentType(Enum):
    APP_CRASH = "app_crash"
    HIGH_ERROR_RATE = "high_error_rate" 
    HIGH_LATENCY = "high_latency"
    DISK_FULL = "disk_full"
    CERT_EXPIRED = "cert_expired"
    MEMORY_HIGH = "memory_high"
    CPU_HIGH = "cpu_high"
    NGINX_DOWN = "nginx_down"

@dataclass
class Incident:
    """Incident data structure"""
    incident_id: str
    request_id: str
    incident_type: IncidentType
    severity: IncidentSeverity
    title: str
    description: str
    first_seen: datetime
    last_seen: datetime
    count: int
    affected_components: List[str]
    root_cause: str
    remediation_taken: List[str]
    status: str = "detected"
    resolved_at: Optional[datetime] = None

@dataclass
class LogEvent:
    """Log event structure"""
    timestamp: datetime
    level: str
    source: str
    message: str
    request_id: Optional[str] = None
    response_code: Optional[int] = None
    response_time_ms: Optional[float] = None
    ip_address: Optional[str] = None

class AIOpsMonitor:
    """Main monitoring system for log analysis and incident detection"""
    
    def __init__(self):
        self.incidents: Dict[str, Incident] = {}
        self.log_buffer = deque(maxlen=10000)  # Rolling buffer for log analysis
        self.metrics_window = deque(maxlen=300)  # 5-minute window at 1-second intervals
        
        # Thresholds for incident detection
        self.thresholds = {
            'error_rate': 0.05,  # 5% error rate
            'high_latency_ms': 2000,  # 2 second response time
            'high_latency_rate': 0.10,  # 10% of requests slow
            'disk_usage': 0.90,  # 90% disk usage
            'memory_usage': 0.85,  # 85% memory usage
            'cpu_usage': 0.80,  # 80% CPU usage
        }
        
        # Log patterns for incident detection
        self.log_patterns = {
            'app_crash': [
                r'Process .* exited',
                r'Application terminated',
                r'Traceback \(most recent call last\)',
                r'CRITICAL|FATAL',
                r'Segmentation fault'
            ],
            'high_error_rate': [
                r'HTTP/\d+\.\d+"\s+[45]\d{2}',  # 4xx, 5xx status codes
                r'ERROR|Exception|Failed',
                r'Internal Server Error'
            ],
            'high_latency': [
                r'took (\d+)ms',
                r'response_time_ms:\s*(\d+)',
                r'slow query'
            ],
            'nginx_issues': [
                r'nginx.*failed',
                r'upstream.*timeout',
                r'connection refused'
            ]
        }
        
        # Sessions directory for incident summaries
        self.sessions_dir = Path("/Users/fredtaylor/Desktop/Projects/ai-tools/ai-memory/sessions")
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info("🔍 AIOps Monitor initialized")

    def generate_request_id(self) -> str:
        """Generate unique request ID for tracking"""
        return f"req_{uuid.uuid4().hex[:8]}_{int(datetime.now().timestamp())}"

    def parse_log_line(self, line: str, source: str = "app") -> Optional[LogEvent]:
        """Parse a log line into a LogEvent"""
        try:
            # Common log patterns
            timestamp_pattern = r'(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d{3})?)'
            level_pattern = r'(DEBUG|INFO|WARNING|ERROR|CRITICAL|FATAL)'
            
            # Extract timestamp
            timestamp_match = re.search(timestamp_pattern, line)
            if not timestamp_match:
                return None
            
            timestamp_str = timestamp_match.group(1)
            try:
                timestamp = datetime.fromisoformat(timestamp_str.replace(' ', 'T'))
            except:
                timestamp = datetime.now()
            
            # Extract log level
            level_match = re.search(level_pattern, line)
            level = level_match.group(1) if level_match else "INFO"
            
            # Extract request ID if present
            request_id_match = re.search(r'request_id[:\s=]+([a-zA-Z0-9_]+)', line)
            request_id = request_id_match.group(1) if request_id_match else None
            
            # Extract response code for nginx/access logs
            response_code_match = re.search(r'HTTP/\d+\.\d+"\s+(\d{3})', line)
            response_code = int(response_code_match.group(1)) if response_code_match else None
            
            # Extract response time
            response_time_match = re.search(r'response_time[:\s=]+(\d+(?:\.\d+)?)(?:ms)?', line)
            response_time_ms = float(response_time_match.group(1)) if response_time_match else None
            
            # Extract IP address
            ip_match = re.search(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', line)
            ip_address = ip_match.group(1) if ip_match else None
            
            return LogEvent(
                timestamp=timestamp,
                level=level,
                source=source,
                message=line.strip(),
                request_id=request_id,
                response_code=response_code,
                response_time_ms=response_time_ms,
                ip_address=ip_address
            )
            
        except Exception as e:
            logger.warning(f"Failed to parse log line: {e}")
            return None

    def analyze_log_events(self, events: List[LogEvent]) -> List[Incident]:
        """Analyze log events and detect incidents"""
        detected_incidents = []
        
        if not events:
            return detected_incidents
        
        # Group events by time windows for analysis
        time_window = timedelta(minutes=5)
        current_time = max(event.timestamp for event in events)
        window_start = current_time - time_window
        
        recent_events = [e for e in events if e.timestamp >= window_start]
        
        # Detect app crashes
        crash_incidents = self._detect_app_crashes(recent_events)
        detected_incidents.extend(crash_incidents)
        
        # Detect high error rates
        error_rate_incidents = self._detect_high_error_rate(recent_events)
        detected_incidents.extend(error_rate_incidents)
        
        # Detect high latency
        latency_incidents = self._detect_high_latency(recent_events)
        detected_incidents.extend(latency_incidents)
        
        return detected_incidents

    def _detect_app_crashes(self, events: List[LogEvent]) -> List[Incident]:
        """Detect application crashes from log events"""
        incidents = []
        
        crash_patterns = self.log_patterns['app_crash']
        crash_events = []
        
        for event in events:
            for pattern in crash_patterns:
                if re.search(pattern, event.message, re.IGNORECASE):
                    crash_events.append(event)
                    break
        
        if crash_events:
            request_id = self.generate_request_id()
            incident = Incident(
                incident_id=f"crash_{hashlib.md5(str(crash_events[0].timestamp).encode()).hexdigest()[:8]}",
                request_id=request_id,
                incident_type=IncidentType.APP_CRASH,
                severity=IncidentSeverity.CRITICAL,
                title="Application Crash Detected",
                description=f"Application crash detected with {len(crash_events)} related log entries",
                first_seen=min(e.timestamp for e in crash_events),
                last_seen=max(e.timestamp for e in crash_events),
                count=len(crash_events),
                affected_components=["main_app"],
                root_cause="Process termination or fatal error",
                remediation_taken=[]
            )
            incidents.append(incident)
            logger.error(f"🚨 App crash detected - Incident ID: {incident.incident_id}, Request ID: {request_id}")
        
        return incidents

    def _detect_high_error_rate(self, events: List[LogEvent]) -> List[Incident]:
        """Detect high error rates from log events"""
        incidents = []
        
        # Count total requests and errors
        total_requests = len([e for e in events if e.response_code])
        error_requests = len([e for e in events if e.response_code and e.response_code >= 400])
        
        if total_requests == 0:
            return incidents
        
        error_rate = error_requests / total_requests
        
        if error_rate > self.thresholds['error_rate']:
            request_id = self.generate_request_id()
            incident = Incident(
                incident_id=f"errors_{hashlib.md5(f'{datetime.now()}{error_rate}'.encode()).hexdigest()[:8]}",
                request_id=request_id,
                incident_type=IncidentType.HIGH_ERROR_RATE,
                severity=IncidentSeverity.HIGH if error_rate > 0.1 else IncidentSeverity.MEDIUM,
                title=f"High Error Rate: {error_rate:.1%}",
                description=f"Error rate of {error_rate:.1%} ({error_requests}/{total_requests} requests)",
                first_seen=min(e.timestamp for e in events if e.response_code and e.response_code >= 400),
                last_seen=max(e.timestamp for e in events if e.response_code and e.response_code >= 400),
                count=error_requests,
                affected_components=["web_server", "application"],
                root_cause="Multiple request failures or application errors",
                remediation_taken=[]
            )
            incidents.append(incident)
            logger.warning(f"⚠️ High error rate detected: {error_rate:.1%} - Request ID: {request_id}")
        
        return incidents

    def _detect_high_latency(self, events: List[LogEvent]) -> List[Incident]:
        """Detect high latency incidents"""
        incidents = []
        
        # Get events with response times
        timed_events = [e for e in events if e.response_time_ms]
        if not timed_events:
            return incidents
        
        # Calculate latency statistics
        slow_requests = [e for e in timed_events if e.response_time_ms > self.thresholds['high_latency_ms']]
        slow_rate = len(slow_requests) / len(timed_events)
        
        if slow_rate > self.thresholds['high_latency_rate']:
            avg_latency = sum(e.response_time_ms for e in slow_requests) / len(slow_requests)
            request_id = self.generate_request_id()
            
            incident = Incident(
                incident_id=f"latency_{hashlib.md5(f'{datetime.now()}{slow_rate}'.encode()).hexdigest()[:8]}",
                request_id=request_id,
                incident_type=IncidentType.HIGH_LATENCY,
                severity=IncidentSeverity.MEDIUM,
                title=f"High Latency: {avg_latency:.0f}ms avg",
                description=f"High response times: {slow_rate:.1%} of requests over {self.thresholds['high_latency_ms']}ms",
                first_seen=min(e.timestamp for e in slow_requests),
                last_seen=max(e.timestamp for e in slow_requests),
                count=len(slow_requests),
                affected_components=["application", "database"],
                root_cause="Performance degradation or resource contention",
                remediation_taken=[]
            )
            incidents.append(incident)
            logger.warning(f"⚠️ High latency detected: {avg_latency:.0f}ms avg - Request ID: {request_id}")
        
        return incidents

    def process_log_file(self, file_path: str, source: str = "app") -> List[Incident]:
        """Process a log file and detect incidents"""
        incidents = []
        
        try:
            if not os.path.exists(file_path):
                logger.warning(f"Log file not found: {file_path}")
                return incidents
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                events = []
                for line in f:
                    if line.strip():
                        event = self.parse_log_line(line.strip(), source)
                        if event:
                            events.append(event)
                            self.log_buffer.append(event)
                
                # Analyze recent events for incidents
                recent_incidents = self.analyze_log_events(events[-1000:])  # Last 1000 events
                incidents.extend(recent_incidents)
                
        except Exception as e:
            logger.error(f"Failed to process log file {file_path}: {e}")
        
        return incidents

    def monitor_system_metrics(self) -> List[Incident]:
        """Monitor system metrics and detect resource-based incidents"""
        incidents = []
        
        try:
            # Check disk usage
            import shutil
            total, used, free = shutil.disk_usage("/")
            disk_usage = used / total
            
            if disk_usage > self.thresholds['disk_usage']:
                request_id = self.generate_request_id()
                incident = Incident(
                    incident_id=f"disk_{hashlib.md5(f'{datetime.now()}{disk_usage}'.encode()).hexdigest()[:8]}",
                    request_id=request_id,
                    incident_type=IncidentType.DISK_FULL,
                    severity=IncidentSeverity.HIGH,
                    title=f"Disk Usage Critical: {disk_usage:.1%}",
                    description=f"Disk usage at {disk_usage:.1%} - {free/(1024**3):.1f}GB free",
                    first_seen=datetime.now(),
                    last_seen=datetime.now(),
                    count=1,
                    affected_components=["filesystem", "application"],
                    root_cause="Insufficient disk space",
                    remediation_taken=[]
                )
                incidents.append(incident)
                logger.error(f"🚨 Disk usage critical: {disk_usage:.1%} - Request ID: {request_id}")
            
        except Exception as e:
            logger.error(f"Failed to monitor system metrics: {e}")
        
        return incidents

    def save_incident_summary(self, date: datetime, incidents: List[Incident]) -> str:
        """Save daily incident summary to ai-memory/sessions/"""
        date_str = date.strftime("%Y-%m-%d")
        summary_file = self.sessions_dir / f"incident_summary_{date_str}.json"
        
        summary = {
            "date": date_str,
            "total_incidents": len(incidents),
            "incidents_by_severity": {
                "critical": len([i for i in incidents if i.severity == IncidentSeverity.CRITICAL]),
                "high": len([i for i in incidents if i.severity == IncidentSeverity.HIGH]),
                "medium": len([i for i in incidents if i.severity == IncidentSeverity.MEDIUM]),
                "low": len([i for i in incidents if i.severity == IncidentSeverity.LOW])
            },
            "incidents_by_type": {},
            "incidents": []
        }
        
        # Group by type
        for incident in incidents:
            incident_type = incident.incident_type.value
            if incident_type not in summary["incidents_by_type"]:
                summary["incidents_by_type"][incident_type] = 0
            summary["incidents_by_type"][incident_type] += 1
            
            # Add incident details
            summary["incidents"].append({
                "incident_id": incident.incident_id,
                "request_id": incident.request_id,
                "type": incident.incident_type.value,
                "severity": incident.severity.value,
                "title": incident.title,
                "description": incident.description,
                "what": incident.description,
                "why": incident.root_cause,
                "next": f"Applied remediation: {', '.join(incident.remediation_taken) if incident.remediation_taken else 'Manual investigation required'}",
                "first_seen": incident.first_seen.isoformat(),
                "last_seen": incident.last_seen.isoformat(),
                "count": incident.count,
                "affected_components": incident.affected_components,
                "status": incident.status,
                "resolved_at": incident.resolved_at.isoformat() if incident.resolved_at else None
            })
        
        # Write summary to file
        try:
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=2)
            logger.info(f"📄 Incident summary saved: {summary_file}")
            return str(summary_file)
        except Exception as e:
            logger.error(f"Failed to save incident summary: {e}")
            return ""

    def get_daily_summary(self, date: Optional[datetime] = None) -> Dict[str, Any]:
        """Get daily incident summary"""
        if date is None:
            date = datetime.now()
        
        date_str = date.strftime("%Y-%m-%d")
        summary_file = self.sessions_dir / f"incident_summary_{date_str}.json"
        
        if not summary_file.exists():
            return {
                "date": date_str,
                "total_incidents": 0,
                "message": "No incidents recorded for this date",
                "incidents": []
            }
        
        try:
            with open(summary_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load daily summary: {e}")
            return {"error": f"Failed to load summary: {e}"}

# Global monitor instance
aiops_monitor = AIOpsMonitor()