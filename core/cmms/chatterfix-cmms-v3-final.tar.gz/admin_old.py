#!/usr/bin/env python3
"""
CMMS Admin Module
Handles administrative functions, user management, system configuration
"""

from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from navigation_component import get_navigation_html, get_navigation_styles, get_navigation_javascript, get_base_styles

logger = logging.getLogger(__name__)

# Admin router
admin_router = APIRouter(prefix="/admin", tags=["admin"])

# Data models
class User(BaseModel):
    id: str
    username: str
    email: str
    role: str
    active: bool
    created_date: str
    last_login: Optional[str] = None

class SystemConfig(BaseModel):
    maintenance_schedule_days: int
    auto_assign_technicians: bool
    email_notifications: bool
    backup_frequency: str
    ai_model_preference: str

# Mock database
users_db = [
    {
        "id": "USR-001",
        "username": "admin",
        "email": "admin@chatterfix.com",
        "role": "administrator",
        "active": True,
        "created_date": "2025-08-01",
        "last_login": "2025-09-01T15:30:00"
    },
    {
        "id": "USR-002", 
        "username": "tech1",
        "email": "tech1@chatterfix.com",
        "role": "technician",
        "active": True,
        "created_date": "2025-08-15",
        "last_login": "2025-09-01T14:20:00"
    },
    {
        "id": "USR-003",
        "username": "manager1",
        "email": "manager@chatterfix.com", 
        "role": "manager",
        "active": True,
        "created_date": "2025-08-10",
        "last_login": "2025-09-01T16:10:00"
    }
]

system_config = {
    "maintenance_schedule_days": 30,
    "auto_assign_technicians": True,
    "email_notifications": True,
    "backup_frequency": "daily",
    "ai_model_preference": "balanced"
}

@admin_router.get("/dashboard", response_class=HTMLResponse)
async def admin_dashboard():
    """Admin dashboard with user management and system controls"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix Admin Dashboard</title>
        <style>
            body {{ font-family: system-ui, sans-serif; margin: 0; background: #f5f7fa; }}
            .header {{ background: #2d3748; color: white; padding: 1rem 2rem; }}
            .container {{ max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }}
            .card {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            .stat {{ display: flex; justify-content: space-between; align-items: center; margin: 1rem 0; }}
            .stat-value {{ font-size: 2rem; font-weight: bold; color: #4299e1; }}
            .btn {{ background: #4299e1; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; margin: 0.25rem; }}
            .btn:hover {{ background: #3182ce; }}
            .btn-danger {{ background: #e53e3e; }}
            .btn-danger:hover {{ background: #c53030; }}
            .table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
            .table th, .table td {{ padding: 0.75rem; text-align: left; border-bottom: 1px solid #e2e8f0; }}
            .table th {{ background: #edf2f7; font-weight: 600; }}
            .status-active {{ color: #38a169; }}
            .status-inactive {{ color: #e53e3e; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>=' ChatterFix Admin Dashboard</h1>
            <p>System Administration & User Management</p>
        </div>
        
        <div class="container">
            <div class="grid">
                <div class="card">
                    <h3>=� System Overview</h3>
                    <div class="stat">
                        <span>Total Users</span>
                        <span class="stat-value">{len(users_db)}</span>
                    </div>
                    <div class="stat">
                        <span>Active Users</span>
                        <span class="stat-value">{len([u for u in users_db if u['active']])}</span>
                    </div>
                    <div class="stat">
                        <span>System Uptime</span>
                        <span class="stat-value">99.8%</span>
                    </div>
                    <button class="btn" onclick="refreshStats()">Refresh Stats</button>
                </div>
                
                <div class="card">
                    <h3>� System Configuration</h3>
                    <div class="stat">
                        <span>Maintenance Cycle</span>
                        <span>{system_config['maintenance_schedule_days']} days</span>
                    </div>
                    <div class="stat">
                        <span>Auto Assignment</span>
                        <span>{' Enabled' if system_config['auto_assign_technicians'] else 'L Disabled'}</span>
                    </div>
                    <div class="stat">
                        <span>AI Model</span>
                        <span>{system_config['ai_model_preference'].title()}</span>
                    </div>
                    <button class="btn" onclick="configureSystem()">Configure</button>
                </div>
                
                <div class="card">
                    <h3>=� Quick Actions</h3>
                    <button class="btn" onclick="createUser()">Add New User</button>
                    <button class="btn" onclick="systemBackup()">System Backup</button>
                    <button class="btn" onclick="viewLogs()">View System Logs</button>
                    <button class="btn" onclick="exportData()">Export Data</button>
                    <button class="btn btn-danger" onclick="systemRestart()">Restart System</button>
                </div>
            </div>
            
            <div class="card" style="margin-top: 2rem;">
                <h3>=e User Management</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTable">
                        {chr(10).join([f'''
                        <tr>
                            <td>{user['id']}</td>
                            <td>{user['username']}</td>
                            <td>{user['email']}</td>
                            <td>{user['role'].title()}</td>
                            <td class="{'status-active' if user['active'] else 'status-inactive'}">
                                {'Active' if user['active'] else 'Inactive'}
                            </td>
                            <td>{user.get('last_login', 'Never')}</td>
                            <td>
                                <button class="btn" onclick="editUser('{user['id']}')">Edit</button>
                                <button class="btn btn-danger" onclick="toggleUser('{user['id']}')">
                                    {'Deactivate' if user['active'] else 'Activate'}
                                </button>
                            </td>
                        </tr>''' for user in users_db])}
                    </tbody>
                </table>
            </div>
        </div>
        
        <script>
            function refreshStats() {{
                fetch('/admin/stats')
                    .then(response => response.json())
                    .then(data => {{
                        console.log('Stats refreshed:', data);
                        location.reload();
                    }});
            }}
            
            function createUser() {{
                const username = prompt('Username:');
                if (!username) return;
                const email = prompt('Email:');
                if (!email) return;
                const role = prompt('Role (technician/manager/administrator):');
                if (!role) return;
                
                fetch('/admin/users', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ username, email, role }})
                }})
                .then(response => response.json())
                .then(data => {{
                    alert('User created: ' + data.id);
                    location.reload();
                }});
            }}
            
            function editUser(userId) {{
                fetch(`/admin/users/${{userId}}`)
                    .then(response => response.json())
                    .then(user => {{
                        const newEmail = prompt('New email:', user.email);
                        if (newEmail && newEmail !== user.email) {{
                            fetch(`/admin/users/${{userId}}`, {{
                                method: 'PUT',
                                headers: {{ 'Content-Type': 'application/json' }},
                                body: JSON.stringify({{ email: newEmail }})
                            }})
                            .then(() => location.reload());
                        }}
                    }});
            }}
            
            function toggleUser(userId) {{
                if (confirm('Toggle user status?')) {{
                    fetch(`/admin/users/${{userId}}/toggle`, {{ method: 'POST' }})
                        .then(() => location.reload());
                }}
            }}
            
            function systemBackup() {{
                fetch('/admin/backup', {{ method: 'POST' }})
                    .then(response => response.json())
                    .then(data => alert('Backup initiated: ' + data.backup_id));
            }}
            
            function systemRestart() {{
                if (confirm('Restart the entire system? This will cause downtime.')) {{
                    fetch('/admin/restart', {{ method: 'POST' }})
                        .then(() => alert('System restart initiated...'));
                }}
            }}
            
            function configureSystem() {{
                alert('System configuration panel would open here');
            }}
            
            function viewLogs() {{
                window.open('/admin/logs', '_blank');
            }}
            
            function exportData() {{
                window.open('/admin/export', '_blank');
            }}
        </script>
    </body>
    </html>
    """

@admin_router.get("/users")
async def get_users() -> List[Dict]:
    """Get all users"""
    return users_db

@admin_router.get("/users/{user_id}")
async def get_user(user_id: str) -> Dict:
    """Get specific user"""
    user = next((u for u in users_db if u['id'] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@admin_router.post("/users")
async def create_user(user_data: Dict[str, str]) -> Dict:
    """Create new user"""
    user_id = f"USR-{len(users_db) + 1:03d}"
    new_user = {
        "id": user_id,
        "username": user_data["username"],
        "email": user_data["email"],
        "role": user_data["role"],
        "active": True,
        "created_date": datetime.now().strftime("%Y-%m-%d"),
        "last_login": None
    }
    users_db.append(new_user)
    logger.info(f"User created: {user_id}")
    return new_user

@admin_router.put("/users/{user_id}")
async def update_user(user_id: str, user_data: Dict[str, Any]) -> Dict:
    """Update user"""
    user = next((u for u in users_db if u['id'] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.update(user_data)
    logger.info(f"User updated: {user_id}")
    return user

@admin_router.post("/users/{user_id}/toggle")
async def toggle_user(user_id: str) -> Dict:
    """Toggle user active status"""
    user = next((u for u in users_db if u['id'] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user['active'] = not user['active']
    logger.info(f"User {'activated' if user['active'] else 'deactivated'}: {user_id}")
    return user

@admin_router.get("/stats")
async def get_system_stats() -> Dict:
    """Get system statistics"""
    return {
        "total_users": len(users_db),
        "active_users": len([u for u in users_db if u['active']]),
        "system_uptime": "99.8%",
        "last_backup": "2025-09-01T02:00:00",
        "disk_usage": "45%",
        "memory_usage": "67%",
        "timestamp": datetime.now().isoformat()
    }

@admin_router.post("/backup")
async def create_backup() -> Dict:
    """Create system backup"""
    backup_id = f"BKP-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    logger.info(f"Backup initiated: {backup_id}")
    return {
        "backup_id": backup_id,
        "status": "initiated",
        "timestamp": datetime.now().isoformat()
    }

@admin_router.post("/restart")
async def restart_system() -> Dict:
    """Restart system (admin only)"""
    logger.warning("System restart requested by admin")
    return {
        "status": "restart_initiated",
        "timestamp": datetime.now().isoformat(),
        "estimated_downtime": "2-3 minutes"
    }

@admin_router.get("/config")
async def get_config() -> Dict:
    """Get system configuration"""
    return system_config

@admin_router.put("/config")
async def update_config(config_data: SystemConfig) -> Dict:
    """Update system configuration"""
    system_config.update(config_data.dict())
    logger.info("System configuration updated")
    return system_config

@admin_router.get("/logs")
async def get_system_logs():
    """Get system logs (HTML page)"""
    return HTMLResponse("""
    <!DOCTYPE html>
    <html>
    <head><title>System Logs</title></head>
    <body style="font-family: monospace; padding: 2rem; background: #1a202c; color: #e2e8f0;">
        <h2>=� ChatterFix System Logs</h2>
        <div style="background: #2d3748; padding: 1rem; border-radius: 4px; max-height: 600px; overflow-y: scroll;">
            <div>[2025-09-01 15:30:15] INFO - System started</div>
            <div>[2025-09-01 15:30:16] INFO - Database connected</div>
            <div>[2025-09-01 15:30:17] INFO - AI models initialized</div>
            <div>[2025-09-01 15:45:23] INFO - User USR-001 logged in</div>
            <div>[2025-09-01 16:12:45] INFO - Work order WO-001 created</div>
            <div>[2025-09-01 16:34:12] INFO - Equipment EQ-001 health check completed</div>
            <div>[2025-09-01 17:21:33] INFO - Backup completed successfully</div>
            <div style="color: #fbb6ce;">[2025-09-01 18:45:21] WARN - High memory usage detected</div>
            <div style="color: #fc8181;">[2025-09-01 19:02:15] ERROR - Failed to connect to sensor EQ-003</div>
            <div>[2025-09-01 19:15:44] INFO - Sensor connection restored</div>
        </div>
        <button onclick="location.reload()" style="margin-top: 1rem; padding: 0.5rem 1rem;">Refresh Logs</button>
    </body>
    </html>
    """)

@admin_router.get("/export")
async def export_data():
    """Export system data"""
    return {
        "export_url": "/admin/download/chatterfix-export-20250901.json",
        "timestamp": datetime.now().isoformat(),
        "includes": ["users", "work_orders", "equipment", "configurations"]
    }