#!/usr/bin/env python3
"""
Main CMMS Router - All Modules
"""

from fastapi import APIRouter
import logging

logger = logging.getLogger(__name__)

# Import core working modules first
from admin import admin_router
from ai import ai_router  
from assets import assets_router
from dashboard import dashboard_router
from part import parts_router

# Try to import additional modules
try:
    from ai_enhanced import ai_enhanced_router
    AI_ENHANCED_AVAILABLE = True
except ImportError as e:
    logger.warning(f"AI Enhanced module not available: {e}")
    AI_ENHANCED_AVAILABLE = False

try:
    from prevenative import preventive_router  # Note: file is named "prevenative"
    PREVENTIVE_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Preventive module not available: {e}")
    PREVENTIVE_AVAILABLE = False

try:
    from technician import technician_router
    TECHNICIAN_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Technician module not available: {e}")
    TECHNICIAN_AVAILABLE = False

try:
    from workorders import workorders_router
    WORKORDERS_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Work Orders module not available: {e}")
    WORKORDERS_AVAILABLE = False

# Create main router
cmms_router = APIRouter(prefix="/cmms")

# Include core working modules
cmms_router.include_router(admin_router)
cmms_router.include_router(ai_router)
cmms_router.include_router(assets_router)
cmms_router.include_router(dashboard_router)
cmms_router.include_router(parts_router)

# Include additional modules if available
if AI_ENHANCED_AVAILABLE:
    cmms_router.include_router(ai_enhanced_router)
    logger.info("✅ AI Enhanced module loaded")

if PREVENTIVE_AVAILABLE:
    cmms_router.include_router(preventive_router)
    logger.info("✅ Preventive Maintenance module loaded")
    
if TECHNICIAN_AVAILABLE:
    cmms_router.include_router(technician_router)
    logger.info("✅ Technician Portal module loaded")
    
if WORKORDERS_AVAILABLE:
    cmms_router.include_router(workorders_router)
    logger.info("✅ Work Orders module loaded")

logger.info(f"🚀 CMMS Router initialized with {5 + sum([AI_ENHANCED_AVAILABLE, PREVENTIVE_AVAILABLE, TECHNICIAN_AVAILABLE, WORKORDERS_AVAILABLE])} modules")
