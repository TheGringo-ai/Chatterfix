#!/usr/bin/env python3
"""
CMMS Dashboard Module
Provides main dashboard functionality and overview statistics
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Dashboard router
dashboard_router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@dashboard_router.get("/main", response_class=HTMLResponse)
async def main_dashboard():
    """Main system dashboard with comprehensive overview"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChatterFix CMMS - Main Dashboard</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                color: white;
            }
            
            /* Navigation Styles */
            .navbar {
                background: rgba(0,0,0,0.3);
                backdrop-filter: blur(10px);
                border-bottom: 1px solid rgba(255,255,255,0.1);
                padding: 0;
                position: sticky;
                top: 0;
                z-index: 1000;
            }
            .navbar-brand {
                color: white;
                font-size: 1.5rem;
                font-weight: bold;
                text-decoration: none;
                padding: 1rem;
                display: inline-block;
            }
            .navbar-nav {
                list-style: none;
                display: flex;
                margin: 0;
                padding: 0;
                flex-wrap: wrap;
            }
            .nav-item {
                position: relative;
            }
            .nav-link {
                color: rgba(255,255,255,0.8);
                text-decoration: none;
                padding: 1rem 1.5rem;
                display: block;
                transition: all 0.3s ease;
                border-bottom: 2px solid transparent;
            }
            .nav-link:hover {
                color: white;
                background: rgba(255,255,255,0.1);
                border-bottom-color: #38ef7d;
            }
            .nav-link.active {
                color: white;
                background: rgba(255,255,255,0.15);
                border-bottom-color: #38ef7d;
            }
            
            /* Mobile Navigation */
            .navbar-toggle {
                display: none;
                background: none;
                border: none;
                color: white;
                font-size: 1.5rem;
                padding: 1rem;
                cursor: pointer;
            }
            
            @media (max-width: 768px) {
                .navbar-nav {
                    display: none;
                    width: 100%;
                    flex-direction: column;
                    background: rgba(0,0,0,0.5);
                }
                .navbar-nav.show {
                    display: flex;
                }
                .navbar-toggle {
                    display: block;
                }
                .navbar {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    flex-wrap: wrap;
                }
            }
            
            /* Dashboard Content */
            .header { 
                padding: 3rem 2rem 2rem;
                text-align: center;
            }
            .header h1 { 
                font-size: 3rem; 
                margin-bottom: 0.5rem;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            .container { 
                max-width: 1400px; 
                margin: 0 auto; 
                padding: 0 2rem 2rem; 
            }
            .stats-grid { 
                display: grid; 
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                gap: 2rem; 
                margin-bottom: 3rem;
            }
            .stat-card { 
                background: rgba(255,255,255,0.15); 
                border-radius: 15px; 
                padding: 2rem; 
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                text-align: center;
                transition: transform 0.3s ease;
            }
            .stat-card:hover {
                transform: translateY(-5px);
            }
            .stat-value {
                font-size: 3rem;
                font-weight: bold;
                color: #38ef7d;
                display: block;
                margin-bottom: 0.5rem;
            }
            .stat-label {
                color: rgba(255,255,255,0.8);
                font-size: 1.1rem;
            }
            
            .charts-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 2rem;
                margin-top: 2rem;
            }
            .chart-card {
                background: rgba(255,255,255,0.1);
                border-radius: 15px;
                padding: 2rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
            }
            .chart-title {
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar">
            <a href="/cmms/" class="navbar-brand">⚡ ChatterFix CMMS</a>
            <button class="navbar-toggle" onclick="toggleNav()">☰</button>
            <ul class="navbar-nav" id="navbarNav">
                <li class="nav-item"><a href="/cmms/dashboard/main" class="nav-link active">📊 Dashboard</a></li>
                <li class="nav-item"><a href="/cmms/workorders/dashboard" class="nav-link">📋 Work Orders</a></li>
                <li class="nav-item"><a href="/cmms/assets/dashboard" class="nav-link">⚙️ Assets</a></li>
                <li class="nav-item"><a href="/cmms/parts/dashboard" class="nav-link">📦 Parts</a></li>
                <li class="nav-item"><a href="/cmms/preventive/dashboard" class="nav-link">🔄 Preventive</a></li>
                <li class="nav-item"><a href="/cmms/technicians/portal" class="nav-link">👷 Technicians</a></li>
                <li class="nav-item"><a href="/cmms/ai-enhanced/dashboard/universal" class="nav-link">🤖 AI Assistant</a></li>
                <li class="nav-item"><a href="/cmms/admin/dashboard" class="nav-link">⚖️ Admin</a></li>
            </ul>
        </nav>
        
        <!-- Header -->
        <div class="header">
            <h1>📊 System Dashboard</h1>
            <p>Comprehensive CMMS Overview & Key Performance Indicators</p>
        </div>
        
        <!-- Main Content -->
        <div class="container">
            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value">24</span>
                    <span class="stat-label">Active Work Orders</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">47</span>
                    <span class="stat-label">Assets Monitored</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">3</span>
                    <span class="stat-label">Critical Alerts</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">95%</span>
                    <span class="stat-label">System Health</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">12</span>
                    <span class="stat-label">Technicians Online</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">$2.4K</span>
                    <span class="stat-label">Parts Inventory</span>
                </div>
            </div>
            
            <!-- Charts Section -->
            <div class="charts-grid">
                <div class="chart-card">
                    <h3 class="chart-title">Work Order Status</h3>
                    <canvas id="workOrderChart" width="400" height="300"></canvas>
                </div>
                <div class="chart-card">
                    <h3 class="chart-title">Asset Health Overview</h3>
                    <canvas id="assetHealthChart" width="400" height="300"></canvas>
                </div>
            </div>
        </div>
        
        <script>
            function toggleNav() {
                const nav = document.getElementById('navbarNav');
                nav.classList.toggle('show');
            }
            
            // Close mobile nav when clicking outside
            document.addEventListener('click', function(event) {
                const nav = document.getElementById('navbarNav');
                const toggle = document.querySelector('.navbar-toggle');
                if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                    nav.classList.remove('show');
                }
            });
            
            // Inject AI Assistant on page load
            window.addEventListener('DOMContentLoaded', function() {
                injectChatterFixAI();
            });
            
            function injectChatterFixAI() {
                if (window.chatterFixAIInjected) return;
                window.chatterFixAIInjected = true;
                
                // Create AI button
                const aiBtn = document.createElement('div');
                aiBtn.id = 'cfAIBtn';
                aiBtn.innerHTML = '🤖';
                aiBtn.style.cssText = `
                    position: fixed; bottom: 30px; right: 30px;
                    width: 65px; height: 65px; border-radius: 50%;
                    background: linear-gradient(135deg, #38ef7d, #11998e);
                    display: flex; align-items: center; justify-content: center;
                    cursor: pointer; z-index: 10000; font-size: 32px;
                    box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                    border: 3px solid rgba(255,255,255,0.3);
                    transition: all 0.3s ease;
                    animation: pulse-glow 3s infinite;
                `;
                
                // Add pulsing animation
                const style = document.createElement('style');
                style.textContent = `
                    @keyframes pulse-glow {
                        0%, 100% { 
                            transform: scale(1); 
                            box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                        }
                        50% { 
                            transform: scale(1.05); 
                            box-shadow: 0 8px 30px rgba(56,239,125,0.8);
                        }
                    }
                    #cfAIBtn:hover {
                        transform: scale(1.1) !important;
                        box-shadow: 0 8px 35px rgba(56,239,125,0.9) !important;
                    }
                `;
                document.head.appendChild(style);
                
                // Create AI panel
                const aiPanel = document.createElement('iframe');
                aiPanel.id = 'cfAIPanel';
                aiPanel.src = '/cmms/ai-enhanced/dashboard/universal';
                aiPanel.style.cssText = `
                    position: fixed; bottom: 100px; right: 30px;
                    width: 400px; height: 600px; max-width: 90vw; max-height: 70vh;
                    border: none; border-radius: 20px; display: none; z-index: 9999;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
                `;
                
                document.body.appendChild(aiBtn);
                document.body.appendChild(aiPanel);
                
                // Toggle panel
                aiBtn.onclick = () => {
                    const visible = aiPanel.style.display === 'block';
                    aiPanel.style.display = visible ? 'none' : 'block';
                    aiBtn.style.transform = visible ? 'scale(1)' : 'scale(0.9)';
                };
                
                aiBtn.onmouseover = () => aiBtn.style.transform = 'scale(1.1)';
                aiBtn.onmouseout = () => {
                    if (aiPanel.style.display !== 'block') {
                        aiBtn.style.transform = 'scale(1)';
                    }
                };
                
                console.log('✅ ChatterFix AI Assistant loaded');
            }
            
            // Auto-update stats
            setInterval(function() {
                // Simulate real-time updates
                const stats = document.querySelectorAll('.stat-value');
                stats.forEach((stat, index) => {
                    if (index === 0) { // Work Orders
                        const current = parseInt(stat.textContent);
                        stat.textContent = current + Math.floor(Math.random() * 2);
                    }
                });
            }, 30000);
        </script>
    </body>
    </html>
    """