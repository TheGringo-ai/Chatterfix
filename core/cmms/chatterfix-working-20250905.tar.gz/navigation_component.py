#!/usr/bin/env python3
"""
Navigation Component for ChatterFix CMMS
Provides consistent navigation bar across all modules
"""

def get_navigation_html(current_page: str = "", breadcrumbs: list = None) -> str:
    """
    Generate navigation HTML with current page highlighted
    
    Args:
        current_page: The current page identifier (dashboard, workorders, assets, etc.)
    
    Returns:
        HTML string for the navigation component
    """
    
    nav_items = [
        {"id": "dashboard", "href": "/cmms/dashboard/main", "icon": "📊", "label": "Dashboard"},
        {"id": "workorders", "href": "/cmms/workorders/dashboard", "icon": "📋", "label": "Work Orders"},
        {"id": "assets", "href": "/cmms/assets/dashboard", "icon": "⚙️", "label": "Assets"},
        {"id": "parts", "href": "/cmms/parts/dashboard", "icon": "📦", "label": "Parts"},
        {"id": "preventive", "href": "/cmms/preventive/dashboard", "icon": "🔄", "label": "Preventive"},
        {"id": "technicians", "href": "/cmms/technicians/portal", "icon": "👷", "label": "Technicians"},
        {"id": "ai", "href": "/cmms/ai-enhanced/dashboard/universal", "icon": "🤖", "label": "AI Assistant"},
        {"id": "admin", "href": "/cmms/admin/dashboard", "icon": "⚖️", "label": "Admin"}
    ]
    
    nav_links = ""
    for item in nav_items:
        active_class = "active" if item["id"] == current_page else ""
        nav_links += f"""
            <li class="nav-item">
                <a href="{item['href']}" class="nav-link {active_class}">
                    {item['icon']} {item['label']}
                </a>
            </li>"""
    
    # Generate breadcrumbs if provided
    breadcrumb_html = ""
    if breadcrumbs:
        breadcrumb_items = []
        for crumb in breadcrumbs:
            if 'url' in crumb:
                breadcrumb_items.append(f'<a href="{crumb["url"]}" class="breadcrumb-link">{crumb["name"]}</a>')
            else:
                breadcrumb_items.append(f'<span class="breadcrumb-current">{crumb["name"]}</span>')
        breadcrumb_html = f"""
        <div class="breadcrumb-container">
            <nav class="breadcrumb">
                <a href="/cmms/" class="breadcrumb-link">🏠 Home</a>
                <span class="breadcrumb-separator">›</span>
                {' <span class="breadcrumb-separator">›</span> '.join(breadcrumb_items)}
            </nav>
        </div>
        """

    return f"""
        <nav class="navbar">
            <a href="/cmms/" class="navbar-brand">⚡ ChatterFix CMMS</a>
            <button class="navbar-toggle" onclick="toggleNav()">☰</button>
            <ul class="navbar-nav" id="navbarNav">
                {nav_links}
            </ul>
        </nav>
        {breadcrumb_html}
    """

def get_navigation_styles() -> str:
    """
    Get CSS styles for the navigation component
    
    Returns:
        CSS styles as string
    """
    return """
        /* Navigation Styles */
        .navbar {
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
            padding: 1rem;
            display: inline-block;
        }
        .navbar-nav {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            flex-wrap: wrap;
        }
        .nav-item {
            position: relative;
        }
        .nav-link {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: block;
            transition: all 0.3s ease;
            border-bottom: 2px solid transparent;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255,255,255,0.1);
            border-bottom-color: #38ef7d;
        }
        .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.15);
            border-bottom-color: #38ef7d;
        }
        
        /* Mobile Navigation */
        .navbar-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            padding: 1rem;
            cursor: pointer;
        }
        
        /* Breadcrumb Styles */
        .breadcrumb-container {
            background: rgba(0,0,0,0.2);
            backdrop-filter: blur(5px);
            padding: 0.75rem 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .breadcrumb {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            font-size: 0.9rem;
        }
        .breadcrumb-link {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .breadcrumb-link:hover {
            color: #38ef7d;
        }
        .breadcrumb-current {
            color: white;
            font-weight: 500;
        }
        .breadcrumb-separator {
            margin: 0 0.5rem;
            color: rgba(255,255,255,0.4);
        }
        
        @media (max-width: 768px) {
            .navbar-nav {
                display: none;
                width: 100%;
                flex-direction: column;
                background: rgba(0,0,0,0.5);
            }
            .navbar-nav.show {
                display: flex;
            }
            .navbar-toggle {
                display: block;
            }
            .navbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
            }
            .breadcrumb-container {
                padding: 0.5rem;
            }
            .breadcrumb {
                font-size: 0.8rem;
            }
            .breadcrumb-separator {
                margin: 0 0.25rem;
            }
        }
    """

def get_navigation_javascript() -> str:
    """
    Get JavaScript code for navigation functionality with AI assistant
    
    Returns:
        JavaScript code as string with AI injection
    """
    return """
        function toggleNav() {
            const nav = document.getElementById('navbarNav');
            nav.classList.toggle('show');
        }
        
        // Close mobile nav when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('navbarNav');
            const toggle = document.querySelector('.navbar-toggle');
            if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                nav.classList.remove('show');
            }
        });
        
        // Inject AI Assistant on page load
        window.addEventListener('DOMContentLoaded', function() {
            injectChatterFixAI();
        });
        
        function injectChatterFixAI() {
            if (window.chatterFixAIInjected) return;
            window.chatterFixAIInjected = true;
            
            // Create AI button
            const aiBtn = document.createElement('div');
            aiBtn.id = 'cfAIBtn';
            aiBtn.innerHTML = '🤖';
            aiBtn.style.cssText = `
                position: fixed; bottom: 30px; right: 30px;
                width: 65px; height: 65px; border-radius: 50%;
                background: linear-gradient(135deg, #38ef7d, #11998e);
                display: flex; align-items: center; justify-content: center;
                cursor: pointer; z-index: 10000; font-size: 32px;
                box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                border: 3px solid rgba(255,255,255,0.3);
                transition: all 0.3s ease;
                animation: pulse-glow 3s infinite;
            `;
            
            // Add pulsing animation
            const style = document.createElement('style');
            style.textContent = \`
                @keyframes pulse-glow {
                    0%, 100% { 
                        transform: scale(1); 
                        box-shadow: 0 6px 25px rgba(56,239,125,0.6);
                    }
                    50% { 
                        transform: scale(1.05); 
                        box-shadow: 0 8px 30px rgba(56,239,125,0.8);
                    }
                }
                #cfAIBtn:hover {
                    transform: scale(1.1) !important;
                    box-shadow: 0 8px 35px rgba(56,239,125,0.9) !important;
                }
            \`;
            document.head.appendChild(style);
            
            // Create AI panel
            const aiPanel = document.createElement('iframe');
            aiPanel.id = 'cfAIPanel';
            aiPanel.src = '/ai-enhanced/dashboard/universal';
            aiPanel.style.cssText = `
                position: fixed; bottom: 100px; right: 30px;
                width: 400px; height: 600px; max-width: 90vw; max-height: 70vh;
                border: none; border-radius: 20px; display: none; z-index: 9999;
                box-shadow: 0 10px 40px rgba(0,0,0,0.5);
            `;
            
            document.body.appendChild(aiBtn);
            document.body.appendChild(aiPanel);
            
            // Toggle panel
            aiBtn.onclick = () => {
                const visible = aiPanel.style.display === 'block';
                aiPanel.style.display = visible ? 'none' : 'block';
                aiBtn.style.transform = visible ? 'scale(1)' : 'scale(0.9)';
            };
            
            aiBtn.onmouseover = () => aiBtn.style.transform = 'scale(1.1)';
            aiBtn.onmouseout = () => {
                if (aiPanel.style.display !== 'block') {
                    aiBtn.style.transform = 'scale(1)';
                }
            };
            
            console.log('✅ ChatterFix AI Assistant loaded');
        }
    """

def get_base_styles() -> str:
    """
    Get base CSS styles consistent across all modules
    
    Returns:
        CSS styles as string
    """
    return """
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        
        .container { 
            max-width: 1400px; 
            margin: 0 auto; 
            padding: 2rem; 
        }
        
        .header { 
            padding: 2rem;
            text-align: center;
            background: rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 2rem;
        }
        
        .header h1 { 
            font-size: 2.5rem; 
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .card { 
            background: rgba(255,255,255,0.15); 
            border-radius: 15px; 
            padding: 2rem; 
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 2rem;
        }
        
        .grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 2rem; 
            margin-bottom: 2rem;
        }
        
        .btn { 
            background: #4299e1; 
            color: white; 
            border: none; 
            padding: 0.75rem 1.5rem; 
            border-radius: 8px; 
            cursor: pointer; 
            font-size: 1rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { 
            background: #3182ce; 
            transform: translateY(-2px);
        }
        .btn-success { background: #38a169; }
        .btn-success:hover { background: #2f855a; }
        .btn-warning { background: #d69e2e; }
        .btn-warning:hover { background: #b7791f; }
        .btn-danger { background: #e53e3e; }
        .btn-danger:hover { background: #c53030; }
        
        .table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 1rem; 
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .table th, .table td { 
            padding: 1rem; 
            text-align: left; 
            border-bottom: 1px solid rgba(255,255,255,0.1); 
        }
        .table th { 
            background: rgba(0,0,0,0.3); 
            font-weight: 600; 
        }
        
        .stat-value { 
            font-size: 2rem; 
            font-weight: bold; 
            color: #38ef7d; 
        }
        
        .status-operational { color: #38a169; }
        .status-maintenance { color: #d69e2e; }
        .status-down { color: #e53e3e; }
        .status-active { color: #38a169; }
        .status-inactive { color: #e53e3e; }
    """