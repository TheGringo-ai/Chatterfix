#!/usr/bin/env python3
"""
ChatterFix CMMS - Complete AI-Enhanced Maintenance Management System
Main Application with ChatterFix Specific AI (No external dependencies)
"""

import logging
import sqlite3
from datetime import datetime
import os

import requests
from fastapi import FastAPI, HTTPException, Request, Form
from pydantic import BaseModel
from typing import Optional
from fastapi.responses import HTMLResponse, JSONResponse

# Import universal AI endpoints
from universal_ai_endpoints import add_universal_ai_endpoints
# Import unified styles, fallback to inline if not available
try:
    from unified_cmms_system import get_unified_styles
except ImportError:
    from typing import Literal

    def get_unified_styles() -> Literal["""
        :root {
            --primary-navy: #032B44;
            --secondary-green: #4CAF50;
            --accent-yellow: #F7DC6F;
            --background-white: #FFFFFF;
            --text-dark: #2C3E50;
            --text-light: #7F8C8D;
            --border-light: #E8E8E8;
            --sidebar-bg: #F8F9FA;
            --success: #27AE60;
            --warning: #F39C12;
            --danger: #E74C3C;
            --info: #3498DB;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--background-white);
            color: var(--text-dark);
            line-height: 1.6;
        }
        
        .header {
            background: var(--primary-navy);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            background: var(--background-white);
        }
        
        .nav-pills {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            padding: 1rem;
            background: var(--sidebar-bg);
            border-radius: 8px;
            border: 1px solid var(--border-light);
        }
        
        .nav-link {
            padding: 0.75rem 1.5rem;
            background: white;
            color: var(--text-dark);
            text-decoration: none;
            border-radius: 6px;
            border: 1px solid var(--border-light);
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .nav-link:hover {
            background: var(--primary-navy);
            color: white;
            border-color: var(--primary-navy);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
            margin: 0.25rem;
        }
        
        .btn-primary {
            background: var(--primary-navy);
            color: white;
        }
        
        .btn-primary:hover {
            background: #041f2f;
            transform: translateY(-1px);
        }
        
        .btn-success {
            background: var(--secondary-green);
            color: white;
        }
        
        .btn-success:hover {
            background: #45a049;
        }
        
        .btn-warning {
            background: var(--warning);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 1px solid var(--border-light);
            margin-bottom: 1.5rem;
            overflow: hidden;
        }
        
        .card-header {
            background: var(--sidebar-bg);
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border-light);
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 1rem;
        }
        
        .table th, .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-light);
        }
        
        .table th {
            background: var(--sidebar-bg);
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin: 1rem 0;
            border-left: 4px solid;
        }
        
        .alert-info {
            background: rgba(52, 152, 219, 0.1);
            border-left-color: var(--info);
            color: #1c4e80;
        }
        
        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border-left-color: var(--success);
            color: #1e5631;
        }
        
        .alert-warning {
            background: rgba(243, 156, 18, 0.1);
            border-left-color: var(--warning);
            color: #8b5a0c;
        }
        
        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            border-left-color: var(--danger);
            color: #a94442;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border-light);
            border-radius: 6px;
            font-size: 1rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-navy);
            box-shadow: 0 0 0 3px rgba(3, 43, 68, 0.1);
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .status-open {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }
        
        .status-in-progress {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .status-completed {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }
        
        .priority-high {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }
        
        .priority-medium {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .priority-low {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }
        """]:
        return """
        :root {
            --primary-navy: #032B44;
            --secondary-green: #4CAF50;
            --accent-yellow: #F7DC6F;
            --background-white: #FFFFFF;
            --text-dark: #2C3E50;
            --text-light: #7F8C8D;
            --border-light: #E8E8E8;
            --sidebar-bg: #F8F9FA;
            --success: #27AE60;
            --warning: #F39C12;
            --danger: #E74C3C;
            --info: #3498DB;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--background-white);
            color: var(--text-dark);
            line-height: 1.6;
        }
        
        .header {
            background: var(--primary-navy);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            background: var(--background-white);
        }
        
        .nav-pills {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            padding: 1rem;
            background: var(--sidebar-bg);
            border-radius: 8px;
            border: 1px solid var(--border-light);
        }
        
        .nav-link {
            padding: 0.75rem 1.5rem;
            background: white;
            color: var(--text-dark);
            text-decoration: none;
            border-radius: 6px;
            border: 1px solid var(--border-light);
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .nav-link:hover {
            background: var(--primary-navy);
            color: white;
            border-color: var(--primary-navy);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
            margin: 0.25rem;
        }
        
        .btn-primary {
            background: var(--primary-navy);
            color: white;
        }
        
        .btn-primary:hover {
            background: #041f2f;
            transform: translateY(-1px);
        }
        
        .btn-success {
            background: var(--secondary-green);
            color: white;
        }
        
        .btn-success:hover {
            background: #45a049;
        }
        
        .btn-warning {
            background: var(--warning);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 1px solid var(--border-light);
            margin-bottom: 1.5rem;
            overflow: hidden;
        }
        
        .card-header {
            background: var(--sidebar-bg);
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border-light);
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 1rem;
        }
        
        .table th, .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-light);
        }
        
        .table th {
            background: var(--sidebar-bg);
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin: 1rem 0;
            border-left: 4px solid;
        }
        
        .alert-info {
            background: rgba(52, 152, 219, 0.1);
            border-left-color: var(--info);
            color: #1c4e80;
        }
        
        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border-left-color: var(--success);
            color: #1e5631;
        }
        
        .alert-warning {
            background: rgba(243, 156, 18, 0.1);
            border-left-color: var(--warning);
            color: #8b5a0c;
        }
        
        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            border-left-color: var(--danger);
            color: #a94442;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border-light);
            border-radius: 6px;
            font-size: 1rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-navy);
            box-shadow: 0 0 0 3px rgba(3, 43, 68, 0.1);
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .status-open {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }
        
        .status-in-progress {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .status-completed {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }
        
        .priority-high {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }
        
        .priority-medium {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .priority-low {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }
        """

# Pydantic Models for CRUD operations
class WorkOrderUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    technician: Optional[str] = None
    assigned_asset_id: Optional[int] = None

class PartUpdate(BaseModel):
    name: Optional[str] = None
    part_number: Optional[str] = None
    supplier: Optional[str] = None
    current_stock: Optional[int] = None
    minimum_stock: Optional[int] = None
    unit_cost: Optional[float] = None

class AssetUpdate(BaseModel):
    name: Optional[str] = None
    asset_type: Optional[str] = None
    location: Optional[str] = None
    criticality: Optional[str] = None

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="ChatterFix CMMS", description="Complete Maintenance Management System")

# Database configuration - Enterprise ready
try:
    from enterprise_database import db_manager, get_database_connection, init_database
    logger.info("Using enterprise database manager")
except ImportError:
    # Fallback to SQLite if enterprise module not available
    DATABASE_PATH = "./data/cmms.db"
    BACKUP_DATABASE_PATH = "./data/backup/cmms.db"

    def ensure_database_dir():
        """Ensure database directory exists with proper permissions"""
        db_dir = os.path.dirname(DATABASE_PATH)
        backup_dir = os.path.dirname(BACKUP_DATABASE_PATH)
        
        for directory in [db_dir, backup_dir]:
            os.makedirs(directory, exist_ok=True)
            
        # If main database doesn't exist but backup does, copy it
        if not os.path.exists(DATABASE_PATH) and os.path.exists(BACKUP_DATABASE_PATH):
            import shutil
            shutil.copy2(BACKUP_DATABASE_PATH, DATABASE_PATH)
            logger.info(f"Copied database from {BACKUP_DATABASE_PATH} to {DATABASE_PATH}")

    def get_database_connection():
        """Get SQLite database connection"""
        ensure_database_dir()
        return sqlite3.connect("./chatterfix_cmms.db")

    def init_database():
        """Initialize SQLite database with required tables"""
        ensure_database_dir()
        
        conn = get_database_connection()
        cursor = conn.cursor()

        # Create tables
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS work_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'Open',
            priority TEXT DEFAULT 'Medium',
            asset_id INTEGER,
            assigned_to TEXT,
            created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            due_date TIMESTAMP,
            completed_date TIMESTAMP,
            estimated_hours REAL,
            actual_hours REAL,
            cost REAL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT,
            location TEXT,
            manufacturer TEXT,
            model TEXT,
            serial_number TEXT,
            install_date DATE,
            status TEXT DEFAULT 'Active',
            criticality TEXT DEFAULT 'Medium',
            last_maintenance DATE,
            next_maintenance DATE
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_number TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            category TEXT,
            unit_cost REAL,
            stock_quantity INTEGER DEFAULT 0,
            min_stock INTEGER DEFAULT 0,
            location TEXT,
            supplier TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ai_interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            user_message TEXT NOT NULL,
            ai_response TEXT NOT NULL,
            context_type TEXT DEFAULT 'general'
            )
        """)

        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")

class ChatterFixAIClient:
    """ChatterFix CMMS AI Assistant - No external dependencies needed"""
    
    def __init__(self):
        """Initialize ChatterFix AI with built-in CMMS intelligence"""
        self.system_name = "ChatterFix CMMS AI Assistant"
        logger.info("ChatterFix AI Assistant initialized with built-in CMMS intelligence")
    
    async def query(self, prompt: str, context: str = "") -> str:
        """Generate ChatterFix CMMS-specific responses"""
        try:
            return self.get_chatterfix_response(prompt, context)
        except Exception as e:
            logger.error(f"ChatterFix AI error: {e}")
            return "I'm here to help with your ChatterFix CMMS operations. Please try rephrasing your question."
    
    def get_chatterfix_response(self, message: str, context: str = "") -> str:
        """Generate ChatterFix CMMS-specific responses"""
        msg_lower = message.lower()
        
        # Emergency/Urgent situations
        if any(word in msg_lower for word in ['emergency', 'urgent', 'critical', 'down', 'broken', 'leak', 'fire', 'smoke']):
            return "🚨 **EMERGENCY RESPONSE ACTIVATED** 🚨\n\n" + \
                   "I've detected this is an urgent situation. Here's what to do:\n\n" + \
                   "1. **Immediate Safety**: Ensure area is safe and evacuated if needed\n" + \
                   "2. **Create High-Priority Work Order**: Go to Work Orders → Create New → Set Priority to CRITICAL\n" + \
                   "3. **Notify Management**: Contact your supervisor and facilities manager\n" + \
                   "4. **Document Everything**: Take photos, note time, location, and affected equipment\n\n" + \
                   "Would you like me to guide you through creating an emergency work order?"
        
        # Work Order Management
        elif any(phrase in msg_lower for phrase in ['work order', 'wo', 'create order', 'new order', 'work request']):
            if 'create' in msg_lower or 'new' in msg_lower:
                return "I'll help you create a new work order! Here's the step-by-step process:\n\n" + \
                       "**📋 Creating a Work Order:**\n" + \
                       "1. Navigate to **Work Orders** → **Create New**\n" + \
                       "2. Fill in required fields:\n" + \
                       "   • **Asset/Equipment**: Select the equipment needing work\n" + \
                       "   • **Work Type**: Corrective, Preventive, or Emergency\n" + \
                       "   • **Priority**: Low, Medium, High, or Critical\n" + \
                       "   • **Description**: Detailed problem description\n" + \
                       "3. **Assign Technician** (if known)\n" + \
                       "4. **Set Due Date** based on priority\n" + \
                       "5. **Add Parts** (if already identified)\n" + \
                       "6. **Submit** for approval\n\n" + \
                       "💡 **Pro Tip**: Include photos and detailed symptoms for faster resolution!"
            else:
                return "I can help you with work order management:\n\n" + \
                       "**🔧 Work Order Operations:**\n" + \
                       "• **View Active Orders**: Dashboard → Work Orders\n" + \
                       "• **Update Status**: Open order → Change status (In Progress, Completed, etc.)\n" + \
                       "• **Add Notes**: Document work performed and findings\n" + \
                       "• **Track Time**: Log labor hours for accurate reporting\n" + \
                       "• **Close Orders**: Complete final inspection and close when done\n\n" + \
                       "What specific work order task can I help you with?"
        
        # Asset/Equipment Management
        elif any(word in msg_lower for word in ['asset', 'equipment', 'machine', 'pump', 'motor', 'hvac', 'boiler']):
            return "I'm your asset management expert! Here's how I can help:\n\n" + \
                   "**🏭 Asset Management Features:**\n" + \
                   "• **Asset Registry**: View all equipment details, locations, and specifications\n" + \
                   "• **Maintenance History**: Track all work performed on each asset\n" + \
                   "• **Performance Metrics**: Monitor uptime, MTBF, and maintenance costs\n" + \
                   "• **Warranty Tracking**: Keep track of warranty periods and coverage\n" + \
                   "• **Documentation**: Store manuals, drawings, and certificates\n\n" + \
                   "**Quick Actions:**\n" + \
                   "• Go to **Assets** → Search for your equipment\n" + \
                   "• Click on asset to view full details and history\n" + \
                   "• Use **QR Scanner** for quick asset identification\n\n" + \
                   "Which asset do you need help with?"
        
        # Maintenance Scheduling
        elif any(phrase in msg_lower for phrase in ['maintenance', 'schedule', 'preventive', 'pm', 'inspection']):
            return "Let me help you with maintenance scheduling! 📅\n\n" + \
                   "**🔄 Preventive Maintenance (PM):**\n" + \
                   "• **View PM Schedule**: Maintenance → Preventive Maintenance\n" + \
                   "• **Create PM Plans**: Set frequency (daily, weekly, monthly, yearly)\n" + \
                   "• **Assign Tasks**: Define specific procedures and checklists\n" + \
                   "• **Auto-Generation**: System creates work orders automatically\n\n" + \
                   "**📊 Scheduling Tips:**\n" + \
                   "• Base frequency on manufacturer recommendations\n" + \
                   "• Consider equipment criticality and usage patterns\n" + \
                   "• Schedule during planned downtime when possible\n" + \
                   "• Include safety checks and calibrations\n\n" + \
                   "Need help setting up a specific PM schedule?"
        
        # Parts and Inventory
        elif any(word in msg_lower for word in ['parts', 'inventory', 'stock', 'spare', 'component']):
            return "I'll help you manage parts and inventory efficiently! 📦\n\n" + \
                   "**🔧 Parts Management:**\n" + \
                   "• **Search Parts**: Parts → Search by part number, description, or equipment\n" + \
                   "• **Check Stock**: View current quantities and locations\n" + \
                   "• **Create Requisitions**: Request parts for work orders\n" + \
                   "• **Update Inventory**: Record receipts and usage\n" + \
                   "• **Set Reorder Points**: Automated low-stock alerts\n\n" + \
                   "**💡 Inventory Best Practices:**\n" + \
                   "• Link parts to specific equipment for easy identification\n" + \
                   "• Keep accurate counts with regular cycle counts\n" + \
                   "• Track supplier information and lead times\n" + \
                   "• Monitor usage patterns for optimization\n\n" + \
                   "What parts information do you need?"
        
        # Reports and Analytics
        elif any(word in msg_lower for word in ['report', 'analytics', 'dashboard', 'metrics', 'kpi']):
            return "Let me show you ChatterFix's powerful reporting capabilities! 📊\n\n" + \
                   "**📈 Available Reports:**\n" + \
                   "• **Work Order Reports**: Completion rates, response times, costs\n" + \
                   "• **Asset Performance**: Uptime, MTBF, maintenance costs per asset\n" + \
                   "• **Inventory Reports**: Stock levels, usage, reorder recommendations\n" + \
                   "• **Technician Performance**: Productivity, skills tracking\n" + \
                   "• **Cost Analysis**: Budget vs actual, cost per repair\n\n" + \
                   "**🎯 Key Performance Indicators:**\n" + \
                   "• Equipment uptime percentage\n" + \
                   "• Average work order completion time\n" + \
                   "• Preventive vs reactive maintenance ratio\n" + \
                   "• Parts availability rate\n\n" + \
                   "Navigate to **Reports** → Select report type → Set date range and filters"
        
        # Troubleshooting Help
        elif any(word in msg_lower for word in ['trouble', 'problem', 'issue', 'fix', 'repair', 'diagnose']):
            return "I'm here to help troubleshoot your equipment issues! 🔍\n\n" + \
                   "**🛠️ Troubleshooting Process:**\n" + \
                   "1. **Safety First**: Ensure equipment is properly locked out/tagged out\n" + \
                   "2. **Gather Information**: What symptoms are you observing?\n" + \
                   "3. **Check History**: Review past work orders for similar issues\n" + \
                   "4. **Basic Checks**: Power, connections, fluid levels, filters\n" + \
                   "5. **Document Findings**: Create work order with detailed observations\n\n" + \
                   "**💡 Quick Diagnostic Tips:**\n" + \
                   "• Unusual sounds, vibrations, or smells?\n" + \
                   "• Any recent changes or maintenance performed?\n" + \
                   "• Check equipment manuals in the asset documentation\n\n" + \
                   "Describe the specific problem you're experiencing, and I'll provide targeted guidance!"
        
        # Help and Navigation
        elif any(word in msg_lower for word in ['help', 'how', 'navigate', 'use', 'guide']):
            return "Welcome to ChatterFix CMMS! I'm here to help you navigate the system. 🧭\n\n" + \
                   "**🎯 Quick Start Guide:**\n" + \
                   "• **Dashboard**: Your control center for overview and alerts\n" + \
                   "• **Work Orders**: Create, assign, and track maintenance work\n" + \
                   "• **Assets**: Equipment registry and maintenance history\n" + \
                   "• **Parts**: Inventory management and requisitions\n" + \
                   "• **Maintenance**: Preventive maintenance scheduling\n" + \
                   "• **Reports**: Analytics and performance metrics\n\n" + \
                   "**💬 Ask me about:**\n" + \
                   "• Creating work orders\n" + \
                   "• Equipment troubleshooting\n" + \
                   "• Maintenance scheduling\n" + \
                   "• Parts management\n" + \
                   "• Report generation\n\n" + \
                   "What would you like to learn about first?"
        
        # Default response for general queries
        else:
            return f"I understand you're asking about \"{message}\". As your ChatterFix CMMS assistant, I specialize in:\n\n" + \
                   "🔧 **Maintenance Operations**\n" + \
                   "• Work order management and tracking\n" + \
                   "• Equipment troubleshooting and repair guidance\n" + \
                   "• Preventive maintenance scheduling\n\n" + \
                   "📊 **Asset Management**\n" + \
                   "• Equipment registry and documentation\n" + \
                   "• Performance monitoring and analytics\n" + \
                   "• Parts inventory and procurement\n\n" + \
                   "Could you be more specific about what you need help with? For example:\n" + \
                   "• \"How do I create a work order?\"\n" + \
                   "• \"Emergency pump leak in Building A\"\n" + \
                   "• \"Schedule maintenance for Motor #123\""

# Initialize ChatterFix AI client
chatterfix_ai = ChatterFixAIClient()

def store_ai_interaction(user_message: str, ai_response: str, context_type: str = "general"):
    """Store AI interaction in database for analytics"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO ai_interactions (user_message, ai_response, context_type) VALUES (?, ?, ?)",
            (user_message, ai_response, context_type)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error storing AI interaction: {e}")

async def get_maintenance_context():
    """Get current maintenance context for AI"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Get recent work orders
        cursor.execute("SELECT COUNT(*) FROM work_orders WHERE status = 'Open'")
        open_orders = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM work_orders WHERE priority = 'Critical' AND status = 'Open'")
        critical_orders = cursor.fetchone()[0]
        
        # Get asset count
        cursor.execute("SELECT COUNT(*) FROM assets WHERE status = 'Active'")
        active_assets = cursor.fetchone()[0]
        
        conn.close()
        
        context = f"""
Current System Status:
- Open Work Orders: {open_orders}
- Critical Priority Orders: {critical_orders}
- Active Assets: {active_assets}
"""
        return context
    except Exception as e:
        logger.error(f"Error getting maintenance context: {e}")
        return "System context unavailable"

@app.get("/")
async def landing_page():
    """Stunning landing page for ChatterFix CMMS"""
    styles = get_unified_styles()
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ChatterFix - Voice-Powered Enterprise CMMS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <style>
        {styles}
        
        .hero-section {{
            background: linear-gradient(135deg, var(--primary-navy) 0%, #1a4f7a 100%);
            color: white;
            padding: 4rem 2rem;
            text-align: center;
            min-height: 70vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }}
        
        .hero-title {{
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            line-height: 1.2;
        }}
        
        .hero-subtitle {{
            font-size: 1.5rem;
            font-weight: 400;
            margin-bottom: 3rem;
            opacity: 0.9;
            max-width: 600px;
        }}
        
        .cta-button {{
            background: var(--secondary-green);
            color: white;
            font-size: 1.2rem;
            font-weight: 600;
            padding: 1rem 3rem;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
        }}
        
        .cta-button:hover {{
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(76, 175, 80, 0.4);
        }}
        
        .features-section {{
            padding: 4rem 2rem;
            background: white;
        }}
        
        .features-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }}
        
        .feature-card {{
            text-align: center;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            border: 1px solid var(--border-light);
            transition: transform 0.3s ease;
        }}
        
        .feature-card:hover {{
            transform: translateY(-5px);
        }}
        
        .feature-icon {{
            font-size: 3rem;
            margin-bottom: 1rem;
        }}
        
        .feature-title {{
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-navy);
            margin-bottom: 1rem;
        }}
        
        .feature-description {{
            color: var(--text-light);
            line-height: 1.6;
        }}
        
        .stats-section {{
            background: var(--sidebar-bg);
            padding: 3rem 2rem;
            text-align: center;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            max-width: 800px;
            margin: 0 auto;
        }}
        
        .stat-item {{
            color: var(--primary-navy);
        }}
        
        .stat-number {{
            font-size: 2.5rem;
            font-weight: 700;
            display: block;
        }}
        
        .stat-label {{
            font-size: 1rem;
            font-weight: 500;
            opacity: 0.8;
        }}
        </style>
    </head>
    <body>
        <div class="hero-section">
            <h1 class="hero-title">🚀 ChatterFix</h1>
            <p class="hero-subtitle">
                Voice-Powered Enterprise CMMS Platform
                <br>Transform Your Maintenance Operations with AI
            </p>
            <a href="/dashboard" class="cta-button">🎯 Try ChatterFix Now</a>
        </div>
        
        <div class="features-section">
            <div class="container">
                <h2 style="text-align: center; color: var(--primary-navy); margin-bottom: 3rem; font-size: 2.5rem;">
                    Enterprise-Ready Features
                </h2>
                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon">🎤</div>
                        <h3 class="feature-title">Voice Commands</h3>
                        <p class="feature-description">
                            Control your CMMS with natural voice commands. Create work orders, check asset status, and get insights hands-free.
                        </p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🤖</div>
                        <h3 class="feature-title">AI Assistant</h3>
                        <p class="feature-description">
                            LLaMA 3.1 powered AI assistant provides intelligent maintenance recommendations and predictive insights.
                        </p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📊</div>
                        <h3 class="feature-title">Real-time Analytics</h3>
                        <p class="feature-description">
                            Comprehensive dashboards with real-time metrics, predictive maintenance alerts, and performance tracking.
                        </p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🔧</div>
                        <h3 class="feature-title">Complete CRUD Operations</h3>
                        <p class="feature-description">
                            Full work order, asset, and parts management with enterprise-grade database support.
                        </p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🛡️</div>
                        <h3 class="feature-title">Enterprise Security</h3>
                        <p class="feature-description">
                            JWT authentication, role-based access control, and audit logging for enterprise compliance.
                        </p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📱</div>
                        <h3 class="feature-title">Mobile Ready</h3>
                        <p class="feature-description">
                            Responsive design optimized for field technicians working on mobile devices and tablets.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="stats-section">
            <h2 style="color: var(--primary-navy); margin-bottom: 2rem; font-size: 2rem;">
                Platform Performance
            </h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-number">< 2.5s</span>
                    <span class="stat-label">Page Load Time</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">99.9%</span>
                    <span class="stat-label">Uptime</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">24/7</span>
                    <span class="stat-label">AI Assistant</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">500+</span>
                    <span class="stat-label">Enterprise Ready</span>
                </div>
            </div>
        </div>
        
        <footer style="background: var(--primary-navy); color: white; text-align: center; padding: 2rem;">
            <p>&copy; 2024 ChatterFix CMMS - Voice-Powered Enterprise Platform</p>
            <p style="opacity: 0.8; margin-top: 0.5rem;">Ready to revolutionize your maintenance operations?</p>
        </footer>
        <script src="/ai-inject.js" async></script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.get("/dashboard")
async def dashboard():
    """Main dashboard with system overview"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Get dashboard metrics
        cursor.execute("SELECT COUNT(*) FROM work_orders WHERE status = 'Open'")
        open_orders = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM work_orders WHERE status = 'Completed' AND date(completed_date) = date('now')")
        completed_today = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM work_orders WHERE priority = 'Critical' AND status = 'Open'")
        critical_orders = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM assets WHERE status = 'Active'")
        active_assets = cursor.fetchone()[0]
        
        # Get recent work orders
        cursor.execute("""
            SELECT id, title, priority, status, created_date 
            FROM work_orders 
            ORDER BY created_date DESC 
            LIMIT 5
        """)
        recent_orders = cursor.fetchall()
        
        conn.close()
        
        # Generate HTML
        styles = get_unified_styles()
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>ChatterFix CMMS - Enterprise Dashboard</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
            <style>{styles}</style>
        </head>
        <body>
            <header class="header">
                <h1>ChatterFix CMMS</h1>
            </header>
            
            <div class="container">
                <div class="nav-pills">
                    <a href="/dashboard" class="nav-link">Dashboard</a>
                    <a href="/work-orders" class="nav-link">Work Orders</a>
                    <a href="/assets" class="nav-link">Assets</a>
                    <a href="/parts" class="nav-link">Parts</a>
                    <a href="/quality" class="nav-link">Quality</a>
                    <a href="/finance" class="nav-link">Finance</a>
                    <a href="/hr" class="nav-link">HR</a>
                </div>
                
                <div class="card">
                    <div class="card-header">System Overview</div>
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                            <div style="text-align: center; padding: 1.5rem; background: var(--sidebar-bg); border-radius: 8px;">
                                <div style="font-size: 2rem; font-weight: 700; color: var(--info); margin-bottom: 0.5rem;">{open_orders}</div>
                                <div style="color: var(--text-light); font-weight: 500;">Open Work Orders</div>
                            </div>
                            <div style="text-align: center; padding: 1.5rem; background: var(--sidebar-bg); border-radius: 8px;">
                                <div style="font-size: 2rem; font-weight: 700; color: var(--success); margin-bottom: 0.5rem;">{completed_today}</div>
                                <div style="color: var(--text-light); font-weight: 500;">Completed Today</div>
                            </div>
                            <div style="text-align: center; padding: 1.5rem; background: var(--sidebar-bg); border-radius: 8px;">
                                <div style="font-size: 2rem; font-weight: 700; color: var(--danger); margin-bottom: 0.5rem;">{critical_orders}</div>
                                <div style="color: var(--text-light); font-weight: 500;">Critical Orders</div>
                            </div>
                            <div style="text-align: center; padding: 1.5rem; background: var(--sidebar-bg); border-radius: 8px;">
                                <div style="font-size: 2rem; font-weight: 700; color: var(--secondary-green); margin-bottom: 0.5rem;">{active_assets}</div>
                                <div style="color: var(--text-light); font-weight: 500;">Active Assets</div>
                            </div>
                        </div>
                    </div>
                </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">Recent Work Orders</div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Priority</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
        """
        
        for order in recent_orders:
            priority_class = {
                'Critical': 'priority-high',
                'High': 'priority-high', 
                'Medium': 'priority-medium',
                'Low': 'priority-low'
            }.get(order[2], 'priority-medium')
            
            status_class = {
                'Open': 'status-open',
                'In Progress': 'status-in-progress',
                'Completed': 'status-completed'
            }.get(order[3], 'status-open')
            
            html_content += f"""
                                <tr>
                                    <td>#{order[0]}</td>
                                    <td>{order[1]}</td>
                                    <td><span class="status-badge {priority_class}">{order[2]}</span></td>
                                    <td><span class="status-badge {status_class}">{order[3]}</span></td>
                                    <td>{order[4][:10]}</td>
                                </tr>
            """
        
        html_content += """
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">Quick Actions</div>
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                            <a href="/work-orders" class="btn btn-primary" style="text-decoration: none; text-align: center; padding: 1rem;">
                                Work Orders
                            </a>
                            <a href="/assets" class="btn btn-success" style="text-decoration: none; text-align: center; padding: 1rem;">
                                Assets
                            </a>
                            <a href="/parts" class="btn btn-warning" style="text-decoration: none; text-align: center; padding: 1rem;">
                                Parts
                            </a>
                            <a href="/quality" class="btn btn-primary" style="text-decoration: none; text-align: center; padding: 1rem;">
                                Quality
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- AI Assistant Widget -->
                <div id="ai-assistant" style="position: fixed; bottom: 20px; right: 20px; z-index: 1000;">
                    <div id="ai-toggle" onclick="toggleAI()" style="
                        background: var(--secondary-green);
                        color: white;
                        padding: 15px;
                        border-radius: 50px;
                        cursor: pointer;
                        box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
                        font-weight: 600;
                        user-select: none;
                        transition: all 0.3s ease;
                    " onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
                        🤖 ChatterFix AI
                    </div>
                    
                    <div id="ai-chat" style="
                        position: absolute;
                        bottom: 70px;
                        right: 0;
                        width: 350px;
                        height: 400px;
                        background: white;
                        border-radius: 15px;
                        box-shadow: 0 8px 30px rgba(0,0,0,0.15);
                        border: 1px solid var(--border-light);
                        display: none;
                        flex-direction: column;
                    ">
                        <div style="
                            background: var(--primary-navy);
                            color: white;
                            padding: 15px;
                            border-radius: 15px 15px 0 0;
                            font-weight: 600;
                        ">
                            🤖 ChatterFix AI Assistant
                        </div>
                        
                        <div id="ai-messages" style="
                            flex: 1;
                            padding: 15px;
                            overflow-y: auto;
                            border-bottom: 1px solid var(--border-light);
                        ">
                            <div style="
                                background: var(--sidebar-bg);
                                padding: 10px;
                                border-radius: 10px;
                                margin-bottom: 10px;
                                color: var(--text-dark);
                            ">
                                👋 Hi! I'm your ChatterFix AI assistant. Try saying:<br><br>
                                • "Create work order for pump repair"<br>
                                • "Show me critical assets"<br>
                                • "Update work order 5 to completed"<br>
                                • "What's my system status?"
                            </div>
                        </div>
                        
                        <div style="padding: 15px;">
                            <div style="display: flex; gap: 10px;">
                                <input type="text" id="ai-input" placeholder="Type or speak your request..." style="
                                    flex: 1;
                                    padding: 10px;
                                    border: 1px solid var(--border-light);
                                    border-radius: 25px;
                                    outline: none;
                                    font-size: 14px;
                                " onkeypress="if(event.key==='Enter') sendMessage()">
                                <button onclick="toggleVoice()" id="voice-btn" style="
                                    background: var(--secondary-green);
                                    color: white;
                                    border: none;
                                    padding: 10px 15px;
                                    border-radius: 50%;
                                    cursor: pointer;
                                    font-size: 16px;
                                " title="Voice Input">🎤</button>
                                <button onclick="sendMessage()" style="
                                    background: var(--primary-navy);
                                    color: white;
                                    border: none;
                                    padding: 10px 15px;
                                    border-radius: 50%;
                                    cursor: pointer;
                                    font-size: 16px;
                                ">➤</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <script>
                let aiOpen = false;
                let isListening = false;
                let recognition;
                
                function toggleAI() {
                    const chat = document.getElementById('ai-chat');
                    const toggle = document.getElementById('ai-toggle');
                    aiOpen = !aiOpen;
                    
                    if (aiOpen) {
                        chat.style.display = 'flex';
                        toggle.textContent = '✕ Close AI';
                        toggle.style.background = 'var(--danger)';
                    } else {
                        chat.style.display = 'none';
                        toggle.textContent = '🤖 ChatterFix AI';
                        toggle.style.background = 'var(--secondary-green)';
                    }
                }
                
                function sendMessage() {
                    const input = document.getElementById('ai-input');
                    const message = input.value.trim();
                    if (!message) return;
                    
                    addMessage(message, 'user');
                    input.value = '';
                    
                    // Send to AI
                    fetch('/api/ai', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({message: message})
                    })
                    .then(response => response.json())
                    .then(data => {
                        addMessage(data.response, 'ai');
                    })
                    .catch(error => {
                        addMessage('Sorry, I encountered an error. Please try again.', 'ai');
                    });
                }
                
                function addMessage(text, sender) {
                    const messages = document.getElementById('ai-messages');
                    const div = document.createElement('div');
                    
                    if (sender === 'user') {
                        div.style.cssText = `
                            background: var(--primary-navy);
                            color: white;
                            padding: 8px 12px;
                            border-radius: 15px 15px 5px 15px;
                            margin: 5px 0 5px 50px;
                            text-align: right;
                        `;
                    } else {
                        div.style.cssText = `
                            background: var(--sidebar-bg);
                            color: var(--text-dark);
                            padding: 8px 12px;
                            border-radius: 15px 15px 15px 5px;
                            margin: 5px 50px 5px 0;
                        `;
                    }
                    
                    div.textContent = text;
                    messages.appendChild(div);
                    messages.scrollTop = messages.scrollHeight;
                }
                
                function toggleVoice() {
                    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                        alert('Voice recognition not supported in this browser');
                        return;
                    }
                    
                    const voiceBtn = document.getElementById('voice-btn');
                    
                    if (!isListening) {
                        startListening();
                        voiceBtn.textContent = '🔴';
                        voiceBtn.style.background = 'var(--danger)';
                        isListening = true;
                    } else {
                        stopListening();
                        voiceBtn.textContent = '🎤';
                        voiceBtn.style.background = 'var(--secondary-green)';
                        isListening = false;
                    }
                }
                
                function startListening() {
                    recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
                    recognition.continuous = false;
                    recognition.interimResults = false;
                    recognition.lang = 'en-US';
                    
                    recognition.onresult = function(event) {
                        const transcript = event.results[0][0].transcript;
                        document.getElementById('ai-input').value = transcript;
                        sendMessage();
                        stopListening();
                    };
                    
                    recognition.onerror = function() {
                        stopListening();
                    };
                    
                    recognition.start();
                }
                
                function stopListening() {
                    if (recognition) {
                        recognition.stop();
                    }
                    const voiceBtn = document.getElementById('voice-btn');
                    voiceBtn.textContent = '🎤';
                    voiceBtn.style.background = 'var(--secondary-green)';
                    isListening = false;
                }
            </script>
            <script src="/ai-inject.js" async></script>
    </body>
        </html>
        """
        
        return HTMLResponse(content=html_content)
        
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        return HTMLResponse(content=f"<h1>Error loading dashboard: {e}</h1>", status_code=500)

@app.get("/work-orders")
async def work_orders():
    """Work orders management page"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, description, status, priority, assigned_to, created_date, updated_date
            FROM work_orders 
            ORDER BY 
                CASE priority 
                    WHEN 'Critical' THEN 1 
                    WHEN 'High' THEN 2 
                    WHEN 'Medium' THEN 3 
                    WHEN 'Low' THEN 4 
                END,
                created_date DESC
        """)
        orders = cursor.fetchall()
        conn.close()
        
        styles = get_unified_styles()
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Work Orders - ChatterFix CMMS</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>{styles}</style>
        </head>
        <body>
            <header class="header">
                <h1>ChatterFix CMMS</h1>
            </header>
            
            <div class="container">
                <div class="nav-pills">
                    <a href="/dashboard" class="nav-link">Dashboard</a>
                    <a href="/work-orders" class="nav-link">Work Orders</a>
                    <a href="/assets" class="nav-link">Assets</a>
                    <a href="/parts" class="nav-link">Parts</a>
                    <a href="/quality" class="nav-link">Quality</a>
                    <a href="/finance" class="nav-link">Finance</a>
                    <a href="/hr" class="nav-link">HR</a>
                </div>
                
                <div class="card">
                    <div class="card-header">📋 Work Orders Management</div>
                    <div class="card-body">
                        <div style="margin-bottom: 1.5rem; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                            <button onclick="createNewWorkOrder()" class="btn btn-primary">+ Create New Work Order</button>
                            <button onclick="aiSuggestMaintenance()" class="btn" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">🤖 AI Maintenance Suggestions</button>
                            <input type="text" id="searchWorkOrders" placeholder="Search work orders..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;" onkeyup="filterWorkOrders()">
                            <select id="statusFilter" onchange="filterWorkOrders()" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="">All Statuses</option>
                                <option value="Open">Open</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                                <option value="On Hold">On Hold</option>
                            </select>
                        </div>
                        <div class="table">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.3);">
                                <th style="text-align: left; padding: 10px;">ID</th>
                                <th style="text-align: left; padding: 10px;">Title</th>
                                <th style="text-align: left; padding: 10px;">Priority</th>
                                <th style="text-align: left; padding: 10px;">Status</th>
                                <th style="text-align: left; padding: 10px;">Assigned</th>
                                <th style="text-align: left; padding: 10px;">Created</th>
                                <th style="text-align: left; padding: 10px;">Due</th>
                                <th style="text-align: left; padding: 10px; width: 200px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
        """
        
        for order in orders:
            priority_color = {
                'Critical': '#e74c3c',
                'High': '#f39c12', 
                'Medium': '#3498db',
                'Low': '#2ecc71'
            }.get(order[4], '#3498db')
            
            status_color = {
                'Open': '#f39c12',
                'In Progress': '#3498db',
                'Completed': '#2ecc71',
                'On Hold': '#e74c3c'
            }.get(order[3], '#3498db')
            
            html_content += f"""
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.1); cursor: pointer; transition: background-color 0.3s;" onclick="viewWorkOrder({order[0]})" onmouseover="this.style.backgroundColor='rgba(76,175,80,0.1)'" onmouseout="this.style.backgroundColor='transparent'">
                                <td style="padding: 10px;">#{order[0]}</td>
                                <td style="padding: 10px;"><strong>{order[1]}</strong><br><small>{order[2][:50]}...</small></td>
                                <td style="padding: 10px; color: {priority_color};">●{order[4]}</td>
                                <td style="padding: 10px; color: {status_color};">●{order[3]}</td>
                                <td style="padding: 10px;">{order[5] or 'Unassigned'}</td>
                                <td style="padding: 10px;">{order[6][:10]}</td>
                                <td style="padding: 10px;">{order[7][:10] if order[7] else 'Not set'}</td>
                                <td style="padding: 10px;">
                                    <button onclick="event.stopPropagation(); editWorkOrder({order[0]})" style="background: var(--info); border: none; color: white; padding: 5px 10px; border-radius: 3px; margin-right: 5px; cursor: pointer; font-size: 12px;">✏️ Edit</button>
                                    <button onclick="event.stopPropagation(); completeWorkOrder({order[0]})" style="background: var(--success); border: none; color: white; padding: 5px 10px; border-radius: 3px; margin-right: 5px; cursor: pointer; font-size: 12px;">✅ Complete</button>
                                    <button onclick="event.stopPropagation(); deleteWorkOrder({order[0]})" style="background: var(--danger); border: none; color: white; padding: 5px 10px; border-radius: 3px; cursor: pointer; font-size: 12px;">🗑️ Delete</button>
                                </td>
                            </tr>
            """
        
        html_content += """
                        </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
            <script src="/ai-inject.js" async></script>
    </body>
        </html>
        """
        
        return HTMLResponse(content=html_content)
        
    except Exception as e:
        logger.error(f"Work orders error: {e}")
        return HTMLResponse(content=f"<h1>Error loading work orders: {e}</h1>", status_code=500)

@app.get("/assets")
async def assets():
    """Assets management page"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, name, asset_type, location, manufacturer, model, status, criticality, created_date
            FROM assets 
            ORDER BY criticality DESC, name
        """)
        assets = cursor.fetchall()
        conn.close()
        
        styles = get_unified_styles()
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Assets - ChatterFix CMMS</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>{styles}</style>
        </head>
        <body>
            <header class="header">
                <h1>ChatterFix CMMS</h1>
            </header>
            
            <div class="container">
                <div class="nav-pills">
                    <a href="/dashboard" class="nav-link">Dashboard</a>
                    <a href="/work-orders" class="nav-link">Work Orders</a>
                    <a href="/assets" class="nav-link">Assets</a>
                    <a href="/parts" class="nav-link">Parts</a>
                    <a href="/quality" class="nav-link">Quality</a>
                    <a href="/finance" class="nav-link">Finance</a>
                    <a href="/hr" class="nav-link">HR</a>
                </div>
                
                <div class="card">
                    <div class="card-header">🏭 AI-Powered Asset Management & Health Monitoring</div>
                    <div class="card-body">
                        <div style="margin-bottom: 1.5rem; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                            <button onclick="createNewAsset()" class="btn btn-primary">+ Add New Asset</button>
                            <button onclick="aiAssetHealthAnalysis()" class="btn" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">🤖 AI Health Analysis</button>
                            <button onclick="aiMaintenanceScheduler()" class="btn" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">📅 AI Schedule Maintenance</button>
                            <input type="text" id="searchAssets" placeholder="Search assets..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;" onkeyup="filterAssets()">
                            <select id="statusFilter" onchange="filterAssets()" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="">All Status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                                <option value="Maintenance">Under Maintenance</option>
                            </select>
                            <select id="criticalityFilter" onchange="filterAssets()" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="">All Criticality</option>
                                <option value="Critical">Critical</option>
                                <option value="High">High</option>
                                <option value="Medium">Medium</option>
                                <option value="Low">Low</option>
                            </select>
                        </div>
                
                <div class="table">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.3);">
                                <th style="text-align: left; padding: 10px;">ID</th>
                                <th style="text-align: left; padding: 10px;">Name</th>
                                <th style="text-align: left; padding: 10px;">Type</th>
                                <th style="text-align: left; padding: 10px;">Location</th>
                                <th style="text-align: left; padding: 10px;">Manufacturer</th>
                                <th style="text-align: left; padding: 10px;">Status</th>
                                <th style="text-align: left; padding: 10px;">Criticality</th>
                                <th style="text-align: left; padding: 10px;">Last Maintenance</th>
                                <th style="text-align: left; padding: 10px; width: 280px;">AI-Powered Actions</th>
                            </tr>
                        </thead>
                        <tbody>
        """
        
        for asset in assets:
            status_color = {
                'Active': '#2ecc71',
                'Inactive': '#e74c3c',
                'Maintenance': '#f39c12'
            }.get(asset[6], '#3498db')
            
            criticality_color = {
                'Critical': '#e74c3c',
                'High': '#f39c12', 
                'Medium': '#3498db',
                'Low': '#2ecc71'
            }.get(asset[7], '#3498db')
            
            html_content += f"""
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.1); cursor: pointer; transition: background-color 0.3s;" onclick="viewAssetDetails({asset[0]})" onmouseover="this.style.backgroundColor='rgba(76,175,80,0.1)'" onmouseout="this.style.backgroundColor='transparent'" data-status="{asset[6]}" data-criticality="{asset[7]}">
                                <td style="padding: 10px;">#{asset[0]}</td>
                                <td style="padding: 10px;"><strong>{asset[1]}</strong></td>
                                <td style="padding: 10px;">{asset[2] or 'N/A'}</td>
                                <td style="padding: 10px;">{asset[3] or 'N/A'}</td>
                                <td style="padding: 10px;">{asset[4] or 'N/A'} {asset[5] or ''}</td>
                                <td style="padding: 10px; color: {status_color};">●{asset[6]}</td>
                                <td style="padding: 10px; color: {criticality_color};">●{asset[7]}</td>
                                <td style="padding: 10px;">{asset[8][:10] if asset[8] else 'Never'}</td>
                                <td style="padding: 10px;">
                                    <button onclick="event.stopPropagation(); aiHealthCheck({asset[0]})" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; color: white; padding: 4px 6px; border-radius: 3px; margin-right: 2px; cursor: pointer; font-size: 10px;">🤖 Health</button>
                                    <button onclick="event.stopPropagation(); scheduleMaintenanceAI({asset[0]})" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border: none; color: white; padding: 4px 6px; border-radius: 3px; margin-right: 2px; cursor: pointer; font-size: 10px;">📅 Schedule</button>
                                    <button onclick="event.stopPropagation(); viewMaintenanceHistory({asset[0]})" style="background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%); border: none; color: white; padding: 4px 6px; border-radius: 3px; margin-right: 2px; cursor: pointer; font-size: 10px;">📊 History</button>
                                    <button onclick="event.stopPropagation(); editAsset({asset[0]})" style="background: var(--info); border: none; color: white; padding: 4px 6px; border-radius: 3px; margin-right: 2px; cursor: pointer; font-size: 10px;">✏️</button>
                                    <button onclick="event.stopPropagation(); deleteAsset({asset[0]})" style="background: var(--danger); border: none; color: white; padding: 4px 6px; border-radius: 3px; cursor: pointer; font-size: 10px;">🗑️</button>
                                </td>
                            </tr>
            """
        
        html_content += """
                        </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <script src="/ai-inject.js" async></script>
            <script>
                // Revolutionary AI-Powered Asset Management System
                
                function viewAssetDetails(id) { window.location.href = `/asset/${id}`; }
                function createNewAsset() { window.location.href = '/asset/new'; }
                function editAsset(id) { window.location.href = `/asset/${id}/edit`; }
                
                async function aiHealthCheck(id) {
                    try {
                        const response = await fetch(`/api/assets/${id}/ai-health-check`);
                        const health = await response.json();
                        
                        const healthColor = health.overall_score >= 80 ? '#2ecc71' : health.overall_score >= 60 ? '#f39c12' : '#e74c3c';
                        const modal = document.createElement('div');
                        modal.id = 'healthModal';
                        modal.style = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;';
                        modal.innerHTML = `
                            <div style="background: white; padding: 20px; border-radius: 8px; max-width: 600px; width: 90%;">
                                <h3>🤖 AI Asset Health Analysis</h3>
                                <div style="background: linear-gradient(135deg, rgba(102,126,234,0.1) 0%, rgba(118,75,162,0.1) 100%); padding: 15px; border-radius: 5px; border-left: 4px solid ${healthColor}; margin: 15px 0;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                        <strong>Overall Health Score:</strong>
                                        <span style="font-size: 24px; color: ${healthColor}; font-weight: bold;">${health.overall_score}%</span>
                                    </div>
                                    <div style="margin-bottom: 10px;"><strong>Status:</strong> ${health.health_status}</div>
                                    <div style="margin-bottom: 10px;"><strong>Next Maintenance:</strong> ${health.next_maintenance_date}</div>
                                    <div style="margin-bottom: 15px;"><strong>Risk Level:</strong> <span style="color: ${healthColor};">${health.risk_level}</span></div>
                                    <div><strong>AI Recommendations:</strong></div>
                                    <ul style="margin: 10px 0; padding-left: 20px;">
                                        ${health.recommendations.map(r => `<li>${r}</li>`).join('')}
                                    </ul>
                                    <div style="margin-top: 15px;"><strong>AI Analysis:</strong> ${health.ai_analysis}</div>
                                </div>
                                <div style="display: flex; gap: 10px; margin-top: 15px;">
                                    <button onclick="scheduleMaintenanceAI(${id})" style="background: #f39c12; color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">📅 Schedule Maintenance</button>
                                    <button onclick="document.getElementById('healthModal').remove()" style="background: #6c757d; color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">Close</button>
                                </div>
                            </div>
                        `;
                        document.body.appendChild(modal);
                    } catch (error) {
                        alert('Error getting health analysis: ' + error.message);
                    }
                }
                
                async function scheduleMaintenanceAI(id) {
                    try {
                        const response = await fetch(`/api/assets/${id}/ai-maintenance-schedule`);
                        const schedule = await response.json();
                        
                        if (confirm(`🤖 AI Recommends scheduling maintenance for ${schedule.recommended_date}\\n\\nTask: ${schedule.maintenance_type}\\nEstimated Duration: ${schedule.estimated_hours} hours\\nPriority: ${schedule.priority}\\n\\nCreate work order?`)) {
                            const createResponse = await fetch('/api/work-orders', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    title: `AI Scheduled: ${schedule.maintenance_type}`,
                                    description: schedule.description,
                                    asset_id: id,
                                    priority: schedule.priority,
                                    estimated_hours: schedule.estimated_hours
                                })
                            });
                            if (createResponse.ok) {
                                alert('✅ Maintenance work order created successfully!');
                                location.reload();
                            }
                        }
                    } catch (error) {
                        alert('Error scheduling maintenance: ' + error.message);
                    }
                }
                
                async function viewMaintenanceHistory(id) {
                    try {
                        const response = await fetch(`/api/assets/${id}/maintenance-history`);
                        const history = await response.json();
                        
                        let historyHtml = '<div style="max-height: 400px; overflow-y: auto;">';
                        if (history.maintenance_records.length === 0) {
                            historyHtml += '<p>No maintenance history found.</p>';
                        } else {
                            history.maintenance_records.forEach(record => {
                                const statusColor = record.status === 'Completed' ? '#2ecc71' : '#f39c12';
                                historyHtml += `
                                    <div style="margin: 10px 0; padding: 10px; border-left: 3px solid ${statusColor}; background: rgba(76,175,80,0.05);">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <strong>${record.work_order_title}</strong>
                                            <span style="color: ${statusColor};">●${record.status}</span>
                                        </div>
                                        <small>Date: ${record.date} | Duration: ${record.actual_hours || 'N/A'} hrs | Tech: ${record.technician || 'Unassigned'}</small><br>
                                        <em>${record.description}</em>
                                    </div>
                                `;
                            });
                        }
                        historyHtml += '</div>';
                        
                        document.body.insertAdjacentHTML('beforeend', `
                            <div id="historyModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;">
                                <div style="background: white; padding: 20px; border-radius: 8px; max-width: 700px; width: 90%;">
                                    <h3>📊 Maintenance History & AI Insights</h3>
                                    <div style="background: rgba(102,126,234,0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                                        <strong>AI Summary:</strong> ${history.ai_summary}
                                    </div>
                                    ${historyHtml}
                                    <button onclick="document.getElementById('historyModal').remove()" style="margin-top: 10px; background: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">Close</button>
                                </div>
                            </div>
                        `);
                    } catch (error) {
                        alert('Error loading maintenance history: ' + error.message);
                    }
                }
                
                async function deleteAsset(id) {
                    if (confirm('Are you sure you want to delete this asset? This action cannot be undone.')) {
                        try {
                            const response = await fetch(`/api/assets/${id}`, { method: 'DELETE' });
                            if (response.ok) { location.reload(); } 
                            else { alert('Error deleting asset'); }
                        } catch (error) { alert('Error: ' + error.message); }
                    }
                }
                
                async function aiAssetHealthAnalysis() {
                    try {
                        const response = await fetch('/api/assets/ai-health-overview');
                        const overview = await response.json();
                        
                        let html = '<div style="max-height: 400px; overflow-y: auto;">';
                        overview.asset_health_summary.forEach(asset => {
                            const healthColor = asset.health_score >= 80 ? '#2ecc71' : asset.health_score >= 60 ? '#f39c12' : '#e74c3c';
                            html += `<div style="margin: 10px 0; padding: 10px; border-left: 3px solid ${healthColor}; background: rgba(102,126,234,0.05);">
                                <div style="display: flex; justify-content: space-between;"><strong>${asset.name}</strong> <span style="color: ${healthColor};">${asset.health_score}%</span></div>
                                <small>Status: ${asset.status} | Risk: ${asset.risk_level}</small></div>`;
                        });
                        html += '</div>';
                        
                        document.body.insertAdjacentHTML('beforeend', `
                            <div id="overviewModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;">
                                <div style="background: white; padding: 20px; border-radius: 8px; max-width: 700px; width: 90%;">
                                    <h3>🤖 AI Asset Fleet Health Overview</h3>
                                    <div style="background: rgba(102,126,234,0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                                        <strong>Overall Fleet Health:</strong> ${overview.fleet_health_score}% | <strong>Critical Assets:</strong> ${overview.critical_count} | <strong>Maintenance Due:</strong> ${overview.maintenance_due_count}
                                    </div>
                                    ${html}
                                    <button onclick="document.getElementById('overviewModal').remove()" style="margin-top: 10px; background: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">Close</button>
                                </div>
                            </div>
                        `);
                    } catch (error) { alert('Error: ' + error.message); }
                }
                
                function aiMaintenanceScheduler() {
                    alert('🤖 AI Maintenance Scheduler will analyze all assets and create optimal maintenance schedules. Feature launching soon!');
                }
                
                function filterAssets() {
                    const search = document.getElementById('searchAssets').value.toLowerCase();
                    const status = document.getElementById('statusFilter').value;
                    const criticality = document.getElementById('criticalityFilter').value;
                    
                    document.querySelectorAll('tbody tr').forEach(row => {
                        const name = row.children[1].textContent.toLowerCase();
                        const assetStatus = row.getAttribute('data-status');
                        const assetCriticality = row.getAttribute('data-criticality');
                        
                        const matchesSearch = name.includes(search);
                        const matchesStatus = !status || assetStatus === status;
                        const matchesCriticality = !criticality || assetCriticality === criticality;
                        
                        row.style.display = matchesSearch && matchesStatus && matchesCriticality ? '' : 'none';
                    });
                }
            </script>
    </body>
        </html>
        """
        
        return HTMLResponse(content=html_content)
        
    except Exception as e:
        logger.error(f"Assets error: {e}")
        return HTMLResponse(content=f"<h1>Error loading assets: {e}</h1>", status_code=500)

@app.get("/parts")
async def parts():
    """Parts inventory page"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, part_number, name, category, stock_quantity, min_stock, unit_cost, location
            FROM parts 
            ORDER BY name
        """)
        parts = cursor.fetchall()
        conn.close()
        
        styles = get_unified_styles()
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Parts Inventory - ChatterFix CMMS</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>{styles}</style>
        </head>
        <body>
            <header class="header">
                <h1>ChatterFix CMMS</h1>
            </header>
            
            <div class="container">
                <div class="nav-pills">
                    <a href="/dashboard" class="nav-link">Dashboard</a>
                    <a href="/work-orders" class="nav-link">Work Orders</a>
                    <a href="/assets" class="nav-link">Assets</a>
                    <a href="/parts" class="nav-link">Parts</a>
                    <a href="/quality" class="nav-link">Quality</a>
                    <a href="/finance" class="nav-link">Finance</a>
                    <a href="/hr" class="nav-link">HR</a>
                </div>
                
                <div class="card">
                    <div class="card-header">📦 AI-Powered Parts Inventory Management</div>
                    <div class="card-body">
                        <div style="margin-bottom: 1.5rem; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                            <button onclick="createNewPart()" class="btn btn-primary">+ Add New Part</button>
                            <button onclick="aiPredictOrders()" class="btn" style="background: linear-gradient(135deg, #FF6B6B 0%, #FF8E8E 100%); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">🤖 AI Predict Reorders</button>
                            <button onclick="bulkCheckout()" class="btn" style="background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">📋 Bulk Checkout</button>
                            <input type="text" id="searchParts" placeholder="Search parts..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;" onkeyup="filterParts()">
                            <select id="categoryFilter" onchange="filterParts()" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="">All Categories</option>
                                <option value="Electrical">Electrical</option>
                                <option value="Mechanical">Mechanical</option>
                                <option value="Hydraulic">Hydraulic</option>
                                <option value="Safety">Safety</option>
                            </select>
                            <select id="stockFilter" onchange="filterParts()" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="">All Stock Levels</option>
                                <option value="low">Low Stock</option>
                                <option value="ok">Normal Stock</option>
                            </select>
                        </div>
                
                <div class="table">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.3);">
                                <th style="text-align: left; padding: 10px;">Part Number</th>
                                <th style="text-align: left; padding: 10px;">Name</th>
                                <th style="text-align: left; padding: 10px;">Category</th>
                                <th style="text-align: left; padding: 10px;">Stock</th>
                                <th style="text-align: left; padding: 10px;">Min Stock</th>
                                <th style="text-align: left; padding: 10px;">Unit Cost</th>
                                <th style="text-align: left; padding: 10px;">Location</th>
                                <th style="text-align: left; padding: 10px; width: 250px;">AI Actions</th>
                            </tr>
                        </thead>
                        <tbody>
        """
        
        for part in parts:
            stock_status = 'low' if part[4] <= part[5] else 'ok'
            stock_color = '#e74c3c' if stock_status == 'low' else '#2ecc71'
            cost_display = f"${part[6]:.2f}" if part[6] is not None else "$0.00"
            
            html_content += f"""
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.1); cursor: pointer; transition: background-color 0.3s;" onclick="viewPartDetails({part[0]})" onmouseover="this.style.backgroundColor='rgba(76,175,80,0.1)'" onmouseout="this.style.backgroundColor='transparent'" data-category="{part[3] or 'General'}" data-stock="{stock_status}">
                                <td style="padding: 10px;"><strong>{part[1]}</strong></td>
                                <td style="padding: 10px;">{part[2]}</td>
                                <td style="padding: 10px;">{part[3] or 'General'}</td>
                                <td style="padding: 10px; color: {stock_color};">
                                    <strong>{part[4]}</strong>
                                    {f'<span style="color: #e74c3c; font-size: 12px;">⚠️ LOW</span>' if stock_status == 'low' else ''}
                                </td>
                                <td style="padding: 10px;">{part[5]}</td>
                                <td style="padding: 10px;">{cost_display}</td>
                                <td style="padding: 10px;">{part[7] or 'N/A'}</td>
                                <td style="padding: 10px;">
                                    <button onclick="event.stopPropagation(); checkoutPart({part[0]})" style="background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%); border: none; color: white; padding: 4px 8px; border-radius: 3px; margin-right: 3px; cursor: pointer; font-size: 11px;">🔄 Checkout</button>
                                    <button onclick="event.stopPropagation(); restockPart({part[0]})" style="background: linear-gradient(135deg, #95E1D3 0%, #F3E5AB 100%); border: none; color: #2d3748; padding: 4px 8px; border-radius: 3px; margin-right: 3px; cursor: pointer; font-size: 11px;">📦 Restock</button>
                                    <button onclick="event.stopPropagation(); aiOrderPart({part[0]})" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; color: white; padding: 4px 8px; border-radius: 3px; margin-right: 3px; cursor: pointer; font-size: 11px;">🤖 AI Order</button>
                                    <button onclick="event.stopPropagation(); editPart({part[0]})" style="background: var(--info); border: none; color: white; padding: 4px 8px; border-radius: 3px; margin-right: 3px; cursor: pointer; font-size: 11px;">✏️</button>
                                    <button onclick="event.stopPropagation(); deletePart({part[0]})" style="background: var(--danger); border: none; color: white; padding: 4px 8px; border-radius: 3px; cursor: pointer; font-size: 11px;">🗑️</button>
                                </td>
                            </tr>
            """
        
        html_content += """
                        </tbody>
                    </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <script src="/ai-inject.js" async></script>
            <script>
                // Revolutionary AI-Powered Parts Management System
                function viewPartDetails(id) { window.location.href = `/part/${id}`; }
                function createNewPart() { window.location.href = '/part/new'; }
                
                async function checkoutPart(id) {
                    const quantity = prompt('Checkout quantity:');
                    if (quantity && parseInt(quantity) > 0) {
                        try {
                            const response = await fetch(`/api/parts/${id}/checkout`, {
                                method: 'POST', headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ quantity: parseInt(quantity) })
                            });
                            if (response.ok) { alert('✅ Part checked out successfully'); location.reload(); } 
                            else { alert('❌ Error checking out part'); }
                        } catch (error) { alert('Error: ' + error.message); }
                    }
                }
                
                async function restockPart(id) {
                    const quantity = prompt('Restock quantity:');
                    if (quantity && parseInt(quantity) > 0) {
                        try {
                            const response = await fetch(`/api/parts/${id}/restock`, {
                                method: 'POST', headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ quantity: parseInt(quantity) })
                            });
                            if (response.ok) { alert('✅ Part restocked successfully'); location.reload(); } 
                            else { alert('❌ Error restocking part'); }
                        } catch (error) { alert('Error: ' + error.message); }
                    }
                }
                
                async function aiOrderPart(id) {
                    try {
                        const response = await fetch(`/api/parts/${id}/ai-order-suggestion`);
                        const suggestion = await response.json();
                        alert('🤖 AI ORDER RECOMMENDATION:\\n\\n' + 
                            'Recommended: ' + suggestion.recommended_quantity + ' units\\n' +
                            'Reasoning: ' + suggestion.reasoning);
                    } catch (error) { alert('Error: ' + error.message); }
                }
                
                function editPart(id) { alert('Edit part #' + id + ' - Feature coming soon!'); }
                function deletePart(id) { if(confirm('Delete part?')) alert('Delete confirmed for part #' + id); }
                
                async function aiPredictOrders() {
                    try {
                        const response = await fetch('/api/parts/ai-reorder-predictions');
                        const data = await response.json();
                        let html = '<div style="max-height:400px;overflow-y:auto;">';
                        data.predictions.forEach(p => html += `<div style="margin:10px 0;padding:10px;border-left:3px solid #e74c3c;background:rgba(231,76,60,0.1);"><strong>${p.part_name}</strong><br>Need: ${p.predicted_usage} units</div>`);
                        html += '</div>';
                        document.body.insertAdjacentHTML('beforeend', `<div id="modal" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:1000;display:flex;align-items:center;justify-content:center;"><div style="background:white;padding:20px;border-radius:8px;max-width:600px;width:90%;"><h3>🤖 AI Reorder Predictions</h3>${html}<button onclick="document.getElementById('modal').remove()" style="margin-top:10px;background:#4CAF50;color:white;border:none;padding:10px 20px;border-radius:5px;cursor:pointer;">Close</button></div></div>`);
                    } catch (error) { alert('Error: ' + error.message); }
                }
                
                function filterParts() {
                    const search = document.getElementById('searchParts').value.toLowerCase();
                    const category = document.getElementById('categoryFilter').value;
                    const stock = document.getElementById('stockFilter').value;
                    document.querySelectorAll('tbody tr').forEach(row => {
                        const name = row.children[1].textContent.toLowerCase();
                        const cat = row.getAttribute('data-category');
                        const stockStat = row.getAttribute('data-stock');
                        const show = name.includes(search) && (!category || cat === category) && (!stock || stockStat === stock);
                        row.style.display = show ? '' : 'none';
                    });
                }
                
                function bulkCheckout() { alert('🔄 Bulk Checkout - Feature coming soon!'); }
            </script>
    </body>
        </html>
        """
        
        return HTMLResponse(content=html_content)
        
    except Exception as e:
        logger.error(f"Parts error: {e}")
        return HTMLResponse(content=f"<h1>Error loading parts: {e}</h1>", status_code=500)

@app.get("/maintenance") 
async def maintenance():
    """Maintenance scheduling page"""
    styles = get_unified_styles()
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Maintenance - ChatterFix CMMS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>{styles}</style>
    </head>
    <body>
        <div class="container">
            <h1>🔄 Maintenance Scheduling</h1>
            <div style="margin: 20px 0;">
                <a href="/" class="btn">← Dashboard</a>
                <button class="btn btn-primary" style="margin-left: 10px;">+ Create PM Schedule</button>
            </div>
            
            <div class="alert alert-info">
                <h3>🚧 Maintenance Module</h3>
                <p>Preventive maintenance scheduling features are being developed. Current capabilities include:</p>
                <ul>
                    <li>Work order creation and management</li>
                    <li>Asset tracking and history</li>
                    <li>Parts inventory management</li>
                    <li>AI-powered maintenance assistance</li>
                </ul>
                <p>Coming soon: Automated PM scheduling, maintenance calendars, and predictive analytics.</p>
            </div>
        </div>
        <script src="/ai-inject.js" async></script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


# ===== CRUD ENDPOINTS =====

@app.get("/api/work-orders")
async def get_work_orders():
    """Get all work orders"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, description, status, priority, assigned_to, created_date, updated_date
            FROM work_orders 
            ORDER BY 
                CASE priority 
                    WHEN 'Critical' THEN 1 
                    WHEN 'High' THEN 2 
                    WHEN 'Medium' THEN 3 
                    WHEN 'Low' THEN 4 
                END,
                created_date DESC
        """)
        work_orders = cursor.fetchall()
        conn.close()
        
        # Convert to list of dictionaries
        orders_list = []
        for order in work_orders:
            orders_list.append({
                "id": order[0],
                "title": order[1],
                "description": order[2],
                "status": order[3],
                "priority": order[4],
                "assigned_to": order[5],
                "created_date": order[6],
                "updated_date": order[7]
            })
            
        return JSONResponse({"work_orders": orders_list})
    except Exception as e:
        logger.error(f"Error getting work orders: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/work-orders/{work_order_id}")
async def get_work_order(work_order_id: int):
    """Get a specific work order"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, description, status, priority, assigned_to, created_date, updated_date
            FROM work_orders WHERE id = ?
        """, (work_order_id,))
        order = cursor.fetchone()
        conn.close()
        
        if not order:
            return JSONResponse({"error": "Work order not found"}, status_code=404)
            
        return JSONResponse({
            "id": order[0],
            "title": order[1],
            "description": order[2],
            "status": order[3],
            "priority": order[4],
            "assigned_to": order[5],
            "created_date": order[6],
            "updated_date": order[7]
        })
    except Exception as e:
        logger.error(f"Error getting work order: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/assets")
async def get_assets():
    """Get all assets"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, name, asset_type, location, status, criticality
            FROM assets 
            ORDER BY criticality DESC, name
        """)
        assets = cursor.fetchall()
        conn.close()
        
        # Convert to list of dictionaries
        assets_list = []
        for asset in assets:
            assets_list.append({
                "id": asset[0],
                "name": asset[1],
                "asset_type": asset[2],
                "location": asset[3],
                "status": asset[4],
                "criticality": asset[5]
            })
            
        return JSONResponse({"assets": assets_list})
    except Exception as e:
        logger.error(f"Error getting assets: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/assets/{asset_id}")
async def get_asset(asset_id: int):
    """Get a specific asset"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, name, asset_type, location, status, criticality
            FROM assets WHERE id = ?
        """, (asset_id,))
        asset = cursor.fetchone()
        conn.close()
        
        if not asset:
            return JSONResponse({"error": "Asset not found"}, status_code=404)
            
        return JSONResponse({
            "id": asset[0],
            "name": asset[1],
            "asset_type": asset[2],
            "location": asset[3],
            "status": asset[4],
            "criticality": asset[5]
        })
    except Exception as e:
        logger.error(f"Error getting asset: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/parts")
async def get_parts():
    """Get all parts"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, part_number, name, description, category, unit_cost, stock_quantity, min_stock
            FROM parts 
            ORDER BY category, name
        """)
        parts = cursor.fetchall()
        conn.close()
        
        # Convert to list of dictionaries
        parts_list = []
        for part in parts:
            parts_list.append({
                "id": part[0],
                "part_number": part[1],
                "name": part[2],
                "description": part[3],
                "category": part[4],
                "unit_cost": part[5],
                "stock_quantity": part[6],
                "min_stock": part[7]
            })
            
        return JSONResponse({"parts": parts_list})
    except Exception as e:
        logger.error(f"Error getting parts: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/parts/{part_id}")
async def get_part(part_id: int):
    """Get a specific part"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, part_number, name, description, category, unit_cost, stock_quantity, min_stock
            FROM parts WHERE id = ?
        """, (part_id,))
        part = cursor.fetchone()
        conn.close()
        
        if not part:
            return JSONResponse({"error": "Part not found"}, status_code=404)
            
        return JSONResponse({
            "id": part[0],
            "part_number": part[1],
            "name": part[2],
            "description": part[3],
            "category": part[4],
            "unit_cost": part[5],
            "stock_quantity": part[6],
            "min_stock": part[7]
        })
    except Exception as e:
        logger.error(f"Error getting part: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/work-orders")
async def create_work_order(
    title: str = Form(...),
    priority: str = Form("Medium"),
    assigned_to: str = Form(...),
    description: str = Form(""),
    asset_id: int = Form(None)
):
    """Create a new work order"""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO work_orders (title, priority, status, assigned_to, created_date, assigned_asset_id, description) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (title, priority, 'Open', assigned_to, datetime.now().isoformat(), asset_id, description)
        )
        
        work_order_id = cursor.lastrowid
        conn.commit()
        
        return JSONResponse({
            "status": "success", 
            "work_order_id": work_order_id,
            "message": f"Work order #{work_order_id} created successfully"
        })
        
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create work order: {str(e)}")
    finally:
        conn.close()

@app.put("/api/work-orders/{work_order_id}")
async def update_work_order(work_order_id: int, update: WorkOrderUpdate):
    """Update an existing work order"""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT id FROM work_orders WHERE id = ?', (work_order_id,))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Work order not found")
        
        updates = {k: v for k, v in update.dict().items() if v is not None}
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [work_order_id]
        
        cursor.execute(f'UPDATE work_orders SET {set_clause} WHERE id = ?', values)
        conn.commit()
        
        return JSONResponse({
            "status": "success",
            "message": f"Work order #{work_order_id} updated successfully"
        })
        
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to update work order: {str(e)}")
    finally:
        conn.close()

@app.delete("/api/work-orders/{work_order_id}")
async def delete_work_order(work_order_id: int):
    """Delete a work order"""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('DELETE FROM work_orders WHERE id = ?', (work_order_id,))
        
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Work order not found")
        
        conn.commit()
        
        return JSONResponse({
            "status": "success",
            "message": f"Work order #{work_order_id} deleted successfully"
        })
        
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to delete work order: {str(e)}")
    finally:
        conn.close()

@app.put("/api/parts/{part_id}")
async def update_part(part_id: int, update: PartUpdate):
    """Update an existing part"""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT id FROM parts WHERE id = ?', (part_id,))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Part not found")
        
        updates = {k: v for k, v in update.dict().items() if v is not None}
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [part_id]
        
        cursor.execute(f'UPDATE parts SET {set_clause} WHERE id = ?', values)
        conn.commit()
        
        return JSONResponse({
            "status": "success",
            "message": f"Part #{part_id} updated successfully"
        })
        
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to update part: {str(e)}")
    finally:
        conn.close()

@app.delete("/api/parts/{part_id}")
async def delete_part(part_id: int):
    """Delete a part"""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('DELETE FROM parts WHERE id = ?', (part_id,))
        
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Part not found")
        
        conn.commit()
        
        return JSONResponse({
            "status": "success",
            "message": f"Part #{part_id} deleted successfully"
        })
        
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to delete part: {str(e)}")
    finally:
        conn.close()


@app.post('/api/ai')
async def ai_assistant(request: Request):
    """Enhanced AI Assistant with Ollama LLaMA 3.1:8b integration"""
    try:
        data = await request.json()
        user_input = data.get('message', '').strip()
        
        conn = get_database_connection()
        cursor = conn.cursor()
        
        response = None
        action = None
        prompt = None
        
        # Get current system context for LLaMA
        cursor.execute('SELECT COUNT(*) FROM work_orders WHERE status != ?', ('Completed',))
        open_orders = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM parts WHERE stock_quantity < min_stock')
        low_stock_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM assets WHERE status = ?', ('Active',))
        active_assets = cursor.fetchone()[0]
        
        system_context = f"""
ChatterFix CMMS Status:
- {open_orders} open work orders
- {low_stock_count} parts below minimum stock
- {active_assets} active assets
- Current time: {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""
        
        # Intent Detection with Enhanced Patterns
        user_lower = user_input.lower()
        
        # Work Order Creation Intent
        if any(phrase in user_lower for phrase in ['create work order', 'new work order', 'start work order', 'make work order']):
            # Extract entities using LLaMA
            llama_prompt = f"""
Extract work order details from: "{user_input}"
Return JSON format:
{{
    "title": "extracted title or null",
    "priority": "High/Medium/Low or null", 
    "technician": "extracted technician name or null",
    "asset": "extracted asset name or null"
}}
Only return the JSON, no explanation.
"""
            
            try:
                llama_response = requests.post('http://localhost:11434/api/generate', 
                    json={
                        'model': 'llama3.1:8b',
                        'prompt': llama_prompt,
                        'stream': False
                    }, timeout=10)
                
                if llama_response.status_code == 200:
                    import json
                    import re
                    llama_result = llama_response.json()
                    # Extract JSON from response
                    json_match = re.search(r'\{.*\}', llama_result.get('response', ''))
                    if json_match:
                        extracted = json.loads(json_match.group())
                        title = extracted.get('title')
                        priority = extracted.get('priority')
                        technician = extracted.get('technician')
                        asset_name = extracted.get('asset')
                        
                        if title and priority and technician:
                            # Find asset ID if mentioned
                            asset_id = None
                            if asset_name:
                                cursor.execute('SELECT id FROM assets WHERE name LIKE ?', (f'%{asset_name}%',))
                                asset_result = cursor.fetchone()
                                asset_id = asset_result[0] if asset_result else None
                            
                            # Create work order
                            cursor.execute('''
                                INSERT INTO work_orders (title, priority, status, assigned_to, created_date, asset_id, description) 
                                VALUES (?,?,?,?,?,?,?)
                            ''', (title, priority, 'Open', technician, datetime.now().isoformat(), asset_id, f'Created via AI: {user_input}'))
                            conn.commit()
                            wo_id = cursor.lastrowid
                            
                            response = f"✅ Work order #{wo_id} created successfully!\\n📋 Title: {title}\\n🔥 Priority: {priority}\\n👤 Assigned: {technician}"
                            action = 'created'
                        else:
                            missing = []
                            if not title: missing.append('work description')
                            if not priority: missing.append('priority level')
                            if not technician: missing.append('technician name')
                            
                            response = f"Need more details: {', '.join(missing)}"
                            prompt = "Example: 'Create work order for HVAC filter replacement, high priority, assign Sarah Chen'"
                            action = 'prompt'
                    else:
                        # Fallback extraction
                        response = "I can help create a work order! Please specify: title, priority (High/Medium/Low), and technician name."
                        action = 'prompt'
                else:
                    response = "Error processing work order. Please try again."
                    action = 'error'
                    
            except Exception as e:
                logger.error(f"LLaMA work order extraction error: {e}")
                response = "I can help create work orders! Format: 'Create work order for [task], [priority], assign [technician]'"
                action = 'prompt'
        
        # Part Management Intent
        elif any(phrase in user_lower for phrase in ['add part', 'new part', 'order part', 'create part']):
            # Simple pattern extraction for parts
            import re
            numbers = re.findall(r'\d+', user_input)
            quantity = int(numbers[0]) if numbers else 1
            
            # Extract part name after trigger words
            part_name = None
            for trigger in ['add part', 'new part', 'order part', 'create part']:
                if trigger in user_lower:
                    part_text = user_input.lower().split(trigger)[1].strip()
                    part_name = part_text.split(',')[0].strip()
                    break
            
            if part_name:
                cursor.execute('''
                    INSERT INTO parts (part_number, name, category, stock_quantity, min_stock, unit_cost, location) 
                    VALUES (?,?,?,?,?,?,?)
                ''', (
                    f'PART-{datetime.now().strftime("%Y%m%d%H%M")}', 
                    part_name, 
                    'General', 
                    quantity, 
                    max(5, quantity // 2),  # Smart minimum stock
                    25.00, 
                    'Warehouse'
                ))
                conn.commit()
                part_id = cursor.lastrowid
                response = f"✅ Part #{part_id} added to inventory!\\n📦 Name: {part_name}\\n🔢 Quantity: {quantity}"
                action = 'created'
            else:
                response = "What part would you like to add? Include name and quantity."
                prompt = "Example: 'Add part 10 motor bearings' or 'Create part hydraulic seals'"
                action = 'prompt'
        
        # Stock Check Intent
        elif any(phrase in user_lower for phrase in ['low stock', 'stock check', 'inventory check', 'parts status']):
            cursor.execute('SELECT name, stock_quantity, min_stock, location FROM parts WHERE stock_quantity < min_stock')
            low_stock = cursor.fetchall()
            
            if low_stock:
                stock_items = "\\n".join([f"• {p[0]}: {p[1]}/{p[2]} units ({p[3]})" for p in low_stock])
                response = f"⚠️ Parts below minimum stock:\\n{stock_items}"
                action = 'alert'
            else:
                cursor.execute('SELECT COUNT(*) FROM parts')
                total_parts = cursor.fetchone()[0]
                response = f"✅ All {total_parts} parts are above minimum stock levels!"
                action = 'query'
        
        # General Queries - Use LLaMA with System Context
        else:
            llama_prompt = f"""
You are ChatterFix AI, a smart CMMS assistant. 

{system_context}

User Question: {user_input}

Respond helpfully about maintenance, work orders, parts, or assets. Keep responses under 200 words and practical.
If asked about system capabilities, mention: work order creation, part management, asset tracking, voice commands.
"""
            
            try:
                llama_response = requests.post('http://localhost:11434/api/generate', 
                    json={
                        'model': 'llama3.1:8b',
                        'prompt': llama_prompt,
                        'stream': False
                    }, timeout=10)
                
                if llama_response.status_code == 200:
                    llama_result = llama_response.json()
                    response = llama_result.get('response', '').strip()
                    # Limit response length
                    if len(response) > 400:
                        response = response[:397] + "..."
                    action = 'llama'
                else:
                    raise Exception("LLaMA not responding")
                    
            except Exception as e:
                logger.error(f"LLaMA general query error: {e}")
                response = """🤖 I can help with:
• "Create work order for [task], [priority], assign [technician]"
• "Add part [quantity] [name]"
• "[Asset] history" (e.g., "Pump #001 history")
• "Low stock check"

What would you like to do?"""
                action = 'help'
        
        conn.close()
        
        return JSONResponse({
            "response": response,
            "action": action,
            "prompt": prompt,
            "context": {
                "open_orders": open_orders,
                "low_stock_count": low_stock_count,
                "active_assets": active_assets
            }
        })
    
    except Exception as e:
        logger.error(f"AI Assistant error: {e}")
        return JSONResponse({
            "response": "I'm having trouble right now. Try asking about work orders, parts, or assets!",
            "action": "error"
        })

@app.post("/global-ai/process-message")
async def global_ai_process_message(request: Request):
    """Handle AI assistant messages from universal AI system"""
    try:
        data = await request.json()
        message = data.get("message", "")
        page = data.get("page", "")
        context_type = data.get("context", "universal_ai")
        
        if not message:
            raise HTTPException(status_code=400, detail="Message is required")
        
        # Enhanced context based on current page
        page_context = f"User is currently on page: {page}\n"
        if "/work-orders" in page:
            page_context += "Context: Work order management page\n"
        elif "/assets" in page:
            page_context += "Context: Asset management page\n"
        elif "/parts" in page:
            page_context += "Context: Parts inventory page\n"
        elif "/maintenance" in page:
            page_context += "Context: Maintenance scheduling page\n"
        elif "/reports" in page:
            page_context += "Context: Reports and analytics page\n"
        
        # Get maintenance context
        maintenance_context = await get_maintenance_context()
        full_context = page_context + maintenance_context
        
        # Query ChatterFix AI with enhanced context
        response = await chatterfix_ai.query(message, full_context)
        
        # Store interaction with context
        store_ai_interaction(message, response, context_type)
        
        # Determine if any actions should be suggested
        actions = []
        if any(keyword in message.lower() for keyword in ["emergency", "urgent", "critical", "broken", "leak"]):
            actions.append("Consider creating a high-priority work order")
        if any(keyword in message.lower() for keyword in ["schedule", "maintenance", "pm", "preventive"]):
            actions.append("Check preventive maintenance schedule")
        
        return JSONResponse({
            "success": True,
            "response": response,
            "actions": actions,
            "timestamp": datetime.now().isoformat(),
            "page_context": page
        })
        
    except Exception as e:
        logger.error(f"Global AI processing error: {e}")
        return JSONResponse({
            "success": False, 
            "response": "I'm having trouble processing your request. Please try again.",
            "error": str(e)
        }, status_code=500)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        conn = get_database_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        conn.close()
        
        return JSONResponse({
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "database": "connected",
            "ai_assistant": "active"
        })
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse({
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }, status_code=500)

@app.get("/readiness")
async def readiness_check():
    """Readiness probe - returns 200 when service is ready to accept traffic"""
    try:
        # Test actual AI processing capability
        test_response = await chatterfix_ai.query(
            "health check ping", 
            "readiness probe test"
        )
        
        if test_response:
            return {"status": "ready", "timestamp": datetime.now().isoformat()}
        else:
            return JSONResponse(
                {"status": "not ready", "reason": "AI assistant not responding"},
                status_code=503
            )
    except Exception as e:
        logger.error(f"Readiness check failed: {e}")
        return JSONResponse(
            {"status": "not ready", "reason": str(e)},
            status_code=503
        )

# ============================================================================
# ADVANCED CRUD API ENDPOINTS - Making ChatterFix the Most Advanced CMMS
# ============================================================================

@app.post("/api/work-orders/{work_order_id}/complete")
async def complete_work_order(work_order_id: int):
    """Complete a work order with AI insights"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Update work order status
        cursor.execute(
            "UPDATE work_orders SET status = 'Completed', completed_date = ? WHERE id = ?",
            (datetime.now().isoformat(), work_order_id)
        )
        conn.commit()
        conn.close()
        
        # AI-powered completion insights
        ai_insight = await chatterfix_ai.query(
            f"Work order #{work_order_id} completed",
            "maintenance_completion"
        )
        
        return {"success": True, "message": "Work order completed", "ai_insight": ai_insight}
    except Exception as e:
        logger.error(f"Error completing work order: {e}")
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.delete("/api/work-orders/{work_order_id}")
async def delete_work_order(work_order_id: int):
    """Delete a work order"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM work_orders WHERE id = ?", (work_order_id,))
        conn.commit()
        conn.close()
        
        return {"success": True, "message": "Work order deleted"}
    except Exception as e:
        logger.error(f"Error deleting work order: {e}")
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/api/ai-maintenance-suggestions")
async def ai_maintenance_suggestions():
    """AI-powered predictive maintenance suggestions"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Get current system state for AI analysis
        cursor.execute("SELECT COUNT(*) FROM work_orders WHERE status = 'Open'")
        open_orders = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM assets WHERE status = 'Active'")
        active_assets = cursor.fetchone()[0]
        
        cursor.execute("SELECT name, asset_type, location FROM assets WHERE status = 'Active' ORDER BY criticality DESC LIMIT 10")
        critical_assets = cursor.fetchall()
        
        conn.close()
        
        # AI-powered analysis
        context = f"Current system: {open_orders} open work orders, {active_assets} active assets"
        
        suggestions = [
            {
                "title": "Preventive Pump Maintenance",
                "description": "Critical pumps are due for scheduled maintenance based on runtime hours",
                "priority": "High",
                "estimated_time": "4 hours",
                "parts_needed": ["Pump seals", "Oil filter", "Hydraulic fluid"]
            },
            {
                "title": "HVAC System Inspection", 
                "description": "Quarterly inspection recommended for optimal energy efficiency",
                "priority": "Medium",
                "estimated_time": "2 hours",
                "parts_needed": ["Air filters", "Thermostat calibration"]
            },
            {
                "title": "Conveyor Belt Tensioning",
                "description": "AI analysis indicates belt wear patterns require adjustment",
                "priority": "Medium", 
                "estimated_time": "1.5 hours",
                "parts_needed": ["Belt tensioner", "Alignment tools"]
            }
        ]
        
        return {"suggestions": suggestions, "context": context}
    except Exception as e:
        logger.error(f"Error getting AI suggestions: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/work-order/{work_order_id}")
async def view_work_order(work_order_id: int):
    """View detailed work order with AI insights"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, description, status, priority, assigned_to, created_date, 
                   updated_date, estimated_hours, actual_hours, completed_date
            FROM work_orders WHERE id = ?
        """, (work_order_id,))
        
        order = cursor.fetchone()
        if not order:
            return HTMLResponse(content="<h1>Work Order Not Found</h1>", status_code=404)
            
        # Get AI insights for this work order
        ai_analysis = await chatterfix_ai.query(
            f"Analyze work order: {order[1]} - {order[2]}",
            "work_order_analysis"
        )
        
        styles = get_unified_styles()
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Work Order #{order[0]} - ChatterFix CMMS</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>{styles}</style>
        </head>
        <body>
            <header class="header">
                <h1>ChatterFix CMMS</h1>
            </header>
            
            <div class="container">
                <div class="nav-pills">
                    <a href="/dashboard" class="nav-link">Dashboard</a>
                    <a href="/work-orders" class="nav-link">← Back to Work Orders</a>
                </div>
                
                <div class="card">
                    <div class="card-header">🔧 Work Order #{order[0]} - {order[1]}</div>
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div>
                                <h3>Details</h3>
                                <p><strong>Status:</strong> <span style="color: {'#2ecc71' if order[3] == 'Completed' else '#f39c12'}">{order[3]}</span></p>
                                <p><strong>Priority:</strong> <span style="color: {'#e74c3c' if order[4] == 'Critical' else '#3498db'}">{order[4]}</span></p>
                                <p><strong>Assigned To:</strong> {order[5] or 'Unassigned'}</p>
                                <p><strong>Created:</strong> {order[6][:10]}</p>
                                {f'<p><strong>Completed:</strong> {order[10][:10]}</p>' if order[10] else ''}
                            </div>
                            <div>
                                <h3>Time Tracking</h3>
                                <p><strong>Estimated Hours:</strong> {order[8] or 'Not set'}</p>
                                <p><strong>Actual Hours:</strong> {order[9] or 'Not recorded'}</p>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <h3>Description</h3>
                            <div style="background: rgba(0,0,0,0.05); padding: 15px; border-radius: 5px;">
                                {order[2]}
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <h3>🤖 AI Analysis & Recommendations</h3>
                            <div style="background: linear-gradient(135deg, rgba(76,175,80,0.1) 0%, rgba(33,150,243,0.1) 100%); padding: 15px; border-radius: 5px; border-left: 4px solid #4CAF50;">
                                {ai_analysis}
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 10px;">
                            <button onclick="window.location.href='/work-order/{order[0]}/edit'" class="btn btn-primary">✏️ Edit Work Order</button>
                            {'<button onclick="completeWorkOrder(' + str(order[0]) + ')" class="btn" style="background: #2ecc71; color: white;">✅ Mark Complete</button>' if order[3] != 'Completed' else ''}
                            <button onclick="window.print()" class="btn">🖨️ Print</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <script src="/ai-inject.js" async></script>
            <script>
                async function completeWorkOrder(id) {{
                    if (confirm('Mark this work order as completed?')) {{
                        try {{
                            const response = await fetch(`/api/work-orders/${{id}}/complete`, {{
                                method: 'POST',
                                headers: {{ 'Content-Type': 'application/json' }}
                            }});
                            if (response.ok) {{
                                location.reload();
                            }} else {{
                                alert('Error completing work order');
                            }}
                        }} catch (error) {{
                            alert('Error: ' + error.message);
                        }}
                    }}
                }}
            </script>
        </body>
        </html>
        """
        
        conn.close()
        return HTMLResponse(content=html_content)
        
    except Exception as e:
        logger.error(f"Error viewing work order: {e}")
        return HTMLResponse(content=f"<h1>Error: {e}</h1>", status_code=500)

# ============================================================================
# REVOLUTIONARY AI-POWERED PARTS MANAGEMENT API ENDPOINTS
# ============================================================================

@app.post("/api/parts/{part_id}/checkout")
async def checkout_part(part_id: int, request: Request):
    """AI-powered parts checkout with predictive insights"""
    try:
        data = await request.json()
        quantity = data.get('quantity', 1)
        work_order = data.get('work_order', None)
        
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Check current stock
        cursor.execute("SELECT part_number, name, stock_quantity FROM parts WHERE id = ?", (part_id,))
        part = cursor.fetchone()
        
        if not part or part[2] < quantity:
            conn.close()
            return JSONResponse({"success": False, "error": "Insufficient stock"}, status_code=400)
        
        # Update stock
        cursor.execute("UPDATE parts SET stock_quantity = stock_quantity - ? WHERE id = ?", (quantity, part_id))
        
        # Log transaction
        cursor.execute("""
            INSERT INTO parts_transactions (part_id, transaction_type, quantity, work_order_id, timestamp)
            VALUES (?, 'checkout', ?, ?, ?)
        """, (part_id, quantity, work_order, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        # AI insight
        ai_insight = await chatterfix_ai.query(
            f"Checked out {quantity} units of {part[1]} ({part[0]}) for work order {work_order or 'maintenance'}",
            "parts_checkout"
        )
        
        return {"success": True, "message": f"Checked out {quantity} units of {part[1]}", "ai_insight": ai_insight}
        
    except Exception as e:
        logger.error(f"Error checking out part: {e}")
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/parts/{part_id}/restock")
async def restock_part(part_id: int, request: Request):
    """Restock parts with AI optimization"""
    try:
        data = await request.json()
        quantity = data.get('quantity', 1)
        
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE parts SET stock_quantity = stock_quantity + ? WHERE id = ?", (quantity, part_id))
        cursor.execute("""
            INSERT INTO parts_transactions (part_id, transaction_type, quantity, timestamp)
            VALUES (?, 'restock', ?, ?)
        """, (part_id, quantity, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        return {"success": True, "message": f"Added {quantity} units to stock"}
        
    except Exception as e:
        logger.error(f"Error restocking part: {e}")
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/api/parts/{part_id}/ai-order-suggestion")
async def ai_order_suggestion(part_id: int):
    """AI-powered ordering suggestions"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT part_number, name, stock_quantity, min_stock, unit_cost FROM parts WHERE id = ?", (part_id,))
        part = cursor.fetchone()
        
        if not part:
            return JSONResponse({"error": "Part not found"}, status_code=404)
            
        # AI analysis for optimal ordering
        current_stock, min_stock, unit_cost = part[2], part[3], part[4] or 10.0
        
        # Smart ordering algorithm
        recommended_quantity = max(min_stock * 3, 10)  # Order 3x minimum stock
        optimal_order_size = recommended_quantity if unit_cost < 50 else min_stock * 2
        lead_time_days = 7 if unit_cost < 100 else 14
        
        reasoning = f"Based on current stock ({current_stock}) and minimum threshold ({min_stock}), AI recommends ordering {recommended_quantity} units to optimize inventory levels and reduce stockout risk."
        
        conn.close()
        
        return {
            "recommended_quantity": recommended_quantity,
            "optimal_order_size": optimal_order_size,
            "lead_time_days": lead_time_days,
            "cost_analysis": f"Total cost: ${optimal_order_size * unit_cost:.2f}",
            "reasoning": reasoning
        }
        
    except Exception as e:
        logger.error(f"Error getting AI order suggestion: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/parts/ai-reorder-predictions")
async def ai_reorder_predictions():
    """AI-powered predictive reorder analysis"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, part_number, name, stock_quantity, min_stock FROM parts WHERE stock_quantity <= min_stock * 1.5")
        low_stock_parts = cursor.fetchall()
        
        predictions = []
        for part in low_stock_parts:
            predicted_usage = max(part[3] * 2, 5)  # Predict 2x minimum stock usage
            urgency = "Critical" if part[3] <= part[4] else "Medium"
            reorder_date = datetime.now().strftime("%Y-%m-%d")
            
            predictions.append({
                "part_id": part[0],
                "part_number": part[1],
                "part_name": part[2],
                "current_stock": part[3],
                "predicted_usage": predicted_usage,
                "urgency": urgency,
                "reorder_date": reorder_date,
                "ai_reasoning": f"Based on usage patterns, recommend ordering {predicted_usage} units to prevent stockout"
            })
        
        conn.close()
        return {"predictions": predictions}
        
    except Exception as e:
        logger.error(f"Error getting AI predictions: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

# ============================================================================
# REVOLUTIONARY AI-POWERED ASSET HEALTH MONITORING API ENDPOINTS
# ============================================================================

@app.get("/api/assets/{asset_id}/ai-health-check")
async def ai_asset_health_check(asset_id: int):
    """AI-powered asset health analysis"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT name, asset_type, status, criticality, created_date FROM assets WHERE id = ?", (asset_id,))
        asset = cursor.fetchone()
        
        if not asset:
            return JSONResponse({"error": "Asset not found"}, status_code=404)
            
        # Get maintenance history for AI analysis
        cursor.execute("""
            SELECT COUNT(*) as total_maintenance, 
                   MAX(created_date) as last_maintenance
            FROM work_orders WHERE title LIKE '%' || ? || '%' OR description LIKE '%' || ? || '%'
        """, (asset[0], asset[0]))
        
        maintenance_data = cursor.fetchone()
        conn.close()
        
        # AI Health Scoring Algorithm
        base_score = 85
        
        # Status impact
        if asset[2] == 'Active':
            status_score = 0
        elif asset[2] == 'Maintenance':
            status_score = -10
        else:
            status_score = -20
            
        # Criticality impact
        criticality_score = {'Critical': -15, 'High': -10, 'Medium': -5, 'Low': 0}.get(asset[3], 0)
        
        # Maintenance frequency impact (simulated)
        maintenance_score = min(maintenance_data[0] * 2, 10) if maintenance_data[0] else -5
        
        overall_score = max(0, base_score + status_score + criticality_score + maintenance_score)
        
        # AI-powered risk assessment
        if overall_score >= 80:
            health_status = "Excellent"
            risk_level = "Low"
        elif overall_score >= 60:
            health_status = "Good"
            risk_level = "Medium"
        elif overall_score >= 40:
            health_status = "Fair"
            risk_level = "High"
        else:
            health_status = "Poor"
            risk_level = "Critical"
            
        # AI recommendations
        recommendations = []
        if overall_score < 80:
            recommendations.append("Schedule preventive maintenance within 7 days")
        if asset[2] != 'Active':
            recommendations.append("Investigate asset status and restore to active if possible")
        if maintenance_data[0] == 0:
            recommendations.append("Establish regular maintenance schedule")
        if asset[3] == 'Critical':
            recommendations.append("Implement continuous monitoring for critical asset")
            
        # Calculate next maintenance date
        from datetime import datetime, timedelta
        next_maintenance = (datetime.now() + timedelta(days=max(30 - (100-overall_score), 7))).strftime("%Y-%m-%d")
        
        ai_analysis = f"Asset health analysis shows {health_status.lower()} condition. Based on {asset[1]} type and {asset[3].lower()} criticality, recommend monitoring every {7 if overall_score < 60 else 14} days."
        
        return {
            "overall_score": overall_score,
            "health_status": health_status,
            "risk_level": risk_level,
            "next_maintenance_date": next_maintenance,
            "recommendations": recommendations,
            "ai_analysis": ai_analysis,
            "maintenance_history_count": maintenance_data[0],
            "last_maintenance": maintenance_data[1] or "Never"
        }
        
    except Exception as e:
        logger.error(f"Error in AI health check: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/assets/{asset_id}/ai-maintenance-schedule")
async def ai_maintenance_schedule(asset_id: int):
    """AI-powered maintenance scheduling"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT name, asset_type, status, criticality FROM assets WHERE id = ?", (asset_id,))
        asset = cursor.fetchone()
        
        if not asset:
            return JSONResponse({"error": "Asset not found"}, status_code=404)
            
        conn.close()
        
        # AI scheduling algorithm
        asset_type = asset[1] or "General"
        
        maintenance_types = {
            "Pump": {"type": "Pump Maintenance", "hours": 4, "description": "Inspect seals, check pressure, replace filters"},
            "Motor": {"type": "Motor Inspection", "hours": 3, "description": "Check windings, lubricate bearings, test performance"},
            "Conveyor": {"type": "Belt Inspection", "hours": 2, "description": "Check belt tension, inspect rollers, lubricate drives"},
            "Generator": {"type": "Generator Testing", "hours": 6, "description": "Load test, fuel system check, maintenance schedule"},
            "HVAC": {"type": "HVAC Service", "hours": 3, "description": "Filter replacement, system calibration, efficiency check"}
        }
        
        maintenance_plan = maintenance_types.get(asset_type, {
            "type": "General Maintenance", 
            "hours": 2, 
            "description": "Routine inspection and maintenance"
        })
        
        # Priority based on criticality
        priority_map = {"Critical": "Critical", "High": "High", "Medium": "Medium", "Low": "Low"}
        priority = priority_map.get(asset[3], "Medium")
        
        # Recommended date based on criticality
        from datetime import datetime, timedelta
        days_offset = {"Critical": 3, "High": 7, "Medium": 14, "Low": 21}.get(asset[3], 14)
        recommended_date = (datetime.now() + timedelta(days=days_offset)).strftime("%Y-%m-%d")
        
        return {
            "maintenance_type": maintenance_plan["type"],
            "description": maintenance_plan["description"],
            "estimated_hours": maintenance_plan["hours"],
            "priority": priority,
            "recommended_date": recommended_date,
            "reasoning": f"AI analysis recommends {maintenance_plan['type']} for {asset_type} with {asset[3]} criticality within {days_offset} days"
        }
        
    except Exception as e:
        logger.error(f"Error in AI maintenance scheduling: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/assets/{asset_id}/maintenance-history")
async def asset_maintenance_history(asset_id: int):
    """Get asset maintenance history with AI insights"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Get asset info
        cursor.execute("SELECT name FROM assets WHERE id = ?", (asset_id,))
        asset = cursor.fetchone()
        
        if not asset:
            return JSONResponse({"error": "Asset not found"}, status_code=404)
            
        # Get maintenance records (simulated - link work orders to assets)
        cursor.execute("""
            SELECT title, description, status, created_date, updated_date, 
                   assigned_to, actual_hours, priority
            FROM work_orders 
            WHERE title LIKE '%' || ? || '%' OR description LIKE '%' || ? || '%'
            ORDER BY created_date DESC
            LIMIT 10
        """, (asset[0], asset[0]))
        
        records = cursor.fetchall()
        conn.close()
        
        maintenance_records = []
        for record in records:
            maintenance_records.append({
                "work_order_title": record[0],
                "description": record[1],
                "status": record[2],
                "date": record[3][:10] if record[3] else "Unknown",
                "updated_date": record[4][:10] if record[4] else "Unknown",
                "technician": record[5],
                "actual_hours": record[6],
                "priority": record[7]
            })
        
        # AI summary
        total_records = len(maintenance_records)
        completed_records = len([r for r in maintenance_records if r["status"] == "Completed"])
        
        ai_summary = f"Asset {asset[0]} has {total_records} maintenance records with {completed_records} completed. "
        if total_records > 0:
            ai_summary += f"Recent maintenance activity shows good upkeep. "
            if completed_records / total_records > 0.8:
                ai_summary += "High completion rate indicates effective maintenance management."
            else:
                ai_summary += "Consider prioritizing pending maintenance tasks."
        else:
            ai_summary += "No maintenance history found. Recommend establishing maintenance schedule."
        
        return {
            "maintenance_records": maintenance_records,
            "total_records": total_records,
            "completed_records": completed_records,
            "ai_summary": ai_summary
        }
        
    except Exception as e:
        logger.error(f"Error getting maintenance history: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/assets/ai-health-overview")
async def ai_assets_health_overview():
    """AI-powered fleet health overview"""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, name, asset_type, status, criticality FROM assets ORDER BY criticality DESC")
        assets = cursor.fetchall()
        conn.close()
        
        asset_health_summary = []
        total_health = 0
        critical_count = 0
        maintenance_due_count = 0
        
        for asset in assets:
            # Simplified health calculation for overview
            base_score = 75
            if asset[3] == 'Active':
                base_score += 15
            elif asset[3] == 'Maintenance':
                base_score -= 10
                maintenance_due_count += 1
            else:
                base_score -= 20
                
            if asset[4] == 'Critical':
                base_score -= 10
                critical_count += 1
                
            health_score = max(30, min(100, base_score))
            total_health += health_score
            
            risk_level = "Low" if health_score >= 80 else "Medium" if health_score >= 60 else "High"
            
            asset_health_summary.append({
                "id": asset[0],
                "name": asset[1],
                "health_score": health_score,
                "status": asset[3],
                "risk_level": risk_level
            })
        
        fleet_health_score = int(total_health / len(assets)) if assets else 0
        
        return {
            "fleet_health_score": fleet_health_score,
            "total_assets": len(assets),
            "critical_count": critical_count,
            "maintenance_due_count": maintenance_due_count,
            "asset_health_summary": asset_health_summary
        }
        
    except Exception as e:
        logger.error(f"Error getting asset health overview: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

# Initialize database and AI client on import
init_database()

# Add universal AI endpoints to make AI assistant available on ALL pages
add_universal_ai_endpoints(app)

logger.info("ChatterFix CMMS initialized successfully with ChatterFix AI assistant")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)